using MessagePack;

[MessagePackObject(false)]
public class ProtagonistSkinDataNew
{
	[Key(0)]
	public SkinType SkinType;

	[Key(1)]
	public string Clothes = "";

	[Key(2)]
	public string Eyes = "";

	[Key(3)]
	public string Hat = "";

	[Key(4)]
	public string Nose = "";

	[Key(5)]
	public string Facemask = "";

	[Key(6)]
	public string Mouth = "";

	[Key(7)]
	public string Beard = "";

	[Key(8)]
	public string HairFront = "";

	[Key(9)]
	public string Cloak = "";

	[Key(10)]
	public string HairBack = "";

	[Key(11)]
	public string WeaponBack = "";

	[Key(12)]
	public bool isCustom;
}
