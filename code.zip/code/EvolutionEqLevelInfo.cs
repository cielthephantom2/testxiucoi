using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class EvolutionEqLevelInfo : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	[HideInInspector]
	public string LevelInfo;

	private PointerEventData _pointerEventData = new PointerEventData(EventSystem.current);

	public void OnPointerEnter(PointerEventData eventData)
	{
		base.transform.parent.parent.Find("Info").gameObject.SetActive(value: false);
		base.transform.parent.parent.Find("LvInfo/Text").GetComponent<Text>().text = LevelInfo;
		base.transform.parent.parent.Find("LvInfo").gameObject.SetActive(value: true);
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		base.transform.parent.parent.Find("Info").gameObject.SetActive(value: true);
		base.transform.parent.parent.Find("LvInfo").gameObject.SetActive(value: false);
	}
}
