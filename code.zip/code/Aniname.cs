public static class Aniname
{
	public static string aniname_stand = "A01-stand";

	public static string aniname_walk = "A02-walk";

	public static string aniname_behit = "D01-behit";

	public static string aniname_die = "D02-die";

	public static string aniname_B01_attack_sword = "B01-attack-sword";

	public static string aniname_B01_attack_sword_nouse = "B01-attack-sword-notuse";

	public static string aniname_B02_attack_knife = "B02-attack-knife";

	public static string aniname_B03_attack_stick = "B03-attack-stick";

	public static string aniname_B04_attack_hand = "B04-attack-hand";

	public static string aniname_B05_attack_finger = "B05-attack-finger";

	public static string aniname_B06_attack_heart = "B06-attack-heart";

	public static string aniname_C01_attackstand_sword = "C01-attackstand-sword";

	public static string aniname_C02_attackstand_knife = "C02-attackstand-knife";

	public static string aniname_C03_attackstand_stick = "C03-attackstand-stick";

	public static string aniname_C04_attackstand_hand = "C04-attackstand-hand";

	public static string aniname_C05_attackstand_finger = "C05-attackstand-finger";

	public static string aniname_C06_attackstand_heart = "C06-attackstand-heart";

	public static string aniname_D02_die_02 = "D02-die-02";
}
