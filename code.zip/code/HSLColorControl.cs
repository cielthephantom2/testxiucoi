using UnityEngine;
using UnityEngine.UI;

public class HSLColorControl : MonoBehaviour
{
	public delegate void ValueChangedDelegate(Color newColor);

	public CharacterChangeForm m_CharacterChangeForm;

	public Slider hueSlider;

	public Slider saturationSlider;

	public Slider lightnessSlider;

	private Color currentColor = Color.white;

	private Color[] hueColors = new Color[7]
	{
		new Color(1f, 0f, 0f),
		new Color(1f, 1f, 0f),
		new Color(0f, 1f, 0f),
		new Color(0f, 1f, 1f),
		new Color(0f, 0f, 1f),
		new Color(1f, 0f, 1f),
		new Color(1f, 0f, 0f)
	};

	public Color CurrentColor
	{
		get
		{
			return currentColor;
		}
		set
		{
			if (currentColor != value)
			{
				currentColor = value;
				this.OnValueChanged?.Invoke(currentColor);
			}
		}
	}

	public event ValueChangedDelegate OnValueChanged;

	private void Start()
	{
		hueSlider.onValueChanged.AddListener(UpdateColor);
		saturationSlider.onValueChanged.AddListener(UpdateColor);
		lightnessSlider.onValueChanged.AddListener(UpdateColor);
		hueSlider.fillRect.GetComponent<Image>().enabled = false;
		saturationSlider.fillRect.GetComponent<Image>().enabled = false;
		lightnessSlider.fillRect.GetComponent<Image>().enabled = false;
		SetHueColor();
		UpdateColor(0f);
	}

	private void SetHueColor()
	{
		Texture2D texture2D = new Texture2D(hueColors.Length, 1);
		texture2D.SetPixels(hueColors);
		texture2D.Apply();
		Sprite sprite = Sprite.Create(texture2D, new Rect(Vector2.zero, new Vector2(hueColors.Length, 1f)), Vector2.one * 0.5f);
		hueSlider.transform.Find("Background").GetComponent<Image>().sprite = sprite;
	}

	private void SetSaturationColor()
	{
		float value = hueSlider.value;
		float value2 = lightnessSlider.value;
		Texture2D texture2D = new Texture2D(256, 1);
		Color[] array = new Color[256];
		for (int i = 0; i < 256; i++)
		{
			float saturation = (float)i / 255f;
			array[i] = SkinManager.Instance().HSLToRGB(value, saturation, value2);
		}
		texture2D.SetPixels(array);
		texture2D.Apply();
		Sprite sprite = Sprite.Create(texture2D, new Rect(0f, 0f, 256f, 1f), Vector2.one * 0.5f);
		saturationSlider.transform.Find("Background").GetComponent<Image>().sprite = sprite;
	}

	private void SetLightnessColor()
	{
		float value = hueSlider.value;
		float value2 = saturationSlider.value;
		Texture2D texture2D = new Texture2D(256, 1);
		Color[] array = new Color[256];
		for (int i = 0; i < 256; i++)
		{
			float lightness = (float)i / 255f;
			array[i] = SkinManager.Instance().HSLToRGB(value, value2, lightness);
		}
		texture2D.SetPixels(array);
		texture2D.Apply();
		Sprite sprite = Sprite.Create(texture2D, new Rect(0f, 0f, 256f, 1f), Vector2.one * 0.5f);
		lightnessSlider.transform.Find("Background").GetComponent<Image>().sprite = sprite;
	}

	private void UpdateColor(float value)
	{
		SetSaturationColor();
		SetLightnessColor();
		float value2 = hueSlider.value;
		float value3 = saturationSlider.value;
		float value4 = lightnessSlider.value;
		CurrentColor = SkinManager.Instance().HSLToRGB(value2, value3, value4);
	}
}
