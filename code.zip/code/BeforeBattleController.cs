using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BeforeBattleController : MonoBehaviour
{
	private GameObject ChoosePanel;

	private GameObject ChooseCount;

	private int SelectedCount;

	private Sprite NormalSprite;

	private Color NormalColor = new Color(14f / 51f, 0.23137255f, 16f / 85f);

	private Sprite SelectedSprite;

	private Color SelectedColor = new Color(47f / 51f, 76f / 85f, 0.8235294f);

	private Sprite UnInteractableSprit;

	private Sprite InteractableSprit;

	public List<Button> buttons;

	private List<Button> ExBtns = new List<Button>();

	private string TitleText = "";

	private IconListController iconListController;

	private List<string> selectedList = new List<string>();

	private void Start()
	{
		base.transform.Find("Panel/SaveBattleChoose/SaveBattleChoose/Checkmark").gameObject.SetActive(SharedData.Instance().isChooseBattle);
		EventTriggerListener.Get(base.transform.Find("Panel/SaveBattleChoose/SaveBattleChoose").gameObject).onClick = OnButtonClick;
		NormalSprite = Resources.Load("images/01-border/boder-duiwu-20220223-2", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-duiwu-20220223-1", typeof(Sprite)) as Sprite;
		UnInteractableSprit = Resources.Load("images/01-border/boder-20231228-01", typeof(Sprite)) as Sprite;
		InteractableSprit = Resources.Load("images/01-border/boder-20231228-highlihgt-01", typeof(Sprite)) as Sprite;
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		ChoosePanel = base.transform.Find("Panel").gameObject;
		ChooseCount = ChoosePanel.transform.Find("Title").gameObject;
		iconListController = ChoosePanel.transform.Find("IconList").GetComponent<IconListController>();
		EventTriggerListener.Get(ChoosePanel.transform.Find("ChooseOK").gameObject).onClick = OnButtonClick;
		buttons = ChoosePanel.transform.Find("CharacterArea").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		foreach (Button button2 in buttons)
		{
			EventTriggerListener.Get(button2.gameObject).onClick = OnButtonClick;
		}
		List<string> list = new List<string> { SharedData.Instance().playerid };
		list.AddRange(SharedData.Instance().FollowList);
		int i = 0;
		while (i < 6)
		{
			Button button = buttons.Find((Button x) => x.name == "TeammateState_" + (i + 1));
			if (i >= list.Count)
			{
				button.gameObject.SetActive(value: false);
			}
			else
			{
				string text = list[i];
				CharaData charaData = SharedData.Instance().GetCharaData(text);
				button.transform.Find("Name").GetComponent<Text>().text = charaData.Indexs_Name["Name"].stringValue;
				button.transform.Find("Level/Text").GetComponent<Text>().text = "Lv." + charaData.m_Level;
				gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(charaData.m_Level.ToString() ?? "");
				button.transform.Find("Exp").GetComponent<Text>().text = charaData.m_Exp + "/" + float.Parse(row.EXP, CultureInfo.InvariantCulture);
				button.transform.Find("States/ExpBar").GetComponent<Slider>().value = (float)charaData.m_Exp / float.Parse(row.EXP, CultureInfo.InvariantCulture);
				float battleValueByName = charaData.GetBattleValueByName("HP");
				button.transform.Find("States/HpBar").GetComponent<Slider>().value = charaData.m_Hp / battleValueByName;
				button.transform.Find("States/HpBar/HPValue").GetComponent<Text>().text = charaData.m_Hp + "/" + battleValueByName;
				float num = CommonFunc.saturate(charaData.GetBattleValueByName("Hurt") / 255f);
				float num2 = Mathf.Floor(charaData.GetBattleValueByName("MP"));
				float num3 = Mathf.Floor(num2 * (1f - num));
				button.transform.Find("States/MpBar/MpValue").GetComponent<Text>().text = charaData.m_Mp + "/" + num2;
				button.transform.Find("States/MpBar/CurMp").GetComponent<Image>().fillAmount = charaData.m_Mp / num2;
				button.transform.Find("States/MpBar/GrayMp").GetComponent<Image>().fillAmount = (num2 - num3) / num2;
				foreach (string item in new List<string> { "Poison", "Hurt", "Bleed", "Drunk", "Seal", "Mad", "Burn" })
				{
					if (charaData.GetBattleValueByName(item) > 0f)
					{
						button.transform.Find("AbnormalState/" + item).gameObject.SetActive(value: true);
					}
				}
				button.transform.Find("States/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(text);
				button.transform.Find("SelcetTeammate/IconMask/IconBG").gameObject.SetActive(value: true);
				Sprite tachieHead = CommonResourcesData.GetTachieHead(charaData.m_BattleIcon);
				if (tachieHead == null)
				{
					button.transform.Find("SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: false);
					button.transform.Find("SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
					button.transform.Find("SelcetTeammate/IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charaData);
				}
				else
				{
					button.transform.Find("SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: true);
					button.transform.Find("SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
					button.transform.Find("SelcetTeammate/IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
				}
				if (SharedData.Instance().PlayerSetting.ContainsKey("Player1"))
				{
					if (SharedData.Instance().PlayerSetting["Player1"].Equals(text))
					{
						button.GetComponent<Image>().sprite = SelectedSprite;
						button.name = "Team|" + text + "|1";
						ExBtns.Add(button);
						SelectedCount++;
						selectedList.Add(text);
						button.transform.Find("SelcetTeammate/Selected").gameObject.SetActive(value: true);
					}
					else
					{
						button.name = "Team|" + text + "|0";
					}
				}
				else if (SharedData.Instance().lastSelectBattleIdList.Contains(text) && !selectedList.Contains(text))
				{
					button.GetComponent<Image>().sprite = SelectedSprite;
					button.name = "Team|" + text + "|1";
					SelectedCount++;
					selectedList.Add(text);
					button.transform.Find("SelcetTeammate/Selected").gameObject.SetActive(value: true);
				}
				else
				{
					button.name = "Team|" + text + "|0";
				}
			}
			int num4 = i + 1;
			i = num4;
		}
		TitleText = CommonFunc.I18nGetLocalizedValue("选择上阵的角色");
		UpdateCount(SelectedCount);
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/CharacterArea").GetChild(0).gameObject);
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.ConfirmBattle.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/ChooseOK").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.ShowFullName.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/SaveBattleChoose/SaveBattleChoose").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	private void UpdateCount(int _count)
	{
		ChooseCount.GetComponentInChildren<Text>().text = TitleText + "    <color=#F3E898>" + _count + "/" + SharedData.Instance().BattleMemberMax + "</color>";
		if (_count <= 0)
		{
			ChoosePanel.transform.Find("ChooseOK").GetComponent<Button>().interactable = false;
			ChoosePanel.transform.Find("ChooseOK").GetComponent<Image>().sprite = UnInteractableSprit;
		}
		else
		{
			ChoosePanel.transform.Find("ChooseOK").GetComponent<Button>().interactable = true;
			ChoosePanel.transform.Find("ChooseOK").GetComponent<Image>().sprite = InteractableSprit;
		}
		iconListController.InitIconList(selectedList, showLevel: false);
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		string[] array = go.name.Split('|');
		if (array[0] == "Team")
		{
			if (!(array[2] == "0") || SelectedCount < SharedData.Instance().BattleMemberMax)
			{
				if (array[2] == "0")
				{
					go.GetComponent<Image>().sprite = SelectedSprite;
					go.GetComponentInChildren<Text>().color = SelectedColor;
					SelectedCount++;
					selectedList.Add(array[1]);
					go.transform.Find("SelcetTeammate/Selected").gameObject.SetActive(value: true);
					go.name = array[0] + "|" + array[1] + "|1";
				}
				if (array[2] == "1" && !ExBtns.Contains(go.GetComponent<Button>()))
				{
					go.GetComponent<Image>().sprite = NormalSprite;
					go.GetComponentInChildren<Text>().color = NormalColor;
					SelectedCount--;
					selectedList.Remove(array[1]);
					go.transform.Find("SelcetTeammate/Selected").gameObject.SetActive(value: false);
					go.name = array[0] + "|" + array[1] + "|0";
				}
				UpdateCount(SelectedCount);
			}
		}
		else if (array[0] == "ChooseOK")
		{
			List<string> list = new List<string>();
			foreach (Button button in buttons)
			{
				string[] array2 = button.name.Split('|');
				if (array2.Length >= 3 && array2[2] == "1")
				{
					list.Add(array2[1]);
				}
			}
			OnButtonClickChooseOK(list);
		}
		else if (array[0] == "SaveBattleChoose")
		{
			SharedData.Instance().isChooseBattle = !SharedData.Instance().isChooseBattle;
			base.transform.Find("Panel/SaveBattleChoose/SaveBattleChoose/Checkmark").gameObject.SetActive(SharedData.Instance().isChooseBattle);
		}
	}

	public static void OnButtonClickChooseOK(List<string> idList)
	{
		List<string> list = new List<string>();
		if (!SharedData.Instance().isRandomFight)
		{
			List<gang_b04Table.Row> list2 = CommonResourcesData.b04.FindAll_GID(MapController.enemygid[0]);
			if (list2 != null && list2.Count > 0)
			{
				foreach (gang_b04Table.Row item in list2)
				{
					if (!"1".Equals(item.Side))
					{
						list.Add(item.ID);
					}
				}
			}
			else
			{
				Debug.LogWarning(">>>> Can NOT find GID: " + MapController.enemygid[0]);
			}
			if (SharedData.Instance().PlayerSetting.ContainsKey("Player1") && !list.Contains("Player1"))
			{
				list.Add("Player1");
			}
		}
		string text = "";
		if (SharedData.Instance().b04BattleID == "70001" || SharedData.Instance().b04BattleID == "70020" || SharedData.Instance().b04BattleID == "70040")
		{
			text = "_" + SharedData.Instance().b04BattleID;
		}
		if (idList != SharedData.Instance().lastSelectBattleIdList)
		{
			SharedData.Instance().lastSelectBattleIdList.Clear();
		}
		int num = 1;
		foreach (string id in idList)
		{
			if (idList != SharedData.Instance().lastSelectBattleIdList)
			{
				SharedData.Instance().lastSelectBattleIdList.Add(id);
			}
			if (!SharedData.Instance().PlayerSetting.ContainsValue(id) && (SharedData.Instance().FollowList.Contains(id) || !(SharedData.Instance().playerid != id)))
			{
				string text2 = "Player" + num + text;
				while (list.Contains(text2))
				{
					num++;
					text2 = "Player" + num + text;
				}
				if (SharedData.Instance().PlayerSetting.ContainsKey(text2))
				{
					SharedData.Instance().PlayerSetting[text2] = id;
				}
				else
				{
					SharedData.Instance().PlayerSetting.Add(text2, id);
				}
				num++;
			}
		}
		SharedData.Instance().ASyncLoadScene(SharedData.Instance().BattleGround);
	}
}
