using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Starter1_1Controller : MonoBehaviour
{
	[SpineSkin("", "", true, false, false)]
	public string baseSkin = "base";

	private Skin characterSkin;

	private SkinType _subSkinType;

	private Transform _CharacterPortraitPanel;

	private Transform _CharacterIconPanel;

	private Transform _CustomControlPanel;

	private List<Button> _CustomControlBtns = new List<Button>();

	private Dictionary<string, Dictionary<string, List<string>>> _skinDict = new Dictionary<string, Dictionary<string, List<string>>>();

	private Dictionary<string, Dictionary<string, int>> _skinIndexDict = new Dictionary<string, Dictionary<string, int>>();

	private List<string> _bodyTypeList = new List<string>();

	private string currentBodyType = "";

	private gang_b01SkinTable.Row b01SkinRow;

	private gang_b01SkinTable.Row _tmpB01SkinRow;

	private Sprite _normalSprite;

	private Sprite _selectedSprite;

	private GameObject SelectedBtn;

	private PointerEventData pointerEventData;

	private bool isLoading;

	private void Start()
	{
		SharedData.Instance().InitSkin = false;
		_normalSprite = Resources.Load("images/01-border/boder-20231228-button-02", typeof(Sprite)) as Sprite;
		_selectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		if (!SharedData.Instance().isLoadedStart1_1)
		{
			SharedData.Instance().protagonistSkinDataNew = new ProtagonistSkinDataNew();
			SharedData.Instance().protagonistSkinDataNew.isCustom = true;
			if (SharedData.Instance().playerid.Equals("9001"))
			{
				SharedData.Instance().protagonistSkinDataNew.SkinType = SkinType.MaleNormal;
			}
			else
			{
				SharedData.Instance().protagonistSkinDataNew.SkinType = SkinType.FemaleNormal;
			}
		}
		_CharacterPortraitPanel = base.transform.Find("Panel/CharacterPortrait");
		_CharacterIconPanel = base.transform.Find("Panel/CharacterIcon");
		_CustomControlPanel = base.transform.Find("Panel/CustomControlPanel");
		Button[] componentsInChildren = base.transform.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		InitSkinDict();
		InitSkinType();
		bool isCustom = SharedData.Instance().protagonistSkinDataNew.isCustom;
		OnButtonClick(base.transform.Find("Panel/CustomBtn").gameObject);
		OnButtonClick(_CustomControlPanel.Find("SkinType").gameObject);
		UpdateCharacterSkin();
		if (!isCustom)
		{
			OnButtonClick(base.transform.Find("Panel/SpecificBtn").gameObject);
		}
	}

	private void Update()
	{
		if (EventSystem.current.currentSelectedGameObject != null && EventSystem.current.currentSelectedGameObject.transform.parent.name.Equals("CustomControlPanel"))
		{
			if (EventSystem.current.currentSelectedGameObject != null && SelectedBtn != EventSystem.current.currentSelectedGameObject)
			{
				OnButtonClick(EventSystem.current.currentSelectedGameObject);
				SelectedBtn = EventSystem.current.currentSelectedGameObject;
			}
			if (InputSystemCustom.Instance().UI.SelectSkinNext.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(SelectedBtn.transform.Find("+").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.SelectSkinPrev.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(SelectedBtn.transform.Find("-").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
		}
		else
		{
			SelectedBtn = null;
		}
		if (!InputDeviceDetector.instance.isMouseInput)
		{
			if (InputSystemCustom.Instance().UI.Starter1_1Confirm.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(base.transform.Find("Panel/Next").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(base.transform.Find("Panel/Return").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
		}
	}

	private void InitSkinDict()
	{
		int childCount = _CharacterPortraitPanel.childCount;
		int childCount2 = _CustomControlPanel.childCount;
		_bodyTypeList = new List<string>();
		for (int i = 0; i < childCount; i++)
		{
			_bodyTypeList.Add(_CharacterPortraitPanel.GetChild(i).name);
		}
		for (int j = 0; j < childCount; j++)
		{
			SkeletonGraphic component = _CharacterPortraitPanel.GetChild(j).GetComponent<SkeletonGraphic>();
			ExposedList<Skin> skins = component.Skeleton.Data.Skins;
			List<string> list = new List<string>();
			int count = component.Skeleton.Data.Skins.Count;
			for (int k = 0; k < count; k++)
			{
				list.Add(skins.Items[k].Name);
			}
			_skinDict.Add(component.name, new Dictionary<string, List<string>>());
			_skinIndexDict.Add(component.name, new Dictionary<string, int>());
			for (int l = 0; l < childCount2; l++)
			{
				Transform skinItem = _CustomControlPanel.GetChild(l);
				if (!skinItem.name.Equals("SkinType"))
				{
					List<string> value = list.FindAll((string x) => x.StartsWith(skinItem.name));
					_skinDict[component.name].Add(skinItem.name, value);
				}
				else
				{
					_skinDict[component.name].Add(skinItem.name, _bodyTypeList);
				}
				FieldInfo field = SharedData.Instance().protagonistSkinDataNew.GetType().GetField(skinItem.name);
				if (skinItem.name.Equals("SkinType"))
				{
					_skinIndexDict[component.name].Add(skinItem.name, (int)field.GetValue(SharedData.Instance().protagonistSkinDataNew));
					continue;
				}
				string text = field.GetValue(SharedData.Instance().protagonistSkinDataNew).ToString();
				if (!text.Equals(""))
				{
					_skinIndexDict[component.name].Add(skinItem.name, text[text.Length - 1] - 48);
				}
				else
				{
					_skinIndexDict[component.name].Add(skinItem.name, 0);
				}
			}
		}
	}

	private void InitSkinType()
	{
		_CharacterPortraitPanel.Find(SkinType.MaleNormal.ToString()).gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.MaleNormal));
		_CharacterPortraitPanel.Find(SkinType.MaleStrong.ToString()).gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.MaleStrong));
		_CharacterPortraitPanel.Find(SkinType.MaleFat.ToString()).gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.MaleFat));
		_CharacterPortraitPanel.Find(SkinType.FemaleNormal.ToString()).gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.FemaleNormal));
		_CharacterPortraitPanel.Find(SkinType.FemaleSpecial.ToString()).gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.FemaleSpecial));
		currentBodyType = SharedData.Instance().protagonistSkinDataNew.SkinType.ToString();
		b01SkinRow = CommonResourcesData.b01Skin.Find_ID(currentBodyType);
		foreach (KeyValuePair<string, Dictionary<string, int>> item in _skinIndexDict)
		{
			item.Value["SkinType"] = (int)SharedData.Instance().protagonistSkinDataNew.SkinType;
		}
	}

	private IEnumerator LoadNextScreen()
	{
		yield return null;
		while (!SharedData.Instance().InitSkin && SharedData.Instance().protagonistSkinDataNew.isCustom)
		{
			yield return null;
		}
		SharedData.Instance().ASyncLoadScene("Starter2");
	}

	private void FefreshProtagonistSkinData()
	{
		SharedData.Instance().isLoadedStart1_1 = true;
		FieldInfo[] fields = SharedData.Instance().protagonistSkinDataNew.GetType().GetFields();
		foreach (FieldInfo fieldInfo in fields)
		{
			if (!fieldInfo.Name.Equals("isCustom"))
			{
				if (fieldInfo.Name.Equals("SkinType"))
				{
					fieldInfo.SetValue(SharedData.Instance().protagonistSkinDataNew, _skinIndexDict[currentBodyType][fieldInfo.Name]);
				}
				else if (!_skinIndexDict[currentBodyType][fieldInfo.Name].Equals(0))
				{
					fieldInfo.SetValue(SharedData.Instance().protagonistSkinDataNew, fieldInfo.Name + "/" + fieldInfo.Name + _skinIndexDict[currentBodyType][fieldInfo.Name]);
				}
				else
				{
					fieldInfo.SetValue(SharedData.Instance().protagonistSkinDataNew, "");
				}
			}
		}
		SharedData.Instance().protagonistSkinB01SkinTable = _tmpB01SkinRow;
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || isLoading)
		{
			return;
		}
		MonoBehaviour.print("[ChangeSkin] Click button: " + go.name);
		if (go.name.Equals("Next"))
		{
			isLoading = true;
			EventSystem.current.SetSelectedGameObject(go);
			FefreshProtagonistSkinData();
			if (SharedData.Instance().protagonistSkinDataNew.isCustom)
			{
				Object.Instantiate(CommonResourcesData.ProtagonistSkin);
			}
			StartCoroutine(LoadNextScreen());
		}
		else if (go.name.Equals("Return"))
		{
			isLoading = true;
			EventSystem.current.SetSelectedGameObject(go);
			FefreshProtagonistSkinData();
			SharedData.Instance().ASyncLoadScene("Starter1");
		}
		else if (go.name.Equals("+") || go.name.Equals("-"))
		{
			MonoBehaviour.print("[ChangeSkin] Click button: " + go.transform.parent.name + " " + go.name);
			int num = _skinIndexDict[currentBodyType][go.transform.parent.name];
			int count = _skinDict[currentBodyType][go.transform.parent.name].Count;
			if (go.name.Equals("+"))
			{
				num = (num + 1) % (count + 1);
			}
			else if (go.name.Equals("-"))
			{
				num = (num - 1 + count + 1) % (count + 1);
			}
			if (go.transform.parent.name.Equals("SkinType"))
			{
				if (currentBodyType.Equals("MaleNormal") || currentBodyType.Equals("MaleStrong") || currentBodyType.Equals("MaleFat"))
				{
					if (num <= 0)
					{
						num = 3;
					}
					else if (num > 3)
					{
						num = 1;
					}
				}
				else if (currentBodyType.Equals("FemaleNormal") || currentBodyType.Equals("FemaleSpecial"))
				{
					switch (num)
					{
					case 3:
						num = 5;
						break;
					case 0:
						num = 4;
						break;
					}
				}
				SharedData.Instance().protagonistSkinDataNew.SkinType = (SkinType)num;
				InitSkinType();
			}
			foreach (KeyValuePair<string, Dictionary<string, int>> item in _skinIndexDict)
			{
				item.Value[go.transform.parent.name] = num;
			}
			UpdateCharacterSkin();
			OnButtonClick(go.transform.parent.gameObject);
		}
		else if (go.transform.parent.name.Equals("CustomControlPanel"))
		{
			EventSystem.current.SetSelectedGameObject(go);
			int childCount = _CustomControlPanel.childCount;
			for (int i = 0; i < childCount; i++)
			{
				_CustomControlPanel.GetChild(i).GetComponent<Image>().sprite = _normalSprite;
			}
			go.GetComponent<Image>().sprite = _selectedSprite;
		}
		else if (go.name.Equals("CustomBtn"))
		{
			EventSystem.current.SetSelectedGameObject(go);
			if (currentBodyType.Equals("MaleNormal") || currentBodyType.Equals("MaleFat") || currentBodyType.Equals("MaleStrong"))
			{
				base.transform.Find("Panel/CharacterPortrait_Specific_Male").gameObject.SetActive(value: false);
				base.transform.Find("Panel/CharacterIcon_Specific_Male").gameObject.SetActive(value: false);
			}
			else
			{
				base.transform.Find("Panel/CharacterPortrait_Specific_Female").gameObject.SetActive(value: false);
				base.transform.Find("Panel/CharacterIcon_Specific_Female").gameObject.SetActive(value: false);
			}
			base.transform.Find("Panel/CharacterPortrait").gameObject.SetActive(value: true);
			base.transform.Find("Panel/CharacterIcon").gameObject.SetActive(value: true);
			SharedData.Instance().protagonistSkinDataNew.isCustom = true;
			base.transform.Find("Panel/CustomBtn").GetComponent<Image>().sprite = _selectedSprite;
			base.transform.Find("Panel/SpecificBtn").GetComponent<Image>().sprite = _normalSprite;
			_CustomControlPanel.GetComponent<CanvasGroup>().interactable = true;
		}
		else if (go.name.Equals("SpecificBtn"))
		{
			EventSystem.current.SetSelectedGameObject(go);
			if (currentBodyType.Equals("MaleNormal") || currentBodyType.Equals("MaleFat") || currentBodyType.Equals("MaleStrong"))
			{
				base.transform.Find("Panel/CharacterPortrait_Specific_Male").gameObject.SetActive(value: true);
				base.transform.Find("Panel/CharacterIcon_Specific_Male").gameObject.SetActive(value: true);
			}
			else
			{
				base.transform.Find("Panel/CharacterPortrait_Specific_Female").gameObject.SetActive(value: true);
				base.transform.Find("Panel/CharacterIcon_Specific_Female").gameObject.SetActive(value: true);
			}
			base.transform.Find("Panel/CharacterPortrait").gameObject.SetActive(value: false);
			base.transform.Find("Panel/CharacterIcon").gameObject.SetActive(value: false);
			SharedData.Instance().protagonistSkinDataNew.isCustom = false;
			base.transform.Find("Panel/CustomBtn").GetComponent<Image>().sprite = _normalSprite;
			base.transform.Find("Panel/SpecificBtn").GetComponent<Image>().sprite = _selectedSprite;
			_CustomControlPanel.GetComponent<CanvasGroup>().interactable = false;
		}
	}

	private void UpdateCharacterSkin()
	{
		Skeleton skeleton = _CharacterPortraitPanel.Find(currentBodyType).GetComponent<SkeletonGraphic>().Skeleton;
		SkeletonData data = skeleton.Data;
		_tmpB01SkinRow = JsonUtility.FromJson<gang_b01SkinTable.Row>(JsonUtility.ToJson(b01SkinRow));
		characterSkin = new Skin("character-base");
		Skin skin = data.FindSkin(baseSkin);
		if (skin != null)
		{
			characterSkin.AddSkin(skin);
		}
		else
		{
			Debug.LogWarning("ChangeSkin can not Find Skin [" + baseSkin + "]");
		}
		FieldInfo[] fields = _tmpB01SkinRow.GetType().GetFields();
		foreach (KeyValuePair<string, int> item in _skinIndexDict[currentBodyType])
		{
			string text = "";
			if (item.Value.Equals(0))
			{
				text = CommonFunc.I18nGetLocalizedValue("I18N_ChangeForm_SkinType_" + item.Key) + "-" + CommonFunc.I18nGetLocalizedValue("I18N_ChangeForm_NUllSkin");
			}
			else
			{
				text = CommonFunc.I18nGetLocalizedValue("I18N_ChangeForm_SkinType_" + item.Key) + "-" + item.Value;
				skin = data.FindSkin(_skinDict[currentBodyType][item.Key][item.Value - 1]);
				if (skin != null)
				{
					characterSkin.AddSkin(skin);
				}
				else if (!item.Key.Equals("SkinType"))
				{
					Debug.LogWarning("ChangeSkin can not Find Skin [" + _skinDict[currentBodyType][item.Key][item.Value - 1] + "]");
				}
				string find = currentBodyType + "_" + _skinDict[currentBodyType][item.Key][item.Value - 1];
				gang_b01SkinTable.Row row = CommonResourcesData.b01Skin.Find_ID(find);
				if (row != null)
				{
					FieldInfo[] array = fields;
					foreach (FieldInfo fieldInfo in array)
					{
						if (fieldInfo.Name.Equals("ID") || fieldInfo.Name.Equals("Name") || fieldInfo.Name.Equals("Name_Id"))
						{
							continue;
						}
						FieldInfo field = row.GetType().GetField(fieldInfo.Name);
						string text2 = field.GetValue(row).ToString();
						if (!text2.Equals("") && !text2.Equals("0"))
						{
							string text3 = fieldInfo.GetValue(_tmpB01SkinRow).ToString();
							if ((text3.Equals("") && !text3.Equals("0")) || !text3.Equals(text2))
							{
								fieldInfo.SetValue(_tmpB01SkinRow, field.GetValue(row));
							}
						}
					}
				}
			}
			_CustomControlPanel.Find(item.Key + "/Text").GetComponent<Text>().text = text;
		}
		skeleton.SetSkin(characterSkin);
		skeleton.SetSlotsToSetupPose();
		SkeletonGraphic[] componentsInChildren = _CharacterIconPanel.GetComponentsInChildren<SkeletonGraphic>();
		foreach (SkeletonGraphic obj in componentsInChildren)
		{
			SkinCharacter.InitSkinCharacterUI(obj, _tmpB01SkinRow);
			obj.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
		}
	}
}
