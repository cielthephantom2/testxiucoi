using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CreateWGController : MonoBehaviour
{
	public Camera playerRenderCamera;

	[HideInInspector]
	public static EnhanceWuGongType enhanceWuGongType;

	private CreatStage _creatStage;

	private GameObject _player;

	[HideInInspector]
	public CharaData charaData;

	private Direction _direction = Direction.Left;

	private SkeletonAnimation[] _Animations;

	private int PerceptValue;

	private int starsLimit = 3;

	private int levelLimit = 9;

	private gang_b07Table.Row baseB07Row = new gang_b07Table.Row();

	private gang_b03Table.Row baseB03Row = new gang_b03Table.Row();

	private gang_b07Table.Row _b07Row = new gang_b07Table.Row();

	private gang_b03Table.Row _b03Row = new gang_b03Table.Row();

	private gang_b03Table.Row _b03TaritEffectRow;

	private string _wugongName = "";

	private Transform CreatePanel1;

	private Transform CreatePanel2;

	private Transform CreatePanel3;

	private Dictionary<string, SkillEffectData> _allEffectPrefabDict = new Dictionary<string, SkillEffectData>();

	private List<string> _effectPrefabList = new List<string>();

	private List<GameObject> _effectObjList = new List<GameObject>();

	private Sprite _normalSprite;

	private Sprite _selectedSprite;

	private Sprite _noAttackAreaSprite;

	private Sprite _selectAreaSprite;

	private Sprite _damageAreaSprite;

	private Sprite _attackAreaSprite;

	private List<gang_b12WugongTypeTable.Row> b12WugongSpecificList = new List<gang_b12WugongTypeTable.Row>();

	private List<Button> _wugongTypes;

	private List<Button> _wugongSpecificTypes;

	private List<Button> _attackAreaTypes;

	private string wugongType = "";

	private int wugongSpecificIndex = -1;

	private string wugongAttackAreaType = "";

	private int wugongEffectIndex;

	private string _effectSite = "0";

	private int _beatCount;

	private Dictionary<Vector3Int, GameObject> _gridDict = new Dictionary<Vector3Int, GameObject>();

	private InputField _InputField;

	private TraitNineGirdController _traitNineGirdController;

	private Transform _hoverWuGongPanel2;

	private Transform _hoverWuGongPanel3;

	private PointerEventData pointerEventData;

	private bool isPanel0EffectFinish = true;

	private bool isNeedFullTrait;

	private Transform ConfirmBtn;

	private Transform infoPanel;

	private Sprite _canNotForgeSprit;

	private Sprite _canForgeSprit;

	private bool isRenaming;

	private void Start()
	{
		if (SharedData.Instance().m_MapController != null)
		{
			SharedData.Instance().m_MapController.m_AudioSource.Pause();
		}
		SharedData.Instance().OpenPackagerFunction = PackagerFunction.PlayerPackage;
		InputDeviceDetector.instance.ClearJoyStack();
		enhanceWuGongType = EnhanceWuGongType.Create;
		Button[] componentsInChildren = base.transform.GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button button in componentsInChildren)
		{
			if (button.GetComponentInParent<TraitNineGirdController>() == null)
			{
				EventTriggerListener.Get(button.gameObject).onClick = OnButtonClick;
			}
		}
		CreatePanel1 = base.transform.Find("Panel1");
		CreatePanel2 = base.transform.Find("Panel2");
		CreatePanel3 = base.transform.Find("Panel3");
		infoPanel = base.transform.Find("Info");
		ConfirmBtn = CreatePanel2.Find("Confirm");
		SetCreateStage(CreatStage.stage1);
		InitPlayer();
		foreach (gang_b03_SkiillEffect_Table.Row row in CommonResourcesData.b03SkillEffect.GetRowList())
		{
			if (!_allEffectPrefabDict.ContainsKey(row.EffectName))
			{
				_allEffectPrefabDict.Add(row.EffectName, new SkillEffectData
				{
					Beat = row.Beat,
					Sound = row.Sound,
					Site = row.Site
				});
			}
		}
		foreach (gang_b03Table.Row row2 in CommonResourcesData.b03.GetRowList())
		{
			if (!_allEffectPrefabDict.ContainsKey(row2.Effect))
			{
				_allEffectPrefabDict.Add(row2.Effect, new SkillEffectData
				{
					Beat = row2.Beat,
					Sound = row2.Sound,
					Site = row2.Site
				});
			}
		}
		_effectPrefabList = _allEffectPrefabDict.Keys.ToList();
		_normalSprite = Resources.Load("images/01-border/Boder-20230206-Kongfu-01", typeof(Sprite)) as Sprite;
		_selectedSprite = Resources.Load("images/01-border/Boder-20230206-Kongfu-02", typeof(Sprite)) as Sprite;
		_noAttackAreaSprite = Resources.Load("images/table/CreatWuGongRange", typeof(Sprite)) as Sprite;
		_selectAreaSprite = Resources.Load("images/table/CreatWuGongRange1", typeof(Sprite)) as Sprite;
		_attackAreaSprite = Resources.Load("images/table/CreatWuGongRange2", typeof(Sprite)) as Sprite;
		_damageAreaSprite = Resources.Load("images/table/CreatWuGongRange3", typeof(Sprite)) as Sprite;
		_canNotForgeSprit = Resources.Load("images/01-border/boder-20231228-06", typeof(Sprite)) as Sprite;
		_canForgeSprit = Resources.Load("images/01-border/boder-20231228-highlihgt-01", typeof(Sprite)) as Sprite;
		for (int j = -4; j <= 4; j++)
		{
			for (int k = -4; k <= 4; k++)
			{
				Vector3Int key = new Vector3Int(k, j);
				GameObject value = playerRenderCamera.transform.Find($"BG-kongfu/Grid/Row ({j + 5})/Table ({k + 5})").gameObject;
				_gridDict.Add(key, value);
			}
		}
		_wugongTypes = CreatePanel1.Find("SelectWuGongType/WuGongType").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		_wugongSpecificTypes = CreatePanel1.Find("SelectWuGongType/WuGongSpecificType").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		_attackAreaTypes = CreatePanel1.Find("SelectAttackArea/AttackAreaType").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		_hoverWuGongPanel2 = CreatePanel2.Find("HoverWuGong");
		_traitNineGirdController = CreatePanel2.Find("TraitNine/TraitNineGrid").GetComponent<TraitNineGirdController>();
		_traitNineGirdController.createWgController = this;
		_InputField = CreatePanel2.Find("HoverWuGong/Name/InputField").GetComponent<InputField>();
		if (GameDataManager.Instance().configdata.language == "English")
		{
			_InputField.characterLimit = 30;
		}
		else
		{
			_InputField.characterLimit = 15;
		}
		_InputField.GetComponent<InputField>().onEndEdit.AddListener(delegate
		{
			StartCoroutine(SetSelectedGameObjectNextFrame());
		});
		_hoverWuGongPanel3 = CreatePanel3.Find("HoverWuGong");
		OnButtonClick(CreatePanel1.Find("SelectWuGongType/WuGongType/WuGongType|Sword|101").gameObject);
		EventSystem.current.SetSelectedGameObject(CreatePanel1.Find("SelectWuGongType/WuGongType/WuGongType|Sword|101").gameObject);
		SharedData.Instance().createWgController = this;
	}

	private IEnumerator SetSelectedGameObjectNextFrame()
	{
		yield return null;
		if (EventSystem.current.currentSelectedGameObject != CreatePanel2.Find("HoverWuGong/Name/Rename").gameObject)
		{
			EventSystem.current.SetSelectedGameObject(CreatePanel2.Find("HoverWuGong/Name/Rename").gameObject);
		}
	}

	private void Update()
	{
		if (infoPanel.gameObject.activeSelf && (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame()))
		{
			StartCoroutine(DelayControllInfoPanel(active: false));
		}
		else
		{
			if (!isPanel0EffectFinish)
			{
				return;
			}
			if (_InputField.GetComponent<InputField>().isFocused && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
			{
				_InputField.GetComponent<InputField>().DeactivateInputField();
				EventSystem.current.SetSelectedGameObject(CreatePanel2.Find("HoverWuGong/Name/Rename").gameObject);
			}
			else if (InputSystemCustom.Instance().UI.SelectWugongEffectNext.WasReleasedThisFrame() && !_InputField.gameObject.activeInHierarchy)
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(CreatePanel1.Find("SelectEffect/NextEffect").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.SelectWugongEffectPrev.WasReleasedThisFrame() && !_InputField.gameObject.activeInHierarchy)
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(CreatePanel1.Find("SelectEffect/PrevEffect").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.ConfirmCreateWugong.WasReleasedThisFrame() && !_InputField.gameObject.activeInHierarchy)
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				if (_creatStage.Equals(CreatStage.stage1))
				{
					ExecuteEvents.Execute(CreatePanel1.Find("Next").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
				}
				else if (_creatStage.Equals(CreatStage.stage2))
				{
					ExecuteEvents.Execute(CreatePanel2.Find("Confirm").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
				}
				else if (_creatStage.Equals(CreatStage.stage3))
				{
					ExecuteEvents.Execute(CreatePanel3.Find("ConfirmDone").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
				}
			}
			else if (InputSystemCustom.Instance().UI.BackCreateWugong.WasReleasedThisFrame() && !_InputField.gameObject.activeInHierarchy)
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(CreatePanel2.Find("Back").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && SharedData.Instance().m_TraitPackageController.isOpen.Equals(obj: false) && !_InputField.gameObject.activeInHierarchy)
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(base.transform.Find("TopBanner/Return").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.Rename.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(CreatePanel2.Find("HoverWuGong/Name/Rename").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
	}

	private IEnumerator DelayControllInfoPanel(bool active)
	{
		yield return null;
		base.transform.GetComponent<CanvasGroup>().interactable = !active;
		infoPanel.gameObject.SetActive(active);
	}

	private void SetCreateStage(CreatStage creatStage)
	{
		_creatStage = creatStage;
		CreatePanel1.gameObject.SetActive(_creatStage.Equals(CreatStage.stage1));
		CreatePanel2.gameObject.SetActive(_creatStage.Equals(CreatStage.stage2));
		CreatePanel3.gameObject.SetActive(_creatStage.Equals(CreatStage.stage3));
	}

	private void InitPlayer()
	{
		charaData = SharedData.Instance().CurrentCharaData;
		PerceptValue = (int)charaData.GetFieldValueByName("Percept");
		starsLimit = 3 + PerceptValue / 100;
		_player = SkinCharacter.InitSkinCharacter(charaData);
		_Animations = _player.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		_player.transform.SetParent(playerRenderCamera.transform);
		_player.transform.localPosition = new Vector3(0f, 0f, 30f);
		_player.transform.localScale = Vector3.one * 0.022f;
		Face(_direction);
		PlayAnimation(Aniname.aniname_stand);
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || !isPanel0EffectFinish || infoPanel.gameObject.activeSelf)
		{
			return;
		}
		MonoBehaviour.print("[CreateWuGong] Click button: " + go.name);
		string[] array = go.name.Split('|');
		if (array[0].Equals("Return"))
		{
			ExitScene();
		}
		else if (array[0].Equals("WuGongType"))
		{
			if (array[2].Equals(wugongType))
			{
				return;
			}
			wugongType = array[2];
			foreach (Button wugongType in _wugongTypes)
			{
				wugongType.GetComponent<Image>().sprite = _normalSprite;
			}
			go.GetComponent<Image>().sprite = _selectedSprite;
			InitWuGongSpecificType();
			ShowWugongEffect();
		}
		else if (array[0].Equals("WuGongSpecificType"))
		{
			wugongSpecificIndex = int.Parse(array[1]) - 1;
			foreach (Button wugongSpecificType in _wugongSpecificTypes)
			{
				wugongSpecificType.GetComponent<Image>().sprite = _normalSprite;
			}
			go.GetComponent<Image>().sprite = _selectedSprite;
			ShowWugongEffect();
		}
		else if (go.transform.parent.name.Equals("AttackAreaType"))
		{
			if (go.name.Equals(wugongAttackAreaType))
			{
				return;
			}
			foreach (Button attackAreaType in _attackAreaTypes)
			{
				attackAreaType.GetComponent<Image>().sprite = _normalSprite;
			}
			go.GetComponent<Image>().sprite = _selectedSprite;
			wugongAttackAreaType = go.name;
			ShowWugongEffect();
		}
		else if (go.transform.parent.name.Equals("SelectEffect"))
		{
			if (go.name.Equals("PrevEffect"))
			{
				wugongEffectIndex--;
				wugongEffectIndex = ((wugongEffectIndex < 0) ? (_effectPrefabList.Count - 1) : wugongEffectIndex);
			}
			else if (go.name.Equals("NextEffect"))
			{
				wugongEffectIndex++;
				wugongEffectIndex = ((wugongEffectIndex < _effectPrefabList.Count) ? wugongEffectIndex : 0);
			}
			ShowWugongEffect(reClaB03: false);
		}
		else if (go.name.Equals("Next"))
		{
			InputDeviceDetector.instance.ClearJoyStack();
			InputDeviceDetector.instance.PushJoyStack();
			SetCreateStage(CreatStage.stage2);
			EventSystem.current.SetSelectedGameObject(CreatePanel2.Find("TraitNine/TraitNineGrid/Trait|2/Btn").gameObject);
			_b03TaritEffectRow = null;
			RefreshTraitEffect();
		}
		else if (go.name.Equals("Back"))
		{
			SetCreateStage(CreatStage.stage1);
			for (int i = 0; i <= 9; i++)
			{
				_traitNineGirdController.TraitDict[i.ToString()] = "";
			}
			_traitNineGirdController.RefreshTraitIcon(new List<string>());
			InputDeviceDetector.instance.ResetJoyCurce();
		}
		else if (go.name.Equals("Confirm"))
		{
			if (go.GetComponent<Image>().sprite != _canForgeSprit)
			{
				StartCoroutine(DelayControllInfoPanel(active: true));
				infoPanel.transform.Find("Banner1/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_CreateWugong_Cant_Info");
				return;
			}
			isPanel0EffectFinish = false;
			Transform panel0 = base.transform.Find("Panel0");
			panel0.gameObject.SetActive(value: true);
			SkeletonGraphic componentInChildren = panel0.GetComponentInChildren<SkeletonGraphic>();
			componentInChildren.AnimationState.SetAnimation(0, "animation", loop: false);
			componentInChildren.AnimationState.Complete += delegate
			{
				panel0.gameObject.SetActive(value: false);
			};
			DOVirtual.DelayedCall(0f, delegate
			{
				SetCreateStage(CreatStage.stage3);
				CanvasGroup component = CreatePanel3.GetComponent<CanvasGroup>();
				component.alpha = 0f;
				component.DOFade(1f, 0f);
				string text = Guid.NewGuid().ToString();
				_b03TaritEffectRow.ID = "MB03_" + _b03TaritEffectRow.ID + "_" + text;
				_b07Row.Relateid = _b03TaritEffectRow.ID;
				_b07Row.ID = _b03TaritEffectRow.ID;
				_b03Row = _b03TaritEffectRow;
				KongFuData kongFuData = new KongFuData
				{
					kf = _b03TaritEffectRow,
					lv = int.Parse(_b03TaritEffectRow.LV),
					exp = 0f,
					proficiency = 0
				};
				if (!_wugongName.Equals(""))
				{
					kongFuData.kf.Name = _wugongName;
					kongFuData.kf.Name_EN = _wugongName;
				}
				SkillHoverShowInfo.SetHoverWugongItem(null, kongFuData, CreatePanel3.Find("HoverWuGong"));
				isPanel0EffectFinish = true;
			});
		}
		else if (go.name.Equals("ConfirmDone"))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1033");
			if (_b03Row.Star.Equals("10"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1034");
			}
			if (_wugongName.Equals(""))
			{
				_wugongName = _b07Row.Name_Trans;
			}
			_b07Row.Name = _wugongName;
			_b07Row.Name_EN = _wugongName;
			_b03Row.Name = _wugongName;
			_b03Row.Name_EN = _wugongName;
			_b07Row.note = string.Format(_b07Row.note, charaData.Indexs_Name["Name"].stringValue, _wugongName);
			_b07Row.note_EN = string.Format(_b07Row.note_EN, charaData.Indexs_Name["Name"].stringValue, _wugongName);
			CommonResourcesData.b07.GetRowList().Add(_b07Row);
			CommonResourcesData.b07append.Add(_b07Row);
			CommonResourcesData.b03.GetRowList().Add(_b03Row);
			CommonResourcesData.b03append.Add(_b03Row);
			SharedData.Instance().PackageAdd(_b07Row.ID, 1);
			SetCreateStage(CreatStage.stage1);
			_wugongName = "";
			this.wugongType = "";
			wugongSpecificIndex = -1;
			wugongAttackAreaType = "";
			wugongEffectIndex = 0;
			InputDeviceDetector.instance.ClearJoyStack();
			EventSystem.current.SetSelectedGameObject(CreatePanel1.Find("SelectWuGongType/WuGongType/WuGongType|Sword|101").gameObject);
			OnButtonClick(CreatePanel1.Find("SelectWuGongType/WuGongType/WuGongType|Sword|101").gameObject);
		}
		else if (go.name.Equals("Rename") && !isRenaming)
		{
			if (_InputField.gameObject.gameObject.activeInHierarchy)
			{
				isRenaming = true;
				CommonFunc.CheckSensitiveWords(_InputField.text, OnCheckSensitiveWordsCompleted);
			}
			else
			{
				_InputField.gameObject.SetActive(value: true);
				EventSystem.current.SetSelectedGameObject(_InputField.gameObject);
				go.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_OK");
			}
		}
	}

	private void OnCheckSensitiveWordsCompleted(bool result)
	{
		isRenaming = false;
		if (!result)
		{
			_InputField.gameObject.SetActive(value: false);
			_hoverWuGongPanel2.Find("Name/Name").GetComponent<Text>().text = _InputField.text;
			_wugongName = _InputField.text;
			_b07Row.Name = _InputField.text;
			_b07Row.Name_EN = _InputField.text;
			_b03TaritEffectRow.Name = _InputField.text;
			_b03TaritEffectRow.Name_EN = _InputField.text;
			_hoverWuGongPanel2.transform.Find("Name/Rename").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Rename");
		}
		else
		{
			_InputField.text = _hoverWuGongPanel2.Find("Name/Name").GetComponent<Text>().text;
		}
	}

	private void InitWuGongSpecificType()
	{
		for (int i = 1; i <= 9; i++)
		{
			CreatePanel1.Find("SelectWuGongType/WuGongSpecificType/WuGongSpecificType|" + i + "/Text").GetComponent<Text>().text = "";
		}
		b12WugongSpecificList = CommonResourcesData.b12WugongType.FindAll_Style(wugongType);
		for (int j = 1; j <= b12WugongSpecificList.Count; j++)
		{
			CreatePanel1.Find("SelectWuGongType/WuGongSpecificType/WuGongSpecificType|" + j + "/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue(b12WugongSpecificList[j - 1].Name);
		}
		wugongSpecificIndex = 0;
		foreach (Button wugongSpecificType in _wugongSpecificTypes)
		{
			wugongSpecificType.GetComponent<Image>().sprite = _normalSprite;
		}
		_wugongSpecificTypes.Find((Button x) => x.name.Equals("WuGongSpecificType|1")).GetComponent<Image>().sprite = _selectedSprite;
		InitWugongAttackAreaType();
	}

	private void InitWugongAttackAreaType()
	{
		gang_b12WugongTypeTable.Row obj = b12WugongSpecificList[wugongSpecificIndex];
		List<string> obj2 = new List<string>
		{
			"A01", "A02", "A03", "A04", "A05", "A06", "A07", "B01", "B02", "B03",
			"B04", "B05", "C01", "C02", "C03", "C04", "D01"
		};
		Type typeFromHandle = typeof(gang_b12WugongTypeTable.Row);
		string text = "";
		bool flag = false;
		foreach (string item in obj2)
		{
			string text2 = typeFromHandle.GetField(item).GetValue(obj).ToString();
			CreatePanel1.Find("SelectAttackArea/AttackAreaType/" + item).gameObject.SetActive(text2.Equals("1"));
			if (text.Equals("") && text2.Equals("1"))
			{
				text = item;
			}
			if (text2.Equals("1") && item.Equals(wugongAttackAreaType))
			{
				flag = true;
			}
		}
		if (!flag)
		{
			wugongAttackAreaType = text;
		}
		foreach (Button attackAreaType in _attackAreaTypes)
		{
			attackAreaType.GetComponent<Image>().sprite = _normalSprite;
		}
		_attackAreaTypes.Find((Button x) => x.name.Equals(wugongAttackAreaType)).GetComponent<Image>().sprite = _selectedSprite;
	}

	private void CalWugongEffectList()
	{
		wugongEffectIndex = 0;
		_effectPrefabList = _allEffectPrefabDict.Keys.ToList();
	}

	private void ShowWugongEffect(bool reClaB03 = true)
	{
		CreatePanel1.Find("SelectEffect/SelectEffectTitle/Value").GetComponent<Text>().text = "";
		foreach (GameObject effectObj in _effectObjList)
		{
			UnityEngine.Object.DestroyImmediate(effectObj);
		}
		_effectObjList.Clear();
		foreach (KeyValuePair<Vector3Int, GameObject> item in _gridDict)
		{
			item.Value.GetComponent<SpriteRenderer>().sprite = _noAttackAreaSprite;
		}
		PlayAnimation(Aniname.aniname_stand);
		if (reClaB03 && !ClaB03Row())
		{
			return;
		}
		switch (wugongType)
		{
		case "101":
			PlayAnimation(Aniname.aniname_B01_attack_sword);
			break;
		case "201":
			PlayAnimation(Aniname.aniname_B02_attack_knife);
			break;
		case "301":
			PlayAnimation(Aniname.aniname_B03_attack_stick);
			break;
		case "401":
		case "501":
		case "601":
		case "701":
		case "801":
		case "1001":
			PlayAnimation(Aniname.aniname_B04_attack_hand);
			break;
		}
		string[] type = (_b03Row.ID + "|" + _b03Row.Attckstyle + "|" + levelLimit + "|MP-GOOD").Split('|');
		Dictionary<Vector3Int, int> dictionary = new Dictionary<Vector3Int, int>();
		Dictionary<Vector3Int, int> dictionary2 = new Dictionary<Vector3Int, int>();
		Vector3Int zero = Vector3Int.zero;
		if (_b03Row.Attckstyle.StartsWith("B|"))
		{
			zero = Vector3Int.zero;
			dictionary = AttackData.GetRange2ByAttackType(type, Vector3Int.zero, 0, Vector3Int.zero);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		else if (_b03Row.Attckstyle.StartsWith("A|07"))
		{
			zero = new Vector3Int(4, 0, 0);
			dictionary = AttackData.GetRange1ByAttackType(type, Vector3Int.zero, null, _b03Row);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		else if (_b03Row.Attckstyle.StartsWith("C|01"))
		{
			zero = new Vector3Int(1, -1, 0);
			dictionary = AttackData.GetRange1ByAttackType(type, Vector3Int.zero, null, _b03Row);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		else if (_b03Row.Attckstyle.StartsWith("C|02"))
		{
			zero = new Vector3Int(1, -1, 0);
			zero = zero;
			dictionary = AttackData.GetRange1ByAttackType(type, Vector3Int.zero, null, _b03Row);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		else if (_b03Row.Attckstyle.StartsWith("C|03"))
		{
			zero = new Vector3Int(2, -2, 0);
			dictionary = AttackData.GetRange1ByAttackType(type, Vector3Int.zero, null, _b03Row);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		else if (_b03Row.Attckstyle.StartsWith("D|01"))
		{
			zero = new Vector3Int(4, 0, 0);
			dictionary = AttackData.GetRange1ByAttackType(type, Vector3Int.zero, null, _b03Row);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		else
		{
			zero = new Vector3Int(1, 0, 0);
			dictionary = AttackData.GetRange1ByAttackType(type, Vector3Int.zero, null, _b03Row);
			dictionary2 = AttackData.GetRange2ByAttackType(type, zero, 6, Vector3Int.zero, _b03Row);
		}
		foreach (KeyValuePair<Vector3Int, GameObject> item2 in _gridDict)
		{
			if (dictionary.ContainsKey(item2.Key))
			{
				item2.Value.GetComponent<SpriteRenderer>().sprite = _selectAreaSprite;
			}
		}
		CreatePanel1.Find("SelectEffect/SelectEffectTitle/Value").GetComponent<Text>().text = _effectPrefabList[wugongEffectIndex];
		gang_b03Table.Row row = CommonResourcesData.b03.Find_Effect(_effectPrefabList[wugongEffectIndex]);
		if (row != null)
		{
			_effectSite = row.Site;
		}
		Quaternion rotation = Quaternion.Euler(0f, 0f, 0f);
		Vector3 localScale = new Vector3(0.2f, 0.2f, 1f);
		if (_effectSite.Equals("1"))
		{
			switch (_direction)
			{
			case Direction.Up:
				rotation = Quaternion.Euler(0f, 0f, 90f);
				break;
			case Direction.Down:
				rotation = Quaternion.Euler(0f, 0f, -90f);
				break;
			case Direction.Left:
				rotation = Quaternion.Euler(0f, 0f, 0f);
				break;
			case Direction.Right:
				rotation = Quaternion.Euler(0f, 0f, 0f);
				localScale = new Vector3(-0.2f, 0.2f, 1f);
				break;
			}
		}
		foreach (KeyValuePair<Vector3Int, int> item3 in dictionary2)
		{
			if (_gridDict.ContainsKey(item3.Key))
			{
				GameObject gameObject = UnityEngine.Object.Instantiate(Resources.Load<GameObject>("Prefabs/Effect/Skills/" + _effectPrefabList[wugongEffectIndex]), _gridDict[item3.Key].transform);
				_gridDict[item3.Key].GetComponent<SpriteRenderer>().sprite = _damageAreaSprite;
				gameObject.transform.localScale = localScale;
				gameObject.transform.rotation = rotation;
				gameObject.GetComponent<EffectController>().loopRun = true;
				_effectObjList.Add(gameObject);
			}
		}
		_b03Row.Effect = _effectPrefabList[wugongEffectIndex];
		_b03Row.Beat = _allEffectPrefabDict[_b03Row.Effect].Beat;
		_b03Row.Sound = _allEffectPrefabDict[_b03Row.Effect].Sound;
		_b03Row.Site = _allEffectPrefabDict[_b03Row.Effect].Site;
		_gridDict[zero].GetComponent<SpriteRenderer>().sprite = _attackAreaSprite;
	}

	private bool ClaB03Row()
	{
		if (wugongType.Equals("") || wugongSpecificIndex >= b12WugongSpecificList.Count || wugongAttackAreaType.Equals(""))
		{
			CreatePanel1.Find("Next").GetComponent<Button>().interactable = false;
			return false;
		}
		CreatePanel1.Find("Next").GetComponent<Button>().interactable = true;
		baseB07Row = CommonResourcesData.b07.Find_ID("Create" + wugongType);
		baseB03Row = CommonResourcesData.b03.Find_ID("Create" + wugongType);
		_b07Row = JsonUtility.FromJson<gang_b07Table.Row>(JsonUtility.ToJson(baseB07Row));
		_b03Row = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(baseB03Row));
		_b03Row.Star = starsLimit.ToString();
		_b03Row.LV = levelLimit.ToString();
		gang_b12WugongStarLimit.Row row = new gang_b12WugongStarLimit.Row();
		gang_b12WugongStarLimit.Row row2 = new gang_b12WugongStarLimit.Row();
		foreach (gang_b12WugongStarLimit.Row row5 in CommonResourcesData.b12WugongStarLimit.GetRowList())
		{
			if ((float)PerceptValue >= float.Parse(row5.Percept, CultureInfo.InvariantCulture))
			{
				row = row5;
				continue;
			}
			break;
		}
		foreach (gang_b12WugongStarLimit.Row row6 in CommonResourcesData.b12WugongStarLimit.GetRowList())
		{
			if (float.Parse(_b03Row.Star, CultureInfo.InvariantCulture) >= float.Parse(row6.Star, CultureInfo.InvariantCulture))
			{
				row2 = row6;
				continue;
			}
			break;
		}
		_b03Row.Damage = row.Damage;
		_b03Row.Expend = row.Expend;
		_b03Row.Damageadd = row2.Damageadd;
		_b03Row.Expendadd = row2.Expendadd;
		gang_b12WugongTypeTable.Row row3 = b12WugongSpecificList[wugongSpecificIndex];
		_b03Row.Limit1 = row3.Limit1 + "|" + row.LimitBasicSkill;
		_b03Row.Limit2 = row3.Limit2 + "|" + row.LimitBasicAttr;
		_b03Row.Attckstyle = wugongAttackAreaType[0] + "|" + wugongAttackAreaType[1] + wugongAttackAreaType[2] + "|1";
		gang_b12WugongTypeAttackArea.Row row4 = CommonResourcesData.b12WugongTypeAttackArea.Find_AttackStyle(wugongAttackAreaType);
		_b03Row.Area = row4.Area;
		_b03Row.Range = row4.Range;
		_b03Row.Space = row4.Space;
		_b03Row.Effect = _effectPrefabList[wugongEffectIndex];
		_b03Row.Beat = _allEffectPrefabDict[_b03Row.Effect].Beat;
		_b03Row.Sound = _allEffectPrefabDict[_b03Row.Effect].Sound;
		_b03Row.Site = _allEffectPrefabDict[_b03Row.Effect].Site;
		return true;
	}

	public gang_b03Table.Row RefreshTraitEffect()
	{
		gang_b03Table.Row row = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(_b03Row));
		gang_b03Table.Row originB03Row = row;
		if (_b03TaritEffectRow != null)
		{
			originB03Row = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(_b03TaritEffectRow));
		}
		List<string> traitList = _traitNineGirdController.TraitDict.Values.ToList();
		_b03TaritEffectRow = RefreshTraitEffectBasic(row, traitList, b12WugongSpecificList[wugongSpecificIndex]);
		KongFuData kongFuData = new KongFuData
		{
			kf = _b03TaritEffectRow,
			lv = int.Parse(_b03TaritEffectRow.LV),
			exp = 0f,
			proficiency = 0
		};
		if (!_wugongName.Equals(""))
		{
			kongFuData.kf.Name = _wugongName;
			kongFuData.kf.Name_EN = _wugongName;
		}
		SkillHoverShowInfo.SetHoverWugongItem(null, kongFuData, CreatePanel2.Find("HoverWuGong"), showCharacterIcon: false, originB03Row);
		bool flag = true;
		foreach (KeyValuePair<string, string> item in _traitNineGirdController.TraitDict)
		{
			if (item.Value.Equals(""))
			{
				flag = false;
				break;
			}
		}
		if (!flag && isNeedFullTrait)
		{
			ConfirmBtn.GetComponent<Image>().sprite = _canNotForgeSprit;
		}
		else
		{
			ConfirmBtn.GetComponent<Image>().sprite = _canForgeSprit;
		}
		return _b03TaritEffectRow;
	}

	public static gang_b03Table.Row RefreshTraitEffectBasic(gang_b03Table.Row tmpB03Row, List<string> traitList, gang_b12WugongTypeTable.Row b12WugongTypeRow = null)
	{
		string star = tmpB03Row.Star;
		foreach (string trait in traitList)
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(trait);
			if (row == null)
			{
				continue;
			}
			gang_b12Table.Row row2 = null;
			row2 = ((!enhanceWuGongType.Equals(EnhanceWuGongType.Create)) ? CommonResourcesData.b12.Find_ID(row.breaktype) : CommonResourcesData.b12.Find_ID(row.createType));
			if (row2 == null)
			{
				continue;
			}
			List<string> list = new List<string> { row2.add1, row2.add2 };
			List<string> list2 = new List<string> { row2.attribute1, row2.attribute2 };
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].Equals("0") || list[i].Equals("1"))
				{
					continue;
				}
				string text = list[i];
				string text2 = list2[i];
				Type type = tmpB03Row.GetType();
				FieldInfo fieldInfo = null;
				switch (text)
				{
				case "Star":
				{
					int num5 = int.Parse(tmpB03Row.Star);
					int num6 = int.Parse(tmpB03Row.Star) + int.Parse(text2);
					num6 = ((num6 > 10) ? 10 : num6);
					tmpB03Row.Star = num6.ToString();
					gang_b12WugongStarLimit.Row row4 = null;
					gang_b12WugongStarLimit.Row row5 = new gang_b12WugongStarLimit.Row();
					foreach (gang_b12WugongStarLimit.Row row6 in CommonResourcesData.b12WugongStarLimit.GetRowList())
					{
						if (num5 >= int.Parse(row6.Star))
						{
							row4 = row6;
							continue;
						}
						break;
					}
					foreach (gang_b12WugongStarLimit.Row row7 in CommonResourcesData.b12WugongStarLimit.GetRowList())
					{
						if (num6 >= int.Parse(row7.Star))
						{
							row5 = row7;
							continue;
						}
						break;
					}
					if (!tmpB03Row.Damageadd.Equals("0"))
					{
						string damageadd = row5.Damageadd;
						if (row4 != null)
						{
							damageadd = (int.Parse(tmpB03Row.Damageadd) + (int.Parse(row5.Damageadd) - int.Parse(row4.Damageadd))).ToString();
						}
						tmpB03Row.Damageadd = damageadd;
					}
					string expendadd = row5.Expendadd;
					if (row4 != null)
					{
						expendadd = (int.Parse(tmpB03Row.Expendadd) + (int.Parse(row5.Expendadd) - int.Parse(row4.Expendadd))).ToString();
					}
					tmpB03Row.Expendadd = expendadd;
					break;
				}
				case "Origin":
					tmpB03Row.Origin = text2;
					break;
				case "LV":
				case "Area":
				case "Range":
				case "Space":
				case "Damage":
				case "Damageadd":
				case "Expendadd":
				case "Decreaserate":
				case "Crit":
				case "Critadd":
				case "Crit1":
				case "Crit1add":
				case "Combo":
				case "Comboadd":
				{
					fieldInfo = type.GetField(text);
					float num3 = float.Parse(fieldInfo.GetValue(tmpB03Row).ToString(), CultureInfo.InvariantCulture);
					float num4 = float.Parse(text2, CultureInfo.InvariantCulture);
					fieldInfo.SetValue(tmpB03Row, (num3 + num4).ToString());
					break;
				}
				case "Expend":
				{
					fieldInfo = type.GetField(text);
					float num3 = float.Parse(fieldInfo.GetValue(tmpB03Row).ToString(), CultureInfo.InvariantCulture);
					float num4 = float.Parse(text2, CultureInfo.InvariantCulture);
					fieldInfo.SetValue(tmpB03Row, ((int)(num3 * (1f - num4))).ToString());
					break;
				}
				case "Limit":
				{
					int num2 = int.Parse(star) + int.Parse(text2);
					gang_b12WugongStarLimit.Row row3 = CommonResourcesData.b12WugongStarLimit.Find_Star(((num2 >= 1) ? num2 : 0).ToString());
					if (b12WugongTypeRow != null)
					{
						tmpB03Row.Limit1 = b12WugongTypeRow.Limit1 + "|" + row3.LimitBasicSkill;
						tmpB03Row.Limit2 = b12WugongTypeRow.Limit2 + "|" + row3.LimitBasicAttr;
						break;
					}
					List<string> list3 = new List<string> { "STR", "AGI", "BON", "WIL", "LER", "MOR" };
					List<string> list4 = new List<string>
					{
						"Sword", "Knife", "Stick", "Hand", "Finger", "Special", "YinYang", "Melody", "Medical", "Darts",
						"Wineart", "Steal", "Forge", "Percept"
					};
					List<string> list5 = new List<string> { "HP", "MP" };
					List<string> list6 = new List<string> { "ATK", "DEF", "SP" };
					if (!tmpB03Row.Limit1.Equals("0"))
					{
						string[] array3 = tmpB03Row.Limit1.Split('|');
						if (!array3[0].Equals('@') && array3[1] != "2")
						{
							if (list3.Contains(array3[0]))
							{
								tmpB03Row.Limit1 = array3[0] + "|" + array3[1] + "|" + row3.LimitBasicAttr;
							}
							else if (list4.Contains(array3[0]))
							{
								tmpB03Row.Limit1 = array3[0] + "|" + array3[1] + "|" + row3.LimitBasicSkill;
							}
							else if (list5.Contains(array3[0]))
							{
								tmpB03Row.Limit1 = array3[0] + "|" + array3[1] + "|" + row3.LimitHPMP;
							}
							else if (list6.Contains(array3[0]))
							{
								tmpB03Row.Limit1 = array3[0] + "|" + array3[1] + "|" + row3.LimitATKDEFSP;
							}
						}
					}
					if (tmpB03Row.Limit2.Equals("0"))
					{
						break;
					}
					string[] array4 = tmpB03Row.Limit2.Split('|');
					if (!array4[0].Equals('@') && array4[1] != "2")
					{
						if (list3.Contains(array4[0]))
						{
							tmpB03Row.Limit2 = array4[0] + "|" + array4[1] + "|" + row3.LimitBasicAttr;
						}
						else if (list4.Contains(array4[0]))
						{
							tmpB03Row.Limit2 = array4[0] + "|" + array4[1] + "|" + row3.LimitBasicSkill;
						}
						else if (list5.Contains(array4[0]))
						{
							tmpB03Row.Limit2 = array4[0] + "|" + array4[1] + "|" + row3.LimitHPMP;
						}
						else if (list6.Contains(array4[0]))
						{
							tmpB03Row.Limit2 = array4[0] + "|" + array4[1] + "|" + row3.LimitATKDEFSP;
						}
					}
					break;
				}
				case "Skill":
				{
					for (int l = 1; l <= 5; l++)
					{
						fieldInfo = type.GetField("Skill" + l);
						if ("0".Equals(fieldInfo.GetValue(tmpB03Row).ToString()))
						{
							fieldInfo.SetValue(tmpB03Row, text2);
							break;
						}
					}
					break;
				}
				case "Paraplus":
				{
					bool flag = false;
					for (int j = 1; j <= 4; j++)
					{
						fieldInfo = type.GetField("Paraplus" + j);
						string[] array = fieldInfo.GetValue(tmpB03Row).ToString().Split('|');
						string[] array2 = text2.Split('|');
						if (array2[0].Equals(array[0]))
						{
							float num = float.Parse(array[1], CultureInfo.InvariantCulture);
							num += float.Parse(array2[1], CultureInfo.InvariantCulture);
							string value = array2[0] + "|" + num;
							fieldInfo.SetValue(tmpB03Row, value);
							flag = true;
							break;
						}
					}
					if (flag)
					{
						break;
					}
					for (int k = 1; k <= 5; k++)
					{
						fieldInfo = type.GetField("Paraplus" + k);
						if ("0".Equals(fieldInfo.GetValue(tmpB03Row).ToString()))
						{
							fieldInfo.SetValue(tmpB03Row, text2);
							break;
						}
					}
					break;
				}
				}
			}
		}
		return tmpB03Row;
	}

	private void ExitScene()
	{
		if (SharedData.Instance().m_MapController != null)
		{
			SharedData.Instance().m_MapController.m_AudioSource.Play();
		}
		InputDeviceDetector.instance.ClearJoyStack();
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			int index = SharedData.Instance().LoadedSceneStack.Count - 1;
			SharedData.Instance().LoadedSceneStack.RemoveAt(index);
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				index = SharedData.Instance().LoadedSceneStack.Count - 1;
				SceneManager.LoadScene(SharedData.Instance().LoadedSceneStack[index], LoadSceneMode.Additive);
			}
		}
		SharedData.Instance().m_Transfer_Info = "";
		SceneManager.UnloadSceneAsync("CreateWG");
	}

	public void Face(Direction direction, bool isInit = false)
	{
		_direction = direction;
		switch (direction)
		{
		case Direction.Left:
			_Animations[0].gameObject.SetActive(value: false);
			_Animations[1].gameObject.SetActive(value: true);
			_Animations[1].skeleton.ScaleX = 1f;
			_Animations[2].gameObject.SetActive(value: false);
			break;
		case Direction.Up:
			_Animations[0].gameObject.SetActive(value: false);
			_Animations[1].gameObject.SetActive(value: false);
			_Animations[2].gameObject.SetActive(value: true);
			break;
		case Direction.Right:
			_Animations[0].gameObject.SetActive(value: false);
			_Animations[1].gameObject.SetActive(value: true);
			_Animations[1].skeleton.ScaleX = -1f;
			_Animations[2].gameObject.SetActive(value: false);
			break;
		default:
			_Animations[0].gameObject.SetActive(value: true);
			_Animations[1].gameObject.SetActive(value: false);
			_Animations[2].gameObject.SetActive(value: false);
			break;
		}
	}

	public void PlayAnimation(string animation, bool loop = true, bool compensate = true, float timescale = 1f)
	{
		if (loop && (animation.Equals(Aniname.aniname_die) || animation.Equals(Aniname.aniname_behit)))
		{
			loop = false;
		}
		if (_Animations[0].AnimationName != animation)
		{
			_Animations[0].timeScale = timescale;
			if (!compensate)
			{
				_Animations[0].skeleton.SetToSetupPose();
				_Animations[0].AnimationState.ClearTracks();
			}
			_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (_Animations[1].AnimationName != animation)
		{
			_Animations[1].timeScale = timescale;
			if (!compensate)
			{
				_Animations[1].skeleton.SetToSetupPose();
				_Animations[1].AnimationState.ClearTracks();
			}
			_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (_Animations[2].AnimationName != animation)
		{
			_Animations[2].timeScale = timescale;
			if (!compensate)
			{
				_Animations[2].skeleton.SetToSetupPose();
				_Animations[2].AnimationState.ClearTracks();
			}
			_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}
}
