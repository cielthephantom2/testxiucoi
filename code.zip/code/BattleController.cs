using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using DG.Tweening;
using MessagePack;
using Newtonsoft.Json;
using SuperTiled2Unity;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;
using UnityEngine.UI;

public class BattleController : MonoBehaviour
{
	[Header("一些预分配的变量位置")]
	[SerializeField]
	private AudioSource m_EffectSound;

	[SerializeField]
	private Animator transition;

	[Header("一些运行时状态")]
	[HideInInspector]
	public Transform canvas;

	private bool InitOK;

	private GameObject m_WalletObj;

	private GameObject m_WalletPrefab;

	public AudioClip BattleBGM;

	private AudioSource m_AudioSource;

	public SuperMap map;

	public Tilemap tilemap;

	public Vector2Int mapSize;

	public List<Vector3Int> obstacle = new List<Vector3Int>();

	private Camera m_camera;

	private Vector3 velocity;

	private Vector3 m_CameraTarget = Vector3.zero;

	private List<Sprite> m_StarImg = new List<Sprite>();

	public SpriteRenderer m_BattleInterBG;

	public List<ItemController> items;

	public Dictionary<string, Vector3Int> itemUnits = new Dictionary<string, Vector3Int>();

	private SuperObject[] m_SuperObjects;

	public int m_Effect_SortingOrder;

	public int m_DynamicLayer_SortingOrder;

	public int m_underfoot_SortingOrder;

	public int m_attackselectrange_SortingOrder;

	public List<TriggerController> triggers;

	private int TerrainKeepRoundTimesMin = 2;

	private int TerrainKeepRoundTimesMax = 5;

	public bool isLoadLevelUp;

	public bool isSepareteAllExp;

	private int money;

	private int TotalExp;

	private string dropItemString = "";

	public List<EffectController> m_EffectControllerList = new List<EffectController>();

	public bool isPlayEffectFinish = true;

	public List<RoundRecord> m_RoundRecordList = new List<RoundRecord>();

	public RoundRecord m_FirstRecord;

	public RoundRecord m_FirstAutoRecord;

	public RoundRecord m_RoundStartRecord;

	public MenuController m_MenuController;

	public float _fantanInjury;

	private bool isShowAllHp;

	public Tilemap InteractiveGrassLayer;

	public InteractiveGrass m_InteractiveGrass;

	public List<SpriteRenderer> m_InteractiveGrassObjList = new List<SpriteRenderer>();

	private List<Vector4> m_InteractiveGrassPoslist = new List<Vector4>();

	public List<Vector4> m_InteractiveGrassTracePoslist = new List<Vector4>();

	private Thread SaveRoundRecordThread;

	public bool IsSaveRoundRecordRunning;

	private Thread LoadRoundRecordThread;

	public bool IsLoadRoundRecordRunning;

	public BattleObject m_Revenge_TGT;

	public string m_Revenge_TGTSkill = "";

	public BattleControllerFlow m_Flow;

	public List<ActionOrderItem> actionOrder = new List<ActionOrderItem>();

	public List<ActionOrderItem> ExtraActionOrder = new List<ActionOrderItem>();

	private ActionOrderItem currentActionObj;

	public List<BattleObject> allBattleObjs = new List<BattleObject>();

	public CurcorController m_curcor;

	public int m_currentID;

	private BattleObject m_current;

	public bool AutoBattle;

	public bool isLostControl;

	private int m_TurnCount;

	public Dictionary<Vector3Int, TerrainController> terrain = new Dictionary<Vector3Int, TerrainController>();

	public int currentRecordIndex = -1;

	public int currentActionOrderIndex = -1;

	public bool isDebugWin;

	public bool isDebugLose;

	public BattleObject current
	{
		get
		{
			return m_current;
		}
		set
		{
			m_current = value;
			m_currentID = m_current.gameObject.GetInstanceID();
		}
	}

	private void Awake()
	{
		map = MapLoader.instance.AsyncLoadMapByName(SharedData.Instance().loadMapE04).GetComponent<SuperMap>();
		map.gameObject.isStatic = true;
		mapSize = new Vector2Int(map.m_Width, map.m_Height);
		List<Tilemap> list = UnityEngine.Object.FindObjectsOfType<Tilemap>().ToList();
		List<SuperTileLayer> source = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>().ToList();
		List<TilemapRenderer> list2 = UnityEngine.Object.FindObjectsOfType<TilemapRenderer>().ToList();
		List<SuperGroupLayer> list3 = UnityEngine.Object.FindObjectsOfType<SuperGroupLayer>().ToList();
		m_curcor = UnityEngine.Object.Instantiate(CommonResourcesData.BattleFieldCurcorPrefab).GetComponent<CurcorController>();
		m_curcor.SetSortingOrder(list2.FirstOrDefault((TilemapRenderer s) => s.name == "curcor").sortingOrder);
		m_DynamicLayer_SortingOrder = list2.FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
		m_underfoot_SortingOrder = list2.FirstOrDefault((TilemapRenderer s) => s.name == "underfoot").sortingOrder;
		m_attackselectrange_SortingOrder = list2.FirstOrDefault((TilemapRenderer s) => s.name == "attackselectrange").sortingOrder;
		m_Effect_SortingOrder = list2.FirstOrDefault((TilemapRenderer s) => s.name == "EffectLayer").sortingOrder;
		foreach (TilemapRenderer item in list2)
		{
			if (item.sortingOrder > m_Effect_SortingOrder)
			{
				m_Effect_SortingOrder = item.sortingOrder;
			}
		}
		string text = "role-battle";
		string obstructLayerName = "obstruct-battle";
		string terrainLayerName = "terrain";
		string text2 = "BattleLayer";
		string[] array = SharedData.Instance().loadMapE04.mapName.Split('|');
		if (array.Length > 1)
		{
			text = text + "|" + array[1];
			obstructLayerName = obstructLayerName + "|" + array[1];
			terrainLayerName = terrainLayerName + "|" + array[1];
			text2 = text2 + "|" + array[1];
		}
		SuperTileLayer superTileLayer = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>().FirstOrDefault((SuperTileLayer s) => s.name == "switch-fire-event");
		if (superTileLayer != null)
		{
			superTileLayer.gameObject.SetActive(value: false);
		}
		Tilemap tilemap = list.FirstOrDefault((Tilemap s) => s.name == terrainLayerName);
		if (tilemap != null)
		{
			for (int i = 0; i < mapSize.x; i++)
			{
				for (int j = 0; j < mapSize.y; j++)
				{
					Vector3Int targetPos = new Vector3Int(i, j, 0);
					if (!tilemap.HasTile(new Vector3Int(i, -j, 0)))
					{
						continue;
					}
					TerrainType terrainType = TerrainType.UNKNOWN;
					foreach (CustomProperty customProperty in ((SuperTile)tilemap.GetTile(new Vector3Int(i, -j, 0))).m_CustomProperties)
					{
						if ("Type".Equals(customProperty.m_Name))
						{
							terrainType = Enum.Parse<TerrainType>(customProperty.m_Value);
							AddTerrain(targetPos, terrainType);
							break;
						}
					}
				}
			}
			UnityEngine.Debug.LogWarning("MAP " + map.name + " has terrain set.");
		}
		list.ForEach(delegate(Tilemap x)
		{
			x.gameObject.SetActive(!x.name.StartsWith("terrain"));
		});
		SuperTileLayer superTileLayer2 = source.FirstOrDefault((SuperTileLayer s) => s.name == "obstruct");
		this.tilemap = ((!(superTileLayer2?.GetComponent<Tilemap>() != null)) ? superTileLayer2?.GetComponentInParent<Tilemap>(includeInactive: true) : superTileLayer2?.GetComponent<Tilemap>());
		SuperTileLayer superTileLayer3 = source.FirstOrDefault((SuperTileLayer s) => s.name == obstructLayerName);
		Tilemap tilemap2 = ((superTileLayer3?.GetComponent<Tilemap>() != null) ? superTileLayer3.GetComponent<Tilemap>() : superTileLayer3?.GetComponentInParent<Tilemap>(includeInactive: true));
		if (tilemap2 == null)
		{
			tilemap2 = this.tilemap;
		}
		else
		{
			this.tilemap = tilemap2;
		}
		if (tilemap2 == null)
		{
			tilemap2 = source.FirstOrDefault((SuperTileLayer s) => s.name == "obstruct")?.GetComponent<Tilemap>();
		}
		for (int k = 0; k < mapSize.x; k++)
		{
			for (int l = 0; l < mapSize.y; l++)
			{
				Vector3Int vector3Int = new Vector3Int(k, l, 0);
				if (tilemap2.HasTile(new Vector3Int(k, -l, 0)))
				{
					if (!terrain.ContainsKey(vector3Int) || (terrain[vector3Int].t_type != 0 && terrain[vector3Int].t_type != TerrainType.Water))
					{
						obstacle.Add(vector3Int);
						continue;
					}
					string[] obj = new string[5] { "Oops! ", null, null, null, null };
					Vector3Int vector3Int2 = vector3Int;
					obj[1] = vector3Int2.ToString();
					obj[2] = " excluded from obstacle by terrain[";
					obj[3] = terrain[vector3Int]?.ToString();
					obj[4] = "].";
					UnityEngine.Debug.LogWarning(string.Concat(obj));
				}
			}
		}
		tilemap2?.gameObject.SetActive(value: false);
		this.tilemap?.gameObject.SetActive(value: false);
		foreach (SuperGroupLayer item2 in list3)
		{
			if (item2.name.StartsWith("FieldLayer"))
			{
				item2.gameObject.SetActive(value: false);
			}
			else if (item2.name.Equals(text2))
			{
				item2.gameObject.SetActive(value: true);
			}
			else if (item2.name.StartsWith("BattleLayer"))
			{
				item2.gameObject.SetActive(value: false);
			}
		}
		m_SuperObjects = UnityEngine.Object.FindObjectsOfType<SuperObject>();
		foreach (SuperGroupLayer item3 in list3)
		{
			if (item3.name.StartsWith("FieldLayer"))
			{
				item3.gameObject.SetActive(value: false);
			}
			else if (item3.name.StartsWith("BattleLayer"))
			{
				item3.gameObject.SetActive(value: false);
			}
		}
		canvas = UnityEngine.Object.Instantiate(CommonResourcesData.BattleFieldCanvasPrefab).transform;
		canvas.name = "BattleCanvas";
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		m_AudioSource = GetComponent<AudioSource>();
		if (SharedData.Instance().loadMapE04.bgm != "")
		{
			BattleBGM = CommonResourcesData.LoadBgm(SharedData.Instance().loadMapE04.bgm);
			m_AudioSource.clip = BattleBGM;
			m_AudioSource.Play();
		}
		SetOverheadCamera();
		SharedData.Instance().m_BattleController = this;
	}

	private void OnDestroy()
	{
		RangePoolManager.instance.ClearObjectPool();
		if (SaveRoundRecordThread != null && SaveRoundRecordThread.IsAlive)
		{
			IsSaveRoundRecordRunning = false;
			SaveRoundRecordThread.Join();
		}
		if (LoadRoundRecordThread != null && LoadRoundRecordThread.IsAlive)
		{
			IsLoadRoundRecordRunning = false;
			LoadRoundRecordThread.Join();
		}
	}

	private void Start()
	{
		InputDeviceDetector.instance.ClearJoyStack();
		GameObject original = Resources.Load("Prefabs/BattleInterBG", typeof(GameObject)) as GameObject;
		m_WalletPrefab = Resources.Load("Prefabs/BattleMenu/WalletCanvas", typeof(GameObject)) as GameObject;
		m_BattleInterBG = UnityEngine.Object.Instantiate(original, m_camera.transform).GetComponent<SpriteRenderer>();
		m_BattleInterBG.sortingOrder = UnityEngine.Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "BattleInterBG").sortingOrder;
		m_BattleInterBG.transform.position = new Vector3(m_camera.transform.position.x, m_camera.transform.position.y, 0f);
		if (UnityEngine.Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "stage-bottom") != null)
		{
			UnityEngine.Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "stage-bottom").sortingOrder = -1;
		}
		if (MapController.enemygid[0] != "demo")
		{
			InitPlayers();
		}
		if (SharedData.Instance().DuelBattleGuild != "")
		{
			InitDuelEnemies();
		}
		else
		{
			InitEnemies();
		}
		List<string> first = CommonResourcesData.b10.Find_ID("2001").Members.Split("|").ToList();
		List<string> second = CommonResourcesData.b10.Find_ID("2002").Members.Split("|").ToList();
		List<string> list = first.Concat(second).ToList();
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.race.Equals("enemy"))
			{
				allBattleObj.isPokemon = list.Contains(allBattleObj.charadata.m_B01Id);
			}
		}
		InitEffects();
		InitItems();
		InitTriggers();
		InitInteractiveGrass();
		m_MenuController = canvas.GetComponent<MenuController>();
		SetFlowState(BattleControllerFlow.Interlude);
		SharedData.Instance().m_BattleDropItemIdList.Clear();
		SharedData.Instance().m_SubdueList.Clear();
		SharedData.Instance().m_FinalSubdueList.Clear();
		InputSystemCustom.Instance().Player.Enable();
		InitOK = true;
	}

	private void InitInteractiveGrass()
	{
		InteractiveGrassLayer = UnityEngine.Object.FindObjectsOfType<Tilemap>().FirstOrDefault((Tilemap s) => s.name == "InteractiveGrassLayer");
		if (InteractiveGrassLayer == null)
		{
			return;
		}
		GameObject gameObject = new GameObject();
		gameObject.name = "Grass";
		gameObject.transform.parent = base.gameObject.transform.parent;
		m_InteractiveGrass = gameObject.AddComponent<InteractiveGrass>();
		for (int i = 0; i < mapSize.x; i++)
		{
			for (int j = 0; j < mapSize.y; j++)
			{
				new Vector3Int(i, j, 0);
				if (InteractiveGrassLayer.HasTile(new Vector3Int(i, -j, 0)))
				{
					Sprite sprite = CommonResourcesData.LoadInteractiveGrass(((SuperTile)InteractiveGrassLayer.GetTile(new Vector3Int(i, -j, 0))).name);
					if (!(sprite == null))
					{
						GameObject obj = UnityEngine.Object.Instantiate(CommonResourcesData.m_InteractiveGrassPrefab, map.transform);
						SpriteRenderer component = obj.GetComponent<SpriteRenderer>();
						component.sprite = sprite;
						obj.transform.localPosition = new Vector3(25 + (i + 1) * 50, -50 - (j - 1) * 50);
						m_InteractiveGrassObjList.Add(component);
						obj.transform.parent = gameObject.transform;
					}
				}
			}
		}
		InteractiveGrassLayer.gameObject.SetActive(value: false);
		m_InteractiveGrass.ReSortGrassOrder(m_BattleInterBG.sortingOrder - 1);
	}

	private void InitEffects()
	{
		SuperObject[] byType = getByType("Effect");
		foreach (SuperObject superObject in byType)
		{
			string[] array = superObject.name.Split('|');
			UnityEngine.Object.Instantiate((GameObject)Resources.Load("Prefabs/Effect/Ground/" + array[0]), map.transform.parent).transform.localPosition = superObject.transform.localPosition;
		}
	}

	private void InitPlayers()
	{
		if (SharedData.Instance().PlayerSetting.Count <= 0)
		{
			SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
		}
		foreach (KeyValuePair<string, string> item in SharedData.Instance().PlayerSetting)
		{
			CommonResourcesData.b01.Find_ID(item.Value);
			SuperObject[] byName = getByName(item.Key);
			foreach (SuperObject superObject in byName)
			{
				CharaData charaData = SharedData.Instance().GetCharaData(item.Value);
				BattleObject battleObject = SkinCharacter.InitSkinCharacter(charaData).AddComponent<BattleObject>();
				battleObject.InitCharacter("player", superObject, charaData);
				battleObject.GetGridPosition();
				allBattleObjs.Add(battleObject);
			}
		}
	}

	private void InitEnemies()
	{
		if (MapController.enemygid[0] == "solo")
		{
			CharaData charaData = SharedData.Instance().GetCharaData(MapController.enemygid[1]);
			SuperObject[] byName = getByName("Enemy1");
			foreach (SuperObject superObject in byName)
			{
				BattleObject battleObject = SkinCharacter.InitSkinCharacter(charaData).AddComponent<BattleObject>();
				battleObject.InitCharacter("enemy", superObject, charaData);
				battleObject.GetGridPosition();
				allBattleObjs.Add(battleObject);
			}
			return;
		}
		List<gang_b04Table.Row> list = null;
		if (SharedData.Instance().isRandomFight)
		{
			list = InitEnemiesRandom();
		}
		else
		{
			list = CommonResourcesData.b04.FindAll_GID(SharedData.Instance().b04BattleID);
			if (list.Count.Equals(0))
			{
				list = CommonResourcesData.b04_Random.FindAll_GID(SharedData.Instance().b04BattleID);
			}
		}
		foreach (gang_b04Table.Row item in list)
		{
			SuperObject[] byName2 = getByName(item.ID);
			SuperObject[] byName;
			if (item.Side == "1")
			{
				byName = byName2;
				foreach (SuperObject superObject2 in byName)
				{
					CharaData charaData2 = new CharaData();
					charaData2.Init(item);
					BattleObject battleObject2 = SkinCharacter.InitSkinCharacter(charaData2).AddComponent<BattleObject>();
					battleObject2.InitCharacter("enemy", superObject2, item);
					battleObject2.GetGridPosition();
					allBattleObjs.Add(battleObject2);
				}
				continue;
			}
			byName = byName2;
			foreach (SuperObject superObject3 in byName)
			{
				CharaData charaData3 = null;
				if (!"0".Equals(item.SetData))
				{
					charaData3 = SharedData.Instance().GetCharaData(item.SetData);
				}
				if (charaData3 == null)
				{
					charaData3 = new CharaData();
					charaData3.Init(item);
				}
				BattleObject battleObject3 = SkinCharacter.InitSkinCharacter(charaData3).AddComponent<BattleObject>();
				battleObject3.InitCharacter("player", superObject3, item);
				battleObject3.GetGridPosition();
				allBattleObjs.Add(battleObject3);
			}
		}
	}

	private List<gang_b04Table.Row> InitEnemiesRandom()
	{
		List<gang_b04Table.Row> list = JsonConvert.DeserializeObject<List<gang_b04Table.Row>>(JsonConvert.SerializeObject(SharedData.Instance().b04RamdonBattleRowList));
		if (SharedData.Instance().SpecialRandomFightGID.Equals(""))
		{
			System.Random random = new System.Random();
			List<int> list2 = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
			for (int i = 0; i < list.Count; i++)
			{
				int index = random.Next(list2.Count);
				int num = list2[index];
				list2.RemoveAt(index);
				list[i].ID = "Enemy" + num;
			}
		}
		return list;
	}

	private void InitDuelEnemies()
	{
		foreach (KeyValuePair<string, string> item in SharedData.Instance().EnemySetting)
		{
			CharaData charaData = SharedData.Instance().GetCharaData(item.Value);
			SuperObject[] byName = getByName(item.Key);
			foreach (SuperObject superObject in byName)
			{
				BattleObject battleObject = SkinCharacter.InitSkinCharacter(charaData).AddComponent<BattleObject>();
				battleObject.InitCharacter("enemy", superObject, charaData);
				battleObject.GetGridPosition();
				allBattleObjs.Add(battleObject);
			}
		}
	}

	private void InitItems()
	{
		items = new List<ItemController>();
		List<gang_b05Table.Row> list = CommonResourcesData.b05.FindAll_GID(SharedData.Instance().BattleItemGroupId);
		SuperObject[] byType = getByType("ITEM");
		foreach (gang_b05Table.Row item in list)
		{
			SuperObject[] array = byType;
			foreach (SuperObject superObject in array)
			{
				if (superObject.name.Equals(item.ID))
				{
					ItemController itemController = UnityEngine.Object.Instantiate((GameObject)Resources.Load("Prefabs/" + item.Prefab1), map.transform.parent).AddComponent<ItemController>();
					itemController.transform.localPosition = superObject.transform.localPosition;
					itemController.name = SharedData.Instance().BattleItemGroupId + "|" + item.ID;
					itemController.b5row = item;
					items.Add(itemController);
					itemUnits.Add(itemController.name, itemController.GetGridPosition());
					break;
				}
			}
		}
	}

	private void InitTriggers()
	{
		triggers = new List<TriggerController>();
		SuperObject[] byType = getByType("TRIGGER");
		foreach (SuperObject superObject in byType)
		{
			TriggerController triggerController = UnityEngine.Object.Instantiate((GameObject)Resources.Load("Prefabs/Field/Dummy"), map.transform.parent).AddComponent<TriggerController>();
			triggerController.transform.localPosition = superObject.transform.localPosition;
			triggerController.name = superObject.m_TiledName;
			triggers.Add(triggerController);
		}
	}

	private void LateUpdate()
	{
		if (InitOK && !IsSaveRoundRecordRunning && !IsLoadRoundRecordRunning)
		{
			m_camera.transform.position = new Vector3(Mathf.SmoothDamp(m_camera.transform.position.x, m_CameraTarget.x, ref velocity.x, CommonVariables.speed), Mathf.SmoothDamp(m_camera.transform.position.y, m_CameraTarget.y, ref velocity.y, CommonVariables.speed), -10f);
		}
	}

	private void Update()
	{
		if (!InitOK || IsSaveRoundRecordRunning || IsLoadRoundRecordRunning || CommonFunc.IsHoverOpen() || !isRoundActionFinish())
		{
			return;
		}
		if (m_Flow == BattleControllerFlow.Interlude)
		{
			SkillTraitEquipManager.m_GatherPosList.Clear();
			if (m_FirstRecord == null)
			{
				SetCameraTrans(allBattleObjs[0]);
				StartSaveRecordThreadedTask();
			}
			m_BattleInterBG.DOFade(0f, 0f);
			if (JudgeWinOrLose())
			{
				return;
			}
			m_EffectControllerList.Clear();
			SharedData.Instance().useItemID = "";
			SharedData.Instance().m_MoneyForAttack = 0f;
			foreach (BattleObject allBattleObj in allBattleObjs)
			{
				allBattleObj.m_HeadMarker.SetActive(value: false);
				allBattleObj.HideNextActionIcon();
				allBattleObj.ClearRangeInfo();
				allBattleObj.GetGridPosition();
			}
			AStarAlgorithmBattleField.AStarClean();
			current = GetNextBattleObject();
			ImpactSkiiManage.isAlreadImpact = false;
			AStarAlgorithmBattleField.isBattleObjOn = new Dictionary<Vector3Int, bool>();
			foreach (Vector3Int item in SharedData.Instance().m_BattleController.obstacle)
			{
				AStarAlgorithmBattleField.isBattleObjOn.Add(item, SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(item) || SharedData.Instance().m_BattleController.CheckIsItemOnGrid(item));
			}
			SetCameraSmooth(current, isSetCurcor: true);
			m_curcor.selected = current;
			current.m_HeadMarker.SetActive(value: true);
			m_MenuController.UpdateCharacterInfo(current);
			CalNextActionIcon();
			InvisibleEffectOn();
			isLostControl = false;
			if (current.race == "enemy" || current.race != current.charadata.originRace || MapController.enemygid[0] == "demo" || AutoBattle || GetCurrentObjActionType() == ActionType.Formless || GetCurrentObjActionType() == ActionType.WugongCounter || GetCurrentObjActionType() == ActionType.Return || GetCurrentObjActionType() == ActionType.FormlessSuper || GetCurrentObjActionType() == ActionType.Ambush || GetCurrentObjActionType() == ActionType.WugongAssist || GetCurrentObjActionType() == ActionType.RoleAssist || GetCurrentObjActionType() == ActionType.Fantan)
			{
				isLostControl = true;
			}
			if (!isLostControl && current.race == "player" && (current.CheckBuffEffectOn("Dizzy") || current.CheckBuffEffectOn("Fear") || current.CheckBuffEffectOn("Blind") || current.charadata.GetBattleValueByName("Mad") >= 255f || current.charadata.originRace == "enemy"))
			{
				isLostControl = true;
			}
			if (terrain.ContainsKey(current.GetGridPosition()) && (!(current.charadata.GetBattleValueByName("TrapImmune") > 0f) || (terrain[current.GetGridPosition()].t_type != TerrainType.TrapBlast && terrain[current.GetGridPosition()].t_type != TerrainType.TrapSeal)))
			{
				terrain[current.GetGridPosition()].TerrainEffectOn();
			}
			SetFlowState(BattleControllerFlow.PreHandTouch);
		}
		else if (m_Flow == BattleControllerFlow.PreHandTouch)
		{
			if (isRoundActionFinish())
			{
				if (current.isDead)
				{
					SetFlowState(BattleControllerFlow.Interlude);
					return;
				}
				current.SetBattleObjState(BattleObjectState.HandIn);
				SetFlowState(BattleControllerFlow.HandTouch);
			}
		}
		else if (m_Flow == BattleControllerFlow.CharacterInit)
		{
			if (AutoBattle)
			{
				m_MenuController.m_menuState = BattleMenuState.CancelAutoBattleShow;
			}
			else if (isLostControl)
			{
				m_MenuController.m_menuState = BattleMenuState.None;
			}
			else
			{
				m_MenuController.m_menuState = BattleMenuState.AutoBattleShow;
				GetOneRoundRecord();
			}
			if (isLostControl || AutoBattle)
			{
				if (current.m_MpBroken)
				{
					RecoveryCurrentMp();
					return;
				}
				SetFlowState(BattleControllerFlow.Move);
				StartCoroutine(AutoBattleCal.AutoMoveAction());
			}
			else
			{
				SetFlowState(BattleControllerFlow.MoveWait);
			}
		}
		else if (m_Flow == BattleControllerFlow.MoveWait)
		{
			if (!JudgeWinOrLose() && isLostControl)
			{
				SetFlowState(BattleControllerFlow.CharacterInit);
			}
		}
		else if (m_Flow == BattleControllerFlow.Move)
		{
			if (current.race == "player")
			{
				JudgeIsDeadCouseJumpToStarPoint(current);
			}
		}
		else if (m_Flow == BattleControllerFlow.ActionWait)
		{
			if (isLostControl)
			{
				AutoActionWait();
			}
		}
		else
		{
			if (m_Flow != BattleControllerFlow.PlayerPackOpen)
			{
				return;
			}
			if (SharedData.Instance().m_BattlePackageStatus == 2)
			{
				SharedData.Instance().m_BattlePackageStatus = 3;
				SelectItemTarget();
			}
			else if (SharedData.Instance().m_BattlePackageStatus == 4)
			{
				SharedData.Instance().m_BattlePackageStatus = 3;
				current.UseItem();
			}
			else if (SharedData.Instance().m_BattlePackageStatus == 9)
			{
				SharedData.Instance().m_BattlePackageStatus = 0;
				m_MenuController.m_menuState = BattleMenuState.AutoBattleShow;
				if (current.handInPos != current.GetGridPosition())
				{
					SetFlowState(BattleControllerFlow.ActionWait);
				}
				else
				{
					SetFlowState(BattleControllerFlow.MoveWait);
				}
			}
			else if (SharedData.Instance().m_BattlePackageStatus == 99)
			{
				SharedData.Instance().m_BattlePackageStatus = 0;
				m_MenuController.m_menuState = BattleMenuState.WugongListShow;
				SetFlowState(BattleControllerFlow.ActionWaitAttack);
			}
		}
	}

	public bool JudgeWinOrLose()
	{
		if (isDebugWin)
		{
			PlayerWinProcess();
			return true;
		}
		if (isDebugLose)
		{
			EnemyWinProcess();
			return true;
		}
		if (SharedData.Instance().b04BattleID == "70001")
		{
			int num = 0;
			int num2 = 0;
			foreach (BattleObject allBattleObj in allBattleObjs)
			{
				if (allBattleObj.charadata.originRace == "enemy")
				{
					if (allBattleObj.isEscape)
					{
						num2++;
					}
					else if (!allBattleObj.isDead)
					{
						num++;
					}
				}
			}
			if (num2 >= 2)
			{
				EnemyWinProcess();
				return true;
			}
			if (num2 == 1 && num == 0)
			{
				PlayerWinProcess();
				return true;
			}
			if (num == 0)
			{
				EnemyWinProcess();
				return true;
			}
			return false;
		}
		int num3 = 0;
		foreach (BattleObject allBattleObj2 in allBattleObjs)
		{
			if (allBattleObj2.race != "enemy")
			{
				if (!allBattleObj2.isDead && allBattleObj2.charadata.originRace == "enemy" && (allBattleObj2.rebellionType == RebellionType.Bribe || allBattleObj2.rebellionType == RebellionType.Temptation || allBattleObj2.rebellionType == RebellionType.ControlMad))
				{
					num3++;
				}
				continue;
			}
			if (!allBattleObj2.isDead)
			{
				if (allBattleObj2.charadata.m_KeyPos != 2)
				{
					num3++;
				}
				continue;
			}
			if (allBattleObj2.charadata.m_KeyPos == 1)
			{
				PlayerWinProcess();
				return true;
			}
			if (allBattleObj2.charadata.m_KeyPos != 2)
			{
				continue;
			}
			EnemyWinProcess();
			return true;
		}
		int num4 = 0;
		foreach (BattleObject allBattleObj3 in allBattleObjs)
		{
			if (allBattleObj3.race != "player")
			{
				if (!allBattleObj3.isDead && allBattleObj3.charadata.originRace == "player" && (allBattleObj3.rebellionType == RebellionType.Bribe || allBattleObj3.rebellionType == RebellionType.Temptation || allBattleObj3.rebellionType == RebellionType.ControlMad))
				{
					num4++;
				}
				continue;
			}
			if (!allBattleObj3.isDead)
			{
				if (allBattleObj3.charadata.m_KeyPos != 2)
				{
					num4++;
				}
				continue;
			}
			if (allBattleObj3.charadata.m_KeyPos == 1)
			{
				EnemyWinProcess();
				return true;
			}
			if (allBattleObj3.charadata.m_KeyPos != 2)
			{
				continue;
			}
			PlayerWinProcess();
			return true;
		}
		if (num4 == 0 && num3 == 0)
		{
			if (current.race == "player")
			{
				num4 = 1;
			}
			else if (current.race == "enemy")
			{
				num3 = 1;
			}
		}
		if (num3 <= 0)
		{
			PlayerWinProcess();
			return true;
		}
		if (num4 <= 0)
		{
			EnemyWinProcess();
			return true;
		}
		if (current != null && triggers.Count > 0)
		{
			foreach (TriggerController trigger in triggers)
			{
				if (trigger.name.Split('|')[0].Equals(current.tileName) && trigger.GetGridPosition().Equals(current.GetGridPosition()))
				{
					PlayerWinProcess();
					return true;
				}
			}
		}
		return false;
	}

	private void PlayerWinProcess()
	{
		m_MenuController.m_menuState = BattleMenuState.None;
		if (SharedData.Instance().isRandomFight && SharedData.Instance().SpecialRandomFightGID != "")
		{
			SharedData.Instance().m_SpecialWantedList.Add(SharedData.Instance().SpecialRandomFightGID);
		}
		if (SharedData.Instance().levelupObjList.Count > 0 || SharedData.Instance().skillLevelupObjList.Count > 0)
		{
			return;
		}
		SharedData.Instance().m_isBattleWin = true;
		if (!isSepareteAllExp)
		{
			SeparateExpAfterBattle();
			return;
		}
		GetMustDropItemAfterBattle();
		m_AudioSource.clip = CommonResourcesData.WinBGM;
		m_AudioSource.Play();
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (!(allBattleObj.charadata.originRace == "player") || !allBattleObj.charadata.m_titleExpDict.ContainsKey(allBattleObj.charadata.m_currentTitleID))
			{
				continue;
			}
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(allBattleObj.charadata.m_currentTitleID);
			if (row != null && !allBattleObj.charadata.m_TraitList.Contains(row.titleLeveUp))
			{
				allBattleObj.charadata.m_titleExpDict[allBattleObj.charadata.m_currentTitleID] += 100;
				if (allBattleObj.charadata.m_titleExpDict[allBattleObj.charadata.m_currentTitleID] >= 10000)
				{
					allBattleObj.charadata.m_titleExpDict[allBattleObj.charadata.m_currentTitleID] = 0;
					SharedData.Instance().m_TitleLevelUpDict.Add(allBattleObj.charadata.m_Id, row.titleLeveUp);
				}
			}
		}
		GameSetCommon();
		if ((!SharedData.Instance().m_isDaTianWangSiChallenge || SharedData.Instance().m_DaTianWangSiLevel == SharedData.Instance().m_MaxDaTianWangSiLevel) && SharedData.Instance().AfterBattleWin.Length > 0)
		{
			SharedData.Instance().FlagList[SharedData.Instance().AfterBattleWin] = 1;
		}
		if (SharedData.Instance().m_isDaTianWangSiChallenge)
		{
			List<string> list = SharedData.Instance().m_Arena_RewardsID_DaTianWangSi.Split("|").ToList();
			List<string> list2 = SharedData.Instance().m_Arena_Rewards_DaTianWangSi.Split("|").ToList();
			foreach (string item in list)
			{
				string text2 = item.Split("&")[0];
				if (SharedData.Instance().m_DaTianWangSiLevel != int.Parse(text2))
				{
					continue;
				}
				string find = item.Split("&")[1];
				List<gang_c04Table.Row> list3 = CommonResourcesData.c04.FindAll_ID(find);
				if (list3 == null)
				{
					continue;
				}
				foreach (int item2 in (from n in Enumerable.Range(0, list3.Count).ToList()
					orderby Guid.NewGuid()
					select n).ToList())
				{
					gang_c04Table.Row row2 = list3[item2];
					bool flag = false;
					foreach (string item3 in list2)
					{
						if (item3.Split("&")[0] == text2 && item3.Split("&")[1] == row2.Item)
						{
							flag = true;
						}
					}
					if (!flag)
					{
						SharedData.Instance().m_challengePrizeItemList.Add(row2.Item);
						int num = 0;
						num = ((!row2.QTY.Contains("|")) ? int.Parse(row2.QTY) : UnityEngine.Random.Range(int.Parse(row2.QTY.Split("|")[0]), int.Parse(row2.QTY.Split("|")[1])));
						SharedData.Instance().m_challengePrizeNumberList.Add(num);
						SharedData.Instance().m_challengePrizeLevelList.Add(text2);
						break;
					}
				}
			}
		}
		CalSubdue();
		m_MenuController.transform.Find("GameSet/ReLoad").gameObject.SetActive(value: false);
		m_MenuController.transform.Find("GameSet/Continue").gameObject.SetActive(value: false);
		m_MenuController.transform.Find("GameSet/LoadRecord").gameObject.SetActive(value: false);
		EventSystem.current.SetSelectedGameObject(m_MenuController.transform.Find("GameSet/Return").gameObject);
		if (SharedData.Instance().m_isDaTianWangSiChallenge)
		{
			m_MenuController.transform.Find("GameSet/Continue").gameObject.SetActive(SharedData.Instance().m_DaTianWangSiLevel != SharedData.Instance().m_MaxDaTianWangSiLevel);
			if (m_MenuController.transform.Find("GameSet/Continue").gameObject.activeInHierarchy)
			{
				EventSystem.current.SetSelectedGameObject(m_MenuController.transform.Find("GameSet/Continue").gameObject);
			}
			m_MenuController.ShowChallengInfo();
		}
		if (MapController.enemygid[0] != "demo")
		{
			m_MenuController.transform.Find("GameSet").gameObject.SetActive(value: true);
			m_MenuController.transform.Find("GameSet/Player").gameObject.SetActive(value: true);
		}
		else if (SharedData.Instance().SceneBefore4Camp.Length > 0)
		{
			LoadScene(SharedData.Instance().SceneBefore4Camp);
		}
		else if (SharedData.Instance().SceneBefore.Length > 0)
		{
			SharedData.Instance().BackFromOtherScene = true;
			LoadScene(SharedData.Instance().SceneBefore);
		}
		else
		{
			LoadScene("BattleField");
		}
	}

	private void EnemyWinProcess()
	{
		m_MenuController.m_menuState = BattleMenuState.None;
		SharedData.Instance().m_isBattleWin = false;
		StatsAndAchievements.Instance().UnlockAchievement("1028");
		m_AudioSource.clip = CommonResourcesData.LoseBGM;
		m_AudioSource.Play();
		GameSetCommon();
		if (SharedData.Instance().AfterBattleLose.Length > 0)
		{
			SharedData.Instance().FlagList[SharedData.Instance().AfterBattleLose] = 1;
		}
		if (SharedData.Instance().m_isDaTianWangSiChallenge)
		{
			SharedData.Instance().m_DaTianWangSiLevel = 0;
			SharedData.Instance().m_challengePrizeItemList.Clear();
			SharedData.Instance().m_challengePrizeNumberList.Clear();
			SharedData.Instance().m_challengePrizeLevelList.Clear();
		}
		m_MenuController.transform.Find("GameSet/Continue").gameObject.SetActive(value: false);
		if (SharedData.Instance().m_isDaTianWangSiChallenge)
		{
			m_MenuController.transform.Find("GameSet/ReLoad").gameObject.SetActive(value: false);
		}
		if (MapController.enemygid[0] != "demo")
		{
			m_MenuController.transform.Find("GameSet").gameObject.SetActive(value: true);
			EventSystem.current.SetSelectedGameObject(m_MenuController.transform.Find("GameSet/ReLoad").gameObject);
			m_MenuController.transform.Find("GameSet/Enemy").gameObject.SetActive(value: true);
		}
		else if (SharedData.Instance().SceneBefore4Camp.Length > 0)
		{
			LoadScene(SharedData.Instance().SceneBefore4Camp);
		}
		else if (SharedData.Instance().SceneBefore.Length > 0)
		{
			SharedData.Instance().BackFromOtherScene = true;
			LoadScene(SharedData.Instance().SceneBefore);
		}
		else
		{
			LoadScene("BattleField");
		}
		if (SharedData.Instance().b04BattleID.Equals("10037") || SharedData.Instance().b04BattleID.Equals("70027"))
		{
			m_MenuController.OnButtonSetClick(m_MenuController.transform.Find("GameSet/Return").gameObject);
		}
	}

	public void GameSetCommon()
	{
		m_MenuController.m_menuState = BattleMenuState.None;
		SetFlowState(BattleControllerFlow.GameSet);
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			allBattleObj.charadata.CleanFightValues();
			if (allBattleObj.charadata.originRace == "player")
			{
				if (allBattleObj.charadata.m_Hp == 0f)
				{
					allBattleObj.charadata.m_Hp = 1f;
				}
			}
			else
			{
				allBattleObj.charadata.m_Hp = allBattleObj.charadata.GetFieldValueByName("HP");
				allBattleObj.charadata.m_Mp = allBattleObj.charadata.GetFieldValueByName("MP");
			}
		}
		SharedData.Instance().m_EventShow = false;
	}

	public void CalSubdue()
	{
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (!allBattleObj.isDead && !(allBattleObj.race == "enemy") && !(allBattleObj.charadata.originRace == "player") && !(allBattleObj.charadata.m_B01Id == "0") && (allBattleObj.rebellionType == RebellionType.Charm || allBattleObj.rebellionType == RebellionType.SaveMad || allBattleObj.rebellionType == RebellionType.ElfBall))
			{
				SharedData.Instance().m_SubdueList.Add(allBattleObj.charadata.m_Id, allBattleObj.charadata);
			}
		}
	}

	private void GetMustDropItemAfterBattle()
	{
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (!(allBattleObj.charadata.originRace == "enemy"))
			{
				continue;
			}
			for (int i = 0; i < allBattleObj.m_mustDropItemsName.Count; i++)
			{
				if (UnityEngine.Random.Range(0, 100) >= int.Parse(allBattleObj.m_mustDropItemsName[i].DD))
				{
					continue;
				}
				if (allBattleObj.m_mustDropItemsName[i].QTY.Contains("|"))
				{
					int minInclusive = int.Parse(allBattleObj.m_mustDropItemsName[i].QTY.Split("|")[0]);
					int maxExclusive = int.Parse(allBattleObj.m_mustDropItemsName[i].QTY.Split("|")[1]);
					int num = UnityEngine.Random.Range(minInclusive, maxExclusive);
					if (SharedData.Instance().m_BattleDropItemIdList.ContainsKey(allBattleObj.m_mustDropItemsName[i].Item))
					{
						SharedData.Instance().m_BattleDropItemIdList[allBattleObj.m_mustDropItemsName[i].Item] += num;
					}
					else
					{
						SharedData.Instance().m_BattleDropItemIdList.Add(allBattleObj.m_mustDropItemsName[i].Item, num);
					}
				}
				else if (SharedData.Instance().m_BattleDropItemIdList.ContainsKey(allBattleObj.m_mustDropItemsName[i].Item))
				{
					SharedData.Instance().m_BattleDropItemIdList[allBattleObj.m_mustDropItemsName[i].Item] += int.Parse(allBattleObj.m_mustDropItemsName[i].QTY);
				}
				else
				{
					SharedData.Instance().m_BattleDropItemIdList.Add(allBattleObj.m_mustDropItemsName[i].Item, int.Parse(allBattleObj.m_mustDropItemsName[i].QTY));
				}
			}
		}
	}

	private void SeparateExpAfterBattle()
	{
		isSepareteAllExp = true;
		int num = 0;
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.charadata.originRace == "player" && (allBattleObj.charadata.m_Table == "b01" || SharedData.Instance().FollowList.Contains(allBattleObj.charadata.m_Id)) && !allBattleObj.isDead)
			{
				num++;
			}
			if (allBattleObj.charadata.originRace == "enemy" && allBattleObj.charadata.m_Table == "b04")
			{
				TotalExp += allBattleObj.charadata.separateexp;
			}
		}
		if (num <= 0)
		{
			num = 1;
		}
		foreach (BattleObject allBattleObj2 in allBattleObjs)
		{
			if (!(allBattleObj2.charadata.originRace == "enemy") && !allBattleObj2.isDead && (allBattleObj2.charadata.m_Table == "b01" || SharedData.Instance().FollowList.Contains(allBattleObj2.charadata.m_Id)))
			{
				allBattleObj2.charadata.m_Exp += TotalExp / num;
			}
		}
		LevelUpCheckProcess();
	}

	public void SeparateExp(string _died_pal, int _total_exp)
	{
		int num = 0;
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (!(allBattleObj.charadata.originRace == "enemy") && !(allBattleObj.race == "enemy") && !allBattleObj.isDead && (!(allBattleObj.charadata.m_Table == "b04") || SharedData.Instance().FollowList.Contains(allBattleObj.charadata.m_Id)))
			{
				num++;
			}
		}
		num = 1;
		if (num <= 0)
		{
			return;
		}
		int num2 = Mathf.CeilToInt(_total_exp / num);
		foreach (BattleObject allBattleObj2 in allBattleObjs)
		{
			if (!(allBattleObj2.charadata.originRace == "enemy") && !(allBattleObj2.race == "enemy") && !allBattleObj2.isDead && (!(allBattleObj2.charadata.m_Table == "b04") || SharedData.Instance().FollowList.Contains(allBattleObj2.charadata.m_Id)) && !(allBattleObj2 != current))
			{
				allBattleObj2.charadata.m_Exp += num2;
			}
		}
	}

	private void UpdateActionOrder()
	{
		actionOrder.Clear();
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			actionOrder.Add(new ActionOrderItem(allBattleObj, ActionType.None));
		}
		actionOrder.Sort((ActionOrderItem a, ActionOrderItem b) => b.battleObject.charadata.GetBattleValueByName("SP").CompareTo(a.battleObject.charadata.GetBattleValueByName("SP")));
	}

	private BattleObject GetNextBattleObject()
	{
		BattleObject battleObjectAfter = GetBattleObjectAfter();
		while (battleObjectAfter.isDead)
		{
			battleObjectAfter = GetBattleObjectAfter();
		}
		return battleObjectAfter;
	}

	private BattleObject GetBattleObjectAfter()
	{
		ActionOrderItem actionOrderItem = null;
		if (ExtraActionOrder.Count != 0)
		{
			actionOrderItem = ExtraActionOrder[0];
			currentActionObj = ExtraActionOrder[0];
			if (actionOrderItem.counterType != 0 && actionOrderItem.counterType != ActionType.WugongAssist && actionOrderItem.counterType != ActionType.RoleAssist && actionOrderItem.counterType != ActionType.Runaway && actionOrderItem.counterType != ActionType.Multikill)
			{
				switch (actionOrderItem.counterType)
				{
				case ActionType.Formless:
				case ActionType.FormlessSuper:
					SetFlowState(BattleControllerFlow.FormlessProcess);
					break;
				case ActionType.WugongCounter:
					SetFlowState(BattleControllerFlow.WugongCounterProcess);
					break;
				case ActionType.Return:
					SetFlowState(BattleControllerFlow.ReturnProcess);
					break;
				case ActionType.Ambush:
				case ActionType.Fantan:
					SetFlowState(BattleControllerFlow.AmbushProcess);
					break;
				}
				actionOrderItem.battleObject.m_Revenge_Target = m_Revenge_TGT;
				if (actionOrderItem.battleObject.charadata.originRace == "player")
				{
					_ = actionOrderItem.battleObject.race == "player";
				}
			}
			currentActionObj = ExtraActionOrder[0];
			ExtraActionOrder.RemoveAt(0);
			return currentActionObj.battleObject;
		}
		if (++currentActionOrderIndex > actionOrder.Count - 1)
		{
			currentActionOrderIndex = 0;
			m_TurnCount++;
			UpdateTerrain();
			UpdateActionOrder();
			actionOrderItem = actionOrder[currentActionOrderIndex];
			m_MenuController.TurnDisp.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Round") + " <color=#E3D1AD><size=35>" + m_TurnCount + "</size></color>";
		}
		else
		{
			actionOrderItem = actionOrder[currentActionOrderIndex];
		}
		currentActionObj = actionOrderItem;
		return actionOrderItem.battleObject;
	}

	private void CalNextActionIcon()
	{
		bool flag = false;
		int num = 0;
		int num2 = actionOrder.FindIndex((ActionOrderItem x) => x.battleObject == current);
		for (int i = num2; i < actionOrder.Count; i++)
		{
			if (!actionOrder[i].battleObject.isDead && actionOrder[i].battleObject.isSelectable)
			{
				num++;
				if (num == 2)
				{
					flag = true;
					actionOrder[i].battleObject.ShowNextActionIcon();
					break;
				}
			}
		}
		if (flag)
		{
			return;
		}
		for (int j = 0; j < num2; j++)
		{
			if (!actionOrder[j].battleObject.isDead && actionOrder[j].battleObject.isSelectable)
			{
				num++;
				if (num == 2)
				{
					actionOrder[j].battleObject.ShowNextActionIcon();
					break;
				}
			}
		}
	}

	public void ShowAllHpGuage(bool isShowActionOrder = false)
	{
		if (isShowAllHp)
		{
			return;
		}
		isShowAllHp = true;
		int num = 0;
		int num2 = actionOrder.FindIndex((ActionOrderItem x) => x.battleObject == current);
		for (int i = num2; i < actionOrder.Count; i++)
		{
			if (!actionOrder[i].battleObject.isDead && actionOrder[i].battleObject.isSelectable)
			{
				actionOrder[i].battleObject.ShowHpGauge();
				if (isShowActionOrder)
				{
					actionOrder[i].battleObject.ShowActionOrder(num++);
				}
				actionOrder[i].battleObject.ShowIsPokemon();
			}
		}
		for (int j = 0; j < num2; j++)
		{
			if (!actionOrder[j].battleObject.isDead && actionOrder[j].battleObject.isSelectable)
			{
				actionOrder[j].battleObject.ShowHpGauge();
				if (isShowActionOrder)
				{
					actionOrder[j].battleObject.ShowActionOrder(num++);
				}
				actionOrder[j].battleObject.ShowIsPokemon();
			}
		}
	}

	public void ShowHpGaugeInAttackRange()
	{
		HideAllHpGuage();
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.isDead || !allBattleObj.isSelectable)
			{
				continue;
			}
			if (current.m_AttackType[3] == "2")
			{
				if (current.race == allBattleObj.race && current.attackSelectRange.Contains(allBattleObj.GetGridPosition()))
				{
					allBattleObj.ShowHpGauge();
				}
			}
			else if (current.race != allBattleObj.race && current.attackSelectRange.Contains(allBattleObj.GetGridPosition()))
			{
				allBattleObj.ShowHpGauge();
			}
		}
	}

	public void HideAllHpGuage()
	{
		isShowAllHp = false;
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (!allBattleObj.isDead)
			{
				allBattleObj.HideHpGuageImmediate();
				allBattleObj.CloseActionOrder();
				allBattleObj.CloseIsPokemon();
			}
		}
		CalNextActionIcon();
	}

	private bool JudgeIsDeadCouseJumpToStarPoint(BattleObject battleObject)
	{
		if (battleObject != current)
		{
			return false;
		}
		if (battleObject.charadata.m_Hp > 0f)
		{
			return false;
		}
		if (battleObject.race == "player" && (battleObject.m_State == BattleObjectState.AStarMoving || battleObject.m_State == BattleObjectState.AStarWaiting) && !AutoBattle)
		{
			current.SetBattleObjState(BattleObjectState.None);
			SetFlowState(BattleControllerFlow.None);
			RoundReSet();
			return true;
		}
		return false;
	}

	public void InvisibleEffectOn()
	{
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			bool invisible = false;
			BuffData buffByName = allBattleObj.GetBuffByName("Invisible");
			if (buffByName != null && buffByName.turn >= 0)
			{
				invisible = true;
			}
			allBattleObj.SetInvisible(invisible);
		}
		if (current.race == "enemy" && current.GetBuffByName("Invisible") != null && current.GetBuffByName("Invisible").turn >= 0)
		{
			m_curcor.gameObject.GetComponentInChildren<SpriteRenderer>().enabled = false;
		}
		else
		{
			m_curcor.gameObject.GetComponentInChildren<SpriteRenderer>().enabled = true;
		}
	}

	private void SelectItemTarget()
	{
		m_MenuController.ClearAttackMenu();
		m_MenuController.m_menuState = BattleMenuState.WugongListShow;
		current.SelectWuGong("ITEM|C|01|2|0");
		SetFlowState(BattleControllerFlow.ActionWaitAttack);
		m_curcor.ResetCurcorPosition();
		Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position);
		m_curcor.CurcorPosition(new Vector3Int(vector3Int.x, -vector3Int.y, 0), pressing: true);
	}

	public void RoundReSet()
	{
		new Stopwatch().Restart();
		if (!current.isBeEffectInMovingStage)
		{
			Vector3 localPosition = new Vector3((float)current.handInPos.x * CommonVariables.MovementBlockSize + 25f, (float)(-current.handInPos.y) * CommonVariables.MovementBlockSize - 25f);
			current.transform.localPosition = localPosition;
			current.SetBattleObjState(BattleObjectState.WaitingForInput);
			SetFlowState(BattleControllerFlow.MoveWait);
			SetCameraSmooth(current, isSetCurcor: true);
			m_curcor.SwitchCurcorSelected(current);
			current.PlayAnimation(Aniname.aniname_stand);
			m_MenuController.m_menuState = BattleMenuState.AutoBattleShow;
		}
		else
		{
			current.SetBattleObjState(BattleObjectState.None);
			SetFlowState(BattleControllerFlow.None);
			LoadSpecialRecord(m_RoundStartRecord, _clearRange: true, isCalBeEffectInMovingStage: true);
		}
	}

	private void AutoActionWait()
	{
		if (current.currentForecast != null && current.currentForecast.actionName != null)
		{
			_ = current.currentForecast.actionPos;
			_ = current.currentForecast.targetPos;
			RangeManager.ShowAttackSelectRange(current, current.currentForecast.targetPos);
			if (current.attackSelectRange.Count == 0)
			{
				SetFlowState(BattleControllerFlow.RoundOff);
				current.SetBattleObjState(BattleObjectState.RoundOff);
			}
			else
			{
				SetFlowState(BattleControllerFlow.None);
				StartCoroutine(AutoActionWait_CallBack(current.currentForecast.targetPos));
			}
		}
		else
		{
			SetFlowState(BattleControllerFlow.RoundOff);
			current.SetBattleObjState(BattleObjectState.RoundOff);
		}
	}

	private IEnumerator AutoActionWait_CallBack(Vector3Int _attackPos)
	{
		yield return new WaitForSeconds(0.25f);
		if (current.isDead)
		{
			SetFlowState(BattleControllerFlow.RoundOff);
			current.SetBattleObjState(BattleObjectState.RoundOff);
		}
		else
		{
			SetFlowState(BattleControllerFlow.Action);
			current.Attack(_attackPos);
		}
	}

	public void RecoveryCurrentMp(bool isForceHealMP = false)
	{
		SetFlowState(BattleControllerFlow.RoundOff);
		current.SetBattleObjState(BattleObjectState.RoundOff);
		if (isForceHealMP || current.handInPos == current.GetGridPosition())
		{
			float num = saturate(current.charadata.GetBattleValueByName("Hurt") / 255f);
			float num2 = Mathf.Floor(current.charadata.GetBattleValueByName("MP") * (1f - num));
			if (current.charadata.m_Mp < num2 && !current.CheckBuffEffectOn("Dizzy"))
			{
				float num3 = Mathf.Floor(num2 / 10f);
				current.AddDamageInfo(num3.ToString(), "HEALMP");
			}
		}
	}

	public void RebellionProcess(BattleObject curTarget, RebellionType _rebellionType = RebellionType.None, int _turn = 0)
	{
		List<string> list = CommonResourcesData.b10.Find_ID("1001").Members.Split("|").ToList();
		if (curTarget.charadata.m_B01Id != "" && list.Contains("curTarget.charadata.m_B01Id"))
		{
			curTarget.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_ImAnimal"), "");
			return;
		}
		if (curTarget.charadata.GetBattleValueByName("Mad") >= 25f)
		{
			curTarget.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Mad"), "");
			return;
		}
		int num = 0;
		switch (_rebellionType)
		{
		case RebellionType.Bribe:
		{
			int num3 = 0;
			float fieldValueByName4 = curTarget.charadata.GetFieldValueByName("MOR");
			num3 = ((!(fieldValueByName4 >= 20f) && !(SharedData.Instance().m_MoneyForAttack / 100f < fieldValueByName4)) ? ((int)(SharedData.Instance().m_MoneyForAttack / 100f - fieldValueByName4) + 1) : 0);
			num = ((num3 > 3) ? 3 : num3);
			break;
		}
		case RebellionType.Charm:
		{
			int num2 = 0;
			float fieldValueByName = current.charadata.GetFieldValueByName("MOR");
			float fieldValueByName2 = curTarget.charadata.GetFieldValueByName("MOR");
			float fieldValueByName3 = curTarget.charadata.GetFieldValueByName("WIL");
			if (fieldValueByName > fieldValueByName2)
			{
				if (fieldValueByName == fieldValueByName3)
				{
					if (UnityEngine.Random.Range(0f, 1f) < 0.5f)
					{
						num2 = int.MaxValue;
					}
				}
				else if (fieldValueByName > fieldValueByName3)
				{
					num2 = int.MaxValue;
				}
			}
			num = num2;
			break;
		}
		case RebellionType.Temptation:
			num = _turn;
			break;
		case RebellionType.ControlMad:
			num = _turn;
			break;
		case RebellionType.SaveMad:
			num = int.MaxValue;
			return;
		}
		if (Rebellion(curTarget, num, _rebellionType))
		{
			curTarget.DeleteRebellionInfo();
			if (num != int.MaxValue)
			{
				curTarget.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Rebellin") + " " + num + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round"), "");
			}
			else
			{
				curTarget.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_RebellionForever"), "");
			}
			if (_rebellionType == RebellionType.SaveMad)
			{
				curTarget.charadata.Indexs_Name["Mad"].fightValue = 0f;
			}
		}
		else
		{
			curTarget.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Failed"), "");
		}
	}

	public bool Rebellion(BattleObject _target, int _rebellionRoundNumber = 0, RebellionType _rebellionType = RebellionType.None, bool _force = false)
	{
		if (_target.charadata.m_KeyPos != 0)
		{
			return false;
		}
		if (_rebellionRoundNumber <= 0 && !_force)
		{
			return false;
		}
		if (_target.isDead)
		{
			return false;
		}
		if (_target.race == "enemy")
		{
			_target.race = "player";
			_target.rebellionRoundNumber = _rebellionRoundNumber;
			_target.rebellionType = _rebellionType;
			_target.player_marker.SetActive(value: true);
			_target.enemy_marker.SetActive(value: false);
		}
		else
		{
			_target.race = "enemy";
			_target.rebellionRoundNumber = _rebellionRoundNumber;
			_target.rebellionType = _rebellionType;
			_target.player_marker.SetActive(value: false);
			_target.enemy_marker.SetActive(value: true);
		}
		if (_rebellionType == RebellionType.Temptation || _rebellionType == RebellionType.Bribe || _rebellionType == RebellionType.ControlMad)
		{
			_target.player_marker.SetActive(value: true);
			_target.enemy_marker.SetActive(value: true);
		}
		return true;
	}

	public void LevelUpCheckProcess()
	{
		int num = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.charadata.originRace == "enemy" || allBattleObj.race == "enemy" || allBattleObj.isDead || (allBattleObj.charadata.m_Table == "b04" && !SharedData.Instance().FollowList.Contains(allBattleObj.charadata.m_Id)))
			{
				continue;
			}
			bool flag = false;
			if (allBattleObj.charadata.m_Level < num)
			{
				if (current.Equals(allBattleObj))
				{
					allBattleObj.charadata.m_Exp += allBattleObj.m_FinalAddExp;
					allBattleObj.m_FinalAddExp = 0;
				}
				int num2 = int.Parse(CommonResourcesData.a05.Find_LV(allBattleObj.charadata.m_Level.ToString()).EXP);
				if (allBattleObj.charadata.m_Exp >= num2)
				{
					flag = true;
					if (allBattleObj.charadata.m_Level < num)
					{
						allBattleObj.charadata.m_Exp = allBattleObj.charadata.m_Exp - num2;
					}
					else
					{
						allBattleObj.charadata.m_Exp = 0;
					}
				}
			}
			if (flag && !SharedData.Instance().levelupObjList.Contains(allBattleObj.charadata))
			{
				SharedData.Instance().levelupObjList.Add(allBattleObj.charadata);
			}
		}
		if (SharedData.Instance().levelupObjList.Count > 0)
		{
			current.SetBattleObjState(BattleObjectState.LevelUp);
			ShowLevelUp();
		}
		else
		{
			current.SetBattleObjState(BattleObjectState.ActionOverPost);
		}
	}

	public void AddTerrain(Vector3Int targetPos, TerrainType t_type, float _damageRate = 0f)
	{
		bool isPersistent = false;
		GameObject original = null;
		if (obstacle.Contains(targetPos) && (t_type == TerrainType.Hell || t_type == TerrainType.Water))
		{
			obstacle.Remove(targetPos);
		}
		if (itemUnits.ContainsValue(targetPos))
		{
			UnityEngine.Debug.Log("AddTerrain Fail: targetPos has already in itemUnits");
		}
		if (terrain.ContainsKey(targetPos) && terrain[targetPos].t_type != 0 && terrain[targetPos].t_type != TerrainType.Water)
		{
			UnityEngine.Object.Destroy(terrain[targetPos].gameObject);
			terrain.Remove(targetPos);
		}
		if (terrain.ContainsKey(targetPos) && (terrain[targetPos].t_type == TerrainType.Hell || terrain[targetPos].t_type == TerrainType.Water))
		{
			UnityEngine.Debug.Log("AddTerrain Fail: targetPos is Hell or Water");
			return;
		}
		switch (t_type)
		{
		case TerrainType.Hell:
			original = CommonResourcesData.Terrain_Fall_Prefab;
			break;
		case TerrainType.Water:
			original = CommonResourcesData.Terrain_WaterFall_Prefab;
			break;
		case TerrainType.FireLv1:
			original = CommonResourcesData.Terrain_FireLv1_Prefab;
			break;
		case TerrainType.FireLv2:
			original = CommonResourcesData.Terrain_FireLv2_Prefab;
			break;
		case TerrainType.FirePersistent:
			original = CommonResourcesData.Terrain_FirePersistent_Prefab;
			break;
		case TerrainType.PoisonLv1:
			original = CommonResourcesData.Terrain_PoisonLv1_Prefab;
			break;
		case TerrainType.PoisonLv2:
			original = CommonResourcesData.Terrain_PoisonLv2_Prefab;
			break;
		case TerrainType.PoisonPersistent:
			original = CommonResourcesData.Terrain_PoisonPersistent_Prefab;
			break;
		case TerrainType.TrapSeal:
			original = CommonResourcesData.Terrain_TrapSeal_Prefab;
			break;
		case TerrainType.TrapBlast:
			original = CommonResourcesData.Terrain_TrapBlast_Prefab;
			break;
		}
		if (t_type == TerrainType.FirePersistent || t_type == TerrainType.PoisonPersistent || t_type == TerrainType.TrapSeal || t_type == TerrainType.TrapBlast || t_type == TerrainType.Hell || t_type == TerrainType.Water)
		{
			isPersistent = true;
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(original, map.transform);
		if (t_type == TerrainType.Hell || t_type == TerrainType.Water)
		{
			gameObject.SetActive(value: false);
		}
		gameObject.transform.localPosition = new Vector3(25 + targetPos.x * 50, -25 - targetPos.y * 50);
		gameObject.GetComponent<TerrainController>().t_type = t_type;
		gameObject.GetComponent<TerrainController>().isPersistent = isPersistent;
		if (gameObject.GetComponent<SpriteRenderer>() != null)
		{
			gameObject.GetComponent<SpriteRenderer>().sortingOrder = m_underfoot_SortingOrder;
		}
		else if (gameObject.GetComponent<MeshRenderer>() != null)
		{
			gameObject.GetComponent<MeshRenderer>().sortingOrder = m_underfoot_SortingOrder;
		}
		if (current != null)
		{
			gameObject.GetComponent<TerrainController>().m_BlastSputterATKup = current.charadata.GetBattleValueByName("BlastSputterATKup");
			gameObject.GetComponent<TerrainController>().m_BlastAttackDizzy = current.charadata.GetBattleValueByName("BlastAttackDizzy");
			gameObject.GetComponent<TerrainController>().m_BlastSputterAttackDizzy = current.charadata.GetBattleValueByName("BlastSputterAttackDizzy");
		}
		if (_damageRate != 0f)
		{
			gameObject.GetComponent<TerrainController>().damageValue = _damageRate;
		}
		terrain.Add(targetPos, gameObject.GetComponent<TerrainController>());
	}

	public void DestoryTerrain(Vector3Int targetPos)
	{
		if (!terrain.ContainsKey(targetPos))
		{
			Vector3Int vector3Int = targetPos;
			UnityEngine.Debug.Log("DestoryTerrain Fail: targetPos = " + vector3Int.ToString() + "not have effect");
		}
		else
		{
			UnityEngine.Object.Destroy(terrain[targetPos].gameObject);
			terrain.Remove(targetPos);
		}
	}

	private void UpdateTerrain()
	{
		if (m_TurnCount == 1)
		{
			return;
		}
		List<Vector3Int> list = new List<Vector3Int>();
		foreach (KeyValuePair<Vector3Int, TerrainController> item in terrain)
		{
			if (item.Value.t_type != TerrainType.TrapBlast && item.Value.t_type != TerrainType.TrapSeal && item.Value.t_type != 0 && item.Value.t_type != TerrainType.Water && !item.Value.isPersistent && ++item.Value.terrainKeepTime > UnityEngine.Random.Range(TerrainKeepRoundTimesMin, TerrainKeepRoundTimesMax))
			{
				list.Add(item.Key);
			}
		}
		foreach (Vector3Int item2 in list)
		{
			DestoryTerrain(item2);
		}
		float num = 0.1f;
		List<Vector3Int> list2 = new List<Vector3Int>(terrain.Keys);
		int count = list2.Count;
		for (int i = 0; i < count; i++)
		{
			TerrainController terrainController = terrain[list2[i]];
			if (terrainController.t_type != 0 && terrainController.t_type != TerrainType.Water && !terrainController.t_type.ToString().Contains("Trap"))
			{
				Vector3Int gridPosition = terrainController.GetGridPosition();
				Vector3Int vector3Int = gridPosition + Vector3Int.up;
				Vector3Int vector3Int2 = gridPosition + Vector3Int.down;
				Vector3Int vector3Int3 = gridPosition + Vector3Int.right;
				Vector3Int vector3Int4 = gridPosition + Vector3Int.left;
				TerrainType t_type = TerrainType.UNKNOWN;
				if (terrainController.t_type.ToString().Contains("Fire"))
				{
					t_type = TerrainType.FireLv1;
				}
				else if (terrainController.t_type.ToString().Contains("Poison"))
				{
					t_type = TerrainType.PoisonLv1;
				}
				if (UnityEngine.Random.Range(0f, 1f) < num && obstacle.Contains(vector3Int) && !terrain.ContainsKey(vector3Int))
				{
					AddTerrain(vector3Int, t_type);
				}
				if (UnityEngine.Random.Range(0f, 1f) < num && obstacle.Contains(vector3Int2) && !terrain.ContainsKey(vector3Int2))
				{
					AddTerrain(vector3Int2, t_type);
				}
				if (UnityEngine.Random.Range(0f, 1f) < num && obstacle.Contains(vector3Int3) && !terrain.ContainsKey(vector3Int3))
				{
					AddTerrain(vector3Int3, t_type);
				}
				if (UnityEngine.Random.Range(0f, 1f) < num && obstacle.Contains(vector3Int4) && !terrain.ContainsKey(vector3Int4))
				{
					AddTerrain(vector3Int4, t_type);
				}
			}
		}
	}

	private void StartSaveRecordThreadedTask()
	{
		if (IsSaveRoundRecordRunning)
		{
			UnityEngine.Debug.LogWarning("正在存档中");
		}
		else
		{
			GetOneRoundRecord();
		}
	}

	private void StartLoadRecordThreadedTask(RoundRecord roundRecord, bool _clearRange = false)
	{
		if (IsLoadRoundRecordRunning)
		{
			UnityEngine.Debug.LogWarning("正在读档中");
			return;
		}
		IsLoadRoundRecordRunning = true;
		LoadSpecialRecord(roundRecord, _clearRange);
	}

	public void BackPrevRound()
	{
		if (currentRecordIndex >= 0)
		{
			RoundRecord roundRecord = m_RoundRecordList[currentRecordIndex];
			currentRecordIndex--;
			m_RoundStartRecord = roundRecord;
			LoadSpecialRecord(roundRecord, _clearRange: true);
			m_curcor.SetPosition(current);
			m_curcor.SwitchCurcorSelected(current);
		}
	}

	public void LoadSpecialRecord(RoundRecord roundRecord, bool _clearRange = false, bool isCalBeEffectInMovingStage = false)
	{
		IsLoadRoundRecordRunning = true;
		SharedData.Instance().PlayerPackage.Clear();
		foreach (KeyValuePair<string, int> item in roundRecord.m_Package)
		{
			SharedData.Instance().PlayerPackage.Add(item.Key, item.Value);
		}
		SharedData.Instance().m_Money = roundRecord.m_Money;
		m_TurnCount = roundRecord.roundNum;
		m_MenuController.TurnDisp.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Round") + " <color=#E3D1AD><size=35>" + m_TurnCount + "</size></color>";
		foreach (KeyValuePair<Vector3Int, TerrainController> item2 in terrain)
		{
			UnityEngine.Object.DestroyImmediate(item2.Value.gameObject);
		}
		terrain.Clear();
		foreach (TerrainData terrainData in roundRecord.m_BattleControllerData.terrainDatas)
		{
			AddTerrain(terrainData.m_pos, terrainData.t_type);
			TerrainController terrainController = terrain[terrainData.m_pos];
			terrainController.terrainKeepTime = terrainData.terrainKeepTime;
			terrainController.isPersistent = terrainData.isPersistent;
			terrainController.loopRun = terrainData.loopRun;
			terrainController.damageValue = terrainData.damageValue;
			terrainController.isBlasting = terrainData.isBlasting;
			terrainController.m_BlastSputterATKup = terrainData.m_BlastSputterATKup;
			terrainController.m_BlastAttackDizzy = terrainData.m_BlastAttackDizzy;
			terrainController.m_BlastSputterAttackDizzy = terrainData.m_BlastSputterAttackDizzy;
		}
		for (int num = allBattleObjs.Count - 1; num >= 0; num--)
		{
			BattleObject tmp = allBattleObjs[num];
			if (!(!tmp.isBeEffectInMovingStage && isCalBeEffectInMovingStage))
			{
				BattleObjectData battleObjectData = null;
				battleObjectData = roundRecord.m_BattleObjectDataList.Find((BattleObjectData x) => x.gameObjID == tmp.gameObjID);
				if (battleObjectData == null)
				{
					allBattleObjs.Remove(tmp);
					UnityEngine.Object.DestroyImmediate(tmp);
				}
				else
				{
					tmp.m_BuffList.Clear();
					tmp.m_DamageList.Clear();
					tmp.m_StealableItemsNum = battleObjectData.m_StealableItemsNum;
					tmp.race = battleObjectData.race;
					tmp.isDead = battleObjectData.isDead;
					tmp.isEscape = battleObjectData.isEscape;
					tmp.isUnSealNextRound = battleObjectData.isUnSealNextRound;
					tmp.charadata._CharaDataBasic = MessagePackSerializer.Deserialize<CharaDataBasic>(MessagePackSerializer.Serialize(battleObjectData.charaDataBasic));
					foreach (KeyValuePair<string, AtomData> item3 in tmp.charadata._CharaDataBasic.Indexs_Name)
					{
						item3.Value._charaData = tmp.charadata;
					}
					tmp.m_State = BattleObjectState.HandOut;
					tmp.aliveRoundNumber = battleObjectData.aliveRoundNumber;
					tmp.isSealFreeze = battleObjectData.isSealFreeze;
					tmp.m_Direction = battleObjectData.m_Direction;
					tmp.isInvisible = battleObjectData.isInvisible;
					tmp.isSelectable = battleObjectData.isSelectable;
					tmp.isBeEffectInMovingStage = false;
					tmp.LoadRecordPost(_clearRange);
					tmp.transform.position = battleObjectData.pos;
					tmp.handInPos = tmp.GetGridPosition();
				}
			}
		}
		InvisibleEffectOn();
		actionOrder.Clear();
		ExtraActionOrder.Clear();
		foreach (ActionOrderRecord tmp in roundRecord.m_BattleControllerData.actionOrder)
		{
			BattleObject battleObject = allBattleObjs.Find((BattleObject x) => x.gameObjID == tmp.objID);
			if (battleObject == null)
			{
				UnityEngine.Debug.LogWarning("丢失战斗数据存档角色:正常顺序");
			}
			else
			{
				actionOrder.Add(new ActionOrderItem(battleObject, tmp.actionType));
			}
		}
		foreach (ActionOrderRecord tmp in roundRecord.m_BattleControllerData.ExtraActionOrder)
		{
			BattleObject battleObject2 = allBattleObjs.Find((BattleObject x) => x.gameObjID == tmp.objID);
			if (battleObject2 == null)
			{
				UnityEngine.Debug.LogWarning("丢失战斗数据存档角色:额外数据");
			}
			else
			{
				ExtraActionOrder.Add(new ActionOrderItem(battleObject2, tmp.actionType));
			}
		}
		currentActionOrderIndex = roundRecord.m_BattleControllerData.currentActionOrderIndex;
		if (isCalBeEffectInMovingStage)
		{
			SetFlowState(BattleControllerFlow.Interlude);
		}
		IsLoadRoundRecordRunning = false;
	}

	public void RecordCurrentRoundInfo()
	{
		m_RoundRecordList.RemoveRange(currentRecordIndex + 1, m_RoundRecordList.Count - currentRecordIndex - 1);
		currentRecordIndex++;
		StartSaveRecordThreadedTask();
	}

	private void GetOneRoundRecord()
	{
		IsSaveRoundRecordRunning = true;
		new Stopwatch().Restart();
		RoundRecord roundRecord = new RoundRecord();
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			BattleObjectData battleObjectData = new BattleObjectData();
			byte[] array = MessagePackSerializer.Serialize(allBattleObj.charadata._CharaDataBasic);
			battleObjectData.charaDataBasic = MessagePackSerializer.Deserialize<CharaDataBasic>(array);
			battleObjectData.gameObjID = allBattleObj.gameObjID;
			battleObjectData.pos = allBattleObj.transform.position;
			battleObjectData.m_StealableItemsNum = new List<int>(allBattleObj.m_StealableItemsNum);
			battleObjectData.race = allBattleObj.race;
			battleObjectData.isDead = allBattleObj.isDead;
			battleObjectData.isEscape = allBattleObj.isEscape;
			battleObjectData.isUnSealNextRound = allBattleObj.isUnSealNextRound;
			battleObjectData.m_State = allBattleObj.m_State;
			battleObjectData.aliveRoundNumber = allBattleObj.aliveRoundNumber;
			battleObjectData.isSealFreeze = allBattleObj.isSealFreeze;
			battleObjectData.m_Direction = allBattleObj.m_Direction;
			battleObjectData.isInvisible = allBattleObj.isInvisible;
			battleObjectData.isSelectable = allBattleObj.isSelectable;
			roundRecord.m_BattleObjectDataList.Add(battleObjectData);
		}
		roundRecord.m_BattleControllerData = new BattleControllerData();
		foreach (KeyValuePair<Vector3Int, TerrainController> item in terrain)
		{
			TerrainData terrainData = MessagePackSerializer.Deserialize<TerrainData>(MessagePackSerializer.Serialize(item.Value._TerrainData));
			terrainData.m_pos = item.Key;
			roundRecord.m_BattleControllerData.terrainDatas.Add(terrainData);
		}
		roundRecord.m_BattleControllerData.m_BattleControllerFlow = m_Flow;
		roundRecord.m_BattleControllerData.m_BattleMenuState = m_MenuController.m_menuState;
		if (ExtraActionOrder != null)
		{
			foreach (ActionOrderItem item2 in ExtraActionOrder)
			{
				roundRecord.m_BattleControllerData.ExtraActionOrder.Add(new ActionOrderRecord(item2.battleObject.gameObjID, item2.counterType));
			}
		}
		if (actionOrder != null)
		{
			foreach (ActionOrderItem item3 in actionOrder)
			{
				roundRecord.m_BattleControllerData.actionOrder.Add(new ActionOrderRecord(item3.battleObject.gameObjID, item3.counterType));
			}
		}
		roundRecord.m_BattleControllerData.currentActionOrderIndex = currentActionOrderIndex - 1;
		foreach (KeyValuePair<string, int> item4 in SharedData.Instance().PlayerPackage)
		{
			roundRecord.m_Package.Add(item4.Key, item4.Value);
		}
		roundRecord.m_Money = SharedData.Instance().m_Money;
		roundRecord.roundNum = m_TurnCount;
		m_RoundStartRecord = roundRecord;
		if (m_FirstRecord == null)
		{
			m_FirstRecord = roundRecord;
		}
		if (m_FirstAutoRecord == null)
		{
			m_FirstAutoRecord = roundRecord;
		}
		m_RoundRecordList.Add(roundRecord);
		IsSaveRoundRecordRunning = false;
	}

	public void ReLoadBattle()
	{
		LoadSpecialRecord(m_FirstRecord);
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			allBattleObj.charadata.CleanFightValues();
		}
		SharedData.Instance().PlayerSetting.Clear();
		SharedData.Instance().EnemySetting.Clear();
		if (MapController.enemygid[0] == "solo")
		{
			SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
			LoadScene(SharedData.Instance().BattleGround);
		}
		else if (MapController.enemygid[0] == "demo")
		{
			SharedData.Instance().b04BattleID = MapController.enemygid[1];
			LoadScene(SharedData.Instance().BattleGround);
		}
		else if (MapController.enemygid[0] == "event")
		{
			SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
			SharedData.Instance().b04BattleID = MapController.enemygid[1];
			SharedData.Instance().m_EventShow = true;
			LoadScene(SharedData.Instance().BattleGround);
		}
		else if (MapController.enemygid[0] == "chara")
		{
			SharedData.Instance().PlayerSetting.Add("Player1", MapController.enemygid[2]);
			SharedData.Instance().b04BattleID = MapController.enemygid[1];
			SharedData.Instance().m_EventShow = true;
			LoadScene(SharedData.Instance().BattleGround);
		}
		else if (MapController.enemygid[0] == "arena")
		{
			SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
			SharedData.Instance().b04BattleID = SharedData.Instance().m_ArenaFightID;
			SharedData.Instance().m_EventShow = true;
			LoadScene(SharedData.Instance().BattleGround);
		}
		else if (MapController.enemygid[0] == "datianwang")
		{
			SharedData.Instance().b04BattleID = SharedData.Instance().m_ArenaFightID;
			LoadScene("BeforeBattle");
		}
		else if (MapController.enemygid[0] == "duel")
		{
			SharedData.Instance().DuelBattleGuild = MapController.enemygid[1];
			LoadScene("BeforeDuelBattle");
		}
		else
		{
			if (MapController.enemygid.Length > 1 && "force".Equals(MapController.enemygid[1]))
			{
				SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
			}
			LoadScene("BeforeBattle");
		}
	}

	public ActionType GetCurrentObjActionType()
	{
		return currentActionObj.counterType;
	}

	public bool isRoundActionFinish()
	{
		if (m_MenuController.m_InteruptInfo.gameObject.activeInHierarchy)
		{
			return false;
		}
		if (!isPlayEffectFinish)
		{
			return false;
		}
		foreach (EffectController effectController in m_EffectControllerList)
		{
			if (effectController != null)
			{
				return false;
			}
		}
		if (!CheckisBlastTrapChainFinish())
		{
			return false;
		}
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.m_DamageList.Find((DisplayDamage x) => !x.isShow) != null || allBattleObj.m_BuffList.Find((DisplayBuff x) => !x.isShow) != null || allBattleObj.isPerforming || !allBattleObj.InitOK)
			{
				return false;
			}
		}
		return true;
	}

	public List<BattleObject> GetGridNeighborBattleObjects(Vector3Int _target, bool _inIncludeDead = true)
	{
		List<BattleObject> list = new List<BattleObject>();
		foreach (Vector3Int tmp in GetGridNeighbors(_target))
		{
			BattleObject battleObject = allBattleObjs.Find((BattleObject x) => (x.GetGridPosition() == tmp && _inIncludeDead) || !x.isDead);
			if (battleObject != null)
			{
				list.Add(battleObject);
			}
		}
		return list;
	}

	public List<Vector3Int> GetGridNeighbors(Vector3Int target)
	{
		List<Vector3Int> list = new List<Vector3Int>();
		Vector3Int item = target + Vector3Int.up;
		Vector3Int item2 = target + Vector3Int.right;
		Vector3Int item3 = target - Vector3Int.right;
		Vector3Int item4 = target - Vector3Int.up;
		if (item.y < mapSize.y && obstacle.Contains(item))
		{
			list.Add(item);
		}
		if (item2.x < mapSize.x && obstacle.Contains(item2))
		{
			list.Add(item2);
		}
		if (item3.x >= 0 && obstacle.Contains(item3))
		{
			list.Add(item3);
		}
		if (item4.y >= 0 && obstacle.Contains(item4))
		{
			list.Add(item4);
		}
		return list;
	}

	public BattleObject GetBattleObjectInPos(Vector3Int pos, BattleObject self = null)
	{
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.GetGridPosition() == pos && allBattleObj != self && !allBattleObj.isDead)
			{
				return allBattleObj;
			}
		}
		return null;
	}

	public BattleObject GetBattleObjectInPos(Vector3 pos, BattleObject self = null)
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(pos.x / CommonVariables.MovementBlockSize);
		zero.y = Mathf.FloorToInt(Mathf.Abs(pos.y) / CommonVariables.MovementBlockSize);
		foreach (BattleObject allBattleObj in allBattleObjs)
		{
			if (allBattleObj.GetGridPosition() == zero && allBattleObj != self && !allBattleObj.isDead)
			{
				return allBattleObj;
			}
		}
		return null;
	}

	public void LoadScene(string _scenename)
	{
		if (transition != null)
		{
			StartCoroutine(LoadLevel(_scenename));
		}
		else
		{
			SharedData.Instance().ASyncLoadScene(_scenename);
		}
	}

	public void ShowLevelUp()
	{
		if (!isLoadLevelUp)
		{
			isLoadLevelUp = true;
			m_MenuController.m_menuState = BattleMenuState.None;
			SceneManager.LoadScene("LevelUp", LoadSceneMode.Additive);
		}
	}

	public void ShowLevelUpSkill()
	{
		m_MenuController.m_menuState = BattleMenuState.None;
		SceneManager.LoadScene("LevelUpSkill", LoadSceneMode.Additive);
	}

	private IEnumerator LoadLevel(string _scenename)
	{
		transition.SetTrigger("Start");
		yield return new WaitForSeconds(0.5f);
		SharedData.Instance().ASyncLoadScene(_scenename);
	}

	public bool IsBlock(Vector3Int pos, BattleObject _exception = null)
	{
		if (terrain.ContainsKey(pos) && (terrain[pos].t_type == TerrainType.Hell || terrain[pos].t_type == TerrainType.Water))
		{
			return false;
		}
		if (obstacle.Contains(pos) && !(allBattleObjs.Find((BattleObject x) => x.GetGridPosition() == pos && !x.isDead && (!(_exception != null) || x != this)) != null))
		{
			return itemUnits.ContainsValue(pos);
		}
		return true;
	}

	public bool CheckisBlastTrapChainFinish()
	{
		foreach (KeyValuePair<Vector3Int, TerrainController> item in terrain)
		{
			if (item.Value.t_type == TerrainType.TrapBlast && item.Value.isBlasting)
			{
				return false;
			}
		}
		return true;
	}

	public bool CheckIsItemOnGrid(Vector3Int pos)
	{
		bool result = false;
		foreach (KeyValuePair<string, Vector3Int> itemUnit in itemUnits)
		{
			if (pos.Equals(itemUnit.Value))
			{
				result = true;
				break;
			}
		}
		return result;
	}

	public bool CheckIsEnemyOnGrid(Vector3Int pos, BattleObject _battleObj)
	{
		return allBattleObjs.Find((BattleObject x) => x.GetGridPosition() == pos && (!(_battleObj != null) || x.race != _battleObj.race) && !x.isDead && x.isSelectable) != null;
	}

	public bool CheckIsTeammateOnGrid(Vector3Int pos, BattleObject _battleObj)
	{
		return allBattleObjs.Find((BattleObject x) => x.GetGridPosition() == pos && (!(_battleObj != null) || x.race == _battleObj.race) && !x.isDead && x.isSelectable) != null;
	}

	public bool CheckIsBattleObjectOnGrid(Vector3Int pos, BattleObject _battleObj = null)
	{
		return allBattleObjs.Find((BattleObject x) => x != _battleObj && x.GetGridPosition() == pos && !x.isDead && x.isSelectable) != null;
	}

	public void SetCameraTrans(BattleObject _BattleObject, bool isSetCurcor = false)
	{
		m_camera.transform.position = new Vector3(_BattleObject.transform.position.x, _BattleObject.transform.position.y, m_camera.transform.position.z);
		m_CameraTarget = m_camera.transform.position;
		if (isSetCurcor)
		{
			m_curcor.SetPosition(_BattleObject);
		}
	}

	public void SetCameraTrans(Vector3 _pos)
	{
		m_camera.transform.position = _pos;
		m_CameraTarget = m_camera.transform.position;
	}

	public void SetCameraSmooth(BattleObject _BattleObject, bool isSetCurcor = false)
	{
		m_CameraTarget = new Vector3(_BattleObject.transform.position.x, _BattleObject.transform.position.y + CommonVariables.m_cameraOffset, -10f);
		if (isSetCurcor)
		{
			m_curcor.SetPosition(_BattleObject);
		}
	}

	public void SetCameraSmooth(Vector3 _pos)
	{
		m_CameraTarget = _pos;
	}

	public void OpenDartPackage(string _skill_id)
	{
		SharedData.Instance().OpenPackageFor = "DartWugong|" + _skill_id;
		SharedData.Instance().OpenPackageFilter = "0100000000";
		SharedData.Instance().m_BattlePackageStatus = 1;
		SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.BattleField, "01000000000");
		SetFlowState(BattleControllerFlow.PlayerPackOpen);
	}

	public void OpenDartWallet(string _skill_id)
	{
		SharedData.Instance().OpenPackageFor = "DartWugong|" + _skill_id;
		SharedData.Instance().OpenPackageFilter = "0100000000";
		SharedData.Instance().m_BattlePackageStatus = 1;
		if (m_WalletObj == null)
		{
			m_WalletObj = UnityEngine.Object.Instantiate(m_WalletPrefab);
		}
		else
		{
			m_WalletObj.SetActive(value: true);
		}
		SetFlowState(BattleControllerFlow.PlayerPackOpen);
	}

	private void SetOverheadCamera()
	{
		m_camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
		m_camera.transparencySortMode = TransparencySortMode.CustomAxis;
		m_camera.transparencySortAxis = Vector3.up;
		m_CameraTarget = new Vector3((float)map.m_Width / 2f * (float)map.m_TileWidth, (float)(-map.m_Height) / 2f * (float)map.m_TileHeight, -10f);
		m_camera.transform.position = m_CameraTarget;
	}

	public SuperObject[] getByName(string _name)
	{
		List<SuperObject> list = new List<SuperObject>();
		SuperObject[] superObjects = m_SuperObjects;
		foreach (SuperObject superObject in superObjects)
		{
			if (superObject.m_TiledName == _name)
			{
				list.Add(superObject);
			}
		}
		return list.ToArray();
	}

	private SuperObject[] getByType(string _type)
	{
		List<SuperObject> list = new List<SuperObject>();
		SuperObject[] superObjects = m_SuperObjects;
		foreach (SuperObject superObject in superObjects)
		{
			if (superObject.m_Type == _type)
			{
				list.Add(superObject);
			}
		}
		return list.ToArray();
	}

	private float saturate(float _input)
	{
		if (_input > 1f)
		{
			return 1f;
		}
		if (_input < 0f)
		{
			return 0f;
		}
		return _input;
	}

	public void SetFlowState(BattleControllerFlow _in)
	{
		if (_in.Equals(BattleControllerFlow.PlayerMenuClick) || _in.Equals(BattleControllerFlow.PlayerPackOpen))
		{
			InputSystemCustom.Instance().Player.BattleCurcorMove.Disable();
		}
		else
		{
			InputSystemCustom.Instance().Player.BattleCurcorMove.Enable();
		}
		if (_in.Equals(BattleControllerFlow.ActionWaitAttack) && !InputDeviceDetector.instance.isMouseInput)
		{
			EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").Disable();
		}
		else
		{
			EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").Enable();
		}
		if (_in != m_Flow)
		{
			m_Flow = _in;
		}
	}
}
