using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ManualController : MonoBehaviour
{
	public SpriteRenderer pageimage;

	private bool exiting;

	private int pageno = 1;

	private AudioSource m_AudioSource;

	private string startInfo = "";

	private Vector2 mousePos;

	private int changePageTime;

	private float changePageIntervalTime = 0.5f;

	private float timer;

	private bool isContinueChangePage;

	private void Start()
	{
		m_AudioSource = GetComponent<AudioSource>();
		m_AudioSource.PlayDelayed(0.5f);
		startInfo = CommonFunc.I18nGetLocalizedValue("I18N_LangChat_7");
		base.transform.Find("Panel/Info").GetComponent<Text>().text = startInfo;
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExitScene();
		}
		else if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() > 0f && !isContinueChangePage)
		{
			isContinueChangePage = true;
			NextPage();
			if (changePageTime < 4)
			{
				changePageIntervalTime -= 0.1f;
				changePageTime++;
			}
		}
		else if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() < 0f && !isContinueChangePage)
		{
			isContinueChangePage = true;
			PrevPage();
			if (changePageTime < 4)
			{
				changePageIntervalTime -= 0.1f;
				changePageTime++;
			}
		}
		if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() != 0f && timer < changePageIntervalTime)
		{
			timer += Time.deltaTime;
		}
		else
		{
			timer = 0f;
			isContinueChangePage = false;
		}
		if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() == 0f)
		{
			changePageTime = 0;
			changePageIntervalTime = 0.5f;
		}
	}

	public void NextPage()
	{
		pageno++;
		if (pageno > 42)
		{
			pageno = 1;
		}
		if (pageno == 1)
		{
			base.transform.Find("Panel/Info").GetComponent<Text>().text = startInfo;
		}
		else
		{
			base.transform.Find("Panel/Info").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_LangChat_8") + " " + CommonFunc.ShortLangSel(SharedData.Instance().Translate2Hanzi(pageno), pageno.ToString(), SharedData.Instance().Translate2Hanzi(pageno)) + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_9");
		}
		pageimage.sprite = Resources.Load("images/97-manual/shouce (" + pageno + ")", typeof(Sprite)) as Sprite;
	}

	public void PrevPage()
	{
		pageno--;
		if (pageno < 1)
		{
			pageno = 42;
		}
		if (pageno == 1)
		{
			base.transform.Find("Panel/Info").GetComponent<Text>().text = startInfo;
		}
		else
		{
			base.transform.Find("Panel/Info").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_LangChat_8") + " " + CommonFunc.ShortLangSel(SharedData.Instance().Translate2Hanzi(pageno), pageno.ToString(), SharedData.Instance().Translate2Hanzi(pageno)) + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_9");
		}
		pageimage.sprite = Resources.Load("images/97-manual/shouce (" + pageno + ")", typeof(Sprite)) as Sprite;
	}

	public void ExitScene()
	{
		if (!exiting)
		{
			exiting = true;
			SceneManager.LoadScene("Title");
		}
	}
}
