using MessagePack;

[MessagePackObject(false)]
public class HSLData
{
	[Key(0)]
	public float hueValue = 0.5f;

	[Key(1)]
	public float saturationValue = 0.8f;

	[Key(2)]
	public float lightnessValue = 1f;
}
