using System.Linq;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TriggerController : MonoBehaviour
{
	protected const float MovementBlockSize = 50f;

	private void Start()
	{
		if (GetComponent<SpriteRenderer>() != null)
		{
			GetComponent<SpriteRenderer>().sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
		}
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		return zero;
	}
}
