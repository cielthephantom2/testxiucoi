using System.Collections.Generic;

public class BattleControllerData
{
	public BattleMenuState m_BattleMenuState;

	public BattleControllerFlow m_BattleControllerFlow = BattleControllerFlow.None;

	public List<TerrainData> terrainDatas = new List<TerrainData>();

	public List<ActionOrderRecord> actionOrder = new List<ActionOrderRecord>();

	public List<ActionOrderRecord> ExtraActionOrder = new List<ActionOrderRecord>();

	public int currentActionOrderIndex;
}
