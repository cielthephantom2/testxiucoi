using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class SharedData
{
	private static SharedData instance = null;

	private string versionBase = "1.0.11.0 ({0}).RTM.202411";

	public string gameDataVersion = "Vesion_00000000";

	public string currentGameDataVersion = "Vesion_20240907";

	public string playerid = "10016";

	public OhPlayerController player;

	public string SpawnPoint = "Spawn";

	public string SpawnStatus = "Normal";

	public string SpawnMapName = "";

	public Dictionary<string, int> FlagList;

	public Dictionary<string, List<gang_e01Table.Row>> EventTable;

	public Dictionary<string, string> PlayerSetting = new Dictionary<string, string>();

	public Dictionary<string, string> EnemySetting = new Dictionary<string, string>();

	public string SceneBefore = "";

	public string SceneBefore4Camp = "";

	public string BattleGround = "BattleField";

	public string BattleEnemyGroupId = "";

	public string b04BattleID = "";

	public List<gang_b04Table.Row> b04RamdonBattleRowList = new List<gang_b04Table.Row>();

	public string BattleItemGroupId = "";

	public string DuelBattleGuild = "";

	public int BattleMemberMax = 3;

	public string AfterBattleWin = "";

	public string AfterBattleLose = "";

	public bool BackFromOtherScene;

	public Dictionary<string, Vector3Int> MapUnitsBefore = new Dictionary<string, Vector3Int>();

	public Dictionary<string, EventRecord> EventsRecord = new Dictionary<string, EventRecord>();

	public Dictionary<string, int> PlayerPackage = new Dictionary<string, int>();

	public string ForwardScene = "";

	public List<string> LoadedSceneStack = new List<string>();

	private string _CurrentChara = "";

	public CharaData CurrentCharaData;

	public bool StatusEditable = true;

	public Dictionary<string, CharaData> CharaDataList = new Dictionary<string, CharaData>();

	public List<string> FullTeam = new List<string>();

	public List<string> FollowList = new List<string>();

	public int FollowMaxCount = 5;

	public int AlliesMaxCount = 18;

	public string SubdueManageFor = "";

	public string OpenPackageFor = "";

	public string OpenShopID = "";

	public PackagerFunction OpenPackagerFunction;

	public string OpenPackageFilter = "1111111111";

	public bool isShowFullName;

	public string ForgeEquipmentStyle = "";

	public string ForgeEquipmentID = "";

	public bool playercamctrl;

	public Direction playerdirection = Direction.Down;

	public string BornID = "";

	public CharaData levelupObj;

	public BattleObject skilllevelupObj;

	public List<CharaData> levelupObjList = new List<CharaData>();

	public List<BattleObject> skillLevelupObjList = new List<BattleObject>();

	public int m_LevelUpIndex;

	public int m_skillLevelUpIndex;

	public string useItemID = "";

	public bool m_EventShow;

	public string m_OpenDetail = "";

	public Dictionary<string, int> m_ShopGoods = new Dictionary<string, int>();

	public Dictionary<string, int> m_LoanedItems = new Dictionary<string, int>();

	public Dictionary<string, int> m_HoriMonos = new Dictionary<string, int>();

	public Dictionary<string, int> m_WantedInfos = new Dictionary<string, int>();

	public int m_BattlePackageStatus;

	public float m_MoneyForAttack;

	public Dictionary<string, string> m_TempParas = new Dictionary<string, string>();

	public GameObject CurrentStatusSubName;

	public bool IsViewOpen;

	public string CurrentMapID = "";

	public Vector3 CurrentPlayerPos = Vector3.zero;

	public string PlayCGName = "";

	public string PlayCGBGM = "";

	public List<string> m_EndAVGFIFO = new List<string>();

	public string AfterCGPlayComplete = "";

	public TitleController m_titleController;

	public int Mark_Direction = -1;

	public Vector3 Mark_Position = Vector3.zero;

	public bool couldCheat;

	public BattleController m_BattleController;

	public MenuController m_MenuController;

	public MapController m_MapController;

	public MapViewController m_MapViewController;

	public EvolutionEqNewController m_EvolutionEqNewController;

	public string m_SubSelectedItem = "";

	private int _money;

	public int m_Epiphany;

	public string m_Transfer_Info = "";

	public bool m_Inevitable;

	public bool m_Teleportation;

	private static string[] UNITS = new string[12]
	{
		"", "十", "百", "千", "万", "十", "百", "千", "亿", "十",
		"百", "千"
	};

	private static string[] NUMS = new string[10] { "零", "一", "二", "三", "四", "五", "六", "七", "八", "九" };

	public int m_PlayRound;

	public float m_FieldMoveSpeedRate = 1f;

	public string m_AppendTraitInfos = "";

	public Queue<string> m_ChatLog = new Queue<string>();

	public string m_SortType = "1111111111";

	public List<string> m_Mesg_News = new List<string>();

	public List<string> m_Mesg_Tecs = new List<string>();

	public bool m_Patch_Fixed;

	public int m_Game_Mode = 1;

	public float m_Enemy_HP_Rate = 1f;

	public float m_Enemy_MP_Rate = 1f;

	public float m_Enemy_ATK_Rate = 1f;

	public float m_Enemy_DEF_Rate = 1f;

	public float m_Enemy_SP_Rate = 1f;

	public int m_Enemy_Skill_Lv_Diff;

	public float m_Enemy_EXP_Rate = 1f;

	public float m_Money_Drop_Rate = 1f;

	public int m_Bonus_Telent;

	public int m_Bonus_Status;

	public int m_InheritItemCount;

	public float terrainFireLv1DamageRate = 0.05f;

	public float terrainFireLv2DamageRate = 0.1f;

	public float terrainFirePersistentDamageRate = 0.1f;

	public float terrainPoisonLv1DamageRate = 0.05f;

	public float terrainPoisonLv2DamageRate = 0.1f;

	public float terrainPoisonPersistentDamageRate = 0.1f;

	public float terrainTrapBlastDamageValue = 10f;

	public float terrainTrapSealValue = 25f;

	public string m_HoveredItem = "";

	public string m_ArenaFightID = "";

	public int m_ArenaWinCount;

	public string m_Arena_RewardsID_JunShan = "2108|2109|2207|3009|3006|3010|3041|3042|3043|3044|3045|1384|3006|3010";

	public string m_Arena_Rewards_JunShan = "000000000000000";

	public int m_Player_Reset;

	public RenderTexture rt;

	private int targetWidth = 720;

	public Dictionary<string, CharaData> m_SubdueList = new Dictionary<string, CharaData>();

	public Dictionary<string, CharaData> m_FinalSubdueList = new Dictionary<string, CharaData>();

	public List<string> m_ExpelList = new List<string>();

	public Dictionary<string, Sprite> UnlockAtlasInfoList = new Dictionary<string, Sprite>();

	public List<string> UnlockAtlasInfoAlreadyShow = new List<string>();

	public Dictionary<string, Sprite> UnlockAchievementInfoList = new Dictionary<string, Sprite>();

	public List<string> UnlockAchievementInfoAlreadyShow = new List<string>();

	public bool isRandomFight;

	public string SpecialRandomFightGID = "";

	public int m_WalkSteps;

	public float m_RandomFightRateLevel1 = 0.1f;

	public float m_RandomFightRateLevel2 = 0.2f;

	public float m_RandomFightRateLevel3 = 0.3f;

	public float m_MaxRandomFightCountInOneMap = 3f;

	public int MineRefreshWalkStep = 1000;

	public int m_MineRefreshWalkStep;

	public int MineRefreshChangeFieldNum = 10;

	public int m_MineRefreshChangeFieldNum;

	public int MaxMineNumInOneMap = 2;

	public int ShovelDurable = int.MaxValue;

	public int m_ShovelDurable;

	public List<MineInfo> mapMineList = new List<MineInfo>();

	public List<RefreshMineInfo> mapMineCouldRefreshList = new List<RefreshMineInfo>();

	public Vector3Int m_DiggingMineGrid = Vector3Int.zero;

	public string appreciationCharacterID = "";

	public string m_unKnownItemID = "";

	public int m_DaTianWangSiLevel;

	public bool m_isDaTianWangSiChallenge;

	public int m_MaxDaTianWangSiLevel = 99;

	public List<string> m_challengePrizeItemList = new List<string>();

	public List<int> m_challengePrizeNumberList = new List<int>();

	public List<string> m_challengePrizeLevelList = new List<string>();

	public string m_Arena_RewardsID_DaTianWangSi = "1&2001|2&2002|3&2003";

	public string m_Arena_Rewards_DaTianWangSi = "";

	public List<string> m_SpecialWantedList = new List<string>();

	public bool m_isBattleWin;

	public Dictionary<string, string> m_TitleLevelUpDict = new Dictionary<string, string>();

	public string m_BattleField_Layer = "";

	public int mapWidth = 8100;

	public int mapHeight = 3349;

	public Color32[] fogPixels;

	public List<PathInfo> pathRecord = new List<PathInfo>();

	public int maxPathRecordCount = 1000;

	public int PathRecordInterval = 1;

	public int fogDis = 300;

	public bool m_IsAutoSaving;

	public float m_WaveSpeed = 2f;

	public float m_WaveScale = 0.5f;

	public float m_SwingAmplitude = 0.4f;

	public float m_SwingFrequency = 0.15f;

	public float m_InteractiveDistanceFade = 3.3f;

	public float m_InteractiveMaxInteracticeOffset = 0.36f;

	public float m_InteractiveMaxInteracticeShort = 0.2f;

	public bool isChangeSortingLayer;

	public bool isChangeAlpha;

	public float m_Alpha_Dis = 20f;

	public float m_Alpha_Value = 0.8f;

	public float m_Alpha_Speed = 0.8f;

	public bool isEnableTrace = true;

	public float m_TraceSamplingInterval = 0.01f;

	public int m_Trace_Length = 30;

	public float m_Trace_Fade = 0.02f;

	public float m_TraceDistanceFade = 0.02f;

	public float m_TraceMaxInteracticeOffset = 0.1f;

	public float m_TraceMaxInteracticeShort = 0.04f;

	public int m_PlayerSortingIrder;

	public DebugBattle debugBattle;

	public Dictionary<string, gang_a01Table.Row> m_A01NameRowDirec = new Dictionary<string, gang_a01Table.Row>();

	public TimeSpan starGameTimeSpan;

	public string m_UnLockMapIconList = "";

	public Dictionary<string, int> m_BattleDropItemIdList = new Dictionary<string, int>();

	public List<string> lastSelectBattleIdList = new List<string>();

	public bool isChooseBattle;

	public gang_e04Table.Row loadMapE04;

	public bool InitSkin;

	public Sprite ProtagonistFullSprite;

	public Sprite ProtagonistHeadSprite;

	public ProtagonistSkinDataNew protagonistSkinDataNew = new ProtagonistSkinDataNew();

	public gang_b01SkinTable.Row protagonistSkinB01SkinTable;

	public CreateWGController createWgController;

	public EvolutionWGController evolutionWgController;

	public bool isLoadedStart1_1;

	public LevelUpController levelUpController;

	public string sectPanelID = "";

	public string Guide_Page_Lic = "";

	public List<string> m_NewItemList = new List<string>();

	public string LocalVersion => string.Format(versionBase, "dajianghu");

	public string CurrentChara
	{
		get
		{
			return _CurrentChara;
		}
		set
		{
			_CurrentChara = value;
			CurrentCharaData = GetCharaData(_CurrentChara);
		}
	}

	public AtlasManagerNewController m_AtlasManagerNewController
	{
		get
		{
			if (CommonResourcesData.atlasManagerNewController == null)
			{
				CommonResourcesData.atlasManagerNewController = UnityEngine.Object.Instantiate(CommonResourcesData.AtlasCanvasPrefab).GetComponent<AtlasManagerNewController>();
				CommonResourcesData.atlasManagerNewController.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.atlasManagerNewController);
			}
			return CommonResourcesData.atlasManagerNewController;
		}
		set
		{
			CommonResourcesData.atlasManagerNewController = value;
		}
	}

	public StatusMainController m_StatusMain
	{
		get
		{
			if (CommonResourcesData.statusMainController == null)
			{
				CommonResourcesData.statusMainController = UnityEngine.Object.Instantiate(CommonResourcesData.StatusMainPrefab).GetComponent<StatusMainController>();
				CommonResourcesData.statusMainController.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusMainController);
			}
			return CommonResourcesData.statusMainController;
		}
		set
		{
			CommonResourcesData.statusMainController = value;
		}
	}

	public StatusSub1 m_StatusSub1
	{
		get
		{
			if (CommonResourcesData.statusSub1 == null)
			{
				CommonResourcesData.statusSub1 = UnityEngine.Object.Instantiate(CommonResourcesData.StatusSub1Prefab).GetComponent<StatusSub1>();
				CommonResourcesData.statusSub1.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusSub1);
			}
			return CommonResourcesData.statusSub1;
		}
		set
		{
			CommonResourcesData.statusSub1 = value;
		}
	}

	public StatusSub2 m_StatusSub2
	{
		get
		{
			if (CommonResourcesData.statusSub2 == null)
			{
				CommonResourcesData.statusSub2 = UnityEngine.Object.Instantiate(CommonResourcesData.StatusSub2Prefab).GetComponent<StatusSub2>();
				CommonResourcesData.statusSub2.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusSub2);
			}
			return CommonResourcesData.statusSub2;
		}
		set
		{
			CommonResourcesData.statusSub2 = value;
		}
	}

	public StatusSub3 m_StatusSub3
	{
		get
		{
			if (CommonResourcesData.statusSub3 == null)
			{
				CommonResourcesData.statusSub3 = UnityEngine.Object.Instantiate(CommonResourcesData.StatusSub3Prefab).GetComponent<StatusSub3>();
				CommonResourcesData.statusSub3.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusSub3);
			}
			return CommonResourcesData.statusSub3;
		}
		set
		{
			CommonResourcesData.statusSub3 = value;
		}
	}

	public StatusSub4 m_StatusSub4
	{
		get
		{
			if (CommonResourcesData.statusSub4 == null)
			{
				CommonResourcesData.statusSub4 = UnityEngine.Object.Instantiate(CommonResourcesData.StatusSub4Prefab).GetComponent<StatusSub4>();
				CommonResourcesData.statusSub4.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusSub4);
			}
			return CommonResourcesData.statusSub4;
		}
		set
		{
			CommonResourcesData.statusSub4 = value;
		}
	}

	public StatusSub5 m_StatusSub5
	{
		get
		{
			if (CommonResourcesData.statusSub5 == null)
			{
				CommonResourcesData.statusSub5 = UnityEngine.Object.Instantiate(CommonResourcesData.StatusSub5Prefab).GetComponent<StatusSub5>();
				CommonResourcesData.statusSub5.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusSub5);
			}
			return CommonResourcesData.statusSub5;
		}
		set
		{
			CommonResourcesData.statusSub5 = value;
		}
	}

	public StatusSub6 m_StatusSub6
	{
		get
		{
			if (CommonResourcesData.statusSub6 == null)
			{
				CommonResourcesData.statusSub6 = UnityEngine.Object.Instantiate(CommonResourcesData.StatusSub6Prefab).GetComponent<StatusSub6>();
				CommonResourcesData.statusSub6.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.statusSub6);
			}
			return CommonResourcesData.statusSub6;
		}
		set
		{
			CommonResourcesData.statusSub6 = value;
		}
	}

	public PackageController m_PackageController
	{
		get
		{
			if (CommonResourcesData.packageController == null)
			{
				CommonResourcesData.packageController = UnityEngine.Object.Instantiate(CommonResourcesData.PackageCanvasPrefab).GetComponent<PackageController>();
				CommonResourcesData.packageController.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.packageController);
			}
			return CommonResourcesData.packageController;
		}
		set
		{
			CommonResourcesData.packageController = value;
		}
	}

	public TraitPackageController m_TraitPackageController
	{
		get
		{
			if (CommonResourcesData.traitPackageController == null)
			{
				CommonResourcesData.traitPackageController = UnityEngine.Object.Instantiate(CommonResourcesData.TraitpackageCanvasPrefab).GetComponent<TraitPackageController>();
				CommonResourcesData.traitPackageController.CloseTraitPackage();
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.traitPackageController);
			}
			return CommonResourcesData.traitPackageController;
		}
		set
		{
			CommonResourcesData.traitPackageController = value;
		}
	}

	public DataRecordManager m_DataRecordManager
	{
		get
		{
			if (CommonResourcesData.dataRecordManager == null)
			{
				CommonResourcesData.dataRecordManager = UnityEngine.Object.Instantiate(CommonResourcesData.DataRecordCanvasPrefab).GetComponent<DataRecordManager>();
				CommonResourcesData.dataRecordManager.gameObject.SetActive(value: false);
				UnityEngine.Object.DontDestroyOnLoad(CommonResourcesData.dataRecordManager);
			}
			return CommonResourcesData.dataRecordManager;
		}
		set
		{
			CommonResourcesData.dataRecordManager = value;
		}
	}

	public int m_Money
	{
		get
		{
			return _money;
		}
		set
		{
			_money = value;
			if (m_MapController != null && SceneManager.sceneCount == 1)
			{
				m_MapController.MoneyMoveAnimation();
			}
		}
	}

	private void Init()
	{
		Debug.Log("SharedData Init()");
		if (!CommonResourcesData.isInitAllResources)
		{
			CommonResourcesData.LoadAllResource();
		}
		CommonResourcesData.UpdateResourcesByLanguage();
		m_A01NameRowDirec = new Dictionary<string, gang_a01Table.Row>();
		foreach (gang_a01Table.Row row in CommonResourcesData.a01.GetRowList())
		{
			m_A01NameRowDirec.Add(row.Name, row);
		}
		Debug.Log("Load b08 ShopGoods...");
		foreach (gang_b08Table.Row row2 in CommonResourcesData.b08.GetRowList())
		{
			m_ShopGoods.Add(row2.ID, 0);
		}
		Debug.Log("Load b07 LoanedItems...");
		foreach (gang_b07Table.Row row3 in CommonResourcesData.b07.GetRowList())
		{
			if (!"0".Equals(row3.Value))
			{
				m_LoanedItems.Add(row3.ID, 0);
			}
		}
		Debug.Log("Load e01 FlagList and EventTable...");
		FlagList = new Dictionary<string, int>();
		EventTable = new Dictionary<string, List<gang_e01Table.Row>>();
		foreach (gang_e01Table.Row row4 in CommonResourcesData.e01.GetRowList())
		{
			if (!"0".Equals(row4.online))
			{
				FlagList.Add(row4.flag, 0);
				if (!EventTable.ContainsKey(row4.eventid))
				{
					List<gang_e01Table.Row> value = new List<gang_e01Table.Row>();
					EventTable.Add(row4.eventid, value);
				}
				EventTable[row4.eventid].Add(row4);
			}
		}
		Debug.Log("Load e03 HoriMono...");
		foreach (gang_e03Table.Row row5 in CommonResourcesData.e03.GetRowList())
		{
			m_HoriMonos.Add(row5.id, 0);
		}
		Debug.Log("Load c03 Wanted...");
		foreach (gang_c03Table.Row row6 in CommonResourcesData.c03.GetRowList())
		{
			m_WantedInfos.Add(row6.ID, 0);
		}
		lastSelectBattleIdList = new List<string>();
		isChooseBattle = false;
		Debug.Log("SharedData Init()... Done");
	}

	public static SharedData Instance(bool init = false)
	{
		if (init || instance == null)
		{
			instance = null;
			instance = new SharedData();
			instance.Init();
		}
		return instance;
	}

	public gang_b02Table.Row BuildB02AppendRow(string _baseid)
	{
		GameDataManager.Instance().configdata.m_create_serial_id++;
		string text = Guid.NewGuid().ToString();
		gang_b02Table.Row row = CommonResourcesData.b02.Find_ID(_baseid);
		gang_b02Table.Row row2 = JsonUtility.FromJson<gang_b02Table.Row>(JsonUtility.ToJson(row));
		row2.ID = "MB02_" + row.ID + "_" + text;
		row2.isAtlas = "0";
		CommonResourcesData.b02.GetRowList().Add(row2);
		CommonResourcesData.b02append.Add(row2);
		return row2;
	}

	public gang_b03Table.Row BuildB03AppendRow(string _baseid)
	{
		GameDataManager.Instance().configdata.m_create_serial_id++;
		string text = Guid.NewGuid().ToString();
		gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(_baseid);
		gang_b03Table.Row row2 = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(row));
		row2.ID = "MB03_" + row.ID + "_" + text;
		row2.isAtlas = row.isAtlas;
		CommonResourcesData.b03.GetRowList().Add(row2);
		CommonResourcesData.b03append.Add(row2);
		return row2;
	}

	public gang_b03Table.Row GetB03AppendRow(string _baseid, bool _create = false)
	{
		foreach (gang_b03Table.Row item in CommonResourcesData.b03append)
		{
			if (item.ID.Equals(_baseid))
			{
				return item;
			}
		}
		if (!_create)
		{
			return null;
		}
		gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(_baseid);
		if (row == null)
		{
			return null;
		}
		gang_b03Table.Row row2 = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(row));
		CommonResourcesData.b03append.Add(row2);
		return row2;
	}

	public gang_b07Table.Row BuildB07AppendRow(string _baseid)
	{
		GameDataManager.Instance().configdata.m_create_serial_id++;
		string text = Guid.NewGuid().ToString();
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_baseid);
		gang_b07Table.Row row2 = JsonUtility.FromJson<gang_b07Table.Row>(JsonUtility.ToJson(row));
		row2.ID = "MB07_" + row.ID + "_" + text;
		row2.isAtlas = "0";
		CommonResourcesData.b07.GetRowList().Add(row2);
		CommonResourcesData.b07append.Add(row2);
		return row2;
	}

	public gang_b07Table.Row GetB07AppendRow(string _baseid, bool _create = false)
	{
		foreach (gang_b07Table.Row item in CommonResourcesData.b07append)
		{
			if (item.ID.Equals(_baseid))
			{
				return item;
			}
		}
		if (!_create)
		{
			return null;
		}
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_baseid);
		if (row == null)
		{
			return null;
		}
		gang_b07Table.Row row2 = JsonUtility.FromJson<gang_b07Table.Row>(JsonUtility.ToJson(row));
		CommonResourcesData.b07append.Add(row2);
		return row2;
	}

	public void RemoveCharaData(string _chara_id)
	{
		if (CharaDataList.ContainsKey(_chara_id))
		{
			CharaDataList.Remove(_chara_id);
		}
	}

	public CharaData GetCharaData(string _chara_id)
	{
		if (CharaDataList.ContainsKey(_chara_id))
		{
			return CharaDataList[_chara_id];
		}
		gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(_chara_id);
		if (row != null)
		{
			CharaData charaData = new CharaData();
			charaData.Init(row);
			CharaDataList.Add(_chara_id, charaData);
			return charaData;
		}
		return null;
	}

	public void SaveMapSnapshot(string _mapname, Dictionary<string, Vector3Int> _mapunits, Dictionary<string, MapController.Event> _mapevents)
	{
		if (_mapname.Split('_')[0].Equals("Base"))
		{
			SceneBefore4Camp = _mapname;
			return;
		}
		SceneBefore = _mapname;
		SceneBefore4Camp = "";
		MapUnitsBefore.Clear();
		foreach (KeyValuePair<string, Vector3Int> _mapunit in _mapunits)
		{
			MapUnitsBefore.Add(_mapunit.Key, _mapunit.Value);
		}
		EventsRecord.Clear();
		foreach (KeyValuePair<string, MapController.Event> _mapevent in _mapevents)
		{
			EventRecord eventRecord = new EventRecord
			{
				originevdata = _mapevent.Value.originevdata,
				evdata = _mapevent.Value.evdata,
				flow = _mapevent.Value.flow,
				elseroute = _mapevent.Value.elseroute
			};
			if (_mapevent.Value.obj != null)
			{
				EventController eventController = _mapevent.Value.eventController;
				eventRecord.display = eventController.display;
				eventRecord.objcamarectrl = eventController.camera_control;
				eventRecord.objdirection = eventController.m_Direction;
			}
			EventsRecord.Add(_mapevent.Key, eventRecord);
		}
	}

	public void ASyncLoadScene(string _scenename)
	{
		loadMapE04 = CommonResourcesData.e04.Find_id(_scenename);
		if (loadMapE04 == null)
		{
			SceneManager.LoadScene(_scenename);
		}
		else if (!MapLoader.instance.mapAreaDict.ContainsKey(loadMapE04.AreaName) || !MapLoader.instance.mapAreaDict[loadMapE04.AreaName].ContainsKey(loadMapE04.mapName.Split('|')[0]))
		{
			SceneManager.LoadScene("Loading");
		}
		else
		{
			LoadMap();
		}
	}

	private void LoadMap()
	{
		SkinCharacter.initSkeletonGraphicList.Clear();
		if (loadMapE04.id.StartsWith("BattleField-"))
		{
			SceneManager.LoadScene("Battle_Template");
		}
		else if (loadMapE04.id.StartsWith("Field_") || loadMapE04.id.StartsWith("Map_"))
		{
			SceneManager.LoadScene("Field_Template");
		}
	}

	public void SetGameMode(int _game_mode)
	{
		m_Game_Mode = _game_mode;
		switch (m_Game_Mode)
		{
		case 0:
			m_Enemy_HP_Rate = 1f;
			m_Enemy_MP_Rate = 1f;
			m_Enemy_ATK_Rate = 1f;
			m_Enemy_DEF_Rate = 1f;
			m_Enemy_SP_Rate = 1f;
			m_Enemy_Skill_Lv_Diff = 0;
			m_Enemy_EXP_Rate = 1f;
			m_Money_Drop_Rate = 1f;
			m_Bonus_Telent = 0;
			m_Bonus_Status = 0;
			m_InheritItemCount = 1;
			break;
		case 1:
			m_Enemy_HP_Rate = 0.5f;
			m_Enemy_MP_Rate = 0.8f;
			m_Enemy_ATK_Rate = 0.8f;
			m_Enemy_DEF_Rate = 0f;
			m_Enemy_SP_Rate = 1f;
			m_Enemy_Skill_Lv_Diff = -3;
			m_Enemy_EXP_Rate = 1.5f;
			m_Money_Drop_Rate = 1.5f;
			m_Bonus_Telent = 1;
			m_Bonus_Status = 1;
			m_InheritItemCount = 0;
			break;
		case 2:
			m_Enemy_HP_Rate = 1f;
			m_Enemy_MP_Rate = 1f;
			m_Enemy_ATK_Rate = 1f;
			m_Enemy_DEF_Rate = 1f;
			m_Enemy_SP_Rate = 1f;
			m_Enemy_Skill_Lv_Diff = 0;
			m_Enemy_EXP_Rate = 1f;
			m_Money_Drop_Rate = 1f;
			m_Bonus_Telent = 0;
			m_Bonus_Status = 0;
			m_InheritItemCount = 1;
			break;
		}
	}

	public bool CheckGuiRaycastObjects(string check = "")
	{
		EventSystem current = EventSystem.current;
		if (current == null)
		{
			return false;
		}
		if (!InputDeviceDetector.instance.isMouseInput)
		{
			return false;
		}
		PointerEventData pointerEventData = new PointerEventData(current);
		pointerEventData.pressPosition = Input.mousePosition;
		pointerEventData.position = Input.mousePosition;
		List<RaycastResult> list = new List<RaycastResult>();
		current.RaycastAll(pointerEventData, list);
		int num = 0;
		if (check.Length <= 0)
		{
			num = list.Count;
		}
		else if (list.Count > 0)
		{
			foreach (RaycastResult item in list)
			{
				if (item.gameObject.name.Equals(check))
				{
					num++;
					break;
				}
			}
		}
		return num > 0;
	}

	public List<T> RandomSort<T>(List<T> list)
	{
		List<T> list2 = new List<T>();
		foreach (T item in list)
		{
			list2.Insert(UnityEngine.Random.Range(0, list2.Count), item);
		}
		return list2;
	}

	public void PackageRemove(string _key)
	{
		Dictionary<string, int> dictionary = new Dictionary<string, int>();
		foreach (KeyValuePair<string, int> item in PlayerPackage)
		{
			if (!item.Key.Equals(_key))
			{
				dictionary.Add(item.Key, item.Value);
			}
		}
		PlayerPackage.Clear();
		PlayerPackage = dictionary;
		m_NewItemList.Remove(_key);
	}

	public bool PackageAdd(string _key, int _amount)
	{
		if (_key == "")
		{
			return false;
		}
		bool flag = false;
		bool result = false;
		if (!PlayerPackage.ContainsKey(_key) && _amount < 0)
		{
			result = true;
		}
		if ("999".Equals(_key))
		{
			Instance().m_Money += _amount;
			flag = false;
		}
		else
		{
			if (PlayerPackage.ContainsKey(_key))
			{
				if (PlayerPackage[_key] > 0)
				{
					flag = true;
					PlayerPackage[_key] += _amount;
				}
				else
				{
					PackageRemove(_key);
					PlayerPackage.Add(_key, _amount);
					flag = true;
				}
			}
			else
			{
				PlayerPackage.Add(_key, _amount);
				flag = true;
			}
			if (PlayerPackage[_key] <= 0)
			{
				flag = false;
				PackageRemove(_key);
			}
			if (_amount > 0)
			{
				GameDataManager.Instance().AddUnlockAtlasList(_key, "b07");
			}
		}
		if (flag && _amount > 0)
		{
			m_NewItemList.Add(_key);
		}
		return result;
	}

	public bool AddMesgNews(string _news)
	{
		bool result = false;
		if (!m_Mesg_News.Contains(_news))
		{
			m_Mesg_News.Add(_news);
			result = true;
		}
		return result;
	}

	public string FormatDynamicText(string _text)
	{
		string text = "";
		string[] array = _text.Split('[');
		foreach (string text2 in array)
		{
			string[] array2 = text2.Split(']');
			if (array2.Length > 1)
			{
				text = ((array2[0] == "player") ? (text + player.charadata.Indexs_Name["Name"].stringValue) : ((array2[0] == "nickname") ? ((player.charadata.m_NicknameList.Count <= 0) ? (text + "写死数值") : (text + player.charadata.m_NicknameList[0])) : ((array2[0] == "arenawincount") ? (text + m_ArenaWinCount) : ((!m_TempParas.ContainsKey(array2[0])) ? (text + array2[0]) : (text + m_TempParas[array2[0]])))));
				text += array2[1];
			}
			else
			{
				text += text2;
			}
		}
		return text;
	}

	public bool AddMesgTecs(string _tecs)
	{
		bool result = false;
		if (!m_Mesg_Tecs.Contains(_tecs))
		{
			m_Mesg_Tecs.Add(_tecs);
			result = true;
		}
		return result;
	}

	public string Translate2Hanzi(int value)
	{
		string text = "";
		for (int num = value.ToString().Length - 1; num >= 0; num--)
		{
			int num2 = Mathf.FloorToInt((float)value / Mathf.Pow(10f, num));
			text = text + NUMS[num2 % 10] + UNITS[num];
		}
		text = Regex.Replace(text, "零[十, 百, 千]", "零");
		text = Regex.Replace(text, "零+", "零");
		if ("ChineseTraditional".Equals(GameDataManager.Instance().configdata.language))
		{
			text = Regex.Replace(text, "零([萬, 億])", "$1");
			text = Regex.Replace(text, "億萬", "億");
		}
		else
		{
			text = Regex.Replace(text, "零([万, 亿])", "$1");
			text = Regex.Replace(text, "亿万", "亿");
		}
		if (text.StartsWith("一十"))
		{
			text = text.Substring(1);
		}
		if (text.EndsWith("零"))
		{
			text = text.Substring(0, text.Length - 1);
		}
		if (text.Length <= 0)
		{
			text = "零";
		}
		return text;
	}

	public Texture2D CreateTexture(int width, int height)
	{
		Texture2D texture2D = new Texture2D(width, height);
		Color[] array = new Color[width * height];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = Color.black;
		}
		texture2D.SetPixels(array);
		texture2D.Apply();
		return texture2D;
	}

	public float SetFieldMoveSpeedRate()
	{
		float num = 1f;
		num += Instance().GetCharaData(Instance().playerid).GetFieldValueByName("Speed") * 0.5f;
		foreach (string follow in Instance().FollowList)
		{
			num += Instance().GetCharaData(follow).GetFieldValueByName("Speed") * 0.5f;
		}
		num = ((num > 3f) ? 3f : num);
		num = ((num < 1f) ? 1f : num);
		Instance().m_FieldMoveSpeedRate = num;
		return num;
	}

	public void LoadSceneStackAdd(string sceneName)
	{
		if (LoadedSceneStack.Contains(sceneName))
		{
			LoadedSceneStack.Remove(sceneName);
		}
		LoadedSceneStack.Add(sceneName);
	}

	public void LoadSceneStackRemove(string sceneName)
	{
		if (LoadedSceneStack.Contains(sceneName))
		{
			LoadedSceneStack.Remove(sceneName);
		}
	}
}
