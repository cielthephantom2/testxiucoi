public class Message
{
	public string inputDeviceType;

	public object MsgParams;

	public Message(string _msgType, object _msgParams)
	{
		inputDeviceType = _msgType;
		MsgParams = _msgParams;
	}
}
