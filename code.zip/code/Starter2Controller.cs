using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Starter2Controller : MonoBehaviour
{
	private Color btn_txt_down = new Color(1f, 1f, 0.925f, 0.3f);

	private Color btn_txt_common = new Color(1f, 1f, 0.925f, 1f);

	private Color image_down = new Color(1f, 1f, 1f, 0.3f);

	private Color image_common = new Color(1f, 1f, 1f, 1f);

	private Color btn_txt_down1 = new Color(0.412f, 0.376f, 0.325f, 0.3f);

	private Color btn_txt_common1 = new Color(0.412f, 0.376f, 0.325f, 1f);

	[HideInInspector]
	public GameObject SelectedBtn;

	private Transform StoryArea;

	private GameObject NextBtn;

	private void Start()
	{
		StoryArea = base.transform.Find("Panel/StoryFrame");
		GameObject.FindGameObjectWithTag("MainCamera").GetComponent<AudioSource>();
		Sprite tachieFull = CommonResourcesData.GetTachieFull(CommonResourcesData.b01.Find_ID(SharedData.Instance().playerid).BattleIcon);
		base.transform.Find("Panel/Portrait/Portrait").GetComponent<Image>().sprite = tachieFull;
		NextBtn = base.transform.Find("Panel/Next").gameObject;
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		_ = (GameObject)Resources.Load("Prefabs/Field/BornBtn");
		GameObject gameObject = null;
		GameObject selectedBtn = null;
		GameObject gameObject2 = base.transform.Find("Panel/ScrollView/Viewport/Content").gameObject;
		int num = 0;
		foreach (gang_a02Table.Row row in CommonResourcesData.a02.GetRowList())
		{
			int num2 = int.Parse(row.Round) - 1;
			gameObject = gameObject2.transform.Find("Born|" + num).gameObject;
			gameObject.gameObject.SetActive(value: true);
			EventTriggerListener.Get(gameObject).onClick = OnButtonClick;
			gameObject.name = "Born|" + row.ID;
			if (num == 0)
			{
				selectedBtn = gameObject;
			}
			else
			{
				gameObject.GetComponent<Image>().color = image_down;
			}
			if (GameDataManager.Instance().configdata.playRound < num2)
			{
				gameObject.GetComponentInChildren<Text>().color = btn_txt_down1;
				gameObject.transform.Find("Week").gameObject.SetActive(value: true);
			}
			gameObject.GetComponentInChildren<Text>().text = row.Scenario_Trans;
			num++;
		}
		if (SharedData.Instance().BornID != "")
		{
			SelectedBtn = base.transform.Find("Panel/ScrollView/Viewport/Content/Born|" + SharedData.Instance().BornID).gameObject;
			if (SelectedBtn == null)
			{
				SelectedBtn = selectedBtn;
			}
		}
		else
		{
			SelectedBtn = selectedBtn;
		}
		EventSystem.current.SetSelectedGameObject(SelectedBtn);
		UpdateRightInfo();
	}

	private void UpdateRightInfo()
	{
		string[] array = SelectedBtn.name.Split('|');
		SharedData.Instance().BornID = array[1];
		gang_a02Table.Row row = CommonResourcesData.a02.Find_ID(array[1]);
		int num = int.Parse(row.Round) - 1;
		if (GameDataManager.Instance().configdata.playRound < num)
		{
			NextBtn.SetActive(value: false);
		}
		else
		{
			SelectedBtn.GetComponent<Image>().color = image_common;
			NextBtn.SetActive(value: true);
		}
		StoryArea.Find("Description").GetComponent<Text>().text = row.Note_Trans;
		StoryArea.Find("Money/Content").GetComponent<Text>().text = row.Money + " " + CommonFunc.I18nGetLocalizedValue("I18N_Money_1");
		string[] array2 = row.Kongfu.Split('|');
		string text = "";
		int num2 = 0;
		string[] array3 = array2;
		foreach (string find in array3)
		{
			gang_b03Table.Row row2 = CommonResourcesData.b03.Find_ID(find);
			text = text + ((num2 > 0) ? "，" : "") + row2.Name_Trans;
			num2++;
		}
		StoryArea.Find("WuGong/Content").GetComponent<Text>().text = text;
		StoryArea.Find("GoodAt/Content").GetComponent<Text>().text = row.GoodAt_Trans;
		StoryArea.Find("Special/Content").GetComponent<Text>().text = row.Kungfu_Trans;
	}

	public void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			MonoBehaviour.print("OnButtonClick -> " + go.name);
			if (go.name == "Next")
			{
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_down;
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common;
				SharedData.Instance().ASyncLoadScene("Starter3");
			}
			else if (go.name == "Return")
			{
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_down1;
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common1;
				SharedData.Instance().ASyncLoadScene("Starter1_1");
			}
			else
			{
				SelectedBtn.GetComponent<Image>().color = image_down;
				SelectedBtn = go;
				UpdateRightInfo();
			}
		}
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Next").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Return").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}
}
