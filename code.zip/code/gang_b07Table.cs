using System.Collections.Generic;
using UnityEngine;

public class gang_b07Table
{
	public class Row
	{
		public string ID;

		public string Name;

		public string Name_EN;

		public string BookIcon;

		public string Style;

		public string Star;

		public string Value;

		public string Use;

		public string Relateid;

		public string Skills1;

		public string Skills1Ec;

		public string Skills2;

		public string Skills2Ec;

		public string Skills3;

		public string Skills3Ec;

		public string Skills4;

		public string Skills4Ec;

		public string Attckstyle;

		public string Area;

		public string Range;

		public string note;

		public string note_EN;

		public string isAtlas;

		public string _PriceType;

		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);

		public string note_Trans => CommonFunc.ShortLangSel(note, note_EN);

		public PriceType PriceType => _PriceType switch
		{
			"money" => PriceType.money, 
			"oldcoin" => PriceType.oldcoin, 
			"bone" => PriceType.bone, 
			_ => PriceType.money, 
		};
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Name = list[i][num++],
				BookIcon = list[i][num++],
				Style = list[i][num++],
				Star = list[i][num++],
				Value = list[i][num++],
				_PriceType = list[i][num++],
				Use = list[i][num++],
				Relateid = list[i][num++],
				Skills1 = list[i][num++],
				Skills1Ec = list[i][num++],
				Skills2 = list[i][num++],
				Skills2Ec = list[i][num++],
				Skills3 = list[i][num++],
				Skills3Ec = list[i][num++],
				Skills4 = list[i][num++],
				Skills4Ec = list[i][num++],
				Attckstyle = list[i][num++],
				Area = list[i][num++],
				Range = list[i][num++],
				note = list[i][num++],
				isAtlas = list[i][num++]
			};
			row.Use = row.Use.Substring(1);
			while (row.Use.Length <= 11)
			{
				row.Use += "0";
			}
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_b07_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_b07_" + row.ID + "_Name")?.en_US;
			row.note = I18nData.Instance().tableI18N.Find_ID("gang_b07_" + row.ID + "_Note")?.zh_CH;
			row.note_EN = I18nData.Instance().tableI18N.Find_ID("gang_b07_" + row.ID + "_Note")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		if (find.Contains("&"))
		{
			find = find.Split("&")[0];
		}
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Name_EN(string find)
	{
		return rowList.Find((Row x) => x.Name_EN == find);
	}

	public List<Row> FindAll_Name_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Name_EN == find);
	}

	public Row Find_BookIcon(string find)
	{
		return rowList.Find((Row x) => x.BookIcon == find);
	}

	public List<Row> FindAll_BookIcon(string find)
	{
		return rowList.FindAll((Row x) => x.BookIcon == find);
	}

	public Row Find_Style(string find)
	{
		return rowList.Find((Row x) => x.Style == find);
	}

	public List<Row> FindAll_Style(string find)
	{
		return rowList.FindAll((Row x) => x.Style == find);
	}

	public Row Find_Star(string find)
	{
		return rowList.Find((Row x) => x.Star == find);
	}

	public List<Row> FindAll_Star(string find)
	{
		return rowList.FindAll((Row x) => x.Star == find);
	}

	public Row Find_Value(string find)
	{
		return rowList.Find((Row x) => x.Value == find);
	}

	public List<Row> FindAll_Value(string find)
	{
		return rowList.FindAll((Row x) => x.Value == find);
	}

	public Row Find_Use(string find)
	{
		return rowList.Find((Row x) => x.Use == find);
	}

	public List<Row> FindAll_Use(string find)
	{
		return rowList.FindAll((Row x) => x.Use == find);
	}

	public Row Find_Relateid(string find)
	{
		return rowList.Find((Row x) => x.Relateid == find);
	}

	public Row Find_Relate_Wugong_id(string find)
	{
		return rowList.Find((Row x) => x.Relateid == find && x.Use[8] == '1');
	}

	public Row Find_Relate_Equip_id(string find)
	{
		return rowList.Find((Row x) => x.Relateid == find && (x.Use[2] == '1' || x.Use[3] == '1' || x.Use[4] == '1'));
	}

	public List<Row> FindAll_Relateid(string find)
	{
		return rowList.FindAll((Row x) => x.Relateid == find);
	}

	public Row Find_Skills1(string find)
	{
		return rowList.Find((Row x) => x.Skills1 == find);
	}

	public List<Row> FindAll_Skills1(string find)
	{
		return rowList.FindAll((Row x) => x.Skills1 == find);
	}

	public Row Find_Skills2(string find)
	{
		return rowList.Find((Row x) => x.Skills2 == find);
	}

	public List<Row> FindAll_Skills2(string find)
	{
		return rowList.FindAll((Row x) => x.Skills2 == find);
	}

	public Row Find_Skills3(string find)
	{
		return rowList.Find((Row x) => x.Skills3 == find);
	}

	public List<Row> FindAll_Skills3(string find)
	{
		return rowList.FindAll((Row x) => x.Skills3 == find);
	}

	public Row Find_Skills4(string find)
	{
		return rowList.Find((Row x) => x.Skills4 == find);
	}

	public List<Row> FindAll_Skills4(string find)
	{
		return rowList.FindAll((Row x) => x.Skills4 == find);
	}

	public Row Find_Attckstyle(string find)
	{
		return rowList.Find((Row x) => x.Attckstyle == find);
	}

	public List<Row> FindAll_Attckstyle(string find)
	{
		return rowList.FindAll((Row x) => x.Attckstyle == find);
	}

	public Row Find_Area(string find)
	{
		return rowList.Find((Row x) => x.Area == find);
	}

	public List<Row> FindAll_Area(string find)
	{
		return rowList.FindAll((Row x) => x.Area == find);
	}

	public Row Find_Range(string find)
	{
		return rowList.Find((Row x) => x.Range == find);
	}

	public List<Row> FindAll_Range(string find)
	{
		return rowList.FindAll((Row x) => x.Range == find);
	}

	public Row Find_note(string find)
	{
		return rowList.Find((Row x) => x.note == find);
	}

	public List<Row> FindAll_note(string find)
	{
		return rowList.FindAll((Row x) => x.note == find);
	}

	public Row Find_note_EN(string find)
	{
		return rowList.Find((Row x) => x.note_EN == find);
	}

	public List<Row> FindAll_note_EN(string find)
	{
		return rowList.FindAll((Row x) => x.note_EN == find);
	}
}
