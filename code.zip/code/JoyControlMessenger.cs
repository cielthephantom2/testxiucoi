using System;
using System.Collections.Generic;
using UnityEngine;

public class JoyControlMessenger
{
	private Dictionary<string, EventListenerDelegate> events = new Dictionary<string, EventListenerDelegate>();

	public void AddListener(string type, EventListenerDelegate listener)
	{
		if (listener == null)
		{
			Debug.LogError("AddListener: listener can not empty");
			return;
		}
		EventListenerDelegate value = null;
		events.TryGetValue(type, out value);
		events[type] = (EventListenerDelegate)Delegate.Combine(value, listener);
	}

	public void RemoveListener(string type, EventListenerDelegate listener)
	{
		if (listener == null)
		{
			Debug.LogError("RemoveListener: listener can not empty");
		}
		else
		{
			events[type] = (EventListenerDelegate)Delegate.Remove(events[type], listener);
		}
	}

	public void SendMessage(string type, object param)
	{
		if (events.TryGetValue(type, out var value))
		{
			Message message = new Message(type, param);
			try
			{
				value?.Invoke(message);
			}
			catch (Exception ex)
			{
				Debug.Log("SendMessage:" + message.inputDeviceType.ToString() + " " + ex.Message + " " + ex.StackTrace + " " + ex);
			}
		}
	}

	public void Clear()
	{
		events.Clear();
	}
}
