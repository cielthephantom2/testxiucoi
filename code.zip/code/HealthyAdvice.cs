using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HealthyAdvice : MonoBehaviour
{
	private void Start()
	{
		StartCoroutine(DelayJump());
	}

	private IEnumerator DelayJump()
	{
		yield return new WaitForSeconds(5f);
		SceneManager.LoadSceneAsync("Caution");
	}
}
