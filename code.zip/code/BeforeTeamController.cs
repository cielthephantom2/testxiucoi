using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BeforeTeamController : MonoBehaviour
{
	private GameObject ChoosePanel;

	private GameObject ChooseCount;

	private string TitleText = "";

	private int SelectedCount;

	public List<Button> allBtns = new List<Button>();

	public List<Button> buttonsTeamMate;

	public List<Button> buttonsPokemon;

	private List<string> NewFollowList = new List<string>();

	private IconListController iconListController;

	private void Start()
	{
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		ChoosePanel = base.transform.Find("Panel").gameObject;
		ChooseCount = ChoosePanel.transform.Find("Title").gameObject;
		iconListController = ChoosePanel.transform.Find("IconList").GetComponent<IconListController>();
		EventTriggerListener.Get(ChoosePanel.transform.Find("ChooseOK").gameObject).onClick = OnButtonClick;
		allBtns = ChoosePanel.transform.Find("CharacterArea/Viewport/Content").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		foreach (Button allBtn in allBtns)
		{
			if (allBtn.name.StartsWith("SelcetTeammate"))
			{
				buttonsTeamMate.Add(allBtn);
			}
			else
			{
				buttonsPokemon.Add(allBtn);
			}
			EventTriggerListener.Get(allBtn.gameObject).onClick = OnButtonClick;
		}
		NewFollowList.AddRange(SharedData.Instance().FollowList);
		int teammateCounts = 0;
		int pokemonCounts = 0;
		for (int i = 0; i < SharedData.Instance().FullTeam.Count; i++)
		{
			string text = SharedData.Instance().FullTeam[i];
			Button button = null;
			if (!text.Contains('_'))
			{
				teammateCounts++;
				if (teammateCounts > 54)
				{
					continue;
				}
				button = buttonsTeamMate.Find((Button x) => x.name == "SelcetTeammate_" + teammateCounts);
			}
			else
			{
				pokemonCounts++;
				if (pokemonCounts > 18)
				{
					continue;
				}
				button = buttonsPokemon.Find((Button x) => x.name == "SelcetPokemon_" + pokemonCounts);
			}
			button.transform.Find("IconMask/IconBG").gameObject.SetActive(value: true);
			CharaData charaData = SharedData.Instance().GetCharaData(text);
			Sprite tachieHead = CommonResourcesData.GetTachieHead(charaData.m_BattleIcon);
			if (tachieHead == null)
			{
				button.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: false);
				button.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
				button.transform.Find("IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charaData);
			}
			else
			{
				button.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: true);
				button.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
				button.transform.Find("IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
			}
			button.transform.Find("Name").gameObject.SetActive(value: true);
			button.transform.Find("Name").GetComponent<Text>().text = charaData.Indexs_Name["Name"].stringValue;
			button.transform.Find("Level").gameObject.SetActive(value: true);
			button.transform.Find("Level/Text").GetComponent<Text>().text = "LV." + charaData.m_Level;
			if (SharedData.Instance().FollowList.Contains(text) && SelectedCount < SharedData.Instance().FollowMaxCount)
			{
				button.transform.Find("Selected").gameObject.SetActive(value: true);
				button.name = button.name + "|" + text + "|1";
				SelectedCount++;
			}
			else
			{
				button.name = button.name + "|" + text + "|0";
			}
		}
		TitleText = CommonFunc.I18nGetLocalizedValue("选择队伍成员");
		UpdateCount(SelectedCount);
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/CharacterArea/Viewport/Content").GetChild(0).gameObject);
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/ChooseOK").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	private void UpdateCount(int _count)
	{
		ChooseCount.GetComponentInChildren<Text>().text = TitleText + "    <color=#F3E898>" + _count + "/" + SharedData.Instance().FollowMaxCount + "</color>";
		iconListController.InitIconList(NewFollowList, showLevel: false);
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		string[] array = go.name.Split('|');
		if (array[0].StartsWith("SelcetTeammate_") || array[0].StartsWith("SelcetPokemon_"))
		{
			if (array.Length >= 3 && (!(array[2] == "0") || SelectedCount < SharedData.Instance().FollowMaxCount))
			{
				if (array[2] == "0")
				{
					go.transform.Find("Selected").gameObject.SetActive(value: true);
					SelectedCount++;
					NewFollowList.Add(array[1]);
					go.name = array[0] + "|" + array[1] + "|1";
				}
				else
				{
					go.transform.Find("Selected").gameObject.SetActive(value: false);
					SelectedCount--;
					NewFollowList.Remove(array[1]);
					go.name = array[0] + "|" + array[1] + "|0";
				}
				UpdateCount(SelectedCount);
			}
		}
		else if (array[0] == "ChooseOK")
		{
			SharedData.Instance().FollowList.Clear();
			SharedData.Instance().FollowList.AddRange(NewFollowList);
			foreach (string follow in SharedData.Instance().FollowList)
			{
				GameDataManager.Instance().AddUnlockAtlasList(follow, "b01");
			}
			SharedData.Instance().player.InitFollows();
			SharedData.Instance().SetFieldMoveSpeedRate();
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				int index = SharedData.Instance().LoadedSceneStack.Count - 1;
				string sceneName = SharedData.Instance().LoadedSceneStack[index];
				SharedData.Instance().LoadedSceneStack.RemoveAt(index);
				SceneManager.UnloadSceneAsync(sceneName);
			}
			if (SharedData.Instance().SpawnMapName != "")
			{
				SharedData.Instance().m_MapController.LoadScene(SharedData.Instance().SpawnMapName);
			}
		}
		else if (array[0] == "ChooseCancel")
		{
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				int index2 = SharedData.Instance().LoadedSceneStack.Count - 1;
				string sceneName2 = SharedData.Instance().LoadedSceneStack[index2];
				SharedData.Instance().LoadedSceneStack.RemoveAt(index2);
				SceneManager.UnloadSceneAsync(sceneName2);
			}
			if (SharedData.Instance().SpawnMapName != "")
			{
				SharedData.Instance().m_MapController.LoadScene(SharedData.Instance().SpawnMapName);
			}
		}
	}
}
