using System.Collections;
using System.Threading;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AutoGameSaveController : MonoBehaviour
{
	public static AutoGameSaveController instance;

	private float timer;

	private float m_AutoSaveInterval = 180f;

	private Thread AutoSaveRecordThread;

	private void OnEnable()
	{
		Application.quitting += HandleQuit;
	}

	private void OnDisable()
	{
		Application.quitting -= HandleQuit;
	}

	private void HandleQuit()
	{
		AutoSave();
	}

	private void Start()
	{
		if (instance == null)
		{
			instance = this;
		}
		StartCoroutine(AutoSaveTask());
		timer = m_AutoSaveInterval;
	}

	private void OnDestroy()
	{
		RangePoolManager.instance.ClearObjectPool();
		if (AutoSaveRecordThread != null && AutoSaveRecordThread.IsAlive)
		{
			AutoSaveRecordThread.Join();
		}
	}

	private void Update()
	{
		timer += Time.deltaTime;
	}

	private IEnumerator AutoSaveTask()
	{
		while (true)
		{
			if (isCouldSave())
			{
				SharedData.Instance().m_IsAutoSaving = true;
				AutoSaveAsync();
				yield return null;
			}
			yield return null;
		}
	}

	private bool isCouldSave()
	{
		if (SharedData.Instance().m_IsAutoSaving)
		{
			return false;
		}
		if (timer < m_AutoSaveInterval)
		{
			return false;
		}
		gang_e04Table.Row loadMapE = SharedData.Instance().loadMapE04;
		if (loadMapE == null || loadMapE.savedata != "1")
		{
			return false;
		}
		if (SharedData.Instance().m_MapController == null || SharedData.Instance().m_MapController.player == null || SharedData.Instance().m_MapController.EffectTimer < 5f || SharedData.Instance().m_MapController.m_camera == null || SharedData.Instance().LoadedSceneStack.Count > 1 || SharedData.Instance().m_MapController.IsChating() || !SharedData.Instance().m_MapController.m_Menu3.gameObject.activeInHierarchy || SharedData.Instance().m_MapController.player.m_State != State.WaitingForInput || SharedData.Instance().m_MapController.isEnterBattleAnimPlaying || SharedData.Instance().m_PackageController.isOpen || SharedData.Instance().m_TraitPackageController.isOpen || SceneManager.sceneCount > 1)
		{
			return false;
		}
		timer = 0f;
		return true;
	}

	public void AutoSave()
	{
	}

	public void AutoSaveAsync()
	{
		SharedData.Instance().m_MapController.SaveMapSnapShot();
		Debug.Log("AutoSaveAsync Start");
		SharedData.Instance().m_MapController.AutoSaveAnimationOut();
		GameDataManager.Instance().configdata.currentAutoSaveIndex++;
		if (GameDataManager.Instance().configdata.currentAutoSaveIndex > 24)
		{
			GameDataManager.Instance().configdata.currentAutoSaveIndex = 17;
		}
		StartCoroutine(GameDataManager.Instance().SaveAsync(GameDataManager.Instance().configdata.currentAutoSaveIndex));
	}
}
