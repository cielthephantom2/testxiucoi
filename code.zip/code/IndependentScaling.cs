using UnityEngine;

public class IndependentScaling : MonoBehaviour
{
	private Vector3 originalScale;

	private void Awake()
	{
		originalScale = base.transform.localScale;
	}

	private void OnEnable()
	{
		Vector3 localScale = base.transform.parent.localScale;
		base.transform.localScale = new Vector3(originalScale.x / localScale.x, originalScale.y / localScale.y, originalScale.z / localScale.z);
	}
}
