public enum PackagerFunction
{
	None,
	Equip,
	Wugong,
	PlayerPackage,
	Shop,
	Loan,
	Redeem,
	Appreciation,
	BattleField,
	EvolutionEQ,
	Inheritance
}
