public enum StatusSub5Type
{
	Showwugong,
	Deletewugong
}
