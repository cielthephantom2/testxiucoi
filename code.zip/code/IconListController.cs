using System.Collections.Generic;
using UnityEngine;

public class IconListController : MonoBehaviour
{
	public void InitIconList(List<string> _followerList, bool showLevel = true, List<gang_b01SkinTable.Row> b01SkinRows = null)
	{
		for (int i = 1; i <= 6; i++)
		{
			base.transform.Find("Icon" + i).gameObject.SetActive(value: false);
		}
		for (int j = 1; j <= _followerList.Count; j++)
		{
			if (_followerList[j - 1] != "")
			{
				base.transform.Find("Icon" + j).gameObject.SetActive(value: true);
				if (b01SkinRows != null && j - 1 < b01SkinRows.Count)
				{
					base.transform.Find("Icon" + j).GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(_followerList[j - 1].Split("|")[0], showLevel ? int.Parse(_followerList[j - 1].Split("|")[1]) : 0, b01SkinRows[j - 1]);
				}
				else
				{
					base.transform.Find("Icon" + j).GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(_followerList[j - 1].Split("|")[0], showLevel ? int.Parse(_followerList[j - 1].Split("|")[1]) : 0);
				}
			}
		}
	}
}
