public enum GameIconType
{
	Auto,
	KeyBoard,
	Xbox,
	PS,
	Switch
}
