using System.Collections.Generic;
using System.Linq;
using MessagePack;
using UnityEngine;

public class gang_b03Table
{
	[MessagePackObject(false)]
	public class Row
	{
		[Key(0)]
		public string ID;

		[Key(1)]
		public string Star;

		[Key(2)]
		public string Name;

		[Key(3)]
		public string Name_EN;

		[Key(4)]
		public string Icon;

		[Key(5)]
		public string BookIcon;

		[Key(6)]
		public string Origin;

		[Key(7)]
		public string LV;

		[Key(8)]
		public string Style;

		[Key(9)]
		public string Damage;

		[Key(10)]
		public string Damageadd;

		[Key(11)]
		public string Expend;

		[Key(12)]
		public string Expendadd;

		[Key(13)]
		public string EXP;

		[Key(14)]
		public string EXPadd;

		[Key(15)]
		public string Attckstyle;

		[Key(16)]
		public string Area;

		[Key(17)]
		public string Range;

		[Key(18)]
		public string Space;

		[Key(19)]
		public string Decreaserate;

		[Key(20)]
		public string DelayedattackType;

		[Key(21)]
		public string DelayedattackTime;

		[Key(22)]
		public string Effect;

		[Key(23)]
		public string Sound;

		[Key(24)]
		public string Site;

		[Key(25)]
		public string Beat;

		[Key(26)]
		public string Dart;

		[Key(27)]
		public string Crit;

		[Key(28)]
		public string Critadd;

		[Key(29)]
		public string Crit1;

		[Key(30)]
		public string Crit1add;

		[Key(31)]
		public string Combo;

		[Key(32)]
		public string Comboadd;

		[Key(33)]
		public string Skill1;

		[Key(34)]
		public string Skill1EC;

		[Key(35)]
		public string Skill2;

		[Key(36)]
		public string Skill2EC;

		[Key(37)]
		public string Skill3;

		[Key(38)]
		public string Skill3EC;

		[Key(39)]
		public string Skill4;

		[Key(40)]
		public string Skill4EC;

		[Key(41)]
		public string Skill5;

		[Key(42)]
		public string Skill5EC;

		[Key(43)]
		public string Limit1;

		[Key(44)]
		public string Limit2;

		[Key(45)]
		public string Limit3;

		[Key(46)]
		public string Paraplus1;

		[Key(47)]
		public string Paraplus2;

		[Key(48)]
		public string Paraplus3;

		[Key(49)]
		public string Paraplus4;

		[Key(50)]
		public string AppendTraits;

		[Key(51)]
		public string atlasType;

		[Key(52)]
		public string isAtlas;

		[Key(53)]
		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Star = list[i][num++],
				Name = list[i][num++],
				Icon = list[i][num++],
				BookIcon = list[i][num++],
				Origin = list[i][num++],
				LV = list[i][num++],
				Style = list[i][num++],
				Damage = list[i][num++],
				Damageadd = list[i][num++],
				Expend = list[i][num++],
				Expendadd = list[i][num++],
				EXP = list[i][num++],
				EXPadd = list[i][num++],
				Attckstyle = list[i][num++],
				Area = list[i][num++],
				Range = list[i][num++],
				Space = list[i][num++],
				Decreaserate = list[i][num++],
				DelayedattackType = list[i][num++],
				DelayedattackTime = list[i][num++],
				Effect = list[i][num++],
				Sound = list[i][num++],
				Site = list[i][num++],
				Beat = list[i][num++],
				Dart = list[i][num++],
				Crit = list[i][num++],
				Critadd = list[i][num++],
				Crit1 = list[i][num++],
				Crit1add = list[i][num++],
				Combo = list[i][num++],
				Comboadd = list[i][num++],
				Skill1 = list[i][num++],
				Skill1EC = list[i][num++],
				Skill2 = list[i][num++],
				Skill2EC = list[i][num++],
				Skill3 = list[i][num++],
				Skill3EC = list[i][num++],
				Skill4 = list[i][num++],
				Skill4EC = list[i][num++],
				Skill5 = list[i][num++],
				Skill5EC = list[i][num++],
				Limit1 = list[i][num++],
				Limit2 = list[i][num++],
				Limit3 = list[i][num++],
				Paraplus1 = list[i][num++],
				Paraplus2 = list[i][num++],
				Paraplus3 = list[i][num++],
				Paraplus4 = list[i][num++],
				AppendTraits = list[i][num++],
				atlasType = list[i][num++],
				isAtlas = list[i][num++]
			};
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_b03_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_b03_" + row.ID + "_Name")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => find.Split('|').ToList().Contains(x.ID));
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Star(string find)
	{
		return rowList.Find((Row x) => x.Star == find);
	}

	public List<Row> FindAll_Star(string find)
	{
		return rowList.FindAll((Row x) => x.Star == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Name_EN(string find)
	{
		return rowList.Find((Row x) => x.Name_EN == find);
	}

	public List<Row> FindAll_Name_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Name_EN == find);
	}

	public Row Find_Icon(string find)
	{
		return rowList.Find((Row x) => x.Icon == find);
	}

	public List<Row> FindAll_Icon(string find)
	{
		return rowList.FindAll((Row x) => x.Icon == find);
	}

	public Row Find_BookIcon(string find)
	{
		return rowList.Find((Row x) => x.BookIcon == find);
	}

	public List<Row> FindAll_BookIcon(string find)
	{
		return rowList.FindAll((Row x) => x.BookIcon == find);
	}

	public Row Find_Origin(string find)
	{
		return rowList.Find((Row x) => x.Origin == find);
	}

	public List<Row> FindAll_Origin(string find)
	{
		return rowList.FindAll((Row x) => x.Origin == find);
	}

	public Row Find_LV(string find)
	{
		return rowList.Find((Row x) => x.LV == find);
	}

	public List<Row> FindAll_LV(string find)
	{
		return rowList.FindAll((Row x) => x.LV == find);
	}

	public Row Find_Style(string find)
	{
		return rowList.Find((Row x) => x.Style == find);
	}

	public List<Row> FindAll_Style(string find)
	{
		return rowList.FindAll((Row x) => x.Style == find);
	}

	public Row Find_Damage(string find)
	{
		return rowList.Find((Row x) => x.Damage == find);
	}

	public List<Row> FindAll_Damage(string find)
	{
		return rowList.FindAll((Row x) => x.Damage == find);
	}

	public Row Find_Damageadd(string find)
	{
		return rowList.Find((Row x) => x.Damageadd == find);
	}

	public List<Row> FindAll_Damageadd(string find)
	{
		return rowList.FindAll((Row x) => x.Damageadd == find);
	}

	public Row Find_Expend(string find)
	{
		return rowList.Find((Row x) => x.Expend == find);
	}

	public List<Row> FindAll_Expend(string find)
	{
		return rowList.FindAll((Row x) => x.Expend == find);
	}

	public Row Find_Expendadd(string find)
	{
		return rowList.Find((Row x) => x.Expendadd == find);
	}

	public List<Row> FindAll_Expendadd(string find)
	{
		return rowList.FindAll((Row x) => x.Expendadd == find);
	}

	public Row Find_EXP(string find)
	{
		return rowList.Find((Row x) => x.EXP == find);
	}

	public List<Row> FindAll_EXP(string find)
	{
		return rowList.FindAll((Row x) => x.EXP == find);
	}

	public Row Find_EXPadd(string find)
	{
		return rowList.Find((Row x) => x.EXPadd == find);
	}

	public List<Row> FindAll_EXPadd(string find)
	{
		return rowList.FindAll((Row x) => x.EXPadd == find);
	}

	public Row Find_Attckstyle(string find)
	{
		return rowList.Find((Row x) => x.Attckstyle == find);
	}

	public List<Row> FindAll_Attckstyle(string find)
	{
		return rowList.FindAll((Row x) => x.Attckstyle == find);
	}

	public Row Find_Area(string find)
	{
		return rowList.Find((Row x) => x.Area == find);
	}

	public List<Row> FindAll_Area(string find)
	{
		return rowList.FindAll((Row x) => x.Area == find);
	}

	public Row Find_Range(string find)
	{
		return rowList.Find((Row x) => x.Range == find);
	}

	public List<Row> FindAll_Range(string find)
	{
		return rowList.FindAll((Row x) => x.Range == find);
	}

	public Row Find_Effect(string find)
	{
		return rowList.Find((Row x) => x.Effect == find);
	}

	public List<Row> FindAll_Effect(string find)
	{
		return rowList.FindAll((Row x) => x.Effect == find);
	}

	public Row Find_Space(string find)
	{
		return rowList.Find((Row x) => x.Space == find);
	}

	public List<Row> FindAll_Space(string find)
	{
		return rowList.FindAll((Row x) => x.Space == find);
	}

	public Row Find_Sound(string find)
	{
		return rowList.Find((Row x) => x.Sound == find);
	}

	public List<Row> FindAll_Sound(string find)
	{
		return rowList.FindAll((Row x) => x.Sound == find);
	}

	public Row Find_Site(string find)
	{
		return rowList.Find((Row x) => x.Site == find);
	}

	public List<Row> FindAll_Site(string find)
	{
		return rowList.FindAll((Row x) => x.Site == find);
	}

	public Row Find_Beat(string find)
	{
		return rowList.Find((Row x) => x.Beat == find);
	}

	public List<Row> FindAll_Beat(string find)
	{
		return rowList.FindAll((Row x) => x.Beat == find);
	}

	public Row Find_Dart(string find)
	{
		return rowList.Find((Row x) => x.Dart == find);
	}

	public List<Row> FindAll_Dart(string find)
	{
		return rowList.FindAll((Row x) => x.Dart == find);
	}

	public Row Find_Crit(string find)
	{
		return rowList.Find((Row x) => x.Crit == find);
	}

	public List<Row> FindAll_Crit(string find)
	{
		return rowList.FindAll((Row x) => x.Crit == find);
	}

	public Row Find_Critadd(string find)
	{
		return rowList.Find((Row x) => x.Critadd == find);
	}

	public List<Row> FindAll_Critadd(string find)
	{
		return rowList.FindAll((Row x) => x.Critadd == find);
	}

	public Row Find_Crit1(string find)
	{
		return rowList.Find((Row x) => x.Crit1 == find);
	}

	public List<Row> FindAll_Crit1(string find)
	{
		return rowList.FindAll((Row x) => x.Crit1 == find);
	}

	public Row Find_Crit1add(string find)
	{
		return rowList.Find((Row x) => x.Crit1add == find);
	}

	public List<Row> FindAll_Crit1add(string find)
	{
		return rowList.FindAll((Row x) => x.Crit1add == find);
	}

	public Row Find_Combo(string find)
	{
		return rowList.Find((Row x) => x.Combo == find);
	}

	public List<Row> FindAll_Combo(string find)
	{
		return rowList.FindAll((Row x) => x.Combo == find);
	}

	public Row Find_Comboadd(string find)
	{
		return rowList.Find((Row x) => x.Comboadd == find);
	}

	public List<Row> FindAll_Comboadd(string find)
	{
		return rowList.FindAll((Row x) => x.Comboadd == find);
	}

	public Row Find_Skill1(string find)
	{
		return rowList.Find((Row x) => x.Skill1 == find);
	}

	public List<Row> FindAll_Skill1(string find)
	{
		return rowList.FindAll((Row x) => x.Skill1 == find);
	}

	public Row Find_Skill2(string find)
	{
		return rowList.Find((Row x) => x.Skill2 == find);
	}

	public List<Row> FindAll_Skill2(string find)
	{
		return rowList.FindAll((Row x) => x.Skill2 == find);
	}

	public Row Find_Skill3(string find)
	{
		return rowList.Find((Row x) => x.Skill3 == find);
	}

	public List<Row> FindAll_Skill3(string find)
	{
		return rowList.FindAll((Row x) => x.Skill3 == find);
	}

	public Row Find_Skill4(string find)
	{
		return rowList.Find((Row x) => x.Skill4 == find);
	}

	public List<Row> FindAll_Skill4(string find)
	{
		return rowList.FindAll((Row x) => x.Skill4 == find);
	}

	public Row Find_Skill5(string find)
	{
		return rowList.Find((Row x) => x.Skill5 == find);
	}

	public List<Row> FindAll_Skill5(string find)
	{
		return rowList.FindAll((Row x) => x.Skill5 == find);
	}

	public Row Find_Limit1(string find)
	{
		return rowList.Find((Row x) => x.Limit1 == find);
	}

	public List<Row> FindAll_Limit1(string find)
	{
		return rowList.FindAll((Row x) => x.Limit1 == find);
	}

	public Row Find_Limit2(string find)
	{
		return rowList.Find((Row x) => x.Limit2 == find);
	}

	public List<Row> FindAll_Limit2(string find)
	{
		return rowList.FindAll((Row x) => x.Limit2 == find);
	}

	public Row Find_Limit3(string find)
	{
		return rowList.Find((Row x) => x.Limit3 == find);
	}

	public List<Row> FindAll_Limit3(string find)
	{
		return rowList.FindAll((Row x) => x.Limit3 == find);
	}

	public Row Find_Paraplus1(string find)
	{
		return rowList.Find((Row x) => x.Paraplus1 == find);
	}

	public List<Row> FindAll_Paraplus1(string find)
	{
		return rowList.FindAll((Row x) => x.Paraplus1 == find);
	}

	public Row Find_Paraplus2(string find)
	{
		return rowList.Find((Row x) => x.Paraplus2 == find);
	}

	public List<Row> FindAll_Paraplus2(string find)
	{
		return rowList.FindAll((Row x) => x.Paraplus2 == find);
	}

	public Row Find_Paraplus3(string find)
	{
		return rowList.Find((Row x) => x.Paraplus3 == find);
	}

	public List<Row> FindAll_Paraplus3(string find)
	{
		return rowList.FindAll((Row x) => x.Paraplus3 == find);
	}

	public Row Find_Paraplus4(string find)
	{
		return rowList.Find((Row x) => x.Paraplus4 == find);
	}

	public List<Row> FindAll_Paraplus4(string find)
	{
		return rowList.FindAll((Row x) => x.Paraplus4 == find);
	}

	public Row Find_AppendTraits(string find)
	{
		return rowList.Find((Row x) => x.AppendTraits == find);
	}

	public List<Row> FindAll_AppendTraits(string find)
	{
		return rowList.FindAll((Row x) => x.AppendTraits == find);
	}
}
