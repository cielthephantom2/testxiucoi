using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using DG.Tweening;
using Spine;
using Spine.Unity;
using SuperTiled2Unity;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;
using UnityEngine.UI;

public class MapController : MonoBehaviour
{
	public class Portal
	{
		public string name = "";

		public Vector3Int position = Vector3Int.zero;

		public string teleport = "";

		public int hidden;
	}

	public class Event
	{
		public string name = "";

		public string eventid = "";

		public gang_e01Table.Row originevdata;

		public gang_e01Table.Row evdata;

		public SuperObject tileobj;

		public GameObject obj;

		public EventController eventController;

		public int flow = -1;

		public bool elseroute;

		public bool activelock;
	}

	public class ChatInfo
	{
		public Event ev;

		public string name;

		public string text;

		public int position;

		public string message;

		public string picture;
	}

	private Transform canvas;

	public SuperMap map;

	public Tilemap tilemap;

	public List<Tilemap> RandomFightGridMapList;

	public Tilemap InteractiveGrassLayer;

	public InteractiveGrass m_InteractiveGrass;

	public List<SpriteRenderer> m_InteractiveGrassObjList = new List<SpriteRenderer>();

	private List<Vector4> m_InteractiveGrassPoslist = new List<Vector4>();

	public List<Vector4> m_InteractiveGrassTracePoslist = new List<Vector4>();

	public List<Vector3> traceList = new List<Vector3>();

	private float recordTraceTimer;

	private float fadeTraceTimer;

	public Vector2Int mapSize;

	public List<Vector3Int> obstacle = new List<Vector3Int>();

	public List<Vector3Int> sliding = new List<Vector3Int>();

	public Dictionary<string, Vector3Int> mapUnits = new Dictionary<string, Vector3Int>();

	public List<GameObject> mapUnitMarks = new List<GameObject>();

	public OhPlayerController player;

	private Dictionary<string, Portal> portals = new Dictionary<string, Portal>();

	private Dictionary<string, Event> events = new Dictionary<string, Event>();

	private List<Event> eof_events = new List<Event>();

	private SuperObject[] m_SuperObjects;

	private int m_SortingOrder;

	private GameObject m_Dialog;

	private GameObject m_JoyStick;

	private GameObject m_JoyTouch;

	private Text m_Chat_NameL;

	private Text m_Chat_Name;

	private GameObject m_TaChile_L;

	private GameObject m_TaChile_R;

	private Text m_Chat_Text;

	private SkeletonGraphic m_News_Ani;

	private SkeletonGraphic m_Tecs_Ani;

	public GameObject m_WantedList;

	private GameObject m_Chat_Icon;

	private GameObject m_Explore;

	private Text m_Explore_Text;

	private GameObject m_Explore_IconFrame;

	private GameObject m_Explore_VoiceOver;

	private GameObject m_Explore_BrowseURL;

	private GameObject m_Explore_Guide;

	private GameObject m_Selector;

	public Menu2Controller m_Menu2;

	public Menu3Controller m_Menu3;

	private List<ChatInfo> m_ChatList = new List<ChatInfo>();

	private List<string> m_ExploreList = new List<string>();

	public Event m_Canvas_Event;

	private Event m_Current_Event;

	public bool m_LastClick;

	public bool m_ScenePlaying;

	public AudioSource m_AudioSource;

	private AudioClip FieldBGM;

	private AudioClip DefaultFieldBGM;

	private AudioSource m_EffectSound;

	private GameObject m_HoldCamera;

	public bool m_EventPause;

	private bool m_LoadingScene;

	private GameObject m_Curcor;

	public string m_MapType = "";

	private Texture2D m_Talk_Pointer;

	private Texture2D m_Loot_Pointer;

	private Texture2D m_Wanted_Pointer;

	private Texture2D m_Walk_Pointer;

	private Texture2D m_Select_Pointer;

	private Vector3Int m_PrePointer = Vector3Int.zero;

	public bool IsCameraShadow;

	private bool InitOK;

	private bool IsTeleport;

	public Camera m_camera;

	private float speed = 0.333f;

	private Vector3 velocity;

	public Vector3 m_CameraTarget = Vector3.zero;

	[SerializeField]
	private Animator transition;

	public int m_LastClickCamera;

	private Vector3 m_LastClickCameraPos = Vector3.zero;

	public GameObject m_InputField;

	private int m_chat_process;

	private string m_chat_content = "";

	public string m_leave_pos = "";

	public string sceneName = "";

	public float MovingSpeedRate = 1f;

	private const float MovementBlockSize = 50f;

	private int m_MineCount;

	private float m_exploreMinimumShowTime = 0.1f;

	private float m_exploreShowTimer;

	private Transform m_location;

	private Transform m_money;

	private Transform m_SaveData;

	private GameObject WantedPrefab;

	public float EffectTimer;

	private string mapSceneName = "";

	public bool isEnterBattleAnimPlaying;

	public static string[] enemygid;

	public Dictionary<string, GameObject> AllCharacterObjs = new Dictionary<string, GameObject>();

	private List<RandomFightInfo> randomFightInfos = new List<RandomFightInfo>();

	private List<RandomFightInfo> couldFightList = new List<RandomFightInfo>();

	private int currentRandomPlayerLevel = 1;

	private string inputString = "";

	private string targetString = "showmethemoney";

	private int maxLength = 100;

	private void Awake()
	{
		SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: false);
		sceneName = SharedData.Instance().loadMapE04.id;
		if (UnityEngine.Object.FindObjectsOfType<SuperMap>().Length != 0)
		{
			map = UnityEngine.Object.FindObjectsOfType<SuperMap>()[0];
		}
		else
		{
			map = MapLoader.instance.AsyncLoadMapByName(SharedData.Instance().loadMapE04).GetComponent<SuperMap>();
		}
		map.gameObject.isStatic = true;
		mapSize = new Vector2Int(map.m_Width, map.m_Height);
		UnityEngine.Object.FindObjectsOfType<Tilemap>().ToList().ForEach(delegate(Tilemap x)
		{
			x.gameObject.SetActive(!x.name.StartsWith("terrain"));
		});
		List<SuperTileLayer> source = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>().ToList();
		UnityEngine.Object.FindObjectsOfType<TilemapRenderer>().ToList();
		List<SuperGroupLayer> list = UnityEngine.Object.FindObjectsOfType<SuperGroupLayer>().ToList();
		List<SuperObjectLayer> list2 = UnityEngine.Object.FindObjectsOfType<SuperObjectLayer>().ToList();
		RandomFightGridMapList = UnityEngine.Object.FindObjectsOfType<Tilemap>().ToList().FindAll((Tilemap s) => s.name.StartsWith("RandomFightGrid"));
		string text = "FieldLayer";
		string text2 = "role";
		string[] array = SharedData.Instance().loadMapE04.mapName.Split('|');
		if (array.Length > 1)
		{
			text = text + "|" + array[1];
			text2 = text2 + "|" + array[1];
		}
		SuperTileLayer superTileLayer = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>().FirstOrDefault((SuperTileLayer s) => s.name == "switch-fire-event");
		if (superTileLayer != null)
		{
			superTileLayer.gameObject.SetActive(value: false);
		}
		SuperObjectLayer superObjectLayer = null;
		bool active = true;
		for (int i = 0; i < list2.Count; i++)
		{
			SuperObjectLayer superObjectLayer2 = list2[i];
			if (!"掉落".Equals(superObjectLayer2.name))
			{
				if (text2.Equals(superObjectLayer2.name))
				{
					superObjectLayer = superObjectLayer2;
				}
				superObjectLayer2.gameObject.SetActive(value: false);
			}
		}
		bool flag = false;
		for (int j = 0; j < list2.Count; j++)
		{
			SuperObjectLayer superObjectLayer3 = list2[j];
			if ("掉落".Equals(superObjectLayer3.name))
			{
				continue;
			}
			if (text2.Equals(superObjectLayer3.name))
			{
				superObjectLayer = superObjectLayer3;
				continue;
			}
			bool active2 = false;
			if (!flag)
			{
				if (CheckFlag(superObjectLayer3.name, 1))
				{
					active2 = true;
					active = true;
					flag = true;
				}
				else if (CheckFlag(superObjectLayer3.name, 2))
				{
					active2 = true;
					active = false;
					flag = true;
				}
			}
			superObjectLayer3.gameObject.SetActive(active2);
		}
		if (superObjectLayer != null)
		{
			superObjectLayer.gameObject.SetActive(active);
		}
		foreach (SuperGroupLayer item2 in list)
		{
			if (item2.name.StartsWith("BattleLayer"))
			{
				item2.gameObject.SetActive(value: false);
			}
			else if (item2.name.Equals(text))
			{
				item2.gameObject.SetActive(value: true);
			}
			else if (item2.name.StartsWith("FieldLayer"))
			{
				item2.gameObject.SetActive(value: false);
			}
		}
		m_SuperObjects = UnityEngine.Object.FindObjectsOfType<SuperObject>();
		SuperTileLayer superTileLayer2 = source.FirstOrDefault((SuperTileLayer s) => s.name == "obstruct");
		this.tilemap = ((superTileLayer2.GetComponent<Tilemap>() != null) ? superTileLayer2.GetComponent<Tilemap>() : superTileLayer2.GetComponentInParent<Tilemap>());
		for (int k = 0; k < mapSize.x; k++)
		{
			for (int l = 0; l < mapSize.y; l++)
			{
				Vector3Int item = new Vector3Int(k, l, 0);
				if (this.tilemap.HasTile(new Vector3Int(k, -l, 0)))
				{
					obstacle.Add(item);
				}
			}
		}
		this.tilemap.gameObject.SetActive(value: false);
		Tilemap tilemap = UnityEngine.Object.FindObjectsOfType<Tilemap>().FirstOrDefault((Tilemap s) => s.name == "slide");
		if (tilemap != null)
		{
			for (int m = 0; m < mapSize.x; m++)
			{
				for (int n = 0; n < mapSize.y; n++)
				{
					Vector3Int vector3Int = new Vector3Int(m, n, 0);
					if (tilemap.HasTile(new Vector3Int(m, -n, 0)))
					{
						Vector3Int vector3Int2 = vector3Int;
						Debug.Log("sliding.Add(" + vector3Int2.ToString() + ")");
						sliding.Add(vector3Int);
					}
				}
			}
			tilemap.gameObject.SetActive(value: false);
		}
		canvas = UnityEngine.Object.Instantiate(CommonResourcesData.FieldCanvasPrefab).transform;
		canvas.name = "Canvas";
		if (SharedData.Instance().SceneBefore != sceneName && (++SharedData.Instance().m_MineRefreshChangeFieldNum == SharedData.Instance().MineRefreshChangeFieldNum || ++SharedData.Instance().m_MineRefreshWalkStep == SharedData.Instance().MineRefreshWalkStep))
		{
			SharedData.Instance().m_MineRefreshChangeFieldNum = 0;
			SharedData.Instance().m_MineRefreshWalkStep = 0;
			SharedData.Instance().mapMineList.Clear();
			SharedData.Instance().mapMineCouldRefreshList.Clear();
		}
	}

	private void InitInteractiveGrass()
	{
		InteractiveGrassLayer = UnityEngine.Object.FindObjectsOfType<Tilemap>().FirstOrDefault((Tilemap s) => s.name == "InteractiveGrassLayer");
		if (InteractiveGrassLayer == null)
		{
			return;
		}
		GameObject gameObject = new GameObject();
		gameObject.name = "Grass";
		gameObject.transform.parent = base.gameObject.transform.parent;
		m_InteractiveGrass = gameObject.AddComponent<InteractiveGrass>();
		for (int i = 0; i < mapSize.x; i++)
		{
			for (int j = 0; j < mapSize.y; j++)
			{
				new Vector3Int(i, j, 0);
				if (InteractiveGrassLayer.HasTile(new Vector3Int(i, -j, 0)))
				{
					Sprite sprite = CommonResourcesData.LoadInteractiveGrass(((SuperTile)InteractiveGrassLayer.GetTile(new Vector3Int(i, -j, 0))).name);
					if (!(sprite == null))
					{
						GameObject obj = UnityEngine.Object.Instantiate(CommonResourcesData.m_InteractiveGrassPrefab, map.transform);
						SpriteRenderer component = obj.GetComponent<SpriteRenderer>();
						component.sprite = sprite;
						obj.transform.localPosition = new Vector3(25 + (i + 1) * 50, -50 - (j - 1) * 50);
						m_InteractiveGrassObjList.Add(component);
						obj.transform.parent = gameObject.transform;
					}
				}
			}
		}
		InteractiveGrassLayer.gameObject.SetActive(value: false);
		int sortingOrder = SharedData.Instance().player.gameObject.GetComponentInChildren<SkeletonAnimation>(includeInactive: true).GetComponent<MeshRenderer>().sortingOrder;
		m_InteractiveGrass.ReSortGrassOrder(sortingOrder);
	}

	private void InitTerrain()
	{
		if (SharedData.Instance().mapMineList.Find((MineInfo x) => x._scenename == sceneName) == null)
		{
			SuperObject[] array = (from n in getByType("MINE")
				orderby Guid.NewGuid()
				select n).ToArray();
			foreach (SuperObject superObject in array)
			{
				SuperCustomProperties component = superObject.GetComponent<SuperCustomProperties>();
				string text = "";
				Vector3Int zero = Vector3Int.zero;
				foreach (CustomProperty property in component.m_Properties)
				{
					if (property.m_Name == "c01ID")
					{
						text = property.m_Value;
						string[] array2 = text.Split("|");
						List<float> list = new List<float>();
						float num = 0f;
						string[] array3 = array2;
						foreach (string text2 in array3)
						{
							list.Add(float.Parse(text2.Split("&")[1], CultureInfo.InvariantCulture));
							num += float.Parse(text2.Split("&")[1], CultureInfo.InvariantCulture);
						}
						for (int k = 0; k < list.Count; k++)
						{
							list[k] /= num;
						}
						float num2 = UnityEngine.Random.Range(0f, 1f);
						int num3 = 0;
						for (float num4 = list[num3]; num2 > num4; num4 += list[num3])
						{
							num3++;
							if (num3 >= list.Count)
							{
								num3--;
								break;
							}
						}
						text = array2[num3].Split("&")[0];
					}
					zero.x = Mathf.FloorToInt(superObject.m_X / 50f);
					zero.y = Mathf.FloorToInt(Mathf.Abs(superObject.m_Y) / 50f);
				}
				InitMines(superObject, zero, text);
			}
			return;
		}
		foreach (MineInfo item in SharedData.Instance().mapMineList.FindAll((MineInfo x) => x._scenename == sceneName))
		{
			if (!item._isDigged)
			{
				SuperObject[] byName = getByName(item._tileObjName);
				if (byName.Length != 0)
				{
					InitMines(byName[0], item._grid, item._c04ID, isFirst: false);
				}
			}
		}
	}

	private void InitMines(SuperObject _tileObj, Vector3Int _pos, string _mineInfo, bool isFirst = true)
	{
		GameObject original = null;
		switch (_mineInfo)
		{
		case "300001":
		case "300003":
		case "300005":
		case "300006":
		case "300008":
		case "300010":
		case "300012":
			original = CommonResourcesData.m_Mine300001;
			break;
		case "300002":
		case "300007":
		case "300009":
		case "300011":
		case "300013":
			original = CommonResourcesData.m_Mine300002;
			break;
		case "300014":
		case "300016":
			original = CommonResourcesData.m_Mine300003;
			break;
		case "300015":
		case "300017":
		case "300019":
			original = CommonResourcesData.m_Mine300004;
			break;
		case "300018":
		case "300020":
			original = CommonResourcesData.m_Mine300005;
			break;
		}
		if (isFirst)
		{
			if (SharedData.Instance().mapMineCouldRefreshList.Find((RefreshMineInfo x) => x._scenename == sceneName) == null)
			{
				RefreshMineInfo refreshMineInfo = new RefreshMineInfo();
				refreshMineInfo._scenename = sceneName;
				refreshMineInfo._couldRefresh = false;
				SharedData.Instance().mapMineCouldRefreshList.Add(refreshMineInfo);
			}
			MineInfo mineInfo = new MineInfo();
			mineInfo._scenename = sceneName;
			mineInfo._grid = _pos;
			mineInfo._tileObjName = _tileObj.name;
			mineInfo._c04ID = _mineInfo;
			mineInfo._isDigged = false;
			SharedData.Instance().mapMineList.Add(mineInfo);
			if (++m_MineCount > SharedData.Instance().MaxMineNumInOneMap)
			{
				mineInfo._isDigged = true;
				return;
			}
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(original, map.transform);
		gameObject.name = _tileObj.m_TiledName;
		gameObject.transform.localPosition = new Vector3(25 + _pos.x * 50, -25 - _pos.y * 50);
		gameObject.transform.parent = base.transform.parent;
		Event @event = new Event
		{
			name = _tileObj.m_TiledName,
			eventid = "MINING_00_1",
			tileobj = _tileObj,
			flow = 1
		};
		@event.obj = gameObject;
		@event.evdata = CommonResourcesData.e01.Find_flag("MINING_00_1");
		@event.originevdata = @event.evdata;
		SharedData.Instance().FlagList[@event.evdata.flag] = 1;
		events.Add(_tileObj.m_TiledName, @event);
		EventController eventController = (@event.eventController = gameObject.GetComponent<EventController>());
		eventController.tileName = _tileObj.m_TiledName;
		eventController.Init();
	}

	public void RefreshUnKnownItem()
	{
		if (!(SharedData.Instance().CurrentCharaData.GetFieldValueByName("Appreciation") > 0f))
		{
			return;
		}
		List<string> list = new List<string>();
		Dictionary<string, int> dictionary = new Dictionary<string, int>();
		foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
		{
			if (item.Key.Contains("Mine"))
			{
				list.Add(item.Key);
				string key = item.Key.Split("&")[1];
				if (dictionary.ContainsKey(key))
				{
					dictionary[key]++;
				}
				else
				{
					dictionary.Add(key, 1);
				}
			}
		}
		foreach (string item2 in list)
		{
			SharedData.Instance().PlayerPackage.Remove(item2);
		}
		foreach (KeyValuePair<string, int> item3 in dictionary)
		{
			SharedData.Instance().PackageAdd(item3.Key, 1);
		}
	}

	private void Start()
	{
		GameDataManager.Instance().sceneLoadData = false;
		InputDeviceDetector.instance.ClearJoyStack();
		if (SharedData.Instance().protagonistSkinDataNew.isCustom && !SharedData.Instance().InitSkin)
		{
			UnityEngine.Object.Instantiate(CommonResourcesData.ProtagonistSkin);
		}
		string sceneName = SharedData.Instance().loadMapE04.id;
		mapSceneName = sceneName;
		foreach (gang_e07Table.Row item in CommonResourcesData.e07.GetRowList().FindAll((gang_e07Table.Row x) => x.UnLockE04Id.Split('|').ToList().Contains(sceneName)))
		{
			if (!SharedData.Instance().m_UnLockMapIconList.Contains(item.id + "&"))
			{
				SharedData sharedData = SharedData.Instance();
				sharedData.m_UnLockMapIconList = sharedData.m_UnLockMapIconList + item.id + "&";
			}
		}
		Debug.Log("m_create_serial_id = " + GameDataManager.Instance().configdata.m_create_serial_id);
		SetOverheadCamera();
		if (IsCameraShadow)
		{
			UnityEngine.Object.Instantiate(CommonResourcesData.cameraShadowPrefab, base.transform).transform.localPosition = new Vector3(0f, 0f, 10f);
		}
		m_Talk_Pointer = CommonResourcesData.m_Talk_Pointer;
		m_Loot_Pointer = CommonResourcesData.m_Loot_Pointer;
		m_Wanted_Pointer = CommonResourcesData.m_Wanted_Pointer;
		WantedPrefab = CommonResourcesData.WantedPrefab;
		m_Walk_Pointer = null;
		m_Select_Pointer = null;
		m_AudioSource = GetComponent<AudioSource>();
		if (SharedData.Instance().loadMapE04.bgm != "")
		{
			DefaultFieldBGM = CommonResourcesData.LoadBgm(SharedData.Instance().loadMapE04.bgm);
			m_AudioSource.clip = DefaultFieldBGM;
			m_AudioSource.Play();
		}
		m_EffectSound = base.transform.Find("EffectSound").GetComponent<AudioSource>();
		m_SortingOrder = UnityEngine.Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "underfoot").sortingOrder;
		m_Dialog = canvas.Find("Dialog").gameObject;
		m_Dialog.SetActive(value: false);
		m_JoyStick = canvas.Find("WalkMenu/JoyStick").gameObject;
		m_JoyTouch = canvas.Find("WalkMenu/JoyTouch").gameObject;
		m_Chat_Name = m_Dialog.transform.Find("Name/Text").GetComponent<Text>();
		m_Chat_NameL = m_Dialog.transform.Find("NameL/Text").GetComponent<Text>();
		m_Chat_Text = m_Dialog.transform.Find("Text").GetComponent<Text>();
		m_TaChile_L = canvas.Find("TachieL").gameObject;
		m_TaChile_R = canvas.Find("Tachie").gameObject;
		CloseTachie();
		if (GameDataManager.Instance().configdata.language == "English")
		{
			m_News_Ani = canvas.Find("NewsAniEN").GetComponent<SkeletonGraphic>();
			m_Tecs_Ani = canvas.Find("TecsAniEN").GetComponent<SkeletonGraphic>();
		}
		else
		{
			m_News_Ani = canvas.Find("NewsAni").GetComponent<SkeletonGraphic>();
			m_Tecs_Ani = canvas.Find("TecsAni").GetComponent<SkeletonGraphic>();
		}
		m_News_Ani.AnimationState.Complete += News_Ani_Complete;
		m_Tecs_Ani.AnimationState.Complete += Tecs_Ani_Complete;
		m_Explore = canvas.Find("Explore").gameObject;
		m_Explore_Text = m_Explore.transform.Find("Explore/Text").GetComponent<Text>();
		m_Explore_IconFrame = m_Explore.transform.Find("IconFrame").gameObject;
		m_Explore_IconFrame.SetActive(value: false);
		m_Explore_VoiceOver = m_Explore.transform.Find("VoiceOver").gameObject;
		m_Explore_VoiceOver.SetActive(value: false);
		m_Explore_BrowseURL = m_Explore.transform.Find("BrowseURL").gameObject;
		m_Explore_BrowseURL.SetActive(value: false);
		m_Explore_Guide = m_Explore.transform.Find("Guide").gameObject;
		m_Explore_Guide.SetActive(value: false);
		m_Explore.SetActive(value: false);
		m_WantedList = canvas.Find("WantedList").gameObject;
		m_WantedList.SetActive(value: false);
		EventTriggerListener.Get(m_WantedList.transform.Find("WantedClose").gameObject).onClick = OnButtonClick;
		m_Selector = canvas.Find("Selector").gameObject;
		m_Selector.SetActive(value: false);
		m_Menu2 = canvas.Find("Menu").GetComponent<Menu2Controller>();
		m_Menu2.gameObject.SetActive(value: false);
		m_Menu3 = canvas.Find("WalkMenu").GetComponent<Menu3Controller>();
		m_Menu3.gameObject.SetActive(value: false);
		m_InputField = canvas.Find("InputField").gameObject;
		m_InputField.SetActive(value: false);
		gang_e04Table.Row loadMapE = SharedData.Instance().loadMapE04;
		string text = "";
		text = ((loadMapE == null) ? SceneManager.GetActiveScene().name : loadMapE.name_Trans);
		m_SaveData = m_Menu3.transform.parent.Find("AutoSave");
		m_money = m_Menu3.transform.parent.Find("Money");
		m_location = m_Menu3.transform.parent.Find("Location_New");
		m_location.Find("Text").GetComponent<Text>().text = text;
		m_Menu3.transform.Find("Location").GetComponent<Text>().text = text;
		StartCoroutine(LocationAndMoneyMoveAnimation(m_location));
		string[] array = SceneManager.GetActiveScene().name.Split('_');
		m_MapType = array[0];
		if (loadMapE.savedata.Equals("1"))
		{
			m_Menu3.transform.Find("WalkSub/WalkSave").gameObject.SetActive(value: true);
			m_Menu3.transform.Find("MobileTerminalUI/MTSave").gameObject.SetActive(value: true);
		}
		else
		{
			m_Menu3.transform.Find("WalkSub/WalkSave").gameObject.SetActive(value: false);
			m_Menu3.transform.Find("MobileTerminalUI/MTSave").gameObject.SetActive(value: false);
		}
		m_Menu3.transform.Find("WalkSub/WalkTeam").gameObject.SetActive(value: false);
		m_Menu3.transform.Find("WalkSub/WalkLeave").gameObject.SetActive(!loadMapE.leave.Equals("0"));
		m_Menu3.MobileTerminalWalkSub.transform.Find("WalkLeave").gameObject.SetActive(!loadMapE.leave.Equals("0"));
		m_leave_pos = loadMapE.leave;
		FixIssues();
		InitPlayer(SharedData.Instance().SpawnPoint);
		InitGlobalEvents();
		InitEvents();
		InitPortal();
		InitNpcs();
		InitEffects();
		InitTerrain();
		InitInteractiveGrass();
		if (m_MapType.Equals("Base"))
		{
			Debug.Log("In Base from [" + SharedData.Instance().SceneBefore + "] at " + SharedData.Instance().MapUnitsBefore[player.name].ToString());
		}
		SharedData.Instance().BackFromOtherScene = false;
		m_Curcor = UnityEngine.Object.Instantiate(CommonResourcesData.m_CurcorPrefab, map.transform);
		m_Curcor.GetComponentInChildren<SpriteRenderer>().sortingOrder = m_SortingOrder;
		ExpelTeam();
		SubdueEnemy();
		SharedData.Instance().m_FinalSubdueList.Clear();
		SharedData.Instance().m_SubdueList.Clear();
		UpdateEvents();
		TitleLevelUp();
		PlayBGM();
		if (SharedData.Instance().m_WalkSteps != 0)
		{
			SharedData.Instance().m_WalkSteps = SharedData.Instance().m_WalkSteps / 2;
		}
		else
		{
			SharedData.Instance().m_WalkSteps = 0;
		}
		SharedData.Instance().isRandomFight = false;
		InitRandmFightIdList();
		SharedData.Instance().m_MapController = this;
		SharedData.Instance().m_isDaTianWangSiChallenge = false;
		SharedData.Instance().m_unKnownItemID = "";
		BattleDropItem();
		InitOK = true;
	}

	private void BattleDropItem()
	{
		int num = 0;
		foreach (KeyValuePair<string, int> battleDropItemId in SharedData.Instance().m_BattleDropItemIdList)
		{
			_ = battleDropItemId.Key == "999";
			SharedData.Instance().PackageAdd(battleDropItemId.Key, battleDropItemId.Value);
			string explore = "GET|ITEM|" + battleDropItemId.Key + "|" + battleDropItemId.Value;
			AddExploreList(explore);
		}
		SharedData.Instance().m_BattleDropItemIdList.Clear();
	}

	private void InitRandmFightIdList()
	{
		int level = SharedData.Instance().player.charadata.m_Level;
		if (level <= 5)
		{
			currentRandomPlayerLevel = 1;
		}
		else if (level <= 10)
		{
			currentRandomPlayerLevel = 2;
		}
		else if (level <= 20)
		{
			currentRandomPlayerLevel = 3;
		}
		else if (level <= 40)
		{
			currentRandomPlayerLevel = 4;
		}
		else if (level <= 60)
		{
			currentRandomPlayerLevel = 5;
		}
		else if (level <= 80)
		{
			currentRandomPlayerLevel = 6;
		}
		else if (level <= 100)
		{
			currentRandomPlayerLevel = 7;
		}
		RandomFightGridMapList = UnityEngine.Object.FindObjectsOfType<Tilemap>().ToList().FindAll((Tilemap s) => s.name.StartsWith("RandomFightGrid"));
		foreach (Tilemap randomFightGridMap in RandomFightGridMapList)
		{
			try
			{
				RandomFightInfo randomFightInfo = new RandomFightInfo(randomFightGridMap);
				bool flag = false;
				if (randomFightInfo.isUnique)
				{
					foreach (KeyValuePair<string, Dictionary<int, List<gang_b04Table.Row>>> item in randomFightInfo.GIDGroupDict)
					{
						foreach (KeyValuePair<int, List<gang_b04Table.Row>> item2 in item.Value)
						{
							if (item2.Key > currentRandomPlayerLevel && item2.Value.Count > 0)
							{
								flag = true;
								break;
							}
						}
						if (flag)
						{
							break;
						}
					}
				}
				if (!flag)
				{
					randomFightInfos.Add(randomFightInfo);
				}
			}
			catch (ArgumentException ex)
			{
				Debug.LogWarning("Create RandomFightInfo failed: " + ex.Message);
			}
			randomFightGridMap.gameObject.SetActive(value: false);
		}
	}

	private void PlayUISpine(SkeletonGraphic _ani)
	{
		if (!_ani.gameObject.activeInHierarchy)
		{
			_ani.gameObject.SetActive(value: true);
		}
	}

	private void News_Ani_Complete(TrackEntry trackEntry)
	{
		m_News_Ani.gameObject.SetActive(value: false);
	}

	private void Tecs_Ani_Complete(TrackEntry trackEntry)
	{
		m_Tecs_Ani.gameObject.SetActive(value: false);
	}

	private void FixIssues()
	{
		if (SharedData.Instance().m_Patch_Fixed)
		{
			return;
		}
		if (SharedData.Instance().PlayerPackage.ContainsKey("999") && SharedData.Instance().PlayerPackage["999"] > 0)
		{
			Debug.LogFormat("Money = {0}, BlackMoney = {1}", SharedData.Instance().m_Money, SharedData.Instance().PlayerPackage["999"]);
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Tip") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_GetMoneyFormPackage_1") + " " + SharedData.Instance().PlayerPackage["999"] + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetMoneyFormPackage_2") + "</color>");
			SharedData.Instance().m_Money += SharedData.Instance().PlayerPackage["999"];
			SharedData.Instance().PlayerPackage["999"] = 0;
			Dictionary<string, int> dictionary = new Dictionary<string, int>();
			dictionary.Add("999", 0);
			foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
			{
				if (!item.Key.Equals("999"))
				{
					dictionary.Add(item.Key, item.Value);
				}
			}
			SharedData.Instance().PlayerPackage.Clear();
			SharedData.Instance().PlayerPackage = dictionary;
		}
		if (SharedData.Instance().m_LoanedItems.ContainsKey("999") && SharedData.Instance().m_LoanedItems["999"] > 0)
		{
			Debug.LogFormat("Money = {0}, LoanedMoney = {1}", SharedData.Instance().m_Money, SharedData.Instance().m_LoanedItems["999"]);
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Tip") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_GetFormLoan_1") + " " + SharedData.Instance().m_LoanedItems["999"] + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetFormLoan_2") + "</color>");
			SharedData.Instance().m_Money += SharedData.Instance().m_LoanedItems["999"];
			SharedData.Instance().m_LoanedItems["999"] = 0;
			Dictionary<string, int> dictionary2 = new Dictionary<string, int>();
			dictionary2.Add("999", 0);
			foreach (KeyValuePair<string, int> item2 in SharedData.Instance().PlayerPackage)
			{
				if (!item2.Key.Equals("999"))
				{
					dictionary2.Add(item2.Key, item2.Value);
				}
			}
			SharedData.Instance().PlayerPackage.Clear();
			SharedData.Instance().PlayerPackage = dictionary2;
		}
		int count = SharedData.Instance().FollowList.Count;
		if (count > SharedData.Instance().FollowMaxCount)
		{
			Debug.LogFormat("Fix FollowList.Length issue, followcount = {0}, FollowMaxCount = {1}", count, SharedData.Instance().FollowMaxCount);
			for (int num = count - 1; num >= SharedData.Instance().FollowMaxCount; num--)
			{
				SharedData.Instance().FollowList.RemoveAt(num);
			}
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Tip") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_Reorganized") + "</color>");
		}
		string value = CheckEventRunningFlag("STAGE_17.D_42");
		if ("STAGE_17.D_42_SEL_1_WIN".Equals(value) || "STAGE_17.D_42_SEL_1_LOSE".Equals(value))
		{
			OpenEvent("STAGE_17.D_42");
			OpenFlag("STAGE_17.D_42");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_4") + "</color>");
		}
		if ((CheckFlag("STAGE_41_15_FLAG", 2) || CheckFlag("STAGE_48_28_3", 2)) && !CheckFlag("STAGE_36_1C", 2))
		{
			CloseEvent("STAGE_36_1C");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_6") + "</color>");
		}
		if (CheckFlag("STAGE_48_28_3", 2) && (!CheckFlag("STAGE_36_3A", 2) || !CheckFlag("STAGE_36_3B", 2) || !CheckFlag("STAGE_36_4A", 2) || !CheckFlag("STAGE_36_4B", 2)))
		{
			CloseEvent("STAGE_36_3A");
			CloseEvent("STAGE_36_3B");
			CloseEvent("STAGE_36_4A");
			CloseEvent("STAGE_36_4B");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_2") + "</color>");
		}
		if (CheckFlag("STAGE_41_15_FLAG", 2) && (!CheckFlag("STAGE_36_3A", 2) || !CheckFlag("STAGE_36_3B", 2) || !CheckFlag("STAGE_36_4A", 2) || !CheckFlag("STAGE_36_4B", 2)))
		{
			CloseEvent("STAGE_36_3A");
			CloseEvent("STAGE_36_3B");
			CloseEvent("STAGE_36_4A");
			CloseEvent("STAGE_36_4B");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_JianghuGanKai") + "</color>");
		}
		if (CheckFlag("MAP_03_6", 2) && CheckFlag("MAP_03_6S", 1) && CheckFlag("MAP_03_6F", 0) && CheckFlag("STAGE_36_7", 1) && CheckFlag("STAGE_36_8", 1) && CheckFlag("STAGE_36_9", 1))
		{
			CloseEvent("STAGE_36_7");
			CloseEvent("STAGE_36_8");
			CloseEvent("STAGE_36_9");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_1") + "</color>");
		}
		if (SharedData.Instance().m_Mesg_News.Count <= 0 && SharedData.Instance().m_Mesg_Tecs.Count <= 0)
		{
			foreach (KeyValuePair<string, int> flag in SharedData.Instance().FlagList)
			{
				if (flag.Value != 2)
				{
					continue;
				}
				gang_e01Table.Row row = CommonResourcesData.e01.Find_flag(flag.Key);
				if (row == null)
				{
					continue;
				}
				string[] array = row.action.Split('|');
				if (!"CHAT".Equals(array[0]))
				{
					continue;
				}
				foreach (gang_e02Table.Row item3 in CommonResourcesData.e02.FindAll_chatid(array[1]))
				{
					gang_f01Table.Row row2 = CommonResourcesData.f01.Find_id(item3.rumourid);
					if (row2 != null)
					{
						if ("1".Equals(row2.catalog))
						{
							SharedData.Instance().AddMesgNews(row2.openflag);
						}
						else if ("2".Equals(row2.catalog))
						{
							SharedData.Instance().AddMesgTecs(row2.openflag);
						}
					}
				}
			}
			if (SharedData.Instance().m_Mesg_News.Count > 0)
			{
				ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor_1") + " " + SharedData.Instance().m_Mesg_News.Count + " " + CommonFunc.I18nGetLocalizedValue("I18N_News") + "</color>");
			}
			if (SharedData.Instance().m_Mesg_Tecs.Count > 0)
			{
				ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor_2") + " " + SharedData.Instance().m_Mesg_Tecs.Count + " " + CommonFunc.I18nGetLocalizedValue("I18N_Tecs") + "</color>");
			}
		}
		if (CheckFlag("STAGE_41_15_FLAG", 2) && CheckFlag("STAGE_41_33", 0))
		{
			OpenFlag("STAGE_41_33");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_3") + "</color>");
		}
		if (CheckFlag("STAGE_41_15_FLAG", 2) && CheckFlag("STAGE_41_35", 0))
		{
			CloseEvent("STAGE_41.1_1");
			CloseEvent("MAP_03_11");
			OpenFlag("STAGE_41.1_1L");
			OpenFlag("MAP_03_11L");
			OpenFlag("STAGE_41_35");
			ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Rumor") + "】：" + CommonFunc.I18nGetLocalizedValue("I18N_LangChat_5") + "</color>");
		}
		if ((CheckFlag("STAGE_36_24", 1) || CheckFlag("STAGE_36_24", 2)) && (CheckFlag("STAGE_36_0_VO", 1) || CheckFlag("STAGE_36_1C", 1) || CheckFlag("STAGE_36_3A", 1) || CheckFlag("STAGE_36_3B", 1) || CheckFlag("STAGE_36_4A", 1) || CheckFlag("STAGE_36_4B", 1) || CheckFlag("STAGE_36_5A", 1) || CheckFlag("STAGE_36_5B", 1) || CheckFlag("STAGE_36_7", 1) || CheckFlag("STAGE_36_8", 1) || CheckFlag("STAGE_36_9", 1) || CheckFlag("STAGE_36_10", 1) || CheckFlag("STAGE_36_11", 1) || CheckFlag("STAGE_36_12", 1) || CheckFlag("STAGE_36_13", 1) || CheckFlag("STAGE_36_14", 1) || CheckFlag("STAGE_36_16", 1) || CheckFlag("STAGE_36_17", 1) || CheckFlag("STAGE_36_18", 1) || CheckFlag("STAGE_48_1", 1) || CheckFlag("STAGE_48_3", 1) || CheckFlag("STAGE_48_4", 1) || CheckFlag("STAGE_48_4C", 1) || CheckFlag("STAGE_48_5", 1) || CheckFlag("STAGE_48_6", 1) || CheckFlag("STAGE_48_7", 1) || CheckFlag("STAGE_48_8", 1) || CheckFlag("STAGE_48_9", 1) || CheckFlag("STAGE_48_10", 1) || CheckFlag("STAGE_48_11", 1) || CheckFlag("STAGE_48_12", 1) || CheckFlag("STAGE_48_13", 1) || CheckFlag("STAGE_48_14", 1) || CheckFlag("STAGE_48_15", 1) || CheckFlag("STAGE_48_16", 1) || CheckFlag("STAGE_48_17", 1) || CheckFlag("STAGE_48_18", 1) || CheckFlag("STAGE_48_19", 1) || CheckFlag("STAGE_48_20", 1) || CheckFlag("STAGE_48_21", 1) || CheckFlag("STAGE_48_22", 1) || CheckFlag("STAGE_48_23", 1) || CheckFlag("STAGE_48_24", 1) || CheckFlag("STAGE_48_25", 1) || CheckFlag("STAGE_48_26", 1) || CheckFlag("STAGE_48_27", 1) || CheckFlag("STAGE_48_28", 1) || CheckFlag("STAGE_48_29", 1) || CheckFlag("STAGE_48_30", 1) || CheckFlag("STAGE_48_31", 1) || CheckFlag("STAGE_48_32", 1) || CheckFlag("STAGE_48_33", 1) || CheckFlag("STAGE_48_34", 1) || CheckFlag("STAGE_48_35", 1) || CheckFlag("STAGE_48_36", 1) || CheckFlag("STAGE_48_37", 1) || CheckFlag("STAGE_49_2", 1) || CheckFlag("STAGE_49_3", 1) || CheckFlag("STAGE_49_4", 1) || CheckFlag("STAGE_49_5", 1) || CheckFlag("STAGE_49_6", 1) || CheckFlag("STAGE_49_7", 1) || CheckFlag("STAGE_49_8", 1) || CheckFlag("MAP_03_6", 1) || CheckFlag("MAP_03_6S", 1)))
		{
			CloseEvent("STAGE_36_0_VO&STAGE_36_1C&STAGE_36_3A&STAGE_36_3B&STAGE_36_4A&STAGE_36_4B&STAGE_36_5A&STAGE_36_5B&STAGE_36_7&STAGE_36_8&STAGE_36_9&STAGE_36_10&STAGE_36_11&STAGE_36_12&STAGE_36_13&STAGE_36_14&STAGE_36_16&STAGE_36_17&STAGE_36_18&STAGE_48_1&STAGE_48_3&STAGE_48_4&STAGE_48_4C&STAGE_48_5&STAGE_48_6&STAGE_48_7&STAGE_48_8&STAGE_48_9&STAGE_48_10&STAGE_48_11&STAGE_48_12&STAGE_48_13&STAGE_48_14&STAGE_48_15&STAGE_48_16&STAGE_48_17&STAGE_48_18&STAGE_48_19&STAGE_48_20&STAGE_48_21&STAGE_48_22&STAGE_48_23&STAGE_48_24&STAGE_48_25&STAGE_48_26&STAGE_48_27&STAGE_48_28&STAGE_48_29&STAGE_48_30&STAGE_48_31&STAGE_48_32&STAGE_48_33&STAGE_48_34&STAGE_48_35&STAGE_48_36&STAGE_48_37&STAGE_49_2&STAGE_49_3&STAGE_49_4&STAGE_49_5&STAGE_49_6&STAGE_49_7&STAGE_49_8&MAP_03_6&MAP_03_6S");
			OpenEvent("MAP_03_6F", _active: true);
			Debug.LogWarning("BETA-Fix Clear HengShan 中原篇大内高手围攻衡山前清场");
		}
		if (CheckFlag("GLOBAL_FLAGS_FACTION_DONGSHU_JOIN", 1) && CheckFlag("STAGE_500_00", 0))
		{
			OpenFlag("STAGE_500_00");
			Debug.LogWarning("Fix YueLuDongTingGe issues 东书门派 触发岳麓洞庭阁-2上官楠剧情");
		}
		if (CheckFlag("STAGE_03_43", 2) && !CheckFlag("STAGE_08NY_2B", 1))
		{
			OpenEvent("STAGE_08NY_2B", _active: true);
			Debug.LogWarning("Fix JinJunYingDi-NanYang issues 中原篇江湖线南阳剧情后襄阳地区金兵营地南阳出口修正");
		}
		if (CheckFlag("STAGE_40C_4", 1))
		{
			CloseEvent("STAGE_40C_4");
			Debug.LogWarning("BETA-Fix YueLuDongTingGe-1C issues 岳麓洞庭阁1C中央挡门弟子删除");
		}
		if (CheckFlag("STAGE_510_2", 1))
		{
			CloseFlag("SCENE_FLAG_STAGE_510_2");
			Debug.LogWarning("BETA-Fix TingQinGe issues 听琴阁 STAGE_510_2 剧情触发后相应Layer打开");
		}
		if (CheckFlag("STAGE_510_7", 1))
		{
			CloseFlag("SCENE_FLAG_STAGE_510_7");
			Debug.LogWarning("BETA-Fix TingQinGe issues 听琴阁 STAGE_510_7 剧情触发后相应Layer打开");
		}
		if (CheckFlag("STAGE_510_11", 1))
		{
			CloseFlag("SCENE_FLAG_STAGE_510_11");
			Debug.LogWarning("BETA-Fix TingQinGe issues 听琴阁 STAGE_510_11 剧情触发后相应Layer打开");
		}
		if (CheckFlag("STAGE_514_30", 1))
		{
			CloseFlag("SCENE_FLAG_STAGE_514_30");
			Debug.LogWarning("BETA-Fix TingQinGe issues 听琴阁 STAGE_514_30 剧情触发后相应Layer打开");
		}
		if (CheckFlag("STAGE_125_2", 1))
		{
			CloseFlag("SCENE_FLAG_STAGE_125_2");
			Debug.LogWarning("BETA-Fix FengLingDuKou issues 风陵渡口西域黑老大事件补丁");
		}
		if (CheckFlag("STAGE_128_2", 2) && CheckFlag("STAGE_128_7", 0))
		{
			OpenFlag("STAGE_128_7");
			Debug.LogWarning("BETA-Fix GaoChangShiJi issues 高昌市集共祭商人补丁");
		}
		if (CheckFlag("STAGE_16_13", 2) && !CheckFlag("STAGE_16_13FA", 0) && !CheckFlag("STAGE_16_13FF", 2))
		{
			CloseEvent("STAGE_16_13FF");
			OpenEvent("STAGE_16_13FA", _active: true);
			Debug.LogWarning("BETA-Fix stage-2212-linan-east issues 临安城通缉江湖线补丁");
		}
		if (CheckFlag("STAGE_16_13", 2) && !CheckFlag("STAGE_16_13FB", 0) && !CheckFlag("STAGE_16_13FF", 2))
		{
			CloseEvent("STAGE_16_13FF");
			OpenEvent("STAGE_16_13FB", _active: true);
			Debug.LogWarning("BETA-Fix stage-2212-linan-east issues 临安城通缉羽衣线补丁");
		}
		if (CheckFlag("STAGE_37_7P", 2) && !CheckFlag("STAGE_37_7", 2))
		{
			CloseEvent("STAGE_37_7");
			OpenEvent("STAGE_37_7F", _active: true);
			Debug.LogWarning("BETA-Fix stage-303-hengyangcheng 衡阳城通缉补丁");
		}
		if (CheckFlag("STAGE_110_13", 0) && (CheckFlag("GLOBAL_FLAGS_FACTION_BeiGu_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_DONGSHU_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_HengShan_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_JinWuWangFu_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_QuanZhen_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_SHAOLIN_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_XiaoJiangDong_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_FACTION_XiBo_JOIN_WuLinDaHui", 1) || CheckFlag("GLOBAL_FLAGS_EVIL_XIBO", 2)))
		{
			CloseEvent("MAP_05_SHLS&STAGE_110_1&STAGE_110_3A&STAGE_110_4&STAGE_110_4P&STAGE_110_10&STAGE_110_11&STAGE_110.1_3&STAGE_110.1_5&STAGE_110.1_6&STAGE_110.1_7&STAGE_110.1_8&STAGE_110.1_9&STAGE_110.1_10&STAGE_110.1_11&STAGE_110.1_12&STAGE_110.1_13&STAGE_110.1_14&STAGE_110.1_15&STAGE_110.4_1A&STAGE_110.4_1&STAGE_110_12&STAGE_504_2&STAGE_504_5&STAGE_505_0&STAGE_505_5&STAGE_505_6&STAGE_505_7&STAGE_505_8&STAGE_505_9&STAGE_505_10&STAGE_506_0&STAGE_506_2&STAGE_506_4&STAGE_506_5&STAGE_506_6&STAGE_507_0&STAGE_507_2P&STAGE_507_2&STAGE_507_2A&STAGE_507_4&STAGE_507_4A");
			OpenEvent("STAGE_110_3", _active: true);
			OpenFlag("MAP_05_SHLS_XYUEN|STAGE_110_13|STAGE_41_33|STAGE_110_1A|STAGE_110_53|STAGE_110_54|STAGE_110_55|STAGE_110_56|STAGE_110_57|STAGE_110_58");
			Debug.LogWarning("BETA-Fix 各个门派天下第一武林大会触发及少林寺清场");
		}
		if (CheckFlag("GLOBAL_FLAGS_YY_ROUTE_3", 2) && !CheckFlag("STAGE_127_5", 2))
		{
			CloseEvent("STAGE_127_3&STAGE_127_4&STAGE_127_5");
			Debug.LogWarning("BETA-Fix 羽衣线胡姬酒肆后打开山口子关堵门");
		}
		if (CheckFlag("STAGE_107_7", 2) && !CheckFlag("STAGE_127_5", 2))
		{
			CloseEvent("STAGE_127_3&STAGE_127_4&STAGE_127_5");
			Debug.LogWarning("BETA-Fix 天煞孤星线终南山完颜雍剧情后打开山口子关堵门");
		}
		if (CheckFlag("STAGE_112_72", 0) && CheckFlag("GLOBAL_FLAGS_CHA_2073", 2) && CheckFlag("STAGE_107_7", 2))
		{
			OpenFlag("STAGE_112_72");
			Debug.LogWarning("BETA-Fix 石彦章二次入队");
		}
		if (CheckFlag("STAGE_29_S1_18_1", 2))
		{
			GameDataManager.Instance().AddUnlockAtlasList("201", "b01");
		}
		if ((CheckFlag("STAGE_118_11", 1) && CheckFlag("GLOBAL_FLAGS_FACTION_BeiGu_JOIN", 1)) || CheckFlag("STAGE_118_11", 2))
		{
			GameDataManager.Instance().AddUnlockAtlasList("203", "b01");
		}
		if (CheckFlag("STAGE_514_9", 2))
		{
			GameDataManager.Instance().AddUnlockAtlasList("1117", "b01");
		}
		if (CheckFlag("STAGE_38_13A_FLAG", 2) && (!CheckFlag("STAGE_29_S1_7", 2) || !CheckFlag("STAGE_29_S1_17", 2)))
		{
			CloseEvent("STAGE_29_S1_7&STAGE_29_S1_17");
			Debug.LogWarning("BETA-Fix 中原篇开启后在盲眼铁匠处清理白鹿洞书院小屋林瑛");
		}
		if (CheckFlag("STAGE_38_13A_FLAG", 2) && (!CheckFlag("STAGE_76_9", 2) || !CheckFlag("STAGE_76_9G", 2) || !CheckFlag("STAGE_76_9E", 2) || !CheckFlag("STAGE_76_10", 2) || !CheckFlag("STAGE_76_11", 2) || !CheckFlag("STAGE_76_11F", 2) || !CheckFlag("STAGE_76_11F2", 2) || !CheckFlag("STAGE_76_12", 2)))
		{
			CloseEvent("STAGE_76_9&STAGE_76_9G&STAGE_76_9E&STAGE_76_10&STAGE_76_11&STAGE_76_11F&STAGE_76_11F2&STAGE_76_12");
			Debug.LogWarning("BETA-Fix 中原篇开启后在盲眼铁匠处清理成都城客栈登云子等人");
		}
		if (CheckFlag("STAGE_111_7A", 2) && !CheckFlag("STAGE_111_1", 1))
		{
			OpenEvent("STAGE_111_1", _active: true);
			Debug.LogWarning("BETA-Fix 华山四侠剧情后，再回华山卡住问题修正");
		}
		if (CheckFlag("STAGE_41_90", 2) && !CheckFlag("STAGE_36_1", 1))
		{
			CloseEvent("STAGE_36_1C");
			OpenEvent("STAGE_36_1", _active: true);
			Debug.LogWarning("BETA-Fix 中原篇开始后修正衡山通往大地图的过图点");
		}
		if ((CheckFlag("STAGE_109.1_2", 2) || CheckFlag("STAGE_113_4", 2)) && !CheckFlag("STAGE_48_1S", 1))
		{
			OpenEvent("STAGE_48_1S", _active: true);
			Debug.LogWarning("BETA-Fix 衡山派清场后，衡山（stage-306-hengshanpai-2）下方过图点修正");
		}
		if ((CheckFlag("STAGE_111_6Y", 2) || CheckFlag("STAGE_111_7T", 2) || CheckFlag("STAGE_111_8L", 2)) && !CheckFlag("STAGE_111_1", 1))
		{
			CloseEvent("STAGE_111_1S");
			OpenEvent("STAGE_111_1", _active: true);
			Debug.LogWarning("BETA-Fix 华山羽衣四侠个人告白后离开华山时重置华山去往大地图的过图点");
		}
		if (CheckFlag("STAGE_517_9", 2))
		{
			if (CheckFlag("STAGE_113_3", 2) && !CheckFlag("STAGE_517_11", 1))
			{
				OpenFlag("STAGE_517_11");
				Debug.LogWarning("BETA-Fix 完颜齐完颜雍兄弟谈话之后复原大殿上完颜雍");
			}
			if (CheckFlag("STAGE_517_0", 2) && (!CheckFlag("STAGE_517_1", 1) || !CheckFlag("STAGE_517_2", 1)))
			{
				OpenFlag("STAGE_517_1");
				OpenFlag("STAGE_517_2");
				Debug.LogWarning("BETA-Fix 完颜齐完颜雍兄弟谈话之后复原大殿上胡漠北祝虎谋");
			}
		}
		if (CheckFlag("STAGE_98_49", 2) && CheckFlag("GLOBAL_FLAGS_YY", 2) && !CheckFlag("STAGE_96_A_8", 1))
		{
			CloseEvent("STAGE_96_A_8NG1&STAGE_96_A_8NG2&STAGE_97_2&STAGE_97_3&STAGE_97_4&STAGE_97_7&STAGE_97_8&STAGE_97_3F&STAGE_97_4F&STAGE_97_5F&STAGE_97_6F");
			OpenEvent("STAGE_96_A_8&STAGE_97_5&STAGE_97_6", _active: true);
			Debug.LogWarning("BETA-Fix 羽衣线南阳关键选择后改造西侧营地为可访问状态");
		}
		if (CheckFlag("STAGE_117_4", 2) && CheckFlag("STAGE_66_19", 0))
		{
			OpenFlag("STAGE_66_19");
			Debug.LogWarning("BETA-Fix 寒玉洞王害风李大路剧情后开启姑子庙孙麻瑛");
		}
		if (CheckFlag("GLOBAL_FLAGS_4OF4", 2) && CheckFlag("STAGE_66_19", 2) && CheckFlag("TEAMMATE_STANDBY_1167", 0))
		{
			OpenFlag("TEAMMATE_STANDBY_1167");
			Debug.LogWarning("BETA-Fix 羽衣四侠线也可在姑子庙后去曲家村收李大路");
		}
		if (CheckFlag("STAGE_129.5_2", 2) && !CheckFlag("STAGE_129.4_12", 2))
		{
			CloseEvent("STAGE_129.4_12");
			Debug.LogWarning("BETA-Fix 陈僧之&陈南絮线，打完波斯三使后更新乌屠昆弥状态");
		}
		if (CheckFlag("GLOBAL_FLAGS_JH", 2) && CheckFlag("STAGE_41.1_34", 2) && !CheckFlag("STAGE_51_17W", 2))
		{
			CloseEvent("STAGE_51_17W");
			Debug.LogWarning("BETA-Fix 江湖线 衡阳抓密探前铲掉衡阳酒馆木挽风");
		}
		if (CheckFlag("GLOBAL_FLAGS_YY", 2) && CheckFlag("SCENE_03_4", 2) && !CheckFlag("STAGE_51_17W", 2))
		{
			CloseEvent("STAGE_51_17W");
			Debug.LogWarning("BETA-Fix 羽衣线 衡山篝火告别所有队友后铲掉衡阳酒馆木挽风");
		}
		if (CheckFlag("GLOBAL_FLAGS_4OF4", 2) && CheckFlag("STAGE_112_75", 2) && CheckFlag("TEAMMATE_STANDBY_1166", 0))
		{
			OpenFlag("TEAMMATE_STANDBY_1166");
			Debug.LogWarning("BETA-Fix 羽衣线 包狗儿二次入队补丁");
		}
		if (CheckFlag("GLOBAL_FLAGS_YY", 2) && CheckFlag("STAGE_108.1_3", 2) && CheckFlag("STAGE_87_25", 0))
		{
			OpenFlag("STAGE_87_25");
			Debug.LogWarning("BETA-Fix 羽衣线 小雪球二次入队补丁");
		}
		if (SharedData.Instance().FullTeam.Contains("307") && !CheckFlag("STAGE_123.1_14_ITEM_FLAG", 2))
		{
			SharedData.Instance().PackageAdd("T1051", 1);
			CloseFlag("STAGE_123.1_14_ITEM_FLAG");
			Debug.LogWarning("BETA-Fix 四大才子入队道具补丁");
		}
		if (SharedData.Instance().FullTeam.Contains("H1028") && !CheckFlag("STAGE_129_3", 2))
		{
			CloseEvent("STAGE_129_3&STAGE_129_4");
			Debug.LogWarning("BETA-Fix 陈氏兄妹加入队伍后删除昆弥王墓入口二人");
		}
		SharedData.Instance().m_Patch_Fixed = true;
		Debug.Log("MapController::FixIssues(): Patch fixed after data LOAD.");
	}

	public void ChatLog(string _log)
	{
		while (SharedData.Instance().m_ChatLog.Count >= 1000)
		{
			SharedData.Instance().m_ChatLog.Dequeue();
		}
		SharedData.Instance().m_ChatLog.Enqueue(_log);
	}

	private void PlaySoundEffect(string _url, string _delay, Event _event)
	{
		float delay = float.Parse(_delay, CultureInfo.InvariantCulture);
		if (m_EffectSound != null)
		{
			if (_event != null)
			{
				StartCoroutine(PlaySoundEffectDelay(_url, delay, _event));
				return;
			}
			m_EffectSound.clip = Resources.Load("Music/SE/" + _url, typeof(AudioClip)) as AudioClip;
			m_EffectSound.Play();
		}
	}

	protected IEnumerator PlaySoundEffectDelay(string _url, float _delay, Event _event)
	{
		_event.activelock = true;
		m_EffectSound.clip = Resources.Load("Music/SE/" + _url, typeof(AudioClip)) as AudioClip;
		m_EffectSound.Play();
		yield return new WaitForSeconds(_delay);
		_event.activelock = false;
		EventComplete(_event);
	}

	protected IEnumerator TeleportDelay(float _delay, string _nextscene)
	{
		yield return new WaitForSeconds(_delay);
		LoadScene(_nextscene);
	}

	private void PlayBGM()
	{
		if (m_AudioSource != null && FieldBGM != null && m_AudioSource.clip != FieldBGM)
		{
			m_AudioSource.clip = FieldBGM;
			m_AudioSource.Play();
		}
		else if (FieldBGM == null)
		{
			if (DefaultFieldBGM != null)
			{
				m_AudioSource.clip = DefaultFieldBGM;
				m_AudioSource.Play();
			}
			else
			{
				m_AudioSource.Stop();
			}
		}
	}

	private void InitNpcs()
	{
		SuperObject[] byType = getByType("Npc");
		foreach (SuperObject superObject in byType)
		{
			string[] array = superObject.name.Split('|');
			OhNpcController ohNpcController = UnityEngine.Object.Instantiate(CommonResourcesData.LoadCharacter(array[1]), map.transform.parent).AddComponent<OhNpcController>();
			ohNpcController.superObject = superObject;
			ohNpcController.name = array[0] + "|" + array[1] + "|" + array[2];
			switch (array[3])
			{
			case "0":
				ohNpcController.Face(Direction.Down, isInit: true);
				break;
			case "1":
				ohNpcController.Face(Direction.Right, isInit: true);
				break;
			case "2":
				ohNpcController.Face(Direction.Up, isInit: true);
				break;
			case "3":
				ohNpcController.Face(Direction.Left, isInit: true);
				break;
			default:
				ohNpcController.Face(Direction.Down, isInit: true);
				break;
			}
			ohNpcController.movement = int.Parse(array[4]);
			ohNpcController.MovingSpeedRate = float.Parse(array[5], CultureInfo.InvariantCulture);
			string[] array2 = array[6].Split('-');
			ohNpcController.MinMoveGap = float.Parse(array2[0], CultureInfo.InvariantCulture);
			ohNpcController.MaxMoveGap = float.Parse(array2[1], CultureInfo.InvariantCulture);
		}
	}

	private void InitEffects()
	{
		SuperObject[] byType = getByType("Effect");
		foreach (SuperObject superObject in byType)
		{
			string[] array = superObject.name.Split('|');
			UnityEngine.Object.Instantiate((GameObject)Resources.Load("Prefabs/Effect/Ground/" + array[0]), map.transform.parent).transform.localPosition = superObject.transform.localPosition;
		}
	}

	private void InitEOFEvents(string _event_id)
	{
		if (!SharedData.Instance().EventTable.ContainsKey(_event_id))
		{
			Debug.LogWarning("! NOT found eventid: " + _event_id);
			return;
		}
		Event item = new Event
		{
			name = _event_id,
			eventid = _event_id,
			tileobj = null,
			flow = 0
		};
		eof_events.Add(item);
	}

	private int DealInitEvents(string _event_id, SuperObject _obj = null)
	{
		int num = 2;
		string key = ((_obj == null) ? _event_id : _obj.name);
		if (!SharedData.Instance().EventTable.ContainsKey(_event_id))
		{
			Debug.LogWarning("! NOT found eventid: " + _event_id);
			return num;
		}
		foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[_event_id])
		{
			if (item.online == "0")
			{
				continue;
			}
			if (item.trigger == "AUTO")
			{
				Debug.Log("Revive AUTO-FLAG [" + item.flag + "]");
				SharedData.Instance().FlagList[item.flag] = 0;
			}
			else if (item.trigger == "AUTOCHK")
			{
				Debug.Log("AUTOCHK [" + item.action + "]");
				if (SharedData.Instance().FlagList[item.flag] == 0)
				{
					string[] array = item.action.Split('|');
					if (array[0] == "CHECK" && DoAutoActionCheck(array))
					{
						SharedData.Instance().FlagList[item.flag] = 2;
						string[] array2 = item.nextflag.Split('|');
						foreach (string key2 in array2)
						{
							SharedData.Instance().FlagList[key2] = 1;
						}
					}
				}
			}
			if (SharedData.Instance().FlagList[item.flag] < 2)
			{
				num = 0;
				break;
			}
		}
		if (num == 2)
		{
			return num;
		}
		Event @event = new Event
		{
			name = key,
			eventid = _event_id,
			tileobj = _obj,
			flow = 0
		};
		if (SharedData.Instance().BackFromOtherScene && SharedData.Instance().MapUnitsBefore.ContainsKey(key))
		{
			@event.originevdata = SharedData.Instance().EventsRecord[key].originevdata;
			@event.evdata = SharedData.Instance().EventsRecord[key].evdata;
			@event.flow = SharedData.Instance().EventsRecord[key].flow;
			@event.elseroute = SharedData.Instance().EventsRecord[key].elseroute;
			if (SharedData.Instance().EventsRecord[key].display != "")
			{
				string[] array3 = SharedData.Instance().EventsRecord[key].display.Split('|');
				GameObject original = (GameObject)Resources.Load(array3[0]);
				if (array3[0].StartsWith("Prefabs/Character/"))
				{
					gang_b01SkinTable.Row row = CommonResourcesData.b01Skin.Find_ID(array3[0].Split('/')[2]);
					if (row != null)
					{
						@event.obj = SkinCharacter.InitSkinCharacter(row);
					}
					else
					{
						@event.obj = UnityEngine.Object.Instantiate(original, map.transform.parent);
					}
				}
				else
				{
					@event.obj = UnityEngine.Object.Instantiate(original, map.transform.parent);
				}
				EventController eventController = (@event.eventController = @event.obj.AddComponent<EventController>());
				eventController.BackFromOtherScene = SharedData.Instance().BackFromOtherScene;
				eventController.tileName = ((@event.tileobj == null) ? @event.originevdata.flag : @event.tileobj.m_TiledName);
				eventController.name = key;
				eventController.trigger = @event.originevdata.trigger;
				eventController.display = SharedData.Instance().EventsRecord[key].display;
				eventController.Init();
				if (SharedData.Instance().EventsRecord[key].objcamarectrl)
				{
					EventTakeCamera(@event, _init: true);
				}
			}
		}
		if (@event.flow != 2)
		{
			events.Add(key, @event);
		}
		return num;
	}

	private void InitGlobalEvents()
	{
		foreach (KeyValuePair<string, List<gang_e01Table.Row>> item in SharedData.Instance().EventTable)
		{
			if (!(item.Value[0].online != "2") && SharedData.Instance().FlagList[item.Key] == 1)
			{
				DealInitEvents(item.Key);
				MonoBehaviour.print("============= InitGlobalEvents(" + item.Key + "). =============");
			}
		}
	}

	private void InitEvents()
	{
		SuperObject[] byType = getByType("Event");
		foreach (SuperObject superObject in byType)
		{
			string[] array = superObject.name.Split('|');
			DealInitEvents(array[1], superObject);
		}
	}

	private void UpdateEventByFlag(string _flag)
	{
		bool flag = false;
		foreach (KeyValuePair<string, Event> @event in events)
		{
			foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[@event.Value.eventid])
			{
				if (item.flag.Equals(_flag))
				{
					if (@event.Value.flow == 0)
					{
						InitEvent(@event.Value);
					}
					else
					{
						Debug.LogWarning("[AUTO] flag: " + _flag + " will NOT open, because FLOW[" + @event.Value.flow + "] != 0.");
					}
					flag = true;
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
	}

	private void UpdateEvents(int _pid = 0)
	{
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			return;
		}
		int num = 0;
		if (eof_events.Count > 0)
		{
			foreach (Event eof_event in eof_events)
			{
				events.Add(eof_event.eventid, eof_event);
			}
			eof_events.Clear();
		}
		foreach (KeyValuePair<string, Event> @event in events)
		{
			if (@event.Value.flow == 0)
			{
				num += InitEvent(@event.Value);
				if (IsTeleport)
				{
					return;
				}
			}
			else if (@event.Value.flow == 1 && @event.Value.obj != null)
			{
				if (@event.Value.obj.GetComponent<EventController>().m_MultiEvent != null)
				{
					num++;
				}
				else if (@event.Value.activelock)
				{
					num++;
				}
			}
		}
		if (player.m_MultiEvent != null)
		{
			num++;
		}
		if (num > 0)
		{
			m_Menu3.Close();
		}
		else
		{
			if (m_LoadingScene || IsChating() || m_Menu2.IsOpen())
			{
				return;
			}
			PlayerTakeCamera();
			m_Menu3.Open();
			if (m_Canvas_Event != null && m_Canvas_Event.obj != null)
			{
				if (!m_Canvas_Event.evdata.menu.Equals("STILL"))
				{
					m_Canvas_Event.obj.GetComponent<EventController>().ResetDirection("CLICK");
				}
				m_Canvas_Event = null;
			}
		}
	}

	public bool IsChating()
	{
		if (!m_WantedList.activeInHierarchy && !m_Dialog.activeInHierarchy && !m_Explore.activeInHierarchy)
		{
			return m_Selector.activeInHierarchy;
		}
		return true;
	}

	public void AddChatList(string _name, string _chat)
	{
		if (!IsChating())
		{
			Chat(null, _name, _chat, "0", "0");
			return;
		}
		ChatInfo item = new ChatInfo
		{
			ev = null,
			name = _name,
			text = _chat,
			position = 0,
			message = "0"
		};
		m_ChatList.Add(item);
	}

	public void AddChatList(Event _event, string _chat_id)
	{
		Event @event = null;
		string picture = "0";
		int position = 0;
		List<gang_e02Table.Row> list = CommonResourcesData.e02.FindAll_chatid(_chat_id);
		if (list.Count <= 0)
		{
			@event = _event;
			string text = ((_event.obj == null) ? "???" : _event.obj.name);
			string text2 = CommonFunc.I18nGetLocalizedValue("I18N_NoChat");
			string message = "0";
			if (!IsChating())
			{
				Chat(@event, text, text2, message, picture, position);
				return;
			}
			ChatInfo item = new ChatInfo
			{
				ev = @event,
				name = text,
				text = text2,
				position = position,
				message = message,
				picture = picture
			};
			m_ChatList.Add(item);
			return;
		}
		foreach (gang_e02Table.Row item3 in list)
		{
			picture = "0";
			@event = null;
			string text = item3.side_Trans;
			string message;
			if ("player".Equals(text))
			{
				text = player.charadata.Indexs_Name["Name"].stringValue;
				message = item3.rumourid;
				position = ((!"0".Equals(item3.talkicon)) ? 1 : (-1));
				if (!"0".Equals(item3.talkicon) && !"1".Equals(item3.talkicon))
				{
					picture = item3.talkicon;
				}
			}
			else
			{
				@event = GetEventById(item3.eventid);
				position = ((!"0".Equals(item3.talkicon)) ? 1 : (-1));
				if (!"0".Equals(item3.talkicon) && !"1".Equals(item3.talkicon))
				{
					picture = item3.talkicon;
				}
			}
			string text2 = FormatDynamicText(item3.chating_Trans);
			message = item3.rumourid;
			if (!IsChating())
			{
				Chat(@event, text, text2, message, picture, position);
				continue;
			}
			ChatInfo item2 = new ChatInfo
			{
				ev = @event,
				name = text,
				text = text2,
				position = position,
				message = message,
				picture = picture
			};
			m_ChatList.Add(item2);
		}
	}

	public void CloseTachie()
	{
		m_TaChile_L.SetActive(value: false);
		m_TaChile_R.SetActive(value: false);
	}

	private int SetTachie(string _picture)
	{
		if ("0".Equals(_picture) || "1".Equals(_picture))
		{
			return 0;
		}
		int num = 0;
		string[] array = _picture.Split("|");
		GameObject gameObject = null;
		if ("L".Equals(array[0]))
		{
			m_TaChile_L.SetActive(value: true);
			m_TaChile_R.SetActive(value: false);
			gameObject = m_TaChile_L;
			num = 0;
		}
		else
		{
			if (!"R".Equals(array[0]))
			{
				CloseTachie();
				return 0;
			}
			m_TaChile_L.SetActive(value: false);
			m_TaChile_R.SetActive(value: true);
			gameObject = m_TaChile_R;
			num = 1;
		}
		string text = array[1];
		if ("player".Equals(text))
		{
			text = CommonResourcesData.b01.Find_ID(SharedData.Instance().playerid).BattleIcon;
		}
		if (text != "")
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(text);
			if (tachieFull != null)
			{
				gameObject.GetComponent<Image>().sprite = tachieFull;
			}
			else
			{
				CloseTachie();
			}
		}
		else
		{
			CloseTachie();
		}
		return num;
	}

	private void Chat(Event _event, string _name, string _chat, string _message, string _picture, int _position = 0)
	{
		GameObject gameObject = null;
		if (_event == null)
		{
			gameObject = player.gameObject;
			PlayerTakeCamera();
		}
		else if (_event.obj != null)
		{
			gameObject = _event.obj;
			EventTakeCamera(_event);
		}
		Transform transform = null;
		if (_position >= 0 && gameObject != null)
		{
			transform = gameObject.transform.Find("head_icon/talk");
			if (transform != null)
			{
				transform.gameObject.SetActive(value: true);
			}
		}
		m_Menu3.Close();
		m_Dialog.SetActive(value: true);
		CloseTachie();
		int num = SetTachie(_picture);
		if (num == 0)
		{
			m_Chat_Name.transform.parent.gameObject.SetActive(value: false);
			m_Chat_NameL.transform.parent.gameObject.SetActive(value: true);
			m_Chat_NameL.text = _name;
		}
		else
		{
			m_Chat_NameL.transform.parent.gameObject.SetActive(value: false);
			m_Chat_Name.transform.parent.gameObject.SetActive(value: true);
			m_Chat_Name.text = _name;
		}
		m_Chat_Text.text = "";
		m_chat_content = _chat.Replace("\\n", "\n");
		m_chat_process = 1;
		StartCoroutine(TrendsText(m_chat_content, num));
		if (transform != null)
		{
			m_Chat_Icon = transform.gameObject;
		}
		else
		{
			m_Chat_Icon = null;
		}
		if ("0".Equals(_message))
		{
			return;
		}
		gang_f01Table.Row row = CommonResourcesData.f01.Find_openflag(_message);
		if (row == null)
		{
			return;
		}
		if ("1".Equals(row.catalog))
		{
			if (SharedData.Instance().AddMesgNews(_message))
			{
				PlaySoundEffect("01-message-chuanwen", "0", null);
				PlayUISpine(m_News_Ani);
			}
		}
		else if ("2".Equals(row.catalog) && SharedData.Instance().AddMesgTecs(_message))
		{
			PlaySoundEffect("01-wuxue-message", "0", null);
			PlayUISpine(m_Tecs_Ani);
		}
	}

	private IEnumerator TrendsText(string _chat_content, int _position)
	{
		char[] chat_content = _chat_content.ToCharArray();
		int idx = 0;
		string richright = "";
		string tmp_chat_text = "";
		while (idx < chat_content.Length)
		{
			if (m_chat_process == 2)
			{
				m_Chat_Text.text = _chat_content;
				break;
			}
			if (chat_content[idx] == '<')
			{
				int num = idx;
				if (chat_content[num + 1] == '/')
				{
					tmp_chat_text += chat_content[num++];
					tmp_chat_text += chat_content[num++];
					while (chat_content[num] != '>')
					{
						tmp_chat_text += chat_content[num++];
					}
					tmp_chat_text += chat_content[num++];
					richright = "";
					idx = num;
					continue;
				}
				tmp_chat_text += chat_content[num++];
				richright = "</";
				while (chat_content[num] != '=')
				{
					richright += chat_content[num];
					tmp_chat_text += chat_content[num++];
				}
				richright += ">";
				while (chat_content[num] != '>')
				{
					tmp_chat_text += chat_content[num++];
				}
				tmp_chat_text += chat_content[num++];
				idx = num;
			}
			else
			{
				PlaySoundEffect("Talk", "0", null);
				tmp_chat_text += chat_content[idx++];
				m_Chat_Text.text = tmp_chat_text + richright;
				yield return new WaitForSeconds(0.076f);
			}
		}
		if (_position == 0)
		{
			ChatLog("<color=#a37034>【" + m_Chat_NameL.text + "】：</color><color=#918574>" + _chat_content + "</color>");
		}
		else
		{
			ChatLog("<color=#a37034>【" + m_Chat_Name.text + "】：</color><color=#918574>" + _chat_content + "</color>");
		}
		m_chat_process = 0;
	}

	public void AddExploreList(string _explore)
	{
		if (!IsChating())
		{
			Explore(_explore);
		}
		else
		{
			m_ExploreList.Add(_explore);
		}
	}

	private void Explore(string _explore)
	{
		string[] array = _explore.Split('|');
		m_Menu3.Close();
		if (array[0] == "GET")
		{
			if (array[1] == "MINE")
			{
				return;
			}
			m_Explore.SetActive(value: true);
			if (array[1] == "ATTR")
			{
				CharaData charaData = player.charadata;
				if (array.Length > 4)
				{
					charaData = SharedData.Instance().GetCharaData(array[4]);
				}
				string stringValue = charaData.Indexs_Name["Name"].stringValue;
				gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(array[2]);
				if (row != null)
				{
					int num = int.Parse(array[3]);
					if (num > 0)
					{
						m_Explore_Text.text = "【" + stringValue + "】" + CommonFunc.I18nGetLocalizedValue("I18N_Attribute") + "【" + row.NameScene_Trans + "】+" + array[3];
					}
					else if (num < 0)
					{
						m_Explore_Text.text = "【" + stringValue + "】" + CommonFunc.I18nGetLocalizedValue("I18N_Attribute") + "【" + row.NameScene_Trans + "】-" + Mathf.Abs(num);
					}
					else
					{
						m_Explore_Text.text = "【" + stringValue + "】" + CommonFunc.I18nGetLocalizedValue("I18N_Attribute") + "【" + row.NameScene_Trans + "】" + CommonFunc.I18nGetLocalizedValue("I18N_LooksWeird");
					}
				}
				else
				{
					m_Explore_Text.text = "！！江湖上还未有此属性【" + array[2] + "】= " + array[3];
				}
				PlaySoundEffect("Got_Special", "0", null);
				if (array[2] == "LV")
				{
					charaData.m_Level += Mathf.FloorToInt(float.Parse(array[3], CultureInfo.InvariantCulture));
					int num2 = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
					if (charaData.m_Level > num2)
					{
						charaData.m_Level = num2;
					}
					charaData.m_Exp = 0;
				}
			}
			else if (array[1] == "OPINION")
			{
				string text = "NoName";
				CharaData charaData2 = SharedData.Instance().GetCharaData(array[2]);
				if (charaData2 != null)
				{
					text = charaData2.Indexs_Name["Name"].stringValue;
				}
				int num3 = int.Parse(array[3]);
				if (num3 > 0)
				{
					m_Explore_Text.text = text + " 对你的好感度<color=green>上升</color>了 " + Mathf.Abs(num3) + "！";
				}
				else
				{
					m_Explore_Text.text = text + " 对你的好感度<color=red>降低</color>了 " + Mathf.Abs(num3) + "！";
				}
				PlaySoundEffect("Got_Special", "0", null);
			}
			else if (array[1] == "TRAIT")
			{
				string text2 = "NoName";
				if (array[2] == "PLAYER")
				{
					text2 = player.charadata.Indexs_Name["Name"].stringValue;
				}
				else
				{
					CharaData charaData3 = SharedData.Instance().GetCharaData(array[2]);
					if (charaData3 != null)
					{
						text2 = charaData3.Indexs_Name["Name"].stringValue;
					}
				}
				gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(array[3]);
				if (row2 != null)
				{
					if (array[4] == "+")
					{
						m_Explore_Text.text = text2 + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetTrait") + " 【" + row2.name_Trans + "】！";
					}
					else
					{
						m_Explore_Text.text = text2 + " " + CommonFunc.I18nGetLocalizedValue("I18N_LostTrait") + " 【" + row2.name_Trans + "】！";
					}
				}
				else
				{
					m_Explore_Text.text = "！！" + CommonFunc.I18nGetLocalizedValue("I18N_UnknownTrait") + "【" + array[1] + "】";
				}
				PlaySoundEffect("Got_Special", "0", null);
			}
			else if (array[1] == "ITEM")
			{
				gang_b07Table.Row row3 = CommonResourcesData.b07.Find_ID(array[2]);
				if (row3 != null)
				{
					m_Explore_IconFrame.SetActive(value: true);
					m_Explore_IconFrame.transform.Find("Icon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(row3.BookIcon);
					int num4 = int.Parse(array[3]);
					if (num4 > 0)
					{
						m_Explore_Text.text = "<color=green>" + CommonFunc.I18nGetLocalizedValue("I18N_Got") + "</color> " + CommonFunc.I18nGetLocalizedValue("I18N_Item") + "【" + row3.Name_Trans + "】*" + array[3];
					}
					else if (num4 < 0)
					{
						m_Explore_Text.text = "<color=red>" + CommonFunc.I18nGetLocalizedValue("I18N_Lost") + "</color> " + CommonFunc.I18nGetLocalizedValue("I18N_Item") + "【" + row3.Name_Trans + "】*" + Mathf.Abs(num4);
					}
					else
					{
						m_Explore_Text.text = "物品【" + row3.Name_Trans + "】好像发生了很尴尬的事情";
					}
					if ("999".Equals(row3.ID))
					{
						PlaySoundEffect("Got_Money", "0", null);
					}
					else
					{
						PlaySoundEffect("Got_Item", "0", null);
					}
					ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Item_1") + "】：" + m_Explore_Text.text + "</color>");
				}
				else
				{
					m_Explore_Text.text = "！！江湖上还未有此物品【" + array[2] + "】";
				}
			}
			else if (array[1] == "WUGONG")
			{
				string text3 = "NoName";
				if (array[2] == "PLAYER")
				{
					text3 = player.charadata.Indexs_Name["Name"].stringValue;
				}
				else
				{
					CharaData charaData4 = SharedData.Instance().GetCharaData(array[2]);
					if (charaData4 != null)
					{
						text3 = charaData4.Indexs_Name["Name"].stringValue;
					}
				}
				gang_b03Table.Row row4 = CommonResourcesData.b03.Find_ID(array[3]);
				if (row4 != null)
				{
					if (array[4] == "+")
					{
						m_Explore_Text.text = text3 + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetWugong") + " 【" + row4.Name_Trans + "】！";
					}
					else
					{
						m_Explore_Text.text = text3 + " " + CommonFunc.I18nGetLocalizedValue("I18N_LostWugong") + " 【" + row4.Name_Trans + "】！";
					}
				}
				else
				{
					m_Explore_Text.text = "！！江湖上还未有此武功【" + array[1] + "】";
				}
				PlaySoundEffect("Got_Special", "0", null);
			}
			else if (array[1] == "EPIPHANY")
			{
				m_Explore_Text.text = CommonFunc.I18nGetLocalizedValue("I18N_GotEpiphany") + " * " + int.Parse(array[2]) + " ！";
				PlaySoundEffect("Got_Special", "0", null);
			}
			else
			{
				m_Explore_Text.text = "DEBUG【" + _explore + "】";
			}
		}
		else if (array[0] == "INFO")
		{
			m_Explore.SetActive(value: true);
			m_Explore_Text.text = FormatDynamicText(array[1]);
			ChatLog("<color=#e8e5be>【" + CommonFunc.I18nGetLocalizedValue("I18N_Hint") + "】</color><color=#918574>" + m_Explore_Text.text + "</color>");
		}
		else if (array[0] == "VOICEOVER")
		{
			string text4 = array[1];
			if ("ARENA".Equals(array[1]))
			{
				text4 = "ARENA_" + SharedData.Instance().m_ArenaFightID + "_VO_1";
			}
			gang_e02Table.Row row5 = CommonResourcesData.e02.Find_chatid(text4);
			string text5 = "SIGNAL LOST!!";
			if (row5 != null)
			{
				text5 = FormatDynamicText(row5.chating_Trans.Replace("|", "\n"));
				string[] array2 = text5.Split('\n');
				foreach (string text6 in array2)
				{
					ChatLog("<color=#e8e5be>【" + CommonFunc.I18nGetLocalizedValue("I18N_Narrative") + "】</color><color=#a37034>" + text6 + "</color>");
				}
			}
			else
			{
				Debug.LogWarning("[!]>>> chatid NOT found: [" + text4 + "]");
			}
			m_Explore.SetActive(value: true);
			m_Explore_Text.transform.parent.gameObject.SetActive(value: false);
			m_Explore_VoiceOver.SetActive(value: true);
			m_Explore_VoiceOver.transform.Find("Text").GetComponent<Text>().text = text5;
		}
		else if (array[0] == "BROWSEURL")
		{
			m_Explore.SetActive(value: true);
			m_Explore_Text.transform.parent.gameObject.SetActive(value: false);
			m_Explore_BrowseURL.SetActive(value: true);
		}
		else if (array[0] == "GUIDE")
		{
			m_Explore.SetActive(value: true);
			m_Explore_Text.transform.parent.gameObject.SetActive(value: false);
			if (array.Length > 1)
			{
				SharedData.Instance().Guide_Page_Lic = array[1];
			}
			else
			{
				SharedData.Instance().Guide_Page_Lic = "EQUIP";
			}
			m_Explore_Guide.SetActive(value: true);
		}
		else
		{
			if (!(array[0] == "WANTED"))
			{
				return;
			}
			for (int num5 = m_WantedList.transform.Find("ScrollView/Viewport/Content").childCount - 1; num5 >= 0; num5--)
			{
				UnityEngine.Object.DestroyImmediate(m_WantedList.transform.Find("ScrollView/Viewport/Content").GetChild(num5).gameObject);
			}
			m_WantedList.SetActive(value: true);
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			string[] array3 = array[1].Split('&');
			int num6 = -1;
			for (int j = 0; j < array3.Length; j++)
			{
				gang_c03Table.Row row6 = CommonResourcesData.c03.Find_ID(array3[j]);
				if (row6 == null)
				{
					continue;
				}
				string value = "";
				string text7 = "???";
				string text8 = "";
				string[] array4 = row6.Wanted.Split('@');
				if (array4.Length > 1 && "B01".Equals(array4[1]))
				{
					gang_b01Table.Row row7 = CommonResourcesData.b01.Find_ID(array4[0]);
					if (row7 != null)
					{
						value = row7.BattleIcon;
						text7 = row7.LV;
						text8 = row7.Name_Trans;
					}
				}
				else
				{
					gang_b04Table.Row row8 = CommonResourcesData.b04.Find_GID(row6.Wanted);
					if (row8 != null)
					{
						value = row8.BattleIcon;
						text7 = row8.LV;
						text8 = row8.Name_Trans;
					}
					else
					{
						gang_b04Table.Row row9 = CommonResourcesData.b04_Random.Find_GID(row6.Wanted);
						if (row9 != null)
						{
							value = row9.BattleIcon;
							text7 = row9.LV;
							text8 = row9.Name_Trans;
						}
					}
				}
				if ("".Equals(value))
				{
					continue;
				}
				if (array[2] == "CLOSE")
				{
					SharedData.Instance().m_WantedInfos[row6.ID] = 1;
				}
				GameObject gameObject = UnityEngine.Object.Instantiate(WantedPrefab, m_WantedList.transform.Find("ScrollView/Viewport/Content"));
				gameObject.transform.Find("Icon").GetComponent<Image>().sprite = CommonResourcesData.GetRoleIcon(value);
				gameObject.transform.Find("LV/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + text7;
				gameObject.transform.Find("Name").GetComponent<Text>().text = text8;
				gameObject.transform.Find("Money/Text").GetComponent<Text>().text = row6.WantedBonus + "<size=32><color=#E5BD69> " + CommonFunc.I18nGetLocalizedValue("I18N_Money_1") + "</color></size>";
				gameObject.transform.Find("Description").GetComponent<Text>().text = row6.WantedNPC_Trans;
				gameObject.transform.Find("Wantedcheck").gameObject.SetActive(SharedData.Instance().m_WantedInfos[row6.ID] > 0);
				if (num6 < 0 && SharedData.Instance().m_WantedInfos[row6.ID] <= 0)
				{
					num6 = j;
				}
				if (row6.WantedReword != "")
				{
					gang_b07Table.Row row10 = CommonResourcesData.b07.Find_ID(row6.WantedReword);
					if (row10 != null)
					{
						GameObject obj = gameObject.transform.Find("RewordItem").gameObject;
						obj.gameObject.SetActive(value: true);
						obj.GetComponent<PackageIconController>().InitPackageIcon(row10, 1, null, 0);
						obj.transform.Find("Name4Wanted").GetComponent<Text>().text = row10.Name_Trans;
						obj.transform.Find("Name4Wanted").gameObject.SetActive(value: true);
						EventTriggerListener.Get(obj.gameObject).onClick = OnButtonClick;
					}
				}
				if (j == 0)
				{
					EventSystem.current.SetSelectedGameObject(gameObject);
				}
			}
		}
	}

	private void EventFlowEnd(Event _event)
	{
		Debug.Log("[INFO] END Event flow: " + _event.eventid);
		foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[_event.eventid])
		{
			SharedData.Instance().FlagList[item.flag] = 2;
		}
		_event.elseroute = false;
		_event.flow = 2;
	}

	private int InitEvent(Event _event)
	{
		bool flag = false;
		bool flag2 = false;
		foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[_event.eventid])
		{
			if (item.online == "0")
			{
				continue;
			}
			if (_event.originevdata == null)
			{
				_event.originevdata = item;
			}
			if (SharedData.Instance().FlagList[item.flag] == 0)
			{
				if (item.trigger == "AUTO")
				{
					SharedData.Instance().FlagList[item.flag] = 1;
				}
				else
				{
					flag2 = true;
				}
			}
			if (SharedData.Instance().FlagList[item.flag] != 1)
			{
				continue;
			}
			if (_event.evdata != item)
			{
				if (_event.obj == null)
				{
					if (item.display != "")
					{
						string text = item.display;
						if ("ARENA".Equals(text))
						{
							gang_b04Table.Row row = CommonResourcesData.b04.Find_GID(SharedData.Instance().m_ArenaFightID);
							if (row != null)
							{
								text = "Prefabs/Character/" + row.Prefab;
							}
						}
						string[] array = text.Split('|');
						GameObject original = (GameObject)Resources.Load(array[0]);
						if (array[0].StartsWith("Prefabs/Character/"))
						{
							gang_b01SkinTable.Row row2 = CommonResourcesData.b01Skin.Find_ID(array[0].Split('/')[2]);
							if (row2 != null)
							{
								_event.obj = SkinCharacter.InitSkinCharacter(row2);
							}
							else
							{
								_event.obj = UnityEngine.Object.Instantiate(original, map.transform.parent);
							}
						}
						else
						{
							_event.obj = UnityEngine.Object.Instantiate(original, map.transform.parent);
						}
						EventController eventController = (_event.eventController = _event.obj.AddComponent<EventController>());
						eventController.tileName = ((_event.tileobj == null) ? item.flag : _event.tileobj.m_TiledName);
						eventController.name = _event.name;
						eventController.trigger = item.trigger;
						eventController.display = text;
						eventController.Init(item.direction);
					}
					else if (_event.originevdata.display != "")
					{
						string text2 = _event.originevdata.display;
						if ("ARENA".Equals(text2))
						{
							gang_b04Table.Row row3 = CommonResourcesData.b04.Find_GID(SharedData.Instance().m_ArenaFightID);
							if (row3 != null)
							{
								text2 = "Prefabs/Character/" + row3.Prefab;
							}
						}
						string[] array2 = text2.Split('|');
						GameObject original2 = (GameObject)Resources.Load(array2[0]);
						if (array2[0].StartsWith("Prefabs/Character/"))
						{
							gang_b01SkinTable.Row row4 = CommonResourcesData.b01Skin.Find_ID(array2[0].Split('/')[2]);
							if (row4 != null)
							{
								_event.obj = SkinCharacter.InitSkinCharacter(row4);
							}
							else
							{
								_event.obj = UnityEngine.Object.Instantiate(original2, map.transform.parent);
							}
						}
						else
						{
							_event.obj = UnityEngine.Object.Instantiate(original2, map.transform.parent);
						}
						EventController eventController2 = (_event.eventController = _event.obj.AddComponent<EventController>());
						eventController2.tileName = ((_event.tileobj == null) ? item.flag : _event.tileobj.m_TiledName);
						eventController2.name = _event.name;
						eventController2.trigger = item.trigger;
						eventController2.display = text2;
						eventController2.Init(_event.originevdata.direction);
					}
				}
				else if (item.display != "" && !_event.obj.GetComponent<EventController>().display.Equals(item.display))
				{
					UnityEngine.Object.Destroy(_event.obj);
					string text3 = item.display;
					if ("ARENA".Equals(text3))
					{
						gang_b04Table.Row row5 = CommonResourcesData.b04.Find_GID(SharedData.Instance().m_ArenaFightID);
						if (row5 != null)
						{
							text3 = "Prefabs/Character/" + row5.Prefab;
						}
					}
					string[] array3 = text3.Split('|');
					GameObject original3 = (GameObject)Resources.Load(array3[0]);
					if (array3[0].StartsWith("Prefabs/Character/"))
					{
						gang_b01SkinTable.Row row6 = CommonResourcesData.b01Skin.Find_ID(array3[0].Split('/')[2]);
						if (row6 != null)
						{
							_event.obj = SkinCharacter.InitSkinCharacter(row6);
						}
						else
						{
							_event.obj = UnityEngine.Object.Instantiate(original3, map.transform.parent);
						}
					}
					else
					{
						_event.obj = UnityEngine.Object.Instantiate(original3, map.transform.parent);
					}
					EventController eventController3 = (_event.eventController = _event.obj.AddComponent<EventController>());
					eventController3.tileName = ((_event.tileobj == null) ? item.flag : _event.tileobj.m_TiledName);
					eventController3.name = _event.name;
					eventController3.trigger = item.trigger;
					eventController3.display = text3;
					eventController3.Init(item.direction);
				}
				_event.evdata = item;
			}
			_event.elseroute = false;
			_event.flow = 1;
			if (item.trigger == "AUTO")
			{
				DoAutoAction(_event);
			}
			else if (item.trigger == "FOLLOW")
			{
				DoAutoAction(_event);
			}
			flag = true;
			break;
		}
		if (!flag && !flag2)
		{
			_event.elseroute = false;
			_event.flow = 2;
		}
		if (flag)
		{
			return 1;
		}
		return 0;
	}

	public string FormatDynamicText(string _text)
	{
		return SharedData.Instance().FormatDynamicText(_text);
	}

	private void ElixirChara(string _chara)
	{
		if ("PLAYER".Equals(_chara))
		{
			player.charadata.m_Hp = player.charadata.GetFieldValueByName("HP");
			player.charadata.m_Mp = player.charadata.GetFieldValueByName("MP");
			player.charadata.Indexs_Name["Drunk"].fightValue = 0f;
			player.charadata.Indexs_Name["Hurt"].fightValue = 0f;
			player.charadata.Indexs_Name["Poison"].fightValue = 0f;
			player.charadata.Indexs_Name["Bleed"].fightValue = 0f;
			player.charadata.Indexs_Name["Burn"].fightValue = 0f;
			player.charadata.Indexs_Name["Seal"].fightValue = 0f;
			player.charadata.Indexs_Name["Mad"].fightValue = 0f;
			return;
		}
		if ("ALL".Equals(_chara))
		{
			player.charadata.m_Hp = player.charadata.GetFieldValueByName("HP");
			player.charadata.m_Mp = player.charadata.GetFieldValueByName("MP");
			player.charadata.Indexs_Name["Drunk"].fightValue = 0f;
			player.charadata.Indexs_Name["Hurt"].fightValue = 0f;
			player.charadata.Indexs_Name["Poison"].fightValue = 0f;
			player.charadata.Indexs_Name["Bleed"].fightValue = 0f;
			player.charadata.Indexs_Name["Burn"].fightValue = 0f;
			player.charadata.Indexs_Name["Seal"].fightValue = 0f;
			player.charadata.Indexs_Name["Mad"].fightValue = 0f;
			{
				foreach (string follow in SharedData.Instance().FollowList)
				{
					CharaData charaData = SharedData.Instance().GetCharaData(follow);
					charaData.m_Hp = charaData.GetFieldValueByName("HP");
					charaData.m_Mp = charaData.GetFieldValueByName("MP");
					charaData.Indexs_Name["Drunk"].fightValue = 0f;
					charaData.Indexs_Name["Hurt"].fightValue = 0f;
					charaData.Indexs_Name["Poison"].fightValue = 0f;
					charaData.Indexs_Name["Bleed"].fightValue = 0f;
					charaData.Indexs_Name["Burn"].fightValue = 0f;
					charaData.Indexs_Name["Seal"].fightValue = 0f;
					charaData.Indexs_Name["Mad"].fightValue = 0f;
				}
				return;
			}
		}
		CharaData charaData2 = SharedData.Instance().GetCharaData(_chara);
		charaData2.m_Hp = charaData2.GetFieldValueByName("HP");
		charaData2.m_Mp = charaData2.GetFieldValueByName("MP");
		charaData2.Indexs_Name["Drunk"].fightValue = 0f;
		charaData2.Indexs_Name["Hurt"].fightValue = 0f;
		charaData2.Indexs_Name["Poison"].fightValue = 0f;
		charaData2.Indexs_Name["Bleed"].fightValue = 0f;
		charaData2.Indexs_Name["Burn"].fightValue = 0f;
		charaData2.Indexs_Name["Seal"].fightValue = 0f;
		charaData2.Indexs_Name["Mad"].fightValue = 0f;
	}

	private bool DoAutoActionCheck(string[] act)
	{
		bool flag = false;
		int num = 2;
		if (act[1].StartsWith("FLAGS") && act.Length == 4)
		{
			num = int.Parse(act[3]);
		}
		if (act[1] == "FLAGS")
		{
			string[] array = act[2].Split('+');
			flag = true;
			string[] array2 = array;
			foreach (string key in array2)
			{
				if (SharedData.Instance().FlagList.ContainsKey(key) && SharedData.Instance().FlagList[key] != num)
				{
					flag = false;
					break;
				}
			}
		}
		else if (act[1] == "FLAGSOR")
		{
			string[] array3 = act[2].Split('+');
			flag = false;
			string[] array2 = array3;
			foreach (string key2 in array2)
			{
				if (SharedData.Instance().FlagList.ContainsKey(key2) && SharedData.Instance().FlagList[key2] == num)
				{
					flag = true;
					break;
				}
			}
		}
		else if (act[1] == "FACTION")
		{
			string guild = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Guild;
			flag = !"".Equals(guild);
			if (flag)
			{
				gang_b10Table.Row row = CommonResourcesData.b10.Find_ID(guild);
				SharedData.Instance().m_TempParas["faction_name"] = row.Name_Trans;
			}
		}
		else if (act[1] == "PERMISSION")
		{
			string value = "";
			if (act.Length > 3)
			{
				value = act[3];
			}
			if (!"YYOK".Equals(value) && !"ALLOK".Equals(value) && SharedData.Instance().FlagList["GLOBAL_FLAGS_YY"] == 2)
			{
				flag = true;
				SharedData.Instance().m_TempParas["permission_denied"] = CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_YY_" + act[2]);
			}
			else if (!"JWOK".Equals(value) && !"ALLOK".Equals(value) && SharedData.Instance().FlagList["GLOBAL_FLAGS_JWWF"] == 2)
			{
				flag = true;
				SharedData.Instance().m_TempParas["permission_denied"] = CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_JW_" + act[2]);
			}
			else
			{
				string guild2 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Guild;
				flag = !"".Equals(guild2);
				if (flag)
				{
					gang_b10Table.Row row2 = CommonResourcesData.b10.Find_ID(guild2);
					SharedData.Instance().m_TempParas["permission_denied"] = CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_Faction_0") + " " + row2.Name_Trans + CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_Faction_" + act[2]);
				}
			}
		}
		else if (act[1] == "LANG")
		{
			flag = act[2].Equals(GameDataManager.Instance().configdata.language);
		}
		else if (act[1] == "RANDOM")
		{
			flag = UnityEngine.Random.Range(0f, 1f) < float.Parse(act[2], CultureInfo.InvariantCulture);
		}
		else if (act[1] == "GAMEMODE")
		{
			flag = SharedData.Instance().m_Game_Mode == int.Parse(act[2], CultureInfo.InvariantCulture);
		}
		else if (act[1] == "EAPLAYER")
		{
			flag = GameDataManager.Instance().configdata.isEAPlayer;
		}
		else if (act[1] == "RANKOVER")
		{
			flag = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Ranking >= int.Parse(act[2]);
		}
		else if (act[1] == "BORNID")
		{
			flag = act[2].Equals(SharedData.Instance().BornID);
		}
		else if (act[1] == "SEX")
		{
			string value2 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).GetFieldValueByName("Sex")
				.ToString();
			flag = act[2].Equals(value2);
		}
		else if (act[1] == "INHERIT")
		{
			flag = GameDataManager.Instance().configdata.inheritItems.Length > 0;
		}
		else if (act[1] == "KONGFU")
		{
			foreach (KongFuData kongFu in SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_KongFuList)
			{
				if (kongFu.kf.ID == act[2])
				{
					flag = true;
					break;
				}
			}
		}
		else if (act[1] == "EQUIPS")
		{
			CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
			string[] array4 = act[2].Split('&');
			flag = true;
			if (array4.Length == 3)
			{
				for (int j = 0; j < 3; j++)
				{
					if (!"0".Equals(array4[j]) && !charaData.m_EquipSlot[j].Equals(array4[j]))
					{
						string[] array5 = charaData.m_EquipSlot[j].Split('_');
						if (array5.Length < 2 || !"MB07".Equals(array5[0]) || !array5[1].Equals(array4[j]))
						{
							Debug.Log("NOT found eqid[" + array4[j] + "] in Slot-" + j + "[" + charaData.m_EquipSlot[j] + "]");
							flag = false;
							break;
						}
					}
				}
			}
		}
		else if (act[1] == "PARA")
		{
			string[] array6 = act[2].Split('+');
			flag = true;
			string[] array2 = array6;
			for (int i = 0; i < array2.Length; i++)
			{
				string[] array7 = array2[i].Split('_');
				if ("ALL".Equals(array7[0]))
				{
					float num2 = 0f;
					float num3 = float.Parse(array7[3], CultureInfo.InvariantCulture);
					if (array7[2] == ">")
					{
						_ = CommonFunc.I18nGetLocalizedValue("I18N_Amount") + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_GreaterEqual") + "</color> <color=#f0e352>" + (num3 + 1f) + "</color>";
					}
					else if (array7[2] == "<")
					{
						_ = CommonFunc.I18nGetLocalizedValue("I18N_Amount") + "color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_LessEqual") + "</color> <color=#f0e352>" + (num3 - 1f) + "</color>";
					}
					else if (array7[2] == "=")
					{
						_ = CommonFunc.I18nGetLocalizedValue("I18N_Amount") + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + "</color> <color=#f0e352>" + num3 + "</color>";
					}
					CharaData charaData2 = null;
					charaData2 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
					num2 = charaData2.GetFieldValueByName(array7[1]);
					foreach (string follow in SharedData.Instance().FollowList)
					{
						charaData2 = SharedData.Instance().GetCharaData(follow);
						num2 = ((!(array7[1] == "LV")) ? ((!(array7[1] == "HP")) ? ((!(array7[1] == "MP")) ? ((!(array7[1] == "HPLIMIT")) ? ((!(array7[1] == "MPLIMIT")) ? (num2 + charaData2.GetFieldValueByName(array7[1])) : (num2 + charaData2.GetFieldValueByName("MP"))) : (num2 + charaData2.GetFieldValueByName("HP"))) : (num2 + charaData2.m_Mp)) : (num2 + charaData2.m_Hp)) : (num2 + (float)charaData2.m_Level));
					}
					Debug.Log("Check All follower's " + array7[1] + " [" + num2 + "] " + array7[2] + " [" + num3 + "]");
					if (array7[2] == ">")
					{
						if (num2 <= num3)
						{
							flag = false;
						}
					}
					else if (array7[2] == "<")
					{
						if (num2 >= num3)
						{
							flag = false;
						}
					}
					else if (array7[2] == "=" && num2 != num3)
					{
						flag = false;
					}
					continue;
				}
				List<string> list = new List<string>();
				if (array7[0] == "ANY")
				{
					list.Add(SharedData.Instance().playerid);
					list.AddRange(SharedData.Instance().FollowList);
				}
				else if (array7[0] == "SELF")
				{
					list.Add(SharedData.Instance().playerid);
				}
				else if (array7[0].StartsWith("SPEC"))
				{
					list.Add(array7[0].Split('-')[1]);
				}
				else
				{
					list.Add(array7[0]);
				}
				float num4 = 0f;
				float num5 = float.Parse(array7[3], CultureInfo.InvariantCulture);
				string text = "???";
				if (array7[2] == ">")
				{
					text = "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_GreaterEqual") + "</color> <color=#f0e352>" + (num5 + 1f) + "</color>";
				}
				else if (array7[2] == "<")
				{
					text = "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_LessEqual") + "</color> <color=#f0e352>" + (num5 - 1f) + "</color>";
				}
				else if (array7[2] == "=")
				{
					text = "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + "</color> <color=#f0e352>" + num5 + "</color>";
				}
				CharaData charaData3 = null;
				flag = false;
				foreach (string item in list)
				{
					charaData3 = SharedData.Instance().GetCharaData(item);
					num4 = ((array7[1] == "LV") ? ((float)charaData3.m_Level) : ((array7[1] == "MONEY") ? ((float)SharedData.Instance().m_Money) : ((array7[1] == "HP") ? charaData3.m_Hp : ((array7[1] == "MP") ? charaData3.m_Mp : ((array7[1] == "HPLIMIT") ? charaData3.GetFieldValueByName("HP") : ((!(array7[1] == "MPLIMIT")) ? charaData3.GetFieldValueByName(array7[1]) : charaData3.GetFieldValueByName("MP")))))));
					Debug.Log("Check " + charaData3.Indexs_Name["Name"].stringValue + " " + array7[1] + " [" + num4 + "] " + array7[2] + " [" + num5 + "]");
					if (array7[2] == ">")
					{
						if (num4 > num5)
						{
							flag = true;
						}
					}
					else if (array7[2] == "<")
					{
						if (num4 < num5)
						{
							flag = true;
						}
					}
					else if (array7[2] == "=" && num4 == num5)
					{
						flag = true;
					}
					if (flag && array7.Length > 4)
					{
						flag = false;
						num4 = 0f;
						num5 = float.Parse(array7[6], CultureInfo.InvariantCulture);
						num4 = ((array7[4] == "LV") ? ((float)charaData3.m_Level) : ((array7[4] == "MONEY") ? ((float)SharedData.Instance().m_Money) : ((array7[4] == "HP") ? charaData3.m_Hp : ((array7[4] == "MP") ? charaData3.m_Mp : ((array7[4] == "HPLIMIT") ? charaData3.GetFieldValueByName("HP") : ((!(array7[4] == "MPLIMIT")) ? charaData3.GetFieldValueByName(array7[4]) : charaData3.GetFieldValueByName("MP")))))));
						Debug.Log("Check2 " + charaData3.Indexs_Name["Name"].stringValue + " " + array7[4] + " [" + num4 + "] " + array7[5] + " [" + num5 + "]");
						if (array7[5] == ">")
						{
							if (num4 > num5)
							{
								flag = true;
							}
						}
						else if (array7[5] == "<")
						{
							if (num4 < num5)
							{
								flag = true;
							}
						}
						else if (array7[5] == "=" && num4 == num5)
						{
							flag = true;
						}
					}
					if (flag)
					{
						SharedData.Instance().m_TempParas["teammates"] = charaData3.Indexs_Name["Name"].stringValue;
						break;
					}
				}
				if (flag)
				{
					continue;
				}
				gang_a01Table.Row row3 = CommonResourcesData.a01.Find_Name(array7[1]);
				if (array7[0] == "ANY")
				{
					if (array7.Length <= 4)
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_NeedAnyone") + " <color=#f0e352>" + row3.NameScene_Trans + "</color> " + text + "！");
					}
				}
				else if (array7[0] != "SELF" && !array7[0].StartsWith("SPEC"))
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Need") + " <color=#f0e352>" + charaData3.Indexs_Name["Name"].stringValue + "</color> " + CommonFunc.I18nGetLocalizedValue("I18N_InTeamAnd") + " <color=#f0e352>" + row3.NameScene_Trans + "</color> " + text + "！");
				}
			}
			if (flag)
			{
				PlaySoundEffect("Check_True", "0", null);
			}
			else
			{
				PlaySoundEffect("Check_False", "0", null);
			}
		}
		else if (act[1] == "TEAM")
		{
			string[] array8 = act[2].Split('_');
			if (array8.Length > 2)
			{
				float num6 = 0f;
				float num7 = 0f;
				if (array8[0] == "COUNT")
				{
					num6 = SharedData.Instance().FollowList.Count;
					num7 = float.Parse(array8[2], CultureInfo.InvariantCulture);
				}
				if (array8[1] == ">")
				{
					if (num6 > num7)
					{
						flag = true;
					}
				}
				else if (array8[1] == "<")
				{
					if (num6 < num7)
					{
						flag = true;
					}
				}
				else if (array8[1] == "=" && num6 == num7)
				{
					flag = true;
				}
			}
			else if (array8.Length > 1 && array8[0] == "EXISTS")
			{
				flag = SharedData.Instance().FollowList.Contains(array8[1]);
			}
		}
		else if (act[1] == "PARTY")
		{
			flag = SharedData.Instance().FullTeam.Contains(act[2]);
		}
		else if (act[1] == "TRAIT")
		{
			flag = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_TraitList.Contains(act[2]);
		}
		else if (act[1] == "PACKAGE")
		{
			string[] array9 = act[2].Split('+');
			bool flag2 = true;
			string[] array2 = array9;
			foreach (string text2 in array2)
			{
				if (!flag2)
				{
					break;
				}
				string[] array10 = text2.Split('_');
				float num8 = 0f;
				string value3 = "_" + array10[0] + "_";
				foreach (KeyValuePair<string, int> item2 in SharedData.Instance().PlayerPackage)
				{
					if (item2.Key.Contains(value3) || item2.Key.Equals(array10[0]))
					{
						num8 += (float)item2.Value;
					}
				}
				float num9 = float.Parse(array10[2], CultureInfo.InvariantCulture);
				if (array10[1] == ">")
				{
					if (num8 <= num9)
					{
						flag2 = false;
					}
				}
				else if (array10[1] == "<")
				{
					if (num8 >= num9)
					{
						flag2 = false;
					}
				}
				else if (array10[1] == "=" && num8 != num9)
				{
					flag2 = false;
				}
			}
			flag = flag2;
		}
		else if (act[1] == "MINE")
		{
			if (act[2] == "APPRECIATIONTRAIT")
			{
				SharedData.Instance().appreciationCharacterID = "";
				string text3 = "";
				if (player.charadata.GetFieldValueByName("Appreciation") > 0f)
				{
					SharedData.Instance().appreciationCharacterID = player.charadata.m_Id;
					text3 = player.charadata.Indexs_Name["Name"].stringValue;
				}
				else
				{
					foreach (string follow2 in SharedData.Instance().FollowList)
					{
						if (SharedData.Instance().GetCharaData(follow2).GetFieldValueByName("Appreciation") > 0f)
						{
							SharedData.Instance().appreciationCharacterID = follow2;
							text3 = CommonResourcesData.b01.Find_ID(follow2).Name_Trans;
						}
					}
				}
				if (SharedData.Instance().appreciationCharacterID != "" && SharedData.Instance().m_unKnownItemID != "")
				{
					flag = true;
					gang_e02Table.Row row4 = CommonResourcesData.e02.Find_chatid(act[2]);
					gang_b07Table.Row row5 = CommonResourcesData.b07.Find_ID(SharedData.Instance().m_unKnownItemID.Split("&")[1]);
					row4.side = text3;
					row4.side_EN = text3;
					string name_Trans = row5.Name_Trans;
					SharedData.Instance().m_TempParas["UnknownMine"] = name_Trans;
					SharedData.Instance().m_TempParas["player1"] = text3;
					SharedData.Instance().m_PackageController.AppreciationIdValueDict.Add("|" + SharedData.Instance().m_unKnownItemID + "|", 0);
				}
			}
		}
		else if (act[1] == "ARENA" && act[2] == "DaTianWangSi" && SharedData.Instance().m_challengePrizeItemList.Count > 0)
		{
			flag = true;
		}
		return flag;
	}

	private void DoFaction(string _Action, string _FactionID, string _CharacterID)
	{
		gang_b10Table.Row row = CommonResourcesData.b10.Find_ID(_FactionID);
		string[] array = row.Members.Split("|");
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		if (_Action == "JOIN")
		{
			if (_CharacterID == "SELF")
			{
				charaData.m_Guild = _FactionID;
				foreach (string item in array.ToList())
				{
					if (!SharedData.Instance().FullTeam.Contains(item))
					{
						SharedData.Instance().FullTeam.Add(item);
					}
				}
				SharedData.Instance().FlagList["GLOBAL_FLAGS_IN_GUILD"] = 2;
			}
			else if (!array.Contains(_CharacterID))
			{
				if (charaData.m_Guild.Equals(_FactionID) && !SharedData.Instance().FullTeam.Contains(_CharacterID))
				{
					SharedData.Instance().FullTeam.Add(_CharacterID);
				}
				row.Members = row.Members + "|" + _CharacterID;
				SharedData.Instance().GetCharaData(_CharacterID).m_Guild = _FactionID;
			}
		}
		else
		{
			if (!(_Action == "LEAVE"))
			{
				return;
			}
			if (_CharacterID == "SELF")
			{
				foreach (string item2 in array.ToList())
				{
					LeaveTeam(item2, _reteamable: true);
				}
				SharedData.Instance().player.InitFollows();
				SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Guild = "";
				SharedData.Instance().FlagList["GLOBAL_FLAGS_IN_GUILD"] = 0;
			}
			else
			{
				if (!array.Contains(_CharacterID))
				{
					return;
				}
				LeaveTeam(_CharacterID, _reteamable: true);
				SharedData.Instance().player.InitFollows();
				string text = "";
				string[] array2 = array;
				foreach (string text2 in array2)
				{
					if (!text2.Equals(_CharacterID))
					{
						text = ((text.Length != 0) ? (text + "|" + text2) : text2);
					}
				}
				CommonResourcesData.b10.Find_ID(_FactionID).Members = text;
				SharedData.Instance().GetCharaData(_CharacterID).m_Guild = "";
			}
		}
	}

	private void DoAutoAction(Event _event)
	{
		if (_event.evdata.action.Length > 0)
		{
			string[] act = _event.evdata.action.Split('|');
			StatsAndAchievements.Instance().UnlockStoryAchievement(_event.evdata.flag);
			if (act[0] == "CHAT")
			{
				string chat_id = act[1];
				if (act.Length >= 3)
				{
					string find = act[2];
					CommonResourcesData.b01.Find_ID(find);
				}
				if ("ARENA".Equals(act[1]))
				{
					chat_id = "ARENA_" + SharedData.Instance().m_ArenaFightID + "_CHAT_1";
				}
				AddChatList(_event, chat_id);
				m_Canvas_Event = _event;
			}
			else if (act[0] == "GET")
			{
				bool flag = true;
				bool flag2 = false;
				if (act[1] == "LOOT")
				{
					List<gang_c01Table.Row> list = CommonResourcesData.c01.FindAll_ID(act[2]);
					int num = 0;
					foreach (gang_c01Table.Row item in list)
					{
						float num2 = float.Parse(item.Chance, CultureInfo.InvariantCulture);
						if (UnityEngine.Random.Range(0f, 1f) >= num2)
						{
							continue;
						}
						int num3 = 0;
						string[] array = item.QTY.Split('|');
						if (array.Length > 1)
						{
							int minInclusive = int.Parse(array[0]);
							int maxExclusive = int.Parse(array[1]) + 1;
							num3 = UnityEngine.Random.Range(minInclusive, maxExclusive);
						}
						else
						{
							num3 = int.Parse(array[0]);
						}
						if ("999".Equals(item.Item))
						{
							if (num3 > 0)
							{
								num3 = Mathf.CeilToInt((float)num3 * SharedData.Instance().m_Money_Drop_Rate);
							}
							SharedData.Instance().m_Money += num3;
							if (SharedData.Instance().m_Money < 0)
							{
								SharedData.Instance().m_Money = 0;
							}
						}
						else
						{
							SharedData.Instance().PackageAdd(item.Item, num3);
						}
						num++;
						string explore = "GET|ITEM|" + item.Item + "|" + num3;
						AddExploreList(explore);
					}
					if (num <= 0)
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_NextTime"));
					}
					if ("END".Equals(_event.evdata.output) && _event.obj != null)
					{
						if (m_HoldCamera == _event.obj)
						{
							PlayerTakeCamera();
						}
						mapUnits.Remove(_event.obj.name);
						UnityEngine.Object.Destroy(_event.obj);
						_event.obj = null;
					}
					m_Canvas_Event = _event;
				}
				else if (act[1] == "ATTR")
				{
					CharaData charaData = player.charadata;
					if (act.Length > 4)
					{
						charaData = SharedData.Instance().GetCharaData(act[4]);
					}
					if (act[2] == "TALENT")
					{
						charaData.m_Talent += Mathf.FloorToInt(float.Parse(act[3], CultureInfo.InvariantCulture));
						int num4 = int.Parse(SharedData.Instance().m_A01NameRowDirec["TALENT"].Limit);
						if (charaData.m_Talent > num4)
						{
							charaData.m_Talent = num4;
						}
					}
					else if (act[2] == "LV")
					{
						charaData.m_Level += Mathf.FloorToInt(float.Parse(act[3], CultureInfo.InvariantCulture));
						int num5 = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
						if (charaData.m_Level > num5)
						{
							charaData.m_Level = num5;
						}
						charaData.m_Exp = 0;
					}
					else if (act[2] == "RANK")
					{
						if ("+".Equals(act[3]))
						{
							charaData.m_Ranking++;
						}
						else if ("-".Equals(act[3]))
						{
							charaData.m_Ranking--;
						}
						else
						{
							charaData.m_Ranking = Mathf.FloorToInt(float.Parse(act[3], CultureInfo.InvariantCulture));
						}
						if (charaData.m_Ranking < 1)
						{
							charaData.m_Ranking = 1;
						}
					}
					else
					{
						charaData.Indexs_Name[act[2]].juqingValue += Mathf.Floor(float.Parse(act[3], CultureInfo.InvariantCulture));
						if (act[2] == "HP")
						{
							if (charaData.m_Hp > charaData.GetFieldValueByName("HP"))
							{
								charaData.m_Hp = charaData.GetFieldValueByName("HP");
							}
						}
						else if (act[2] == "MP" && charaData.m_Mp > charaData.GetFieldValueByName("MP"))
						{
							charaData.m_Mp = charaData.GetFieldValueByName("MP");
						}
					}
				}
				else if (act[1] == "EPIPHANY")
				{
					SharedData.Instance().m_Epiphany += Mathf.FloorToInt(float.Parse(act[2], CultureInfo.InvariantCulture));
				}
				else if (act[1] == "OPINION")
				{
					CharaData charaData2 = SharedData.Instance().GetCharaData(act[2]);
					if (charaData2 != null)
					{
						int num6 = int.Parse(act[3]);
						charaData2.m_Relationship += num6;
						Debug.Log(charaData2.Indexs_Name["Name"].stringValue + " m_Relationship = " + charaData2.m_Relationship);
					}
				}
				else if (act[1] == "TRAIT")
				{
					if (act[2] == "PLAYER")
					{
						if (act[4] == "+")
						{
							if (!player.charadata.m_TraitList.Contains(act[3]))
							{
								player.charadata.AddTraits(act[3]);
								gang_b06Table.Row row = CommonResourcesData.b06.Find_id(act[3]);
								if ("1".Equals(row.isLockTrait))
								{
									player.charadata.m_EquipTraitDict[row.traitEquipIndex] = row.id;
								}
								GameDataManager.Instance().AddUnlockAtlasList(act[3], "b06");
							}
							else
							{
								flag = false;
							}
						}
						else if (player.charadata.m_TraitList.Contains(act[3]))
						{
							player.charadata.RemoveTrait(act[3]);
						}
						else
						{
							flag = false;
						}
					}
					else
					{
						CharaData charaData3 = SharedData.Instance().GetCharaData(act[2]);
						if (charaData3 != null)
						{
							if (act[4] == "+")
							{
								if (!charaData3.m_TraitList.Contains(act[3]))
								{
									charaData3.AddTraits(act[3]);
									gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(act[3]);
									if ("1".Equals(row2.isLockTrait))
									{
										charaData3.m_EquipTraitDict[row2.traitEquipIndex] = row2.id;
									}
									GameDataManager.Instance().AddUnlockAtlasList(act[3], "b06");
								}
								else
								{
									flag = false;
								}
							}
							else if (charaData3.m_TraitList.Contains(act[3]))
							{
								charaData3.RemoveTrait(act[3]);
							}
							else
							{
								flag = false;
							}
						}
					}
				}
				else if (act[1] == "ITEM")
				{
					if ("ARENA".Equals(act[2]))
					{
						if (act[3].Equals("JunShanGaiBang"))
						{
							string[] array2 = SharedData.Instance().m_Arena_RewardsID_JunShan.Split('|');
							List<int> list2 = new List<int>();
							for (int i = 0; i < array2.Length; i++)
							{
								if (SharedData.Instance().m_Arena_Rewards_JunShan[i] == '0')
								{
									list2.Add(i);
								}
							}
							if (list2.Count > 0)
							{
								int index = UnityEngine.Random.Range(0, list2.Count);
								act[2] = array2[list2[index]];
								act[3] = "1";
								char[] array3 = SharedData.Instance().m_Arena_Rewards_JunShan.ToCharArray();
								array3[list2[index]] = '1';
								SharedData.Instance().m_Arena_Rewards_JunShan = new string(array3);
								Debug.Log("SharedData.Instance().m_Arena_Rewards_JunShan update: " + SharedData.Instance().m_Arena_Rewards_JunShan);
							}
							else
							{
								act[2] = "999";
								act[3] = "1000";
							}
						}
						else if (act[3].Equals("DaTianWangSi"))
						{
							if (SharedData.Instance().m_challengePrizeItemList.Count > 0)
							{
								new List<int>();
								for (int j = 0; j < SharedData.Instance().m_challengePrizeItemList.Count; j++)
								{
									string text = SharedData.Instance().m_challengePrizeItemList[j];
									string text2 = SharedData.Instance().m_challengePrizeNumberList[j].ToString();
									string text3 = SharedData.Instance().m_challengePrizeLevelList[j].ToString();
									string text4 = text3 + "&" + text + "&" + text2;
									SharedData sharedData = SharedData.Instance();
									sharedData.m_Arena_Rewards_DaTianWangSi = sharedData.m_Arena_Rewards_DaTianWangSi + text4 + "|";
								}
							}
							List<string> list3 = new List<string>();
							List<int> list4 = new List<int>();
							for (int k = 0; k < SharedData.Instance().m_challengePrizeItemList.Count; k++)
							{
								if (list3.Contains(SharedData.Instance().m_challengePrizeItemList[k]))
								{
									list4[list3.IndexOf(SharedData.Instance().m_challengePrizeItemList[k])] += SharedData.Instance().m_challengePrizeNumberList[k];
									continue;
								}
								list3.Add(SharedData.Instance().m_challengePrizeItemList[k]);
								list4.Add(SharedData.Instance().m_challengePrizeNumberList[k]);
							}
							if (list3.Count > 0)
							{
								new List<int>();
								for (int l = 0; l < list3.Count; l++)
								{
									string text5 = list3[l];
									string text6 = list4[l].ToString();
									SharedData.Instance().PackageAdd(text5, int.Parse(text6));
									AddExploreList("GET|ITEM|" + text5 + "|" + text6);
								}
							}
							flag2 = true;
							m_Canvas_Event = _event;
							act[2] = "";
						}
					}
					if (act[2] == "999")
					{
						float num7 = float.Parse(act[3], CultureInfo.InvariantCulture);
						int num8 = Mathf.CeilToInt(num7);
						if (num7 > 0f)
						{
							num8 = Mathf.CeilToInt(num7 * SharedData.Instance().m_Money_Drop_Rate);
						}
						SharedData.Instance().m_Money += num8;
						if (SharedData.Instance().m_Money < 0)
						{
							SharedData.Instance().m_Money = 0;
						}
						flag2 = true;
						AddExploreList("GET|ITEM|999|" + num8);
						m_Canvas_Event = _event;
					}
					else if (act[2] == "APPRECIATIONMINE")
					{
						foreach (KeyValuePair<string, int> item2 in SharedData.Instance().m_PackageController.AppreciationIdValueDict)
						{
							string text7 = item2.Key.Split('|')[1];
							SharedData.Instance().PackageRemove(text7);
							AddExploreList("GET|ITEM|" + text7 + "|-1");
							SharedData.Instance().PackageAdd(text7.Split("&")[1], 1);
							AddExploreList("GET|ITEM|" + text7.Split("&")[1] + "|1");
						}
						SharedData.Instance().m_PackageController.AppreciationIdValueDict.Clear();
						SharedData.Instance().m_unKnownItemID = "";
						m_Canvas_Event = _event;
						flag2 = true;
					}
					else if (act[2] != "")
					{
						int num9 = 0;
						num9 = ((!"PLAYROUND".Equals(act[3])) ? int.Parse(act[3]) : Mathf.Min(GameDataManager.Instance().configdata.playRound + 1, 9));
						bool flag3 = SharedData.Instance().PackageAdd(act[2], num9);
						if (!"-99999".Equals(act[3]))
						{
							flag2 = true;
							if (!flag3)
							{
								AddExploreList("GET|ITEM|" + act[2] + "|" + num9);
								m_Canvas_Event = _event;
							}
						}
					}
					if ("END".Equals(_event.evdata.output) && _event.obj != null)
					{
						if (m_HoldCamera == _event.obj)
						{
							PlayerTakeCamera();
						}
						mapUnits.Remove(_event.obj.name);
						UnityEngine.Object.Destroy(_event.obj);
						_event.obj = null;
					}
				}
				else if (act[1] == "MINE")
				{
					if (SharedData.Instance().m_DiggingMineGrid != Vector3Int.zero)
					{
						MineInfo mineInfo = SharedData.Instance().mapMineList.Find((MineInfo x) => x._grid == SharedData.Instance().m_DiggingMineGrid && x._scenename == sceneName);
						string find2 = "defaultMine300000";
						if (mineInfo != null)
						{
							find2 = mineInfo._c04ID;
							mineInfo._isDigged = true;
						}
						if (++SharedData.Instance().m_ShovelDurable >= SharedData.Instance().ShovelDurable)
						{
							SharedData.Instance().m_ShovelDurable = 0;
							SharedData.Instance().PackageAdd("2133", -1);
							AddExploreList("GET|ITEM|2133|-1");
						}
						bool flag4 = false;
						foreach (gang_c01Table.Row item3 in CommonResourcesData.c01.FindAll_ID(find2))
						{
							if ((float)UnityEngine.Random.Range(0, 100) > (float)int.Parse(item3.Chance) + player.charadata.GetFieldValueByName("DiggingMineChangeAdd") * 100f)
							{
								continue;
							}
							int num10 = 0;
							if (item3.QTY.Contains("|"))
							{
								int minInclusive2 = int.Parse(item3.QTY.Split("|")[0]);
								int num11 = int.Parse(item3.QTY.Split("|")[1]);
								num10 = UnityEngine.Random.Range(minInclusive2, num11 + 1) + (int)player.charadata.GetFieldValueByName("DiggingMineNumberAdd");
							}
							else
							{
								num10 = int.Parse(item3.QTY);
							}
							string text8 = item3.Item;
							if (item3.Item.Contains("Mine"))
							{
								gang_b07Table.Row row3 = CommonResourcesData.b07.Find_ID(item3.Item);
								List<gang_c01Table.Row> list5 = CommonResourcesData.c01.FindAll_ID(row3.Relateid);
								List<float> list6 = new List<float>();
								float num12 = 0f;
								foreach (gang_c01Table.Row item4 in list5)
								{
									list6.Add(float.Parse(item4.Chance, CultureInfo.InvariantCulture));
									num12 += float.Parse(item4.Chance, CultureInfo.InvariantCulture);
								}
								for (int m = 0; m < list6.Count; m++)
								{
									list6[m] /= num12;
								}
								float num13 = UnityEngine.Random.Range(0f, 1f);
								int num14 = 0;
								for (float num15 = list6[num14]; num15 < num13; num15 += list6[num14])
								{
									num14++;
									if (num14 >= list6.Count)
									{
										num14--;
										break;
									}
								}
								int num16 = 0;
								foreach (KeyValuePair<string, int> item5 in SharedData.Instance().PlayerPackage)
								{
									if (item5.Key.Contains("Mine"))
									{
										num16++;
										StatsAndAchievements.Instance().UnlockAchievement("1006");
									}
								}
								text8 = item3.Item + "&" + list5[num14].Item + "&" + num16;
								SharedData.Instance().m_unKnownItemID = text8;
								num10 = 1;
							}
							SharedData.Instance().PackageAdd(text8, num10);
							flag4 = true;
							flag2 = true;
							AddExploreList("GET|ITEM|" + item3.Item + "|" + num10);
							m_Canvas_Event = _event;
						}
						if (!flag4)
						{
							AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_AllTrash"));
							m_Canvas_Event = _event;
						}
						SharedData.Instance().m_DiggingMineGrid = Vector3Int.zero;
					}
				}
				else if (act[1] == "INHERIT")
				{
					getInheritItems();
				}
				else if (act[1] == "WUGONG")
				{
					if (act[2] == "PLAYER")
					{
						if (act[4] == "+")
						{
							if (player.charadata.GetKongFuByID(act[3]) == null)
							{
								KongFuData kongFuData = new KongFuData();
								kongFuData.kf = CommonResourcesData.b03.Find_ID(act[3]);
								kongFuData.lv = 1;
								kongFuData.exp = 0f;
								kongFuData.proficiency = 0;
								player.charadata.KongFuListAdd(kongFuData);
							}
							else
							{
								flag = false;
							}
						}
						else
						{
							KongFuData kongFuByID = player.charadata.GetKongFuByID(act[3]);
							if (kongFuByID != null)
							{
								player.charadata.KongFuListRemove(kongFuByID);
							}
							else
							{
								flag = false;
							}
						}
					}
					else
					{
						CharaData charaData4 = SharedData.Instance().GetCharaData(act[2]);
						if (charaData4 != null)
						{
							if (act[4] == "+")
							{
								if (charaData4.GetKongFuByID(act[3]) == null)
								{
									KongFuData kongFuData2 = new KongFuData();
									kongFuData2.kf = CommonResourcesData.b03.Find_ID(act[3]);
									kongFuData2.lv = 1;
									kongFuData2.exp = 0f;
									kongFuData2.proficiency = 0;
									charaData4.KongFuListAdd(kongFuData2);
								}
								else
								{
									flag = false;
								}
							}
							else
							{
								KongFuData kongFuByID2 = charaData4.GetKongFuByID(act[3]);
								if (kongFuByID2 != null)
								{
									charaData4.KongFuListRemove(kongFuByID2);
								}
								else
								{
									flag = false;
								}
							}
						}
					}
				}
				if (!(act[1] != "LOOT") || !(act[1] != "INHERIT"))
				{
					return;
				}
				if (flag)
				{
					if (!flag2)
					{
						AddExploreList(_event.evdata.action);
						m_Canvas_Event = _event;
					}
				}
				else
				{
					EventComplete(_event);
				}
			}
			else if (act[0] == "WANTED")
			{
				AddExploreList(_event.evdata.action);
				m_Canvas_Event = _event;
			}
			else if (act[0] == "VOICEOVER")
			{
				AddExploreList(_event.evdata.action);
				m_Canvas_Event = _event;
			}
			else if (act[0] == "BROWSEURL")
			{
				AddExploreList(_event.evdata.action);
				m_Canvas_Event = _event;
			}
			else if (act[0] == "GUIDE")
			{
				AddExploreList(_event.evdata.action);
				m_Canvas_Event = _event;
			}
			else if (act[0] == "INFO")
			{
				List<gang_e02Table.Row> list7 = CommonResourcesData.e02.FindAll_chatid(act[1]);
				if (list7.Count <= 0)
				{
					AddExploreList("INFO|" + act[1]);
				}
				else
				{
					foreach (gang_e02Table.Row item6 in list7)
					{
						AddExploreList("INFO|" + item6.chating_Trans);
					}
				}
				m_Canvas_Event = _event;
			}
			else if (act[0] == "CHANGETEAM")
			{
				EventComplete(_event);
				LoadSceneAdditive("BeforeTeam");
			}
			else if (act[0] == "EXPELTEAM")
			{
				EventComplete(_event);
				SharedData.Instance().SubdueManageFor = "Expel";
				LoadSceneAdditive("SubdueManage");
			}
			else if (act[0] == "CURE")
			{
				int num17 = int.Parse(act[1]);
				if (num17 > SharedData.Instance().m_Money)
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_InsufficientMoneyToCure"));
				}
				else
				{
					bool flag5 = IsCharaNeedCure(player.charadata);
					if (!flag5)
					{
						foreach (string follow in SharedData.Instance().FollowList)
						{
							CharaData charaData5 = SharedData.Instance().GetCharaData(follow);
							flag5 = IsCharaNeedCure(charaData5);
							if (flag5)
							{
								break;
							}
						}
					}
					if (flag5)
					{
						SharedData.Instance().m_Money -= num17;
						player.charadata.Indexs_Name["Drunk"].fightValue = 0f;
						player.charadata.Indexs_Name["Hurt"].fightValue = 0f;
						player.charadata.Indexs_Name["Poison"].fightValue = 0f;
						player.charadata.Indexs_Name["Bleed"].fightValue = 0f;
						player.charadata.Indexs_Name["Burn"].fightValue = 0f;
						player.charadata.Indexs_Name["Seal"].fightValue = 0f;
						player.charadata.Indexs_Name["Mad"].fightValue = 0f;
						foreach (string follow2 in SharedData.Instance().FollowList)
						{
							CharaData charaData6 = SharedData.Instance().GetCharaData(follow2);
							charaData6.Indexs_Name["Drunk"].fightValue = 0f;
							charaData6.Indexs_Name["Hurt"].fightValue = 0f;
							charaData6.Indexs_Name["Poison"].fightValue = 0f;
							charaData6.Indexs_Name["Bleed"].fightValue = 0f;
							charaData6.Indexs_Name["Burn"].fightValue = 0f;
							charaData6.Indexs_Name["Seal"].fightValue = 0f;
							charaData6.Indexs_Name["Mad"].fightValue = 0f;
						}
						if (num17 <= 0)
						{
							AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Cured_1"));
						}
						else
						{
							AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Cured_2") + num17 + CommonFunc.I18nGetLocalizedValue("I18N_Money_2"));
						}
					}
					else
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_NoNeedCure"));
					}
				}
				m_Canvas_Event = _event;
			}
			else if (act[0] == "ELIXIR")
			{
				ElixirChara(act[1]);
				EventComplete(_event);
			}
			else if (act[0] == "REST")
			{
				int num18 = int.Parse(act[1]);
				if (num18 > SharedData.Instance().m_Money)
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_InsufficientMoneyToStay"));
				}
				else
				{
					SharedData.Instance().m_Money -= num18;
					ElixirChara("ALL");
					if (num18 <= 0)
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Restored_1"));
					}
					else
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Restored_2") + " " + num18 + CommonFunc.I18nGetLocalizedValue("I18N_Money_2"));
					}
					SharedData.Instance().mapMineCouldRefreshList.Clear();
					SharedData.Instance().mapMineList.Clear();
				}
				m_Canvas_Event = _event;
			}
			else if (act[0] == "SAVEDATA")
			{
				EventComplete(_event);
				SaveMapSnapShot();
				m_Menu3.Close();
				SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
				SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Save;
				SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
			}
			else if (act[0] == "CALLSCENE")
			{
				EventComplete(_event);
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				LoadSceneAdditive(act[1]);
			}
			else if (act[0] == "FLAG")
			{
				if (act[1] == "INIT")
				{
					if (SharedData.Instance().FlagList.ContainsKey(act[2]))
					{
						SharedData.Instance().FlagList[act[2]] = 0;
					}
				}
				else if (act[1] == "OPEN")
				{
					if (SharedData.Instance().FlagList.ContainsKey(act[2]))
					{
						SharedData.Instance().FlagList[act[2]] = 1;
					}
				}
				else if (act[1] == "CLOSE")
				{
					if (SharedData.Instance().FlagList.ContainsKey(act[2]))
					{
						SharedData.Instance().FlagList[act[2]] = 2;
					}
				}
				else if (act[1] == "SET")
				{
					if (SharedData.Instance().FlagList.ContainsKey(act[2]))
					{
						SharedData.Instance().FlagList[act[2]] = int.Parse(act[3]);
					}
				}
				else if (act[1] == "ADD")
				{
					if (SharedData.Instance().FlagList.ContainsKey(act[2]))
					{
						SharedData.Instance().FlagList[act[2]]++;
					}
				}
				else if (act[1] == "SUB" && SharedData.Instance().FlagList.ContainsKey(act[2]))
				{
					SharedData.Instance().FlagList[act[2]]--;
				}
				EventComplete(_event);
			}
			else if (act[0] == "EVENT")
			{
				if (act[1] == "OPEN")
				{
					OpenEvent(act[2]);
				}
				else if (act[1] == "ACTIVEOPEN")
				{
					OpenEvent(act[2], _active: true);
				}
				else if (act[1] == "EOFACTIVEOPEN")
				{
					InitEOFEvents(act[2]);
					OpenEvent(act[2], _active: true);
				}
				else if (act[1] == "CLOSE")
				{
					CloseEvent(act[2]);
				}
				EventComplete(_event);
			}
			else if (act[0] == "UPDATEPLAYROUND")
			{
				if (SharedData.Instance().m_PlayRound > GameDataManager.Instance().configdata.playRound)
				{
					GameDataManager.Instance().configdata.playRound = SharedData.Instance().m_PlayRound;
					GameDataManager.Instance().SaveConfig();
				}
				EventComplete(_event);
			}
			else if (act[0] == "UPDATEARENAWINCOUNT")
			{
				SharedData.Instance().m_ArenaWinCount++;
				EventComplete(_event);
			}
			else if (act[0] == "MOVIE")
			{
				string[] array4 = act[1].Split('#');
				int num19 = 0;
				m_Menu3.Close();
				string[] array5 = array4;
				for (int n = 0; n < array5.Length; n++)
				{
					string[] array6 = array5[n].Split('$');
					if (array6[0] == "MOVE")
					{
						if (array6[1] == "PLAYER")
						{
							if (array6.Length > 3)
							{
								player.MovingSpeedRate = float.Parse(array6[3], CultureInfo.InvariantCulture);
							}
							player.PlaySceneMove(array6[2]);
							player.m_ScenePlay = 1;
							player.m_MovieMove = true;
							num19++;
							continue;
						}
						Event eventById = GetEventById(array6[1]);
						if (eventById != null && eventById.obj != null)
						{
							EventController component = eventById.obj.GetComponent<EventController>();
							if (array6.Length > 3)
							{
								component.MovingSpeedRate = float.Parse(array6[3], CultureInfo.InvariantCulture);
							}
							component.PlaySceneMove(array6[2]);
							component.m_ScenePlay = 1;
							num19 = (component.m_MovieCutID = num19 + 1);
							component.m_MovieEvent = _event;
						}
					}
					else
					{
						if (!(array6[0] == "PLAYANI"))
						{
							continue;
						}
						bool isLoop = false;
						if (array6.Length > 4)
						{
							isLoop = "LOOP".Equals(array6[4]);
						}
						float timescale = 1f;
						if (array6.Length > 5)
						{
							timescale = float.Parse(array6[5], CultureInfo.InvariantCulture);
						}
						if (array6[1] == "PLAYER")
						{
							player.m_KeepAnimation = false;
							player.PlayAnimation(array6[2], loop: true, compensate: false, timescale);
							player.m_IsLoop = isLoop;
							if (array6[3] != "0")
							{
								player.Idle(array6[3]);
								num19++;
							}
							continue;
						}
						Event eventById2 = GetEventById(array6[1]);
						if (eventById2 != null && eventById2.obj != null)
						{
							eventById2.obj.GetComponent<EventController>().m_KeepAnimation = false;
							eventById2.obj.GetComponent<EventController>().PlayAnimation(array6[2], loop: true, compensate: false, timescale);
							eventById2.obj.GetComponent<EventController>().m_IsLoop = isLoop;
							if (array6[3] != "0")
							{
								eventById2.obj.GetComponent<EventController>().Idle(array6[3]);
								num19++;
								eventById2.obj.GetComponent<EventController>().m_MovieCutID = num19;
								eventById2.obj.GetComponent<EventController>().m_MovieEvent = _event;
							}
						}
					}
				}
			}
			else if (act[0] == "MOVE")
			{
				m_Menu3.Close();
				if (act[1] == "PLAYER")
				{
					if (act.Length > 3)
					{
						player.MovingSpeedRate = float.Parse(act[3], CultureInfo.InvariantCulture);
					}
					if (act.Length > 4 && "MULTI".Equals(act[4]))
					{
						player.PlaySceneMove(act[2], _event);
					}
					else
					{
						player.PlaySceneMove(act[2]);
						player.m_ScenePlay = 1;
					}
					m_Current_Event = _event;
					return;
				}
				if (act[1] == "THIS")
				{
					EventController component2 = _event.obj.GetComponent<EventController>();
					if (act.Length > 3)
					{
						component2.MovingSpeedRate = float.Parse(act[3], CultureInfo.InvariantCulture);
					}
					if (act.Length > 4 && "MULTI".Equals(act[4]))
					{
						component2.PlaySceneMove(act[2], _event);
						return;
					}
					component2.PlaySceneMove(act[2]);
					component2.m_ScenePlay = 1;
					return;
				}
				Event eventById3 = GetEventById(act[1]);
				if (eventById3 != null && eventById3.obj != null)
				{
					EventController component3 = eventById3.obj.GetComponent<EventController>();
					if (act.Length > 3)
					{
						component3.MovingSpeedRate = float.Parse(act[3], CultureInfo.InvariantCulture);
					}
					if (act.Length > 4 && "MULTI".Equals(act[4]))
					{
						component3.PlaySceneMove(act[2], _event);
						return;
					}
					component3.PlaySceneMove(act[2]);
					component3.m_ScenePlay = 1;
				}
			}
			else if (act[0] == "WARP")
			{
				if (act[1] == "PLAYER")
				{
					if ("ZERO".Equals(act[2]))
					{
						player.WarpTo(Vector3.zero);
					}
					else
					{
						SuperObject superObject = getByName(act[2])[0];
						player.WarpTo(superObject.transform.position);
					}
				}
				else
				{
					Event eventById4 = GetEventById(act[1]);
					if (eventById4 != null && eventById4.obj != null)
					{
						EventController component4 = eventById4.obj.GetComponent<EventController>();
						if ("ZERO".Equals(act[2]))
						{
							component4.WarpTo(Vector3.zero);
						}
						else if ("PLAYER".Equals(act[2]))
						{
							component4.WarpTo(player.transform.position);
						}
						else
						{
							SuperObject superObject2 = getByName(act[2])[0];
							component4.WarpTo(superObject2.transform.position);
						}
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "TELEPORT")
			{
				IsTeleport = true;
				m_Menu3.Close();
				EventComplete(_event);
				if (act[1] == "RETURNTOSCENE")
				{
					SharedData.Instance().BackFromOtherScene = true;
					LoadScene(SharedData.Instance().SceneBefore);
				}
				else if (act[1] == "GAMEOVER")
				{
					LoadScene("Title");
				}
				else if (act[1] == "THISMAP")
				{
					SharedData.Instance().SpawnPoint = act[2];
					if (act[2][0] == '@')
					{
						string text9 = act[2][1..];
						if (text9 == "PLAYER")
						{
							SharedData.Instance().Mark_Position = player.transform.position;
							SharedData.Instance().Mark_Direction = player.GetMonoDirection();
						}
						else
						{
							Event eventById5 = GetEventById(text9);
							SharedData.Instance().Mark_Position = eventById5.eventController.transform.position;
							SharedData.Instance().Mark_Direction = eventById5.eventController.GetMonoDirection();
						}
					}
					SharedData.Instance().SpawnStatus = "Normal";
					if (act.Length > 3)
					{
						SharedData.Instance().SpawnStatus = act[3];
					}
					LoadScene(sceneName);
				}
				else
				{
					if (_event.evdata.trigger == "FOOTON")
					{
						AutoGameSaveController.instance.AutoSave();
					}
					SharedData.Instance().SpawnPoint = act[2];
					SharedData.Instance().SpawnStatus = "Normal";
					if (act.Length > 3)
					{
						SharedData.Instance().SpawnStatus = act[3];
					}
					LoadScene(act[1]);
				}
			}
			else if (act[0] == "LEAVEFACTIONMAP")
			{
				EventComplete(_event);
				SharedData.Instance().SpawnMapName = act[1];
				SharedData.Instance().SpawnPoint = act[2];
				SharedData.Instance().SpawnStatus = "Normal";
				if (act.Length > 3)
				{
					SharedData.Instance().SpawnStatus = act[3];
				}
				LoadSceneAdditive("BeforeTeam");
			}
			else if (act[0] == "PLAYSE")
			{
				PlaySoundEffect(act[1], act[2], _event);
			}
			else if (act[0] == "PLAYBGM")
			{
				FieldBGM = CommonResourcesData.LoadBgm(act[1]);
				PlayBGM();
				EventComplete(_event);
			}
			else if (act[0] == "PLAYCG")
			{
				EventComplete(_event);
				SaveMapSnapShot();
				SharedData.Instance().PlayCGName = act[1];
				if (act.Length > 2)
				{
					SharedData.Instance().PlayCGBGM = act[2];
				}
				SharedData.Instance().AfterCGPlayComplete = _event.evdata.flag + "_COMPLETE";
				SharedData.Instance().BackFromOtherScene = false;
				SceneManager.LoadScene("CGPlayer");
			}
			else if (act[0] == "ENDPUSH")
			{
				SharedData.Instance().m_EndAVGFIFO.Add(act[1]);
				EventComplete(_event);
			}
			else if (act[0] == "ENDAVG")
			{
				if (SharedData.Instance().m_PlayRound > GameDataManager.Instance().configdata.playRound)
				{
					GameDataManager.Instance().configdata.playRound = SharedData.Instance().m_PlayRound;
					GameDataManager.Instance().SaveConfig();
				}
				EventComplete(_event);
				SaveMapSnapShot();
				SharedData.Instance().PlayCGName = act[1];
				SharedData.Instance().AfterCGPlayComplete = _event.evdata.flag + "_COMPLETE";
				SharedData.Instance().BackFromOtherScene = false;
				SceneManager.LoadScene("AVGEngine");
			}
			else if (act[0] == "ARENA")
			{
				string text10 = "";
				if (act[1].Equals("DaTianWangSi"))
				{
					if (act[2].Equals("Start"))
					{
						SharedData.Instance().m_DaTianWangSiLevel = 0;
						SharedData.Instance().m_challengePrizeItemList.Clear();
						SharedData.Instance().m_challengePrizeNumberList.Clear();
						SharedData.Instance().m_challengePrizeLevelList.Clear();
					}
					text10 = SharedData.Instance().m_DaTianWangSiLevel.ToString();
					SharedData.Instance().m_DaTianWangSiLevel++;
					SharedData.Instance().m_isDaTianWangSiChallenge = true;
				}
				else
				{
					text10 = act[2];
				}
				List<gang_b11Table.Row> list8 = CommonResourcesData.b11.FindAll_Arena(act[1]);
				if (list8 != null && list8.Count > 0)
				{
					foreach (gang_b11Table.Row item7 in list8)
					{
						if (item7.Wave.Equals(text10))
						{
							string[] array7 = item7.Members.Split('|');
							int num20 = UnityEngine.Random.Range(0, array7.Length);
							SharedData.Instance().m_ArenaFightID = array7[num20];
							Debug.LogWarning("SharedData.Instance().m_ArenaFightID = " + SharedData.Instance().m_ArenaFightID);
							break;
						}
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "BATTLE")
			{
				EventComplete(_event);
				SaveMapSnapShot();
				SharedData.Instance().BattleEnemyGroupId = act[2];
				SharedData.Instance().DuelBattleGuild = "";
				if (act.Length > 3)
				{
					SharedData.Instance().BattleMemberMax = int.Parse(act[3]);
				}
				else
				{
					SharedData.Instance().BattleMemberMax = 3;
				}
				if (act[1].Equals("BattleField-DaTianWangSiRandom"))
				{
					act[1] = "BattleField-DaTianWangSi-" + UnityEngine.Random.Range(1, 4) + "F";
					SharedData.Instance().m_isDaTianWangSiChallenge = true;
					SharedData.Instance().BattleMemberMax = 5;
				}
				SharedData.Instance().BattleGround = act[1];
				SharedData.Instance().BattleItemGroupId = _event.evdata.menu;
				SharedData.Instance().AfterBattleWin = _event.evdata.flag + "_WIN";
				SharedData.Instance().AfterBattleLose = _event.evdata.flag + "_LOSE";
				SharedData.Instance().BackFromOtherScene = false;
				SharedData.Instance().PlayerSetting.Clear();
				SharedData.Instance().EnemySetting.Clear();
				enemygid = SharedData.Instance().BattleEnemyGroupId.Split('-');
				if (enemygid[0] == "solo")
				{
					SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
					LoadScene(act[1], isBattle: true);
					return;
				}
				if (enemygid[0] == "demo")
				{
					SharedData.Instance().b04BattleID = enemygid[1];
					LoadScene(act[1], isBattle: true);
					return;
				}
				if (enemygid[0] == "event")
				{
					if (act.Length > 3 && act[3] == "1")
					{
						ElixirChara("ALL");
					}
					SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
					SharedData.Instance().b04BattleID = enemygid[1];
					SharedData.Instance().m_EventShow = true;
					LoadScene(act[1], isBattle: true);
					return;
				}
				if (enemygid[0] == "chara")
				{
					SharedData.Instance().PlayerSetting.Add("Player1", enemygid[2]);
					SharedData.Instance().b04BattleID = enemygid[1];
					SharedData.Instance().m_EventShow = true;
					LoadScene(act[1], isBattle: true);
					return;
				}
				if (enemygid[0] == "arena")
				{
					SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
					SharedData.Instance().b04BattleID = SharedData.Instance().m_ArenaFightID;
					SharedData.Instance().m_EventShow = true;
					LoadScene(act[1], isBattle: true);
					return;
				}
				if (enemygid[0] == "datianwang")
				{
					SharedData.Instance().b04BattleID = SharedData.Instance().m_ArenaFightID;
					LoadScene("BeforeBattle", isBattle: true);
					return;
				}
				if (enemygid[0] == "duel")
				{
					SharedData.Instance().DuelBattleGuild = enemygid[1];
					LoadScene("BeforeDuelBattle", isBattle: true);
					return;
				}
				if (act.Length > 4 && act[4] == "1")
				{
					ElixirChara("ALL");
				}
				if (enemygid.Length > 1 && "force".Equals(enemygid[1]))
				{
					SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
					SharedData.Instance().BattleMemberMax++;
					SharedData.Instance().isChooseBattle = false;
				}
				SharedData.Instance().b04BattleID = enemygid[0];
				LoadScene("BeforeBattle", isBattle: true);
			}
			else if (act[0] == "DESTROY")
			{
				if (act[1] == "THIS")
				{
					if (_event.obj != null)
					{
						if (m_HoldCamera == _event.obj)
						{
							PlayerTakeCamera();
						}
						if ("HOVER".Equals(_event.originevdata.trigger))
						{
							Vector3Int gridPosition = _event.obj.GetComponent<EventController>().GetGridPosition();
							if (obstacle.Contains(gridPosition))
							{
								Vector3Int vector3Int = gridPosition;
								MonoBehaviour.print("HOVER remove obstacle position(1.1): [" + vector3Int.ToString() + "]");
								obstacle.Remove(gridPosition);
							}
						}
						mapUnits.Remove(_event.obj.name);
						UnityEngine.Object.Destroy(_event.obj);
						_event.obj = null;
					}
				}
				else
				{
					string[] array5 = act[1].Split('&');
					foreach (string ids in array5)
					{
						Event eventById6 = GetEventById(ids);
						if (eventById6 == null || !(eventById6.obj != null))
						{
							continue;
						}
						if (m_HoldCamera == eventById6.obj)
						{
							PlayerTakeCamera();
						}
						if ("HOVER".Equals(eventById6.originevdata.trigger))
						{
							Vector3Int gridPosition2 = eventById6.obj.GetComponent<EventController>().GetGridPosition();
							if (obstacle.Contains(gridPosition2))
							{
								Vector3Int vector3Int = gridPosition2;
								MonoBehaviour.print("HOVER remove obstacle position(1.2): [" + vector3Int.ToString() + "]");
								obstacle.Remove(gridPosition2);
							}
						}
						mapUnits.Remove(eventById6.obj.name);
						UnityEngine.Object.Destroy(eventById6.obj);
						eventById6.obj = null;
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "HIDE")
			{
				if (act[1] == "PLAYER")
				{
					player.Hide();
				}
				else if (act[1] == "THIS")
				{
					if (_event.obj != null)
					{
						if (m_HoldCamera == _event.obj)
						{
							PlayerTakeCamera();
						}
						_event.obj.GetComponent<EventController>().Hide();
					}
				}
				else
				{
					Event eventById7 = GetEventById(act[1]);
					if (eventById7 != null && eventById7.obj != null)
					{
						if (m_HoldCamera == eventById7.obj)
						{
							PlayerTakeCamera();
						}
						eventById7.obj.GetComponent<EventController>().Hide();
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "SHOW")
			{
				if (act[1] == "PLAYER")
				{
					player.Show();
				}
				else if (act[1] == "THIS")
				{
					_event.obj.GetComponent<EventController>().Show();
				}
				else
				{
					Event eventById8 = GetEventById(act[1]);
					if (eventById8 != null && eventById8.obj != null)
					{
						eventById8.obj.GetComponent<EventController>().Show();
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "JOIN")
			{
				JoinTeam(act[1]);
				ElixirChara(act[1]);
				EventComplete(_event);
			}
			else if (act[0] == "SPECIALONLY")
			{
				SpecialJoinTeamProcess(act[1]);
				EventComplete(_event);
			}
			else if (act[0] == "SPECIALJOIN")
			{
				JoinTeam(act[1], isSpecial: true);
				ElixirChara(act[1]);
				EventComplete(_event);
			}
			else if (act[0] == "FOLLOW")
			{
				if (SharedData.Instance().FullTeam.Contains(act[1]) && SharedData.Instance().FollowList.Count < SharedData.Instance().FollowMaxCount && !SharedData.Instance().FollowList.Contains(act[1]))
				{
					SharedData.Instance().FollowList.Add(act[1]);
					GameDataManager.Instance().AddUnlockAtlasList(act[1], "b01");
					SharedData.Instance().player.InitFollows();
				}
				EventComplete(_event);
			}
			else if (act[0] == "UNFOLLOW")
			{
				if ("ALL".Equals(act[1]))
				{
					SharedData.Instance().FollowList.Clear();
					SharedData.Instance().player.InitFollows();
				}
				else if (SharedData.Instance().FollowList.Contains(act[1]))
				{
					SharedData.Instance().FollowList.Remove(act[1]);
					SharedData.Instance().player.InitFollows();
				}
				EventComplete(_event);
			}
			else if (act[0] == "GATHERFOLLOWER")
			{
				SharedData.Instance().player.GatherFollower();
				EventComplete(_event);
			}
			else if (act[0] == "LOSTMONEY")
			{
				float num22 = SharedData.Instance().m_Money;
				int num23 = 0;
				if ("HALF".Equals(act[1]))
				{
					num23 = Mathf.RoundToInt(num22 / 2f);
					SharedData.Instance().FlagList["ROB_MONEY"] = num23;
				}
				else if ("ONETENTH".Equals(act[1]))
				{
					num23 = Mathf.RoundToInt(num22 / 10f);
					SharedData.Instance().FlagList["ROB_MONEY"] = num23;
				}
				else if ("ALL".Equals(act[1]))
				{
					num23 = Mathf.RoundToInt(num22);
					SharedData.Instance().FlagList["ROB_MONEY"] = num23;
				}
				else if ("RETURN".Equals(act[1]))
				{
					num23 = -1 * SharedData.Instance().FlagList["ROB_MONEY"];
					SharedData.Instance().FlagList["ROB_MONEY"] = 0;
				}
				Debug.LogWarning("Lost money " + num23);
				SharedData.Instance().m_Money -= num23;
				if (num23 >= 0)
				{
					SharedData.Instance().m_TempParas["lostmoney"] = num23.ToString();
				}
				else
				{
					SharedData.Instance().m_TempParas["returnmoney"] = Mathf.Abs(num23).ToString();
				}
				EventComplete(_event);
			}
			else if (act[0] == "OPENLAYER")
			{
				SuperTileLayer superTileLayer = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>(includeInactive: true).FirstOrDefault((SuperTileLayer s) => s.name == act[1]);
				if (superTileLayer != null)
				{
					superTileLayer.gameObject.SetActive(value: true);
				}
				EventComplete(_event);
			}
			else if (act[0] == "CLOSELAYER")
			{
				SuperTileLayer superTileLayer2 = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>().FirstOrDefault((SuperTileLayer s) => s.name == act[1]);
				if (superTileLayer2 != null)
				{
					superTileLayer2.gameObject.SetActive(value: false);
				}
				EventComplete(_event);
			}
			else if (act[0] == "LEAVE")
			{
				bool reteamable = act.Length > 2 && "RETEAM".Equals(act[2]);
				if ("ALL".Equals(act[1]))
				{
					string[] array5 = SharedData.Instance().FullTeam.ToArray();
					foreach (string text11 in array5)
					{
						LeaveTeam(text11, reteamable);
						if (act.Length > 2 && "MEMO".Equals(act[2]))
						{
							string key = "GLOBAL_FLAGS_CHA_" + text11;
							SharedData.Instance().FlagList[key] = 2;
						}
					}
					SharedData.Instance().FollowList.Clear();
				}
				else
				{
					LeaveTeam(act[1], reteamable);
				}
				SharedData.Instance().player.InitFollows();
				EventComplete(_event);
			}
			else if (act[0] == "SELECT")
			{
				string ask = "null";
				if (act.Length > 2)
				{
					ask = act[2];
				}
				PlaySoundEffect("Talk", "0", null);
				if ("EQOPERATOR".Equals(act[1]))
				{
					string text12 = SharedData.Instance().playerid;
					foreach (string follow3 in SharedData.Instance().FollowList)
					{
						text12 = text12 + "&" + follow3;
					}
					m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, text12, 1);
				}
				else if ("WGOPERATOR".Equals(act[1]))
				{
					string text13 = SharedData.Instance().playerid;
					foreach (string follow4 in SharedData.Instance().FollowList)
					{
						text13 = text13 + "&" + follow4;
					}
					m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, text13, 2);
				}
				else if ("TEAMLIST".Equals(act[1]))
				{
					string text14 = SharedData.Instance().playerid;
					foreach (string follow5 in SharedData.Instance().FollowList)
					{
						text14 = text14 + "&" + follow5;
					}
					m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, text14, 3);
				}
				else
				{
					m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, act[1]);
				}
				m_Menu3.Close();
				EventComplete(_event);
			}
			else if (act[0] == "CHECKFINALLOVERS")
			{
				string text15 = _event.evdata.flag + "_" + CheckFinalLover();
				MonoBehaviour.print("CHECKFINALLOVERS 2 nextflag -> " + text15);
				SetNextFlag(text15, _event.evdata.trigger == "AUTO");
				EventComplete(_event);
			}
			else if (act[0] == "CHGROOT")
			{
				if (!act[1].Equals(SharedData.Instance().m_TempParas["has_trait"]))
				{
					bool flag6 = false;
					if ("10126".Equals(act[1]))
					{
						if (SharedData.Instance().PlayerPackage.ContainsKey("997") && SharedData.Instance().PlayerPackage["997"] >= 20)
						{
							SharedData.Instance().PlayerPackage["997"] -= 20;
							flag6 = true;
						}
					}
					else if (SharedData.Instance().PlayerPackage.ContainsKey("998") && SharedData.Instance().PlayerPackage["998"] >= 20)
					{
						SharedData.Instance().PlayerPackage["998"] -= 20;
						flag6 = true;
					}
					if (flag6)
					{
						player.charadata.RemoveTrait(SharedData.Instance().m_TempParas["has_trait"]);
						player.charadata.AddTraits(act[1]);
						gang_b06Table.Row row4 = CommonResourcesData.b06.Find_id(act[1]);
						if (row4 != null)
						{
							AddExploreList("INFO|" + string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Change_Roots"), row4.name_Trans));
						}
					}
					else
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Change_Roots_Poor"));
					}
				}
				else
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Change_Roots_duplicate"));
				}
				EventComplete(_event);
			}
			else if (act[0] == "SWITCH")
			{
				int num24 = 1;
				string[] array5 = act[1].Split('+');
				foreach (string text16 in array5)
				{
					if (text16.Contains(">"))
					{
						string[] array8 = text16.Split('>');
						float num25 = 0f;
						if (SharedData.Instance().PlayerPackage.ContainsKey(array8[0]))
						{
							num25 = SharedData.Instance().PlayerPackage[array8[0]];
						}
						float num26 = float.Parse(array8[1], CultureInfo.InvariantCulture);
						if (num25 > num26)
						{
							break;
						}
					}
					else if (text16.Contains("="))
					{
						string[] array9 = text16.Split('=');
						if ("BORNID".Equals(array9[0]) && array9[1].Equals(SharedData.Instance().BornID))
						{
							break;
						}
						if ("HASTRAIT".Equals(array9[0]) && SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_TraitList.Contains(array9[1]))
						{
							SharedData.Instance().m_TempParas["has_trait"] = array9[1];
							break;
						}
					}
					else
					{
						int num27 = 2;
						if (act.Length > 2)
						{
							num27 = int.Parse(act[2]);
						}
						if (SharedData.Instance().FlagList[text16] == num27)
						{
							break;
						}
					}
					num24++;
				}
				string text17 = _event.evdata.flag + "_" + num24;
				MonoBehaviour.print("SWITCH 2 nextflag -> " + text17);
				SetNextFlag(text17, _event.evdata.trigger == "AUTO");
				EventComplete(_event);
			}
			else if (act[0] == "CHECK")
			{
				bool num28 = DoAutoActionCheck(act);
				string flag7 = _event.evdata.flag;
				flag7 = ((!num28) ? (flag7 + "_FALSE") : (flag7 + "_TRUE"));
				MonoBehaviour.print("CHECK 2 nextflag -> " + flag7);
				SetNextFlag(flag7, _event.evdata.trigger == "AUTO");
				EventComplete(_event);
			}
			else if (act[0] == "PLAYANI")
			{
				bool flag8 = false;
				if (act.Length > 4)
				{
					flag8 = "LOOP".Equals(act[4]);
				}
				float timescale2 = 1f;
				if (act.Length > 5)
				{
					timescale2 = float.Parse(act[5], CultureInfo.InvariantCulture);
				}
				if (act[1] == "THIS")
				{
					_event.obj.GetComponent<EventController>().m_KeepAnimation = false;
					_event.obj.GetComponent<EventController>().PlayAnimation(act[2], loop: true, compensate: false, timescale2);
					_event.obj.GetComponent<EventController>().m_IsLoop = flag8;
					if (act[3] != "0")
					{
						_event.obj.GetComponent<EventController>().Idle(act[3]);
					}
				}
				else if (act[1] == "PLAYER")
				{
					player.m_KeepAnimation = false;
					player.PlayAnimation(act[2], loop: true, compensate: false, timescale2);
					player.m_IsLoop = flag8;
					if (act[3] != "0")
					{
						player.Idle(act[3]);
					}
				}
				if (!flag8)
				{
					EventComplete(_event);
				}
			}
			else if (act[0] == "CAMCTRL")
			{
				if (act[1] == "THIS")
				{
					EventTakeCamera(_event);
				}
				else if (act[1] == "PLAYER")
				{
					PlayerTakeCamera();
				}
				else
				{
					Event eventById9 = GetEventById(act[1]);
					if (eventById9 != null)
					{
						EventTakeCamera(eventById9);
					}
					else
					{
						Debug.LogWarning("Can NOT find eventid[" + act[1] + "]");
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "SHOP")
			{
				SharedData.Instance().OpenShopID = act[1];
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Shop);
				EventComplete(_event);
			}
			else if (act[0] == "PACKMULTI")
			{
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				LoadSceneAdditive("Inheritance");
				EventComplete(_event);
			}
			else if (act[0] == "CREATEWUGONG")
			{
				CreateWGController.enhanceWuGongType = EnhanceWuGongType.Create;
				LoadSceneAdditive("CreateWG");
				EventComplete(_event);
			}
			else if (act[0] == "BREAKWUGONG")
			{
				CreateWGController.enhanceWuGongType = EnhanceWuGongType.Break;
				LoadSceneAdditive("EvolutionWG");
				EventComplete(_event);
			}
			else if (act[0] == "ENHANCEEQ")
			{
				EvolutionEqNewController.EnhanceEquipmentType = EnhanceType.Enhance;
				if (act.Length > 1)
				{
					EvolutionEqNewController.EnhanceAnvilLevel = int.Parse(act[1]);
				}
				else
				{
					EvolutionEqNewController.EnhanceAnvilLevel = 0;
				}
				LoadSceneAdditive("EvolutionEQ");
				EventComplete(_event);
			}
			else if (act[0] == "RESETEQ")
			{
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				EvolutionEqNewController.EnhanceEquipmentType = EnhanceType.Reset;
				LoadSceneAdditive("EvolutionEQ");
				EventComplete(_event);
			}
			else if (act[0] == "LOAN")
			{
				SharedData.Instance().OpenShopID = act[1];
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Loan);
				EventComplete(_event);
			}
			else if (act[0] == "REDEEM")
			{
				SharedData.Instance().OpenShopID = act[1];
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Redeem);
				EventComplete(_event);
			}
			else if (act[0] == "APPRECIATION")
			{
				SharedData.Instance().OpenShopID = act[1];
				SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Appreciation, "00000000001");
				EventComplete(_event);
			}
			else if (act[0] == "TOMB")
			{
				gang_e03Table.Row row5 = CommonResourcesData.e03.Find_id(act[1]);
				string[] array10 = row5.pos.Split('|');
				Vector3Int vector3Int2 = new Vector3Int(int.Parse(array10[0]), int.Parse(array10[1]), 0);
				if (SharedData.Instance().SceneBefore.Equals(row5.prescene) && vector3Int2.Equals(SharedData.Instance().MapUnitsBefore[player.name]))
				{
					AddChatList(player.charadata.Indexs_Name["Name"].stringValue, row5.horimono);
				}
				else
				{
					AddChatList(player.charadata.Indexs_Name["Name"].stringValue, CommonFunc.I18nGetLocalizedValue("I18N_WildernessNothing"));
				}
				m_Canvas_Event = _event;
			}
			else if (act[0] == "FACETOPLAYER")
			{
				_event.obj.GetComponent<EventController>().FaceToPlayer(_event: true);
				EventComplete(_event);
			}
			else if (act[0] == "SETSKIN")
			{
				string[] array11 = act[2].Split('&');
				if (act[1] == "PLAYER")
				{
					player.charadata.m_DefaultPrefab = player.charadata.m_Prefab;
					player.charadata.m_DefaultBattleIcon = player.charadata.m_BattleIcon;
					player.charadata.m_Prefab = array11[0];
					player.charadata.m_BattleIcon = array11[1];
				}
				else if (act[1] == "TEAM")
				{
					if ("DEFAULT".Equals(array11[0]))
					{
						player.charadata.m_Prefab = player.charadata.m_DefaultPrefab;
						player.charadata.m_BattleIcon = player.charadata.m_DefaultBattleIcon;
						foreach (string follow6 in SharedData.Instance().FollowList)
						{
							if (!"1186".Equals(follow6))
							{
								CharaData charaData7 = SharedData.Instance().GetCharaData(follow6);
								if (charaData7 != null)
								{
									charaData7.m_Prefab = charaData7.m_DefaultPrefab;
									charaData7.m_BattleIcon = charaData7.m_DefaultBattleIcon;
								}
								else
								{
									Debug.LogWarning("[DEFAULT] Can NOT find follow charaid[" + act[1] + "]");
								}
							}
						}
					}
					else
					{
						player.charadata.m_DefaultPrefab = player.charadata.m_Prefab;
						player.charadata.m_DefaultBattleIcon = player.charadata.m_BattleIcon;
						player.charadata.m_Prefab = array11[0];
						player.charadata.m_BattleIcon = array11[1];
						foreach (string follow7 in SharedData.Instance().FollowList)
						{
							if (!"1186".Equals(follow7))
							{
								CharaData charaData8 = SharedData.Instance().GetCharaData(follow7);
								if (charaData8 != null)
								{
									charaData8.m_DefaultPrefab = charaData8.m_Prefab;
									charaData8.m_DefaultBattleIcon = charaData8.m_BattleIcon;
									charaData8.m_Prefab = array11[0];
									charaData8.m_BattleIcon = array11[1];
								}
								else
								{
									Debug.LogWarning("Can NOT find follow charaid[" + act[1] + "]");
								}
							}
						}
					}
				}
				else
				{
					CharaData charaData9 = SharedData.Instance().GetCharaData(act[1]);
					if (charaData9 != null)
					{
						charaData9.m_DefaultPrefab = charaData9.m_Prefab;
						charaData9.m_DefaultBattleIcon = charaData9.m_BattleIcon;
						charaData9.m_Prefab = array11[0];
						charaData9.m_BattleIcon = array11[1];
					}
					else
					{
						Debug.LogWarning("Can NOT find charaid[" + act[1] + "]");
					}
				}
				EventComplete(_event);
			}
			else if (act[0] == "AbolishKungfu")
			{
				AbolishKungfu(SharedData.Instance().CurrentChara);
				SharedData.Instance().m_TempParas["operateflag"] = _event.evdata.flag;
				EventComplete(_event);
			}
			else if (act[0] == "PlayerForgetSkill")
			{
				PlayerForgetSkill(act[1], _special: true);
				EventComplete(_event);
			}
			else if (act[0] == "PlayerWashUp")
			{
				PlayerWashUp();
				EventComplete(_event);
			}
			else if (act[0] == "FACTION")
			{
				if (act.Length > 3)
				{
					DoFaction(act[1], act[2], act[3]);
				}
				EventComplete(_event);
			}
			else if (act[0] == "SECTPANEL")
			{
				if (act.Length >= 2)
				{
					SharedData.Instance().sectPanelID = act[1];
					UnityEngine.Object.Instantiate(Resources.Load("Prefabs/NewUI/SectCanvas/SectCanvas") as GameObject);
				}
				EventComplete(_event);
			}
			else if (act[0] == "UNLOCKATLAS" && act.Length >= 3)
			{
				GameDataManager.Instance().AddUnlockAtlasList(act[2], act[1]);
			}
		}
		else
		{
			EventComplete(_event);
			if (InitOK && !"AUTO".Equals(_event.evdata.trigger) && !"".Equals(_event.evdata.nextflag))
			{
				UpdateEvents(1);
			}
		}
	}

	private string CheckFinalLover()
	{
		List<CharaData> list = new List<CharaData>();
		List<CharaData> list2 = new List<CharaData>();
		SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		Dictionary<string, int> dictionary = new Dictionary<string, int>
		{
			{ "2030", 5 },
			{ "206", 4 },
			{ "606", 3 },
			{ "H1029", 2 },
			{ "1108", 1 },
			{ "1186", 0 }
		};
		foreach (string key in dictionary.Keys)
		{
			if (!SharedData.Instance().FullTeam.Contains(key))
			{
				continue;
			}
			if (key == "206")
			{
				if (SharedData.Instance().FlagList["GLOBAL_FLAGS_MUWANFENG_LOVE"] != 2)
				{
					continue;
				}
			}
			else if (key == "606" && SharedData.Instance().FlagList["GLOBAL_FLAGS_YEXIYI_LOVE"] != 2)
			{
				continue;
			}
			list2.Add(SharedData.Instance().GetCharaData(key));
			Debug.LogWarning("Round 0 winnerPool: " + key);
		}
		if (list2.Count == 0)
		{
			return "NONE";
		}
		list.AddRange(list2);
		list2.Clear();
		foreach (CharaData item in list)
		{
			if (item.m_Level >= 80)
			{
				list2.Add(item);
				Debug.LogWarning("Round 1 winnerPool: " + item.m_Id);
			}
		}
		if (list2.Count == 0)
		{
			return "NONE";
		}
		if (list2.Count == 1)
		{
			return list2[0].m_Id;
		}
		list.Clear();
		list.AddRange(list2);
		list2.Clear();
		for (int i = 0; i < list.Count; i++)
		{
			for (int j = i + 1; j < list.Count; j++)
			{
				if (list[j].m_Level > list[i].m_Level)
				{
					int index = j;
					List<CharaData> list3 = list;
					int index2 = i;
					CharaData charaData = list[i];
					CharaData charaData2 = list[j];
					CharaData charaData4 = (list[index] = charaData);
					charaData4 = (list3[index2] = charaData2);
				}
			}
		}
		int level = list[0].m_Level;
		foreach (CharaData item2 in list)
		{
			if (item2.m_Level == level)
			{
				list2.Add(item2);
				Debug.LogWarning("Round 2 winnerPool: " + item2.m_Id);
			}
		}
		if (list2.Count == 1)
		{
			return list2[0].m_Id;
		}
		list.Clear();
		list.AddRange(list2);
		list2.Clear();
		for (int k = 0; k < list.Count; k++)
		{
			for (int l = k + 1; l < list.Count; l++)
			{
				if (list[l].m_KongFuList.Count > list[k].m_KongFuList.Count)
				{
					int index2 = l;
					List<CharaData> list3 = list;
					int index = k;
					CharaData charaData2 = list[k];
					CharaData charaData = list[l];
					CharaData charaData4 = (list[index2] = charaData2);
					charaData4 = (list3[index] = charaData);
				}
			}
		}
		level = list[0].m_Level;
		foreach (CharaData item3 in list)
		{
			if (item3.m_Level == level)
			{
				list2.Add(item3);
				Debug.LogWarning("Round 3 winnerPool: " + item3.m_Id);
			}
		}
		if (list2.Count == 1)
		{
			return list2[0].m_Id;
		}
		list.Clear();
		list.AddRange(list2);
		for (int m = 0; m < list.Count; m++)
		{
			for (int n = m + 1; n < list.Count; n++)
			{
				if (dictionary[list[n].m_Id] > dictionary[list[m].m_Id])
				{
					int index = n;
					List<CharaData> list3 = list;
					int index2 = m;
					CharaData charaData = list[m];
					CharaData charaData2 = list[n];
					CharaData charaData4 = (list[index] = charaData);
					charaData4 = (list3[index2] = charaData2);
				}
			}
		}
		return list[0].m_Id;
	}

	private void EventTakeCamera(Event _event, bool _init = false)
	{
		if (!(m_HoldCamera == _event.obj))
		{
			player.camera_control = false;
			_event.obj.GetComponent<EventController>().TakeCamera(_init);
			if (m_HoldCamera != null)
			{
				m_HoldCamera.GetComponent<EventController>().camera_control = false;
			}
			m_HoldCamera = _event.obj;
		}
	}

	public void PlayerTakeCamera()
	{
		if (!(m_HoldCamera == null))
		{
			player.TakeCamera();
			m_LastClickCamera = 1;
			m_HoldCamera.GetComponent<EventController>().camera_control = false;
			m_HoldCamera = null;
		}
	}

	public void LoadScene(string _scenename, bool isBattle = false)
	{
		if (isBattle)
		{
			EnterBattleAnimation(_scenename);
			return;
		}
		SharedData.Instance().SpawnMapName = "";
		m_LoadingScene = true;
		m_Menu3.Close();
		if (_scenename == "BeforeBattle" && SharedData.Instance().isChooseBattle)
		{
			bool flag = false;
			foreach (string lastSelectBattleId in SharedData.Instance().lastSelectBattleIdList)
			{
				if (SharedData.Instance().FollowList.Contains(lastSelectBattleId))
				{
					flag = true;
					break;
				}
			}
			if (SharedData.Instance().lastSelectBattleIdList.Contains(SharedData.Instance().playerid))
			{
				flag = true;
			}
			if (flag)
			{
				BeforeBattleController.OnButtonClickChooseOK(SharedData.Instance().lastSelectBattleIdList);
				return;
			}
		}
		if (transition != null)
		{
			StartCoroutine(LoadLevel(_scenename));
		}
		else
		{
			SharedData.Instance().ASyncLoadScene(_scenename);
		}
	}

	private IEnumerator LoadLevel(string _scenename)
	{
		transition.SetTrigger("Start");
		yield return new WaitForSeconds(0.5f);
		SharedData.Instance().ASyncLoadScene(_scenename);
	}

	public void LoadSceneAdditive(string _scenename)
	{
		m_Menu3.Close();
		SharedData.Instance().LoadSceneStackAdd(_scenename);
		SceneManager.LoadScene(_scenename, LoadSceneMode.Additive);
	}

	private void SetNextFlag(string _nextflag, bool _auto)
	{
		string[] array = _nextflag.Split('|');
		int num = 0;
		if (_auto)
		{
			string[] array2 = array;
			foreach (string text in array2)
			{
				if (SharedData.Instance().FlagList.ContainsKey(text))
				{
					if (SharedData.Instance().FlagList[text] == 0)
					{
						MonoBehaviour.print("[AUTO] Open flag: " + text);
						SharedData.Instance().FlagList[text] = 1;
						UpdateEventByFlag(text);
					}
					num++;
				}
			}
		}
		else
		{
			string[] array2 = array;
			foreach (string key in array2)
			{
				if (SharedData.Instance().FlagList.ContainsKey(key))
				{
					SharedData.Instance().FlagList[key] = 1;
					num++;
				}
			}
		}
		if (num == 0)
		{
			Debug.LogWarning("Flags *NOT* found in FlagList, input --> [" + _nextflag + "]");
		}
	}

	private void InitPortal()
	{
		SuperObject[] byType = getByType("Portal");
		foreach (SuperObject superObject in byType)
		{
			SuperCustomProperties component = superObject.GetComponent<SuperCustomProperties>();
			Portal portal = new Portal
			{
				name = superObject.name,
				position = tilemap.WorldToCell(superObject.transform.position)
			};
			foreach (CustomProperty property in component.m_Properties)
			{
				if (property.m_Name == "teleport")
				{
					portal.teleport = property.m_Value;
				}
				if (property.m_Name == "hidden")
				{
					portal.hidden = int.Parse(property.m_Value);
				}
			}
			portals.TryAdd(superObject.name, portal);
		}
	}

	private void InitPlayer(string spawn_name)
	{
		int num = 0;
		if (SharedData.Instance().BackFromOtherScene)
		{
			MonoBehaviour.print("InitPlayer BackFromOtherScene.");
		}
		else
		{
			MonoBehaviour.print("InitPlayer spawn_name: " + spawn_name);
			SuperObject[] byName = getByName(spawn_name);
			if (byName.Length != 0)
			{
				foreach (CustomProperty property in byName[0].GetComponent<SuperCustomProperties>().m_Properties)
				{
					if (property.m_Name == "direction")
					{
						num = int.Parse(property.m_Value);
					}
				}
			}
			else
			{
				num = SharedData.Instance().Mark_Direction;
			}
		}
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		player = SkinCharacter.InitSkinCharacter(charaData).AddComponent<OhPlayerController>();
		AllCharacterObjs.Add(SharedData.Instance().playerid, player.gameObject);
		player.BackFromOtherScene = SharedData.Instance().BackFromOtherScene;
		player.name = charaData.m_Prefab;
		player.Init(SharedData.Instance().BackFromOtherScene ? "" : spawn_name);
		player.joyStickController = m_JoyStick.GetComponentInChildren<JoyStickController>();
		if (SharedData.Instance().BackFromOtherScene)
		{
			player.Face(SharedData.Instance().playerdirection, isInit: true);
		}
		else
		{
			switch (num)
			{
			case 0:
				player.Face(Direction.Down, isInit: true);
				break;
			case 1:
				player.Face(Direction.Left, isInit: true);
				break;
			case 2:
				player.Face(Direction.Up, isInit: true);
				break;
			case 3:
				player.Face(Direction.Right, isInit: true);
				break;
			}
		}
		if ("Hide".Equals(SharedData.Instance().SpawnStatus))
		{
			player.Hide();
		}
		SharedData.Instance().player = player;
		player.PlayAnimation("A01-stand");
	}

	private void SetOverheadCamera()
	{
		m_camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
		m_camera.transparencySortMode = TransparencySortMode.CustomAxis;
		m_camera.transparencySortAxis = Vector3.up;
		m_CameraTarget = new Vector3((float)map.m_Width / 2f * (float)map.m_TileWidth, (float)(-map.m_Height) / 2f * (float)map.m_TileHeight, -10f);
		m_camera.transform.position = m_CameraTarget;
	}

	private void PointerCheck()
	{
		if (SharedData.Instance().LoadedSceneStack.Count > 0 || EventSystem.current.IsPointerOverGameObject())
		{
			return;
		}
		if (IsChating())
		{
			Cursor.SetCursor(m_Select_Pointer, Vector2.one, CursorMode.ForceSoftware);
			return;
		}
		Vector3Int vector3Int = tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
		Vector3Int vector3Int2 = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (vector3Int2.Equals(m_PrePointer))
		{
			return;
		}
		m_PrePointer = vector3Int2;
		Texture2D texture = null;
		if (CanWalk(vector3Int2))
		{
			texture = m_Walk_Pointer;
		}
		foreach (Event value in events.Values)
		{
			if (value.obj == null || SharedData.Instance().FlagList[value.evdata.flag] != 1 || value.evdata.trigger != "CLICK")
			{
				continue;
			}
			EventController component = value.obj.GetComponent<EventController>();
			if (!vector3Int2.Equals(component.GetGridPosition()))
			{
				continue;
			}
			if (value.evdata.menu != "0")
			{
				texture = m_Talk_Pointer;
				break;
			}
			string[] array = value.evdata.action.Split('|');
			if (array[0] == "GET")
			{
				texture = m_Loot_Pointer;
			}
			else if (array[0] == "CHAT")
			{
				texture = m_Talk_Pointer;
			}
			else if (array[0] == "WANTED")
			{
				texture = m_Wanted_Pointer;
			}
			else if (array[0] == "CHECK")
			{
				texture = m_Talk_Pointer;
			}
			else if (array[0] == "SELECT")
			{
				texture = m_Talk_Pointer;
			}
			else if (value.obj.transform.Find("head_icon/talk/Ani") != null)
			{
				texture = m_Talk_Pointer;
			}
			break;
		}
		Cursor.SetCursor(texture, Vector2.one, CursorMode.Auto);
	}

	private bool PlayerForgetSkill(string _skill_id, bool _special = false)
	{
		if (player.charadata.m_Training_Id.Equals(_skill_id))
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_Relate_Wugong_id(player.charadata.m_Training_Id);
			SharedData.Instance().PackageAdd(row.ID, 1);
			player.charadata.m_Training_Id = "0";
		}
		KongFuData kongFuData = null;
		List<string> list = new List<string>();
		if (_special)
		{
			list.Add("Sword");
			list.Add("Knife");
			list.Add("Stick");
			list.Add("Hand");
			list.Add("Finger");
			list.Add("Special");
			list.Add("YinYang");
			list.Add("Melody");
			list.Add("Medical");
			list.Add("Darts");
			list.Add("Wineart");
			list.Add("Steal");
		}
		foreach (KongFuData kongFu in player.charadata.m_KongFuList)
		{
			if (!kongFu.kf.ID.Equals(_skill_id))
			{
				continue;
			}
			Dictionary<string, float> dictionary = new Dictionary<string, float>();
			if (kongFu.kf.Paraplus1 != "0")
			{
				string[] array = kongFu.kf.Paraplus1.Split('|');
				if (!list.Contains(array[0]))
				{
					dictionary.Add(array[0], float.Parse(array[1], CultureInfo.InvariantCulture));
				}
			}
			if (kongFu.kf.Paraplus2 != "0")
			{
				string[] array2 = kongFu.kf.Paraplus2.Split('|');
				if (!list.Contains(array2[0]))
				{
					dictionary.Add(array2[0], float.Parse(array2[1], CultureInfo.InvariantCulture));
				}
			}
			if (kongFu.kf.Paraplus3 != "0")
			{
				string[] array3 = kongFu.kf.Paraplus3.Split('|');
				if (!list.Contains(array3[0]))
				{
					dictionary.Add(array3[0], float.Parse(array3[1], CultureInfo.InvariantCulture));
				}
			}
			if (kongFu.kf.Paraplus4 != "0")
			{
				string[] array4 = kongFu.kf.Paraplus4.Split('|');
				if (!list.Contains(array4[0]))
				{
					dictionary.Add(array4[0], float.Parse(array4[1], CultureInfo.InvariantCulture));
				}
			}
			_ = kongFu.lv;
			kongFuData = kongFu;
			kongFuData.lv = 1;
			kongFuData.newlv = 0;
			kongFuData.exp = 0f;
			kongFuData.proficiency = 0;
			break;
		}
		if (kongFuData != null)
		{
			player.charadata.KongFuListRemove(kongFuData);
			gang_b03Table.Row row2 = CommonResourcesData.b03.Find_ID(_skill_id);
			SharedData.Instance().m_TempParas["forgotwugong"] = row2.Name_Trans;
			return true;
		}
		SharedData.Instance().m_TempParas["forgotwugong"] = CommonFunc.ShortLangSel("XXXX", "XXXX", "XXXX");
		return false;
	}

	private void PlayerWashUp()
	{
		StatsAndAchievements.Instance().UnlockAchievement("1036");
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().CurrentChara);
		int num = 0;
		foreach (string item in new List<string> { "STR", "AGI", "BON", "WIL", "LER", "MOR" })
		{
			int num2 = (int)(charaData.Indexs_Name[item].rollValue + charaData.Indexs_Name[item].levelupValue);
			_ = charaData.Indexs_Name[item].basicValue;
			for (int i = 1; (float)i <= charaData.Indexs_Name[item].talentValue; i++)
			{
				float num3 = num2 + i;
				if (num3 > 20f)
				{
					num += 3;
				}
				else if (num3 > 10f)
				{
					num += 2;
				}
				else if (num3 > 0f)
				{
					num++;
				}
			}
		}
		if (num > charaData.totalTalentCost)
		{
			charaData.m_Talent += num;
		}
		else
		{
			charaData.m_Talent += charaData.totalTalentCost;
		}
		charaData.totalTalentCost = 0;
		PlayerAttrReset("STR");
		PlayerAttrReset("AGI");
		PlayerAttrReset("BON");
		PlayerAttrReset("WIL");
		PlayerAttrReset("LER");
	}

	private void PlayerAttrReset(string _attr)
	{
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().CurrentChara);
		int num = (int)charaData.Indexs_Name[_attr].talentValue;
		switch (_attr)
		{
		case "STR":
			charaData.Indexs_Name["ATK"].bornValue -= 5f * (float)num;
			charaData.Indexs_Name["DEF"].bornValue -= 5f * (float)num;
			charaData.Indexs_Name["ATK"].rollValue = charaData.Indexs_Name["ATK"].bornValue;
			charaData.Indexs_Name["DEF"].rollValue = charaData.Indexs_Name["DEF"].bornValue;
			break;
		case "AGI":
			charaData.Indexs_Name["SP"].bornValue -= 5f * (float)num;
			charaData.Indexs_Name["SP"].rollValue = charaData.Indexs_Name["SP"].bornValue;
			break;
		case "BON":
			charaData.Indexs_Name["HP"].bornValue -= 25f * (float)num;
			charaData.Indexs_Name["HP"].rollValue = charaData.Indexs_Name["HP"].bornValue;
			charaData.m_Hp -= 25f * (float)num;
			if (charaData.m_Hp < 0f)
			{
				charaData.m_Hp = 0f;
			}
			break;
		case "WIL":
			charaData.Indexs_Name["MP"].bornValue -= 25f * (float)num;
			charaData.Indexs_Name["MP"].rollValue = charaData.Indexs_Name["MP"].bornValue;
			charaData.m_Mp -= 25f * (float)num;
			if (charaData.m_Mp < 0f)
			{
				charaData.m_Mp = 0f;
			}
			break;
		}
		charaData.Indexs_Name[_attr].talentValue = 0f;
		if (charaData.Indexs_Name[_attr].talentValue < 0f)
		{
			charaData.Indexs_Name[_attr].talentValue = 0f;
		}
	}

	private void InteractiveGrassCharacterEffect()
	{
		m_InteractiveGrassPoslist.Clear();
		m_InteractiveGrassPoslist.Add(SharedData.Instance().player.transform.position);
		foreach (FollowController follow in SharedData.Instance().player.m_Follows)
		{
			bool flag = true;
			foreach (Vector4 item in m_InteractiveGrassPoslist)
			{
				if (Vector3.Distance(item, follow.transform.position) < 20f)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				m_InteractiveGrassPoslist.Add(follow.transform.position);
			}
		}
		while (m_InteractiveGrassPoslist.Count < 6)
		{
			m_InteractiveGrassPoslist.Add(Vector3.zero);
		}
		m_InteractiveGrassPoslist.Reverse();
		m_InteractiveGrass.material.SetVectorArray("_InteractivePositions", m_InteractiveGrassPoslist);
		m_InteractiveGrass.material.SetInt("_InteractiveCount", m_InteractiveGrassPoslist.Count);
	}

	private void InteractiveGrassTraceEffect()
	{
		m_InteractiveGrassTracePoslist.Clear();
		if (SharedData.Instance().isEnableTrace)
		{
			GameObject gameObject = null;
			gameObject = ((SharedData.Instance().player.m_Follows.Count != 0) ? SharedData.Instance().player.m_Follows[SharedData.Instance().player.m_Follows.Count - 1].gameObject : SharedData.Instance().player.gameObject);
			recordTraceTimer += Time.deltaTime;
			fadeTraceTimer += Time.deltaTime;
			if (recordTraceTimer > SharedData.Instance().m_TraceSamplingInterval)
			{
				if (traceList.Count == 0)
				{
					traceList.Add(gameObject.transform.position);
				}
				else if (Vector3.Distance(traceList[traceList.Count - 1], gameObject.transform.position) > 2f)
				{
					traceList.Add(gameObject.transform.position);
				}
				recordTraceTimer = 0f;
			}
			if (fadeTraceTimer > SharedData.Instance().m_Trace_Fade && traceList.Count > 1)
			{
				traceList.RemoveAt(0);
				fadeTraceTimer = 0f;
			}
			if (traceList.Count > SharedData.Instance().m_Trace_Length)
			{
				traceList.RemoveRange(0, traceList.Count - SharedData.Instance().m_Trace_Length);
			}
			for (int num = traceList.Count - 1; num >= 0; num--)
			{
				m_InteractiveGrassTracePoslist.Add(traceList[num]);
			}
		}
		int num2 = 200;
		while (m_InteractiveGrassTracePoslist.Count < num2)
		{
			m_InteractiveGrassTracePoslist.Add(Vector3.zero);
		}
		m_InteractiveGrass.material.SetVectorArray("_TracePositions", m_InteractiveGrassTracePoslist);
		m_InteractiveGrass.material.SetInt("_TraceCount", m_InteractiveGrassTracePoslist.Count);
	}

	private void InteractiveGrassChangeSortingEffect()
	{
		SkeletonAnimation[] animations;
		if (SharedData.Instance().isChangeSortingLayer && (SharedData.Instance().player.m_State == State.AStarMoving || SharedData.Instance().player.m_State == State.InputMoving))
		{
			animations = SharedData.Instance().player.m_Animations;
			for (int i = 0; i < animations.Length; i++)
			{
				animations[i].GetComponent<SortingGroup>().sortingOrder = SharedData.Instance().m_PlayerSortingIrder + 1;
			}
			{
				foreach (FollowController follow in SharedData.Instance().player.m_Follows)
				{
					animations = follow.m_Animations;
					for (int i = 0; i < animations.Length; i++)
					{
						animations[i].GetComponent<SortingGroup>().sortingOrder = SharedData.Instance().m_PlayerSortingIrder + 1;
					}
				}
				return;
			}
		}
		if (SharedData.Instance().player.m_Animations[0].GetComponent<SortingGroup>().sortingOrder == SharedData.Instance().m_PlayerSortingIrder)
		{
			return;
		}
		animations = SharedData.Instance().player.m_Animations;
		for (int i = 0; i < animations.Length; i++)
		{
			animations[i].GetComponent<SortingGroup>().sortingOrder = SharedData.Instance().m_PlayerSortingIrder;
		}
		foreach (FollowController follow2 in SharedData.Instance().player.m_Follows)
		{
			animations = follow2.m_Animations;
			for (int i = 0; i < animations.Length; i++)
			{
				animations[i].GetComponent<SortingGroup>().sortingOrder = SharedData.Instance().m_PlayerSortingIrder;
			}
		}
	}

	private void InteractiveGrassChangeAlphaEffect()
	{
		if (!SharedData.Instance().isChangeAlpha)
		{
			return;
		}
		foreach (SpriteRenderer interactiveGrassObj in m_InteractiveGrassObjList)
		{
			float num = float.MaxValue;
			foreach (Vector4 item in m_InteractiveGrassPoslist)
			{
				float num2 = Vector3.Distance(item, interactiveGrassObj.transform.position - Vector3.down * 25f);
				if (num2 < num)
				{
					num = num2;
				}
			}
			if (num < SharedData.Instance().m_Alpha_Dis && (SharedData.Instance().player.m_State == State.AStarMoving || SharedData.Instance().player.m_State == State.InputMoving))
			{
				if (SharedData.Instance().isChangeAlpha)
				{
					interactiveGrassObj.color = Color.Lerp(interactiveGrassObj.color, new Color(1f, 1f, 1f, SharedData.Instance().m_Alpha_Value), Mathf.PingPong(Time.time, SharedData.Instance().m_Alpha_Speed));
				}
			}
			else if (SharedData.Instance().isChangeAlpha)
			{
				interactiveGrassObj.color = Color.Lerp(interactiveGrassObj.color, Color.white, Mathf.PingPong(Time.time, SharedData.Instance().m_Alpha_Speed));
			}
		}
	}

	public void UpdateInteractiveGrass()
	{
		if (!(InteractiveGrassLayer == null) && !(SharedData.Instance().player == null))
		{
			InteractiveGrassCharacterEffect();
			InteractiveGrassTraceEffect();
			InteractiveGrassChangeSortingEffect();
			InteractiveGrassChangeAlphaEffect();
			m_InteractiveGrass.material.SetFloat("_WaveSpeed", SharedData.Instance().m_WaveSpeed);
			m_InteractiveGrass.material.SetFloat("_WaveScale", SharedData.Instance().m_WaveScale);
			m_InteractiveGrass.material.SetFloat("_SwingAmplitude", SharedData.Instance().m_SwingAmplitude);
			m_InteractiveGrass.material.SetFloat("_SwingFrequency", SharedData.Instance().m_SwingFrequency);
			m_InteractiveGrass.material.SetFloat("_DistanceFade", SharedData.Instance().m_InteractiveDistanceFade);
			m_InteractiveGrass.material.SetFloat("_MaxInteracticeOffset", SharedData.Instance().m_InteractiveMaxInteracticeOffset);
			m_InteractiveGrass.material.SetFloat("_MaxInteracticeShort", SharedData.Instance().m_InteractiveMaxInteracticeShort);
			m_InteractiveGrass.material.SetFloat("_TraceDistanceFade", SharedData.Instance().m_TraceDistanceFade);
			m_InteractiveGrass.material.SetFloat("_TraceMaxInteracticeOffset", SharedData.Instance().m_TraceMaxInteracticeOffset);
			m_InteractiveGrass.material.SetFloat("_TraceMaxInteracticeShort", SharedData.Instance().m_TraceMaxInteracticeShort);
		}
	}

	private void LateUpdate()
	{
		if (!InitOK || IsTeleport || isEnterBattleAnimPlaying)
		{
			return;
		}
		UpdateInteractiveGrass();
		PointerCheck();
		if (m_LastClickCamera == 1)
		{
			m_LastClickCameraPos = m_CameraTarget;
			m_LastClickCamera = 2;
			m_camera.transform.position = new Vector3(Mathf.SmoothDamp(m_camera.transform.position.x, m_LastClickCameraPos.x, ref velocity.x, speed), Mathf.SmoothDamp(m_camera.transform.position.y, m_LastClickCameraPos.y, ref velocity.y, speed), Mathf.SmoothDamp(m_camera.transform.position.z, m_LastClickCameraPos.z, ref velocity.z, speed));
			if (Vector3.Distance(m_camera.transform.position, m_LastClickCameraPos) <= 5f)
			{
				m_LastClickCameraPos = Vector3.zero;
				m_LastClickCamera = 0;
			}
		}
		else if (m_LastClickCamera == 2)
		{
			m_camera.transform.position = new Vector3(Mathf.SmoothDamp(m_camera.transform.position.x, m_LastClickCameraPos.x, ref velocity.x, speed), Mathf.SmoothDamp(m_camera.transform.position.y, m_LastClickCameraPos.y, ref velocity.y, speed), Mathf.SmoothDamp(m_camera.transform.position.z, m_LastClickCameraPos.z, ref velocity.z, speed));
			if (Vector3.Distance(m_camera.transform.position, m_LastClickCameraPos) <= 5f)
			{
				m_LastClickCameraPos = Vector3.zero;
				m_LastClickCamera = 0;
			}
		}
		else
		{
			if (!IsChating() && !m_ScenePlaying && m_Menu3.IsOpen())
			{
				PlayerTakeCamera();
			}
			m_camera.transform.position = new Vector3(Mathf.SmoothDamp(m_camera.transform.position.x, m_CameraTarget.x, ref velocity.x, speed), Mathf.SmoothDamp(m_camera.transform.position.y, m_CameraTarget.y, ref velocity.y, speed), Mathf.SmoothDamp(m_camera.transform.position.z, m_CameraTarget.z, ref velocity.z, speed));
		}
	}

	private bool CheckFlag(string _flagid, int _value)
	{
		if (SharedData.Instance().FlagList.ContainsKey(_flagid))
		{
			return SharedData.Instance().FlagList[_flagid] == _value;
		}
		return false;
	}

	private string CheckEventRunningFlag(string _eventid)
	{
		string text = "Null";
		foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[_eventid])
		{
			if (SharedData.Instance().FlagList[item.flag] == 1)
			{
				text = item.flag;
				break;
			}
		}
		Debug.LogFormat("Event[{0}] is running Flag[{1}].", _eventid, text);
		return text;
	}

	private void CloseEvent(string _eventid)
	{
		string[] array = _eventid.Split('&');
		foreach (string text in array)
		{
			if (SharedData.Instance().EventTable.ContainsKey(text))
			{
				Debug.Log("CloseEvent: " + text);
				foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[text])
				{
					SharedData.Instance().FlagList[item.flag] = 2;
				}
			}
			else
			{
				Debug.LogWarning("CloseEvent can NOT found id: " + text);
			}
		}
	}

	public void OpenEvent(string _eventid, bool _active = false)
	{
		string[] array = _eventid.Split('&');
		foreach (string text in array)
		{
			if (SharedData.Instance().EventTable.ContainsKey(text))
			{
				Debug.Log((_active ? "OpenEvent(active): " : "OpenEvent: ") + text);
				List<gang_e01Table.Row> list = SharedData.Instance().EventTable[text];
				int num = 0;
				foreach (gang_e01Table.Row item in list)
				{
					SharedData.Instance().FlagList[item.flag] = ((_active && num == 0) ? 1 : 0);
					num++;
				}
			}
			else
			{
				Debug.LogWarning("OpenEvent can NOT found id: " + text);
			}
		}
	}

	private void CloseFlag(string _flagid)
	{
		string[] array = _flagid.Split('|');
		foreach (string text in array)
		{
			if (SharedData.Instance().FlagList.ContainsKey(text))
			{
				SharedData.Instance().FlagList[text] = 2;
				MonoBehaviour.print("CloseFlag " + text);
			}
		}
	}

	public void OpenFlag(string _flagid)
	{
		string[] array = _flagid.Split('|');
		foreach (string text in array)
		{
			if (SharedData.Instance().FlagList.ContainsKey(text))
			{
				SharedData.Instance().FlagList[text] = 1;
				MonoBehaviour.print("OpenFlag " + text);
			}
		}
	}

	private void InitFlag(string _flagid)
	{
		string[] array = _flagid.Split('|');
		foreach (string text in array)
		{
			if (SharedData.Instance().FlagList.ContainsKey(text))
			{
				SharedData.Instance().FlagList[text] = 0;
				MonoBehaviour.print("InitFlag " + text);
			}
		}
	}

	private void ShowMeTheMoney()
	{
		if (SharedData.Instance().couldCheat)
		{
			return;
		}
		string text = Input.inputString;
		for (int i = 0; i < text.Length; i++)
		{
			char c = text[i];
			if (c == '\n' || c == '\r')
			{
				inputString = "";
				continue;
			}
			inputString += c;
			if (inputString.Length > maxLength)
			{
				inputString = inputString.Substring(inputString.Length - maxLength);
			}
			if (inputString.Contains(targetString))
			{
				Debug.Log("showmethemoney");
				SharedData.Instance().couldCheat = true;
				inputString = "";
			}
		}
	}

	private void Update()
	{
		if (m_WantedList.activeInHierarchy && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(m_WantedList.transform.Find("WantedClose").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		if (!InitOK)
		{
			return;
		}
		ShowMeTheMoney();
		if (isEnterBattleAnimPlaying || CommonFunc.IsHoverOpen())
		{
			return;
		}
		EffectTimer += Time.deltaTime;
		if (IsTeleport)
		{
			return;
		}
		if (SharedData.Instance().couldCheat)
		{
			if (!m_ScenePlaying && m_Menu3.IsOpen() && m_LastClickCamera == 0 && !m_InputField.activeInHierarchy && InputSystemCustom.Instance().UI.CheatInput.WasReleasedThisFrame())
			{
				m_InputField.SetActive(value: true);
				m_InputField.GetComponent<InputField>().ActivateInputField();
				m_Menu3.Close();
				return;
			}
			if (m_InputField.activeInHierarchy)
			{
				if (Keyboard.current != null && Keyboard.current.enterKey.wasReleasedThisFrame)
				{
					string[] array = m_InputField.GetComponent<InputField>().text.Split(' ');
					m_Canvas_Event = null;
					string text = "";
					gang_b07Table.Row row = null;
					switch (array[0])
					{
					case "getitem":
						row = CommonResourcesData.b07.Find_ID(array[1]);
						if (row != null)
						{
							if (array[1] == "999")
							{
								SharedData.Instance().m_Money += int.Parse(array[2]);
								if (SharedData.Instance().m_Money < 0)
								{
									SharedData.Instance().m_Money = 0;
								}
							}
							else
							{
								SharedData.Instance().PackageAdd(array[1], int.Parse(array[2]));
							}
							text = "GET|ITEM|" + array[1] + "|" + array[2];
							AddExploreList(text);
						}
						else
						{
							Debug.LogWarning("NOT found itemid[" + array[1] + "] in table B07.");
							if (SharedData.Instance().PlayerPackage.ContainsKey(array[1]))
							{
								SharedData.Instance().PackageRemove(array[1]);
							}
						}
						break;
					case "gettrait":
						if (array[1] == "all")
						{
							if (array[2] == "+")
							{
								foreach (gang_b06Table.Row row3 in CommonResourcesData.b06.GetRowList())
								{
									player.charadata.AddTraits(row3.id);
								}
							}
							else
							{
								player.charadata.m_TraitList.Clear();
							}
						}
						else if (array[2] == "+")
						{
							if (!player.charadata.m_TraitList.Contains(array[1]))
							{
								player.charadata.AddTraits(array[1]);
								gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(array[1]);
								if ("1".Equals(row2.isLockTrait))
								{
									player.charadata.m_EquipTraitDict[row2.traitEquipIndex] = row2.id;
								}
								GameDataManager.Instance().AddUnlockAtlasList(array[1], "b06");
							}
						}
						else if (player.charadata.m_TraitList.Contains(array[1]))
						{
							player.charadata.RemoveTrait(array[1]);
						}
						text = "GET|TRAIT|PLAYER|" + array[1] + "|" + array[2];
						AddExploreList(text);
						break;
					case "getwugong":
					{
						string[] array2;
						if (array[2] == "+")
						{
							array2 = array[1].Split('|');
							foreach (string text3 in array2)
							{
								if (player.charadata.GetKongFuByID(text3) == null)
								{
									KongFuData kongFuData = new KongFuData();
									kongFuData.kf = CommonResourcesData.b03.Find_ID(text3);
									kongFuData.lv = int.Parse(kongFuData.kf.LV);
									kongFuData.exp = 0f;
									kongFuData.proficiency = 0;
									player.charadata.KongFuListAdd(kongFuData);
									text = "GET|WUGONG|PLAYER|" + text3 + "|" + array[2];
									AddExploreList(text);
								}
							}
							break;
						}
						array2 = array[1].Split('|');
						foreach (string text4 in array2)
						{
							KongFuData kongFuByID3 = player.charadata.GetKongFuByID(text4);
							if (kongFuByID3 != null)
							{
								player.charadata.KongFuListRemove(kongFuByID3);
								text = "GET|WUGONG|PLAYER|" + text4 + "|" + array[2];
								AddExploreList(text);
							}
						}
						break;
					}
					case "showitem":
						row = CommonResourcesData.b07.Find_ID(array[1]);
						if (row != null)
						{
							Chat(null, "天之声", "【" + array[1] + "】：" + row.Name + "\n" + row.note, "0", "0");
						}
						else
						{
							Chat(null, "天之声", "不明物品【" + array[1] + "】", "0", "0");
						}
						break;
					case "resetplayer":
						SharedData.Instance().m_Player_Reset = 1;
						SaveMapSnapShot();
						LoadSceneAdditive("Starter3");
						break;
					case "wugonglist":
					{
						string text2 = "";
						foreach (KongFuData kongFu in player.charadata.m_KongFuList)
						{
							text2 = text2 + "【" + kongFu.kf.ID + ": " + kongFu.kf.Name + "】";
						}
						Chat(null, "天之声", text2, "0", "0");
						break;
					}
					case "forget":
						if (array.Length > 1)
						{
							if (PlayerForgetSkill(array[1]))
							{
								Chat(null, "天之声", "哎呦，不错哦！", "0", "0");
							}
							else
							{
								Chat(null, "天之声", "哎呀~，你干嘛~~", "0", "0");
							}
						}
						break;
					case "Epic":
						SharedData.Instance().m_Epiphany += 1000;
						Chat(null, "天之声", "Duang~", "0", "0");
						break;
					case "showmethemoney":
						SharedData.Instance().m_Money += 10000;
						AddExploreList("GET|ITEM|999|10000");
						break;
					case "iaminevitable":
						SharedData.Instance().m_Inevitable = true;
						Chat(null, "天之声", "噗~", "0", "0");
						break;
					case "playerwashup":
						SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
						PlayerWashUp();
						Chat(null, "天之声", "哗啦~ 枯嚓~", "0", "0");
						break;
					case "iamironman":
						SharedData.Instance().m_Inevitable = false;
						Chat(null, "天之声", "啪！", "0", "0");
						break;
					case "checkfinallover":
						Chat(null, "天之声", CheckFinalLover(), "0", "0");
						break;
					case "setplayround":
						SharedData.Instance().m_PlayRound = int.Parse(array[1]);
						Chat(null, "天之声", "当前周目数 = " + SharedData.Instance().m_PlayRound, "0", "0");
						break;
					case "setmaxplayround":
						GameDataManager.Instance().configdata.playRound = int.Parse(array[1]);
						Chat(null, "天之声", "已通关次数 = " + GameDataManager.Instance().configdata.playRound, "0", "0");
						break;
					case "showplayround":
						Chat(null, "天之声", "当前" + SharedData.Instance().Translate2Hanzi(SharedData.Instance().m_PlayRound) + "周目，已通关" + SharedData.Instance().Translate2Hanzi(GameDataManager.Instance().configdata.playRound) + "次", "0", "0");
						break;
					case "setspeed":
						SharedData.Instance().m_FieldMoveSpeedRate = float.Parse(array[1], CultureInfo.InvariantCulture);
						Chat(null, "天之声", "移动速度倍率 = " + SharedData.Instance().m_FieldMoveSpeedRate, "0", "0");
						break;
					case "getspeed":
						Chat(null, "天之声", "移动速度倍率 = " + SharedData.Instance().m_FieldMoveSpeedRate, "0", "0");
						break;
					case "ev1":
						SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
						if (array.Length >= 2)
						{
							if (array[1].Equals("Enhance"))
							{
								EvolutionEqNewController.EnhanceEquipmentType = EnhanceType.Enhance;
							}
							else if (array[1].Equals("Reset"))
							{
								EvolutionEqNewController.EnhanceEquipmentType = EnhanceType.Reset;
							}
						}
						if (array.Length >= 3)
						{
							SharedData.Instance().CurrentChara = array[2];
						}
						if (array[0].Equals("ev1") && (array[1].Equals("Enhance") || array[1].Equals("Reset")))
						{
							LoadSceneAdditive("EvolutionEQ");
						}
						break;
					case "ev2":
						SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
						if (array.Length >= 3)
						{
							SharedData.Instance().CurrentChara = array[2];
						}
						if (array.Length >= 2)
						{
							if (array[1].Equals("Create"))
							{
								CreateWGController.enhanceWuGongType = EnhanceWuGongType.Create;
								LoadSceneAdditive("CreateWG");
							}
							else if (array[1].Equals("Break"))
							{
								CreateWGController.enhanceWuGongType = EnhanceWuGongType.Break;
								LoadSceneAdditive("EvolutionWG");
							}
						}
						break;
					case "modiattr":
						if (array[1] == "TALENT")
						{
							player.charadata.m_Talent += Mathf.FloorToInt(float.Parse(array[2], CultureInfo.InvariantCulture));
						}
						else
						{
							player.charadata.Indexs_Name[array[1]].juqingValue += Mathf.Floor(float.Parse(array[2], CultureInfo.InvariantCulture));
							if (array[1] == "HP")
							{
								player.charadata.m_Hp = player.charadata.GetFieldValueByName("HP");
							}
							else if (array[1] == "MP")
							{
								player.charadata.m_Mp = player.charadata.GetFieldValueByName("MP");
							}
						}
						AddExploreList("GET|ATTR|" + array[1] + "|" + array[2]);
						break;
					case "setwugonglv":
					{
						KongFuData kongFuByID = player.charadata.GetKongFuByID(array[1]);
						if (kongFuByID != null)
						{
							kongFuByID.lv = int.Parse(array[2]);
							MonoBehaviour.print("Set kongfu " + kongFuByID.kf.Name_Trans + " lv = " + array[2]);
						}
						break;
					}
					case "setwugongneet":
					{
						KongFuData kongFuByID2 = player.charadata.GetKongFuByID(array[1]);
						if (kongFuByID2 != null)
						{
							kongFuByID2.proficiency = int.Parse(array[2]);
							MonoBehaviour.print("Set kongfu " + kongFuByID2.kf.Name_Trans + " proficiency = " + array[2]);
						}
						break;
					}
					case "setwugongexp":
					{
						KongFuData kongFuByID = player.charadata.GetKongFuByID(array[1]);
						if (kongFuByID != null)
						{
							kongFuByID.exp = int.Parse(array[2]);
							MonoBehaviour.print("Set kongfu " + kongFuByID.kf.Name_Trans + " exp = " + array[2]);
						}
						break;
					}
					case "battle":
						SaveMapSnapShot();
						SharedData.Instance().BattleEnemyGroupId = array[2];
						if (array.Length > 3)
						{
							SharedData.Instance().BattleMemberMax = int.Parse(array[3]);
						}
						else
						{
							SharedData.Instance().BattleMemberMax = 3;
						}
						SharedData.Instance().BattleGround = array[1];
						SharedData.Instance().BattleItemGroupId = "0";
						SharedData.Instance().AfterBattleWin = "";
						SharedData.Instance().AfterBattleLose = "";
						SharedData.Instance().BackFromOtherScene = false;
						SharedData.Instance().PlayerSetting.Clear();
						SharedData.Instance().EnemySetting.Clear();
						enemygid = SharedData.Instance().BattleEnemyGroupId.Split('-');
						if (enemygid[0] == "solo")
						{
							SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
							LoadScene(array[1], isBattle: true);
							break;
						}
						if (enemygid[0] == "demo")
						{
							SharedData.Instance().b04BattleID = enemygid[1];
							LoadScene(array[1], isBattle: true);
							break;
						}
						if (enemygid[0] == "event")
						{
							if (array.Length > 3 && array[3] == "1")
							{
								ElixirChara("ALL");
							}
							SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
							SharedData.Instance().b04BattleID = enemygid[1];
							SharedData.Instance().m_EventShow = true;
							LoadScene(array[1], isBattle: true);
							break;
						}
						if (enemygid[0] == "chara")
						{
							SharedData.Instance().PlayerSetting.Add("Player1", enemygid[2]);
							SharedData.Instance().b04BattleID = enemygid[1];
							SharedData.Instance().m_EventShow = true;
							LoadScene(array[1], isBattle: true);
							break;
						}
						if (enemygid[0] == "duel")
						{
							SharedData.Instance().DuelBattleGuild = enemygid[1];
							LoadScene("BeforeDuelBattle", isBattle: true);
							break;
						}
						if (array.Length > 4 && array[4] == "1")
						{
							ElixirChara("ALL");
						}
						if (enemygid.Length > 1 && "force".Equals(enemygid[1]))
						{
							SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
							SharedData.Instance().BattleMemberMax++;
							SharedData.Instance().isChooseBattle = false;
						}
						SharedData.Instance().b04BattleID = enemygid[0];
						LoadScene("BeforeBattle", isBattle: true);
						break;
					case "teleport":
						if (!SharedData.Instance().m_Teleportation)
						{
							Chat(null, "天之声", "瞬移能力，开启！", "0", "0");
						}
						else
						{
							Chat(null, "天之声", "瞬移能力，关闭！", "0", "0");
						}
						SharedData.Instance().m_Teleportation = !SharedData.Instance().m_Teleportation;
						break;
					case "follow":
						if (SharedData.Instance().FullTeam.Contains(array[1]) && SharedData.Instance().FollowList.Count < SharedData.Instance().FollowMaxCount && !SharedData.Instance().FollowList.Contains(array[1]))
						{
							SharedData.Instance().FollowList.Add(array[1]);
							GameDataManager.Instance().AddUnlockAtlasList(array[1], "b01");
							SharedData.Instance().player.InitFollows();
						}
						break;
					case "join":
						JoinTeam(array[1]);
						break;
					case "specialjoin":
						JoinTeam(array[1], isSpecial: true);
						break;
					case "unlockall":
						foreach (gang_b01Table.Row row4 in CommonResourcesData.b01.GetRowList())
						{
							GameDataManager.Instance().AddUnlockAtlasList(row4.ID, "b01");
						}
						foreach (gang_b07Table.Row row5 in CommonResourcesData.b07.GetRowList())
						{
							GameDataManager.Instance().AddUnlockAtlasList(row5.ID, "b07");
						}
						break;
					case "changesex":
					{
						CharaData charaData3 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
						SharedData.Instance().playerid = ("9001".Equals(SharedData.Instance().playerid) ? "9002" : "9001");
						SharedData.Instance().GetCharaData(SharedData.Instance().playerid).UpdateData(charaData3);
						Debug.Log("changesex: SharedData.Instance().playerid = " + SharedData.Instance().playerid);
						break;
					}
					case "leave":
						LeaveTeam(array[1], _reteamable: true);
						SharedData.Instance().player.InitFollows();
						break;
					case "unfollow":
						SharedData.Instance().FollowList.Clear();
						SharedData.Instance().player.InitFollows();
						break;
					case "openflag":
						OpenFlag(array[1]);
						break;
					case "closeflag":
						CloseFlag(array[1]);
						break;
					case "initflag":
						InitFlag(array[1]);
						break;
					case "reopenevent":
						OpenEvent(array[1]);
						break;
					case "closeevent":
						CloseEvent(array[1]);
						break;
					case "browseurl":
						AddExploreList("BROWSEURL");
						break;
					case "guide":
						if (array.Length > 1)
						{
							AddExploreList("GUIDE|" + array[1]);
						}
						else
						{
							AddExploreList("GUIDE");
						}
						break;
					case "checkflag":
					{
						string text5 = array[1] + " = " + SharedData.Instance().FlagList[array[1]];
						Chat(null, "天之声", text5, "0", "0");
						MonoBehaviour.print(text5);
						break;
					}
					case "savedata":
						SaveMapSnapShot();
						m_Menu3.Close();
						SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
						SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Save;
						SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
						break;
					case "gomap":
						SharedData.Instance().SpawnPoint = array[2];
						SharedData.Instance().SpawnStatus = "Normal";
						if (array.Length > 3)
						{
							SharedData.Instance().SpawnStatus = array[3];
						}
						LoadScene(array[1]);
						break;
					case "changeborn":
						SharedData.Instance().BornID = array[1];
						break;
					case "getperception":
						if (array.Length >= 2)
						{
							Chat(null, "获取感悟点", "成功获取感悟点" + int.Parse(array[1]), "0", "0");
						}
						break;
					case "refreshmine":
						if (SharedData.Instance().mapMineCouldRefreshList.Find((RefreshMineInfo x) => x._scenename == sceneName) == null)
						{
							SharedData.Instance().mapMineList.Clear();
							SharedData.Instance().mapMineCouldRefreshList.Clear();
							Chat(null, "刷新矿物", "刷新成功", "0", "0");
						}
						else
						{
							Chat(null, "刷新矿物", "刷新失败", "0", "0");
						}
						break;
					case "joinfaction":
						DoFaction("JOIN", array[1], array[2]);
						break;
					case "leavefaction":
						DoFaction("LEAVE", array[1], array[2]);
						break;
					case "changeform":
						SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
						LoadSceneAdditive("ChangeForm");
						break;
					case "skip2flag":
						EventSkipper.Instance().PrepareAndRun(array[1], "");
						break;
					case "getallB07":
						foreach (gang_b07Table.Row row6 in CommonResourcesData.b07.GetRowList())
						{
							SharedData.Instance().PackageAdd(row6.ID, 1);
						}
						break;
					case "unlockmapID":
						if (!SharedData.Instance().m_UnLockMapIconList.Contains(array[1] + "&") && CommonResourcesData.e07.Find_id(array[1]) != null)
						{
							SharedData sharedData2 = SharedData.Instance();
							sharedData2.m_UnLockMapIconList = sharedData2.m_UnLockMapIconList + array[1] + "&";
						}
						break;
					case "unlockmap":
						SharedData.Instance().m_UnLockMapIconList = "";
						foreach (gang_e07Table.Row row7 in CommonResourcesData.e07.GetRowList())
						{
							SharedData sharedData = SharedData.Instance();
							sharedData.m_UnLockMapIconList = sharedData.m_UnLockMapIconList + row7.id + "&";
						}
						break;
					case "expel":
						SharedData.Instance().SubdueManageFor = "Expel";
						LoadSceneAdditive("SubdueManage");
						break;
					case "subdueTest":
					{
						for (int i = 2; i < 20; i++)
						{
							CharaData charaData2 = new CharaData();
							charaData2.Init(CommonResourcesData.b01.Find_ID("1186_" + i));
							charaData2.Indexs_Name["Name"].stringValue = "测试大黄狗_" + i;
							SharedData.Instance().m_SubdueList.Add("1186_" + i, charaData2);
						}
						SharedData.Instance().SubdueManageFor = "SubdueTest";
						LoadSceneAdditive("SubdueManage");
						break;
					}
					case "DuelTest":
						if (array.Length > 1)
						{
							SharedData.Instance().DuelBattleGuild = array[1];
						}
						if (array.Length > 2)
						{
							SharedData.Instance().BattleGround = array[2];
						}
						else
						{
							SharedData.Instance().BattleGround = "BattleField-XiangYangRandom-1";
						}
						LoadSceneAdditive("BeforeDuelBattle");
						break;
					case "unlockAchievementSteam":
						if (array.Length >= 2)
						{
							StatsAndAchievements.Instance().UnlockAchievement(array[1]);
						}
						break;
					case "changeSpeed":
						if (array.Length >= 2)
						{
							Time.timeScale = float.Parse(array[1], CultureInfo.InvariantCulture);
						}
						break;
					case "modiExp":
					{
						CharaData charaData = SharedData.Instance().player.charadata;
						if (array.Length >= 3)
						{
							charaData = SharedData.Instance().GetCharaData(array[2]);
						}
						charaData.m_Exp = int.Parse(array[1]);
						break;
					}
					case "opensect":
						if (array.Length >= 2)
						{
							SharedData.Instance().sectPanelID = array[1];
							UnityEngine.Object.Instantiate(Resources.Load("Prefabs/NewUI/SectCanvas/SectCanvas") as GameObject);
						}
						break;
					case "openshop":
						if (array.Length >= 2)
						{
							SharedData.Instance().OpenShopID = array[1];
							SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
							SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Shop);
						}
						break;
					case "inheritance":
						LoadSceneAdditive("Inheritance");
						break;
					case "getinheritance":
						getInheritItems();
						break;
					case "deletewugong":
						SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
						if (array.Length >= 2)
						{
							SharedData.Instance().CurrentChara = array[1];
						}
						AbolishKungfu(SharedData.Instance().CurrentChara);
						break;
					}
					m_InputField.SetActive(value: false);
				}
				else if (InputSystemCustom.Instance().UI.CheatInput.WasReleasedThisFrame())
				{
					m_InputField.SetActive(value: false);
				}
				return;
			}
			if (m_WantedList.activeInHierarchy && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
			{
				ExecuteEvents.Execute(m_WantedList.transform.Find("WantedClose").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
		if (!m_ScenePlaying && m_Menu3.IsOpen() && m_LastClickCamera == 0 && !m_InputField.activeInHierarchy && !SharedData.Instance().m_PackageController.isOpen && !SharedData.Instance().m_TraitPackageController.isOpen && SceneManager.sceneCount == 1 && !CommonResourcesData.statusMainController.gameObject.activeInHierarchy && !SharedData.Instance().IsViewOpen)
		{
			if (Keyboard.current != null && Keyboard.current.cKey.wasReleasedThisFrame)
			{
				m_Menu3.OpenStatusMain("1");
				return;
			}
			if (Keyboard.current != null && Keyboard.current.vKey.wasReleasedThisFrame)
			{
				m_Menu3.OpenStatusMain("2");
				return;
			}
			if (Keyboard.current != null && Keyboard.current.bKey.wasReleasedThisFrame)
			{
				m_Menu3.OpenStatusMain("3");
				return;
			}
			if (Keyboard.current != null && Keyboard.current.kKey.wasReleasedThisFrame)
			{
				m_Menu3.OpenStatusMain("4");
				return;
			}
			if (Keyboard.current != null && Keyboard.current.jKey.wasReleasedThisFrame)
			{
				m_Menu3.OpenStatusMain("5");
				return;
			}
			if (Keyboard.current != null && Keyboard.current.iKey.wasReleasedThisFrame)
			{
				m_Menu3.OpenStatusMain("7");
				return;
			}
			if (InputSystemCustom.Instance().UI.OpenMapView.WasReleasedThisFrame())
			{
				OpenMapView();
				return;
			}
			if (InputSystemCustom.Instance().UI.OpenLogView.WasReleasedThisFrame())
			{
				OpenLogView();
				return;
			}
			if (InputSystemCustom.Instance().UI.OpenJourney.WasReleasedThisFrame())
			{
				SharedData.Instance().IsViewOpen = true;
				SceneManager.LoadScene("JourneyList", LoadSceneMode.Additive);
				return;
			}
			if (InputSystemCustom.Instance().UI.OpenAtlas.WasReleasedThisFrame())
			{
				SharedData.Instance().m_AtlasManagerNewController.OpenAtlas();
				SharedData.Instance().IsViewOpen = true;
				return;
			}
		}
		if (m_Menu2.IsOpen() && !SharedData.Instance().CheckGuiRaycastObjects() && (Input.GetMouseButtonDown(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame()))
		{
			m_Menu2.Close();
		}
		if (m_Menu3.IsOpen() && !SharedData.Instance().CheckGuiRaycastObjects() && Input.GetMouseButtonDown(0))
		{
			m_Menu3.Close();
		}
		int num = 0;
		bool flag = false;
		foreach (Event value in events.Values)
		{
			if (!(value.obj != null))
			{
				continue;
			}
			EventController component = value.obj.GetComponent<EventController>();
			if (component.m_ScenePlay == 2)
			{
				component.m_ScenePlay = 0;
				if (component.m_MovieEvent != null)
				{
					if (component.m_MovieCutID == 1)
					{
						EventComplete(component.m_MovieEvent);
						flag = true;
					}
					component.m_MovieEvent = null;
					component.m_MovieCutID = 0;
				}
				else
				{
					EventComplete(value);
					flag = true;
				}
			}
			num += component.m_ScenePlay;
		}
		if (num == 0)
		{
			if (!flag)
			{
				if (player.m_ScenePlay > 0)
				{
					if (player.m_ScenePlay == 2)
					{
						if (player.m_MovieMove)
						{
							player.m_MovieMove = false;
							player.m_ScenePlay = 0;
							player.m_KeepAnimation = false;
						}
						else
						{
							EventComplete(m_Current_Event);
							player.m_ScenePlay = 0;
							player.m_KeepAnimation = false;
							UpdateEvents(2);
						}
					}
					m_ScenePlaying = true;
					return;
				}
				if (IsChating())
				{
					if (m_exploreShowTimer < m_exploreMinimumShowTime)
					{
						m_exploreShowTimer += Time.deltaTime;
					}
					else if (m_LastClick)
					{
						if (m_Dialog.activeInHierarchy)
						{
							m_Chat_Name.text = "";
							m_Chat_NameL.text = "";
							m_Chat_Text.text = "";
							if (m_Chat_Icon != null)
							{
								m_Chat_Icon.SetActive(value: false);
							}
							m_Dialog.SetActive(value: false);
							CloseTachie();
						}
						if (m_Explore.activeInHierarchy)
						{
							m_Explore_VoiceOver.SetActive(value: false);
							m_Explore_IconFrame.SetActive(value: false);
							m_Explore_BrowseURL.SetActive(value: false);
							m_Explore_Guide.SetActive(value: false);
							m_Explore_Text.transform.parent.gameObject.SetActive(value: true);
							m_Explore.SetActive(value: false);
						}
						UpdateEvents(3);
						m_LastClick = false;
						m_exploreShowTimer = 0f;
					}
					else if (!m_Selector.activeInHierarchy && (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame() || Input.GetKeyUp(KeyCode.Space)))
					{
						if (m_chat_process == 1)
						{
							m_chat_process = 2;
						}
						else if (m_chat_process == 0)
						{
							if (m_ChatList.Count > 0)
							{
								m_Chat_Name.text = "";
								m_Chat_NameL.text = "";
								m_Chat_Text.text = "";
								if (m_Chat_Icon != null)
								{
									m_Chat_Icon.SetActive(value: false);
								}
								Chat(m_ChatList[0].ev, m_ChatList[0].name, m_ChatList[0].text, m_ChatList[0].message, m_ChatList[0].picture, m_ChatList[0].position);
								m_ChatList.RemoveAt(0);
							}
							else
							{
								if (m_Dialog.activeInHierarchy)
								{
									EventComplete(m_Canvas_Event);
								}
								if (!m_Explore_BrowseURL.activeInHierarchy && !m_Explore_Guide.activeInHierarchy)
								{
									if (m_ExploreList.Count > 0)
									{
										Explore(m_ExploreList[0]);
										m_ExploreList.RemoveAt(0);
									}
									else
									{
										if (m_Explore.activeInHierarchy)
										{
											EventComplete(m_Canvas_Event);
										}
										m_LastClick = true;
									}
								}
							}
						}
					}
				}
				else
				{
					UpdateEvents(4);
				}
				m_ScenePlaying = false;
			}
			else
			{
				m_ScenePlaying = true;
			}
		}
		else
		{
			m_ScenePlaying = true;
		}
	}

	private void AbolishKungfu(string characterID = "")
	{
		SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
		if (!characterID.Equals(""))
		{
			SharedData.Instance().CurrentChara = characterID;
		}
		SharedData.Instance().m_StatusSub5.statusSub5Type = StatusSub5Type.Deletewugong;
		SharedData.Instance().m_StatusSub5.gameObject.SetActive(value: true);
		SharedData.Instance().LoadedSceneStack.Add("deletewugong");
	}

	public void OpenMapView()
	{
		m_Menu3.Close();
		SharedData.Instance().IsViewOpen = true;
		SharedData.Instance().CurrentMapID = SharedData.Instance().loadMapE04.id;
		SharedData.Instance().CurrentPlayerPos = player.transform.position;
		SceneManager.LoadScene("MapView", LoadSceneMode.Additive);
		PlayMapViewBgm(isShowMapView: true);
	}

	public void PlayMapViewBgm(bool isShowMapView)
	{
		if (isShowMapView)
		{
			m_AudioSource.clip = CommonResourcesData.LoadBgm("Chinatown_Healing_loop");
			m_AudioSource.loop = true;
			m_AudioSource.Play();
		}
		else
		{
			PlayBGM();
		}
	}

	private IEnumerator RecordPath()
	{
		while (true)
		{
			string id = SharedData.Instance().loadMapE04.id;
			gang_e04Table.Row loadMapE = SharedData.Instance().loadMapE04;
			if (loadMapE != null && loadMapE.maplocation.Length > 0 && !loadMapE.maplocation.Equals("0"))
			{
				string[] array = loadMapE.maplocation.Split('|');
				if (array.Length == 5)
				{
					SharedData.Instance().CurrentPlayerPos = player.transform.position;
					float num = float.Parse(array[0], CultureInfo.InvariantCulture);
					float num2 = float.Parse(array[1], CultureInfo.InvariantCulture);
					float num3 = float.Parse(array[4], CultureInfo.InvariantCulture);
					float num4 = (SharedData.Instance().CurrentPlayerPos.x - num) * num3;
					float num5 = (SharedData.Instance().CurrentPlayerPos.y - num2) * num3;
					float num6 = float.Parse(array[2], CultureInfo.InvariantCulture);
					float num7 = float.Parse(array[3], CultureInfo.InvariantCulture);
					Vector2 vector = new Vector2(num6 - num4, num7 - num5);
					vector = -1f * vector / 10f;
					if (SharedData.Instance().pathRecord.Count == 0)
					{
						SharedData.Instance().pathRecord.Add(new PathInfo(id, vector));
					}
					else if (SharedData.Instance().pathRecord[SharedData.Instance().pathRecord.Count - 1].Pos != vector)
					{
						SharedData.Instance().pathRecord.Add(new PathInfo(id, vector));
					}
					if (SharedData.Instance().pathRecord.Count > SharedData.Instance().maxPathRecordCount)
					{
						SharedData.Instance().pathRecord.RemoveAt(0);
					}
				}
			}
			yield return new WaitForSeconds(SharedData.Instance().PathRecordInterval);
		}
	}

	public void OpenLogView()
	{
		m_Menu3.Close();
		SharedData.Instance().IsViewOpen = true;
		SceneManager.LoadScene("LogView", LoadSceneMode.Additive);
	}

	public void EventComplete(Event _event)
	{
		if (GameDataManager.Instance().sceneLoadData || _event == null)
		{
			return;
		}
		if (_event.elseroute && _event.evdata.elsefollow.Length > 0)
		{
			SetNextFlag(_event.evdata.elsefollow, _event.evdata.trigger == "AUTO");
			_event.flow = 0;
			_event = null;
			return;
		}
		if (SharedData.Instance().FlagList[_event.evdata.flag] == 1)
		{
			if (_event.evdata.trigger == "FOLLOW")
			{
				SharedData.Instance().FlagList[_event.evdata.flag] = 0;
			}
			else
			{
				SharedData.Instance().FlagList[_event.evdata.flag] = 2;
			}
			if (_event.evdata.nextflag.Length > 0)
			{
				SetNextFlag(_event.evdata.nextflag, _event.evdata.trigger == "AUTO");
			}
		}
		if (_event.evdata.output != "END")
		{
			_event.flow = 0;
		}
		else
		{
			EventFlowEnd(_event);
		}
		_event = null;
	}

	private void JoinTeam(string _uid, bool isSpecial = false)
	{
		if (!SharedData.Instance().FullTeam.Contains(_uid))
		{
			SharedData.Instance().FullTeam.Add(_uid);
			GameDataManager.Instance().AddUnlockAtlasList(_uid, "b01");
			PlaySoundEffect("Join1", "0", null);
			SharedData.Instance().isChooseBattle = false;
		}
		if (SharedData.Instance().FollowList.Count < SharedData.Instance().FollowMaxCount && !SharedData.Instance().FollowList.Contains(_uid))
		{
			SharedData.Instance().FollowList.Add(_uid);
			GameDataManager.Instance().AddUnlockAtlasList(_uid, "b01");
			SharedData.Instance().player.InitFollows();
		}
		if (isSpecial)
		{
			SpecialJoinTeamProcess(_uid);
		}
	}

	private void SpecialJoinTeamProcess(string _uid)
	{
		Debug.Log("SpecialJoinTeamProcess _uid = " + _uid);
		CharaData charaData = SharedData.Instance().GetCharaData(_uid);
		int num = SharedData.Instance().player?.charadata.m_Level ?? 0;
		if (charaData.m_Level < num)
		{
			charaData.m_Talent += num - charaData.m_Level;
			FieldInfo[] fields = typeof(gang_a05Table.Row).GetFields();
			for (int i = charaData.m_Level + 1; i < num; i++)
			{
				gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(i.ToString() ?? "");
				if (row == null)
				{
					continue;
				}
				FieldInfo[] array = fields;
				foreach (FieldInfo fieldInfo in array)
				{
					if (!fieldInfo.Name.Equals("LV") && !fieldInfo.Name.Equals("EXP"))
					{
						charaData.Indexs_Name[fieldInfo.Name].levelupValue += float.Parse(fieldInfo.GetValue(row).ToString(), CultureInfo.InvariantCulture);
					}
				}
			}
			charaData.m_Level = num;
		}
		List<string> list = new List<string>
		{
			"HP", "MP", "ATK", "DEF", "SP", "Sword", "Knife", "Stick", "Hand", "Finger",
			"Special", "YinYang", "Melody", "Medical", "Darts", "Wineart", "Steal", "Forge", "Percept"
		};
		gang_b01Table.Row row2 = CommonResourcesData.b01.Find_ID(_uid + "&SpecialJoin");
		if (row2 != null)
		{
			FieldInfo[] array = typeof(gang_b01Table.Row).GetFields();
			foreach (FieldInfo fieldInfo2 in array)
			{
				if (list.Contains(fieldInfo2.Name))
				{
					charaData.Indexs_Name[fieldInfo2.Name].levelupValue += float.Parse(fieldInfo2.GetValue(row2).ToString(), CultureInfo.InvariantCulture);
				}
				else
				{
					if (!fieldInfo2.Name.Equals("Traits"))
					{
						continue;
					}
					string[] array2 = fieldInfo2.GetValue(row2).ToString().Split('|');
					foreach (string text in array2)
					{
						gang_b06Table.Row row3 = CommonResourcesData.b06.Find_id(text);
						if (row3 != null)
						{
							charaData.AddTraits(text);
							if ("1".Equals(row3.isLockTrait) && charaData.m_EquipTraitDict[row3.traitEquipIndex].Equals(""))
							{
								charaData.m_EquipTraitDict[row3.traitEquipIndex] = row3.id;
							}
						}
					}
				}
			}
		}
		charaData.m_Hp = charaData.GetFieldValueByName("HP");
		charaData.m_Mp = charaData.GetFieldValueByName("MP");
		SharedData.Instance().m_TempParas["teammates"] = charaData.Indexs_Name["Name"].stringValue;
	}

	public void LeaveTeam(string _uid, bool _reteamable = false, bool isForce = false)
	{
		if (!SharedData.Instance().FullTeam.Contains(_uid))
		{
			return;
		}
		CharaData charaData = SharedData.Instance().GetCharaData(_uid);
		string text = "";
		text = ((charaData != null) ? charaData.Indexs_Name["Name"].stringValue : _uid);
		if (!"0".Equals(charaData.m_EquipSlot[0]))
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(charaData.m_EquipSlot[0]);
			if (row != null)
			{
				MonoBehaviour.print("LeaveTeam(): 武器 " + row.Name + " unequip from " + text);
				SharedData.Instance().PackageAdd(charaData.m_EquipSlot[0], 1);
				charaData.m_EquipSlot[0] = "0";
			}
			else
			{
				MonoBehaviour.print("LeaveTeam(): 武器 " + charaData.m_EquipSlot[0] + " NOT found in table B07.");
				charaData.m_EquipSlot[0] = "0";
			}
		}
		if (!"0".Equals(charaData.m_EquipSlot[1]))
		{
			gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(charaData.m_EquipSlot[1]);
			if (row2 != null)
			{
				MonoBehaviour.print("LeaveTeam(): 防具 " + row2.Name + " unequip from " + text);
				SharedData.Instance().PackageAdd(charaData.m_EquipSlot[1], 1);
				charaData.m_EquipSlot[1] = "0";
			}
			else
			{
				MonoBehaviour.print("LeaveTeam(): 防具 " + charaData.m_EquipSlot[1] + " NOT found in table B07.");
				charaData.m_EquipSlot[1] = "0";
			}
		}
		if (!"0".Equals(charaData.m_EquipSlot[2]))
		{
			gang_b07Table.Row row3 = CommonResourcesData.b07.Find_ID(charaData.m_EquipSlot[2]);
			CommonResourcesData.b02.Find_ID(row3.Relateid);
			if (row3 != null)
			{
				MonoBehaviour.print("LeaveTeam(): 饰品 " + row3.Name + " unequip from " + text);
				SharedData.Instance().PackageAdd(charaData.m_EquipSlot[2], 1);
				charaData.m_EquipSlot[2] = "0";
				SharedData.Instance().SetFieldMoveSpeedRate();
			}
			else
			{
				MonoBehaviour.print("LeaveTeam(): 饰品 " + charaData.m_EquipSlot[2] + " NOT found in table B07.");
				charaData.m_EquipSlot[2] = "0";
			}
		}
		if (!"0".Equals(charaData.m_Training_Id))
		{
			gang_b07Table.Row row4 = CommonResourcesData.b07.Find_Relate_Wugong_id(charaData.m_Training_Id);
			if (row4 != null)
			{
				MonoBehaviour.print("LeaveTeam(): 武学 " + row4.Name + " unequip from " + text);
				SharedData.Instance().PackageAdd(row4.ID, 1);
				charaData.m_Training_Id = "0";
			}
			else
			{
				MonoBehaviour.print("LeaveTeam(): 武学 " + charaData.m_Training_Id + " NOT found in table B07.");
				charaData.m_Training_Id = "0";
			}
		}
		if (SharedData.Instance().FlagList.ContainsKey("GLOBAL_FLAGS_CHA_" + _uid))
		{
			SharedData.Instance().FlagList["GLOBAL_FLAGS_CHA_" + _uid] = 2;
		}
		if (_reteamable)
		{
			string eventid = "TEAMMATE_STANDBY_" + _uid;
			OpenEvent(eventid, _active: true);
		}
		if (!IsEntourage(_uid) || isForce)
		{
			SharedData.Instance().FullTeam.Remove(_uid);
		}
		if (SharedData.Instance().FollowList.Contains(_uid))
		{
			SharedData.Instance().FollowList.Remove(_uid);
		}
		SharedData.Instance().isChooseBattle = false;
	}

	public void MenuActiveEvent(Event e)
	{
		EventController component = e.obj.GetComponent<EventController>();
		if (SharedData.Instance().FlagList[e.evdata.flag] == 1)
		{
			if (e.evdata.action.Length > 0)
			{
				component.ChangeSkin();
				EventAction(e.evdata.action, component, e);
			}
		}
		else if (SharedData.Instance().FlagList[e.evdata.flag] == 0)
		{
			if (e.evdata.elseaction.Length > 0)
			{
				EventAction(e.evdata.elseaction, component, e);
				e.elseroute = true;
			}
		}
		else if (SharedData.Instance().FlagList[e.evdata.flag] == 2 && e.evdata.throughaction.Length > 0)
		{
			EventAction(e.evdata.throughaction, component, e);
		}
	}

	public int isPositionHaveEvent(Vector3Int pos)
	{
		foreach (Event value in events.Values)
		{
			if (value.obj == null || SharedData.Instance().FlagList[value.evdata.flag] != 1 || value.evdata.trigger != "CLICK")
			{
				continue;
			}
			EventController component = value.obj.GetComponent<EventController>();
			if (pos.Equals(component.GetGridPosition()))
			{
				if (value.evdata.menu != "0")
				{
					return 2;
				}
				string[] array = value.evdata.action.Split('|');
				if (array[0] == "GET")
				{
					return 1;
				}
				if (array[0] == "CHAT")
				{
					return 2;
				}
				if (array[0] == "WANTED")
				{
					return 3;
				}
				if (array[0] == "CHECK")
				{
					return 2;
				}
				if (array[0] == "SELECT")
				{
					return 2;
				}
				if (value.obj.transform.Find("head_icon/talk/Ani") != null)
				{
					return 2;
				}
				break;
			}
		}
		return 0;
	}

	public bool ClickPosition(Vector3Int pos, bool _isKey = false)
	{
		if (!_isKey)
		{
			ShowCurcorAt(player.GetEndPosVec2());
		}
		bool result = false;
		foreach (Event value in events.Values)
		{
			if (value.obj == null || SharedData.Instance().FlagList[value.evdata.flag] != 1 || value.evdata.trigger != "CLICK")
			{
				continue;
			}
			EventController component = value.obj.GetComponent<EventController>();
			if (!pos.Equals(mapUnits[value.obj.name]))
			{
				continue;
			}
			if (component.tileName.Contains("MINE"))
			{
				SharedData.Instance().m_DiggingMineGrid = pos;
			}
			Vector3Int gridPosition = player.GetGridPosition();
			int num = component.IsNextToMe(gridPosition);
			if (num > 0)
			{
				string[] array = value.evdata.menu.Split('|');
				if (array[0] == "1")
				{
					player.GatherFollower();
					m_Menu3.Close();
					m_Menu2.Open(value);
				}
				else
				{
					MenuActiveEvent(value);
				}
				if (array[0] == "STILL")
				{
					switch (num)
					{
					case 3:
						player.Face(Direction.Down);
						break;
					case 1:
						player.Face(Direction.Up);
						break;
					case 2:
						player.Face(Direction.Right);
						break;
					case 4:
						player.Face(Direction.Left);
						break;
					}
				}
				else
				{
					switch (num)
					{
					case 3:
						player.Face(Direction.Down);
						component.Face(Direction.Up);
						break;
					case 1:
						player.Face(Direction.Up);
						component.Face(Direction.Down);
						break;
					case 2:
						player.Face(Direction.Right);
						component.Face(Direction.Left);
						break;
					case 4:
						player.Face(Direction.Left);
						component.Face(Direction.Right);
						break;
					}
				}
				result = true;
			}
			else
			{
				Vector3Int closePosition = component.GetClosePosition(gridPosition);
				player.CloseToTarget(closePosition, component.GetGridPosition());
				m_Current_Event = null;
				m_Canvas_Event = null;
			}
			break;
		}
		return result;
	}

	private Event GetEventById(string _ids)
	{
		Event result = null;
		string[] array = _ids.Split('|');
		bool flag = false;
		foreach (Event value2 in events.Values)
		{
			string[] array2 = array;
			foreach (string value in array2)
			{
				if (value2.eventid.Equals(value))
				{
					result = value2;
					flag = true;
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		return result;
	}

	public bool FootOnPosition(Vector3Int pos)
	{
		bool result = false;
		foreach (Event value in events.Values)
		{
			if (value.obj == null || SharedData.Instance().FlagList[value.evdata.flag] == 2 || (value.evdata.trigger != "FOOTON" && value.evdata.trigger != "HOVER"))
			{
				continue;
			}
			EventController component = value.obj.GetComponent<EventController>();
			if (!pos.Equals(component.GetGridPosition()) || SharedData.Instance().FlagList[value.evdata.flag] != 1)
			{
				continue;
			}
			if (value.evdata.action.Length > 0)
			{
				string[] array = value.evdata.action.Split('|');
				player.m_FootOnInterrupt = !array[0].Equals("THROUGH");
				bool footOnInterrupt = EventAction(value.evdata.action, component, value);
				if (array[0].Equals("CHECK"))
				{
					player.m_FootOnInterrupt = footOnInterrupt;
				}
				if (player.m_FootOnInterrupt)
				{
					player.ResetFollowerPosition();
				}
				result = true;
				break;
			}
			EventComplete(value);
		}
		return result;
	}

	private bool IsCharaNeedCure(CharaData _charadata)
	{
		bool result = false;
		if (_charadata.Indexs_Name["Drunk"].fightValue > 0f || _charadata.Indexs_Name["Hurt"].fightValue > 0f || _charadata.Indexs_Name["Poison"].fightValue > 0f || _charadata.Indexs_Name["Bleed"].fightValue > 0f || _charadata.Indexs_Name["Burn"].fightValue > 0f || _charadata.Indexs_Name["Seal"].fightValue > 0f || _charadata.Indexs_Name["Mad"].fightValue > 0f)
		{
			result = true;
		}
		return result;
	}

	private bool EventAction(string _action, EventController _eventcontroller, Event _event)
	{
		bool flag = false;
		StatsAndAchievements.Instance().UnlockStoryAchievement(_event.evdata.flag);
		string[] act = _action.Split('|');
		if (act[0] == "CHAT")
		{
			string chat_id = act[1];
			_ = act.Length;
			_ = 3;
			if ("ARENA".Equals(act[1]))
			{
				chat_id = "ARENA_" + SharedData.Instance().m_ArenaFightID + "_CHAT_1";
			}
			AddChatList(_event, chat_id);
			m_Canvas_Event = _event;
		}
		else if (act[0] == "GET")
		{
			bool flag2 = true;
			bool flag3 = false;
			if (act[1] == "LOOT")
			{
				List<gang_c01Table.Row> list = CommonResourcesData.c01.FindAll_ID(act[2]);
				int num = 0;
				foreach (gang_c01Table.Row item in list)
				{
					float num2 = float.Parse(item.Chance, CultureInfo.InvariantCulture);
					if (UnityEngine.Random.Range(0f, 1f) >= num2)
					{
						continue;
					}
					int num3 = 0;
					string[] array = item.QTY.Split('|');
					if (array.Length > 1)
					{
						int minInclusive = int.Parse(array[0]);
						int maxExclusive = int.Parse(array[1]) + 1;
						num3 = UnityEngine.Random.Range(minInclusive, maxExclusive);
					}
					else
					{
						num3 = int.Parse(array[0]);
					}
					if ("999".Equals(item.Item))
					{
						if (num3 > 0)
						{
							num3 = Mathf.CeilToInt((float)num3 * SharedData.Instance().m_Money_Drop_Rate);
						}
						SharedData.Instance().m_Money += num3;
						if (SharedData.Instance().m_Money < 0)
						{
							SharedData.Instance().m_Money = 0;
						}
					}
					else
					{
						SharedData.Instance().PackageAdd(item.Item, num3);
					}
					num++;
					string explore = "GET|ITEM|" + item.Item + "|" + num3;
					AddExploreList(explore);
				}
				if (num <= 0)
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_NextTime"));
				}
				if ("END".Equals(_event.evdata.output) && _event.obj != null)
				{
					if (m_HoldCamera == _event.obj)
					{
						PlayerTakeCamera();
					}
					mapUnits.Remove(_event.obj.name);
					UnityEngine.Object.Destroy(_event.obj);
					_event.obj = null;
				}
				m_Canvas_Event = _event;
			}
			else if (act[1] == "ATTR")
			{
				CharaData charaData = player.charadata;
				if (act.Length > 4)
				{
					charaData = SharedData.Instance().GetCharaData(act[4]);
				}
				if (act[2] == "TALENT")
				{
					charaData.m_Talent += Mathf.FloorToInt(float.Parse(act[3], CultureInfo.InvariantCulture));
					int num4 = int.Parse(SharedData.Instance().m_A01NameRowDirec["TALENT"].Limit);
					if (charaData.m_Talent > num4)
					{
						charaData.m_Talent = num4;
					}
				}
				else if (act[2] == "LV")
				{
					charaData.m_Level += Mathf.FloorToInt(float.Parse(act[3], CultureInfo.InvariantCulture));
					int num5 = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
					if (charaData.m_Level > num5)
					{
						charaData.m_Level = num5;
					}
					charaData.m_Exp = 0;
				}
				else if (act[2] == "RANK")
				{
					if ("+".Equals(act[3]))
					{
						charaData.m_Ranking++;
					}
					else if ("-".Equals(act[3]))
					{
						charaData.m_Ranking--;
					}
					else
					{
						charaData.m_Ranking = Mathf.FloorToInt(float.Parse(act[3], CultureInfo.InvariantCulture));
					}
					if (charaData.m_Ranking < 1)
					{
						charaData.m_Ranking = 1;
					}
				}
				else
				{
					charaData.Indexs_Name[act[2]].juqingValue += Mathf.Floor(float.Parse(act[3], CultureInfo.InvariantCulture));
					if (act[2] == "HP")
					{
						if (charaData.m_Hp > charaData.GetFieldValueByName("HP"))
						{
							charaData.m_Hp = charaData.GetFieldValueByName("HP");
						}
					}
					else if (act[2] == "MP" && charaData.m_Mp > charaData.GetFieldValueByName("MP"))
					{
						charaData.m_Mp = charaData.GetFieldValueByName("MP");
					}
				}
			}
			else if (act[1] == "EPIPHANY")
			{
				SharedData.Instance().m_Epiphany += Mathf.FloorToInt(float.Parse(act[2], CultureInfo.InvariantCulture));
			}
			else if (act[1] == "OPINION")
			{
				CharaData charaData2 = SharedData.Instance().GetCharaData(act[2]);
				if (charaData2 != null)
				{
					int num6 = int.Parse(act[3]);
					charaData2.m_Relationship += num6;
					Debug.Log(charaData2.Indexs_Name["Name"].stringValue + " m_Relationship = " + charaData2.m_Relationship);
				}
			}
			else if (act[1] == "TRAIT")
			{
				if (act[2] == "PLAYER")
				{
					if (act[4] == "+")
					{
						if (!player.charadata.m_TraitList.Contains(act[3]))
						{
							player.charadata.AddTraits(act[3]);
							gang_b06Table.Row row = CommonResourcesData.b06.Find_id(act[3]);
							if ("1".Equals(row.isLockTrait))
							{
								player.charadata.m_EquipTraitDict[row.traitEquipIndex] = row.id;
							}
							GameDataManager.Instance().AddUnlockAtlasList(act[3], "b06");
						}
						else
						{
							flag2 = false;
						}
					}
					else if (player.charadata.m_TraitList.Contains(act[3]))
					{
						player.charadata.RemoveTrait(act[3]);
					}
					else
					{
						flag2 = false;
					}
				}
				else
				{
					CharaData charaData3 = SharedData.Instance().GetCharaData(act[2]);
					if (charaData3 != null)
					{
						if (act[4] == "+")
						{
							if (!charaData3.m_TraitList.Contains(act[3]))
							{
								charaData3.AddTraits(act[3]);
								gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(act[3]);
								if ("1".Equals(row2.isLockTrait))
								{
									charaData3.m_EquipTraitDict[row2.traitEquipIndex] = row2.id;
								}
								GameDataManager.Instance().AddUnlockAtlasList(act[3], "b06");
							}
							else
							{
								flag2 = false;
							}
						}
						else if (charaData3.m_TraitList.Contains(act[3]))
						{
							charaData3.RemoveTrait(act[3]);
						}
						else
						{
							flag2 = false;
						}
					}
				}
			}
			else if (act[1] == "ITEM")
			{
				if ("ARENA".Equals(act[2]))
				{
					string[] array2 = SharedData.Instance().m_Arena_RewardsID_JunShan.Split('|');
					List<int> list2 = new List<int>();
					for (int i = 0; i < array2.Length; i++)
					{
						if (SharedData.Instance().m_Arena_Rewards_JunShan[i] == '0')
						{
							list2.Add(i);
						}
					}
					if (list2.Count > 0)
					{
						int index = UnityEngine.Random.Range(0, list2.Count);
						act[2] = array2[list2[index]];
						act[3] = "1";
						char[] array3 = SharedData.Instance().m_Arena_RewardsID_JunShan.ToCharArray();
						array3[list2[index]] = '1';
						SharedData.Instance().m_Arena_RewardsID_JunShan = new string(array3);
						Debug.LogWarning("SharedData.Instance().m_Arena_RewardsID_JunShan update: " + SharedData.Instance().m_Arena_RewardsID_JunShan);
					}
					else
					{
						act[2] = "999";
						act[3] = "1000";
					}
				}
				if (act[2] == "999")
				{
					float num7 = float.Parse(act[3], CultureInfo.InvariantCulture);
					int num8 = Mathf.CeilToInt(num7);
					if (num7 > 0f)
					{
						num8 = Mathf.CeilToInt(num7 * SharedData.Instance().m_Money_Drop_Rate);
					}
					SharedData.Instance().m_Money += num8;
					if (SharedData.Instance().m_Money < 0)
					{
						SharedData.Instance().m_Money = 0;
					}
					flag3 = true;
					AddExploreList("GET|ITEM|999|" + num8);
					m_Canvas_Event = _event;
				}
				else
				{
					int num9 = 0;
					num9 = ((!"PLAYROUND".Equals(act[3])) ? int.Parse(act[3]) : Mathf.Min(GameDataManager.Instance().configdata.playRound + 1, 9));
					bool flag4 = SharedData.Instance().PackageAdd(act[2], num9);
					if (!"-99999".Equals(act[3]))
					{
						flag3 = true;
						if (!flag4)
						{
							AddExploreList("GET|ITEM|" + act[2] + "|" + num9);
							m_Canvas_Event = _event;
						}
					}
				}
				if ("END".Equals(_event.evdata.output) && _event.obj != null)
				{
					if (m_HoldCamera == _event.obj)
					{
						PlayerTakeCamera();
					}
					mapUnits.Remove(_event.obj.name);
					UnityEngine.Object.Destroy(_event.obj);
					_event.obj = null;
				}
			}
			else if (act[1] == "INHERIT")
			{
				getInheritItems();
			}
			else if (act[1] == "WUGONG")
			{
				if (act[2] == "PLAYER")
				{
					if (act[4] == "+")
					{
						if (player.charadata.GetKongFuByID(act[3]) == null)
						{
							KongFuData kongFuData = new KongFuData();
							kongFuData.kf = CommonResourcesData.b03.Find_ID(act[3]);
							kongFuData.lv = 1;
							kongFuData.exp = 0f;
							kongFuData.proficiency = 0;
							player.charadata.KongFuListAdd(kongFuData);
						}
						else
						{
							flag2 = false;
						}
					}
					else
					{
						KongFuData kongFuByID = player.charadata.GetKongFuByID(act[3]);
						if (kongFuByID != null)
						{
							player.charadata.KongFuListRemove(kongFuByID);
						}
						else
						{
							flag2 = false;
						}
					}
				}
				else
				{
					CharaData charaData4 = SharedData.Instance().GetCharaData(act[2]);
					if (charaData4 != null)
					{
						if (act[4] == "+")
						{
							if (charaData4.GetKongFuByID(act[3]) == null)
							{
								KongFuData kongFuData2 = new KongFuData();
								kongFuData2.kf = CommonResourcesData.b03.Find_ID(act[3]);
								kongFuData2.lv = 1;
								kongFuData2.exp = 0f;
								kongFuData2.proficiency = 0;
								charaData4.KongFuListAdd(kongFuData2);
							}
							else
							{
								flag2 = false;
							}
						}
						else
						{
							KongFuData kongFuByID2 = charaData4.GetKongFuByID(act[3]);
							if (kongFuByID2 != null)
							{
								charaData4.KongFuListRemove(kongFuByID2);
							}
							else
							{
								flag2 = false;
							}
						}
					}
				}
			}
			if (act[1] != "LOOT")
			{
				if (flag2)
				{
					if (!flag3)
					{
						AddExploreList(_action);
						m_Canvas_Event = _event;
					}
				}
				else
				{
					EventComplete(_event);
				}
			}
		}
		else if (act[0] == "WANTED")
		{
			AddExploreList(_action);
			m_Canvas_Event = _event;
		}
		else if (act[0] == "VOICEOVER")
		{
			AddExploreList(_action);
			m_Canvas_Event = _event;
		}
		else if (act[0] == "BROWSEURL")
		{
			AddExploreList(_action);
			m_Canvas_Event = _event;
		}
		else if (act[0] == "GUIDE")
		{
			AddExploreList(_action);
			m_Canvas_Event = _event;
		}
		else if (act[0] == "INFO")
		{
			List<gang_e02Table.Row> list3 = CommonResourcesData.e02.FindAll_chatid(act[1]);
			if (list3.Count <= 0)
			{
				AddExploreList("INFO|" + act[1]);
			}
			else
			{
				foreach (gang_e02Table.Row item2 in list3)
				{
					AddExploreList("INFO|" + item2.chating_Trans);
				}
			}
			m_Canvas_Event = _event;
		}
		else if (act[0] == "CHANGETEAM")
		{
			EventComplete(_event);
			LoadSceneAdditive("BeforeTeam");
		}
		else if (act[0] == "EXPELTEAM")
		{
			EventComplete(_event);
			SharedData.Instance().SubdueManageFor = "Expel";
			LoadSceneAdditive("SubdueManage");
		}
		else if (act[0] == "CURE")
		{
			int num10 = int.Parse(act[1]);
			if (num10 > SharedData.Instance().m_Money)
			{
				AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_InsufficientMoneyToCure"));
			}
			else
			{
				bool flag5 = IsCharaNeedCure(player.charadata);
				if (!flag5)
				{
					foreach (string follow in SharedData.Instance().FollowList)
					{
						CharaData charaData5 = SharedData.Instance().GetCharaData(follow);
						flag5 = IsCharaNeedCure(charaData5);
						if (flag5)
						{
							break;
						}
					}
				}
				if (flag5)
				{
					SharedData.Instance().m_Money -= num10;
					player.charadata.Indexs_Name["Drunk"].fightValue = 0f;
					player.charadata.Indexs_Name["Hurt"].fightValue = 0f;
					player.charadata.Indexs_Name["Poison"].fightValue = 0f;
					player.charadata.Indexs_Name["Bleed"].fightValue = 0f;
					player.charadata.Indexs_Name["Burn"].fightValue = 0f;
					player.charadata.Indexs_Name["Seal"].fightValue = 0f;
					player.charadata.Indexs_Name["Mad"].fightValue = 0f;
					foreach (string follow2 in SharedData.Instance().FollowList)
					{
						CharaData charaData6 = SharedData.Instance().GetCharaData(follow2);
						charaData6.Indexs_Name["Drunk"].fightValue = 0f;
						charaData6.Indexs_Name["Hurt"].fightValue = 0f;
						charaData6.Indexs_Name["Poison"].fightValue = 0f;
						charaData6.Indexs_Name["Bleed"].fightValue = 0f;
						charaData6.Indexs_Name["Burn"].fightValue = 0f;
						charaData6.Indexs_Name["Seal"].fightValue = 0f;
						charaData6.Indexs_Name["Mad"].fightValue = 0f;
					}
					if (num10 <= 0)
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Cured_1"));
					}
					else
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Cured_2") + num10 + CommonFunc.I18nGetLocalizedValue("I18N_Money_2"));
					}
				}
				else
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_NoNeedCure"));
				}
			}
			m_Canvas_Event = _event;
		}
		else if (act[0] == "ELIXIR")
		{
			ElixirChara(act[1]);
			EventComplete(_event);
		}
		else if (act[0] == "REST")
		{
			int num11 = int.Parse(act[1]);
			if (num11 > SharedData.Instance().m_Money)
			{
				AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_InsufficientMoneyToStay"));
			}
			else
			{
				SharedData.Instance().m_Money -= num11;
				ElixirChara("ALL");
				if (num11 <= 0)
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Restored_1"));
				}
				else
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Restored_2") + " " + num11 + CommonFunc.I18nGetLocalizedValue("I18N_Money_2"));
				}
			}
			m_Canvas_Event = _event;
		}
		else if (act[0] == "SAVEDATA")
		{
			EventComplete(_event);
			SaveMapSnapShot();
			m_Menu3.Close();
			SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
			SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Save;
			SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
		}
		else if (act[0] == "CALLSCENE")
		{
			EventComplete(_event);
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			LoadSceneAdditive(act[1]);
		}
		else if (act[0] == "FLAG")
		{
			if (act[1] == "INIT")
			{
				if (SharedData.Instance().FlagList.ContainsKey(act[2]))
				{
					SharedData.Instance().FlagList[act[2]] = 0;
				}
			}
			else if (act[1] == "OPEN")
			{
				if (SharedData.Instance().FlagList.ContainsKey(act[2]))
				{
					SharedData.Instance().FlagList[act[2]] = 1;
				}
			}
			else if (act[1] == "CLOSE")
			{
				if (SharedData.Instance().FlagList.ContainsKey(act[2]))
				{
					SharedData.Instance().FlagList[act[2]] = 2;
				}
			}
			else if (act[1] == "SET")
			{
				if (SharedData.Instance().FlagList.ContainsKey(act[2]))
				{
					SharedData.Instance().FlagList[act[2]] = int.Parse(act[3]);
				}
			}
			else if (act[1] == "ADD")
			{
				if (SharedData.Instance().FlagList.ContainsKey(act[2]))
				{
					SharedData.Instance().FlagList[act[2]]++;
				}
			}
			else if (act[1] == "SUB" && SharedData.Instance().FlagList.ContainsKey(act[2]))
			{
				SharedData.Instance().FlagList[act[2]]--;
			}
			EventComplete(_event);
		}
		else if (act[0] == "EVENT")
		{
			if (act[1] == "OPEN")
			{
				OpenEvent(act[2]);
			}
			else if (act[1] == "ACTIVEOPEN")
			{
				OpenEvent(act[2], _active: true);
			}
			else if (act[1] == "EOFACTIVEOPEN")
			{
				InitEOFEvents(act[2]);
				OpenEvent(act[2], _active: true);
			}
			else if (act[1] == "CLOSE")
			{
				CloseEvent(act[2]);
			}
			EventComplete(_event);
		}
		else if (act[0] == "UPDATEPLAYROUND")
		{
			if (SharedData.Instance().m_PlayRound > GameDataManager.Instance().configdata.playRound)
			{
				GameDataManager.Instance().configdata.playRound = SharedData.Instance().m_PlayRound;
				GameDataManager.Instance().SaveConfig();
			}
			EventComplete(_event);
		}
		else if (act[0] == "UPDATEARENAWINCOUNT")
		{
			SharedData.Instance().m_ArenaWinCount++;
			EventComplete(_event);
		}
		else if (act[0] == "MOVIE")
		{
			string[] array4 = act[1].Split('#');
			int num12 = 0;
			m_Menu3.Close();
			string[] array5 = array4;
			for (int j = 0; j < array5.Length; j++)
			{
				string[] array6 = array5[j].Split('$');
				if (array6[0] == "MOVE")
				{
					if (array6[1] == "PLAYER")
					{
						if (array6.Length > 3)
						{
							player.MovingSpeedRate = float.Parse(array6[3], CultureInfo.InvariantCulture);
						}
						player.PlaySceneMove(array6[2]);
						player.m_ScenePlay = 1;
						player.m_MovieMove = true;
						num12++;
						continue;
					}
					Event eventById = GetEventById(array6[1]);
					if (eventById != null && eventById.obj != null)
					{
						EventController component = eventById.obj.GetComponent<EventController>();
						if (array6.Length > 3)
						{
							component.MovingSpeedRate = float.Parse(array6[3], CultureInfo.InvariantCulture);
						}
						component.PlaySceneMove(array6[2]);
						component.m_ScenePlay = 1;
						num12 = (component.m_MovieCutID = num12 + 1);
						component.m_MovieEvent = _event;
					}
				}
				else
				{
					if (!(array6[0] == "PLAYANI"))
					{
						continue;
					}
					bool isLoop = false;
					if (array6.Length > 4)
					{
						isLoop = "LOOP".Equals(array6[4]);
					}
					float timescale = 1f;
					if (array6.Length > 5)
					{
						timescale = float.Parse(array6[5], CultureInfo.InvariantCulture);
					}
					if (array6[1] == "PLAYER")
					{
						player.m_KeepAnimation = false;
						player.PlayAnimation(array6[2], loop: true, compensate: false, timescale);
						player.m_IsLoop = isLoop;
						if (array6[3] != "0")
						{
							player.Idle(array6[3]);
							num12++;
						}
						continue;
					}
					Event eventById2 = GetEventById(array6[1]);
					if (eventById2 != null && eventById2.obj != null)
					{
						eventById2.obj.GetComponent<EventController>().m_KeepAnimation = false;
						eventById2.obj.GetComponent<EventController>().PlayAnimation(array6[2], loop: true, compensate: false, timescale);
						eventById2.obj.GetComponent<EventController>().m_IsLoop = isLoop;
						if (array6[3] != "0")
						{
							eventById2.obj.GetComponent<EventController>().Idle(array6[3]);
							num12++;
							eventById2.obj.GetComponent<EventController>().m_MovieCutID = num12;
							eventById2.obj.GetComponent<EventController>().m_MovieEvent = _event;
						}
					}
				}
			}
		}
		else if (act[0] == "MOVE")
		{
			m_Menu3.Close();
			if (act[1] == "PLAYER")
			{
				if (act.Length > 3)
				{
					player.MovingSpeedRate = float.Parse(act[3], CultureInfo.InvariantCulture);
				}
				if (act.Length > 4 && "MULTI".Equals(act[4]))
				{
					player.PlaySceneMove(act[2], _event);
				}
				else
				{
					player.PlaySceneMove(act[2]);
					player.m_ScenePlay = 1;
				}
				m_Current_Event = _event;
			}
			else if (act[1] == "THIS")
			{
				if (act.Length > 3)
				{
					_eventcontroller.MovingSpeedRate = float.Parse(act[3], CultureInfo.InvariantCulture);
				}
				if (act.Length > 4 && "MULTI".Equals(act[4]))
				{
					_eventcontroller.PlaySceneMove(act[2], _event);
				}
				else
				{
					_eventcontroller.PlaySceneMove(act[2]);
					_eventcontroller.m_ScenePlay = 1;
				}
			}
			else
			{
				Event eventById3 = GetEventById(act[1]);
				if (eventById3 != null && eventById3.obj != null)
				{
					EventController component2 = eventById3.obj.GetComponent<EventController>();
					if (act.Length > 3)
					{
						component2.MovingSpeedRate = float.Parse(act[3], CultureInfo.InvariantCulture);
					}
					if (act.Length > 4 && "MULTI".Equals(act[4]))
					{
						component2.PlaySceneMove(act[2], _event);
					}
					else
					{
						component2.PlaySceneMove(act[2]);
						component2.m_ScenePlay = 1;
					}
				}
			}
		}
		else if (act[0] == "WARP")
		{
			if (act[1] == "PLAYER")
			{
				if ("ZERO".Equals(act[2]))
				{
					player.WarpTo(Vector3.zero);
				}
				else
				{
					SuperObject superObject = getByName(act[2])[0];
					player.WarpTo(superObject.transform.position);
				}
			}
			else
			{
				Event eventById4 = GetEventById(act[1]);
				if (eventById4 != null && eventById4.obj != null)
				{
					EventController component3 = eventById4.obj.GetComponent<EventController>();
					if ("ZERO".Equals(act[2]))
					{
						component3.WarpTo(Vector3.zero);
					}
					else if ("PLAYER".Equals(act[2]))
					{
						component3.WarpTo(player.transform.position);
					}
					else
					{
						SuperObject superObject2 = getByName(act[2])[0];
						component3.WarpTo(superObject2.transform.position);
					}
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "TELEPORT")
		{
			IsTeleport = true;
			m_Menu3.Close();
			EventComplete(_event);
			if (act[1] == "RETURNTOSCENE")
			{
				SharedData.Instance().BackFromOtherScene = true;
				LoadScene(SharedData.Instance().SceneBefore);
			}
			else if (act[1] == "GAMEOVER")
			{
				LoadScene("Title");
			}
			else if (act[1] == "THISMAP")
			{
				SharedData.Instance().SpawnPoint = act[2];
				if (act[2][0] == '@')
				{
					string text = act[2][1..];
					if (text == "PLAYER")
					{
						SharedData.Instance().Mark_Position = player.transform.position;
						SharedData.Instance().Mark_Direction = player.GetMonoDirection();
					}
					else
					{
						Event eventById5 = GetEventById(text);
						SharedData.Instance().Mark_Position = eventById5.eventController.transform.position;
						SharedData.Instance().Mark_Direction = eventById5.eventController.GetMonoDirection();
					}
				}
				SharedData.Instance().SpawnStatus = "Normal";
				if (act.Length > 3)
				{
					SharedData.Instance().SpawnStatus = act[3];
				}
				LoadScene(sceneName);
			}
			else
			{
				if (_event.evdata.trigger == "FOOTON")
				{
					AutoGameSaveController.instance.AutoSave();
				}
				SharedData.Instance().SpawnPoint = act[2];
				SharedData.Instance().SpawnStatus = "Normal";
				if (act.Length > 3)
				{
					SharedData.Instance().SpawnStatus = act[3];
				}
				LoadScene(act[1]);
			}
		}
		else if (act[0] == "LEAVEFACTIONMAP")
		{
			EventComplete(_event);
			SharedData.Instance().SpawnMapName = act[1];
			SharedData.Instance().SpawnPoint = act[2];
			SharedData.Instance().SpawnStatus = "Normal";
			if (act.Length > 3)
			{
				SharedData.Instance().SpawnStatus = act[3];
			}
			LoadSceneAdditive("BeforeTeam");
		}
		else if (act[0] == "PLAYSE")
		{
			PlaySoundEffect(act[1], act[2], _event);
		}
		else if (act[0] == "PLAYBGM")
		{
			FieldBGM = CommonResourcesData.LoadBgm(act[1]);
			PlayBGM();
			EventComplete(_event);
		}
		else if (act[0] == "PLAYCG")
		{
			EventComplete(_event);
			SaveMapSnapShot();
			SharedData.Instance().PlayCGName = act[1];
			if (act.Length > 2)
			{
				SharedData.Instance().PlayCGBGM = act[2];
			}
			SharedData.Instance().AfterCGPlayComplete = _event.evdata.flag + "_COMPLETE";
			SharedData.Instance().BackFromOtherScene = false;
			SceneManager.LoadScene("CGPlayer");
		}
		else if (act[0] == "ENDPUSH")
		{
			SharedData.Instance().m_EndAVGFIFO.Add(act[1]);
			EventComplete(_event);
		}
		else if (act[0] == "ENDAVG")
		{
			if (SharedData.Instance().m_PlayRound > GameDataManager.Instance().configdata.playRound)
			{
				GameDataManager.Instance().configdata.playRound = SharedData.Instance().m_PlayRound;
				GameDataManager.Instance().SaveConfig();
			}
			EventComplete(_event);
			SaveMapSnapShot();
			SharedData.Instance().PlayCGName = act[1];
			SharedData.Instance().AfterCGPlayComplete = _event.evdata.flag + "_COMPLETE";
			SharedData.Instance().BackFromOtherScene = false;
			SceneManager.LoadScene("AVGEngine");
		}
		else if (act[0] == "ARENA")
		{
			List<gang_b11Table.Row> list4 = CommonResourcesData.b11.FindAll_Arena(act[1]);
			if (list4 != null && list4.Count > 0)
			{
				foreach (gang_b11Table.Row item3 in list4)
				{
					if (item3.Wave.Equals(act[2]))
					{
						string[] array7 = item3.Members.Split('|');
						int num13 = UnityEngine.Random.Range(0, array7.Length);
						SharedData.Instance().m_ArenaFightID = array7[num13];
						Debug.LogWarning("SharedData.Instance().m_ArenaFightID = " + SharedData.Instance().m_ArenaFightID);
						break;
					}
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "BATTLE")
		{
			EventComplete(_event);
			SaveMapSnapShot();
			SharedData.Instance().BattleEnemyGroupId = act[2];
			if (act.Length > 3)
			{
				SharedData.Instance().BattleMemberMax = int.Parse(act[3]);
			}
			else
			{
				SharedData.Instance().BattleMemberMax = 3;
			}
			SharedData.Instance().BattleGround = act[1];
			SharedData.Instance().BattleItemGroupId = _event.evdata.menu;
			SharedData.Instance().AfterBattleWin = _event.evdata.flag + "_WIN";
			SharedData.Instance().AfterBattleLose = _event.evdata.flag + "_LOSE";
			SharedData.Instance().BackFromOtherScene = false;
			SharedData.Instance().PlayerSetting.Clear();
			SharedData.Instance().EnemySetting.Clear();
			enemygid = SharedData.Instance().BattleEnemyGroupId.Split('-');
			if (enemygid[0] == "solo")
			{
				SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
				LoadScene(act[1], isBattle: true);
			}
			else if (enemygid[0] == "demo")
			{
				SharedData.Instance().b04BattleID = enemygid[1];
				LoadScene(act[1], isBattle: true);
			}
			else if (enemygid[0] == "event")
			{
				if (act.Length > 3 && act[3] == "1")
				{
					ElixirChara("ALL");
				}
				SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
				SharedData.Instance().b04BattleID = enemygid[1];
				SharedData.Instance().m_EventShow = true;
				LoadScene(act[1], isBattle: true);
			}
			else if (enemygid[0] == "chara")
			{
				SharedData.Instance().PlayerSetting.Add("Player1", enemygid[2]);
				SharedData.Instance().b04BattleID = enemygid[1];
				SharedData.Instance().m_EventShow = true;
				LoadScene(act[1], isBattle: true);
			}
			else if (enemygid[0] == "arena")
			{
				SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
				SharedData.Instance().b04BattleID = SharedData.Instance().m_ArenaFightID;
				SharedData.Instance().m_EventShow = true;
				LoadScene(act[1], isBattle: true);
			}
			else
			{
				if (act.Length > 4 && act[4] == "1")
				{
					ElixirChara("ALL");
				}
				if (enemygid.Length > 1 && "force".Equals(enemygid[1]))
				{
					SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
					SharedData.Instance().BattleMemberMax++;
					SharedData.Instance().isChooseBattle = false;
				}
				SharedData.Instance().b04BattleID = enemygid[0];
				LoadScene("BeforeBattle", isBattle: true);
			}
		}
		else if (act[0] == "DESTROY")
		{
			if (act[1] == "THIS")
			{
				if (_event.obj != null)
				{
					if (m_HoldCamera == _event.obj)
					{
						PlayerTakeCamera();
					}
					if ("HOVER".Equals(_event.originevdata.trigger))
					{
						Vector3Int gridPosition = _event.obj.GetComponent<EventController>().GetGridPosition();
						if (obstacle.Contains(gridPosition))
						{
							Vector3Int vector3Int = gridPosition;
							MonoBehaviour.print("HOVER remove obstacle position(2.1): [" + vector3Int.ToString() + "]");
							obstacle.Remove(gridPosition);
						}
					}
					mapUnits.Remove(_event.obj.name);
					UnityEngine.Object.Destroy(_event.obj);
					_event.obj = null;
				}
			}
			else
			{
				string[] array5 = act[1].Split('&');
				foreach (string ids in array5)
				{
					Event eventById6 = GetEventById(ids);
					if (eventById6 == null || !(eventById6.obj != null))
					{
						continue;
					}
					if (m_HoldCamera == eventById6.obj)
					{
						PlayerTakeCamera();
					}
					if ("HOVER".Equals(eventById6.originevdata.trigger))
					{
						Vector3Int gridPosition2 = eventById6.obj.GetComponent<EventController>().GetGridPosition();
						if (obstacle.Contains(gridPosition2))
						{
							Vector3Int vector3Int = gridPosition2;
							MonoBehaviour.print("HOVER remove obstacle position(2.2): [" + vector3Int.ToString() + "]");
							obstacle.Remove(gridPosition2);
						}
					}
					mapUnits.Remove(eventById6.obj.name);
					UnityEngine.Object.Destroy(eventById6.obj);
					eventById6.obj = null;
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "HIDE")
		{
			if (act[1] == "PLAYER")
			{
				player.Hide();
			}
			else if (act[1] == "THIS")
			{
				if (_event.obj != null)
				{
					if (m_HoldCamera == _event.obj)
					{
						PlayerTakeCamera();
					}
					_event.obj.GetComponent<EventController>().Hide();
				}
			}
			else
			{
				Event eventById7 = GetEventById(act[1]);
				if (eventById7 != null && eventById7.obj != null)
				{
					if (m_HoldCamera == eventById7.obj)
					{
						PlayerTakeCamera();
					}
					eventById7.obj.GetComponent<EventController>().Hide();
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "SHOW")
		{
			if (act[1] == "PLAYER")
			{
				player.Show();
			}
			else if (act[1] == "THIS")
			{
				_event.obj.GetComponent<EventController>().Show();
			}
			else
			{
				Event eventById8 = GetEventById(act[1]);
				if (eventById8 != null && eventById8.obj != null)
				{
					eventById8.obj.GetComponent<EventController>().Show();
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "JOIN")
		{
			JoinTeam(act[1]);
			ElixirChara(act[1]);
			EventComplete(_event);
		}
		else if (act[0] == "SPECIALONLY")
		{
			SpecialJoinTeamProcess(act[1]);
			EventComplete(_event);
		}
		else if (act[0] == "SPECIALJOIN")
		{
			JoinTeam(act[1], isSpecial: true);
			ElixirChara(act[1]);
			EventComplete(_event);
		}
		else if (act[0] == "FOLLOW")
		{
			if (SharedData.Instance().FullTeam.Contains(act[1]) && SharedData.Instance().FollowList.Count < SharedData.Instance().FollowMaxCount && !SharedData.Instance().FollowList.Contains(act[1]))
			{
				SharedData.Instance().FollowList.Add(act[1]);
				GameDataManager.Instance().AddUnlockAtlasList(act[1], "b01");
				SharedData.Instance().player.InitFollows();
			}
			EventComplete(_event);
		}
		else if (act[0] == "UNFOLLOW")
		{
			if ("ALL".Equals(act[1]))
			{
				SharedData.Instance().FollowList.Clear();
				SharedData.Instance().player.InitFollows();
			}
			else if (SharedData.Instance().FollowList.Contains(act[1]))
			{
				SharedData.Instance().FollowList.Remove(act[1]);
				SharedData.Instance().player.InitFollows();
			}
			EventComplete(_event);
		}
		else if (act[0] == "GATHERFOLLOWER")
		{
			SharedData.Instance().player.GatherFollower();
			EventComplete(_event);
		}
		else if (act[0] == "LOSTMONEY")
		{
			float num14 = SharedData.Instance().m_Money;
			int num15 = 0;
			if ("HALF".Equals(act[1]))
			{
				num15 = Mathf.RoundToInt(num14 / 2f);
				SharedData.Instance().FlagList["ROB_MONEY"] = num15;
			}
			else if ("ONETENTH".Equals(act[1]))
			{
				num15 = Mathf.RoundToInt(num14 / 10f);
				SharedData.Instance().FlagList["ROB_MONEY"] = num15;
			}
			else if ("ALL".Equals(act[1]))
			{
				num15 = Mathf.RoundToInt(num14);
				SharedData.Instance().FlagList["ROB_MONEY"] = num15;
			}
			else if ("RETURN".Equals(act[1]))
			{
				num15 = -1 * SharedData.Instance().FlagList["ROB_MONEY"];
				SharedData.Instance().FlagList["ROB_MONEY"] = 0;
			}
			Debug.LogWarning("Lost money " + num15);
			SharedData.Instance().m_Money -= num15;
			if (num15 >= 0)
			{
				SharedData.Instance().m_TempParas["lostmoney"] = num15.ToString();
			}
			else
			{
				SharedData.Instance().m_TempParas["returnmoney"] = Mathf.Abs(num15).ToString();
			}
			EventComplete(_event);
		}
		else if (act[0] == "OPENLAYER")
		{
			SuperTileLayer superTileLayer = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>(includeInactive: true).FirstOrDefault((SuperTileLayer s) => s.name == act[1]);
			if (superTileLayer != null)
			{
				superTileLayer.gameObject.SetActive(value: true);
			}
			EventComplete(_event);
		}
		else if (act[0] == "CLOSELAYER")
		{
			SuperTileLayer superTileLayer2 = UnityEngine.Object.FindObjectsOfType<SuperTileLayer>().FirstOrDefault((SuperTileLayer s) => s.name == act[1]);
			if (superTileLayer2 != null)
			{
				superTileLayer2.gameObject.SetActive(value: false);
			}
			EventComplete(_event);
		}
		else if (act[0] == "LEAVE")
		{
			bool reteamable = act.Length > 2 && "RETEAM".Equals(act[2]);
			if ("ALL".Equals(act[1]))
			{
				string[] array5 = SharedData.Instance().FullTeam.ToArray();
				foreach (string text2 in array5)
				{
					LeaveTeam(text2, reteamable);
					if (act.Length > 2 && "MEMO".Equals(act[2]))
					{
						string key = "GLOBAL_FLAGS_CHA_" + text2;
						SharedData.Instance().FlagList[key] = 2;
					}
				}
				SharedData.Instance().FollowList.Clear();
			}
			else
			{
				LeaveTeam(act[1], reteamable);
			}
			SharedData.Instance().player.InitFollows();
			EventComplete(_event);
		}
		else if (act[0] == "SELECT")
		{
			string ask = "null";
			if (act.Length > 2)
			{
				ask = act[2];
			}
			PlaySoundEffect("Talk", "0", null);
			if ("EQOPERATOR".Equals(act[1]))
			{
				string text3 = SharedData.Instance().playerid;
				foreach (string follow3 in SharedData.Instance().FollowList)
				{
					text3 = text3 + "&" + follow3;
				}
				m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, text3, 1);
			}
			else if ("WGOPERATOR".Equals(act[1]))
			{
				string text4 = SharedData.Instance().playerid;
				foreach (string follow4 in SharedData.Instance().FollowList)
				{
					text4 = text4 + "&" + follow4;
				}
				m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, text4, 2);
			}
			else if ("TEAMLIST".Equals(act[1]))
			{
				string text5 = SharedData.Instance().playerid;
				foreach (string follow5 in SharedData.Instance().FollowList)
				{
					text5 = text5 + "&" + follow5;
				}
				m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, text5, 3);
			}
			else
			{
				m_Selector.GetComponent<SelectorController>().Open(player.charadata.Indexs_Name["Name"].stringValue, ask, _event.evdata.flag, act[1]);
			}
			m_Menu3.Close();
			EventComplete(_event);
		}
		else if (act[0] == "CHECKFINALLOVERS")
		{
			string text6 = _event.evdata.flag + "_" + CheckFinalLover();
			MonoBehaviour.print("CHECKFINALLOVERS 1 nextflag -> " + text6);
			SetNextFlag(text6, _event.evdata.trigger == "AUTO");
			EventComplete(_event);
		}
		else if (act[0] == "CHGROOT")
		{
			if (!act[1].Equals(SharedData.Instance().m_TempParas["has_trait"]))
			{
				bool flag6 = false;
				if ("10126".Equals(act[1]))
				{
					if (SharedData.Instance().PlayerPackage.ContainsKey("997") && SharedData.Instance().PlayerPackage["997"] >= 20)
					{
						SharedData.Instance().PlayerPackage["997"] -= 20;
						flag6 = true;
					}
				}
				else if (SharedData.Instance().PlayerPackage.ContainsKey("998") && SharedData.Instance().PlayerPackage["998"] >= 20)
				{
					SharedData.Instance().PlayerPackage["998"] -= 20;
					flag6 = true;
				}
				if (flag6)
				{
					player.charadata.RemoveTrait(SharedData.Instance().m_TempParas["has_trait"]);
					player.charadata.AddTraits(act[1]);
					gang_b06Table.Row row3 = CommonResourcesData.b06.Find_id(act[1]);
					if (row3 != null)
					{
						AddExploreList("INFO|" + string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Change_Roots"), row3.name_Trans));
					}
				}
				else
				{
					AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Change_Roots_Poor"));
				}
			}
			else
			{
				AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Change_Roots_duplicate"));
			}
			EventComplete(_event);
		}
		else if (act[0] == "SWITCH")
		{
			int num16 = 1;
			string[] array5 = act[1].Split('+');
			foreach (string text7 in array5)
			{
				if (text7.Contains(">"))
				{
					string[] array8 = text7.Split('>');
					float num17 = 0f;
					if (SharedData.Instance().PlayerPackage.ContainsKey(array8[0]))
					{
						num17 = SharedData.Instance().PlayerPackage[array8[0]];
					}
					float num18 = float.Parse(array8[1], CultureInfo.InvariantCulture);
					if (num17 > num18)
					{
						break;
					}
				}
				else if (text7.Contains("="))
				{
					string[] array9 = text7.Split('=');
					if ("BORNID".Equals(array9[0]) && array9[1].Equals(SharedData.Instance().BornID))
					{
						break;
					}
					if ("HASTRAIT".Equals(array9[0]) && SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_TraitList.Contains(array9[1]))
					{
						SharedData.Instance().m_TempParas["has_trait"] = array9[1];
						break;
					}
				}
				else
				{
					int num19 = 2;
					if (act.Length > 2)
					{
						num19 = int.Parse(act[2]);
					}
					if (SharedData.Instance().FlagList[text7] == num19)
					{
						break;
					}
				}
				num16++;
			}
			string text8 = _event.evdata.flag + "_" + num16;
			MonoBehaviour.print("SWITCH 1 nextflag -> " + text8);
			SetNextFlag(text8, _event.evdata.trigger == "AUTO");
			EventComplete(_event);
		}
		else if (act[0] == "CHECK")
		{
			int num20 = 2;
			if (act[1].StartsWith("FLAGS") && act.Length == 4)
			{
				num20 = int.Parse(act[3]);
			}
			if (act[1] == "FLAGS")
			{
				string[] array10 = act[2].Split('+');
				flag = true;
				string[] array5 = array10;
				foreach (string key2 in array5)
				{
					if (SharedData.Instance().FlagList.ContainsKey(key2) && SharedData.Instance().FlagList[key2] != num20)
					{
						flag = false;
						break;
					}
				}
			}
			else if (act[1] == "FLAGSOR")
			{
				string[] array11 = act[2].Split('+');
				flag = false;
				string[] array5 = array11;
				foreach (string key3 in array5)
				{
					if (SharedData.Instance().FlagList.ContainsKey(key3) && SharedData.Instance().FlagList[key3] == num20)
					{
						flag = true;
						break;
					}
				}
			}
			else if (act[1] == "FACTION")
			{
				string guild = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Guild;
				flag = !"".Equals(guild);
				if (flag)
				{
					gang_b10Table.Row row4 = CommonResourcesData.b10.Find_ID(guild);
					SharedData.Instance().m_TempParas["faction_name"] = row4.Name_Trans;
				}
			}
			else if (act[1] == "PERMISSION")
			{
				string value = "";
				if (act.Length > 3)
				{
					value = act[3];
				}
				if (!"YYOK".Equals(value) && !"ALLOK".Equals(value) && SharedData.Instance().FlagList["GLOBAL_FLAGS_YY"] == 2)
				{
					flag = true;
					SharedData.Instance().m_TempParas["permission_denied"] = CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_YY_" + act[2]);
				}
				else if (!"JWOK".Equals(value) && !"ALLOK".Equals(value) && SharedData.Instance().FlagList["GLOBAL_FLAGS_JWWF"] == 2)
				{
					flag = true;
					SharedData.Instance().m_TempParas["permission_denied"] = CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_JW_" + act[2]);
				}
				else
				{
					string guild2 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Guild;
					flag = !"".Equals(guild2);
					if (flag)
					{
						gang_b10Table.Row row5 = CommonResourcesData.b10.Find_ID(guild2);
						SharedData.Instance().m_TempParas["permission_denied"] = CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_Faction_0") + " " + row5.Name_Trans + CommonFunc.I18nGetLocalizedValue("I18N_Permission_Denied_Faction_" + act[2]);
					}
				}
			}
			else if (act[1] == "LANG")
			{
				flag = act[2].Equals(GameDataManager.Instance().configdata.language);
			}
			else if (act[1] == "RANDOM")
			{
				flag = UnityEngine.Random.Range(0f, 1f) < float.Parse(act[2], CultureInfo.InvariantCulture);
			}
			else if (act[1] == "GAMEMODE")
			{
				flag = SharedData.Instance().m_Game_Mode == int.Parse(act[2]);
			}
			else if (act[1] == "EAPLAYER")
			{
				flag = GameDataManager.Instance().configdata.isEAPlayer;
			}
			else if (act[1] == "RANKOVER")
			{
				flag = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Ranking >= int.Parse(act[2]);
			}
			else if (act[1] == "BORNID")
			{
				flag = act[2].Equals(SharedData.Instance().BornID);
			}
			else if (act[1] == "SEX")
			{
				string value2 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).GetFieldValueByName("Sex")
					.ToString();
				flag = act[2].Equals(value2);
			}
			else if (act[1] == "INHERIT")
			{
				flag = GameDataManager.Instance().configdata.inheritItems.Length > 0;
			}
			else if (act[1] == "KONGFU")
			{
				CharaData charaData7 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
				flag = false;
				foreach (KongFuData kongFu in charaData7.m_KongFuList)
				{
					if (kongFu.kf.ID == act[2])
					{
						flag = true;
						break;
					}
				}
			}
			else if (act[1] == "EQUIPS")
			{
				CharaData charaData8 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
				string[] array12 = act[2].Split('&');
				flag = true;
				if (array12.Length == 3)
				{
					for (int l = 0; l < 3; l++)
					{
						if (!"0".Equals(array12[l]) && !charaData8.m_EquipSlot[l].Equals(array12[l]))
						{
							string[] array13 = charaData8.m_EquipSlot[l].Split('_');
							if (array13.Length < 2 || !"MB07".Equals(array13[0]) || !array13[1].Equals(array12[l]))
							{
								Debug.Log("NOT found eqid[" + array12[l] + "] in Slot-" + l + "[" + charaData8.m_EquipSlot[l] + "]");
								flag = false;
								break;
							}
						}
					}
				}
			}
			else if (act[1] == "PARA")
			{
				string[] array14 = act[2].Split('+');
				flag = true;
				string[] array5 = array14;
				for (int k = 0; k < array5.Length; k++)
				{
					string[] array15 = array5[k].Split('_');
					if ("ALL".Equals(array15[0]))
					{
						float num21 = 0f;
						float num22 = float.Parse(array15[3], CultureInfo.InvariantCulture);
						if (array15[2] == ">")
						{
							_ = CommonFunc.I18nGetLocalizedValue("I18N_Amount") + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_GreaterEqual") + "</color> <color=#f0e352>" + (num22 + 1f) + "</color>";
						}
						else if (array15[2] == "<")
						{
							_ = CommonFunc.I18nGetLocalizedValue("I18N_Amount") + "color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_LessEqual") + "</color> <color=#f0e352>" + (num22 - 1f) + "</color>";
						}
						else if (array15[2] == "=")
						{
							_ = CommonFunc.I18nGetLocalizedValue("I18N_Amount") + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + "</color> <color=#f0e352>" + num22 + "</color>";
						}
						CharaData charaData9 = null;
						charaData9 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
						num21 = charaData9.GetFieldValueByName(array15[1]);
						foreach (string follow6 in SharedData.Instance().FollowList)
						{
							charaData9 = SharedData.Instance().GetCharaData(follow6);
							num21 = ((!(array15[1] == "LV")) ? ((!(array15[1] == "HP")) ? ((!(array15[1] == "MP")) ? ((!(array15[1] == "HPLIMIT")) ? ((!(array15[1] == "MPLIMIT")) ? (num21 + charaData9.GetFieldValueByName(array15[1])) : (num21 + charaData9.GetFieldValueByName("MP"))) : (num21 + charaData9.GetFieldValueByName("HP"))) : (num21 + charaData9.m_Mp)) : (num21 + charaData9.m_Hp)) : (num21 + (float)charaData9.m_Level));
						}
						Debug.Log("Check All follower's " + array15[1] + " [" + num21 + "] " + array15[2] + " [" + num22 + "]");
						if (array15[2] == ">")
						{
							if (num21 <= num22)
							{
								flag = false;
							}
						}
						else if (array15[2] == "<")
						{
							if (num21 >= num22)
							{
								flag = false;
							}
						}
						else if (array15[2] == "=" && num21 != num22)
						{
							flag = false;
						}
						continue;
					}
					List<string> list5 = new List<string>();
					if (array15[0] == "ANY")
					{
						list5.Add(SharedData.Instance().playerid);
						list5.AddRange(SharedData.Instance().FollowList);
					}
					else if (array15[0] == "SELF")
					{
						list5.Add(SharedData.Instance().playerid);
					}
					else if (array15[0].StartsWith("SPEC"))
					{
						list5.Add(array15[0].Split('-')[1]);
					}
					else
					{
						list5.Add(array15[0]);
					}
					float num23 = 0f;
					float num24 = float.Parse(array15[3], CultureInfo.InvariantCulture);
					string text9 = "???";
					if (array15[2] == ">")
					{
						text9 = "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_GreaterEqual") + "</color> <color=#f0e352>" + (num24 + 1f) + "</color>";
					}
					else if (array15[2] == "<")
					{
						text9 = "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_LessEqual") + "</color> <color=#f0e352>" + (num24 - 1f) + "</color>";
					}
					else if (array15[2] == "=")
					{
						text9 = "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + "</color> <color=#f0e352>" + num24 + "</color>";
					}
					CharaData charaData10 = null;
					flag = false;
					foreach (string item4 in list5)
					{
						charaData10 = SharedData.Instance().GetCharaData(item4);
						num23 = ((array15[1] == "LV") ? ((float)charaData10.m_Level) : ((array15[1] == "MONEY") ? ((float)SharedData.Instance().m_Money) : ((array15[1] == "HP") ? charaData10.m_Hp : ((array15[1] == "MP") ? charaData10.m_Mp : ((array15[1] == "HPLIMIT") ? charaData10.GetFieldValueByName("HP") : ((!(array15[1] == "MPLIMIT")) ? charaData10.GetFieldValueByName(array15[1]) : charaData10.GetFieldValueByName("MP")))))));
						Debug.Log("Check " + charaData10.Indexs_Name["Name"].stringValue + " " + array15[1] + " [" + num23 + "] " + array15[2] + " [" + num24 + "]");
						if (array15[2] == ">")
						{
							if (num23 > num24)
							{
								flag = true;
							}
						}
						else if (array15[2] == "<")
						{
							if (num23 < num24)
							{
								flag = true;
							}
						}
						else if (array15[2] == "=" && num23 == num24)
						{
							flag = true;
						}
						if (flag && array15.Length > 4)
						{
							flag = false;
							num23 = 0f;
							num24 = float.Parse(array15[6], CultureInfo.InvariantCulture);
							num23 = ((array15[4] == "LV") ? ((float)charaData10.m_Level) : ((array15[4] == "MONEY") ? ((float)SharedData.Instance().m_Money) : ((array15[4] == "HP") ? charaData10.m_Hp : ((array15[4] == "MP") ? charaData10.m_Mp : ((array15[4] == "HPLIMIT") ? charaData10.GetFieldValueByName("HP") : ((!(array15[4] == "MPLIMIT")) ? charaData10.GetFieldValueByName(array15[4]) : charaData10.GetFieldValueByName("MP")))))));
							Debug.Log("Check2 " + charaData10.Indexs_Name["Name"].stringValue + " " + array15[4] + " [" + num23 + "] " + array15[5] + " [" + num24 + "]");
							if (array15[5] == ">")
							{
								if (num23 > num24)
								{
									flag = true;
								}
							}
							else if (array15[5] == "<")
							{
								if (num23 < num24)
								{
									flag = true;
								}
							}
							else if (array15[5] == "=" && num23 == num24)
							{
								flag = true;
							}
						}
						if (flag)
						{
							SharedData.Instance().m_TempParas["teammates"] = charaData10.Indexs_Name["Name"].stringValue;
							break;
						}
					}
					if (flag)
					{
						continue;
					}
					gang_a01Table.Row row6 = CommonResourcesData.a01.Find_Name(array15[1]);
					if (array15[0] == "ANY")
					{
						if (array15.Length <= 4)
						{
							AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_NeedAnyone") + " <color=#f0e352>" + row6.NameScene_Trans + "</color> " + text9 + "！");
						}
					}
					else if (array15[0] != "SELF" && !array15[0].StartsWith("SPEC"))
					{
						AddExploreList("INFO|" + CommonFunc.I18nGetLocalizedValue("I18N_Need") + " <color=#f0e352>" + charaData10.Indexs_Name["Name"].stringValue + "</color> " + CommonFunc.I18nGetLocalizedValue("I18N_InTeamAnd") + " <color=#f0e352>" + row6.NameScene_Trans + "</color> " + text9 + "！");
					}
				}
				if (flag)
				{
					PlaySoundEffect("Check_True", "0", null);
				}
				else
				{
					PlaySoundEffect("Check_False", "0", null);
				}
			}
			else if (act[1] == "TEAM")
			{
				string[] array16 = act[2].Split('_');
				if (array16.Length > 2)
				{
					float num25 = 0f;
					float num26 = 0f;
					if (array16[0] == "COUNT")
					{
						num25 = SharedData.Instance().FollowList.Count;
						num26 = float.Parse(array16[2], CultureInfo.InvariantCulture);
					}
					if (array16[1] == ">")
					{
						if (num25 > num26)
						{
							flag = true;
						}
					}
					else if (array16[1] == "<")
					{
						if (num25 < num26)
						{
							flag = true;
						}
					}
					else if (array16[1] == "=" && num25 == num26)
					{
						flag = true;
					}
				}
				else if (array16.Length > 1 && array16[0] == "EXISTS")
				{
					flag = SharedData.Instance().FollowList.Contains(array16[1]);
				}
			}
			else if (act[1] == "PARTY")
			{
				flag = SharedData.Instance().FullTeam.Contains(act[2]);
			}
			else if (act[1] == "TRAIT")
			{
				flag = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_TraitList.Contains(act[2]);
			}
			else if (act[1] == "PACKAGE")
			{
				string[] array17 = act[2].Split('+');
				bool flag7 = true;
				string[] array5 = array17;
				foreach (string text10 in array5)
				{
					if (!flag7)
					{
						break;
					}
					string[] array18 = text10.Split('_');
					float num27 = 0f;
					string value3 = "_" + array18[0] + "_";
					foreach (KeyValuePair<string, int> item5 in SharedData.Instance().PlayerPackage)
					{
						if (item5.Key.Contains(value3) || item5.Key.Equals(array18[0]))
						{
							num27 += (float)item5.Value;
						}
					}
					float num28 = float.Parse(array18[2], CultureInfo.InvariantCulture);
					if (array18[1] == ">")
					{
						if (num27 <= num28)
						{
							flag7 = false;
						}
					}
					else if (array18[1] == "<")
					{
						if (num27 >= num28)
						{
							flag7 = false;
						}
					}
					else if (array18[1] == "=" && num27 != num28)
					{
						flag7 = false;
					}
				}
				flag = flag7;
			}
			string flag8 = _event.evdata.flag;
			flag8 = ((!flag) ? (flag8 + "_FALSE") : (flag8 + "_TRUE"));
			MonoBehaviour.print("CHECK 1 nextflag -> " + flag8);
			SetNextFlag(flag8, _event.evdata.trigger == "AUTO");
			EventComplete(_event);
		}
		else if (act[0] == "PLAYANI")
		{
			bool flag9 = false;
			if (act.Length > 4)
			{
				flag9 = "LOOP".Equals(act[4]);
			}
			float timescale2 = 1f;
			if (act.Length > 5)
			{
				timescale2 = float.Parse(act[5], CultureInfo.InvariantCulture);
			}
			if (act[1] == "THIS")
			{
				_event.obj.GetComponent<EventController>().m_KeepAnimation = false;
				_event.obj.GetComponent<EventController>().PlayAnimation(act[2], loop: true, compensate: false, timescale2);
				_event.obj.GetComponent<EventController>().m_IsLoop = flag9;
				if (act[3] != "0")
				{
					_event.obj.GetComponent<EventController>().Idle(act[3]);
				}
			}
			else if (act[1] == "PLAYER")
			{
				player.m_KeepAnimation = false;
				player.PlayAnimation(act[2], loop: true, compensate: false, timescale2);
				player.m_IsLoop = flag9;
				if (act[3] != "0")
				{
					player.Idle(act[3]);
				}
			}
			if (!flag9)
			{
				EventComplete(_event);
			}
		}
		else if (act[0] == "CAMCTRL")
		{
			if (act[1] == "THIS")
			{
				EventTakeCamera(_event);
			}
			else if (act[1] == "PLAYER")
			{
				PlayerTakeCamera();
			}
			else
			{
				Event eventById9 = GetEventById(act[1]);
				if (eventById9 != null)
				{
					EventTakeCamera(eventById9);
				}
				else
				{
					Debug.LogWarning("Can NOT find eventid[" + act[1] + "]");
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "SHOP")
		{
			SharedData.Instance().OpenShopID = act[1];
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Shop);
			EventComplete(_event);
		}
		else if (act[0] == "PACKMULTI")
		{
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			LoadSceneAdditive("Inheritance");
			EventComplete(_event);
		}
		else if (act[0] == "CREATEWUGONG")
		{
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			CreateWGController.enhanceWuGongType = EnhanceWuGongType.Create;
			LoadSceneAdditive("CreateWG");
			EventComplete(_event);
		}
		else if (act[0] == "BREAKWUGONG")
		{
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			CreateWGController.enhanceWuGongType = EnhanceWuGongType.Break;
			LoadSceneAdditive("EvolutionWG");
			EventComplete(_event);
		}
		else if (act[0] == "ENHANCEEQ")
		{
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			EvolutionEqNewController.EnhanceEquipmentType = EnhanceType.Enhance;
			if (act.Length > 1)
			{
				EvolutionEqNewController.EnhanceAnvilLevel = int.Parse(act[1]);
			}
			else
			{
				EvolutionEqNewController.EnhanceAnvilLevel = 0;
			}
			LoadSceneAdditive("EvolutionEQ");
			EventComplete(_event);
		}
		else if (act[0] == "RESETEQ")
		{
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			EvolutionEqNewController.EnhanceEquipmentType = EnhanceType.Reset;
			LoadSceneAdditive("EvolutionEQ");
			EventComplete(_event);
		}
		else if (act[0] == "LOAN")
		{
			SharedData.Instance().OpenShopID = act[1];
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Loan);
			EventComplete(_event);
		}
		else if (act[0] == "REDEEM")
		{
			SharedData.Instance().OpenShopID = act[1];
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Redeem);
			EventComplete(_event);
		}
		else if (act[0] == "APPRECIATION")
		{
			SharedData.Instance().OpenShopID = act[1];
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Appreciation, "00000000001");
			EventComplete(_event);
		}
		else if (act[0] == "TOMB")
		{
			gang_e03Table.Row row7 = CommonResourcesData.e03.Find_id(act[1]);
			string[] array19 = row7.pos.Split('|');
			Vector3Int vector3Int2 = new Vector3Int(int.Parse(array19[0]), int.Parse(array19[1]), 0);
			if (SharedData.Instance().SceneBefore.Equals(row7.prescene) && vector3Int2.Equals(SharedData.Instance().MapUnitsBefore[player.name]))
			{
				AddChatList(player.charadata.Indexs_Name["Name"].stringValue, row7.horimono);
			}
			else
			{
				AddChatList(player.charadata.Indexs_Name["Name"].stringValue, "荒郊野坟，啥都没有。");
			}
			m_Canvas_Event = _event;
		}
		else if (act[0] == "FACETOPLAYER")
		{
			_event.obj.GetComponent<EventController>().FaceToPlayer(_event: true);
			EventComplete(_event);
		}
		else if (act[0] == "SETSKIN")
		{
			string[] array20 = act[2].Split('&');
			if (act[1] == "PLAYER")
			{
				player.charadata.m_DefaultPrefab = player.charadata.m_Prefab;
				player.charadata.m_DefaultBattleIcon = player.charadata.m_BattleIcon;
				player.charadata.m_Prefab = array20[0];
				player.charadata.m_BattleIcon = array20[1];
			}
			else if (act[1] == "TEAM")
			{
				if ("DEFAULT".Equals(array20[0]))
				{
					player.charadata.m_Prefab = player.charadata.m_DefaultPrefab;
					player.charadata.m_BattleIcon = player.charadata.m_DefaultBattleIcon;
					foreach (string follow7 in SharedData.Instance().FollowList)
					{
						if (!"1186".Equals(follow7))
						{
							CharaData charaData11 = SharedData.Instance().GetCharaData(follow7);
							if (charaData11 != null)
							{
								charaData11.m_Prefab = charaData11.m_DefaultPrefab;
								charaData11.m_BattleIcon = charaData11.m_DefaultBattleIcon;
							}
							else
							{
								Debug.LogWarning("[DEFAULT] Can NOT find follow charaid[" + act[1] + "]");
							}
						}
					}
				}
				else
				{
					player.charadata.m_DefaultPrefab = player.charadata.m_Prefab;
					player.charadata.m_DefaultBattleIcon = player.charadata.m_BattleIcon;
					player.charadata.m_Prefab = array20[0];
					player.charadata.m_BattleIcon = array20[1];
					foreach (string follow8 in SharedData.Instance().FollowList)
					{
						if (!"1186".Equals(follow8))
						{
							CharaData charaData12 = SharedData.Instance().GetCharaData(follow8);
							if (charaData12 != null)
							{
								charaData12.m_DefaultPrefab = charaData12.m_Prefab;
								charaData12.m_DefaultBattleIcon = charaData12.m_BattleIcon;
								charaData12.m_Prefab = array20[0];
								charaData12.m_BattleIcon = array20[1];
							}
							else
							{
								Debug.LogWarning("Can NOT find follow charaid[" + act[1] + "]");
							}
						}
					}
				}
			}
			else
			{
				CharaData charaData13 = SharedData.Instance().GetCharaData(act[1]);
				if (charaData13 != null)
				{
					charaData13.m_DefaultPrefab = charaData13.m_Prefab;
					charaData13.m_DefaultBattleIcon = charaData13.m_BattleIcon;
					charaData13.m_Prefab = array20[0];
					charaData13.m_BattleIcon = array20[1];
				}
				else
				{
					Debug.LogWarning("Can NOT find charaid[" + act[1] + "]");
				}
			}
			EventComplete(_event);
		}
		else if (act[0] == "AbolishKungfu")
		{
			AbolishKungfu(SharedData.Instance().CurrentChara);
			EventComplete(_event);
		}
		else if (act[0] == "PlayerForgetSkill")
		{
			PlayerForgetSkill(act[1], _special: true);
			EventComplete(_event);
		}
		else if (act[0] == "PlayerWashUp")
		{
			PlayerWashUp();
			EventComplete(_event);
		}
		else if (act[0] == "FACTION")
		{
			if (act.Length > 3)
			{
				DoFaction(act[1], act[2], act[3]);
			}
			EventComplete(_event);
		}
		else if (act[0] == "SECTPANEL")
		{
			if (act.Length >= 2)
			{
				SharedData.Instance().sectPanelID = act[1];
				UnityEngine.Object.Instantiate(Resources.Load("Prefabs/NewUI/SectCanvas/SectCanvas") as GameObject);
			}
			EventComplete(_event);
		}
		else if (act[0] == "UNLOCKATLAS")
		{
			if (act.Length >= 3)
			{
				GameDataManager.Instance().AddUnlockAtlasList(act[2], act[1]);
			}
		}
		else
		{
			EventComplete(_event);
			if (InitOK && !"AUTO".Equals(_event.evdata.trigger) && !"".Equals(_event.evdata.nextflag))
			{
				UpdateEvents(5);
			}
		}
		return flag;
	}

	public void SaveMapSnapShot()
	{
		SharedData.Instance().SaveMapSnapshot(mapSceneName, mapUnits, events);
		SharedData.Instance().playercamctrl = player.camera_control;
		SharedData.Instance().playerdirection = player.m_Direction;
	}

	public void ReportPosition(string name, Vector3Int pos)
	{
		if (mapUnits.ContainsKey(name))
		{
			mapUnits[name] = pos;
		}
		else
		{
			mapUnits.Add(name, pos);
		}
		if (!IsChating() && player.m_ScenePlay == 0 && name == player.name)
		{
			FootOnPosition(pos);
		}
	}

	private void getInheritItems()
	{
		if (GameDataManager.Instance().configdata.inheritItems.Length <= 0)
		{
			return;
		}
		string[] array = GameDataManager.Instance().configdata.inheritItems.Split('&');
		List<string> list = new List<string>();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].Contains("Mine"))
			{
				string text = array[i] + "&" + array[++i] + "&" + array[++i];
				Debug.LogWarning("Repack [Mine]: " + text);
				list.Add(text);
			}
			else if (array[i].Contains("Traitscroll"))
			{
				string text2 = array[i] + "&" + array[++i];
				Debug.LogWarning("Repack [Traitscroll]: " + text2);
				list.Add(text2);
			}
			else
			{
				Debug.LogWarning("Repack [NORMAL]: " + array[i]);
				list.Add(array[i]);
			}
		}
		foreach (string item in list)
		{
			string[] array2 = item.Split('|');
			if (array2[0] == "999")
			{
				int num = int.Parse(array2[1]);
				SharedData.Instance().m_Money += num;
				if (SharedData.Instance().m_Money < 0)
				{
					SharedData.Instance().m_Money = 0;
				}
			}
			else
			{
				SharedData.Instance().PackageAdd(array2[0], int.Parse(array2[1]));
			}
			string explore = "GET|ITEM|" + item;
			AddExploreList(explore);
		}
	}

	public SuperObject[] getByName(string _name)
	{
		List<SuperObject> list = new List<SuperObject>();
		SuperObject[] superObjects = m_SuperObjects;
		foreach (SuperObject superObject in superObjects)
		{
			if (superObject.m_TiledName == _name)
			{
				list.Add(superObject);
			}
		}
		return list.ToArray();
	}

	private SuperObject[] getByType(string _type)
	{
		List<SuperObject> list = new List<SuperObject>();
		SuperObject[] superObjects = m_SuperObjects;
		foreach (SuperObject superObject in superObjects)
		{
			if (superObject.m_Type == _type)
			{
				list.Add(superObject);
			}
		}
		return list.ToArray();
	}

	public bool CanSlide(Vector3Int _pos)
	{
		if (_pos.x < 0)
		{
			return false;
		}
		if (_pos.x >= mapSize.x)
		{
			return false;
		}
		if (_pos.y < 0)
		{
			return false;
		}
		if (_pos.y >= mapSize.y)
		{
			return false;
		}
		if (!sliding.Contains(_pos))
		{
			return false;
		}
		return true;
	}

	public bool CanWalk(Vector3Int _pos, bool _astar = false)
	{
		if (_pos.x < 0)
		{
			return false;
		}
		if (_pos.x >= mapSize.x)
		{
			return false;
		}
		if (_pos.y < 0)
		{
			return false;
		}
		if (_pos.y >= mapSize.y)
		{
			return false;
		}
		if (mapUnits.ContainsValue(_pos))
		{
			return false;
		}
		if (!_astar && !obstacle.Contains(_pos))
		{
			return false;
		}
		return true;
	}

	public void HideCurcor()
	{
		m_Curcor.transform.Find("war-click").gameObject.SetActive(value: false);
	}

	public void ShowCurcorAt(Vector2 _pos)
	{
		m_Curcor.transform.localPosition = _pos;
		m_Curcor.transform.Find("war-click").gameObject.SetActive(value: true);
	}

	public void SubdueEnemy()
	{
		if (SharedData.Instance().m_FinalSubdueList.Count == 0)
		{
			return;
		}
		foreach (KeyValuePair<string, CharaData> finalSubdue in SharedData.Instance().m_FinalSubdueList)
		{
			if (SharedData.Instance().CharaDataList.ContainsKey(finalSubdue.Key))
			{
				SharedData.Instance().CharaDataList[finalSubdue.Key] = finalSubdue.Value;
			}
			else
			{
				SharedData.Instance().CharaDataList.Add(finalSubdue.Key, finalSubdue.Value);
			}
			JoinTeam(finalSubdue.Key);
			ElixirChara(finalSubdue.Key);
			if (CommonResourcesData.b10.Find_ID("2001").Members.Split('|').Contains(finalSubdue.Value.m_B01Id))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1012");
			}
			else if (CommonResourcesData.b10.Find_ID("2002").Members.Split('|').Contains(finalSubdue.Value.m_B01Id))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1013");
			}
		}
		int num = 0;
		int num2 = 0;
		List<string> list = CommonResourcesData.b10.Find_ID("1001").Members.Split("|").ToList();
		foreach (string item in SharedData.Instance().FullTeam)
		{
			if (item.Contains('_'))
			{
				if (list.Contains(item.Split('_')[0]))
				{
					num++;
				}
				else
				{
					num2++;
				}
			}
		}
		if (num2 == 18)
		{
			StatsAndAchievements.Instance().UnlockAchievement("1057");
		}
		if (num == 18)
		{
			StatsAndAchievements.Instance().UnlockAchievement("1058");
		}
	}

	private bool IsEntourage(string _b01_id)
	{
		string[] array = _b01_id.Split('_');
		if (array.Length > 1)
		{
			if (CommonResourcesData.b10.Find_ID("2001").Members.Split('|').Contains(array[0]))
			{
				return true;
			}
			if (CommonResourcesData.b10.Find_ID("2002").Members.Split('|').Contains(array[0]))
			{
				return true;
			}
		}
		return false;
	}

	public void ExpelTeam()
	{
		if (SharedData.Instance().m_ExpelList.Count == 0)
		{
			return;
		}
		foreach (string expel in SharedData.Instance().m_ExpelList)
		{
			LeaveTeam(expel, _reteamable: false, isForce: true);
		}
		SharedData.Instance().player.InitFollows();
		SharedData.Instance().m_ExpelList.Clear();
	}

	private bool IsPlayerInZone(RandomFightInfo randomFightInfo)
	{
		Vector3Int gridPosition = player.GetGridPosition();
		gridPosition.y = -gridPosition.y;
		if (randomFightInfo.tilemap != null)
		{
			return randomFightInfo.tilemap.HasTile(gridPosition);
		}
		return false;
	}

	public bool CheckNeedRandomFight()
	{
		if (player.m_FootOnInterrupt || randomFightInfos.Count.Equals(0))
		{
			return false;
		}
		couldFightList = new List<RandomFightInfo>();
		bool flag = false;
		foreach (RandomFightInfo randomFightInfo in randomFightInfos)
		{
			if (randomFightInfo.couldFight && randomFightInfo.couldFight && (!randomFightInfo.isUnique || !SharedData.Instance().m_SpecialWantedList.Contains(randomFightInfo.GIDList)) && randomFightInfo.couldFight && IsPlayerInZone(randomFightInfo))
			{
				bool flag2 = player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue == 1f;
				if (player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue > 0f && randomFightInfo.currentStep >= 2)
				{
					flag2 = true;
				}
				if (!flag)
				{
					flag = true;
					SharedData.Instance().m_WalkSteps++;
				}
				if ((++randomFightInfo.currentStep >= randomFightInfo.requireStep || flag2) && (UnityEngine.Random.Range(0f, 1f) < randomFightInfo.battleRate || flag2))
				{
					couldFightList.Add(randomFightInfo);
				}
			}
		}
		if (flag)
		{
			player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue -= 1f;
		}
		if (player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue > 0f || player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue > 0f)
		{
			if (flag)
			{
				player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue -= 1f;
			}
			return false;
		}
		if (couldFightList.Count == 0)
		{
			return false;
		}
		return RandomFight();
	}

	public bool RandomFight()
	{
		RandomFightInfo randomFightInfo = couldFightList[UnityEngine.Random.Range(0, couldFightList.Count)];
		SharedData.Instance().b04RamdonBattleRowList.Clear();
		if (randomFightInfo.isUnique)
		{
			string[] array = randomFightInfo.GIDList.Split('&');
			SharedData.Instance().b04BattleID = array[UnityEngine.Random.Range(0, array.Length)];
			SharedData.Instance().SpecialRandomFightGID = SharedData.Instance().b04BattleID;
			SharedData.Instance().BattleGround = randomFightInfo.battleFieldList[UnityEngine.Random.Range(0, randomFightInfo.battleFieldList.Count)];
			SharedData.Instance().b04RamdonBattleRowList = CommonResourcesData.b04_Random.FindAll_GID(SharedData.Instance().b04BattleID);
		}
		else
		{
			SharedData.Instance().b04BattleID = "";
			SharedData.Instance().SpecialRandomFightGID = "";
			SharedData.Instance().BattleGround = randomFightInfo.battleFieldList[UnityEngine.Random.Range(0, randomFightInfo.battleFieldList.Count)];
			int num = UnityEngine.Random.Range(randomFightInfo.enemyCountMin, randomFightInfo.enemyCountMax + 1);
			for (int num2 = currentRandomPlayerLevel; num2 >= 1; num2--)
			{
				foreach (KeyValuePair<string, Dictionary<int, List<gang_b04Table.Row>>> item in randomFightInfo.GIDGroupDict)
				{
					if (item.Value[num2].Count > 0 && num >= SharedData.Instance().b04RamdonBattleRowList.Count)
					{
						SharedData.Instance().b04RamdonBattleRowList.AddRange(item.Value[num2]);
					}
				}
				if (num < SharedData.Instance().b04RamdonBattleRowList.Count)
				{
					break;
				}
			}
			if (SharedData.Instance().b04RamdonBattleRowList.Count == 0)
			{
				for (int num3 = 7; num3 >= 1; num3--)
				{
					foreach (KeyValuePair<string, Dictionary<int, List<gang_b04Table.Row>>> item2 in randomFightInfo.GIDGroupDict)
					{
						if (item2.Value[num3].Count > 0 && num >= SharedData.Instance().b04RamdonBattleRowList.Count)
						{
							SharedData.Instance().b04RamdonBattleRowList.AddRange(item2.Value[num3]);
						}
					}
					if (num < SharedData.Instance().b04RamdonBattleRowList.Count)
					{
						break;
					}
				}
			}
			System.Random random = new System.Random();
			if (num > SharedData.Instance().b04RamdonBattleRowList.Count)
			{
				while (num > SharedData.Instance().b04RamdonBattleRowList.Count)
				{
					int index = random.Next(SharedData.Instance().b04RamdonBattleRowList.Count);
					SharedData.Instance().b04RamdonBattleRowList.Add(SharedData.Instance().b04RamdonBattleRowList[index]);
				}
			}
			else
			{
				random = new System.Random();
				List<gang_b04Table.Row> list = new List<gang_b04Table.Row>();
				for (int i = 0; i < num; i++)
				{
					int index2 = random.Next(SharedData.Instance().b04RamdonBattleRowList.Count);
					list.Add(SharedData.Instance().b04RamdonBattleRowList[index2]);
					SharedData.Instance().b04RamdonBattleRowList.RemoveAt(index2);
				}
				SharedData.Instance().b04RamdonBattleRowList = list;
			}
		}
		if (SharedData.Instance().b04RamdonBattleRowList.Count == 0)
		{
			SharedData.Instance().b04BattleID = "";
			SharedData.Instance().SpecialRandomFightGID = "";
			SharedData.Instance().BattleGround = "";
			return false;
		}
		SaveMapSnapShot();
		enemygid = new string[2] { "RandomFight", "" };
		SharedData.Instance().BattleMemberMax = 5;
		SharedData.Instance().BattleItemGroupId = "0";
		SharedData.Instance().AfterBattleWin = "";
		SharedData.Instance().AfterBattleLose = "";
		SharedData.Instance().BackFromOtherScene = false;
		SharedData.Instance().PlayerSetting.Clear();
		SharedData.Instance().EnemySetting.Clear();
		SharedData.Instance().isRandomFight = true;
		player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue = 0f;
		SharedData.Instance().m_WalkSteps = 0;
		LoadScene("BeforeBattle", isBattle: true);
		return true;
	}

	private void EnterBattleAnimation(string screenName)
	{
		isEnterBattleAnimPlaying = true;
		m_AudioSource.clip = CommonResourcesData.Battle_SE;
		m_AudioSource.loop = false;
		m_AudioSource.Play();
		canvas.transform.Find("RandomFight").gameObject.SetActive(value: true);
		canvas.transform.Find("RandomFight/RandomFight_ZH").gameObject.SetActive(value: false);
		canvas.transform.Find("RandomFight/RandomFight_TW").gameObject.SetActive(value: false);
		canvas.transform.Find("RandomFight/RandomFight_EN").gameObject.SetActive(value: false);
		SkeletonGraphic component = canvas.transform.Find("RandomFight/RandomFight_" + CommonFunc.ShortLangSel("ZH", "EN", "TW")).GetComponent<SkeletonGraphic>();
		component.gameObject.SetActive(value: true);
		InputSystemCustom.Instance().joyInputSystemManager.Disable();
		component.AnimationState.SetAnimation(0, "animation", loop: false);
		component.AnimationState.Complete += delegate
		{
			Debug.Log("Animation complete!");
			InputSystemCustom.Instance().joyInputSystemManager.Enable();
			isEnterBattleAnimPlaying = false;
			LoadScene(screenName);
		};
	}

	private bool CheckHaveAlreadyMeetSpecialCharacter(string idList)
	{
		if (SharedData.Instance().m_SpecialWantedList.Contains(idList))
		{
			return true;
		}
		return false;
	}

	public void AfterAppreciation()
	{
		Event eventById = GetEventById("APPRECIATION_00");
		eventById.evdata = CommonResourcesData.e01.Find_flag("APPRECIATION_00_1");
		SharedData.Instance().FlagList["APPRECIATION_00_1"] = 1;
		DoAutoAction(eventById);
	}

	public void TitleLevelUp()
	{
		if (SharedData.Instance().m_TitleLevelUpDict.Count > 0)
		{
			foreach (KeyValuePair<string, string> item in SharedData.Instance().m_TitleLevelUpDict)
			{
				CharaData charaData = SharedData.Instance().GetCharaData(item.Key);
				charaData.AddTraits(item.Value);
				charaData.RemoveTrait(charaData.m_currentTitleID);
				charaData.m_titleExpDict.Remove(charaData.m_currentTitleID);
				charaData.m_currentTitleID = item.Value;
				GameDataManager.Instance().AddUnlockAtlasList(item.Value, "b06");
				string explore = "GET|TRAIT|" + item.Key + "|" + item.Value + "|+";
				AddExploreList(explore);
			}
		}
		SharedData.Instance().m_TitleLevelUpDict.Clear();
	}

	private IEnumerator AutoSaveAnimation(Transform transform)
	{
		transform.gameObject.SetActive(value: true);
		RectTransform rectTransform = transform.GetComponent<RectTransform>();
		rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, -20f);
		rectTransform.DOAnchorPosY(180f, 0.4f).SetEase(Ease.InQuad);
		transform.GetComponent<Image>().DOFade(0f, 0f);
		transform.GetComponent<Image>().DOFade(1f, 0.4f);
		yield return new WaitForSeconds(2f);
		transform.GetComponent<Image>().DOFade(0f, 0.2f);
		rectTransform.DOAnchorPosY(-20f, 0.2f).SetEase(Ease.OutQuad).OnComplete(delegate
		{
			transform.gameObject.SetActive(value: false);
		});
	}

	private IEnumerator LocationAndMoneyMoveAnimation(Transform transform)
	{
		transform.gameObject.SetActive(value: true);
		RectTransform rectTransform = transform.GetComponent<RectTransform>();
		rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, 0f);
		rectTransform.DOAnchorPosY(-50f, 0.4f).SetEase(Ease.InQuad);
		transform.GetComponent<Image>().DOFade(0f, 0f);
		transform.GetComponent<Image>().DOFade(1f, 0.4f);
		yield return new WaitForSeconds(3f);
		transform.GetComponent<Image>().DOFade(0f, 0.2f);
		rectTransform.DOAnchorPosY(50f, 0.2f).SetEase(Ease.OutQuad).OnComplete(delegate
		{
			transform.gameObject.SetActive(value: false);
		});
	}

	public void MoneyMoveAnimation()
	{
		string text = SharedData.Instance().m_Money.ToString();
		if (SharedData.Instance().m_Money > 9999999)
		{
			text = Math.Round((float)SharedData.Instance().m_Money / 1000f, 1) + "K";
		}
		m_money.transform.Find("Text").GetComponent<Text>().text = text;
		StartCoroutine(LocationAndMoneyMoveAnimation(m_money));
	}

	public void AutoSaveAnimationOut()
	{
		StartCoroutine(AutoSaveAnimation(m_SaveData));
	}

	public void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			string[] array = go.name.Split('|');
			if (array[0] == "ItemBtn" || array[0] == "WuGong")
			{
				CommonFunc.CloseHover();
				StartCoroutine(CommonFunc.DelayedOpenHoverOperation(go, showEquip: false, useCharaData: false));
			}
			else if (array[0] == "WantedClose")
			{
				m_WantedList.SetActive(value: false);
				EventSystem.current.SetSelectedGameObject(null);
				EventComplete(m_Canvas_Event);
			}
		}
	}
}
