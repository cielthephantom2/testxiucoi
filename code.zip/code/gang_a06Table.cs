using System.Collections.Generic;
using UnityEngine;

public class gang_a06Table
{
	public class Row
	{
		public string ID;

		public string Depth;

		public string Describe;

		public string No;

		public string Value;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Depth = list[i][num++],
				Describe = list[i][num++],
				No = list[i][num++],
				Value = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Depth(string find)
	{
		return rowList.Find((Row x) => x.Depth == find);
	}

	public List<Row> FindAll_Depth(string find)
	{
		return rowList.FindAll((Row x) => x.Depth == find);
	}

	public Row Find_Describe(string find)
	{
		return rowList.Find((Row x) => x.Describe == find);
	}

	public List<Row> FindAll_Describe(string find)
	{
		return rowList.FindAll((Row x) => x.Describe == find);
	}

	public Row Find_No(string find)
	{
		return rowList.Find((Row x) => x.No == find);
	}

	public List<Row> FindAll_No(string find)
	{
		return rowList.FindAll((Row x) => x.No == find);
	}

	public Row Find_Value(string find)
	{
		return rowList.Find((Row x) => x.Value == find);
	}

	public List<Row> FindAll_Value(string find)
	{
		return rowList.FindAll((Row x) => x.Value == find);
	}
}
