using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.Tilemaps;

public class ItemController : MonoBehaviour
{
	protected const float MovementBlockSize = 50f;

	public gang_b05Table.Row b5row;

	public int isItemPerforming;

	private void Start()
	{
		GetComponent<SpriteRenderer>().sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		return zero;
	}

	public void BeHit()
	{
		isItemPerforming = 1;
		StartCoroutine(BeHit_CallBack());
	}

	private IEnumerator BeHit_CallBack()
	{
		yield return new WaitForSeconds(0.5f);
		isItemPerforming = 2;
	}
}
