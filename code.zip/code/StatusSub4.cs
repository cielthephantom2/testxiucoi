using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class StatusSub4 : MonoBehaviour
{
	private Button[] equip_btns;

	private CharaData curdata;

	private void Awake()
	{
		equip_btns = base.transform.Find("Panel/Equips").GetComponentsInChildren<Button>();
		Button[] array = equip_btns;
		for (int i = 0; i < array.Length; i++)
		{
			EventTriggerListener.Get(array[i].gameObject).onClick = OnButtonClick;
		}
		SharedData.Instance().m_StatusSub4 = this;
	}

	private void OnEnable()
	{
		if (!(SharedData.Instance().CurrentChara == ""))
		{
			curdata = SharedData.Instance().CurrentCharaData;
			if (curdata != null)
			{
				base.transform.Find("Panel/Area1/Name").GetComponent<Text>().text = curdata.Indexs_Name["Name"].stringValue;
				base.transform.Find("Panel/Area1/LV/Num").GetComponent<Text>().text = curdata.m_Level.ToString() ?? "";
				gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(curdata.m_Level.ToString() ?? "");
				base.transform.Find("Panel/Area1/Exp/Num").GetComponent<Text>().text = curdata.m_Exp + "/" + row.EXP;
				base.transform.Find("Panel/Area1/ExpBar").GetComponent<Slider>().value = (float)curdata.m_Exp / float.Parse(row.EXP, CultureInfo.InvariantCulture);
				RefreshUI();
			}
		}
	}

	public void RefreshUI()
	{
		curdata = SharedData.Instance().CurrentCharaData;
		int num = 0;
		string find = curdata.m_EquipSlot[0] + "|" + curdata.m_EquipSlot[1] + "|" + curdata.m_EquipSlot[2];
		Button[] array = equip_btns;
		foreach (Button button in array)
		{
			MonoBehaviour.print("curdata.m_EquipSlot[" + num + "]: " + curdata.m_EquipSlot[num]);
			button.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/01-border/0508-icon-Equipment-01", typeof(Sprite)) as Sprite;
			button.name = "Equip|" + num + "|" + curdata.m_EquipSlot[num];
			button.transform.parent.Find("Text").GetComponent<Text>().text = "";
			button.transform.Find("Enhence").gameObject.SetActive(value: false);
			for (int j = 1; j <= 10; j++)
			{
				button.transform.parent.Find("Stars/Stars" + j).gameObject.SetActive(value: false);
			}
			if (curdata.m_EquipSlot[num] != "0")
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(curdata.m_EquipSlot[num]);
				button.transform.Find("Icon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(row.BookIcon);
				button.name = "Equip|" + num + "|" + curdata.m_EquipSlot[num];
				button.transform.parent.Find("Text").GetComponent<Text>().text = row.Name_Trans;
				gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(row.Relateid);
				if (row2.Enhance > 0)
				{
					button.transform.Find("Enhence").gameObject.SetActive(value: true);
					button.transform.Find("Enhence/Text").GetComponent<Text>().text = "+" + row2.Enhance;
				}
				int enhance = row2.Enhance;
				for (int k = 1; k <= enhance; k++)
				{
					button.transform.parent.Find("Stars/Stars" + k).gameObject.SetActive(value: true);
				}
			}
			num++;
			if (num > 2)
			{
				break;
			}
		}
		gang_b02SetTable.Row row3 = CommonResourcesData.b02Set.Find_Set(find);
		if (row3 != null)
		{
			List<string> list = new List<string> { row3.Skills1, row3.Skills2, row3.Skills3 };
			List<string> list2 = new List<string> { row3.Skills1Ec, row3.Skills2Ec, row3.Skills3Ec };
			List<SkillShowInfoItem> list3 = new List<SkillShowInfoItem>();
			for (int l = 0; l < list.Count; l++)
			{
				if (list[l] != "" && list[l] != "0")
				{
					list3.Add(SkillHoverShowInfo.SkillUI(list[l], 0, "1", list2[l]));
				}
			}
			List<string> list4 = new List<string> { row3.add1, row3.add2, row3.add3, row3.add4, row3.add5 };
			List<string> list5 = new List<string> { row3.Attribute1, row3.Attribute2, row3.Attribute3, row3.Attribute4, row3.Attribute5 };
			List<string> list6 = new List<string>();
			for (int m = 0; m < list4.Count; m++)
			{
				if (list4[m] != "" && list4[m] != "0" && SharedData.Instance().m_A01NameRowDirec.ContainsKey(list4[m]))
				{
					list6.Add(SkillHoverShowInfo.AddUI(list4[m], list5[m]));
				}
			}
			string text = "";
			foreach (string item in list6)
			{
				text = text + item + "\n";
			}
			foreach (SkillShowInfoItem item2 in list3)
			{
				text = text + item2.info + "\n";
			}
			base.transform.Find("Panel/Info").gameObject.SetActive(value: true);
			base.transform.Find("Panel/Info/Text").GetComponent<Text>().text = text;
		}
		else
		{
			base.transform.Find("Panel/Info").gameObject.SetActive(value: false);
			base.transform.Find("Panel/Info/Text").GetComponent<Text>().text = "";
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MonoBehaviour.print("OnButtonClick: " + go.name);
		string[] array = go.name.Split('|');
		if (array[0] == "Equip")
		{
			int num = int.Parse(array[1]);
			Debug.Log("Equip solt[" + num + "]: " + array[2]);
			string topFilter = "11111111111";
			switch (num)
			{
			case 0:
				topFilter = "00100000000";
				break;
			case 1:
				topFilter = "00010000000";
				break;
			case 2:
				topFilter = "00001000000";
				break;
			}
			CommonResourcesData.inputDeviceDetector.PushJoyStack();
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Equip, topFilter);
		}
	}
}
