using System.Collections.Generic;

public static class SpineBonesSlots
{
	public static void InitSkinDict(string _id)
	{
		InitSkinDict(CommonResourcesData.b01Skin.Find_ID(_id));
	}

	public static Dictionary<string, string> InitSkinDict(gang_b01SkinTable.Row b01SkinRow)
	{
		return new Dictionary<string, string>
		{
			{ "BackPack", b01SkinRow.BackPack },
			{ "weapon-Back", b01SkinRow.WeaponBack },
			{ "weapon-Back2", b01SkinRow.WeaponBack2 },
			{ "hair-back", b01SkinRow.HairBack },
			{ "cloak-back", b01SkinRow.CloakBack },
			{ "leg-right", b01SkinRow.LegRight },
			{ "leg-left", b01SkinRow.LegLeft },
			{ "clothes", b01SkinRow.Clothes },
			{ "cloak-front", b01SkinRow.CloakFront },
			{ "head", b01SkinRow.Head },
			{ "headOther", b01SkinRow.HeadOther },
			{ "eyes", b01SkinRow.Eyes },
			{ "eyes-behit", b01SkinRow.EyesBeHit },
			{ "hair-fornt", b01SkinRow.HairFront },
			{ "hat", b01SkinRow.Hat },
			{ "hand-right-0", b01SkinRow.HandRight },
			{ "hand-left-0", b01SkinRow.HandLeft },
			{ "hand-right-weapon", b01SkinRow.HandRightWeapon },
			{ "hand-right-item", b01SkinRow.HandRightItem },
			{ "hand-left-weapon", b01SkinRow.HandLeftWeapon },
			{ "hand-left-item", b01SkinRow.HandLeftItem },
			{ "hand-left-Sleeve", b01SkinRow.SleeveLeft },
			{ "hand-right-Sleeve", b01SkinRow.SleeveRight },
			{ "weapon-knife", b01SkinRow.weapon_knife },
			{ "weapon-stick", b01SkinRow.weapon_stick },
			{ "weapon-sword", b01SkinRow.weapon_sword },
			{ "Bread", b01SkinRow.Bread },
			{ "FaceMask", b01SkinRow.FaceMask }
		};
	}

	public static string GetSkinCsv(gang_b01SkinTable.Row b01SkinRow, Dictionary<string, string> skinData)
	{
		return b01SkinRow.ID + "," + b01SkinRow.Name + "," + skinData["clothes"] + "," + skinData["head"] + "," + skinData["eyes"] + "," + skinData["hand-left-0"] + "," + skinData["hand-right-0"] + "," + skinData["leg-left"] + "," + skinData["leg-right"] + "," + skinData["cloak-back"] + "," + skinData["cloak-front"] + "," + skinData["eyes-behit"] + "," + skinData["hair-back"] + "," + skinData["hair-fornt"] + "," + skinData["hat"] + "," + skinData["hand-left-item"] + "," + skinData["hand-left-weapon"] + "," + skinData["hand-right-item"] + "," + skinData["hand-right-weapon"] + "," + skinData["weapon-Back"];
	}
}
