using System.Collections;
using UnityEngine;

public class BattleObjectAudioManager
{
	public AudioSource audioSource;

	public AudioClip attack1Clip;

	public AudioClip attack2Clip;

	public AudioClip damageClip;

	public AudioClip deathClip;

	public AudioClip walkClip;

	public AudioClip attackStandClip;

	public AudioClip hitClip;

	public AudioClip missClip;

	public AudioClip heal1Clip;

	public AudioClipEnum m_ClipPlaying;

	private float delay;

	public void Init(BattleObject _battleObject)
	{
		audioSource = _battleObject.transform.Find("head_icon").GetComponent<AudioSource>();
		attack1Clip = (AudioClip)Resources.Load("Music/Charas/" + _battleObject.charadata.m_Sound + "/atk1", typeof(AudioClip));
		attack2Clip = (AudioClip)Resources.Load("Music/Charas/" + _battleObject.charadata.m_Sound + "/atk2", typeof(AudioClip));
		damageClip = (AudioClip)Resources.Load("Music/Charas/" + _battleObject.charadata.m_Sound + "/dmg1", typeof(AudioClip));
		deathClip = (AudioClip)Resources.Load("Music/Charas/" + _battleObject.charadata.m_Sound + "/death", typeof(AudioClip));
		walkClip = (AudioClip)Resources.Load("Music/Charas/" + _battleObject.charadata.m_Sound + "/walk", typeof(AudioClip));
		heal1Clip = (AudioClip)Resources.Load("Music/Skill/heal1", typeof(AudioClip));
	}

	public void PlayAudioClip(AudioClipEnum clipname, bool _force_refresh = false)
	{
		delay = 0f;
		if (_force_refresh || !clipname.Equals(m_ClipPlaying))
		{
			AudioClip audioClip = null;
			audioSource.pitch = 1f;
			switch (clipname)
			{
			case AudioClipEnum.attack1Clip:
				audioClip = attack1Clip;
				break;
			case AudioClipEnum.attack2Clip:
				audioClip = attack2Clip;
				break;
			case AudioClipEnum.damageClip:
				audioClip = damageClip;
				delay = Random.Range(0f, 0.2f);
				break;
			case AudioClipEnum.deathClip:
				audioClip = deathClip;
				break;
			case AudioClipEnum.attackStandClip:
				audioClip = attackStandClip;
				audioSource.pitch = 2f;
				break;
			case AudioClipEnum.missClip:
				audioClip = missClip;
				break;
			case AudioClipEnum.hitClip:
				audioClip = hitClip;
				break;
			case AudioClipEnum.heal1Clip:
				audioClip = heal1Clip;
				break;
			case AudioClipEnum.walkClip:
				audioClip = walkClip;
				break;
			case AudioClipEnum.Water:
				audioClip = CommonResourcesData.SE_WATER;
				break;
			case AudioClipEnum.Hell:
				audioClip = CommonResourcesData.SE_HELL;
				break;
			}
			if (audioClip == null)
			{
				return;
			}
			audioSource.clip = audioClip;
			m_ClipPlaying = clipname;
		}
		if (clipname.Equals(AudioClipEnum.damageClip))
		{
			delay = Random.Range(0f, 0.2f);
		}
	}

	public IEnumerator PlayAudioClipDelay()
	{
		yield return new WaitForSeconds(delay);
		audioSource.Play();
	}
}
