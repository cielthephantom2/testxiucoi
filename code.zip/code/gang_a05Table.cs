using System.Collections.Generic;
using UnityEngine;

public class gang_a05Table
{
	public class Row
	{
		public string LV;

		public string EXP;

		public string HP;

		public string MP;

		public string ATK;

		public string DEF;

		public string SP;

		public string STR;

		public string AGI;

		public string BON;

		public string WIL;

		public string LER;

		public string MOR;

		public string Sword;

		public string Knife;

		public string Stick;

		public string Hand;

		public string Finger;

		public string Special;

		public string YinYang;

		public string Melody;

		public string Medical;

		public string Darts;

		public string Wineart;

		public string Steal;

		public string Forge;

		public string Percept;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				LV = list[i][num++],
				EXP = list[i][num++],
				HP = list[i][num++],
				MP = list[i][num++],
				ATK = list[i][num++],
				DEF = list[i][num++],
				SP = list[i][num++],
				STR = list[i][num++],
				AGI = list[i][num++],
				BON = list[i][num++],
				WIL = list[i][num++],
				LER = list[i][num++],
				MOR = list[i][num++],
				Sword = list[i][num++],
				Knife = list[i][num++],
				Stick = list[i][num++],
				Hand = list[i][num++],
				Finger = list[i][num++],
				Special = list[i][num++],
				YinYang = list[i][num++],
				Melody = list[i][num++],
				Medical = list[i][num++],
				Darts = list[i][num++],
				Wineart = list[i][num++],
				Steal = list[i][num++],
				Forge = list[i][num++],
				Percept = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_LV(string find)
	{
		return rowList.Find((Row x) => x.LV == find);
	}

	public List<Row> FindAll_LV(string find)
	{
		return rowList.FindAll((Row x) => x.LV == find);
	}

	public Row Find_EXP(string find)
	{
		return rowList.Find((Row x) => x.EXP == find);
	}

	public List<Row> FindAll_EXP(string find)
	{
		return rowList.FindAll((Row x) => x.EXP == find);
	}

	public Row Find_HP(string find)
	{
		return rowList.Find((Row x) => x.HP == find);
	}

	public List<Row> FindAll_HP(string find)
	{
		return rowList.FindAll((Row x) => x.HP == find);
	}

	public Row Find_MP(string find)
	{
		return rowList.Find((Row x) => x.MP == find);
	}

	public List<Row> FindAll_MP(string find)
	{
		return rowList.FindAll((Row x) => x.MP == find);
	}

	public Row Find_ATK(string find)
	{
		return rowList.Find((Row x) => x.ATK == find);
	}

	public List<Row> FindAll_ATK(string find)
	{
		return rowList.FindAll((Row x) => x.ATK == find);
	}

	public Row Find_DEF(string find)
	{
		return rowList.Find((Row x) => x.DEF == find);
	}

	public List<Row> FindAll_DEF(string find)
	{
		return rowList.FindAll((Row x) => x.DEF == find);
	}

	public Row Find_SP(string find)
	{
		return rowList.Find((Row x) => x.SP == find);
	}

	public List<Row> FindAll_SP(string find)
	{
		return rowList.FindAll((Row x) => x.SP == find);
	}

	public Row Find_STR(string find)
	{
		return rowList.Find((Row x) => x.STR == find);
	}

	public List<Row> FindAll_STR(string find)
	{
		return rowList.FindAll((Row x) => x.STR == find);
	}

	public Row Find_AGI(string find)
	{
		return rowList.Find((Row x) => x.AGI == find);
	}

	public List<Row> FindAll_AGI(string find)
	{
		return rowList.FindAll((Row x) => x.AGI == find);
	}

	public Row Find_BON(string find)
	{
		return rowList.Find((Row x) => x.BON == find);
	}

	public List<Row> FindAll_BON(string find)
	{
		return rowList.FindAll((Row x) => x.BON == find);
	}

	public Row Find_WIL(string find)
	{
		return rowList.Find((Row x) => x.WIL == find);
	}

	public List<Row> FindAll_WIL(string find)
	{
		return rowList.FindAll((Row x) => x.WIL == find);
	}

	public Row Find_LER(string find)
	{
		return rowList.Find((Row x) => x.LER == find);
	}

	public List<Row> FindAll_LER(string find)
	{
		return rowList.FindAll((Row x) => x.LER == find);
	}

	public Row Find_MOR(string find)
	{
		return rowList.Find((Row x) => x.MOR == find);
	}

	public List<Row> FindAll_MOR(string find)
	{
		return rowList.FindAll((Row x) => x.MOR == find);
	}

	public Row Find_Sword(string find)
	{
		return rowList.Find((Row x) => x.Sword == find);
	}

	public List<Row> FindAll_Sword(string find)
	{
		return rowList.FindAll((Row x) => x.Sword == find);
	}

	public Row Find_Knife(string find)
	{
		return rowList.Find((Row x) => x.Knife == find);
	}

	public List<Row> FindAll_Knife(string find)
	{
		return rowList.FindAll((Row x) => x.Knife == find);
	}

	public Row Find_Stick(string find)
	{
		return rowList.Find((Row x) => x.Stick == find);
	}

	public List<Row> FindAll_Stick(string find)
	{
		return rowList.FindAll((Row x) => x.Stick == find);
	}

	public Row Find_Hand(string find)
	{
		return rowList.Find((Row x) => x.Hand == find);
	}

	public List<Row> FindAll_Hand(string find)
	{
		return rowList.FindAll((Row x) => x.Hand == find);
	}

	public Row Find_Finger(string find)
	{
		return rowList.Find((Row x) => x.Finger == find);
	}

	public List<Row> FindAll_Finger(string find)
	{
		return rowList.FindAll((Row x) => x.Finger == find);
	}

	public Row Find_Special(string find)
	{
		return rowList.Find((Row x) => x.Special == find);
	}

	public List<Row> FindAll_Special(string find)
	{
		return rowList.FindAll((Row x) => x.Special == find);
	}

	public Row Find_YinYang(string find)
	{
		return rowList.Find((Row x) => x.YinYang == find);
	}

	public List<Row> FindAll_YinYang(string find)
	{
		return rowList.FindAll((Row x) => x.YinYang == find);
	}

	public Row Find_Melody(string find)
	{
		return rowList.Find((Row x) => x.Melody == find);
	}

	public List<Row> FindAll_Melody(string find)
	{
		return rowList.FindAll((Row x) => x.Melody == find);
	}

	public Row Find_Medical(string find)
	{
		return rowList.Find((Row x) => x.Medical == find);
	}

	public List<Row> FindAll_Medical(string find)
	{
		return rowList.FindAll((Row x) => x.Medical == find);
	}

	public Row Find_Darts(string find)
	{
		return rowList.Find((Row x) => x.Darts == find);
	}

	public List<Row> FindAll_Darts(string find)
	{
		return rowList.FindAll((Row x) => x.Darts == find);
	}

	public Row Find_Wineart(string find)
	{
		return rowList.Find((Row x) => x.Wineart == find);
	}

	public List<Row> FindAll_Wineart(string find)
	{
		return rowList.FindAll((Row x) => x.Wineart == find);
	}

	public Row Find_Steal(string find)
	{
		return rowList.Find((Row x) => x.Steal == find);
	}

	public List<Row> FindAll_Steal(string find)
	{
		return rowList.FindAll((Row x) => x.Steal == find);
	}
}
