using UnityEngine;

internal class DrawMesh
{
	public Mesh mesh;

	public Matrix4x4 matrix;

	public Material material;

	public DrawMesh(Mesh me, Matrix4x4 ma, Material mat, Color color)
	{
		mesh = me;
		matrix = ma;
		material = new Material(mat);
		material.shader = Shader.Find("Custom/ResidualShadowAdjustAlpha");
	}
}
