using System.Collections.Generic;
using Steamworks;

internal class StatsAndAchievements
{
	private static StatsAndAchievements instance;

	private Dictionary<string, List<string>> statsAndAchieveDict = new Dictionary<string, List<string>>();

	public static StatsAndAchievements Instance(bool init = false)
	{
		if (init || instance == null)
		{
			instance = null;
			instance = new StatsAndAchievements();
			instance.Init();
		}
		return instance;
	}

	public void Init()
	{
		foreach (gang_a07Table.Row row in CommonResourcesData.a07.GetRowList())
		{
			if (row.AchieveCondition.Equals("") || row.AchieveCondition.Equals("|"))
			{
				continue;
			}
			string[] array = row.AchieveCondition.Split('|');
			foreach (string key in array)
			{
				if (!statsAndAchieveDict.ContainsKey(key))
				{
					statsAndAchieveDict.Add(key, new List<string>());
				}
				statsAndAchieveDict[key].Add(row.ID);
			}
		}
	}

	public void UnlockStoryAchievement(string _flag)
	{
		if (!statsAndAchieveDict.ContainsKey(_flag))
		{
			return;
		}
		foreach (string item in statsAndAchieveDict[_flag])
		{
			UnlockAchievement(item);
		}
	}

	public void UnlockAchievement(string _achievementID)
	{
		StatsAndAchievementsData _achievement = GameDataManager.Instance().statsAndAchievementsDataList.Find((StatsAndAchievementsData x) => x.ID == _achievementID);
		if (_achievement != null)
		{
			GameDataManager.Instance().statsAndAchievementsDataList.Find((StatsAndAchievementsData x) => x.ID == _achievement.ID).Achieved = "1";
			GameDataManager.Instance().SaveStatsAndAchievements();
		}
		if (SteamAPI.Init())
		{
			SteamUserStats.SetAchievement(_achievementID);
			SteamUserStats.StoreStats();
		}
	}
}
