using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class PackageIconController : MonoBehaviour
{
	public PackageItemData itemData = new PackageItemData();

	[SerializeField]
	private Image Border;

	[SerializeField]
	private GameObject EnhenceBorder;

	[SerializeField]
	private GameObject FullInfo;

	[SerializeField]
	private Image FullInfoIcon;

	[SerializeField]
	private GameObject FullInfoCheck;

	[SerializeField]
	private Transform FullInfoEnhence;

	[SerializeField]
	private Transform FullInfoInfo;

	[SerializeField]
	private Transform FullInfoHeadIcon;

	[SerializeField]
	private GameObject FullInfoUsed;

	[SerializeField]
	private Text FullInfoPrice;

	[SerializeField]
	private GameObject FullInfoNewItem;

	[SerializeField]
	private Text FullInfoNum;

	[SerializeField]
	private GameObject FullName;

	[SerializeField]
	private Image FullNameIcon;

	[SerializeField]
	private Text FullNameText;

	[SerializeField]
	private Text FullNamePrice;

	[SerializeField]
	private Text FullNameNum;

	public gang_b07Table.Row b07Row
	{
		get
		{
			return itemData.b07Row;
		}
		set
		{
			itemData.b07Row = value;
		}
	}

	public CharaData userData
	{
		get
		{
			return itemData.userData;
		}
		set
		{
			itemData.userData = value;
		}
	}

	public int number
	{
		get
		{
			return itemData.number;
		}
		set
		{
			itemData.number = value;
		}
	}

	public int originPrice
	{
		get
		{
			return itemData.originPrice;
		}
		set
		{
			itemData.originPrice = value;
		}
	}

	public int effectPrice
	{
		get
		{
			return itemData.effectPrice;
		}
		set
		{
			itemData.effectPrice = value;
		}
	}

	private void Start()
	{
	}

	public void HideNewInfo()
	{
		if (itemData.isNew)
		{
			SharedData.Instance().m_NewItemList.Remove(itemData.ID);
			itemData.isNew = false;
			FullInfoNewItem.SetActive(value: false);
		}
	}

	private void CheckIsShop()
	{
		if (SharedData.Instance().m_PackageController.isShop)
		{
			FullInfoInfo.gameObject.SetActive(value: false);
			FullInfoEnhence.gameObject.SetActive(value: false);
			HoverWGController component = GetComponent<HoverWGController>();
			component.shopHoverItem = SharedData.Instance().m_PackageController.ShopHoverItem;
			component.shopHoverWuGong = SharedData.Instance().m_PackageController.ShopHoverWuGong;
		}
	}

	public void InitPackageIcon(gang_b07Table.Row _b07Row, int _number, CharaData _userData, int _price)
	{
		InitB07Row(_b07Row);
		InitUserData(_userData);
		InitNumber(_number);
		InitPrice(_price);
		if (_b07Row != null)
		{
			base.gameObject.name = "ItemBtn|" + _b07Row.ID + "|" + ((_b07Row != null) ? b07Row.Use : "") + "|" + ((_userData != null) ? _userData.m_Id : "null");
		}
		else
		{
			base.gameObject.name = "ItemBtn||" + ((_b07Row != null) ? b07Row.Use : "") + "|" + ((_userData != null) ? _userData.m_Id : "null");
		}
	}

	public void InitPackageIcon(PackageItemData _packageItemData, bool isShowHeadIcoN = true, bool isInheritance = false, bool isApperciation = false)
	{
		base.transform.GetComponent<Image>().sprite = CommonResourcesData.NormalPackageIconSprite;
		itemData = _packageItemData;
		if (itemData.isNew)
		{
			FullInfoNewItem.SetActive(value: true);
			Border.sprite = CommonResourcesData.NewItemSprite;
		}
		else
		{
			FullInfoNewItem.SetActive(value: false);
			Border.sprite = CommonResourcesData.NormalPackageIconSprite;
		}
		InitB07Row(itemData.b07Row);
		InitUserData(itemData.userData, isShowHeadIcoN);
		InitNumber(itemData.number);
		InitPrice(itemData.originPrice);
		CheckIsShop();
		FullName.SetActive(SharedData.Instance().isShowFullName);
		FullInfo.SetActive(!SharedData.Instance().isShowFullName);
		base.gameObject.name = "ItemBtn|" + _packageItemData.ID + "|" + ((_packageItemData.b07Row != null) ? _packageItemData.b07Row.Use : "") + "|" + ((_packageItemData.userData != null) ? _packageItemData.userData.m_Id : "null");
		if (SharedData.Instance().OpenPackagerFunction == PackagerFunction.EvolutionEQ && b07Row != null)
		{
			int num = int.Parse(SharedData.Instance().OpenPackageFor.Split("|")[1]);
			int num2 = 0;
			for (int i = 1; i <= SharedData.Instance().m_EvolutionEqNewController.materials.Count; i++)
			{
				if (b07Row.ID == SharedData.Instance().m_EvolutionEqNewController.materials[i - 1] && num != i)
				{
					num2++;
				}
			}
			if (num2 >= SharedData.Instance().PlayerPackage[b07Row.ID])
			{
				FullInfoCheck.SetActive(value: true);
				FullInfoIcon.color = new Color(1f, 1f, 1f, 0.3f);
			}
			else
			{
				FullInfoCheck.SetActive(value: false);
				FullInfoIcon.color = Color.white;
			}
		}
		if (isInheritance)
		{
			base.transform.GetComponent<Image>().sprite = CommonResourcesData.InheritanceSprite;
			EnhenceBorder.SetActive(value: false);
		}
		if (isApperciation)
		{
			base.transform.GetComponent<Image>().sprite = CommonResourcesData.SelectedSprite;
			EnhenceBorder.SetActive(value: false);
		}
	}

	public void InitB07Row(gang_b07Table.Row _b07Row = null)
	{
		b07Row = _b07Row;
		if (b07Row == null)
		{
			FullInfoIcon.sprite = CommonResourcesData.TransprantSprite;
			FullNameIcon.sprite = FullInfoIcon.sprite;
			FullNameText.text = "";
			FullInfoInfo.gameObject.SetActive(value: false);
			FullInfoHeadIcon.gameObject.SetActive(value: false);
			FullInfoUsed.SetActive(value: false);
			FullInfoCheck.SetActive(value: false);
			FullInfoPrice.gameObject.SetActive(value: false);
			FullNamePrice.gameObject.SetActive(value: false);
			FullInfoEnhence.gameObject.SetActive(value: false);
			EnhenceBorder.SetActive(value: false);
			FullInfoNewItem.SetActive(value: false);
			FullInfoIcon.color = Color.white;
			return;
		}
		FullInfoIcon.sprite = CommonResourcesData.GetBookIcon(b07Row.BookIcon);
		FullNameIcon.sprite = FullInfoIcon.sprite;
		FullNameText.text = b07Row.Name_Trans;
		FullInfoCheck.SetActive(value: false);
		FullInfoIcon.color = Color.white;
		if (b07Row.Use[8] == '1')
		{
			FullInfoInfo.gameObject.SetActive(value: true);
			gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(b07Row.Relateid);
			FullInfoInfo.Find("Text").GetComponent<Text>().text = row.Star + " " + CommonFunc.GetWugongStyle(row.Style);
			if (!CheckKFBook(row))
			{
				FullInfoCheck.SetActive(value: true);
				FullInfoIcon.color = new Color(1f, 1f, 1f, 0.3f);
			}
			else
			{
				FullInfoCheck.SetActive(value: false);
				FullInfoIcon.color = Color.white;
			}
		}
		else
		{
			FullInfoInfo.gameObject.SetActive(value: false);
		}
		FullInfoEnhence.gameObject.SetActive(value: false);
		EnhenceBorder.SetActive(value: false);
		if (b07Row.Use[2] == '1' || b07Row.Use[3] == '1' || b07Row.Use[4] == '1')
		{
			gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(b07Row.Relateid);
			if (row2 == null)
			{
				return;
			}
			if (!CheckEquipment(row2))
			{
				FullInfoCheck.SetActive(value: true);
				FullInfoIcon.color = new Color(1f, 1f, 1f, 0.3f);
			}
			else
			{
				FullInfoCheck.SetActive(value: false);
				FullInfoIcon.color = Color.white;
			}
			if (row2.Enhance > 0)
			{
				FullInfoEnhence.gameObject.SetActive(value: true);
				FullInfoEnhence.Find("Text").GetComponent<Text>().text = "+" + row2.Enhance;
				if (row2.Enhance.Equals(10))
				{
					EnhenceBorder.SetActive(value: true);
				}
			}
		}
		else
		{
			FullInfoEnhence.gameObject.SetActive(value: false);
			EnhenceBorder.SetActive(value: false);
		}
	}

	public void InitUserData(CharaData _charaData = null, bool isShowHeadIcoN = true)
	{
		userData = _charaData;
		FullInfoUsed.SetActive(userData != null);
		if (isShowHeadIcoN)
		{
			FullInfoHeadIcon.gameObject.SetActive(userData != null);
			if (userData != null)
			{
				Sprite tachieHead = CommonResourcesData.GetTachieHead(userData.m_BattleIcon);
				if (tachieHead == null)
				{
					FullInfoHeadIcon.Find("Image").gameObject.SetActive(value: false);
					FullInfoHeadIcon.Find("IconPixel").gameObject.SetActive(value: true);
					FullInfoHeadIcon.Find("IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(userData);
				}
				else
				{
					FullInfoHeadIcon.Find("Image").gameObject.SetActive(value: true);
					FullInfoHeadIcon.Find("IconPixel").gameObject.SetActive(value: false);
					FullInfoHeadIcon.Find("Image").GetComponent<Image>().sprite = tachieHead;
				}
			}
		}
		else
		{
			FullInfoHeadIcon.gameObject.SetActive(value: false);
		}
	}

	public void InitNumber(int _number = 0)
	{
		number = _number;
		FullInfoNum.text = ((number > 1) ? ((object)number) : "")?.ToString() ?? "";
		FullNameNum.text = ((number > 1) ? ((object)number) : "")?.ToString() ?? "";
	}

	public void InitPrice(int _price)
	{
		originPrice = _price;
		FullInfoPrice.gameObject.SetActive(value: false);
		FullNamePrice.gameObject.SetActive(value: false);
		if (SharedData.Instance().OpenPackagerFunction == PackagerFunction.PlayerPackage)
		{
			return;
		}
		if (SharedData.Instance().OpenPackagerFunction == PackagerFunction.Shop)
		{
			effectPrice = originPrice;
		}
		else if (SharedData.Instance().OpenPackagerFunction == PackagerFunction.Appreciation)
		{
			effectPrice = Mathf.FloorToInt((float)originPrice * 0.1f);
		}
		else if (SharedData.Instance().OpenPackagerFunction == PackagerFunction.Loan)
		{
			effectPrice = Mathf.FloorToInt((float)originPrice * 0.2f);
		}
		else if (SharedData.Instance().OpenPackagerFunction == PackagerFunction.Redeem)
		{
			effectPrice = Mathf.FloorToInt((float)originPrice * 0.3f);
		}
		if (originPrice != 0 && effectPrice < 1)
		{
			effectPrice = 1;
		}
		string text = effectPrice + " ";
		if (itemData.priceType.Equals(PriceType.money))
		{
			text += CommonFunc.I18nGetLocalizedValue("I18N_Money_1");
		}
		else if (itemData.priceType.Equals(PriceType.oldcoin))
		{
			text += CommonFunc.I18nGetLocalizedValue("I18N_Package_Currency_OldCoin");
		}
		else if (itemData.priceType.Equals(PriceType.bone))
		{
			text += CommonFunc.I18nGetLocalizedValue("I18N_Package_Currency_Bone");
		}
		if (effectPrice <= 0)
		{
			return;
		}
		if (SharedData.Instance().m_PackageController.isShop)
		{
			FullInfoPrice.gameObject.SetActive(value: true);
			FullNamePrice.gameObject.SetActive(value: true);
			if (SharedData.Instance().m_PackageController.GetCurrencyValue(itemData.priceType) < effectPrice && SharedData.Instance().OpenPackagerFunction != PackagerFunction.Loan)
			{
				text = "<color=#e74722>" + text + "</color>";
			}
		}
		FullInfoPrice.text = text;
		FullNamePrice.text = text;
	}

	private void OnHoverButtonClick(GameObject go)
	{
		if (!CommonFunc.IsHoverOpen())
		{
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(go.gameObject, showEquip: false, useCharaData: false));
		}
	}

	public static bool CheckEquipment(gang_b02Table.Row b02row)
	{
		if (SharedData.Instance().CurrentCharaData == null)
		{
			return true;
		}
		bool result = true;
		if (b02row != null && b02row.Limit1 != "0")
		{
			float fieldValueByName = SharedData.Instance().CurrentCharaData.GetFieldValueByName(b02row.Limit1);
			float num = float.Parse(b02row.Limitvalue, CultureInfo.InvariantCulture);
			result = ((b02row.Logic == "1") ? (fieldValueByName >= num) : ((!(b02row.Logic == "2")) ? (fieldValueByName == num) : (fieldValueByName <= num)));
		}
		return result;
	}

	public static bool CheckKFBook(gang_b03Table.Row b03row)
	{
		if (SharedData.Instance().CurrentCharaData == null)
		{
			return true;
		}
		bool flag = true;
		bool flag2 = false;
		foreach (KongFuData kongFu in SharedData.Instance().CurrentCharaData.m_KongFuList)
		{
			if (kongFu.kf.ID.Equals(b03row.ID))
			{
				flag2 = true;
				break;
			}
		}
		if (flag2)
		{
			return true;
		}
		int num = Mathf.FloorToInt(SharedData.Instance().CurrentCharaData.GetFieldValueByName("BON"));
		bool flag3 = SharedData.Instance().CurrentCharaData.m_KongFuList.Count >= num;
		string kungfuID = b03row.ID;
		if (kungfuID.Contains("MB03"))
		{
			kungfuID = kungfuID.Split('_')[1];
		}
		if (SharedData.Instance().CurrentCharaData.m_KongFuList.Find((KongFuData x) => x.kf.ID.Equals(kungfuID) || x.kf.ID.Contains("_" + kungfuID + "_")) != null)
		{
			flag3 = false;
		}
		if (flag3)
		{
			return false;
		}
		foreach (string item in new List<string> { b03row.Limit1, b03row.Limit2 })
		{
			if (!flag)
			{
				break;
			}
			if (item.Equals("0") || item.Equals(""))
			{
				continue;
			}
			string[] array = item.Split('|');
			if ("@".Equals(array[0]))
			{
				if ("TRAIT".Equals(array[1]))
				{
					string[] array2 = array[2].Split('_');
					bool flag4 = false;
					string[] array3 = array2;
					foreach (string text in array3)
					{
						if (CommonResourcesData.b06.Find_id(text) != null)
						{
							flag4 = SharedData.Instance().CurrentCharaData.m_TraitList.Contains(text);
						}
						else
						{
							Debug.LogWarning("!>>> " + text + " NOT in table B06.");
						}
						if (flag4)
						{
							break;
						}
					}
					flag = flag4;
				}
				else if ("ROLE".Equals(array[1]))
				{
					gang_b10Table.Row row = CommonResourcesData.b10.Find_ID(array[2]);
					if (row != null)
					{
						List<string> list = new List<string>(row.Members.Split('|'));
						string text2 = SharedData.Instance().CurrentCharaData.m_Id;
						if (text2.Contains("_"))
						{
							text2 = text2.Split('_')[0];
						}
						flag = list.Contains(text2);
					}
					else
					{
						Debug.LogWarning("!>>> " + array[2] + " NOT in table B10.");
					}
				}
				else
				{
					Debug.LogWarning("!>>> Can NOT deal with PARA[" + array[1] + "].");
				}
			}
			else
			{
				float fieldValueByName = SharedData.Instance().CurrentCharaData.GetFieldValueByName(array[0]);
				float num2 = float.Parse(array[2], CultureInfo.InvariantCulture);
				flag = ((!(array[1] == "1")) ? ((!(array[1] == "2")) ? (fieldValueByName == num2) : (fieldValueByName <= num2)) : (fieldValueByName >= num2));
			}
		}
		return flag;
	}

	public bool CouldShopBtnActive()
	{
		if (number > 0 && effectPrice <= SharedData.Instance().m_PackageController.GetCurrencyValue(itemData.priceType))
		{
			return true;
		}
		return false;
	}
}
