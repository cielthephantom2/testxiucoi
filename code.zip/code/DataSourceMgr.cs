using System;
using System.Collections.Generic;
using UnityEngine;

public class DataSourceMgr<T> where T : ItemDataBase, new()
{
	private List<T> mItemDataList = new List<T>();

	private Action mOnRefreshFinished;

	private Action mOnLoadMoreFinished;

	private int mLoadMoreCount = 20;

	private float mDataLoadLeftTime;

	private float mDataRefreshLeftTime;

	private bool mIsWaittingRefreshData;

	private bool mIsWaitLoadingMoreData;

	public int TotalItemCount => mItemDataList.Count;

	public List<T> ItemDataList => mItemDataList;

	public DataSourceMgr(int count)
	{
		DoRefreshDataSource(count);
	}

	public T GetItemDataByIndex(int index)
	{
		if (index < 0 || index >= mItemDataList.Count)
		{
			return null;
		}
		return mItemDataList[index];
	}

	public void RequestRefreshDataList(Action onReflushFinished)
	{
		mDataRefreshLeftTime = 1f;
		mOnRefreshFinished = onReflushFinished;
		mIsWaittingRefreshData = true;
	}

	public void RequestLoadMoreDataList(int loadCount, Action onLoadMoreFinished)
	{
		mLoadMoreCount = loadCount;
		mDataLoadLeftTime = 1f;
		mOnLoadMoreFinished = onLoadMoreFinished;
		mIsWaitLoadingMoreData = true;
	}

	public void Update()
	{
		if (mIsWaittingRefreshData)
		{
			mDataRefreshLeftTime -= Time.deltaTime;
			if (mDataRefreshLeftTime <= 0f)
			{
				mIsWaittingRefreshData = false;
				DoRefreshDataSource(mItemDataList.Count);
				if (mOnRefreshFinished != null)
				{
					mOnRefreshFinished();
				}
			}
		}
		if (!mIsWaitLoadingMoreData)
		{
			return;
		}
		mDataLoadLeftTime -= Time.deltaTime;
		if (mDataLoadLeftTime <= 0f)
		{
			mIsWaitLoadingMoreData = false;
			AppendData(mLoadMoreCount);
			if (mOnLoadMoreFinished != null)
			{
				mOnLoadMoreFinished();
			}
		}
	}

	public void SetDataTotalCount(int count)
	{
		int count2 = mItemDataList.Count;
		if (count != count2)
		{
			if (count > count2)
			{
				AppendData(count - count2);
			}
			else
			{
				mItemDataList.RemoveRange(count, count2 - count);
			}
		}
	}

	public void ExchangeData(int index1, int index2)
	{
		T value = mItemDataList[index1];
		T value2 = mItemDataList[index2];
		mItemDataList[index1] = value2;
		mItemDataList[index2] = value;
	}

	public void RemoveData(int index)
	{
		mItemDataList.RemoveAt(index);
	}

	public T InsertData(int index)
	{
		T val = new T();
		val.Init(index);
		mItemDataList.Insert(index, val);
		for (int i = index + 1; i < mItemDataList.Count; i++)
		{
			mItemDataList[i].OnIndexChanged(i);
		}
		return val;
	}

	public T InsertData(int index, T newData)
	{
		mItemDataList.Insert(index, newData);
		for (int i = index + 1; i < mItemDataList.Count; i++)
		{
			mItemDataList[i].OnIndexChanged(i);
		}
		return newData;
	}

	private void DoRefreshDataSource(int count)
	{
		mItemDataList.Clear();
		for (int i = 0; i < count; i++)
		{
			T val = new T();
			val.Init(i);
			mItemDataList.Add(val);
		}
	}

	public void AppendData(int addCount)
	{
		int count = mItemDataList.Count;
		for (int i = 0; i < addCount; i++)
		{
			int index = i + count;
			T val = new T();
			val.Init(index);
			mItemDataList.Add(val);
		}
	}

	public void AppendData(T itemData)
	{
		mItemDataList.Add(itemData);
	}

	public List<T> GetFilteredItemList(string filterStr)
	{
		if (string.IsNullOrEmpty(filterStr))
		{
			return mItemDataList;
		}
		List<T> list = new List<T>();
		foreach (T mItemData in mItemDataList)
		{
			if (mItemData.IsFilterMatched(filterStr))
			{
				list.Add(mItemData);
			}
		}
		return list;
	}
}
