using System.Collections.Generic;
using UnityEngine;

public class gang_b06Table
{
	public class Row
	{
		public string id;

		public string good;

		public string name;

		public string name_EN;

		public string probability;

		public string add1;

		public string attribute1;

		public string add2;

		public string attribute2;

		public string add3;

		public string attribute3;

		public string add4;

		public string attribute4;

		public string Skills1;

		public string Skills1Ec;

		public string Skills2;

		public string Skills2Ec;

		public string Skills3;

		public string Skills3Ec;

		public string eventid;

		public string createType;

		public string breaktype;

		public string note;

		public string note_EN;

		public string comment;

		public string comment_EN;

		public string isTitle;

		public string traitEquipIndex;

		public string traitAdditional;

		public string titleLeveUp;

		public string isLockTrait;

		public string traitCost;

		public string isAtlas;

		public string name_Trans => CommonFunc.ShortLangSel(name, name_EN);

		public string note_Trans => CommonFunc.ShortLangSel(note, note_EN);

		public string comment_Trans => CommonFunc.ShortLangSel(comment, comment_EN);
	}

	private List<Row> rowList = new List<Row>();

	private Dictionary<string, Row> rowDict = new Dictionary<string, Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				id = list[i][num++],
				good = list[i][num++],
				name = list[i][num++],
				probability = list[i][num++],
				add1 = list[i][num++],
				attribute1 = list[i][num++],
				add2 = list[i][num++],
				attribute2 = list[i][num++],
				add3 = list[i][num++],
				attribute3 = list[i][num++],
				add4 = list[i][num++],
				attribute4 = list[i][num++],
				Skills1 = list[i][num++],
				Skills1Ec = list[i][num++],
				Skills2 = list[i][num++],
				Skills2Ec = list[i][num++],
				Skills3 = list[i][num++],
				Skills3Ec = list[i][num++],
				eventid = list[i][num++],
				createType = list[i][num++],
				breaktype = list[i][num++],
				note = list[i][num++],
				comment = list[i][num++],
				isTitle = list[i][num++],
				traitEquipIndex = list[i][num++],
				traitAdditional = list[i][num++],
				titleLeveUp = list[i][num++],
				isLockTrait = list[i][num++],
				traitCost = list[i][num++],
				isAtlas = list[i][num++]
			};
			row.name = I18nData.Instance().tableI18N.Find_ID("gang_b06_" + row.id + "_Name")?.zh_CH;
			row.name_EN = I18nData.Instance().tableI18N.Find_ID("gang_b06_" + row.id + "_Name")?.en_US;
			row.note = I18nData.Instance().tableI18N.Find_ID("gang_b06_" + row.id + "_Note")?.zh_CH;
			row.note_EN = I18nData.Instance().tableI18N.Find_ID("gang_b06_" + row.id + "_Note")?.en_US;
			row.comment = I18nData.Instance().tableI18N.Find_ID("gang_b06_" + row.id + "_Comment")?.zh_CH;
			row.comment_EN = I18nData.Instance().tableI18N.Find_ID("gang_b06_" + row.id + "_Comment")?.en_US;
			rowList.Add(row);
			rowDict.Add(row.id, row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		if (rowDict.ContainsKey(find))
		{
			return rowDict[find];
		}
		return null;
	}

	public List<Row> FindAll_id(string find)
	{
		return rowList.FindAll((Row x) => x.id == find);
	}

	public Row Find_good(string find)
	{
		return rowList.Find((Row x) => x.good == find);
	}

	public List<Row> FindAll_good(string find)
	{
		return rowList.FindAll((Row x) => x.good == find);
	}

	public Row Find_name(string find)
	{
		return rowList.Find((Row x) => x.name == find);
	}

	public List<Row> FindAll_name(string find)
	{
		return rowList.FindAll((Row x) => x.name == find);
	}

	public Row Find_name_EN(string find)
	{
		return rowList.Find((Row x) => x.name_EN == find);
	}

	public List<Row> FindAll_name_EN(string find)
	{
		return rowList.FindAll((Row x) => x.name_EN == find);
	}

	public Row Find_probability(string find)
	{
		return rowList.Find((Row x) => x.probability == find);
	}

	public List<Row> FindAll_probability(string find)
	{
		return rowList.FindAll((Row x) => x.probability == find);
	}

	public Row Find_add1(string find)
	{
		return rowList.Find((Row x) => x.add1 == find);
	}

	public List<Row> FindAll_add1(string find)
	{
		return rowList.FindAll((Row x) => x.add1 == find);
	}

	public Row Find_attribute1(string find)
	{
		return rowList.Find((Row x) => x.attribute1 == find);
	}

	public List<Row> FindAll_attribute1(string find)
	{
		return rowList.FindAll((Row x) => x.attribute1 == find);
	}

	public Row Find_add2(string find)
	{
		return rowList.Find((Row x) => x.add2 == find);
	}

	public List<Row> FindAll_add2(string find)
	{
		return rowList.FindAll((Row x) => x.add2 == find);
	}

	public Row Find_attribute2(string find)
	{
		return rowList.Find((Row x) => x.attribute2 == find);
	}

	public List<Row> FindAll_attribute2(string find)
	{
		return rowList.FindAll((Row x) => x.attribute2 == find);
	}

	public Row Find_add3(string find)
	{
		return rowList.Find((Row x) => x.add3 == find);
	}

	public List<Row> FindAll_add3(string find)
	{
		return rowList.FindAll((Row x) => x.add3 == find);
	}

	public Row Find_attribute3(string find)
	{
		return rowList.Find((Row x) => x.attribute3 == find);
	}

	public List<Row> FindAll_attribute3(string find)
	{
		return rowList.FindAll((Row x) => x.attribute3 == find);
	}

	public Row Find_add4(string find)
	{
		return rowList.Find((Row x) => x.add4 == find);
	}

	public List<Row> FindAll_add4(string find)
	{
		return rowList.FindAll((Row x) => x.add4 == find);
	}

	public Row Find_attribute4(string find)
	{
		return rowList.Find((Row x) => x.attribute4 == find);
	}

	public List<Row> FindAll_attribute4(string find)
	{
		return rowList.FindAll((Row x) => x.attribute4 == find);
	}

	public Row Find_eventid(string find)
	{
		return rowList.Find((Row x) => x.eventid == find);
	}

	public List<Row> FindAll_eventid(string find)
	{
		return rowList.FindAll((Row x) => x.eventid == find);
	}

	public Row Find_breaktype(string find)
	{
		return rowList.Find((Row x) => x.breaktype == find);
	}

	public List<Row> FindAll_breaktype(string find)
	{
		return rowList.FindAll((Row x) => x.breaktype == find);
	}

	public Row Find_note(string find)
	{
		return rowList.Find((Row x) => x.note == find);
	}

	public List<Row> FindAll_note(string find)
	{
		return rowList.FindAll((Row x) => x.note == find);
	}

	public Row Find_note_EN(string find)
	{
		return rowList.Find((Row x) => x.note_EN == find);
	}

	public List<Row> FindAll_note_EN(string find)
	{
		return rowList.FindAll((Row x) => x.note_EN == find);
	}

	public Row Find_comment(string find)
	{
		return rowList.Find((Row x) => x.comment == find);
	}

	public List<Row> FindAll_comment(string find)
	{
		return rowList.FindAll((Row x) => x.comment == find);
	}

	public Row Find_comment_EN(string find)
	{
		return rowList.Find((Row x) => x.comment_EN == find);
	}

	public List<Row> FindAll_comment_EN(string find)
	{
		return rowList.FindAll((Row x) => x.comment_EN == find);
	}
}
