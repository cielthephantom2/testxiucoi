using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public static class InjuryCalManager
{
	public static int GetAttackSideRate(BattleObject _attacker, BattleObject _defender)
	{
		int result = 0;
		if (!(_attacker.m_AttackType[1] == "B"))
		{
			result = ((_attacker.m_Direction == _defender.m_Direction) ? 2 : (((int)_attacker.m_Direction + (int)_defender.m_Direction != 10) ? 1 : 0));
		}
		else
		{
			Vector3Int gridPosition = _attacker.GetGridPosition();
			Vector3Int gridPosition2 = _defender.GetGridPosition();
			if (gridPosition2.x - gridPosition.x > 0 && Mathf.Abs(gridPosition2.x - gridPosition.x) > Mathf.Abs(gridPosition2.y - gridPosition.y))
			{
				switch (_defender.m_Direction)
				{
				case Direction.Down:
				case Direction.Up:
					result = 1;
					break;
				case Direction.Left:
					result = 0;
					break;
				case Direction.Right:
					result = 2;
					break;
				}
			}
			else if (gridPosition2.x - gridPosition.x < 0 && Mathf.Abs(gridPosition2.x - gridPosition.x) > Mathf.Abs(gridPosition2.y - gridPosition.y))
			{
				switch (_defender.m_Direction)
				{
				case Direction.Down:
				case Direction.Up:
					result = 1;
					break;
				case Direction.Left:
					result = 2;
					break;
				case Direction.Right:
					result = 0;
					break;
				}
			}
			else if (gridPosition2.y - gridPosition.y > 0 && Mathf.Abs(gridPosition2.x - gridPosition.x) < Mathf.Abs(gridPosition2.y - gridPosition.y))
			{
				switch (_defender.m_Direction)
				{
				case Direction.Right:
				case Direction.Left:
					result = 1;
					break;
				case Direction.Up:
					result = 0;
					break;
				case Direction.Down:
					result = 2;
					break;
				}
			}
			else if (gridPosition2.y - gridPosition.y < 0 && Mathf.Abs(gridPosition2.x - gridPosition.x) < Mathf.Abs(gridPosition2.y - gridPosition.y))
			{
				switch (_defender.m_Direction)
				{
				case Direction.Right:
				case Direction.Left:
					result = 1;
					break;
				case Direction.Up:
					result = 2;
					break;
				case Direction.Down:
					result = 0;
					break;
				}
			}
		}
		return result;
	}

	public static float CalAttackDamage(BattleObject _attacker, BattleObject _defender)
	{
		if (_attacker.m_BattleController.GetCurrentObjActionType() == ActionType.Fantan)
		{
			return SharedData.Instance().m_BattleController._fantanInjury;
		}
		bool flag = true;
		flag = false;
		float num = 0f;
		num = ((!"701".Equals(_attacker.m_SkillRow.kf.Style)) ? _attacker.charadata.GetBattleValueByName("ATK") : _attacker.charadata.GetBattleValueByName("Melody"));
		if (num < 0f)
		{
			num = 0f;
		}
		float num2 = CommonFunc.saturate(_attacker.charadata.GetBattleValueByName("Hurt") / 255f);
		float num3 = Mathf.Floor(Mathf.Floor(_attacker.charadata.GetBattleValueByName("MP")) * (1f - num2));
		num += num3 / 10f;
		float num4 = float.Parse(_attacker.m_SkillRow.kf.Damage, CultureInfo.InvariantCulture) + float.Parse(_attacker.m_SkillRow.kf.Damageadd, CultureInfo.InvariantCulture) * (float)(_attacker.m_SkillRow.lv - 1);
		float num5 = num4;
		if ("801".Equals(_attacker.m_SkillRow.kf.Style))
		{
			num4 *= 1f + _attacker.charadata.GetBattleValueByName("Drunk") / 25f;
		}
		num4 += _attacker.m_SkillRow.runtime_style_damage;
		num4 = num4 * num4 / 100f;
		float num6 = num + num4;
		float num7 = 0f;
		if (_attacker.charadata.GetBattleValueByName("Mad") >= 25f)
		{
			float num8 = 0f;
			num8 = ((!"701".Equals(_attacker.m_SkillRow.kf.Style)) ? (_attacker.charadata.GetBattleValueByName("DEF") / 12.5f) : (_attacker.charadata.GetBattleValueByName("Melody") / 12.5f));
			num2 = CommonFunc.saturate(_attacker.charadata.GetBattleValueByName("Hurt") / 255f);
			num3 = Mathf.Floor(Mathf.Floor(_attacker.charadata.GetBattleValueByName("MP")) * (1f - num2));
			float num9 = num3 / 65f;
			num7 = 1f + (num8 + num9) / 10f;
			float num10 = num6 / num7;
			if (num10 <= 0f)
			{
				num10 = 1f;
			}
			_attacker.madselftotal += num10;
		}
		float num11 = num6;
		_defender.beAttackSide = GetAttackSideRate(_attacker, _defender);
		switch (_defender.beAttackSide)
		{
		case 0:
			num11 *= 1f + _attacker.charadata.GetBattleValueByName("FrontATK");
			break;
		case 1:
			num11 *= 1f + _attacker.charadata.GetBattleValueByName("FlankATK");
			break;
		case 2:
			num11 *= 1f + _attacker.charadata.GetBattleValueByName("BackATK");
			break;
		}
		num11 = WugongSkillAddAttack(_attacker, _defender, num11, flag);
		num11 = AttributeAddAttack(_attacker, _defender, num11, flag);
		num11 = WugongStyleAddAttack(_attacker, num11, flag);
		num11 = MenpaiWugongAddAttack(_attacker, num11, flag);
		num11 = WugongDebuffAddAttack(_attacker, _defender, num11, flag);
		if (_attacker.CheckBuffEffectOn("Invisible"))
		{
			num11 += num11 * _attacker.charadata.GetBattleValueByName("InvisibleATKup");
		}
		if (_defender.CheckBuffEffectOn("Dizzy"))
		{
			num11 += num11 * _attacker.charadata.GetBattleValueByName("DizzyATKup");
		}
		if (KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "Impact"))
		{
			num11 += num11 * _attacker.charadata.GetBattleValueByName("ImpactATKup");
		}
		if (_attacker.m_SkillRow.kf.Attckstyle.Contains("A|07"))
		{
			num11 += num11 * _attacker.charadata.GetBattleValueByName("ThroughATKup");
		}
		if (KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "Fend") || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "Draw"))
		{
			num11 += num11 * _attacker.charadata.GetBattleValueByName("KnockBackATKup");
		}
		if (_attacker.charadata.GetBattleValueByName("DebuffATKup") > 0f)
		{
			float num12 = 0f;
			num12 += CommonFunc.saturate(_attacker.charadata.Indexs_Name["Mad"].fightValue / float.Parse(SharedData.Instance().m_A01NameRowDirec["Mad"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_attacker.charadata.Indexs_Name["Seal"].fightValue / float.Parse(SharedData.Instance().m_A01NameRowDirec["Seal"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_attacker.charadata.Indexs_Name["Hurt"].fightValue / float.Parse(SharedData.Instance().m_A01NameRowDirec["Hurt"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_attacker.charadata.Indexs_Name["Poison"].fightValue / float.Parse(SharedData.Instance().m_A01NameRowDirec["Poison"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_attacker.charadata.Indexs_Name["Bleed"].fightValue / float.Parse(SharedData.Instance().m_A01NameRowDirec["Bleed"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_attacker.charadata.Indexs_Name["Burn"].fightValue / float.Parse(SharedData.Instance().m_A01NameRowDirec["Burn"].Limit, CultureInfo.InvariantCulture));
			num11 += num11 * num12;
		}
		int num13 = 0;
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			if (!allBattleObj.isDead && !(allBattleObj == _attacker) && !(allBattleObj.race != _attacker.race))
			{
				num13++;
			}
		}
		num11 += num11 * _attacker.charadata.GetBattleValueByName("AllyCountATKup") * (float)num13;
		if (num13 == 0)
		{
			num11 *= 1f + _attacker.charadata.GetBattleValueByName("SingleATKup");
		}
		if (!"701".Equals(_attacker.m_SkillRow.kf.Style))
		{
			num11 *= 1f - _attacker.charadata.GetBattleValueByName("AllWugongDownExceptMelody");
		}
		num11 *= 1f + _attacker.charadata.GetBattleValueByName("Wugong_" + _attacker.m_SkillRow.kf.ID + "_Enhance");
		if (_attacker.charadata.GetBattleValueByName("ChuShouShi") > 0f && _defender.charadata.m_Hp == _defender.charadata.GetBattleValueByName("HP"))
		{
			num11 *= 2f;
			if (Random.Range(0f, 1f) < 0.2f)
			{
				_defender.AddBuff("Dizzy", "", 1f, 1, SharedData.Instance().m_A01NameRowDirec["Dizzy"].NameUI_Trans);
			}
		}
		BuffData buffByName = _attacker.GetBuffByName("KeJi");
		if (buffByName != null)
		{
			num11 *= 1f + buffByName.value;
			_attacker.RemoveBuff(buffByName);
		}
		num11 *= 1f + _attacker.charadata.GetBattleValueByName("FinalInjuryPlus");
		num11 *= 1f - _attacker.charadata.GetBattleValueByName("FinalInjuryMinus");
		num11 *= 1f - _defender.charadata.GetBattleValueByName("EnemyDamageMinus");
		if (_attacker.m_SkillRow.kf.Origin == "1")
		{
			num11 -= num11 * _defender.charadata.GetBattleValueByName("BuddhismDEFup");
		}
		else if (_attacker.m_SkillRow.kf.Origin == "2")
		{
			num11 -= num11 * _defender.charadata.GetBattleValueByName("TaoistDEFup");
		}
		else if (_attacker.m_SkillRow.kf.Origin == "3")
		{
			num11 -= num11 * _defender.charadata.GetBattleValueByName("ConfucianistDEFup");
		}
		else if (_attacker.m_SkillRow.kf.Origin == "4")
		{
			num11 -= num11 * _defender.charadata.GetBattleValueByName("HeresyDEFup");
		}
		else if (_attacker.m_SkillRow.kf.Origin == "5")
		{
			num11 -= num11 * _defender.charadata.GetBattleValueByName("ZaxueDEFup");
		}
		float battleValueByName = _defender.charadata.GetBattleValueByName("MaleDEFup");
		float battleValueByName2 = _defender.charadata.GetBattleValueByName("FemaleDEFup");
		float battleValueByName3 = _defender.charadata.GetBattleValueByName("AnimalDEFup");
		if (battleValueByName > 0f && (_attacker.sex == "1" || _attacker.sex == "0"))
		{
			num11 -= num11 * battleValueByName;
		}
		if (battleValueByName2 > 0f && (_attacker.sex == "2" || _attacker.sex == "0"))
		{
			num11 -= num11 * battleValueByName2;
		}
		if (battleValueByName3 > 0f && _attacker.sex == "3")
		{
			num11 -= num11 * battleValueByName3;
		}
		if (_attacker.charadata.GetBattleValueByName("ZuiYuTuiShan") > 0f && _attacker.sex != _defender.sex)
		{
			num11 *= 1f - _attacker.charadata.GetBattleValueByName("ZuiYuTuiShan");
		}
		if (("4003".Equals(_attacker.m_SkillRow.kf.ID) || "10024".Equals(_attacker.m_SkillRow.kf.ID)) && _defender.sex == "0")
		{
			num11 /= 10f;
		}
		float num14 = 0f;
		num14 = ((!"701".Equals(_attacker.m_SkillRow.kf.Style)) ? (_defender.charadata.GetBattleValueByName("DEF") / 12.5f) : (_defender.charadata.GetBattleValueByName("Melody") / 12.5f));
		num2 = CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Hurt") / 255f);
		num3 = Mathf.Floor(Mathf.Floor(_defender.charadata.GetBattleValueByName("MP")) * (1f - num2));
		float num15 = num3 / 65f;
		float num16 = 1f + (num14 + num15) / 10f;
		if (_defender.charadata.GetBattleValueByName("Mad") >= 25f)
		{
			num16 /= 2f;
		}
		num11 /= num16;
		float num17 = float.Parse(_attacker.m_SkillRow.kf.Beat, CultureInfo.InvariantCulture);
		num11 /= num17;
		num11 *= 1f + _attacker.charadata.GetBattleValueByName("MultihitATKup") * (float)_attacker.ComboCount * (float)int.Parse(_attacker.m_SkillRow.kf.Beat);
		if ("13012".Equals(_attacker.m_SkillRow.kf.ID) || "99036".Equals(_attacker.m_SkillRow.kf.ID))
		{
			num11 = ((!(SharedData.Instance().m_MoneyForAttack > 0f)) ? 0f : (num5 * (1f + _attacker.charadata.GetFieldValueByName("Darts") / 100f) + SharedData.Instance().m_MoneyForAttack / 5f - num7));
			if (flag)
			{
				Debug.Log("[injury by money( " + SharedData.Instance().m_MoneyForAttack + ")]>>> " + num11);
			}
		}
		num11 = Mathf.Ceil(num11);
		if (flag)
		{
			Debug.Log(_attacker.charadata.Indexs_Name["Name"].stringValue + " hit " + _defender.charadata.Indexs_Name["Name"].stringValue + " injury = " + num11 + " * " + _attacker.m_SkillRow.kf.Beat);
		}
		if (num11 <= 1f)
		{
			num11 = 1f;
		}
		if (_defender.charadata.m_EquipTraitDict.ContainsValue("60021") && 2 == _defender.beAttackSide && !_defender.isSealFreeze)
		{
			SharedData.Instance().m_BattleController._fantanInjury = num11;
			num11 = 0f;
			if (SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == _defender && x.counterType == ActionType.Fantan) == null)
			{
				SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(_defender, ActionType.Fantan));
			}
		}
		else if (num11 > _defender.charadata.GetBattleValueByName("HP") * 0.25f && _defender.charadata.m_EquipTraitDict.ContainsValue("60009") && !_defender.isSealFreeze)
		{
			SharedData.Instance().m_BattleController._fantanInjury = num11;
			num11 = 0f;
			if (SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == _defender && x.counterType == ActionType.Fantan) == null)
			{
				SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(_defender, ActionType.Fantan));
			}
		}
		if (num5 < 1f)
		{
			num11 = 0f;
		}
		return num11;
	}

	public static float CalBeHitInjurt(BattleObject _attacker, BattleObject _defender, float _injury)
	{
		if (_injury == 0f)
		{
			return _injury;
		}
		float battleValueByName = _defender.charadata.GetBattleValueByName("DodgeAdd");
		float battleValueByName2 = _attacker.charadata.GetBattleValueByName("Drunk");
		float battleValueByName3 = _attacker.charadata.GetBattleValueByName("Missresist");
		float num = battleValueByName2 / 100f * (1f - CommonFunc.saturate(_attacker.charadata.GetBattleValueByName("Wineart") / 255f));
		BuffData buffByName = _defender.GetBuffByName("Ironvest");
		int knockBackCount = GetKnockBackCount(_attacker, _defender, _injury);
		if (Random.Range(0f, 1f) < battleValueByName && _attacker.m_AttackType[3] == "1")
		{
			_injury = 0f;
			GameObject gameObject = Object.Instantiate(CommonResourcesData.Buff_DodgeAdd_Prefab, _defender.transform);
			gameObject.transform.localPosition = new Vector2(gameObject.transform.localPosition.x - Random.Range(10f, 30f), gameObject.transform.localPosition.y + Random.Range(10f, 30f));
			_defender.PlayAudioClip(AudioClipEnum.missClip);
		}
		else if (battleValueByName3 <= 0f && battleValueByName2 >= 25f && Random.Range(0f, 1f) < num)
		{
			_injury = 0f;
			_defender.PlayAudioClip(AudioClipEnum.missClip);
			_defender.AddDamageInfo("<color=#e74722>" + CommonFunc.I18nGetLocalizedValue("I18N_Miss") + "</color>", "Drunk");
			if (_attacker.race.Equals("player"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1025");
			}
		}
		else if (buffByName != null && buffByName.value > 0f && _attacker.m_AttackType[3] == "1")
		{
			_injury = 0f;
			buffByName.value -= 1f;
			if (buffByName.value == 0f)
			{
				_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_LostIronvest"), "");
				_defender.RemoveBuff(buffByName);
			}
			else
			{
				_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Ironvest"), "");
			}
		}
		else if ("701".Equals(_attacker.m_SkillRow.kf.Style) && _defender.charadata.GetBattleValueByName("MelodyATKresist") > 0f)
		{
			_injury = 0f;
			_defender.PlayAudioClip(AudioClipEnum.hitClip);
			_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_MelodyDamage") + "<color=#e74722> " + CommonFunc.I18nGetLocalizedValue("I18N_Resist") + " </color>", "Drunk");
		}
		else if (knockBackCount == 0 && _defender.CheckBuffEffectOn("Goldenbell"))
		{
			_injury = 0f;
			_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Goldenbell"), "");
		}
		else if (SharedData.Instance().m_BattleController.GetCurrentObjActionType() == ActionType.None && CheckCouldReturnWugong(_attacker, _defender))
		{
			_defender.PlayAudioClip(AudioClipEnum.missClip);
			_injury = 0f;
		}
		else if (CheckGouShiYunEffect(_defender))
		{
			_defender.AddDamageInfo(SharedData.Instance().m_A01NameRowDirec["GouShiYun"].NameUI_Trans, "");
			_defender.PlayAudioClip(AudioClipEnum.missClip);
			_injury = 0f;
		}
		else if (CheckShaRenShaFuEffect(_defender))
		{
			_defender.AddDamageInfo(SharedData.Instance().m_A01NameRowDirec["ShaRenShaFu"].NameUI_Trans, "");
			_defender.PlayAudioClip(AudioClipEnum.missClip);
			_injury = 0f;
		}
		else
		{
			if (_attacker.m_AttackType[3] == "2")
			{
				_defender.PlayAudioClip(AudioClipEnum.heal1Clip);
				Debug.Log(_defender.name + " is healed, no behit animation.");
			}
			else
			{
				_attacker.PlayAudioClip(AudioClipEnum.hitClip);
				if (_attacker == _defender)
				{
					Debug.Log(_defender.name + " hit self, should be B04.");
				}
				else
				{
					if (_defender.isSealFreeze && _injury > 0f)
					{
						_defender.UnSealFreeze();
						_defender.InteruptIn(BattleObjectState.HandOut);
					}
					_defender.BattleObjectBeHit();
				}
			}
			bool flag = true;
			flag = false;
			float num2 = float.Parse(_attacker.m_SkillRow.kf.Crit, CultureInfo.InvariantCulture) + float.Parse(_attacker.m_SkillRow.kf.Critadd, CultureInfo.InvariantCulture) * (float)(_attacker.m_SkillRow.lv - 1);
			if (num2 > 0f)
			{
				num2 += _attacker.charadata.GetBattleValueByName("Crit");
				if (flag)
				{
					Debug.Log("[wugong_critical_rate]>>> " + num2 + " = float.Parse(" + _attacker.m_SkillRow.kf.Crit + ") + float.Parse(" + _attacker.m_SkillRow.kf.Critadd + ") * (" + _attacker.m_SkillRow.lv + " - 1) + " + _attacker.charadata.GetBattleValueByName("Crit"));
				}
			}
			if (_defender.beAttackSide == 2 && _attacker.charadata.GetBattleValueByName("BackCrit") > 0f)
			{
				num2 = 1f;
			}
			bool critical = false;
			if (Random.Range(0f, 1f) <= num2)
			{
				if (flag)
				{
					Debug.Log("!!! CRITICAL HIT !!!");
				}
				float num3 = float.Parse(_attacker.m_SkillRow.kf.Crit1, CultureInfo.InvariantCulture) + float.Parse(_attacker.m_SkillRow.kf.Crit1add, CultureInfo.InvariantCulture) * (float)(_attacker.m_SkillRow.lv - 1) + _attacker.charadata.GetBattleValueByName("Crit1");
				if (flag)
				{
					Debug.Log("[wugong_critical]>>> " + num3 + " = float.Parse(" + _attacker.m_SkillRow.kf.Crit1 + ") + float.Parse(" + _attacker.m_SkillRow.kf.Crit1add + ") * (" + _attacker.m_SkillRow.lv + " - 1) + " + _attacker.charadata.GetBattleValueByName("Crit1"));
				}
				critical = true;
				_injury *= num3;
				if (_attacker.charadata.originRace == "player" && _attacker.race == "player")
				{
					_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_CritAddPerception"), "");
				}
				if (_defender.charadata.GetBattleValueByName("BeCritAddIronvest") > 0f)
				{
					_defender.AddBuff("Ironvest", "", 1f, int.MaxValue);
					_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_BeCritAddIronvest"), "");
				}
				if (_defender.charadata.GetBattleValueByName("BeCritHPup") > 0f)
				{
					_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_BeCritAddHP"), "");
					_defender.AddDamageInfo(((int)(_defender.charadata.GetBattleValueByName("BeCritHPup") * _defender.charadata.GetBattleValueByName("HP"))).ToString(), "HEAL");
				}
				if (_defender.charadata.GetBattleValueByName("BeCritMPup") > 0f)
				{
					_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_BeCritAddMP"), "");
					_defender.AddDamageInfo(((int)(_defender.charadata.GetBattleValueByName("BeCritMPup") * _defender.charadata.GetBattleValueByName("MP"))).ToString(), "HEALMP");
				}
				if (_attacker.charadata.GetBattleValueByName("CritHPup") > 0f)
				{
					_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_CritAddHP"), "");
					_attacker.AddDamageInfo(((int)(_attacker.charadata.GetBattleValueByName("CritHPup") * _attacker.charadata.GetBattleValueByName("HP"))).ToString(), "HEAL");
				}
				if (_attacker.charadata.GetBattleValueByName("CritMPup") > 0f)
				{
					_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_CritAddMP"), "");
					_attacker.AddDamageInfo(((int)(_attacker.charadata.GetBattleValueByName("CritHPup") * _attacker.charadata.GetBattleValueByName("MP"))).ToString(), "HEALMP");
				}
				if (_attacker.charadata.GetBattleValueByName("CritATKup") > 0f)
				{
					_attacker.AddBuff("ATKplus", "", _attacker.charadata.GetBattleValueByName("CritATKup"), int.MaxValue);
					_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_CritAddAtk"), "");
				}
				if (_attacker.charadata.GetBattleValueByName("CritFinalInjuryup") > 0f)
				{
					_attacker.AddBuff("FinalInjuryPlus", "", _attacker.charadata.GetBattleValueByName("CritFinalInjuryup"), int.MaxValue);
					_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_CritAddFinalAtk"), "");
				}
				if (_attacker.charadata.GetBattleValueByName("CritSPupALL") > 0f)
				{
					_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_CritAddTeamSP"), "");
					foreach (BattleObject allBattleObj in _attacker.m_BattleController.allBattleObjs)
					{
						if (!allBattleObj.isDead && !(allBattleObj.race != _attacker.race))
						{
							allBattleObj.AddBuff("SP", "", _attacker.charadata.GetBattleValueByName("CritSPupALL"), int.MaxValue);
						}
					}
				}
			}
			_injury = Mathf.Ceil(_injury);
			if (_injury >= _defender.charadata.m_Hp && Random.Range(0f, 1f) < _defender.charadata.GetBattleValueByName("Deathresist"))
			{
				_injury = _defender.charadata.m_Hp - 1f;
				_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Deathresist"), "");
			}
			if ("10001".Equals(_attacker.m_SkillRow.kf.ID) && _attacker.charadata.m_EquipTraitDict.ContainsValue("SCP99"))
			{
				if (_injury > 0f)
				{
					_defender.AddDamageInfo(_injury.ToString(), "SCP99YOU", critical);
				}
			}
			else if (_injury > 0f && _defender.charadata.GetBattleValueByName("TongQiLianZhi") > 0f)
			{
				List<BattleObject> list = _defender.m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.charadata.GetBattleValueByName("TongQiLianZhi") > 0f && x.race == _defender.race);
				float num4 = _injury / (float)list.Count;
				num4 = ((num4 < 1f) ? 1f : num4);
				foreach (BattleObject item in list)
				{
					item.AddDamageInfo(num4.ToString(), "DAMAGE|" + _attacker.m_SkillRow.kf.Beat, critical);
				}
			}
			else if (_injury > 0f)
			{
				_defender.AddDamageInfo(_injury.ToString(), "DAMAGE|" + _attacker.m_SkillRow.kf.Beat, critical);
			}
			if (flag)
			{
				Debug.Log(_attacker.charadata.Indexs_Name["Name"].stringValue + " hit " + _defender.charadata.Indexs_Name["Name"].stringValue + " single injury = " + _injury);
			}
		}
		if (_injury > 9999f)
		{
			StatsAndAchievements.Instance().UnlockAchievement("1060");
		}
		return _injury;
	}

	private static bool CheckGouShiYunEffect(BattleObject battleObject)
	{
		if (battleObject.charadata.GetBattleValueByName("GouShiYun") > 0f)
		{
			float num = battleObject.charadata.GetFieldValueByName("DEF");
			if (battleObject.charadata.originRace == "enemy")
			{
				num = SharedData.Instance().m_Enemy_DEF_Rate * num;
			}
			float num2 = (battleObject.charadata.GetBattleValueByName("DEF") - num) / num;
			if (Random.Range(0f, 1f) < num2)
			{
				return true;
			}
		}
		return false;
	}

	private static bool CheckShaRenShaFuEffect(BattleObject battleObject)
	{
		if (battleObject.charadata.GetBattleValueByName("ShaRenShaFu") > 0f)
		{
			float fieldValueByName = battleObject.charadata.GetFieldValueByName("LER");
			float num = (fieldValueByName - battleObject.charadata.GetBattleValueByName("LER")) / fieldValueByName;
			if (Random.Range(0f, 1f) < num)
			{
				return true;
			}
		}
		return false;
	}

	public static int GetKnockBackCount(BattleObject _attacker, BattleObject _defender, float _injury)
	{
		if (_injury <= 0f)
		{
			return 0;
		}
		if (SharedData.Instance().m_BattleController.GetCurrentObjActionType() == ActionType.Ambush || SharedData.Instance().m_BattleController.GetCurrentObjActionType() == ActionType.Fantan)
		{
			return 1;
		}
		foreach (KeyValuePair<string, string> item in _defender.charadata.m_EquipTraitDict)
		{
			if (!(item.Value == ""))
			{
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.Value);
				if ("Fendresist" == row.add1 || "Fendresist" == row.add2 || "Fendresist" == row.add3 || "Fendresist" == row.add4)
				{
					return 0;
				}
			}
		}
		if (_defender.charadata.m_currentTitleID != "")
		{
			gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(_defender.charadata.m_currentTitleID);
			if ("Fendresist" == row2.add1 || "Fendresist" == row2.add2 || "Fendresist" == row2.add3 || "Fendresist" == row2.add4)
			{
				return 0;
			}
		}
		int num = 0;
		float battleValueByName = _defender.charadata.GetBattleValueByName("HP");
		num = ((!(_injury > battleValueByName)) ? ((int)(_injury / battleValueByName * 100f) / 20) : 5);
		if (num == 0)
		{
			return num;
		}
		SkillInfo skillInfo = new SkillInfo();
		skillInfo.Init(_attacker.m_SkillRow, _attacker);
		int i;
		for (i = 0; i <= skillInfo.sid && !skillInfo.sName[i].Equals("Fend") && !skillInfo.sName[i].Equals("Impact") && !skillInfo.sName[i].Equals("Draw"); i++)
		{
		}
		if (i == skillInfo.sid + 1)
		{
			return 0;
		}
		int num2 = (int)skillInfo.sValueNum[i];
		int num3 = (int)_defender.charadata.GetBattleValueByName("Fend");
		if (num2 < num3)
		{
			return 0;
		}
		if (skillInfo.sName[i] == "Draw")
		{
			num = -num;
		}
		float num4 = (float)(num2 * num2) / 6f / (float)(num3 * num3) + 1f / 3f;
		if (Random.Range(0f, 1f) < num4)
		{
			return num;
		}
		return 0;
	}

	private static float AttributeAddAttack(BattleObject _attacker, BattleObject _defender, float injury, bool IsDamageLog)
	{
		List<string> list = new List<string>
		{
			"MelodyATKup", "YinYangATKup", "MedicalATKup", "DartsATKup", "StealATKup", "STRATKup", "AGIATKup", "BONATKup", "WILATKup", "LERATKup",
			"MORATKup"
		};
		List<string> list2 = new List<string> { "LowSTRATKup", "LowAGIATKup", "LowBONATKup", "LowWILATKup", "LowLERATKup", "LowMORATKup" };
		List<string> list3 = new List<string> { "EnemySTRATKup", "EnemyAGIATKup", "EnemyBONATKup", "EnemyWILATKup", "EnemyLERATKup", "EnemyMORATKup" };
		List<string> list4 = new List<string> { "EnemyLowSTRATKup", "EnemyLowAGIATKup", "EnemyLowBONATKup", "EnemyLowWILATKup", "EnemyLowLERATKup", "EnemyLowMORATKup" };
		if (_attacker.charadata.GetBattleValueByName("SpATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "SpATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加SpATKup injury *= (1f + " + _attacker.charadata.GetBattleValueByName("SP") + " / 1000f)");
			}
			injury *= 1f + _attacker.charadata.GetBattleValueByName("SP") / 1000f;
		}
		if (_attacker.charadata.GetBattleValueByName("DefATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "DefATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加DefATKup injury *= (1f + " + _attacker.charadata.GetBattleValueByName("DEF") + " / 1000f)");
			}
			injury *= 1f + _attacker.charadata.GetBattleValueByName("DEF") / 1000f;
		}
		if (_attacker.charadata.GetBattleValueByName("LowSpATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "LowSpATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加LowSpATKup injury *= (1f + " + _attacker.charadata.GetBattleValueByName("SP") + " / 200f)");
			}
			float num = float.Parse(SharedData.Instance().m_A01NameRowDirec["SP"].Limit, CultureInfo.InvariantCulture);
			injury *= 1f + (num - _attacker.charadata.GetBattleValueByName("SP")) / num;
		}
		if (_attacker.charadata.GetBattleValueByName("LowDefATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "LowDefATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加LowDefATKup injury *= (1f + " + _attacker.charadata.GetBattleValueByName("DEF") + " / 200f)");
			}
			float num2 = float.Parse(SharedData.Instance().m_A01NameRowDirec["DEF"].Limit, CultureInfo.InvariantCulture);
			injury *= 1f + (num2 - _attacker.charadata.GetBattleValueByName("DEF")) / num2;
		}
		if (_attacker.charadata.GetBattleValueByName("LowHpATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "LowHpATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加LowHpATKup injury *= (1f + (1f - " + _attacker.charadata.m_Hp + " / " + _attacker.charadata.GetBattleValueByName("HP") + "))");
			}
			injury *= 1f + (_attacker.charadata.GetBattleValueByName("HP") - _attacker.charadata.m_Hp) / _attacker.charadata.GetBattleValueByName("HP");
		}
		if (_attacker.charadata.GetBattleValueByName("EnemyLowHpATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "EnemyLowHpATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加EnemyLowHpATKup injury *= (1f + (1f - " + _defender.charadata.m_Hp + " / " + _defender.charadata.GetBattleValueByName("HP") + "))");
			}
			injury *= 1f + (_defender.charadata.GetBattleValueByName("HP") - _defender.charadata.m_Hp) / _defender.charadata.GetBattleValueByName("HP");
		}
		if (_attacker.charadata.GetBattleValueByName("HpATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "HpATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加HpATKup injury *= (1f + " + _attacker.charadata.m_Hp + " / " + _attacker.charadata.GetBattleValueByName("HP") + ")");
			}
			injury *= 1f + (1f - _attacker.charadata.m_Hp / _attacker.charadata.GetBattleValueByName("HP"));
		}
		if (_attacker.charadata.GetBattleValueByName("EnemyHpATKup") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "EnemyHpATKup"))
		{
			if (IsDamageLog)
			{
				Debug.Log("属性伤害增加EnemyHpATKup injury *= (1f + " + _defender.charadata.m_Hp + " / " + _defender.charadata.GetBattleValueByName("HP") + ")");
			}
			injury *= 1f + (1f - _defender.charadata.m_Hp / _defender.charadata.GetBattleValueByName("HP"));
		}
		foreach (string item in list)
		{
			if (_attacker.charadata.GetBattleValueByName(item) > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, item))
			{
				string text = item.Replace("ATKup", "");
				float num3 = float.Parse(SharedData.Instance().m_A01NameRowDirec[text].Limit, CultureInfo.InvariantCulture);
				if (IsDamageLog)
				{
					Debug.Log("属性伤害增加 " + item + " injury *= (1f + " + _attacker.charadata.GetBattleValueByName(text) + " /" + num3 + ")");
				}
				injury *= 1f + _attacker.charadata.GetBattleValueByName(text) / num3;
			}
		}
		foreach (string item2 in list2)
		{
			if (_attacker.charadata.GetBattleValueByName(item2) > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, item2))
			{
				string text2 = item2.Replace("ATKup", "").Replace("Low", "");
				float num4 = float.Parse(SharedData.Instance().m_A01NameRowDirec[text2].Limit, CultureInfo.InvariantCulture);
				if (IsDamageLog)
				{
					Debug.Log("属性伤害增加 " + item2 + " injury *= (1f + (" + num4 + " - " + _attacker.charadata.GetBattleValueByName(text2) + ") /" + num4 + ")");
				}
				injury *= 1f + (num4 - _attacker.charadata.GetBattleValueByName(text2)) / num4;
			}
		}
		foreach (string item3 in list3)
		{
			if (_attacker.charadata.GetBattleValueByName(item3) > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, item3))
			{
				string text3 = item3.Replace("ATKup", "").Replace("Enemy", "");
				float num5 = float.Parse(SharedData.Instance().m_A01NameRowDirec[text3].Limit, CultureInfo.InvariantCulture);
				if (IsDamageLog)
				{
					Debug.Log("敌人属性伤害增加 " + item3 + " injury *= (1f + " + _defender.charadata.GetBattleValueByName(text3) + " /" + num5 + ")");
				}
				injury *= 1f + _defender.charadata.GetBattleValueByName(text3) / num5;
			}
		}
		foreach (string item4 in list4)
		{
			if (_attacker.charadata.GetBattleValueByName(item4) > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, item4))
			{
				string text4 = item4.Replace("ATKup", "").Replace("EnemyLow", "");
				float num6 = float.Parse(SharedData.Instance().m_A01NameRowDirec[text4].Limit, CultureInfo.InvariantCulture);
				if (IsDamageLog)
				{
					Debug.Log("敌人属性伤害增加 " + item4 + " injury *= (1f + (" + num6 + " - " + _defender.charadata.GetBattleValueByName(text4) + ") /" + num6 + ")");
				}
				injury *= 1f + (num6 - _defender.charadata.GetBattleValueByName(text4)) / num6;
			}
		}
		return injury;
	}

	private static float WugongSkillAddAttack(BattleObject _attacker, BattleObject _defender, float injury, bool IsDamageLog)
	{
		float num = 0f;
		SkillInfo skillInfo = new SkillInfo();
		skillInfo.Init(_attacker.m_SkillRow, _attacker);
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			string text = skillInfo.sName[i];
			if (Random.Range(0f, 1f) <= skillInfo.sOddNum[i] && SkillTraitEquipManager.CheckIsSkillEffect(_attacker, _defender, skillInfo.sSkillEc[i]))
			{
				switch (text)
				{
				case "DizzyATKup":
					if (_defender.CheckBuffEffectOn("Dizzy"))
					{
						num += skillInfo.sValueNum[i];
					}
					break;
				case "InvisibleATKup":
					if (_attacker.CheckBuffEffectOn("Invisible"))
					{
						num += skillInfo.sValueNum[i];
					}
					break;
				case "SingleATKup":
				{
					List<BattleObject> list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x != _attacker && x.race == _attacker.race);
					if (list == null || list.Count == 0)
					{
						num += skillInfo.sValueNum[i];
					}
					break;
				}
				case "FinalInjuryPlus":
					num += skillInfo.sValueNum[i];
					break;
				}
			}
			injury *= 1f + num;
			if (IsDamageLog)
			{
				Debug.Log("武功Skill [" + text + "] 伤害增加 injury *= (1f + " + num + ")");
			}
		}
		return injury;
	}

	private static float WugongStyleAddAttack(BattleObject _attacker, float injury, bool IsDamageLog)
	{
		float num = 0f;
		switch (_attacker.m_SkillRow.kf.Style)
		{
		case "101":
			num = _attacker.charadata.GetBattleValueByName("WugongSwordATKup");
			break;
		case "201":
			num = _attacker.charadata.GetBattleValueByName("WugongKnifeATKup");
			break;
		case "301":
			num = _attacker.charadata.GetBattleValueByName("WugongStickATKup");
			break;
		case "401":
			num = _attacker.charadata.GetBattleValueByName("WugongHandATKup");
			break;
		case "501":
			num = _attacker.charadata.GetBattleValueByName("WugongFingerATKup");
			break;
		case "601":
			num = _attacker.charadata.GetBattleValueByName("WugongDartsATKup");
			break;
		case "701":
			num = _attacker.charadata.GetBattleValueByName("WugongMelodyATKup");
			break;
		case "801":
			num = _attacker.charadata.GetBattleValueByName("WugongWineartATKup");
			break;
		case "901":
			num = 0f;
			break;
		case "1001":
			num = _attacker.charadata.GetBattleValueByName("WugongSpecialATKup");
			break;
		case "9101":
			num = 0f;
			break;
		case "9301":
			num = 0f;
			break;
		case "9401":
			num = 0f;
			break;
		case "9501":
			num = 0f;
			break;
		case "9601":
			num = 0f;
			break;
		}
		if (IsDamageLog)
		{
			Debug.Log("武功流派伤害增加 injury *= (1f + " + num + ")");
		}
		injury *= 1f + num;
		return injury;
	}

	private static float WugongDebuffAddAttack(BattleObject _attacker, BattleObject _defender, float injury, bool IsDamageLog)
	{
		float num = 0f;
		if (_attacker.charadata.GetBattleValueByName("DebuffDEFdown") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "DebuffDEFdown"))
		{
			num = 0f + (CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Mad") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Mad"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Seal") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Seal"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Hurt") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Hurt"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Poison") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Poison"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Bleed") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Bleed"].Limit, CultureInfo.InvariantCulture)) + CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Burn") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Burn"].Limit, CultureInfo.InvariantCulture)));
		}
		foreach (string item in new List<string> { "EnemyHurtATKup", "EnemySealATKup", "EnemyPoisonATKup", "EnemyBleedATKup", "EnemyBurnATKup", "EnemyMadATKup" })
		{
			if (!(_defender.charadata.GetBattleValueByName(item.Replace("Enemy", "").Replace("ATKup", "")) >= 25f))
			{
				continue;
			}
			if (KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, item))
			{
				SkillInfo skillInfo = new SkillInfo();
				skillInfo.Init(_attacker.m_SkillRow, _attacker);
				for (int i = 0; i <= skillInfo.sid; i++)
				{
					if (skillInfo.sName[i].StartsWith(item) && Random.Range(0f, 1f) < skillInfo.sOddNum[i])
					{
						num += skillInfo.sValueNum[i];
					}
				}
			}
			num += _attacker.charadata.GetBattleValueByName(item);
		}
		if (IsDamageLog)
		{
			Debug.Log("敌人debuff导致伤害增加 injury *= (1f + " + num + ")");
		}
		float num2 = 0f;
		foreach (string item2 in new List<string> { "HurtATKup", "SealATKup", "PoisonATKup", "BleedATKup", "BurnATKup", "MadATKup" })
		{
			if (!(_attacker.charadata.GetBattleValueByName(item2.Replace("ATKup", "")) >= 25f))
			{
				continue;
			}
			if (KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, item2))
			{
				SkillInfo skillInfo2 = new SkillInfo();
				skillInfo2.Init(_attacker.m_SkillRow, _attacker);
				for (int j = 0; j <= skillInfo2.sid; j++)
				{
					if (skillInfo2.sName[j].StartsWith(item2) && Random.Range(0f, 1f) <= skillInfo2.sOddNum[j])
					{
						num2 += skillInfo2.sValueNum[j];
					}
				}
			}
			num2 += _attacker.charadata.GetBattleValueByName(item2);
		}
		if (IsDamageLog)
		{
			Debug.Log("自身debuff导致伤害增加 injury *= (1f + " + num2 + ")");
		}
		injury *= 1f + num + num2;
		return injury;
	}

	private static float MenpaiWugongAddAttack(BattleObject _attacker, float injury, bool IsDamageLog)
	{
		float num = 0f;
		switch (_attacker.m_SkillRow.kf.Origin)
		{
		case "1":
			num = _attacker.charadata.GetBattleValueByName("BuddhismWugongATKup");
			break;
		case "2":
			num = _attacker.charadata.GetBattleValueByName("TaoistWugongATKup");
			break;
		case "3":
			num = _attacker.charadata.GetBattleValueByName("ConfucianistWugongATKup");
			break;
		case "4":
			num = _attacker.charadata.GetBattleValueByName("HeresyWugongATKup");
			break;
		case "5":
			num = _attacker.charadata.GetBattleValueByName("ZaxueWugongATKup");
			break;
		}
		if (IsDamageLog)
		{
			Debug.Log("门派武学伤害增加 injury *= (1f + " + num + ")");
		}
		injury *= 1f + num;
		return injury;
	}

	public static bool CheckCouldReturnWugong(BattleObject _attacker, BattleObject _defender)
	{
		if (_attacker.m_SkillRow.isSwapPosSkill || _attacker.m_SkillRow.kf.Attckstyle.StartsWith("A|06"))
		{
			return false;
		}
		KongFuData skillRow = _attacker.m_SkillRow;
		int lv = skillRow.lv;
		int num = 0;
		foreach (KongFuData kongFu in _defender.charadata.m_KongFuList)
		{
			if (!(Mathf.Floor(float.Parse(kongFu.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(kongFu.kf.Expendadd, CultureInfo.InvariantCulture) * ((float)kongFu.lv - 1f)) > _defender.charadata.m_Mp) && kongFu.kf.ID == skillRow.kf.ID)
			{
				num = kongFu.lv;
				break;
			}
		}
		if (num > lv)
		{
			return true;
		}
		if (num == lv && Random.Range(0f, 1f) < 0.5f)
		{
			return true;
		}
		return false;
	}
}
