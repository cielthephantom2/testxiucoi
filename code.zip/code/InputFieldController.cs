using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class InputFieldController : MonoBehaviour, IPointerClickHandler, IEventSystemHandler
{
	private TMP_InputField m_InputField;

	private Callback<GamepadTextInputDismissed_t> gamepadTextInputDismissedCallback;

	private SteamKeyboard steamKeyboardToUse = SteamKeyboard.BigPictureKeyboard;

	private bool isKeyBoardOpen;

	private void Awake()
	{
		m_InputField = GetComponent<TMP_InputField>();
		m_InputField.onSelect.AddListener(OnInputFieldSelectHandler);
		m_InputField.onDeselect.AddListener(OnInputFieldDeselectHandler);
		gamepadTextInputDismissedCallback = Callback<GamepadTextInputDismissed_t>.Create(OnGamepadTextInputDismissed);
	}

	public void OnPointerClick(PointerEventData eventData)
	{
		if (!isKeyBoardOpen)
		{
			OnInputFieldSelectHandler("");
		}
	}

	private void OnGamepadTextInputDismissed(GamepadTextInputDismissed_t callback)
	{
		if (!RunningEnvironment.isSteamDeck)
		{
			return;
		}
		isKeyBoardOpen = false;
		if (callback.m_bSubmitted)
		{
			uint enteredGamepadTextLength = SteamUtils.GetEnteredGamepadTextLength();
			if (SteamUtils.GetEnteredGamepadTextInput(out var pchText, enteredGamepadTextLength))
			{
				m_InputField.text = pchText;
			}
		}
	}

	private void OnInputFieldSelectHandler(string text)
	{
		if (RunningEnvironment.isSteamDeck)
		{
			isKeyBoardOpen = true;
			switch (steamKeyboardToUse)
			{
			case SteamKeyboard.FloatingKeyboard:
			{
				RectTransform component = m_InputField.gameObject.GetComponent<RectTransform>();
				Canvas componentInParent = component.GetComponentInParent<Canvas>();
				Rect rect = RectTransformUtility.PixelAdjustRect(component, componentInParent);
				SteamUtils.ShowFloatingGamepadTextInput(EFloatingGamepadTextInputMode.k_EFloatingGamepadTextInputModeModeMultipleLines, (int)rect.x, (int)rect.y, (int)rect.size.x, (int)rect.size.y);
				break;
			}
			case SteamKeyboard.BigPictureKeyboard:
				SteamUtils.ShowGamepadTextInput(EGamepadTextInputMode.k_EGamepadTextInputModeNormal, EGamepadTextInputLineMode.k_EGamepadTextInputLineModeSingleLine, "Enter Player Name", (uint)m_InputField.characterLimit, m_InputField.text);
				break;
			}
		}
	}

	private void OnInputFieldDeselectHandler(string text)
	{
		if (RunningEnvironment.isSteamDeck)
		{
			GetComponentInParent<Starter3Controller>()?.OnButtonRenameClick();
			SteamUtils.DismissFloatingGamepadTextInput();
		}
	}
}
