using MessagePack;
using MessagePack.Resolvers;
using UnityEngine;

public static class RegisterTypes
{
	public static void Initialize()
	{
		Debug.Log("RegisterTypes Initialize...");
		StaticCompositeResolver instance = StaticCompositeResolver.Instance;
		StaticCompositeResolver.Instance.Register(GeneratedResolver.Instance, StandardResolverAllowPrivate.Instance);
		MessagePackSerializer.DefaultOptions = MessagePackSerializerOptions.Standard.WithResolver(instance);
		Debug.Log("RegisterTypes Initialize...Done");
	}
}
