using System;
using System.Collections;
using System.Globalization;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelUpController : MonoBehaviour
{
	private IronMan[] IronMen;

	private CharaData charadata;

	private bool unloaded;

	private AudioSource m_AudioSource;

	private void Start()
	{
		InitLevelUpUI();
		SharedData.Instance().levelUpController = this;
	}

	private void Update()
	{
		if (unloaded || (!Input.GetMouseButtonUp(0) && !InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame() && !InputSystemCustom.Instance().UI.PackageUse.WasReleasedThisFrame()))
		{
			return;
		}
		if (SharedData.Instance().m_LevelUpIndex < SharedData.Instance().levelupObjList.Count)
		{
			InitLevelUpUI();
			return;
		}
		if (SharedData.Instance().m_BattleController != null)
		{
			SharedData.Instance().m_BattleController.current.SetBattleObjState(BattleObjectState.LevelUpOver);
			SharedData.Instance().m_BattleController.isLoadLevelUp = false;
		}
		unloaded = true;
		SharedData.Instance().levelupObjList.Clear();
		if (SharedData.Instance().m_MapController != null)
		{
			SharedData.Instance().LoadedSceneStack.RemoveAt(SharedData.Instance().LoadedSceneStack.Count - 1);
		}
		SharedData.Instance().m_LevelUpIndex = 0;
		SceneManager.UnloadSceneAsync("LevelUp");
	}

	public void InitLevelUpUI()
	{
		if (SharedData.Instance().m_LevelUpIndex < SharedData.Instance().levelupObjList.Count)
		{
			SharedData.Instance().levelupObj = SharedData.Instance().levelupObjList[SharedData.Instance().m_LevelUpIndex++];
		}
		string text = "";
		text = ((SharedData.Instance().levelupObj != null) ? SharedData.Instance().levelupObj.m_Id : SharedData.Instance().playerid);
		charadata = SharedData.Instance().GetCharaData(text);
		base.transform.Find("Panel/Icon/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charadata);
		base.transform.Find("Panel/LevelUp/Text").GetComponent<Text>().text = charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_LevelUP") + " " + (charadata.m_Level + 1) + " " + CommonFunc.ShortLangSel("！", "!", "！");
		base.transform.Find("Panel/TachieL").gameObject.SetActive(value: false);
		if (charadata.m_BattleIcon != "")
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(charadata.m_BattleIcon);
			if (tachieFull != null)
			{
				base.transform.Find("Panel/TachieL/TachieL").GetComponent<Image>().sprite = tachieFull;
				base.transform.Find("Panel/TachieL").gameObject.SetActive(value: true);
			}
		}
		IronMen = base.transform.Find("Panel/Status").GetComponentsInChildren<IronMan>();
		IronMan[] ironMen = IronMen;
		foreach (IronMan ironMan in ironMen)
		{
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(ironMan.name);
			ironMan.GetComponent<Text>().text = row.NameScene_Trans;
		}
		Roll();
		charadata.m_Hp = charadata.GetBattleValueByName("HP");
		float num = charadata.GetBattleValueByName("Hurt") / 255f;
		if (num < 0f)
		{
			num = 0f;
		}
		else if (num > 1f)
		{
			num = 1f;
		}
		float mp = Mathf.Floor(Mathf.Floor(charadata.GetBattleValueByName("MP")) * (1f - num));
		charadata.m_Mp = mp;
		m_AudioSource = GetComponent<AudioSource>();
		m_AudioSource.Play();
		if (SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.AutoBattle)
		{
			StartCoroutine(ExitSceneDelay());
		}
	}

	private IEnumerator ExitSceneDelay()
	{
		unloaded = true;
		yield return new WaitForSeconds(1f);
		if (SharedData.Instance().m_LevelUpIndex < SharedData.Instance().levelupObjList.Count)
		{
			InitLevelUpUI();
			yield return null;
			yield break;
		}
		if (SharedData.Instance().m_BattleController != null)
		{
			if (SharedData.Instance().m_BattleController.current.m_State == BattleObjectState.LevelUp)
			{
				SharedData.Instance().m_BattleController.current.SetBattleObjState(BattleObjectState.LevelUpOver);
			}
			SharedData.Instance().m_BattleController.isLoadLevelUp = false;
		}
		SharedData.Instance().levelupObjList.Clear();
		SharedData.Instance().m_LevelUpIndex = 0;
		SceneManager.UnloadSceneAsync("LevelUp");
	}

	public void ChangePara(GameObject go)
	{
		string text = go.transform.parent.name;
		if (text != "STR" && text != "AGI" && text != "BON" && text != "WIL" && text != "LER")
		{
			return;
		}
		if (go.name == "plus")
		{
			IronMan component = base.transform.Find("Panel/Status/TALENT").GetComponent<IronMan>();
			IronMan component2 = base.transform.Find("Panel/Status/" + text).GetComponent<IronMan>();
			component.rndValue--;
			component.transform.Find("Text").GetComponent<Text>().text = component.rndValue.ToString() ?? "";
			component2.talentValue++;
			component2.transform.Find("Text").GetComponent<Text>().text = (component2.rndValue + component2.talentValue).ToString() ?? "";
			component2.transform.Find("reduce").gameObject.SetActive(value: true);
			if (component2.addValue > 0)
			{
				Text component3 = component2.transform.Find("Text").GetComponent<Text>();
				component3.text = component3.text + " <color=#EBAC34>(+" + component2.addValue + ")</color>";
			}
			else if (component2.addValue < 0)
			{
				Text component4 = component2.transform.Find("Text").GetComponent<Text>();
				component4.text = component4.text + " <color=#C83A2B>(" + component2.addValue + ")</color>";
			}
		}
		else if (go.name == "reduce")
		{
			IronMan component5 = base.transform.Find("Panel/Status/TALENT").GetComponent<IronMan>();
			IronMan component6 = base.transform.Find("Panel/Status/" + text).GetComponent<IronMan>();
			component5.rndValue++;
			component5.transform.Find("Text").GetComponent<Text>().text = component5.rndValue.ToString() ?? "";
			component6.talentValue--;
			component6.transform.Find("Text").GetComponent<Text>().text = (component6.rndValue + component6.talentValue).ToString() ?? "";
			if (component6.addValue > 0)
			{
				Text component7 = component6.transform.Find("Text").GetComponent<Text>();
				component7.text = component7.text + " <color=#E1A532>(+" + component6.addValue + ")</color>";
			}
			if (component6.talentValue <= 0)
			{
				component6.transform.Find("reduce").gameObject.SetActive(value: false);
			}
		}
	}

	private void Roll()
	{
		gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(charadata.m_Level.ToString() ?? "");
		if (row == null)
		{
			return;
		}
		IronMan[] ironMen;
		if (row.EXP != "0")
		{
			Type type = row.GetType();
			charadata.m_Talent++;
			ironMen = IronMen;
			foreach (IronMan ironMan in ironMen)
			{
				gang_a01Table.Row row2 = CommonResourcesData.a01.Find_Name(ironMan.name);
				FieldInfo field = type.GetField(ironMan.name);
				float num = 0f;
				if (field == null)
				{
					if ("TALENT".Equals(ironMan.name))
					{
						ironMan.transform.Find("Text").GetComponent<Text>().text = charadata.m_Talent.ToString() ?? "";
						ironMan.rndValue = charadata.m_Talent;
						continue;
					}
				}
				else
				{
					num = float.Parse(field.GetValue(row).ToString(), CultureInfo.InvariantCulture);
				}
				ironMan.transform.Find("Add").GetComponent<Text>().text = "";
				if (row2.Type.Equals("2"))
				{
					ironMan.transform.Find("Text").GetComponent<Text>().text = Mathf.RoundToInt(charadata.GetFieldValueByName(ironMan.name) * 100f) + "%";
				}
				else
				{
					ironMan.transform.Find("Text").GetComponent<Text>().text = charadata.GetFieldValueByName(ironMan.name).ToString() ?? "";
				}
				if (ironMan.name == "HP" || ironMan.name == "MP" || ironMan.name == "ATK" || ironMan.name == "DEF" || ironMan.name == "SP")
				{
					if (num > 0f)
					{
						ironMan.transform.Find("Add").GetComponent<Text>().text = "+" + num;
						charadata.Indexs_Name[ironMan.name].levelupValue += num;
					}
				}
				else if (ironMan.name == "STR" || ironMan.name == "AGI" || ironMan.name == "BON" || ironMan.name == "WIL" || ironMan.name == "LER")
				{
					if (SharedData.Instance().m_Bonus_Telent > 0)
					{
						ironMan.rndValue = Mathf.FloorToInt(charadata.GetFieldValueByName(ironMan.name));
						ironMan.addValue = Mathf.FloorToInt(num);
						if (num > 0f && UnityEngine.Random.value < num)
						{
							ironMan.transform.Find("Add").GetComponent<Text>().text = "+1";
							charadata.Indexs_Name[ironMan.name].levelupValue += 1f;
						}
					}
				}
				else if (SharedData.Instance().m_Bonus_Status > 0)
				{
					if (num > 0f)
					{
						if (UnityEngine.Random.value < num)
						{
							ironMan.transform.Find("Add").GetComponent<Text>().text = "+3";
							charadata.Indexs_Name[ironMan.name].levelupValue += 3f;
						}
						else
						{
							ironMan.transform.Find("Add").GetComponent<Text>().text = "+2";
							charadata.Indexs_Name[ironMan.name].levelupValue += 2f;
						}
					}
				}
				else if (num > 0f && UnityEngine.Random.value < num)
				{
					ironMan.transform.Find("Add").GetComponent<Text>().text = "+1";
					charadata.Indexs_Name[ironMan.name].levelupValue += 1f;
				}
			}
			charadata.m_Level++;
			int num2 = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
			if (charadata.m_Level >= num2)
			{
				return;
			}
			int num3 = int.Parse(CommonResourcesData.a05.Find_LV(charadata.m_Level.ToString()).EXP);
			if (charadata.m_Exp >= num3)
			{
				SharedData.Instance().m_LevelUpIndex--;
				if (charadata.m_Level < num2)
				{
					charadata.m_Exp -= num3;
				}
				else
				{
					charadata.m_Exp = 0;
				}
			}
			return;
		}
		Type type2 = row.GetType();
		ironMen = IronMen;
		foreach (IronMan ironMan2 in ironMen)
		{
			gang_a01Table.Row row3 = CommonResourcesData.a01.Find_Name(ironMan2.name);
			FieldInfo field2 = type2.GetField(ironMan2.name);
			if (field2 == null && "TALENT".Equals(ironMan2.name))
			{
				ironMan2.transform.Find("Text").GetComponent<Text>().text = charadata.m_Talent.ToString() ?? "";
				ironMan2.rndValue = charadata.m_Talent;
				continue;
			}
			float.Parse(field2.GetValue(row).ToString(), CultureInfo.InvariantCulture);
			if (row3.Type.Equals("2"))
			{
				ironMan2.transform.Find("Text").GetComponent<Text>().text = Mathf.RoundToInt(charadata.GetFieldValueByName(ironMan2.name) * 100f) + "%";
			}
			else
			{
				ironMan2.transform.Find("Text").GetComponent<Text>().text = charadata.GetFieldValueByName(ironMan2.name).ToString() ?? "";
			}
		}
	}
}
