using System;
using UnityEngine;

public class UICameraController : MonoBehaviour
{
	private void Start()
	{
		int num = 960;
		int num2 = 640;
		int num3 = ((!(Convert.ToSingle(Screen.height) / (float)Screen.width > Convert.ToSingle(num2) / (float)num)) ? num2 : Mathf.RoundToInt(Convert.ToSingle(num) / (float)Screen.width * (float)Screen.height));
		Camera component = GetComponent<Camera>();
		float num4 = Convert.ToSingle((float)num3 / 640f);
		component.fieldOfView *= num4;
	}
}
