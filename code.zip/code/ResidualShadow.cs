using System.Collections.Generic;
using UnityEngine;

public class ResidualShadow : MonoBehaviour
{
	private List<Vector3> offsets = new List<Vector3>();

	private List<Material> mats = new List<Material>();

	private int frame;

	public int frameInterval = 10;

	private bool isOpenResidualShadow;

	private void Start()
	{
	}

	public void SetSpecialShader(string _shader)
	{
		if (_shader == "Normal")
		{
			isOpenResidualShadow = false;
			{
				foreach (Material mat in mats)
				{
					mat.shader = Shader.Find("Spine/Skeleton");
				}
				return;
			}
		}
		if (!(_shader == "ResidualShadow"))
		{
			return;
		}
		isOpenResidualShadow = true;
		mats.Clear();
		offsets.Clear();
		offsets.Add(base.transform.position);
		offsets.Add(base.transform.position);
		offsets.Add(base.transform.position);
		offsets.Add(base.transform.position);
		MeshRenderer[] componentsInChildren = base.gameObject.GetComponentsInChildren<MeshRenderer>(includeInactive: true);
		foreach (MeshRenderer meshRenderer in componentsInChildren)
		{
			if (meshRenderer.gameObject.name.StartsWith("body_"))
			{
				mats.Add(meshRenderer.sharedMaterial);
			}
		}
		foreach (Material mat2 in mats)
		{
			mat2.shader = Shader.Find("Custom/ResidualShadow");
		}
	}

	private void Update()
	{
		if (!isOpenResidualShadow)
		{
			return;
		}
		frame++;
		if (frame <= frameInterval)
		{
			return;
		}
		foreach (Material mat in mats)
		{
			mat.SetVector("_Offset0", offsets[3] - base.transform.position);
			mat.SetVector("_Offset1", offsets[2] - base.transform.position);
			mat.SetVector("_Offset2", offsets[1] - base.transform.position);
			mat.SetVector("_Offset3", offsets[0] - base.transform.position);
		}
		offsets.Add(base.transform.position);
		offsets.RemoveAt(0);
		frame = 0;
	}

	private void OnDestroy()
	{
		foreach (Material mat in mats)
		{
			mat.shader = Shader.Find("Spine/Skeleton");
		}
	}
}
