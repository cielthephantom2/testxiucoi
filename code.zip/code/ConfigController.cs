using System.Linq;
using System.Reflection;
using InputIcons;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ConfigController : MonoBehaviour
{
	private Sprite MuteSprite;

	private Sprite UnMuteSprite;

	private Sprite NormalBoredSprite;

	private Sprite SelectedBoredSprite;

	private bool exiting;

	private Dropdown changeResolution;

	private Dropdown language;

	public GameObject mainCamera;

	private Slider masterSlider;

	private Slider musicSlider;

	private Slider seSlider;

	public AudioMixer audioMixer;

	private AudioSource backGroundMusicSource;

	private AudioSource soundEffectSource;

	private bool isInit;

	private void Start()
	{
		MuteSprite = Resources.Load("images/07-icon/mute-20231229-on", typeof(Sprite)) as Sprite;
		UnMuteSprite = Resources.Load("images/07-icon/mute-20231229-off", typeof(Sprite)) as Sprite;
		NormalBoredSprite = Resources.Load("images/01-border/boder-20231228-button-02", typeof(Sprite)) as Sprite;
		SelectedBoredSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		masterSlider = base.transform.Find("Panel/Config/Master/MasterSlider").GetComponent<Slider>();
		musicSlider = base.transform.Find("Panel/Config/BGM/BGMSlider").GetComponent<Slider>();
		seSlider = base.transform.Find("Panel/Config/SE/SESlider").GetComponent<Slider>();
		masterSlider.value = Mathf.Pow(10f, GameDataManager.Instance().configdata.masterVolume / 20f);
		musicSlider.value = Mathf.Pow(10f, GameDataManager.Instance().configdata.musicVolume / 20f);
		seSlider.value = Mathf.Pow(10f, GameDataManager.Instance().configdata.seVolume / 20f);
		masterSlider.onValueChanged.AddListener(SetMasterVolume);
		musicSlider.onValueChanged.AddListener(SetBackgroundMusicVolume);
		seSlider.onValueChanged.AddListener(SetSoundEffectVolume);
		backGroundMusicSource = base.transform.Find("BGM").GetComponent<AudioSource>();
		soundEffectSource = base.transform.Find("SE").GetComponent<AudioSource>();
		base.transform.Find("Panel/Config/Master/Mute/Icon").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMasterMute ? MuteSprite : UnMuteSprite);
		base.transform.Find("Panel/Config/BGM/Mute/Icon").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMusicMute ? MuteSprite : UnMuteSprite);
		base.transform.Find("Panel/Config/SE/Mute/Icon").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isSEMute ? MuteSprite : UnMuteSprite);
		base.transform.Find("Panel/Config/Master/Mute").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMasterMute ? SelectedBoredSprite : NormalBoredSprite);
		base.transform.Find("Panel/Config/BGM/Mute").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMusicMute ? SelectedBoredSprite : NormalBoredSprite);
		base.transform.Find("Panel/Config/SE/Mute").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isSEMute ? SelectedBoredSprite : NormalBoredSprite);
		base.transform.Find("Panel/Config/ScreenType/Mode" + GameDataManager.Instance().configdata.screenmode).GetComponent<Image>().sprite = SelectedBoredSprite;
		base.transform.Find("Panel/Config/GameSpeed/Speed|" + GameDataManager.Instance().configdata.gameSpeed).GetComponent<Image>().sprite = SelectedBoredSprite;
		base.transform.Find("Panel/Config/GameIconType/GameIconType|" + GameDataManager.Instance().configdata.gameIconType).GetComponent<Image>().sprite = SelectedBoredSprite;
		language = base.transform.Find("Panel/Config/Language/Language").GetComponent<Dropdown>();
		language.interactable = SceneManager.sceneCount == 1;
		EventSystem.current.SetSelectedGameObject(masterSlider.gameObject);
		switch (GameDataManager.Instance().configdata.language)
		{
		case "ChineseSimplified":
			language.value = 0;
			break;
		case "ChineseTraditional":
			language.value = 1;
			break;
		case "English":
			language.value = 2;
			break;
		default:
			language.value = 2;
			break;
		}
		language.onValueChanged.AddListener(ChangeLanguage);
		changeResolution = base.transform.Find("Panel/Config/ScreenResolution/ChangeResolution").GetComponent<Dropdown>();
		changeResolution.interactable = GameDataManager.Instance().configdata.screenmode != 0;
		changeResolution.value = GameDataManager.Instance().configdata.resolution;
		changeResolution.onValueChanged.AddListener(ChangeResolution);
		if (RunningEnvironment.isSteamDeck)
		{
			base.transform.Find("Panel/Config/ScreenType").gameObject.SetActive(value: false);
			base.transform.Find("Panel/Config/ScreenResolution").gameObject.SetActive(value: false);
			base.transform.Find("Panel/Config/GameIconType").gameObject.SetActive(value: false);
		}
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		isInit = true;
		SetMasterVolume(masterSlider.value);
		SetBackgroundMusicVolume(musicSlider.value);
		SetSoundEffectVolume(seSlider.value);
		if (SharedData.Instance().m_MapController != null)
		{
			if (Camera.main != null && Camera.main.GetComponent<AudioListener>() != null)
			{
				Camera.main.GetComponent<AudioListener>().enabled = false;
			}
			if (Camera.main != null && Camera.main.GetComponent<AudioSource>() != null)
			{
				Camera.main.GetComponent<AudioSource>().enabled = false;
			}
		}
	}

	private void Update()
	{
		if (InputDeviceDetector.isMouse1Up)
		{
			ExitScene();
		}
		if (!IsDropdownExpanded(changeResolution) && !IsDropdownExpanded(language) && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExitScene();
		}
	}

	private bool IsDropdownExpanded(Dropdown dropdown)
	{
		return typeof(Dropdown).GetField("m_Dropdown", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(dropdown) as GameObject != null;
	}

	public void ReturnTitle()
	{
		ExitScene();
	}

	private void ExitScene()
	{
		if (exiting)
		{
			return;
		}
		exiting = true;
		GameDataManager.Instance().SaveConfig();
		if (SceneManager.GetActiveScene().name == "Config")
		{
			SceneManager.LoadScene("Title");
			return;
		}
		if (Camera.main != null && Camera.main.GetComponent<AudioListener>() != null)
		{
			Camera.main.GetComponent<AudioListener>().enabled = true;
		}
		if (Camera.main != null && Camera.main.GetComponent<AudioSource>() != null)
		{
			Camera.main.GetComponent<AudioSource>().enabled = true;
		}
		GameObject obj = SceneManager.GetActiveScene().GetRootGameObjects().FirstOrDefault((GameObject x) => x.name == "Canvas");
		_ = obj.transform.Find("WalkMenu/MobileTerminalUI").gameObject;
		_ = obj.transform.Find("WalkMenu/JoyStick").gameObject;
		_ = obj.transform.Find("WalkMenu/JoyTouch").gameObject;
		obj.transform.Find("WalkMenu").GetComponent<Menu3Controller>().Open();
		SharedData.Instance().LoadedSceneStack.Clear();
		SceneManager.UnloadSceneAsync("Config");
		InputSystemCustom.Instance().Player.Enable();
	}

	private void ChangeScreen(int _index)
	{
		switch (_index)
		{
		case 0:
			GameDataManager.Instance().configdata.screenmode = 0;
			Screen.SetResolution(Screen.resolutions[Screen.resolutions.Length - 1].width, Screen.resolutions[Screen.resolutions.Length - 1].height, FullScreenMode.FullScreenWindow);
			changeResolution.interactable = false;
			break;
		case 1:
			GameDataManager.Instance().configdata.screenmode = 1;
			switch (GameDataManager.Instance().configdata.resolution)
			{
			case 0:
				Screen.SetResolution(1024, 576, FullScreenMode.Windowed);
				break;
			case 1:
				Screen.SetResolution(1280, 720, FullScreenMode.Windowed);
				break;
			case 2:
				Screen.SetResolution(1366, 768, FullScreenMode.Windowed);
				break;
			case 3:
				Screen.SetResolution(1600, 900, FullScreenMode.Windowed);
				break;
			case 4:
				Screen.SetResolution(1920, 1080, FullScreenMode.Windowed);
				break;
			case 5:
				Screen.SetResolution(2560, 1440, FullScreenMode.Windowed);
				break;
			}
			changeResolution.interactable = true;
			break;
		case 2:
			GameDataManager.Instance().configdata.screenmode = 2;
			switch (GameDataManager.Instance().configdata.resolution)
			{
			case 0:
				Screen.SetResolution(1024, 576, FullScreenMode.FullScreenWindow);
				break;
			case 1:
				Screen.SetResolution(1280, 720, FullScreenMode.FullScreenWindow);
				break;
			case 2:
				Screen.SetResolution(1366, 768, FullScreenMode.FullScreenWindow);
				break;
			case 3:
				Screen.SetResolution(1600, 900, FullScreenMode.FullScreenWindow);
				break;
			case 4:
				Screen.SetResolution(1920, 1080, FullScreenMode.FullScreenWindow);
				break;
			case 5:
				Screen.SetResolution(2560, 1440, FullScreenMode.FullScreenWindow);
				break;
			}
			changeResolution.interactable = true;
			break;
		}
		base.transform.Find("Panel/Config/ScreenType/Mode0").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/ScreenType/Mode1").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/ScreenType/Mode2").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/ScreenType/Mode" + GameDataManager.Instance().configdata.screenmode).GetComponent<Image>().sprite = SelectedBoredSprite;
	}

	private void ChangeResolution(int _index)
	{
		switch (GameDataManager.Instance().configdata.screenmode)
		{
		case 1:
			switch (_index)
			{
			case 0:
				GameDataManager.Instance().configdata.resolution = 0;
				Screen.SetResolution(1024, 576, FullScreenMode.Windowed);
				break;
			case 1:
				GameDataManager.Instance().configdata.resolution = 1;
				Screen.SetResolution(1280, 720, FullScreenMode.Windowed);
				break;
			case 2:
				GameDataManager.Instance().configdata.resolution = 2;
				Screen.SetResolution(1366, 768, FullScreenMode.Windowed);
				break;
			case 3:
				GameDataManager.Instance().configdata.resolution = 3;
				Screen.SetResolution(1600, 900, FullScreenMode.Windowed);
				break;
			case 4:
				GameDataManager.Instance().configdata.resolution = 4;
				Screen.SetResolution(1920, 1080, FullScreenMode.Windowed);
				break;
			case 5:
				GameDataManager.Instance().configdata.resolution = 5;
				Screen.SetResolution(2560, 1440, FullScreenMode.Windowed);
				break;
			}
			break;
		case 2:
			switch (_index)
			{
			case 0:
				GameDataManager.Instance().configdata.resolution = 0;
				Screen.SetResolution(1024, 576, FullScreenMode.FullScreenWindow);
				break;
			case 1:
				GameDataManager.Instance().configdata.resolution = 1;
				Screen.SetResolution(1280, 720, FullScreenMode.FullScreenWindow);
				break;
			case 2:
				GameDataManager.Instance().configdata.resolution = 2;
				Screen.SetResolution(1366, 768, FullScreenMode.FullScreenWindow);
				break;
			case 3:
				GameDataManager.Instance().configdata.resolution = 3;
				Screen.SetResolution(1600, 900, FullScreenMode.FullScreenWindow);
				break;
			case 4:
				GameDataManager.Instance().configdata.resolution = 4;
				Screen.SetResolution(1920, 1080, FullScreenMode.FullScreenWindow);
				break;
			case 5:
				GameDataManager.Instance().configdata.resolution = 5;
				Screen.SetResolution(2560, 1440, FullScreenMode.FullScreenWindow);
				break;
			}
			break;
		}
	}

	private void ChangeLanguage(int _index)
	{
		string text = GameDataManager.Instance().configdata.language;
		switch (_index)
		{
		case 0:
			GameDataManager.Instance().configdata.language = "ChineseSimplified";
			break;
		case 1:
			GameDataManager.Instance().configdata.language = "ChineseTraditional";
			break;
		case 2:
			GameDataManager.Instance().configdata.language = "English";
			break;
		}
		CommonResourcesData.UpdateResourcesByLanguage();
		if (!text.Equals(GameDataManager.Instance().configdata.language))
		{
			Object.DestroyImmediate(SharedData.Instance().m_DataRecordManager.gameObject);
		}
		if (SceneManager.GetActiveScene().name == "Config")
		{
			SceneManager.LoadScene("Config");
			return;
		}
		SceneManager.LoadScene("Config", LoadSceneMode.Additive);
		SceneManager.UnloadSceneAsync("Config");
	}

	private void ChangeSpeed(int _speed)
	{
		switch (_speed)
		{
		case 1:
			GameDataManager.Instance().configdata.gameSpeed = 1;
			Time.timeScale = 1f;
			break;
		case 2:
			GameDataManager.Instance().configdata.gameSpeed = 2;
			Time.timeScale = 1.5f;
			break;
		default:
			Time.timeScale = 1f;
			break;
		}
		base.transform.Find("Panel/Config/GameSpeed/Speed|1").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameSpeed/Speed|2").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameSpeed/Speed|" + GameDataManager.Instance().configdata.gameSpeed).GetComponent<Image>().sprite = SelectedBoredSprite;
	}

	private void ChangeGameIconType(string Type)
	{
		switch (Type)
		{
		case "Auto":
			GameDataManager.Instance().configdata.gameIconType = GameIconType.Auto;
			break;
		case "KeyBoard":
			GameDataManager.Instance().configdata.gameIconType = GameIconType.KeyBoard;
			InputIconsManagerSO.SetDeviceAndRefreshDisplayedIcons(InputIconSetConfiguratorSO.InputIconsDevice.Keyboard);
			break;
		case "Xbox":
			GameDataManager.Instance().configdata.gameIconType = GameIconType.Xbox;
			InputIconsManagerSO.SetDeviceAndRefreshDisplayedIcons(InputIconSetConfiguratorSO.InputIconsDevice.XBox);
			break;
		case "PS":
			GameDataManager.Instance().configdata.gameIconType = GameIconType.PS;
			InputIconsManagerSO.SetDeviceAndRefreshDisplayedIcons(InputIconSetConfiguratorSO.InputIconsDevice.PS5);
			break;
		case "Switch":
			GameDataManager.Instance().configdata.gameIconType = GameIconType.Switch;
			InputIconsManagerSO.SetDeviceAndRefreshDisplayedIcons(InputIconSetConfiguratorSO.InputIconsDevice.Switch);
			break;
		default:
			GameDataManager.Instance().configdata.gameIconType = GameIconType.Auto;
			InputIconsManagerSO.SetDeviceAndRefreshDisplayedIcons(InputIconSetConfiguratorSO.InputIconsDevice.Fallback);
			break;
		}
		InputIconSetConfiguratorSO.Instance.gameIconType = GameDataManager.Instance().configdata.gameIconType.ToString();
		base.transform.Find("Panel/Config/GameIconType/GameIconType|Auto").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameIconType/GameIconType|KeyBoard").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameIconType/GameIconType|Xbox").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameIconType/GameIconType|PS").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameIconType/GameIconType|Switch").GetComponent<Image>().sprite = NormalBoredSprite;
		base.transform.Find("Panel/Config/GameIconType/GameIconType|" + GameDataManager.Instance().configdata.gameIconType).GetComponent<Image>().sprite = SelectedBoredSprite;
	}

	private void OnButtonClick(GameObject btn)
	{
		if (btn == null || !btn.activeInHierarchy || btn.GetComponent<Button>() == null || !btn.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		if (btn.name == "Return")
		{
			ExitScene();
		}
		else if (btn.name.StartsWith("Mode"))
		{
			ChangeScreen(int.Parse(btn.name[btn.name.Length - 1].ToString()));
		}
		else if (btn.name.StartsWith("Speed"))
		{
			ChangeSpeed(int.Parse(btn.name.Split('|')[1]));
		}
		else if (btn.name.StartsWith("GameIconType"))
		{
			ChangeGameIconType(btn.name.Split('|')[1]);
		}
		else if (btn.name == "Mute")
		{
			switch (btn.transform.parent.name)
			{
			case "Master":
				GameDataManager.Instance().configdata.isMasterMute = !GameDataManager.Instance().configdata.isMasterMute;
				audioMixer.SetFloat("MasterVolume", (!GameDataManager.Instance().configdata.isMasterMute) ? (Mathf.Log10(masterSlider.value) * 20f) : (Mathf.Log10(0.001f) * 20f));
				break;
			case "BGM":
				GameDataManager.Instance().configdata.isMusicMute = !GameDataManager.Instance().configdata.isMusicMute;
				audioMixer.SetFloat("MusicVolume", (!GameDataManager.Instance().configdata.isMusicMute) ? (Mathf.Log10(musicSlider.value) * 20f) : (Mathf.Log10(0.001f) * 20f));
				break;
			case "SE":
				GameDataManager.Instance().configdata.isSEMute = !GameDataManager.Instance().configdata.isSEMute;
				audioMixer.SetFloat("SoundEffectVolume", (!GameDataManager.Instance().configdata.isSEMute) ? (Mathf.Log10(seSlider.value) * 20f) : (Mathf.Log10(0.001f) * 20f));
				break;
			}
			base.transform.Find("Panel/Config/Master/Mute/Icon").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMasterMute ? MuteSprite : UnMuteSprite);
			base.transform.Find("Panel/Config/BGM/Mute/Icon").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMusicMute ? MuteSprite : UnMuteSprite);
			base.transform.Find("Panel/Config/SE/Mute/Icon").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isSEMute ? MuteSprite : UnMuteSprite);
			base.transform.Find("Panel/Config/Master/Mute").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMasterMute ? SelectedBoredSprite : NormalBoredSprite);
			base.transform.Find("Panel/Config/BGM/Mute").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isMusicMute ? SelectedBoredSprite : NormalBoredSprite);
			base.transform.Find("Panel/Config/SE/Mute").GetComponent<Image>().sprite = (GameDataManager.Instance().configdata.isSEMute ? SelectedBoredSprite : NormalBoredSprite);
		}
	}

	public void SetMasterVolume(float volume)
	{
		if (isInit)
		{
			float num = Mathf.Log10(masterSlider.value) * 20f;
			audioMixer.SetFloat("MasterVolume", (!GameDataManager.Instance().configdata.isMasterMute) ? num : (Mathf.Log10(0.001f) * 20f));
			GameDataManager.Instance().configdata.masterVolume = num;
			masterSlider.transform.Find("Value").GetComponent<Text>().text = (int)(masterSlider.value * 100f) + "%";
		}
	}

	public void SetBackgroundMusicVolume(float volume)
	{
		if (isInit)
		{
			float num = Mathf.Log10(musicSlider.value) * 20f;
			audioMixer.SetFloat("MusicVolume", (!GameDataManager.Instance().configdata.isMusicMute) ? num : (Mathf.Log10(0.001f) * 20f));
			GameDataManager.Instance().configdata.musicVolume = num;
			musicSlider.transform.Find("Value").GetComponent<Text>().text = (int)(musicSlider.value * 100f) + "%";
		}
	}

	public void SetSoundEffectVolume(float volume)
	{
		if (isInit)
		{
			float num = Mathf.Log10(seSlider.value) * 20f;
			audioMixer.SetFloat("SoundEffectVolume", (!GameDataManager.Instance().configdata.isSEMute) ? num : (Mathf.Log10(0.001f) * 20f));
			GameDataManager.Instance().configdata.seVolume = num;
			seSlider.transform.Find("Value").GetComponent<Text>().text = (int)(seSlider.value * 100f) + "%";
			if (!soundEffectSource.isPlaying)
			{
				soundEffectSource.Play();
			}
		}
	}
}
