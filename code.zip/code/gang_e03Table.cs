using System.Collections.Generic;
using UnityEngine;

public class gang_e03Table
{
	public class Row
	{
		public string id;

		public string prescene;

		public string pos;

		public string horimono;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				id = list[i][num++],
				prescene = list[i][num++],
				pos = list[i][num++],
				horimono = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		return rowList.Find((Row x) => x.id == find);
	}

	public List<Row> FindAll_id(string find)
	{
		return rowList.FindAll((Row x) => x.id == find);
	}

	public Row Find_prescene(string find)
	{
		return rowList.Find((Row x) => x.prescene == find);
	}

	public List<Row> FindAll_prescene(string find)
	{
		return rowList.FindAll((Row x) => x.prescene == find);
	}

	public Row Find_pos(string find)
	{
		return rowList.Find((Row x) => x.pos == find);
	}

	public List<Row> FindAll_pos(string find)
	{
		return rowList.FindAll((Row x) => x.pos == find);
	}

	public Row Find_horimono(string find)
	{
		return rowList.Find((Row x) => x.horimono == find);
	}

	public List<Row> FindAll_horimono(string find)
	{
		return rowList.FindAll((Row x) => x.horimono == find);
	}
}
