using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class StatusMainController : MonoBehaviour
{
	private Transform m_character;

	private AudioSource m_AudioSource;

	private GameObject RetBtn;

	private bool m_Asyncing;

	private Sprite button_normal;

	private Sprite button_selected;

	private Sprite buttonr_normal;

	private Sprite buttonr_selected;

	public List<GameObject> teamslots = new List<GameObject>();

	private bool isExiting;

	private HoverController[] hovers;

	private List<Button> statusSubBtns = new List<Button>();

	private int currentSubIndex = 1;

	private bool isInit;

	private void Start()
	{
		m_character = base.transform.Find("Panel/Character");
		m_AudioSource = base.gameObject.GetComponent<AudioSource>();
		RetBtn = (RetBtn = base.transform.Find("Panel/Menu/Return").gameObject);
		button_normal = Resources.Load("images/01-border/boder-duiwu-20220223-2", typeof(Sprite)) as Sprite;
		button_selected = Resources.Load("images/01-border/boder-duiwu-20220223-1", typeof(Sprite)) as Sprite;
		buttonr_normal = Resources.Load("images/01-border/boder-20231228-menu-01", typeof(Sprite)) as Sprite;
		buttonr_selected = Resources.Load("images/01-border/boder-20231228-menu-02", typeof(Sprite)) as Sprite;
		for (int i = 0; i <= 5; i++)
		{
			teamslots.Add(base.transform.Find("Panel/Team/Slot|" + i).gameObject);
		}
		hovers = m_character.Find("Buff").GetComponentsInChildren<HoverController>(includeInactive: true);
		Button[] componentsInChildren = base.transform.Find("Panel/Team").GetComponentsInChildren<Button>(includeInactive: true);
		for (int j = 0; j < componentsInChildren.Length; j++)
		{
			EventTriggerListener.Get(componentsInChildren[j].gameObject).onClick = OnButtonClick;
		}
		componentsInChildren = base.transform.Find("Panel/Menu").GetComponentsInChildren<Button>(includeInactive: true);
		for (int j = 0; j < componentsInChildren.Length; j++)
		{
			EventTriggerListener.Get(componentsInChildren[j].gameObject).onClick = OnButtonClick;
		}
		statusSubBtns = base.transform.Find("Panel/Menu").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		SharedData.Instance().m_StatusMain = this;
		RefreshUI();
		isInit = true;
	}

	private void OnEnable()
	{
		if (isInit)
		{
			InputDeviceDetector.instance.ClearJoyStack();
			SharedData.Instance().LoadSceneStackAdd("StatusMain");
			RefreshUI();
		}
	}

	private void Update()
	{
		if (CommonFunc.IsHoverOpen() || (bool)SharedData.Instance().levelUpController || (SharedData.Instance().LoadedSceneStack.Count > 0 && SharedData.Instance().LoadedSceneStack[SharedData.Instance().LoadedSceneStack.Count - 1].Equals("LevelUpSkill")) || SharedData.Instance().m_OpenDetail.Length > 0)
		{
			return;
		}
		if (InputDeviceDetector.isMouse1Up || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			if ((!SharedData.Instance().m_PackageController.isOpen || SharedData.Instance().m_PackageController.packagerFunction == PackagerFunction.PlayerPackage) && !SharedData.Instance().m_TraitPackageController.isOpen && (!SharedData.Instance().m_PackageController.isOpen || SharedData.Instance().m_PackageController.packagerFunction != PackagerFunction.PlayerPackage || !SharedData.Instance().m_PackageController.SelectPanel.activeInHierarchy))
			{
				OnButtonClickReturn();
			}
		}
		else if (InputSystemCustom.Instance().UI.SelectMenuNext.WasReleasedThisFrame())
		{
			int num = ((currentSubIndex - 1 + 1) % 7 + 7) % 7 + 1;
			ExecuteEvents.Execute(base.transform.Find("Panel/Menu/Sub|StatusSub" + num).gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Menu/Sub|StatusSub" + num).gameObject);
		}
		else if (InputSystemCustom.Instance().UI.SelectMenuPrev.WasReleasedThisFrame())
		{
			int num2 = ((currentSubIndex - 1 - 1) % 7 + 7) % 7 + 1;
			ExecuteEvents.Execute(base.transform.Find("Panel/Menu/Sub|StatusSub" + num2).gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Menu/Sub|StatusSub" + num2).gameObject);
		}
		else if (InputSystemCustom.Instance().UI.SelectCharacterNext.WasReleasedThisFrame())
		{
			GameObject item = teamslots.Find((GameObject x) => x.name == "Slot|" + SharedData.Instance().CurrentChara);
			int num3 = teamslots.IndexOf(item) + 1;
			if (num3 >= teamslots.Count || !teamslots[num3].gameObject.activeInHierarchy)
			{
				num3 = 0;
			}
			ExecuteEvents.Execute(base.transform.Find("Panel/Team/" + teamslots[num3].gameObject.name).gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Team/" + teamslots[num3].gameObject.name).gameObject);
		}
		else
		{
			if (!InputSystemCustom.Instance().UI.SelectCharacterPrev.WasReleasedThisFrame())
			{
				return;
			}
			GameObject item2 = teamslots.Find((GameObject x) => x.name == "Slot|" + SharedData.Instance().CurrentChara);
			int num4 = teamslots.IndexOf(item2) - 1;
			if (num4 < 0)
			{
				GameObject item3 = teamslots.FindLast((GameObject x) => x.gameObject.activeInHierarchy);
				num4 = teamslots.IndexOf(item3);
			}
			ExecuteEvents.Execute(base.transform.Find("Panel/Team/" + teamslots[num4].gameObject.name).gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Team/" + teamslots[num4].gameObject.name).gameObject);
		}
	}

	public void RefreshUI()
	{
		foreach (Button statusSubBtn in statusSubBtns)
		{
			statusSubBtn.GetComponent<Image>().sprite = buttonr_normal;
		}
		statusSubBtns[0].GetComponent<Image>().sprite = buttonr_selected;
		SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
		if (SharedData.Instance().CurrentChara == "")
		{
			return;
		}
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		SharedData.Instance().m_OpenDetail = "";
		m_AudioSource.clip = CommonResourcesData.SE_JiangHu;
		m_AudioSource.Play();
		HoverController[] array = hovers;
		foreach (HoverController hoverController in array)
		{
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(hoverController.gameObject.name);
			hoverController.transform.Find("Hover/Text").GetComponent<Text>().text = row.Note_Trans;
		}
		teamslots[0].gameObject.name = "Slot|" + SharedData.Instance().playerid;
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		if (charaData == null)
		{
			return;
		}
		teamslots[0].transform.Find("Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charaData);
		teamslots[0].transform.Find("HP/Value").GetComponent<Text>().text = charaData.m_Hp + "/" + charaData.GetFieldValueByName("HP");
		teamslots[0].transform.Find("HP/Slider").GetComponent<Slider>().value = charaData.m_Hp / charaData.GetFieldValueByName("HP");
		float num = charaData.GetBattleValueByName("Hurt") / 255f;
		if (num < 0f)
		{
			num = 0f;
		}
		else if (num > 1f)
		{
			num = 1f;
		}
		float num2 = Mathf.Floor(charaData.GetFieldValueByName("MP"));
		float num3 = Mathf.Floor(num2 * (1f - num));
		if (charaData.m_Mp > num3)
		{
			charaData.m_Mp = num3;
		}
		teamslots[0].transform.Find("MP/Value").GetComponent<Text>().text = charaData.m_Mp + "/" + num2;
		teamslots[0].transform.Find("MP/MpBG/CurMp").GetComponent<Image>().fillAmount = charaData.m_Mp / num2;
		teamslots[0].transform.Find("MP/MpBG/GrayMp").GetComponent<Image>().fillAmount = (num2 - num3) / num2;
		if (SharedData.Instance().OpenPackageFor.Equals("WalkMain"))
		{
			SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
		}
		if (SharedData.Instance().CurrentChara.Equals(SharedData.Instance().playerid))
		{
			teamslots[0].transform.Find("Marker").gameObject.SetActive(value: true);
			teamslots[0].GetComponent<Image>().sprite = button_selected;
		}
		int count = SharedData.Instance().FollowList.Count;
		if (count > SharedData.Instance().FollowMaxCount)
		{
			Debug.LogWarningFormat("Fix FollowList.Length issue: followcount = {0}, FollowMaxCount = {1}", count, SharedData.Instance().FollowMaxCount);
			for (int num4 = count - 1; num4 >= SharedData.Instance().FollowMaxCount; num4--)
			{
				SharedData.Instance().FollowList.RemoveAt(num4);
			}
		}
		for (int j = 1; j < teamslots.Count; j++)
		{
			teamslots[j].gameObject.SetActive(value: false);
			teamslots[j].transform.Find("Marker").gameObject.SetActive(value: false);
			teamslots[j].GetComponent<Image>().sprite = button_normal;
		}
		int num5 = 1;
		foreach (string follow in SharedData.Instance().FollowList)
		{
			charaData = SharedData.Instance().GetCharaData(follow);
			teamslots[num5].gameObject.SetActive(value: true);
			teamslots[num5].gameObject.name = "Slot|" + follow;
			teamslots[num5].transform.Find("Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charaData);
			teamslots[num5].transform.Find("HP/Value").GetComponent<Text>().text = charaData.m_Hp + "/" + charaData.GetFieldValueByName("HP");
			teamslots[num5].transform.Find("HP/Slider").GetComponent<Slider>().value = charaData.m_Hp / charaData.GetFieldValueByName("HP");
			float num6 = charaData.GetBattleValueByName("Hurt") / 255f;
			if (num6 < 0f)
			{
				num6 = 0f;
			}
			else if (num6 > 1f)
			{
				num6 = 1f;
			}
			float num7 = Mathf.Floor(charaData.GetFieldValueByName("MP"));
			float num8 = Mathf.Floor(num7 * (1f - num6));
			if (charaData.m_Mp > num8)
			{
				charaData.m_Mp = num8;
			}
			teamslots[num5].transform.Find("MP/Value").GetComponent<Text>().text = charaData.m_Mp + "/" + num7;
			teamslots[num5].transform.Find("MP/MpBG/CurMp").GetComponent<Image>().fillAmount = charaData.m_Mp / num7;
			teamslots[num5].transform.Find("MP/MpBG/GrayMp").GetComponent<Image>().fillAmount = (num7 - num8) / num7;
			if (follow.Equals(SharedData.Instance().CurrentChara))
			{
				teamslots[num5].transform.Find("Marker").gameObject.SetActive(value: true);
				teamslots[num5].GetComponent<Image>().sprite = button_selected;
			}
			num5++;
		}
		UpdateCharaInfo();
		if ("StatusSub7".Equals(SharedData.Instance().CurrentStatusSubName?.name) || "StatusSub8".Equals(SharedData.Instance().CurrentStatusSubName?.name))
		{
			m_character.gameObject.SetActive(value: false);
		}
		else
		{
			m_character.gameObject.SetActive(value: true);
		}
		OnButtonClick(teamslots[0].gameObject);
		if (SharedData.Instance().CurrentStatusSubName != null)
		{
			if (SharedData.Instance().CurrentStatusSubName == SharedData.Instance().m_PackageController)
			{
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.PlayerPackage);
			}
			else
			{
				SharedData.Instance().CurrentStatusSubName.gameObject.SetActive(value: true);
			}
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Menu/Sub|StatusSub" + currentSubIndex).gameObject);
		}
	}

	public void UpdateCurrentSlot()
	{
		foreach (GameObject teamslot in teamslots)
		{
			if (("Slot|" + SharedData.Instance().CurrentChara).Equals(teamslot.gameObject.name))
			{
				CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
				teamslot.transform.Find("HP/Value").GetComponent<Text>().text = currentCharaData.m_Hp + "/" + currentCharaData.GetFieldValueByName("HP");
				teamslot.transform.Find("HP/Slider").GetComponent<Slider>().value = currentCharaData.m_Hp / currentCharaData.GetFieldValueByName("HP");
				float num = currentCharaData.GetBattleValueByName("Hurt") / 255f;
				if (num < 0f)
				{
					num = 0f;
				}
				else if (num > 1f)
				{
					num = 1f;
				}
				float num2 = Mathf.Floor(currentCharaData.GetFieldValueByName("MP"));
				float num3 = Mathf.Floor(num2 * (1f - num));
				if (currentCharaData.m_Mp > num3)
				{
					currentCharaData.m_Mp = num3;
				}
				teamslot.transform.Find("MP/Value").GetComponent<Text>().text = currentCharaData.m_Mp + "/" + num2;
				teamslot.transform.Find("MP/MpBG/CurMp").GetComponent<Image>().fillAmount = currentCharaData.m_Mp / num2;
				teamslot.transform.Find("MP/MpBG/GrayMp").GetComponent<Image>().fillAmount = (num2 - num3) / num2;
				break;
			}
		}
	}

	public void UpdateCharaInfo()
	{
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		m_character.Find("Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(currentCharaData);
		m_character.Find("Tachie").gameObject.SetActive(value: false);
		if (currentCharaData.m_BattleIcon != "")
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(currentCharaData.m_BattleIcon);
			if (tachieFull != null)
			{
				m_character.Find("Tachie").gameObject.SetActive(value: true);
				m_character.Find("Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
			}
		}
		SetBuffText("Poison");
		SetBuffText("Hurt");
		SetBuffText("Bleed");
		SetBuffText("Drunk");
		SetBuffText("Seal");
		SetBuffText("Mad");
		SetBuffText("Burn");
		SetBuffText("Fend");
	}

	private void SetBuffText(string _buffname)
	{
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		m_character.Find("Buff/" + _buffname + "/Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[_buffname].NameUI_Trans;
		float battleValueByName = currentCharaData.GetBattleValueByName(_buffname);
		if (battleValueByName < 0f)
		{
			m_character.Find("Buff/" + _buffname + "/Value").GetComponent<Text>().text = "<color=green>" + Mathf.Abs(battleValueByName) + "</color>";
		}
		else if (battleValueByName > 0f)
		{
			m_character.Find("Buff/" + _buffname + "/Value").GetComponent<Text>().text = "<color=red>" + battleValueByName + "</color>";
		}
		else
		{
			m_character.Find("Buff/" + _buffname + "/Value").GetComponent<Text>().text = battleValueByName.ToString() ?? "";
		}
	}

	public void OnButtonClickReturn()
	{
		OnButtonClick(RetBtn);
	}

	public void OnButtonClick(GameObject go)
	{
		if (SharedData.Instance().m_OpenDetail.Length > 0 || go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || m_Asyncing)
		{
			return;
		}
		MonoBehaviour.print("[StatusMainController] Click button: " + go.name);
		string[] array = go.name.Split('|');
		if (array[0] == "Return")
		{
			SharedData.Instance().m_PackageController.ClosePackage();
			ExitScene();
		}
		else if (array[0] == "Slot")
		{
			if (SharedData.Instance().CurrentChara.Equals(array[1]))
			{
				return;
			}
			foreach (GameObject teamslot in teamslots)
			{
				teamslot.transform.Find("Marker").gameObject.SetActive(value: false);
				teamslot.GetComponent<Image>().sprite = button_normal;
			}
			go.transform.Find("Marker").gameObject.SetActive(value: true);
			go.GetComponent<Image>().sprite = button_selected;
			SharedData.Instance().CurrentChara = array[1];
			UpdateCharaInfo();
			if (SharedData.Instance().CurrentStatusSubName == SharedData.Instance().m_PackageController.gameObject)
			{
				SharedData.Instance().m_PackageController.OpenPackage(refresh: false, PackagerFunction.PlayerPackage);
			}
			else
			{
				SharedData.Instance().CurrentStatusSubName.SetActive(value: false);
				SharedData.Instance().CurrentStatusSubName.SetActive(value: true);
			}
			if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_PackageController.packagerFunction != PackagerFunction.PlayerPackage)
			{
				SharedData.Instance().m_PackageController.ClosePackage();
			}
		}
		else
		{
			if (!(array[0] == "Sub"))
			{
				return;
			}
			OpenStatusSub(array[1]);
			foreach (Button statusSubBtn in statusSubBtns)
			{
				statusSubBtn.GetComponent<Image>().sprite = buttonr_normal;
			}
			statusSubBtns[int.Parse(array[1][array[1].Length - 1].ToString()) - 1].GetComponent<Image>().sprite = buttonr_selected;
		}
	}

	private void OpenStatusSub(string _name)
	{
		InputDeviceDetector.instance.ClearJoyStack();
		if (SharedData.Instance().CurrentStatusSubName.Equals(_name[_name.Length - 1]))
		{
			return;
		}
		if (SharedData.Instance().CurrentStatusSubName != SharedData.Instance().m_PackageController.gameObject)
		{
			SharedData.Instance().CurrentStatusSubName.SetActive(value: false);
		}
		switch (_name[_name.Length - 1].ToString())
		{
		case "1":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub1.gameObject;
			currentSubIndex = 1;
			break;
		case "2":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub2.gameObject;
			currentSubIndex = 2;
			break;
		case "3":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub3.gameObject;
			currentSubIndex = 3;
			break;
		case "4":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub4.gameObject;
			currentSubIndex = 4;
			break;
		case "5":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub5.gameObject;
			currentSubIndex = 5;
			break;
		case "6":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub6.gameObject;
			currentSubIndex = 6;
			break;
		case "7":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_PackageController.gameObject;
			currentSubIndex = 7;
			break;
		}
		if (SharedData.Instance().CurrentStatusSubName == SharedData.Instance().m_PackageController.gameObject)
		{
			if (!SharedData.Instance().m_PackageController.isOpen)
			{
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.PlayerPackage);
			}
			return;
		}
		if (SharedData.Instance().m_PackageController.isOpen)
		{
			SharedData.Instance().m_PackageController.ClosePackage();
		}
		SharedData.Instance().CurrentStatusSubName.SetActive(value: true);
	}

	private IEnumerator ExitSceneAfterSE()
	{
		m_Asyncing = true;
		yield return new WaitForSeconds(m_AudioSource.clip.length);
		ExitScene();
		m_Asyncing = false;
	}

	private void ExitScene()
	{
		if (!isExiting)
		{
			isExiting = true;
			if (SharedData.Instance().CurrentStatusSubName == SharedData.Instance().m_PackageController.gameObject)
			{
				SharedData.Instance().m_PackageController.ClosePackage();
			}
			else
			{
				SharedData.Instance().CurrentStatusSubName.SetActive(value: false);
			}
			SharedData.Instance().m_PackageController.ClosePackage();
			SharedData.Instance().CurrentStatusSubName = null;
			base.gameObject.SetActive(value: false);
			SharedData.Instance().LoadSceneStackRemove("StatusMain");
			isExiting = false;
			SharedData.Instance().m_MapController.m_Menu3.Open();
		}
	}
}
