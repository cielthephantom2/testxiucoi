using System.Collections.Generic;
using UnityEngine;

public class gang_b12WugongStarLimit
{
	public class Row
	{
		public string Percept;

		public string Star;

		public string LV;

		public string Damage;

		public string Damageadd;

		public string Expend;

		public string Expendadd;

		public string LimitBasicAttr;

		public string LimitBasicSkill;

		public string LimitHPMP;

		public string LimitATKDEFSP;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				Percept = list[i][num++],
				Star = list[i][num++],
				LV = list[i][num++],
				Damage = list[i][num++],
				Damageadd = list[i][num++],
				Expend = list[i][num++],
				Expendadd = list[i][num++],
				LimitBasicAttr = list[i][num++],
				LimitBasicSkill = list[i][num++],
				LimitHPMP = list[i][num++],
				LimitATKDEFSP = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_Percept(string find)
	{
		return rowList.Find((Row x) => x.Percept == find);
	}

	public Row Find_Star(string find)
	{
		return rowList.Find((Row x) => x.Star == find);
	}

	public List<Row> FindAll_Star(string find)
	{
		return rowList.FindAll((Row x) => x.Star == find);
	}
}
