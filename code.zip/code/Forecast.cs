using System.Collections.Generic;
using UnityEngine;

public class Forecast
{
	public Vector3Int actionPos;

	public Vector3Int targetPos;

	public List<Vector3Int> effectPosList = new List<Vector3Int>();

	public string actionName;
}
