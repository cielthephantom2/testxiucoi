public class ItemDataBase
{
	public virtual void Init(int index)
	{
	}

	public virtual void Init(int index, int parentIndex)
	{
	}

	public virtual void OnIndexChanged(int index)
	{
	}

	public virtual void OnIndexChanged(int index, int parentIndex)
	{
	}

	public virtual bool IsFilterMatched(string filterStr)
	{
		return true;
	}
}
