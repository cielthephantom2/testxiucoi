using System.Collections.Generic;
using UnityEngine;

public class gang_a01Table
{
	public class Row
	{
		public string ID;

		public string Digest;

		public string isSaveData;

		public string Name;

		public string NameUI;

		public string NameUI_EN;

		public string NameScene;

		public string NameScene_EN;

		public string Type;

		public string Default;

		public string Limit;

		public string LowerLimit;

		public string Note;

		public string Note_EN;

		public string NameUI_Trans => CommonFunc.ShortLangSel(NameUI, NameUI_EN);

		public string NameScene_Trans => CommonFunc.ShortLangSel(NameScene, NameScene_EN);

		public string Note_Trans => CommonFunc.ShortLangSel(Note, Note_EN);
	}

	private List<Row> rowList = new List<Row>();

	private Dictionary<string, Row> rowDict = new Dictionary<string, Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		rowDict.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Digest = list[i][num++],
				isSaveData = list[i][num++],
				Name = list[i][num++],
				NameUI = list[i][num++],
				NameScene = list[i][num++],
				Type = list[i][num++],
				Default = list[i][num++],
				Limit = list[i][num++],
				LowerLimit = list[i][num++],
				Note = list[i][num++]
			};
			row.NameUI = I18nData.Instance().tableI18N.Find_ID("gang_a01_" + row.ID + "_NameUI")?.zh_CH;
			row.NameUI_EN = I18nData.Instance().tableI18N.Find_ID("gang_a01_" + row.ID + "_NameUI")?.en_US;
			row.NameScene = I18nData.Instance().tableI18N.Find_ID("gang_a01_" + row.ID + "_NameScene")?.zh_CH;
			row.NameScene_EN = I18nData.Instance().tableI18N.Find_ID("gang_a01_" + row.ID + "_NameScene")?.en_US;
			row.Note = I18nData.Instance().tableI18N.Find_ID("gang_a01_" + row.ID + "_Note")?.zh_CH;
			row.Note_EN = I18nData.Instance().tableI18N.Find_ID("gang_a01_" + row.ID + "_Note")?.en_US;
			rowList.Add(row);
			rowDict.Add(row.ID, row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		if (rowDict.ContainsKey(find))
		{
			return rowDict[find];
		}
		return null;
	}

	public Row Find_Digest(string find)
	{
		return rowList.Find((Row x) => x.Digest == find);
	}

	public List<Row> FindAll_Digest(string find)
	{
		return rowList.FindAll((Row x) => x.Digest == find);
	}

	public Row Find_isSaveData(string find)
	{
		return rowList.Find((Row x) => x.isSaveData == find);
	}

	public List<Row> FindAll_isSaveData(string find)
	{
		return rowList.FindAll((Row x) => x.isSaveData == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_NameUI(string find)
	{
		return rowList.Find((Row x) => x.NameUI == find);
	}

	public List<Row> FindAll_NameUI(string find)
	{
		return rowList.FindAll((Row x) => x.NameUI == find);
	}

	public Row Find_NameUI_EN(string find)
	{
		return rowList.Find((Row x) => x.NameUI_EN == find);
	}

	public List<Row> FindAll_NameUI_EN(string find)
	{
		return rowList.FindAll((Row x) => x.NameUI_EN == find);
	}

	public Row Find_NameScene(string find)
	{
		return rowList.Find((Row x) => x.NameScene == find);
	}

	public List<Row> FindAll_NameScene(string find)
	{
		return rowList.FindAll((Row x) => x.NameScene == find);
	}

	public Row Find_NameScene_EN(string find)
	{
		return rowList.Find((Row x) => x.NameScene_EN == find);
	}

	public List<Row> FindAll_NameScene_EN(string find)
	{
		return rowList.FindAll((Row x) => x.NameScene_EN == find);
	}

	public Row Find_Type(string find)
	{
		return rowList.Find((Row x) => x.Type == find);
	}

	public List<Row> FindAll_Type(string find)
	{
		return rowList.FindAll((Row x) => x.Type == find);
	}

	public Row Find_Default(string find)
	{
		return rowList.Find((Row x) => x.Default == find);
	}

	public List<Row> FindAll_Default(string find)
	{
		return rowList.FindAll((Row x) => x.Default == find);
	}

	public Row Find_Limit(string find)
	{
		return rowList.Find((Row x) => x.Limit == find);
	}

	public List<Row> FindAll_Limit(string find)
	{
		return rowList.FindAll((Row x) => x.Limit == find);
	}

	public Row Find_Note(string find)
	{
		return rowList.Find((Row x) => x.Note == find);
	}

	public List<Row> FindAll_Note(string find)
	{
		return rowList.FindAll((Row x) => x.Note == find);
	}

	public Row Find_Note_EN(string find)
	{
		return rowList.Find((Row x) => x.Note_EN == find);
	}

	public List<Row> FindAll_Note_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Note_EN == find);
	}
}
