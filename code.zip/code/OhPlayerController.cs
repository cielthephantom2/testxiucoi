using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Spine;
using Spine.Unity;
using SuperTiled2Unity;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

public class OhPlayerController : MonoBehaviour
{
	public State m_State;

	public Direction m_Direction;

	public float MovingSpeedRate = 1f;

	private const float MovementBlockSize = 50f;

	public GameObject m_SplashPrefab;

	private Vector2 m_Facing = Vector2.down;

	private Vector2 m_MovingFrom;

	private Vector2 m_MovingTo;

	private Vector2 m_SpawnPoint;

	private Camera m_camera;

	public bool camera_control = true;

	public int movement = 4;

	private MapController mapcontroller;

	private Vector3Int startPos;

	private Vector3Int endPos;

	private Vector3Int eventPos = Vector3Int.zero;

	private bool eventTrigger;

	private Dictionary<Vector3Int, int> search = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, int> cost = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, Vector3Int> pathSave = new Dictionary<Vector3Int, Vector3Int>();

	private List<Vector3Int> hadSearch = new List<Vector3Int>();

	private GameObject PathPrefab;

	private GameObject Path;

	private List<GameObject> pathObject = new List<GameObject>();

	private SpriteRenderer m_Renderer;

	private int m_SortingOrder;

	private int m_MoveProcess;

	public SkeletonAnimation[] m_Animations;

	private bool moveInterupt;

	private string aniname_stand = "A01-stand";

	private string aniname_walk = "A02-walk";

	private string aniname_behit = "D01-behit";

	private string aniname_die = "D02-die";

	private List<SceneMove> m_SceneMoves = new List<SceneMove>();

	public int m_ScenePlay;

	public MapController.Event m_MultiEvent;

	public List<FollowController> m_Follows = new List<FollowController>();

	public CharaData charadata;

	public bool BackFromOtherScene;

	public bool m_FootOnInterrupt;

	private bool m_KeepDirection;

	public bool m_KeepAnimation;

	private bool m_Init;

	private AudioSource audioSource;

	private AudioClip walkClip;

	private string m_ClipPlaying = "";

	private float m_SEDefVolume;

	public float unitRange = 32f;

	public float moveSpeed = 7.5f;

	private float finalSpeed;

	public Transform movePoint;

	public bool m_IsLoop;

	private bool m_TgtMov;

	public bool m_MovieMove;

	[HideInInspector]
	public JoyStickController joyStickController;

	private JoyInputSystemManager.PlayerActions playerActions;

	private bool sliderotate = true;

	private Direction rotatedir = Direction.Down;

	private void Awake()
	{
		int sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
		SharedData.Instance().m_PlayerSortingIrder = sortingOrder;
		m_Animations = base.gameObject.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		SkeletonAnimation[] animations = m_Animations;
		foreach (SkeletonAnimation obj in animations)
		{
			obj.gameObject.GetComponent<MeshRenderer>().sortingOrder = sortingOrder;
			obj.gameObject.AddComponent<SortingGroup>().sortingOrder = sortingOrder;
		}
		m_SortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "underfoot").sortingOrder;
		base.transform.Find("head_icon/talk/Ani").GetComponent<MeshRenderer>().sortingOrder = sortingOrder + 999;
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
		if (m_Animations.Length >= 3)
		{
			for (int j = 0; j < 3; j++)
			{
				m_Animations[j].AnimationState.Complete += State_Complete;
			}
		}
		SetOverheadCamera();
		charadata = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		audioSource = base.transform.Find("head_icon").GetComponent<AudioSource>();
		m_SEDefVolume = audioSource.volume;
		playerActions = InputSystemCustom.Instance().Player;
		playerActions.Enable();
	}

	public void Init(string _tilename)
	{
		PathPrefab = (GameObject)Resources.Load("Prefabs/PathPlayer");
		walkClip = (AudioClip)Resources.Load("Music/Charas/" + charadata.m_Sound + "/walk", typeof(AudioClip));
		if (BackFromOtherScene)
		{
			m_SpawnPoint = new Vector2(25f + (float)SharedData.Instance().MapUnitsBefore[base.gameObject.name].x * 50f, -25f - (float)SharedData.Instance().MapUnitsBefore[base.gameObject.name].y * 50f);
			camera_control = SharedData.Instance().playercamctrl;
			BackFromOtherScene = false;
		}
		else
		{
			SuperObject superObject = null;
			SuperObject[] byName = mapcontroller.getByName(_tilename);
			if (byName.Length != 0)
			{
				superObject = byName[0];
			}
			if (superObject != null)
			{
				m_SpawnPoint = superObject.transform.position;
			}
			else
			{
				m_SpawnPoint = SharedData.Instance().Mark_Position;
			}
		}
		m_SpawnPoint.x = RoundToGrid(m_SpawnPoint.x);
		m_SpawnPoint.y = RoundToGrid(m_SpawnPoint.y);
		base.transform.localPosition = m_SpawnPoint;
		if (camera_control)
		{
			m_camera.transform.position = new Vector3(m_SpawnPoint.x, m_SpawnPoint.y, -10f);
			mapcontroller.m_CameraTarget = m_camera.transform.position;
		}
		finalSpeed = moveSpeed * unitRange;
		movePoint = base.transform.Find("movepoint");
		movePoint.parent = null;
		m_State = State.MoveInit;
		mapcontroller.ReportPosition(base.name, GetGridPosition());
		if (!mapcontroller.m_MapType.Equals("Base"))
		{
			InitFollows();
		}
		m_Init = true;
	}

	public void WarpTo(Vector3 _pos)
	{
		if (camera_control)
		{
			mapcontroller.m_CameraTarget.x = _pos.x;
			mapcontroller.m_CameraTarget.y = _pos.y;
			mapcontroller.m_CameraTarget.z = -10f;
		}
		base.transform.position = _pos;
		movePoint.position = _pos;
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
	}

	public void PlayAudioClip(string clipname)
	{
		if (m_KeepAnimation)
		{
			return;
		}
		float delay = 0f;
		if (!clipname.Equals(m_ClipPlaying))
		{
			AudioClip audioClip = null;
			audioSource.pitch = 1f;
			if (clipname == "walkClip")
			{
				audioClip = walkClip;
			}
			if (audioClip == null)
			{
				return;
			}
			audioSource.clip = audioClip;
			m_ClipPlaying = clipname;
		}
		StartCoroutine(PlayAudioClipDelay(delay));
	}

	protected IEnumerator PlayAudioClipDelay(float _delay)
	{
		yield return new WaitForSeconds(_delay);
		audioSource.Play();
	}

	public void Hide()
	{
		m_Animations[0].gameObject.SetActive(value: false);
		m_Animations[1].gameObject.SetActive(value: false);
		m_Animations[2].gameObject.SetActive(value: false);
		SharedData.Instance().SpawnStatus = "Hide";
	}

	public void Show()
	{
		Face(m_Direction, isInit: true);
		SharedData.Instance().SpawnStatus = "Normal";
	}

	public void Face(Direction direction, bool isInit = false)
	{
		if (isInit || direction != m_Direction)
		{
			m_Direction = direction;
			switch (direction)
			{
			case Direction.Left:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = 1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			case Direction.Up:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: true);
				break;
			case Direction.Right:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = -1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			default:
				m_Animations[0].gameObject.SetActive(value: true);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			}
		}
	}

	public void PlayAnimation(string animation, bool loop = true, bool compensate = true, float timescale = 1f)
	{
		if (m_KeepAnimation)
		{
			return;
		}
		if (loop && (animation.Equals(aniname_die) || animation.Equals(aniname_behit)))
		{
			loop = false;
		}
		if (m_Animations[0].AnimationName != animation)
		{
			m_Animations[0].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[0].skeleton.SetToSetupPose();
				m_Animations[0].AnimationState.ClearTracks();
			}
			m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[1].AnimationName != animation)
		{
			m_Animations[1].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[1].skeleton.SetToSetupPose();
				m_Animations[1].AnimationState.ClearTracks();
			}
			m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[2].AnimationName != animation)
		{
			m_Animations[2].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[2].skeleton.SetToSetupPose();
				m_Animations[2].AnimationState.ClearTracks();
			}
			m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}

	private void ShowOrHideWeapon(string animation)
	{
		if (animation.Contains("sword"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("knife"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("stick"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
		}
		else if (animation.Contains("hand"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("finger"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("heart"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
	}

	public void PlaySceneMove(string _moves, MapController.Event _event = null)
	{
		string[] array = _moves.Split('&');
		for (int i = 0; i < array.Length; i++)
		{
			string[] array2 = array[i].Split('*');
			m_SceneMoves.Add(new SceneMove
			{
				direction = array2[0],
				step = int.Parse(array2[1])
			});
		}
		m_MultiEvent = _event;
	}

	public void CloseToTarget(Vector3Int _disPos, Vector3Int _eventPos)
	{
		endPos = _disPos;
		eventPos = _eventPos;
		eventTrigger = true;
	}

	private void DoSceneMove()
	{
		m_TgtMov = false;
		if (m_SceneMoves[0].direction == "FORWARD")
		{
			Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
			startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
			switch (m_Direction)
			{
			case Direction.Up:
				endPos = new Vector3Int(vector3Int.x, -vector3Int.y - m_SceneMoves[0].step, 0);
				break;
			case Direction.Down:
				endPos = new Vector3Int(vector3Int.x, -vector3Int.y + m_SceneMoves[0].step, 0);
				break;
			case Direction.Right:
				endPos = new Vector3Int(vector3Int.x - m_SceneMoves[0].step, -vector3Int.y, 0);
				break;
			case Direction.Left:
				endPos = new Vector3Int(vector3Int.x + m_SceneMoves[0].step, -vector3Int.y, 0);
				break;
			}
			m_SceneMoves.RemoveAt(0);
			m_State = State.AStarInit;
			AStarSearchPath();
			return;
		}
		if (m_SceneMoves[0].direction == "FACE")
		{
			switch (m_SceneMoves[0].step)
			{
			case 0:
				Face(Direction.Down);
				break;
			case 1:
				Face(Direction.Right);
				break;
			case 2:
				Face(Direction.Up);
				break;
			case 3:
				Face(Direction.Left);
				break;
			}
			m_SceneMoves.RemoveAt(0);
			return;
		}
		if (m_SceneMoves[0].direction == "TARGET")
		{
			string text = "MV_TGT_" + m_SceneMoves[0].step;
			m_SceneMoves.RemoveAt(0);
			SuperObject superObject = null;
			SuperObject[] byName = mapcontroller.getByName(text);
			if (byName.Length != 0)
			{
				superObject = byName[0];
			}
			if (superObject != null)
			{
				Vector3Int vector3Int2 = mapcontroller.tilemap.WorldToCell(movePoint.position);
				startPos = new Vector3Int(vector3Int2.x, -vector3Int2.y, 0);
				vector3Int2 = mapcontroller.tilemap.WorldToCell(superObject.transform.position);
				endPos = new Vector3Int(vector3Int2.x, -vector3Int2.y, 0);
				if (!startPos.Equals(endPos))
				{
					m_TgtMov = true;
					m_State = State.AStarInit;
					AStarSearchPath();
				}
			}
			return;
		}
		Vector3Int vector3Int3 = mapcontroller.tilemap.WorldToCell(movePoint.position);
		startPos = new Vector3Int(vector3Int3.x, -vector3Int3.y, 0);
		string[] array = m_SceneMoves[0].direction.Split('-');
		switch (array[0])
		{
		case "UP":
			endPos = new Vector3Int(vector3Int3.x, -vector3Int3.y - m_SceneMoves[0].step, 0);
			break;
		case "DOWN":
			endPos = new Vector3Int(vector3Int3.x, -vector3Int3.y + m_SceneMoves[0].step, 0);
			break;
		case "LEFT":
			endPos = new Vector3Int(vector3Int3.x - m_SceneMoves[0].step, -vector3Int3.y, 0);
			break;
		case "RIGHT":
			endPos = new Vector3Int(vector3Int3.x + m_SceneMoves[0].step, -vector3Int3.y, 0);
			break;
		}
		m_KeepDirection = array.Length > 1 && array[1].Equals("KEEP");
		m_KeepAnimation = array.Length > 2 && array[2].Equals("KEEPANI");
		m_SceneMoves.RemoveAt(0);
		m_State = State.AStarInit;
		AStarSearchPath();
	}

	private void Tick(float _deltaTime)
	{
		if (m_State == State.MoveInit)
		{
			mapcontroller.HideCurcor();
			m_State = State.WaitingForInput;
		}
		else if (m_State == State.WaitingForInput)
		{
			if (m_ScenePlay == 1)
			{
				if (m_SceneMoves.Count > 0)
				{
					DoSceneMove();
					return;
				}
				ResetFollowerPosition();
				MovingSpeedRate = 1f;
				m_ScenePlay = 2;
			}
			else
			{
				if (m_ScenePlay == 3)
				{
					return;
				}
				if (m_SceneMoves.Count > 0)
				{
					DoSceneMove();
				}
				else if (m_MultiEvent != null)
				{
					MovingSpeedRate = 1f;
					mapcontroller.EventComplete(m_MultiEvent);
					m_MultiEvent = null;
				}
				else
				{
					if (mapcontroller.IsChating() || mapcontroller.m_ScenePlaying || !mapcontroller.m_Menu3.IsOpen() || mapcontroller.m_LastClickCamera != 0 || mapcontroller.m_InputField.activeInHierarchy)
					{
						return;
					}
					if (playerActions.Confirm.WasReleasedThisFrame())
					{
						KeyDownProcess();
					}
					else
					{
						if (InputUpdate() > 0 || SharedData.Instance().CheckGuiRaycastObjects() || !Input.GetMouseButtonDown(0))
						{
							return;
						}
						if (SharedData.Instance().m_Teleportation)
						{
							Vector3 vector = Camera.main.ScreenToWorldPoint(Input.mousePosition);
							Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector);
							new Vector3Int(vector3Int.x, -vector3Int.y, 0);
							vector.x = RoundToGrid(vector.x);
							vector.y = RoundToGrid(vector.y);
							vector.z = 0f;
							base.transform.localPosition = vector;
							if (camera_control)
							{
								mapcontroller.m_CameraTarget = new Vector3(vector.x, vector.y, -10f);
							}
							movePoint.position = vector;
							mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
						}
						else
						{
							Vector3Int vector3Int2 = mapcontroller.tilemap.WorldToCell(movePoint.position);
							startPos = new Vector3Int(vector3Int2.x, -vector3Int2.y, 0);
							vector3Int2 = mapcontroller.tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
							endPos = new Vector3Int(vector3Int2.x, -vector3Int2.y, 0);
							if (mapcontroller.ClickPosition(endPos))
							{
								m_State = State.MoveInit;
								return;
							}
							if (startPos.Equals(endPos))
							{
								m_State = State.MoveInit;
								return;
							}
							Debug.LogWarning("m_State: " + m_State);
							m_State = State.AStarInit;
							AStarSearchPath();
						}
					}
				}
			}
		}
		else if (m_State == State.AStarWaiting)
		{
			MoveInteruptCheck();
			if (moveInterupt)
			{
				AStarStepInterupt();
			}
			else
			{
				AStarStepUpdate();
			}
		}
		else if (m_State == State.AStarMoving)
		{
			MoveInteruptCheck();
			AStarMove();
		}
		else if (m_State == State.InputMoving)
		{
			MoveUpdate();
		}
		else if (m_State == State.InputMoveWaiting)
		{
			if (InputUpdate() <= 0)
			{
				m_State = State.WaitingForInput;
			}
		}
		else if (m_State == State.OnSliding)
		{
			SlideUpdate();
		}
		else
		{
			if (m_State != State.WaitFollowerStopSlide || !FollowerStopSliding())
			{
				return;
			}
			foreach (FollowController follow in m_Follows)
			{
				follow.m_State = State.AStarWaiting;
			}
			AStarClean();
			m_State = State.WaitingForInput;
			if (sliderotate)
			{
				PlayAnimation(aniname_stand);
				PlayAnimation(aniname_walk);
			}
		}
	}

	private void AStarStepInterupt()
	{
		moveInterupt = false;
		eventTrigger = false;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (!mapcontroller.ClickPosition(endPos))
		{
			AStarClean();
			if (startPos.Equals(endPos))
			{
				m_State = State.MoveInit;
				return;
			}
			m_State = State.AStarInit;
			AStarSearchPath();
		}
	}

	private void AStarStepUpdateEndMove()
	{
		AStarClean();
		m_State = State.MoveInit;
		PlayAnimation(aniname_stand);
		m_KeepDirection = false;
		if (eventTrigger)
		{
			mapcontroller.ClickPosition(eventPos);
			eventTrigger = false;
		}
	}

	private void AStarStepUpdate()
	{
		if (m_MoveProcess < 0)
		{
			AStarStepUpdateEndMove();
			return;
		}
		Vector2 vector = new Vector2(pathObject[m_MoveProcess].transform.localPosition.x, pathObject[m_MoveProcess].transform.localPosition.y);
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector);
		Vector3Int item = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (m_ScenePlay == 0 && !mapcontroller.obstacle.Contains(item) && !mapcontroller.sliding.Contains(item))
		{
			AStarStepUpdateEndMove();
			return;
		}
		if (m_MoveProcess < pathObject.Count - 1)
		{
			Object.Destroy(pathObject[m_MoveProcess + 1]);
		}
		if (!m_KeepDirection)
		{
			float num = vector.x - base.transform.localPosition.x;
			float num2 = vector.y - base.transform.localPosition.y;
			if (Mathf.Abs(num) > Mathf.Abs(num2))
			{
				if (num > 0f)
				{
					Face(Direction.Left);
				}
				else
				{
					Face(Direction.Right);
				}
			}
			else if (num2 > 0f)
			{
				Face(Direction.Up);
			}
			else
			{
				Face(Direction.Down);
			}
		}
		PlayAnimation(aniname_walk);
		PlayAudioClip("walkClip");
		AStarSeek(vector);
		m_MoveProcess--;
	}

	private void MoveInteruptCheck()
	{
		if (m_ScenePlay == 0 && m_MultiEvent == null && !SharedData.Instance().CheckGuiRaycastObjects() && Input.GetMouseButtonDown(0))
		{
			Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
			Vector3Int other = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
			if (!endPos.Equals(other))
			{
				moveInterupt = true;
				endPos = other;
				mapcontroller.ShowCurcorAt(GetEndPosVec2());
			}
		}
	}

	public void KeyDownProcess()
	{
		Vector2 vector = (Vector2)base.gameObject.transform.position + m_Facing * 50f;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		mapcontroller.ClickPosition(pos, _isKey: true);
	}

	private int InputUpdate()
	{
		int result = 0;
		if (SharedData.Instance().isRandomFight || SharedData.Instance().m_MapController.isEnterBattleAnimPlaying)
		{
			return result;
		}
		Vector2 zero = Vector2.zero;
		zero = playerActions.PlayerMove.ReadValue<Vector2>();
		if (Mathf.Abs(zero.x) > Mathf.Abs(zero.y))
		{
			zero.y = 0f;
		}
		else
		{
			zero.x = 0f;
		}
		if (joyStickController.input != Vector2.zero)
		{
			zero = joyStickController.input;
		}
		if (zero.x != 0f)
		{
			m_Facing.x = zero.x;
			m_Facing.y = 0f;
			if (zero.x > 0f)
			{
				Face(Direction.Left);
				result = 4;
			}
			else
			{
				Face(Direction.Right);
				result = 2;
			}
		}
		else if (zero.y != 0f)
		{
			m_Facing.x = 0f;
			m_Facing.y = zero.y;
			if (zero.y > 0f)
			{
				Face(Direction.Up);
				result = 3;
			}
			else
			{
				Face(Direction.Down);
				result = 1;
			}
		}
		m_Facing.Normalize();
		m_MovingFrom = movePoint.position;
		if (zero.SqrMagnitude() > 0f)
		{
			Vector2 vector = m_MovingFrom + m_Facing * 50f;
			Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector);
			Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
			if (!mapcontroller.CanWalk(pos) && !mapcontroller.CanSlide(pos))
			{
				PlayAnimation(aniname_stand);
				return 0;
			}
			m_State = State.InputMoving;
			m_MovingTo = m_MovingFrom + m_Facing * 50f;
			movePoint.position = m_MovingTo;
			PlayAnimation(aniname_walk);
			PlayAudioClip("walkClip");
			if (m_ScenePlay == 0 && m_MultiEvent == null && m_Follows.Count > 0)
			{
				foreach (FollowController follow in m_Follows)
				{
					follow.Show();
				}
				m_Follows[0].AddFollowPos(m_MovingFrom);
			}
		}
		else
		{
			PlayAnimation(aniname_stand);
		}
		return result;
	}

	private Vector2 GetFacing()
	{
		Vector2 zero = Vector2.zero;
		switch (m_Direction)
		{
		case Direction.Up:
			zero.y = 1f;
			break;
		case Direction.Down:
			zero.y = -1f;
			break;
		case Direction.Left:
			zero.x = 1f;
			break;
		case Direction.Right:
			zero.x = -1f;
			break;
		}
		return zero;
	}

	public void Rotate()
	{
		Direction direction = (Direction)(((int)rotatedir / 2 % 4 + 1) * 2);
		rotatedir = direction;
		switch (rotatedir)
		{
		case Direction.Left:
			m_Animations[0].gameObject.SetActive(value: false);
			m_Animations[1].gameObject.SetActive(value: true);
			m_Animations[1].skeleton.ScaleX = 1f;
			m_Animations[2].gameObject.SetActive(value: false);
			break;
		case Direction.Up:
			m_Animations[0].gameObject.SetActive(value: false);
			m_Animations[1].gameObject.SetActive(value: false);
			m_Animations[2].gameObject.SetActive(value: true);
			break;
		case Direction.Right:
			m_Animations[0].gameObject.SetActive(value: false);
			m_Animations[1].gameObject.SetActive(value: true);
			m_Animations[1].skeleton.ScaleX = -1f;
			m_Animations[2].gameObject.SetActive(value: false);
			break;
		default:
			m_Animations[0].gameObject.SetActive(value: true);
			m_Animations[1].gameObject.SetActive(value: false);
			m_Animations[2].gameObject.SetActive(value: false);
			break;
		}
	}

	private bool SlideCheck()
	{
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanSlide(pos))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1017");
			sliderotate = Random.value < 0.5f;
			if (sliderotate)
			{
				PlayAnimation(aniname_stand);
				PlayAnimation(aniname_walk, loop: true, compensate: true, 3f);
				rotatedir = m_Direction;
			}
			else
			{
				PlayAnimation(aniname_die);
			}
			eventTrigger = false;
			AStarClean();
			m_State = State.OnSliding;
			m_MovingFrom = movePoint.position;
			m_MovingTo = m_MovingFrom + GetFacing() * 50f;
			movePoint.position = m_MovingTo;
			if (m_Follows.Count > 0)
			{
				m_Follows[0].AddFollowPos(m_MovingFrom);
			}
			return true;
		}
		return false;
	}

	private void SlideUpdate()
	{
		base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, 1.5f * MovingSpeedRate * finalSpeed * Time.deltaTime);
		float num = 1f;
		if (camera_control)
		{
			mapcontroller.m_CameraTarget = new Vector3(base.transform.position.x, base.transform.position.y, -10f);
		}
		else
		{
			float num2 = Vector3.Distance(base.transform.position, mapcontroller.m_CameraTarget) - 50f;
			if (num2 < 0f)
			{
				num2 = 0f;
			}
			else if (num2 > 450f)
			{
				num2 = 450f;
			}
			num = (450f - num2) / 450f;
		}
		audioSource.volume = m_SEDefVolume * num;
		if (!(Vector3.Distance(base.transform.position, movePoint.position) <= 1f))
		{
			return;
		}
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
		m_MovingFrom = movePoint.position;
		Vector2 vector = m_MovingFrom + GetFacing() * 50f;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanSlide(pos))
		{
			m_MovingTo = vector;
			movePoint.position = m_MovingTo;
			if (sliderotate)
			{
				Rotate();
			}
			return;
		}
		eventTrigger = false;
		AStarClean();
		if (sliderotate)
		{
			m_Direction = rotatedir;
		}
		m_State = State.WaitFollowerStopSlide;
	}

	private bool FollowerStopSliding()
	{
		foreach (FollowController follow in m_Follows)
		{
			if (follow.m_State == State.OnSliding)
			{
				m_State = State.WaitFollowerStopSlide;
				return false;
			}
		}
		return true;
	}

	private void MoveUpdate()
	{
		if (m_ScenePlay == 0)
		{
			base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, SharedData.Instance().m_FieldMoveSpeedRate * finalSpeed * Time.deltaTime);
		}
		else
		{
			base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, MovingSpeedRate * finalSpeed * Time.deltaTime);
		}
		float num = 1f;
		if (camera_control)
		{
			mapcontroller.m_CameraTarget = new Vector3(base.transform.position.x, base.transform.position.y, -10f);
		}
		else
		{
			float num2 = Vector3.Distance(base.transform.position, mapcontroller.m_CameraTarget) - 50f;
			if (num2 < 0f)
			{
				num2 = 0f;
			}
			else if (num2 > 450f)
			{
				num2 = 450f;
			}
			num = (450f - num2) / 450f;
		}
		audioSource.volume = m_SEDefVolume * num;
		if (!(Vector3.Distance(base.transform.position, movePoint.position) <= 1f))
		{
			return;
		}
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
		if (SlideCheck())
		{
			return;
		}
		if (m_FootOnInterrupt)
		{
			m_FootOnInterrupt = false;
			PlayAnimation(aniname_stand);
			eventTrigger = false;
			AStarClean();
			m_State = State.WaitingForInput;
			return;
		}
		if (FollowerStopSliding() && InputUpdate() <= 0)
		{
			m_State = State.WaitingForInput;
		}
		SharedData.Instance().m_MineRefreshWalkStep++;
		if (mapcontroller.CheckNeedRandomFight())
		{
			AStarClean();
			m_State = State.WaitingForInput;
			PlayAnimation(aniname_stand);
		}
	}

	private void Update()
	{
		if (!m_Init || SharedData.Instance().m_MapController == null || SharedData.Instance().m_MapController.isEnterBattleAnimPlaying)
		{
			return;
		}
		float deltaTime = Time.deltaTime;
		foreach (FollowController follow in m_Follows)
		{
			follow.Tick(deltaTime);
		}
		if (mapcontroller.IsChating() || mapcontroller.m_Menu2.IsOpen() || SharedData.Instance().LoadedSceneStack.Count > 0 || SharedData.Instance().m_StatusMain.gameObject.activeInHierarchy || SharedData.Instance().IsViewOpen || SceneManager.sceneCount > 1 || mapcontroller.m_Menu3.WalkSub.activeInHierarchy || mapcontroller.m_Menu3.WConfirm.activeInHierarchy || mapcontroller.m_Menu3.WConfirmLeave.activeInHierarchy || SharedData.Instance().m_PackageController.isOpen || SharedData.Instance().m_TraitPackageController.isOpen)
		{
			playerActions.Disable();
			return;
		}
		playerActions.Enable();
		Tick(deltaTime);
	}

	public Vector2 GetEndPosVec2()
	{
		return new Vector2(25f + (float)endPos.x * 50f, -25f - (float)endPos.y * 50f);
	}

	public void AStarSeek(Vector2 target)
	{
		m_MovingFrom = movePoint.position;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(target);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (m_ScenePlay > 0 || mapcontroller.CanWalk(pos) || mapcontroller.CanSlide(pos))
		{
			m_State = State.AStarMoving;
			m_MovingTo = target;
			movePoint.position = m_MovingTo;
			PlayAnimation(aniname_walk);
			PlayAudioClip("walkClip");
			if (m_FootOnInterrupt || m_ScenePlay != 0 || m_MultiEvent != null || m_Follows.Count <= 0)
			{
				return;
			}
			foreach (FollowController follow in m_Follows)
			{
				follow.Show();
			}
			m_Follows[0].AddFollowPos(m_MovingFrom);
		}
		else
		{
			PlayAnimation(aniname_stand);
		}
	}

	public void AStarMove()
	{
		if (m_ScenePlay == 0)
		{
			base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, SharedData.Instance().m_FieldMoveSpeedRate * finalSpeed * Time.deltaTime);
		}
		else
		{
			base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, MovingSpeedRate * finalSpeed * Time.deltaTime);
		}
		float num = 1f;
		if (camera_control)
		{
			mapcontroller.m_CameraTarget = new Vector3(base.transform.position.x, base.transform.position.y, -10f);
		}
		else
		{
			float num2 = Vector3.Distance(base.transform.position, mapcontroller.m_CameraTarget) - 50f;
			if (num2 < 0f)
			{
				num2 = 0f;
			}
			else if (num2 > 450f)
			{
				num2 = 450f;
			}
			num = (450f - num2) / 450f;
		}
		audioSource.volume = m_SEDefVolume * num;
		if (!(Vector3.Distance(base.transform.position, movePoint.position) <= 1f))
		{
			return;
		}
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
		if (SlideCheck() || !FollowerStopSliding())
		{
			return;
		}
		if (m_FootOnInterrupt)
		{
			m_FootOnInterrupt = false;
			PlayAnimation(aniname_stand);
			eventTrigger = false;
			AStarClean();
			m_State = State.WaitingForInput;
			return;
		}
		SharedData.Instance().m_MineRefreshWalkStep++;
		if (mapcontroller.CheckNeedRandomFight())
		{
			AStarClean();
			m_State = State.WaitingForInput;
			PlayAnimation(aniname_stand);
		}
		else if (moveInterupt)
		{
			AStarStepInterupt();
		}
		else
		{
			AStarStepUpdate();
		}
	}

	private bool checkInFactionCancelFollows(string _id)
	{
		string id = SharedData.Instance().loadMapE04.id;
		foreach (gang_b10Table.Row row in CommonResourcesData.b10.GetRowList())
		{
			if (row.FieldName.Contains(id))
			{
				if (SharedData.Instance().FlagList[row.FactionFlag] == 1 && row.Members.Contains(_id))
				{
					return true;
				}
				break;
			}
		}
		return false;
	}

	public void InitFollows()
	{
		if (m_Follows.Count > 0)
		{
			foreach (FollowController follow in m_Follows)
			{
				Object.Destroy(follow.gameObject);
			}
		}
		m_Follows.Clear();
		int count = SharedData.Instance().FollowList.Count;
		if (count > SharedData.Instance().FollowMaxCount)
		{
			Debug.LogWarningFormat("Fix FollowList.Length issue: followcount = {0}, FollowMaxCount = {1}", count, SharedData.Instance().FollowMaxCount);
			for (int num = count - 1; num >= SharedData.Instance().FollowMaxCount; num--)
			{
				SharedData.Instance().FollowList.RemoveAt(num);
			}
		}
		foreach (string follow2 in SharedData.Instance().FollowList)
		{
			if (!checkInFactionCancelFollows(follow2))
			{
				FollowController followController = SkinCharacter.InitSkinCharacter(SharedData.Instance().GetCharaData(follow2)).AddComponent<FollowController>();
				followController.gameObject.name = "Follow_" + follow2;
				m_Follows.Add(followController);
				followController.player = this;
				followController.Hide();
			}
		}
		FollowController followController2 = null;
		foreach (FollowController follow3 in m_Follows)
		{
			if (followController2 != null)
			{
				followController2.m_Next = follow3;
				followController2 = follow3;
			}
			else
			{
				followController2 = follow3;
			}
		}
	}

	public void ResetFollowerPosition()
	{
		if (m_Follows.Count <= 0)
		{
			return;
		}
		foreach (FollowController follow in m_Follows)
		{
			follow.Hide();
			follow.transform.position = movePoint.position;
			follow.movePoint.position = movePoint.position;
			follow.m_FollowList.Clear();
		}
	}

	public void GatherFollower(bool _is_ani = false)
	{
		if (_is_ani)
		{
			if (m_Follows.Count <= 0)
			{
				return;
			}
			{
				foreach (FollowController follow in m_Follows)
				{
					follow.m_FollowList.Clear();
					follow.AddFollowPos(movePoint.position);
				}
				return;
			}
		}
		ResetFollowerPosition();
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		return zero;
	}

	public Vector3Int GetGridPositionMP()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(movePoint.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(movePoint.position.y) / 50f);
		return zero;
	}

	private int RoundToGrid(float value)
	{
		if (value < 0f)
		{
			return Mathf.CeilToInt(value / 50f) * 50 - 25;
		}
		return Mathf.FloorToInt(value / 50f) * 50 + 25;
	}

	private void SetOverheadCamera()
	{
		m_camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
	}

	public void Idle(string _sec)
	{
		m_ScenePlay = 3;
		StartCoroutine(Humiliate(_sec));
	}

	private IEnumerator Humiliate(string _sec)
	{
		yield return new WaitForSeconds(float.Parse(_sec, CultureInfo.InvariantCulture));
		m_ScenePlay = 2;
	}

	public void AStarSearchPath()
	{
		int num = int.MaxValue;
		if (m_ScenePlay == 0 && mapcontroller.mapUnits.ContainsValue(endPos))
		{
			bool flag = false;
			foreach (Vector3Int neighbor in GetNeighbors(endPos))
			{
				int heuristic = GetHeuristic(neighbor, startPos);
				if (heuristic < num)
				{
					num = heuristic;
					endPos = neighbor;
					flag = true;
				}
			}
			if (!flag)
			{
				m_State = State.MoveInit;
				return;
			}
		}
		search.Add(startPos, GetHeuristic(startPos, endPos));
		cost.Add(startPos, 0);
		hadSearch.Add(startPos);
		pathSave.Add(startPos, startPos);
		Vector3Int vector3Int = startPos;
		bool astar = !mapcontroller.obstacle.Contains(endPos);
		num = int.MaxValue;
		while (search.Count > 0)
		{
			Vector3Int shortestPos = GetShortestPos();
			if (shortestPos.Equals(endPos))
			{
				break;
			}
			foreach (Vector3Int neighbor2 in GetNeighbors(shortestPos, astar))
			{
				if (!hadSearch.Contains(neighbor2))
				{
					cost.Add(neighbor2, cost[shortestPos] + 1);
					int heuristic2 = GetHeuristic(neighbor2, endPos);
					search.Add(neighbor2, cost[neighbor2] + heuristic2);
					pathSave.Add(neighbor2, shortestPos);
					if (heuristic2 < num)
					{
						num = heuristic2;
						vector3Int = neighbor2;
					}
					hadSearch.Add(neighbor2);
				}
			}
		}
		if (pathSave.ContainsKey(endPos))
		{
			ShowPath();
			return;
		}
		endPos = vector3Int;
		ShowPath();
	}

	private void AStarClean()
	{
		foreach (GameObject item in pathObject)
		{
			Object.Destroy(item);
		}
		pathObject.Clear();
		search.Clear();
		cost.Clear();
		pathSave.Clear();
		hadSearch.Clear();
	}

	private List<Vector3Int> GetNeighbors(Vector3Int target, bool _astar = false)
	{
		List<Vector3Int> list = new List<Vector3Int>();
		Vector3Int vector3Int = target + Vector3Int.up;
		Vector3Int vector3Int2 = target + Vector3Int.right;
		Vector3Int vector3Int3 = target - Vector3Int.right;
		Vector3Int vector3Int4 = target - Vector3Int.up;
		if (!m_TgtMov && (m_KeepDirection || m_ScenePlay > 0))
		{
			list.Add(vector3Int);
			list.Add(vector3Int2);
			list.Add(vector3Int3);
			list.Add(vector3Int4);
		}
		else
		{
			if (mapcontroller.CanWalk(vector3Int, _astar) || mapcontroller.CanSlide(vector3Int))
			{
				list.Add(vector3Int);
			}
			if (mapcontroller.CanWalk(vector3Int2, _astar) || mapcontroller.CanSlide(vector3Int2))
			{
				list.Add(vector3Int2);
			}
			if (mapcontroller.CanWalk(vector3Int3, _astar) || mapcontroller.CanSlide(vector3Int3))
			{
				list.Add(vector3Int3);
			}
			if (mapcontroller.CanWalk(vector3Int4, _astar) || mapcontroller.CanSlide(vector3Int4))
			{
				list.Add(vector3Int4);
			}
		}
		return list;
	}

	private int GetHeuristic(Vector3Int posA, Vector3Int posB)
	{
		return Mathf.Abs(posA.x - posB.x) + Mathf.Abs(posA.y - posB.y);
	}

	private Vector3Int GetShortestPos()
	{
		KeyValuePair<Vector3Int, int> keyValuePair = new KeyValuePair<Vector3Int, int>(Vector3Int.zero, int.MaxValue);
		foreach (KeyValuePair<Vector3Int, int> item in search)
		{
			if (item.Value < keyValuePair.Value)
			{
				keyValuePair = item;
			}
		}
		search.Remove(keyValuePair.Key);
		return keyValuePair.Key;
	}

	private void ShowPath()
	{
		Vector3Int key = endPos;
		while (!key.Equals(startPos))
		{
			Vector3Int vector3Int = pathSave[key];
			Path = Object.Instantiate(PathPrefab, mapcontroller.map.transform);
			Path.transform.localPosition = new Vector3(25 + key.x * 50, -25 - key.y * 50);
			pathObject.Add(Path);
			m_Renderer = Path.GetComponentInChildren<SpriteRenderer>();
			m_Renderer.sortingOrder = ((m_SortingOrder > 0) ? m_SortingOrder : 0);
			key = vector3Int;
		}
		m_MoveProcess = pathObject.Count - 1;
		m_State = State.AStarWaiting;
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		if (!m_IsLoop)
		{
			if (trackEntry.Animation.Name == "B01-attack-sword")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B02-attack-knife")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B03-attack-stick")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B04-attack-hand")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B05-attack-finger")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B06-attack-heart")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "D01-behit")
			{
				PlayAnimation("A01-stand");
			}
			else
			{
				_ = trackEntry.Animation.Name == "D02-die";
			}
		}
	}

	public void TakeCamera()
	{
		if (!camera_control)
		{
			camera_control = true;
			mapcontroller.m_CameraTarget = new Vector3(base.transform.position.x, base.transform.position.y, -10f);
		}
	}

	public int GetMonoDirection()
	{
		return m_Direction switch
		{
			Direction.Down => 0, 
			Direction.Left => 1, 
			Direction.Up => 2, 
			Direction.Right => 3, 
			_ => 0, 
		};
	}

	public string SpaceNext2Me()
	{
		Vector2 vector = base.gameObject.transform.position;
		Vector2 vector2 = vector + Vector2.up * 50f;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector2);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanWalk(pos, _astar: true))
		{
			return "UP|0";
		}
		vector2 = vector + Vector2.left * 50f;
		vector3Int = mapcontroller.tilemap.WorldToCell(vector2);
		pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanWalk(pos, _astar: true))
		{
			return "LEFT|3";
		}
		vector2 = vector + Vector2.down * 50f;
		vector3Int = mapcontroller.tilemap.WorldToCell(vector2);
		pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanWalk(pos, _astar: true))
		{
			return "DOWN|2";
		}
		vector2 = vector + Vector2.right * 50f;
		vector3Int = mapcontroller.tilemap.WorldToCell(vector2);
		pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanWalk(pos, _astar: true))
		{
			return "RIGHT|1";
		}
		return "";
	}
}
