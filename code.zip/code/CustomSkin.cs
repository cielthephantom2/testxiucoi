using System;
using System.Collections.Generic;
using System.Reflection;
using Spine.Unity;
using TMPro;
using UnityEngine;
using UnityEngine.U2D;
using UnityEngine.UI;

public class CustomSkin : MonoBehaviour
{
	private GameObject skinItemInfoPrefab;

	private SkeletonGraphic[] skeletonGraphics;

	private Dropdown ActionDropdown;

	private Dropdown SkinTypeDropdown;

	private ScrollRect SkinScrollRect;

	private ScrollRect SaveSkinScrollRect;

	private TMP_Dropdown SkinDropdown;

	private TMP_InputField inputField;

	private static SpriteAtlas CommonSpriteAtlas;

	private static SpriteAtlas TopSpriteAtlas;

	private List<GameObject> skinItemList = new List<GameObject>();

	private List<string> skinItems = new List<string>
	{
		"Clothes", "Head", "HeadOther", "Eyes", "HandLeft", "HandRight", "SleeveLeft", "SleeveRight", "LegLeft", "LegRight",
		"CloakBack", "CloakFront", "EyesBeHit", "HairBack", "HairFront", "Hat", "HandLeftItem", "HandLeftWeapon", "HandRightItem", "HandRightWeapon",
		"WeaponBack", "WeaponBack2", "BackPack", "weapon_sword", "weapon_knife", "weapon_stick", "FaceMask", "Bread"
	};

	private string currentSkinItemKey = "";

	private Dictionary<string, List<string>> SkinDict = new Dictionary<string, List<string>>();

	private List<GameObject> B01SkinInfoItemList = new List<GameObject>();

	private List<gang_b01SkinTable.Row> saveSkinList = new List<gang_b01SkinTable.Row>();

	private int currentSelectSkinIndex;

	private string currentSkinType = "TestCharacter_01-male";

	private bool isRemoveSkintypeChange;

	private void Start()
	{
		CommonResourcesData.LoadResources();
		skeletonGraphics = base.transform.GetComponentsInChildren<SkeletonGraphic>();
		ActionDropdown = base.transform.Find("Panel/DropdownAction").GetComponent<Dropdown>();
		ActionDropdown.onValueChanged.AddListener(delegate
		{
			OnActionValueChange();
		});
		SkinTypeDropdown = base.transform.Find("Panel/DropdownSkinType").GetComponent<Dropdown>();
		SkinTypeDropdown.onValueChanged.AddListener(delegate
		{
			OnSkinTypeValueChange();
		});
		SkinDropdown = base.transform.Find("Panel/ChangeSkin/Dropdown").GetComponent<TMP_Dropdown>();
		SkinScrollRect = base.transform.Find("Panel/ChangeSkin/SkinItem").GetComponent<ScrollRect>();
		SaveSkinScrollRect = base.transform.Find("Panel/SaveList").GetComponent<ScrollRect>();
		skinItemInfoPrefab = Resources.Load("Prefabs/Debug/B01SkinInfoItem", typeof(GameObject)) as GameObject;
		CommonSpriteAtlas = Resources.Load("SkinCharacter/02-SpriteAtlas/00-CommonSpriteAtlas") as SpriteAtlas;
		TopSpriteAtlas = Resources.Load("SkinCharacter/02-SpriteAtlas/00-TopSpriteAtlas") as SpriteAtlas;
		inputField = base.transform.Find("Panel/SkinInfo").GetComponent<TMP_InputField>();
		Button[] componentsInChildren = GetComponentsInChildren<Button>();
		foreach (Button tmp in componentsInChildren)
		{
			tmp.onClick.AddListener(delegate
			{
				OnButtonClick(tmp.gameObject);
			});
		}
		foreach (string skinItem in skinItems)
		{
			SkinDict.Add(skinItem, new List<string>());
		}
		Type typeFromHandle = typeof(gang_b01SkinTable.Row);
		FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		List<TMP_Dropdown.OptionData> list = new List<TMP_Dropdown.OptionData>
		{
			new TMP_Dropdown.OptionData("null")
		};
		FieldInfo[] array = fields;
		foreach (FieldInfo fieldInfo in array)
		{
			if (!fieldInfo.Name.Equals("ID") && !fieldInfo.Name.Equals("Name") && !fieldInfo.Name.Equals("Name_Id") && !fieldInfo.Name.Equals("model"))
			{
				list.Add(new TMP_Dropdown.OptionData(fieldInfo.Name));
			}
		}
		SkinDropdown.options = list;
		SkinDropdown.value = 0;
		SkinDropdown.onValueChanged.AddListener(OnSkinDropdownValueChanged);
		foreach (gang_b01SkinTable.Row row in CommonResourcesData.b01Skin.GetRowList())
		{
			array = fields;
			foreach (FieldInfo fieldInfo2 in array)
			{
				if (!fieldInfo2.Name.Equals("ID") && !fieldInfo2.Name.Equals("Name") && !fieldInfo2.Name.Equals("Name_Id") && !fieldInfo2.Name.Equals("model"))
				{
					string text = (string)typeFromHandle.GetField(fieldInfo2.Name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(row);
					if (!SkinDict[fieldInfo2.Name].Contains(text) && text != "")
					{
						SkinDict[fieldInfo2.Name].Add(text);
					}
				}
			}
		}
		saveSkinList.Add(JsonUtility.FromJson<gang_b01SkinTable.Row>(JsonUtility.ToJson(CommonResourcesData.b01Skin.Find_ID(currentSkinType))));
		currentSelectSkinIndex = 0;
		InitSkinCharacter();
		RefreshSaveSkinList();
	}

	private void InitSkinCharacter()
	{
		SkinCharacter.InitSkinCharacterUI(skeletonGraphics[0], saveSkinList[currentSelectSkinIndex]);
		SkinCharacter.InitSkinCharacterUI(skeletonGraphics[1], saveSkinList[currentSelectSkinIndex]);
		SkinCharacter.InitSkinCharacterUI(skeletonGraphics[2], saveSkinList[currentSelectSkinIndex]);
		PlayAnimation(Aniname.aniname_stand);
		inputField.text = GetSkinString(saveSkinList[currentSelectSkinIndex]);
		RefreshSaveSkinList();
	}

	private string GetSkinString(gang_b01SkinTable.Row b01SkinRow)
	{
		string text = "";
		Type typeFromHandle = typeof(gang_b01SkinTable.Row);
		FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		foreach (FieldInfo fieldInfo in fields)
		{
			FieldInfo field = typeFromHandle.GetField(fieldInfo.Name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			text = text + (string)field.GetValue(b01SkinRow) + ",";
		}
		return text;
	}

	private void OnSkinDropdownValueChanged(int value)
	{
		Debug.Log("Selected Index: " + value);
		string text = SkinDropdown.options[value].text;
		RefreshSkinSelectArea(text);
	}

	private void RefreshSkinSelectArea(string _skin)
	{
		currentSkinItemKey = _skin;
		foreach (GameObject skinItem in skinItemList)
		{
			UnityEngine.Object.DestroyImmediate(skinItem);
		}
		skinItemList.Clear();
		foreach (string item in SkinDict[_skin])
		{
			GameObject skinButton = UnityEngine.Object.Instantiate(CommonResourcesData.m_SkinItemsPrefab, SkinScrollRect.content);
			skinButton.name = item;
			Sprite sprite = CommonSpriteAtlas.GetSprite(item);
			if (sprite == null)
			{
				sprite = TopSpriteAtlas.GetSprite(item);
			}
			skinButton.GetComponent<Image>().sprite = sprite;
			skinButton.GetComponent<Button>().onClick.AddListener(delegate
			{
				OnSkinButtonClick(skinButton);
			});
			skinItemList.Add(skinButton);
		}
	}

	public void OnSkinButtonClick(GameObject go)
	{
		typeof(gang_b01SkinTable.Row).GetField(currentSkinItemKey, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).SetValue(saveSkinList[currentSelectSkinIndex], go.name);
		InitSkinCharacter();
	}

	public void OnButtonClick(GameObject go)
	{
		if (go.name.Equals("Clear"))
		{
			SkinTypeDropdown.value = 0;
			saveSkinList[currentSelectSkinIndex] = JsonUtility.FromJson<gang_b01SkinTable.Row>(JsonUtility.ToJson(CommonResourcesData.b01Skin.Find_ID(currentSkinType)));
			InitSkinCharacter();
		}
		else if (go.name.Equals("AddOne"))
		{
			saveSkinList.Add(JsonUtility.FromJson<gang_b01SkinTable.Row>(JsonUtility.ToJson(CommonResourcesData.b01Skin.Find_ID("TestCharacter_01-male"))));
			RefreshSaveSkinList();
		}
		else if (go.name.Equals("DeleteOne"))
		{
			if (currentSelectSkinIndex >= 0 && saveSkinList.Count > 1)
			{
				saveSkinList.RemoveAt(currentSelectSkinIndex);
				currentSelectSkinIndex = 0;
				RefreshSaveSkinList();
			}
		}
		else if (go.name.Equals("ClearOne"))
		{
			saveSkinList[currentSelectSkinIndex] = JsonUtility.FromJson<gang_b01SkinTable.Row>(JsonUtility.ToJson(CommonResourcesData.b01Skin.Find_ID(saveSkinList[currentSelectSkinIndex].ID)));
			RefreshSaveSkinList();
		}
	}

	private void RefreshSaveSkinList()
	{
		for (int i = 0; i < B01SkinInfoItemList.Count; i++)
		{
			UnityEngine.Object.DestroyImmediate(B01SkinInfoItemList[i]);
		}
		B01SkinInfoItemList.Clear();
		for (int j = 0; j < saveSkinList.Count; j++)
		{
			GameObject skinItemInfoObj = UnityEngine.Object.Instantiate(skinItemInfoPrefab, SaveSkinScrollRect.content);
			skinItemInfoObj.name = j.ToString();
			B01SkinInfoItemList.Add(skinItemInfoObj);
			skinItemInfoObj.transform.Find("Toggle").GetComponent<Toggle>().isOn = currentSelectSkinIndex == int.Parse(skinItemInfoObj.name);
			skinItemInfoObj.transform.Find("SkinInfo").GetComponent<TMP_InputField>().text = GetSkinString(saveSkinList[j]);
			skinItemInfoObj.transform.Find("Toggle").GetComponent<Toggle>().onValueChanged.AddListener(delegate(bool value)
			{
				if (value)
				{
					currentSelectSkinIndex = int.Parse(skinItemInfoObj.name);
					InitSkinCharacter();
					foreach (GameObject b01SkinInfoItem in B01SkinInfoItemList)
					{
						b01SkinInfoItem.transform.Find("Toggle").GetComponent<Toggle>().isOn = currentSelectSkinIndex == int.Parse(b01SkinInfoItem.gameObject.name);
					}
					isRemoveSkintypeChange = true;
					switch (saveSkinList[currentSelectSkinIndex].ID)
					{
					case "TestCharacter_01-male":
						SkinTypeDropdown.value = 0;
						break;
					case "TestCharacter_02-male-Strong":
						SkinTypeDropdown.value = 1;
						break;
					case "TestCharacter_03-male-Fat":
						SkinTypeDropdown.value = 2;
						break;
					case "TestCharacter_04-male-Child":
						SkinTypeDropdown.value = 3;
						break;
					case "TestCharacter_09-female":
						SkinTypeDropdown.value = 4;
						break;
					case "TestCharacter_09-female-black":
						SkinTypeDropdown.value = 5;
						break;
					}
					isRemoveSkintypeChange = false;
				}
				else
				{
					skinItemInfoObj.transform.Find("Toggle").GetComponent<Toggle>().isOn = true;
				}
			});
		}
	}

	public void OnSkinTypeValueChange()
	{
		if (!isRemoveSkintypeChange && SkinTypeDropdown != null)
		{
			switch (SkinTypeDropdown.value)
			{
			case 0:
				saveSkinList[currentSelectSkinIndex].model = "01-male";
				currentSkinType = "TestCharacter_01-male";
				break;
			case 1:
				saveSkinList[currentSelectSkinIndex].model = "02-male-Strong";
				currentSkinType = "TestCharacter_02-male-Strong";
				break;
			case 2:
				saveSkinList[currentSelectSkinIndex].model = "03-male-Fat";
				currentSkinType = "TestCharacter_03-male-Fat";
				break;
			case 3:
				saveSkinList[currentSelectSkinIndex].model = "04-male-Child";
				currentSkinType = "TestCharacter_04-male-Child";
				break;
			case 4:
				saveSkinList[currentSelectSkinIndex].model = "09-female";
				currentSkinType = "TestCharacter_09-female";
				break;
			case 5:
				saveSkinList[currentSelectSkinIndex].model = "09-female-black";
				currentSkinType = "TestCharacter_09-female-black";
				break;
			}
			saveSkinList[currentSelectSkinIndex] = JsonUtility.FromJson<gang_b01SkinTable.Row>(JsonUtility.ToJson(CommonResourcesData.b01Skin.Find_ID(currentSkinType)));
			InitSkinCharacter();
		}
	}

	public void OnActionValueChange()
	{
		if (ActionDropdown != null)
		{
			string animation = Aniname.aniname_stand;
			switch (ActionDropdown.value)
			{
			case 0:
				animation = Aniname.aniname_stand;
				break;
			case 1:
				animation = Aniname.aniname_walk;
				break;
			case 2:
				animation = Aniname.aniname_B01_attack_sword;
				break;
			case 3:
				animation = Aniname.aniname_B01_attack_sword_nouse;
				break;
			case 4:
				animation = Aniname.aniname_B02_attack_knife;
				break;
			case 5:
				animation = Aniname.aniname_B03_attack_stick;
				break;
			case 6:
				animation = Aniname.aniname_B04_attack_hand;
				break;
			case 7:
				animation = Aniname.aniname_B05_attack_finger;
				break;
			case 8:
				animation = Aniname.aniname_B06_attack_heart;
				break;
			case 9:
				animation = Aniname.aniname_C01_attackstand_sword;
				break;
			case 10:
				animation = Aniname.aniname_C02_attackstand_knife;
				break;
			case 11:
				animation = Aniname.aniname_C03_attackstand_stick;
				break;
			case 12:
				animation = Aniname.aniname_C04_attackstand_hand;
				break;
			case 13:
				animation = Aniname.aniname_C05_attackstand_finger;
				break;
			case 14:
				animation = Aniname.aniname_C06_attackstand_heart;
				break;
			case 15:
				animation = Aniname.aniname_behit;
				break;
			case 16:
				animation = Aniname.aniname_die;
				break;
			case 17:
				animation = Aniname.aniname_D02_die_02;
				break;
			}
			PlayAnimation(animation);
		}
	}

	public void PlayAnimation(string animation, bool loop = true, bool compensate = true, bool forcerepeat = false)
	{
		SkeletonGraphic[] array = skeletonGraphics;
		foreach (SkeletonGraphic skeletonGraphic in array)
		{
			if (skeletonGraphic.startingAnimation != animation || forcerepeat)
			{
				if (!compensate)
				{
					skeletonGraphic.Skeleton.SetToSetupPose();
					skeletonGraphic.AnimationState.ClearTracks();
				}
				skeletonGraphic.AnimationState.SetAnimation(0, animation, loop);
			}
		}
	}
}
