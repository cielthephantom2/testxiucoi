using System;
using System.Collections.Concurrent;
using UnityEngine;

public class MainThreadDispatcher : MonoBehaviour
{
	private static MainThreadDispatcher instance;

	private static readonly object lockObject = new object();

	private ConcurrentQueue<Action> actionQueue = new ConcurrentQueue<Action>();

	public static MainThreadDispatcher Instance()
	{
		lock (lockObject)
		{
			if (instance == null)
			{
				GameObject obj = new GameObject("MainThreadDispatcher");
				UnityEngine.Object.DontDestroyOnLoad(obj);
				instance = obj.AddComponent<MainThreadDispatcher>();
			}
		}
		return instance;
	}

	private void Update()
	{
		while (!actionQueue.IsEmpty)
		{
			if (actionQueue.TryDequeue(out var result))
			{
				result();
			}
		}
	}

	public void Enqueue(Action action)
	{
		actionQueue.Enqueue(action);
	}

	public int actionQueueCount()
	{
		return actionQueue.Count;
	}
}
