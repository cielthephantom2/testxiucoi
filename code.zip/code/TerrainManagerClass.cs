using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public static class TerrainManagerClass
{
	public static void TerrainManager(string _skill, Vector3Int _pos, float finalval)
	{
		switch (_skill)
		{
		case "TerrainFireLv1":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.FireLv1, finalval);
			return;
		case "TerrainFireLv2":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.FireLv2, finalval);
			return;
		case "TerrainFirePersistent":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.FirePersistent, finalval);
			return;
		case "TerrainPoisonLv1":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.PoisonLv1, finalval);
			return;
		case "TerrainPoisonLv2":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.PoisonLv2, finalval);
			return;
		case "TerrainPoisonPersistent":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.PoisonPersistent, finalval);
			return;
		case "TerrainTrapSeal":
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.TrapSeal, finalval);
			return;
		case "TerrainTrapBlast":
			if (SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.current != null)
			{
				finalval *= 1f + SharedData.Instance().m_BattleController.current.charadata.GetBattleValueByName("BlastATKup");
			}
			SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.TrapBlast, finalval);
			return;
		case "TerrainClear":
			SharedData.Instance().m_BattleController.DestoryTerrain(_pos);
			return;
		case "TerrainClearFire":
			if (SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type.ToString().Contains("Fire"))
			{
				SharedData.Instance().m_BattleController.DestoryTerrain(_pos);
				return;
			}
			break;
		}
		if (_skill == "TerrainClearPoison" && SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type.ToString().Contains("Poison"))
		{
			SharedData.Instance().m_BattleController.DestoryTerrain(_pos);
		}
		else if (_skill == "TerrainClearSealTrap" && SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.TrapSeal)
		{
			SharedData.Instance().m_BattleController.DestoryTerrain(_pos);
		}
		else if (_skill == "TerrainClearBalstTrap" && SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.TrapBlast)
		{
			SharedData.Instance().m_BattleController.DestoryTerrain(_pos);
		}
		else if (_skill == "TerrainTriggerBalstTrap" && SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.TrapBlast)
		{
			SharedData.Instance().m_BattleController.terrain[_pos].TerrainEffectOn();
		}
		else if (_skill == "TerrainEnhanceFire")
		{
			if (SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type.ToString().Contains("Fire"))
			{
				if (SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.FireLv1)
				{
					SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.FireLv2);
				}
				else if (SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.FireLv2)
				{
					SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.FirePersistent);
				}
			}
			else
			{
				SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.FireLv1);
			}
		}
		else
		{
			if (!(_skill == "TerrainEnhancePoison"))
			{
				return;
			}
			if (SharedData.Instance().m_BattleController.terrain.ContainsKey(_pos) && SharedData.Instance().m_BattleController.terrain[_pos].t_type.ToString().Contains("Poison"))
			{
				if (SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.PoisonLv1)
				{
					SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.PoisonLv2);
				}
				else if (SharedData.Instance().m_BattleController.terrain[_pos].t_type == TerrainType.PoisonLv2)
				{
					SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.PoisonPersistent);
				}
			}
			else
			{
				SharedData.Instance().m_BattleController.AddTerrain(_pos, TerrainType.PoisonLv1);
			}
		}
	}

	public static bool RunCreatTerrainSkill(Vector3Int _pos)
	{
		bool result = false;
		SkillInfo skillInfo = new SkillInfo();
		skillInfo.Init(SharedData.Instance().m_BattleController.current.m_SkillRow, SharedData.Instance().m_BattleController.current);
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			if (skillInfo.sName[i].StartsWith("Terrain"))
			{
				TerrainManager(skillInfo.sName[i], _pos, skillInfo.sValueNum[i]);
				result = true;
			}
		}
		return result;
	}

	public static void RunCreatTerrainItem(gang_b07Table.Row _b07row, Vector3Int _pos)
	{
		new List<string>();
		new List<string>();
		SkillInfo skillInfo = new SkillInfo();
		List<string> skillList = new List<string> { _b07row.Skills1, _b07row.Skills2, _b07row.Skills3, _b07row.Skills4 };
		List<string> skillEcList = new List<string> { "0", "0", "0", "0" };
		skillInfo.InitSkill(skillList, skillEcList);
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			if (skillInfo.sName[i].Contains("Terrain"))
			{
				TerrainManager(skillInfo.sName[i], _pos, skillInfo.sValueNum[i]);
			}
		}
	}

	public static bool RunCreatTerrainEquip(Vector3Int _pos)
	{
		bool result = false;
		foreach (string item in SharedData.Instance().m_BattleController.current.charadata.m_EquipSlot)
		{
			if (!(item != "0"))
			{
				continue;
			}
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(item);
			gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(row.Relateid);
			if (!row2.Skills1.Contains("Terrain"))
			{
				continue;
			}
			SkillInfo skillInfo = new SkillInfo();
			List<string> skillList = new List<string> { row2.Skills1 };
			List<string> skillEcList = new List<string> { row2.Skills1Ec };
			skillInfo.InitSkill(skillList, skillEcList, row2.Enhance);
			for (int i = 0; i <= skillInfo.sid; i++)
			{
				if (skillInfo.sName[i].Contains("Terrain") && Random.Range(0f, 1f) < skillInfo.sOddNum[i])
				{
					TerrainManager(skillInfo.sName[i], _pos, skillInfo.sValueNum[i]);
				}
			}
			result = true;
		}
		string find = SharedData.Instance().m_BattleController.current.charadata.m_EquipSlot[0] + "|" + SharedData.Instance().m_BattleController.current.charadata.m_EquipSlot[1] + "|" + SharedData.Instance().m_BattleController.current.charadata.m_EquipSlot[2];
		gang_b02SetTable.Row row3 = CommonResourcesData.b02Set.Find_Set(find);
		if (row3 != null)
		{
			SkillInfo skillInfo2 = new SkillInfo();
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			if (row3.Skills1.Contains("Terrain"))
			{
				list.Add(row3.Skills1);
				list2.Add(row3.Skills1Ec);
			}
			if (row3.Skills2.Contains("Terrain"))
			{
				list.Add(row3.Skills2);
				list2.Add(row3.Skills2Ec);
			}
			if (row3.Skills3.Contains("Terrain"))
			{
				list.Add(row3.Skills3);
				list2.Add(row3.Skills3Ec);
			}
			if (list.Count > 0)
			{
				skillInfo2.InitSkill(list, list2);
				for (int j = 0; j <= skillInfo2.sid; j++)
				{
					if (skillInfo2.sName[j].Contains("Terrain") && Random.Range(0f, 1f) < skillInfo2.sOddNum[j])
					{
						TerrainManager(skillInfo2.sName[j], _pos, skillInfo2.sValueNum[j]);
					}
				}
				result = true;
			}
		}
		return result;
	}

	public static void RunCreatTerrainTrait(Vector3Int _pos)
	{
		foreach (KeyValuePair<string, string> item in SharedData.Instance().m_BattleController.current.charadata.m_EquipTraitDict)
		{
			if (item.Value == "")
			{
				continue;
			}
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.Value);
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			if (row.add1.StartsWith("Terrain"))
			{
				list.Add(row.add1);
				list2.Add(row.attribute1);
			}
			if (row.add2.StartsWith("Terrain"))
			{
				list.Add(row.add2);
				list2.Add(row.attribute2);
			}
			if (row.add3.StartsWith("Terrain"))
			{
				list.Add(row.add3);
				list2.Add(row.attribute3);
			}
			if (row.add4.StartsWith("Terrain"))
			{
				list.Add(row.add4);
				list2.Add(row.attribute4);
			}
			if (list.Count > 0)
			{
				for (int i = 0; i < list.Count; i++)
				{
					float finalval = float.Parse(list2[i], CultureInfo.InvariantCulture);
					TerrainManager(list[i], _pos, finalval);
				}
			}
		}
		if (!(SharedData.Instance().m_BattleController.current.charadata.m_currentTitleID != ""))
		{
			return;
		}
		gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(SharedData.Instance().m_BattleController.current.charadata.m_currentTitleID);
		List<string> list3 = new List<string>();
		List<string> list4 = new List<string>();
		if (row2.add1.StartsWith("Terrain"))
		{
			list3.Add(row2.add1);
			list4.Add(row2.attribute1);
		}
		if (row2.add2.StartsWith("Terrain"))
		{
			list3.Add(row2.add2);
			list4.Add(row2.attribute2);
		}
		if (row2.add3.StartsWith("Terrain"))
		{
			list3.Add(row2.add3);
			list4.Add(row2.attribute3);
		}
		if (row2.add4.StartsWith("Terrain"))
		{
			list3.Add(row2.add4);
			list4.Add(row2.attribute4);
		}
		if (list3.Count > 0)
		{
			for (int j = 0; j < list3.Count; j++)
			{
				float finalval2 = float.Parse(list4[j], CultureInfo.InvariantCulture);
				TerrainManager(list3[j], _pos, finalval2);
			}
		}
	}
}
