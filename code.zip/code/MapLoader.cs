using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;

public class MapLoader : MonoBehaviour
{
	public static MapLoader instance;

	public bool useAddressable;

	private AssetBundle mapAssetBundle;

	private GameObject map;

	private AsyncOperationHandle<IList<GameObject>> loadHandle;

	public string currentAreaName = "";

	public Dictionary<string, Dictionary<string, GameObject>> mapAreaDict = new Dictionary<string, Dictionary<string, GameObject>>();

	private int index = -1;

	public bool isAddressableLoad;

	public AsyncOperationHandle<IList<IResourceLocation>> locations;

	public Dictionary<string, AsyncOperationHandle<GameObject>> operationDictionary;

	private List<string> keys = new List<string> { "Map_XiangYang", "Map_JiangDong", "Map_XiaoXiang", "Map_BaShu", "Map_ZhongYuan" };

	private void Start()
	{
		instance = this;
		StartCoroutine(LoadAndAssociateResultWithKey(keys));
		Object.DontDestroyOnLoad(base.gameObject);
	}

	private IEnumerator LoadAndAssociateResultWithKey(IList<string> keys)
	{
		if (operationDictionary == null)
		{
			operationDictionary = new Dictionary<string, AsyncOperationHandle<GameObject>>();
		}
		locations = Addressables.LoadResourceLocationsAsync(keys, Addressables.MergeMode.Union, typeof(GameObject));
		yield return locations;
		if (locations.Result.Count > 0)
		{
			Addressables.LoadAssetAsync<GameObject>(locations.Result[0]);
		}
	}

	public void AddressablesLoadMap(string[] areaNames)
	{
		foreach (string areaName in areaNames)
		{
			Debug.Log(areaName + " 开始加载区域地图");
			if (currentAreaName != "")
			{
				Addressables.Release(loadHandle);
			}
			currentAreaName = areaName;
			if (!mapAreaDict.ContainsKey(areaName))
			{
				mapAreaDict.Add(areaName, new Dictionary<string, GameObject>());
			}
			loadHandle = Addressables.LoadAssetsAsync(new List<string> { areaName }, delegate(GameObject addressable)
			{
				if (addressable != null && !mapAreaDict[areaName].ContainsKey(addressable.name))
				{
					Debug.Log(areaName + " 加载区域地图 ： " + addressable.name);
					mapAreaDict[areaName].Add(addressable.name, addressable);
				}
			}, Addressables.MergeMode.Union, releaseDependenciesOnFailure: false);
			loadHandle.Completed += delegate
			{
				Debug.Log(areaName + " 加载区域地图成功");
			};
		}
	}

	public void AddressablesLoadOneMap(gang_e04Table.Row e04Row)
	{
		isAddressableLoad = false;
		foreach (KeyValuePair<string, Dictionary<string, GameObject>> item in mapAreaDict)
		{
			if (item.Key == e04Row.AreaName)
			{
				continue;
			}
			foreach (string item2 in item.Value.Keys.ToList())
			{
				Addressables.ReleaseInstance(item.Value[item2]);
			}
			item.Value.Clear();
		}
		if (!mapAreaDict.ContainsKey(e04Row.AreaName))
		{
			mapAreaDict.Add(e04Row.AreaName, new Dictionary<string, GameObject>());
		}
		foreach (IResourceLocation location in locations.Result)
		{
			if (!(location.PrimaryKey != e04Row.mapName.Split('|')[0]))
			{
				Debug.Log("开始加载区域地图");
				AsyncOperationHandle<GameObject> asyncOperationHandle = Addressables.LoadAssetAsync<GameObject>(location);
				asyncOperationHandle.Completed += delegate(AsyncOperationHandle<GameObject> obj)
				{
					mapAreaDict[e04Row.AreaName].Add(e04Row.mapName.Split('|')[0], obj.Result);
					isAddressableLoad = true;
					Debug.Log(e04Row.AreaName + " 加载区域地图 ： " + location.PrimaryKey);
				};
				break;
			}
		}
	}

	public GameObject AsyncLoadMapByName(gang_e04Table.Row e04Row)
	{
		GameObject result = null;
		if (mapAreaDict.ContainsKey(e04Row.AreaName) && mapAreaDict[e04Row.AreaName].ContainsKey(e04Row.mapName.Split('|')[0]))
		{
			result = Object.Instantiate(mapAreaDict[e04Row.AreaName][e04Row.mapName.Split('|')[0]]);
		}
		return result;
	}

	private void OnDestroy()
	{
		foreach (KeyValuePair<string, AsyncOperationHandle<GameObject>> item in operationDictionary)
		{
			Addressables.Release(item.Value);
		}
	}
}
