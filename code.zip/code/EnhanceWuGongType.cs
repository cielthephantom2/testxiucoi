public enum EnhanceWuGongType
{
	Create,
	Break
}
