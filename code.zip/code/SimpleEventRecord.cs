using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class SimpleEventRecord
{
	[Key(0)]
	public string map_id = "";

	[Key(1)]
	public string originevdata_flag = "";

	[Key(2)]
	public string evdata_flag = "";

	[Key(3)]
	public string display = "";

	[Key(4)]
	public int flow = -1;

	[Key(5)]
	public bool elseroute;

	[Key(6)]
	public int objdirection;

	[Key(7)]
	public bool objcamarectrl;
}
