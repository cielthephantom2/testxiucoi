using UnityEngine;

public class FPSOnGUIText : MonoBehaviour
{
	private float updateInterval = 1f;

	private float accumulated;

	private float frames;

	private float timeRemaining;

	private float fps = 15f;

	private float lastSample;

	private void Awake()
	{
	}

	private void Start()
	{
		Object.DontDestroyOnLoad(base.gameObject);
		timeRemaining = updateInterval;
		lastSample = Time.realtimeSinceStartup;
	}

	private void Update()
	{
		frames += 1f;
		float realtimeSinceStartup = Time.realtimeSinceStartup;
		float num = realtimeSinceStartup - lastSample;
		lastSample = realtimeSinceStartup;
		timeRemaining -= num;
		accumulated += 1f / num;
		if (timeRemaining <= 0f)
		{
			fps = accumulated / frames;
			timeRemaining = updateInterval;
			accumulated = 0f;
			frames = 0f;
		}
	}

	private void OnGUI()
	{
		GUIStyle style = new GUIStyle
		{
			border = new RectOffset(0, 0, 0, 0),
			fontSize = 20,
			fontStyle = FontStyle.Bold
		};
		GUI.Label(new Rect(5f, 30f, 20f, 20f), "<color=#00ff00><size=16>" + fps.ToString("f2") + "</size></color>", style);
	}
}
