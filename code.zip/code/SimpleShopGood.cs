using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class SimpleShopGood
{
	[Key(0)]
	public string id;

	[Key(1)]
	public int hold;
}
