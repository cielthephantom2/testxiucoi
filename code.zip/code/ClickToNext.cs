using Spine.Unity;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ClickToNext : MonoBehaviour
{
	public string m_NextScene = "";

	private bool IsProcessing;

	private float jumpTime = 1.5f;

	private float timer;

	private SkeletonAnimation m_Animations;

	private bool isFinish;

	private void Start()
	{
		SharedData.Instance();
		m_Animations = GetComponentInChildren<SkeletonAnimation>(includeInactive: true);
		if (m_Animations != null)
		{
			m_Animations.AnimationState.Complete += delegate
			{
				isFinish = true;
			};
		}
	}

	private void Update()
	{
		base.transform.Find("Panel/JoyIcon/JoyIcon").GetComponent<Image>().fillAmount = timer / jumpTime;
		if (!IsProcessing && !isFinish)
		{
			if (InputSystemCustom.Instance().UI.JumpAnimation.IsPressed() || Input.GetMouseButton(1) || Input.GetMouseButton(0))
			{
				timer += Time.deltaTime;
				if (timer > jumpTime)
				{
					IsProcessing = true;
					SceneManager.LoadScene(m_NextScene);
				}
			}
			else
			{
				timer = Mathf.Clamp(timer - Time.deltaTime, 0f, jumpTime);
			}
		}
		if (isFinish && (InputSystemCustom.Instance().UI.JumpAnimation.IsPressed() || Input.GetMouseButton(1) || Input.GetMouseButton(0) || Input.anyKeyDown || InputSystemCustom.Instance().UI.AnyKey.IsPressed()))
		{
			IsProcessing = true;
			SceneManager.LoadScene(m_NextScene);
		}
	}
}
