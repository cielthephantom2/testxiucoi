using System.Collections.Generic;
using MessagePack;

[MessagePackObject(false)]
public class CharaDataBasic
{
	[Key(0)]
	public float m_Hp;

	[Key(1)]
	public float m_Mp;

	[Key(2)]
	public Dictionary<string, AtomData> Indexs_Name = new Dictionary<string, AtomData>();

	[Key(3)]
	public List<BuffData> m_Buffs = new List<BuffData>();

	[Key(4)]
	public int m_Exp;

	[Key(5)]
	public int m_Money;

	[Key(6)]
	public int m_Level = 1;

	[Key(7)]
	public List<KongFuData> m_KongFuList = new List<KongFuData>();

	[Key(8)]
	public int m_Talent;

	[Key(9)]
	public List<string> m_TraitList = new List<string>();

	[Key(10)]
	public List<KongFuData> m_AbolishedKongFuList = new List<KongFuData>();
}
