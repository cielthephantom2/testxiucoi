using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.InputSystem.DualShock;
using UnityEngine.InputSystem.Switch;
using UnityEngine.InputSystem.UI;
using UnityEngine.InputSystem.XInput;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class InputDeviceDetector : MonoBehaviour
{
	public static InputDeviceDetector instance;

	[HideInInspector]
	public string gamePadType = "";

	[HideInInspector]
	public static InputDevice currentDevice;

	private GameObject JoyCurseEdgePrefab;

	private Transform InputDeviceChangeUI;

	private Stack<Transform> JoyCursorStack = new Stack<Transform>();

	private bool isJoyCurcorInvisible = true;

	private Transform _JoyCursor;

	private Tweener tweenerTrans;

	private Tweener tweenerAlpha;

	private Vector3 effectScale;

	public InputActionAsset JoyInputActionAsset;

	[HideInInspector]
	public bool isMouseInput;

	private GameObject PressStartedGameObject;

	public static bool isMouse1Up => Input.GetMouseButtonUp(1);

	public Transform JoyCursor
	{
		get
		{
			if (_JoyCursor == null)
			{
				_JoyCursor = Object.Instantiate(JoyCurseEdgePrefab).transform;
				isJoyCurcorInvisible = true;
				Object.DontDestroyOnLoad(_JoyCursor);
			}
			return _JoyCursor;
		}
		set
		{
			_JoyCursor = value;
		}
	}

	private void Start()
	{
		Debug.Log("InputDeviceDetector Awake");
		if (instance == null)
		{
			instance = this;
		}
		JoyCurseEdgePrefab = (GameObject)Resources.Load("Prefabs/JoyStick/JoyCurseEdge");
		InputDeviceChangeUI = base.transform;
		InputDeviceChangeUI.Find("DeviceChange").GetComponent<Animation>().Stop();
		InputDeviceChangeUI.Find("ChangeToGamePad").gameObject.SetActive(value: false);
		InputDeviceChangeUI.Find("ChangeToKeyBoardAndMouse").gameObject.SetActive(value: false);
		Debug.Log("InputDeviceDetector end");
	}

	private void OnEnable()
	{
		InputSystem.onActionChange += DetectInputChange;
		InputSystemCustom.Instance().UI.Confirm.started += OnButtonPressStarted;
		InputSystemCustom.Instance().UI.Confirm.canceled += OnButtonPressCancel;
	}

	private void OnDisable()
	{
		InputSystem.onActionChange -= DetectInputChange;
		InputSystemCustom.Instance().UI.Confirm.started -= OnButtonPressStarted;
		InputSystemCustom.Instance().UI.Confirm.canceled -= OnButtonPressCancel;
	}

	private void OnButtonPressStarted(InputAction.CallbackContext context)
	{
		if (!(SharedData.Instance().m_OpenDetail != "") && (!(EventSystem.current.currentSelectedGameObject != null) || !(EventSystem.current.currentSelectedGameObject.GetComponent<Slider>() != null)) && (!(EventSystem.current.currentSelectedGameObject != null) || (!(EventSystem.current.currentSelectedGameObject.GetComponent<TMP_InputField>() != null) && !(EventSystem.current.currentSelectedGameObject.GetComponent<InputField>() != null))))
		{
			EventSystem.current.sendNavigationEvents = false;
			ExecuteEvents.Execute(EventSystem.current.currentSelectedGameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerDownHandler);
			PressStartedGameObject = EventSystem.current.currentSelectedGameObject;
		}
	}

	private void OnButtonPressCancel(InputAction.CallbackContext context)
	{
		if (!(SharedData.Instance().m_OpenDetail != "") && (!(EventSystem.current.currentSelectedGameObject != null) || !(EventSystem.current.currentSelectedGameObject.GetComponent<Slider>() != null)) && (!(EventSystem.current.currentSelectedGameObject != null) || (!(EventSystem.current.currentSelectedGameObject.GetComponent<TMP_InputField>() != null) && !(EventSystem.current.currentSelectedGameObject.GetComponent<InputField>() != null))))
		{
			EventSystem.current.sendNavigationEvents = true;
			ExecuteEvents.Execute(EventSystem.current.currentSelectedGameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerUpHandler);
			if (PressStartedGameObject == EventSystem.current.currentSelectedGameObject && !CommonFunc.IsHoverOpen() && SharedData.Instance().levelUpController == null)
			{
				OnButtonClick(context);
			}
		}
	}

	private void OnButtonClick(InputAction.CallbackContext context)
	{
		GameObject gameObject = JoyCursor.transform.parent?.gameObject;
		if (gameObject == null || !gameObject.activeInHierarchy || (gameObject.GetComponent<Button>() != null && !gameObject.GetComponent<Button>().IsInteractable()) || JoyCursor.transform.parent?.gameObject == null || JoyCursor.GetComponent<Image>().color == Color.gray)
		{
			return;
		}
		ExecuteEvents.Execute(JoyCursor.transform.parent?.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		if (JoyCursor.transform.parent != null && JoyCursor.transform.parent.GetComponent<Dropdown>() != null)
		{
			JoyCursor.transform.parent.GetComponent<Dropdown>().Show();
		}
		else if (JoyCursor.transform.parent?.parent?.parent?.parent?.parent?.GetComponent<Dropdown>() != null)
		{
			Dropdown dropdown = JoyCursor.transform.parent?.parent?.parent?.parent?.parent?.GetComponent<Dropdown>();
			int value = dropdown.options.FindIndex((Dropdown.OptionData option) => option.text == JoyCursor.transform.parent.GetComponentInChildren<Text>().text);
			dropdown.value = value;
			dropdown.Hide();
			EventSystem.current.SetSelectedGameObject(dropdown.gameObject);
		}
	}

	private void Update()
	{
		if (EventSystem.current.currentSelectedGameObject != null && JoyCursor.transform.parent != EventSystem.current.currentSelectedGameObject.transform)
		{
			SetJoyCurseParent(EventSystem.current.currentSelectedGameObject.transform);
		}
		if (JoyCursor.GetComponent<Image>().color.Equals(Color.gray) && EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").enabled && !isJoyCurcorInvisible)
		{
			JoyCursor.GetComponent<Image>().color = Color.white;
		}
		if (JoyCursor.GetComponent<Image>().color.Equals(Color.white) && !EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").enabled)
		{
			JoyCursor.GetComponent<Image>().color = Color.gray;
		}
	}

	private void LateUpdate()
	{
		SetCurseInvisible(gamePadType == "Mouse");
		if (CommonFunc.IsHoverOpen())
		{
			if (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1) || InputSystemCustom.Instance().UI.Confirm.WasPressedThisFrame() || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputSystemCustom.Instance().UI.ShouHoverItem.WasReleasedThisFrame())
			{
				CommonFunc.CloseHover();
			}
		}
		else
		{
			if (!JoyCursor.gameObject.activeInHierarchy || !InputSystemCustom.Instance().UI.ShouHoverItem.WasReleasedThisFrame() || SharedData.Instance().m_PackageController.isOpen)
			{
				return;
			}
			HoverController componentInParent = JoyCursor.GetComponentInParent<HoverController>();
			if (componentInParent != null)
			{
				if (!HoverController.isOpen)
				{
					componentInParent.HoverEnter(JoyCursor.parent.gameObject);
				}
				else
				{
					componentInParent.HoverDeselect();
				}
			}
			HoverWGController componentInParent2 = JoyCursor.GetComponentInParent<HoverWGController>();
			if (componentInParent2 != null && (!(componentInParent2.GetComponent<AtlasWuGongBtn>() != null) || componentInParent2.GetComponent<AtlasWuGongBtn>().atlasWugongData.isUnlock) && (!(componentInParent2.GetComponent<AtlasEquipBtn>() != null) || componentInParent2.GetComponent<AtlasEquipBtn>().atlasEquipData.isUnlock) && !(SharedData.Instance().m_EvolutionEqNewController != null) && !(SharedData.Instance().createWgController != null) && !(SharedData.Instance().evolutionWgController != null))
			{
				if (CommonResourcesData.HoverItem.activeInHierarchy || CommonResourcesData.HoverWuGong.activeInHierarchy)
				{
					componentInParent2.HoverDeselect(componentInParent2.gameObject);
				}
				else
				{
					StartCoroutine(CommonFunc.DelayedOpenHoverOperation(componentInParent2.gameObject));
				}
			}
		}
	}

	public void ReSetEffect()
	{
	}

	private void SetCurseInvisible(bool Invisible = false)
	{
		if (isJoyCurcorInvisible != Invisible)
		{
			if (JoyCursor.parent == null)
			{
				Invisible = true;
			}
			JoyCursor.GetComponent<CanvasGroup>().alpha = (Invisible ? 0f : 1f);
			if (!Invisible)
			{
				EventSystem.current.SetSelectedGameObject(JoyCursor.parent.gameObject);
			}
			isJoyCurcorInvisible = Invisible;
		}
	}

	public void SetJoyCurseParent(Transform parent)
	{
		CommonFunc.CloseHover();
		JoyCursor.transform.SetParent(parent, worldPositionStays: false);
		SetCurseInvisible(parent == null);
		ScrollWithSelection(JoyCursor.transform.parent?.gameObject);
		if (JoyCursor.transform.parent != null && (SceneManager.GetActiveScene().name == "Starter1" || SceneManager.GetActiveScene().name == "Starter2"))
		{
			JoyCursor.transform.parent.GetComponent<EventTriggerListener>().onClick(JoyCursor.transform.parent.gameObject);
		}
	}

	public void DetectInputChange(object obj, InputActionChange change)
	{
		if (change != InputActionChange.ActionPerformed)
		{
			return;
		}
		InputControl activeControl = ((InputAction)obj).activeControl;
		InputDevice device = activeControl.device;
		if (activeControl.device is Gamepad)
		{
			float num = 0.5f;
			if (activeControl is StickControl stickControl)
			{
				if (stickControl.ReadValue().magnitude < num)
				{
					return;
				}
			}
			else if (activeControl is AxisControl axisControl && Mathf.Abs(axisControl.ReadValue()) < num)
			{
				return;
			}
		}
		if (currentDevice == device)
		{
			return;
		}
		currentDevice = device;
		if (currentDevice is Mouse)
		{
			EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").Enable();
			isMouseInput = true;
			ShowCursor();
			gamePadType = "Mouse";
			return;
		}
		if (currentDevice is Keyboard)
		{
			isMouseInput = false;
			gamePadType = "Keyboard";
			return;
		}
		if (SharedData.Instance().m_MenuController != null && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.m_Flow == BattleControllerFlow.ActionWaitAttack)
		{
			EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").Disable();
		}
		isMouseInput = false;
		HideCursor();
		if (currentDevice is SwitchProControllerHID)
		{
			gamePadType = "SwitchPro";
			{
				foreach (InputActionMap actionMap in JoyInputActionAsset.actionMaps)
				{
					for (int i = 0; i < actionMap.actions.Count; i++)
					{
						InputAction inputAction = actionMap.actions[i];
						for (int j = 0; j < inputAction.bindings.Count; j++)
						{
							if (inputAction.bindings[j].path.Contains("<Gamepad>/buttonSouth"))
							{
								inputAction.ApplyBindingOverride(j, "<Gamepad>/buttonEast");
								InputSystemCustom.Instance().joyInputSystemManager.FindAction(inputAction.id.ToString()).ApplyBindingOverride(j, "<Gamepad>/buttonEast");
							}
							else if (inputAction.bindings[j].path.Contains("<Gamepad>/buttonEast"))
							{
								inputAction.ApplyBindingOverride(j, "<Gamepad>/buttonSouth");
								InputSystemCustom.Instance().joyInputSystemManager.FindAction(inputAction.id.ToString()).ApplyBindingOverride(j, "<Gamepad>/buttonSouth");
							}
							else if (inputAction.bindings[j].path.Contains("<Gamepad>/buttonNorth"))
							{
								inputAction.ApplyBindingOverride(j, "<Gamepad>/buttonWest");
								InputSystemCustom.Instance().joyInputSystemManager.FindAction(inputAction.id.ToString()).ApplyBindingOverride(j, "<Gamepad>/buttonWest");
							}
							else if (inputAction.bindings[j].path.Contains("<Gamepad>/buttonWest"))
							{
								inputAction.ApplyBindingOverride(j, "<Gamepad>/buttonNorth");
								InputSystemCustom.Instance().joyInputSystemManager.FindAction(inputAction.id.ToString()).ApplyBindingOverride(j, "<Gamepad>/buttonNorth");
							}
						}
					}
				}
				return;
			}
		}
		if (!(currentDevice is XInputController) && !(currentDevice is DualShockGamepad))
		{
			return;
		}
		if (currentDevice is XInputController)
		{
			gamePadType = "XBox";
		}
		else if (currentDevice is DualShockGamepad)
		{
			gamePadType = "PS";
		}
		else if (currentDevice is Gamepad)
		{
			gamePadType = "GamePad";
		}
		foreach (InputActionMap actionMap2 in JoyInputActionAsset.actionMaps)
		{
			for (int k = 0; k < actionMap2.actions.Count; k++)
			{
				InputAction inputAction2 = actionMap2.actions[k];
				inputAction2.RemoveAllBindingOverrides();
				InputSystemCustom.Instance().joyInputSystemManager.FindAction(inputAction2.id.ToString()).RemoveAllBindingOverrides();
			}
		}
	}

	private void ShowCursor()
	{
		Mouse current = Mouse.current;
		if (current == null || current.magnitude != 0f)
		{
			Cursor.visible = true;
			Cursor.lockState = CursorLockMode.None;
		}
	}

	private void HideCursor()
	{
		Cursor.visible = false;
		Cursor.lockState = CursorLockMode.Locked;
	}

	public void ScrollWithSelection(GameObject _selected)
	{
		if (_selected == null || isJoyCurcorInvisible || isMouseInput)
		{
			return;
		}
		RectTransform rectTransform = _selected.GetComponentInParent<ScrollRect>()?.GetComponent<RectTransform>();
		if (rectTransform == null || !rectTransform.GetComponent<ScrollRect>().enabled)
		{
			return;
		}
		float num = 0f;
		ScrollRect component = rectTransform.GetComponent<ScrollRect>();
		HorizontalLayoutGroup component2 = component.GetComponent<HorizontalLayoutGroup>();
		VerticalLayoutGroup component3 = component.GetComponent<VerticalLayoutGroup>();
		GridLayoutGroup component4 = component.GetComponent<GridLayoutGroup>();
		if (component2 != null)
		{
			num = component2.spacing;
		}
		if (component3 != null)
		{
			_ = component3.spacing;
		}
		if (component4 != null)
		{
			num = component4.spacing.x;
			_ = component4.spacing;
		}
		if (rectTransform.GetComponent<ScrollRect>().vertical)
		{
			RectTransform rectTransform2 = rectTransform.Find("Viewport")?.GetComponent<RectTransform>();
			RectTransform rectTransform3 = rectTransform.Find("Viewport/Content")?.GetComponent<RectTransform>();
			bool flag = false;
			while (_selected?.transform?.parent != rectTransform3.transform)
			{
				if (_selected?.transform?.parent?.GetComponent<VerticalLayoutGroup>() != null)
				{
					flag = true;
					break;
				}
				_selected = _selected.transform.parent?.gameObject;
				if (_selected == null)
				{
					return;
				}
			}
			if (!(_selected?.transform?.parent == null))
			{
				RectTransform component5 = _selected.GetComponent<RectTransform>();
				float y = rectTransform3.anchoredPosition.y;
				float num2 = rectTransform3.anchoredPosition.y + rectTransform2.rect.height;
				float num3 = Mathf.Abs(component5.anchoredPosition.y);
				if (flag)
				{
					num3 += Mathf.Abs(_selected.transform.parent.GetComponent<RectTransform>().anchoredPosition.y);
				}
				float num4 = num3 + component5.rect.height * component5.pivot.y;
				float num5 = num3 - component5.rect.height * (1f - component5.pivot.y);
				if (num4 > num2)
				{
					float y2 = num4 - rectTransform2.rect.height + component5.rect.height * 0.1f;
					rectTransform3.anchoredPosition = new Vector2(rectTransform3.anchoredPosition.x, y2);
				}
				else if (num5 < y)
				{
					float y3 = num5 - component5.rect.height * 0.1f;
					rectTransform3.anchoredPosition = new Vector2(rectTransform3.anchoredPosition.x, y3);
				}
			}
		}
		else
		{
			if (!rectTransform.GetComponent<ScrollRect>().horizontal)
			{
				return;
			}
			RectTransform rectTransform4 = rectTransform.Find("Viewport")?.GetComponent<RectTransform>();
			RectTransform rectTransform5 = rectTransform.Find("Viewport/Content")?.GetComponent<RectTransform>();
			while (_selected?.transform?.parent != rectTransform5.transform)
			{
				_selected = _selected.transform.parent?.gameObject;
			}
			if (!(_selected?.transform?.parent == null))
			{
				RectTransform component6 = _selected.GetComponent<RectTransform>();
				float num6 = (0f - rectTransform4.rect.width) / 2f;
				float num7 = rectTransform4.rect.width / 2f;
				float num8 = 0f - component6.anchoredPosition.x - rectTransform5.anchoredPosition.x + rectTransform.rect.width / 2f + component6.rect.width / 2f + num;
				float num9 = 0f - component6.anchoredPosition.x - rectTransform5.anchoredPosition.x + rectTransform.rect.width / 2f - component6.rect.width / 2f - num;
				if (num8 > num7)
				{
					float x = 0f - component6.anchoredPosition.x + component6.rect.width - component6.rect.width / 2f;
					rectTransform5.anchoredPosition = new Vector2(x, rectTransform5.anchoredPosition.y);
				}
				else if (num9 < num6)
				{
					float x2 = 0f - component6.anchoredPosition.x + rectTransform.rect.width - component6.rect.width + component6.rect.width / 2f;
					rectTransform5.anchoredPosition = new Vector2(x2, rectTransform5.anchoredPosition.y);
				}
			}
		}
	}

	public bool ResetJoyCurce()
	{
		Transform result = null;
		JoyCursorStack.TryPop(out result);
		ClearJoyStack();
		if (result != null)
		{
			EventSystem.current.SetSelectedGameObject(result.gameObject);
			return true;
		}
		return false;
	}

	public void PushJoyStack(Transform transform = null)
	{
		if (transform != null)
		{
			JoyCursorStack.Push(transform);
		}
		else if (EventSystem.current.currentSelectedGameObject != null)
		{
			JoyCursorStack.Push(EventSystem.current.currentSelectedGameObject.transform);
		}
	}

	public void ClearJoyStack()
	{
		JoyCursorStack.Clear();
	}
}
