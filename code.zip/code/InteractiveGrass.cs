using UnityEngine;
using UnityEngine.Rendering;

public class InteractiveGrass : MonoBehaviour
{
	public Material material;

	private void Awake()
	{
		material = Resources.Load<Material>("Material/InteractiveGrass2D");
	}

	private void Update()
	{
	}

	public void ReSortGrassOrder(int sortingorder)
	{
		SpriteRenderer[] componentsInChildren = GetComponentsInChildren<SpriteRenderer>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].sortingOrder = sortingorder;
		}
		SortingGroup[] componentsInChildren2 = GetComponentsInChildren<SortingGroup>();
		for (int i = 0; i < componentsInChildren2.Length; i++)
		{
			componentsInChildren2[i].sortingOrder = sortingorder;
		}
	}
}
