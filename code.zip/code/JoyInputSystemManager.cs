using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

public class JoyInputSystemManager : IInputActionCollection2, IInputActionCollection, IEnumerable<InputAction>, IEnumerable, IDisposable
{
	public struct UIActions
	{
		private JoyInputSystemManager m_Wrapper;

		public InputAction Confirm => m_Wrapper.m_UI_Confirm;

		public InputAction Cancel => m_Wrapper.m_UI_Cancel;

		public InputAction JumpAnimation => m_Wrapper.m_UI_JumpAnimation;

		public InputAction ManualChangePage => m_Wrapper.m_UI_ManualChangePage;

		public InputAction ManualChangePageNext => m_Wrapper.m_UI_ManualChangePageNext;

		public InputAction ManualChangePagePrev => m_Wrapper.m_UI_ManualChangePagePrev;

		public InputAction RoolTraits => m_Wrapper.m_UI_RoolTraits;

		public InputAction LockAttr => m_Wrapper.m_UI_LockAttr;

		public InputAction CustomTraits => m_Wrapper.m_UI_CustomTraits;

		public InputAction Rename => m_Wrapper.m_UI_Rename;

		public InputAction Starter3Confirm => m_Wrapper.m_UI_Starter3Confirm;

		public InputAction Starter1_1Confirm => m_Wrapper.m_UI_Starter1_1Confirm;

		public InputAction ShouHoverItem => m_Wrapper.m_UI_ShouHoverItem;

		public InputAction AutoSaveBtn => m_Wrapper.m_UI_AutoSaveBtn;

		public InputAction ManualSaveBtn => m_Wrapper.m_UI_ManualSaveBtn;

		public InputAction LearnWugong => m_Wrapper.m_UI_LearnWugong;

		public InputAction CheatInput => m_Wrapper.m_UI_CheatInput;

		public InputAction OpenStatusMain => m_Wrapper.m_UI_OpenStatusMain;

		public InputAction SelectCharacterPrev => m_Wrapper.m_UI_SelectCharacterPrev;

		public InputAction SelectCharacterNext => m_Wrapper.m_UI_SelectCharacterNext;

		public InputAction SelectMenuPrev => m_Wrapper.m_UI_SelectMenuPrev;

		public InputAction SelectMenuNext => m_Wrapper.m_UI_SelectMenuNext;

		public InputAction OpenLogView => m_Wrapper.m_UI_OpenLogView;

		public InputAction OpenAtlas => m_Wrapper.m_UI_OpenAtlas;

		public InputAction OpenJourney => m_Wrapper.m_UI_OpenJourney;

		public InputAction OpenMapView => m_Wrapper.m_UI_OpenMapView;

		public InputAction OpenSystemMenu => m_Wrapper.m_UI_OpenSystemMenu;

		public InputAction QuickOpenLoadManual => m_Wrapper.m_UI_QuickOpenLoadManual;

		public InputAction ZoomMap => m_Wrapper.m_UI_ZoomMap;

		public InputAction ZoomMapUp => m_Wrapper.m_UI_ZoomMapUp;

		public InputAction ZoomMapDown => m_Wrapper.m_UI_ZoomMapDown;

		public InputAction MoveMap => m_Wrapper.m_UI_MoveMap;

		public InputAction MoveMapCursor => m_Wrapper.m_UI_MoveMapCursor;

		public InputAction ScrollRectRoll => m_Wrapper.m_UI_ScrollRectRoll;

		public InputAction SelectTrait => m_Wrapper.m_UI_SelectTrait;

		public InputAction UnEquipTrait => m_Wrapper.m_UI_UnEquipTrait;

		public InputAction ShowFullName => m_Wrapper.m_UI_ShowFullName;

		public InputAction PackageUse => m_Wrapper.m_UI_PackageUse;

		public InputAction PackageBulkShop => m_Wrapper.m_UI_PackageBulkShop;

		public InputAction ConfirmEnhance => m_Wrapper.m_UI_ConfirmEnhance;

		public InputAction ConfirmAddTalent => m_Wrapper.m_UI_ConfirmAddTalent;

		public InputAction OpenTitleTraits => m_Wrapper.m_UI_OpenTitleTraits;

		public InputAction OpenAllTraits => m_Wrapper.m_UI_OpenAllTraits;

		public InputAction QuickLearnWugong => m_Wrapper.m_UI_QuickLearnWugong;

		public InputAction DeleteWugong => m_Wrapper.m_UI_DeleteWugong;

		public InputAction PackageDetail => m_Wrapper.m_UI_PackageDetail;

		public InputAction PackageFilter => m_Wrapper.m_UI_PackageFilter;

		public InputAction ConfirmBattle => m_Wrapper.m_UI_ConfirmBattle;

		public InputAction AtlasNext => m_Wrapper.m_UI_AtlasNext;

		public InputAction AtlasPrev => m_Wrapper.m_UI_AtlasPrev;

		public InputAction ExpelFollower => m_Wrapper.m_UI_ExpelFollower;

		public InputAction SelectDuelAlly => m_Wrapper.m_UI_SelectDuelAlly;

		public InputAction SelectDuelEnemy => m_Wrapper.m_UI_SelectDuelEnemy;

		public InputAction SelectWugongEffectNext => m_Wrapper.m_UI_SelectWugongEffectNext;

		public InputAction SelectWugongEffectPrev => m_Wrapper.m_UI_SelectWugongEffectPrev;

		public InputAction SelectSkinNext => m_Wrapper.m_UI_SelectSkinNext;

		public InputAction SelectSkinPrev => m_Wrapper.m_UI_SelectSkinPrev;

		public InputAction ConfirmCreateWugong => m_Wrapper.m_UI_ConfirmCreateWugong;

		public InputAction BackCreateWugong => m_Wrapper.m_UI_BackCreateWugong;

		public InputAction AnyKey => m_Wrapper.m_UI_AnyKey;

		public bool enabled => Get().enabled;

		public UIActions(JoyInputSystemManager wrapper)
		{
			m_Wrapper = wrapper;
		}

		public InputActionMap Get()
		{
			return m_Wrapper.m_UI;
		}

		public void Enable()
		{
			Get().Enable();
		}

		public void Disable()
		{
			Get().Disable();
		}

		public static implicit operator InputActionMap(UIActions set)
		{
			return set.Get();
		}

		public void AddCallbacks(IUIActions instance)
		{
			if (instance != null && !m_Wrapper.m_UIActionsCallbackInterfaces.Contains(instance))
			{
				m_Wrapper.m_UIActionsCallbackInterfaces.Add(instance);
				Confirm.started += instance.OnConfirm;
				Confirm.performed += instance.OnConfirm;
				Confirm.canceled += instance.OnConfirm;
				Cancel.started += instance.OnCancel;
				Cancel.performed += instance.OnCancel;
				Cancel.canceled += instance.OnCancel;
				JumpAnimation.started += instance.OnJumpAnimation;
				JumpAnimation.performed += instance.OnJumpAnimation;
				JumpAnimation.canceled += instance.OnJumpAnimation;
				ManualChangePage.started += instance.OnManualChangePage;
				ManualChangePage.performed += instance.OnManualChangePage;
				ManualChangePage.canceled += instance.OnManualChangePage;
				ManualChangePageNext.started += instance.OnManualChangePageNext;
				ManualChangePageNext.performed += instance.OnManualChangePageNext;
				ManualChangePageNext.canceled += instance.OnManualChangePageNext;
				ManualChangePagePrev.started += instance.OnManualChangePagePrev;
				ManualChangePagePrev.performed += instance.OnManualChangePagePrev;
				ManualChangePagePrev.canceled += instance.OnManualChangePagePrev;
				RoolTraits.started += instance.OnRoolTraits;
				RoolTraits.performed += instance.OnRoolTraits;
				RoolTraits.canceled += instance.OnRoolTraits;
				LockAttr.started += instance.OnLockAttr;
				LockAttr.performed += instance.OnLockAttr;
				LockAttr.canceled += instance.OnLockAttr;
				CustomTraits.started += instance.OnCustomTraits;
				CustomTraits.performed += instance.OnCustomTraits;
				CustomTraits.canceled += instance.OnCustomTraits;
				Rename.started += instance.OnRename;
				Rename.performed += instance.OnRename;
				Rename.canceled += instance.OnRename;
				Starter3Confirm.started += instance.OnStarter3Confirm;
				Starter3Confirm.performed += instance.OnStarter3Confirm;
				Starter3Confirm.canceled += instance.OnStarter3Confirm;
				Starter1_1Confirm.started += instance.OnStarter1_1Confirm;
				Starter1_1Confirm.performed += instance.OnStarter1_1Confirm;
				Starter1_1Confirm.canceled += instance.OnStarter1_1Confirm;
				ShouHoverItem.started += instance.OnShouHoverItem;
				ShouHoverItem.performed += instance.OnShouHoverItem;
				ShouHoverItem.canceled += instance.OnShouHoverItem;
				AutoSaveBtn.started += instance.OnAutoSaveBtn;
				AutoSaveBtn.performed += instance.OnAutoSaveBtn;
				AutoSaveBtn.canceled += instance.OnAutoSaveBtn;
				ManualSaveBtn.started += instance.OnManualSaveBtn;
				ManualSaveBtn.performed += instance.OnManualSaveBtn;
				ManualSaveBtn.canceled += instance.OnManualSaveBtn;
				LearnWugong.started += instance.OnLearnWugong;
				LearnWugong.performed += instance.OnLearnWugong;
				LearnWugong.canceled += instance.OnLearnWugong;
				CheatInput.started += instance.OnCheatInput;
				CheatInput.performed += instance.OnCheatInput;
				CheatInput.canceled += instance.OnCheatInput;
				OpenStatusMain.started += instance.OnOpenStatusMain;
				OpenStatusMain.performed += instance.OnOpenStatusMain;
				OpenStatusMain.canceled += instance.OnOpenStatusMain;
				SelectCharacterPrev.started += instance.OnSelectCharacterPrev;
				SelectCharacterPrev.performed += instance.OnSelectCharacterPrev;
				SelectCharacterPrev.canceled += instance.OnSelectCharacterPrev;
				SelectCharacterNext.started += instance.OnSelectCharacterNext;
				SelectCharacterNext.performed += instance.OnSelectCharacterNext;
				SelectCharacterNext.canceled += instance.OnSelectCharacterNext;
				SelectMenuPrev.started += instance.OnSelectMenuPrev;
				SelectMenuPrev.performed += instance.OnSelectMenuPrev;
				SelectMenuPrev.canceled += instance.OnSelectMenuPrev;
				SelectMenuNext.started += instance.OnSelectMenuNext;
				SelectMenuNext.performed += instance.OnSelectMenuNext;
				SelectMenuNext.canceled += instance.OnSelectMenuNext;
				OpenLogView.started += instance.OnOpenLogView;
				OpenLogView.performed += instance.OnOpenLogView;
				OpenLogView.canceled += instance.OnOpenLogView;
				OpenAtlas.started += instance.OnOpenAtlas;
				OpenAtlas.performed += instance.OnOpenAtlas;
				OpenAtlas.canceled += instance.OnOpenAtlas;
				OpenJourney.started += instance.OnOpenJourney;
				OpenJourney.performed += instance.OnOpenJourney;
				OpenJourney.canceled += instance.OnOpenJourney;
				OpenMapView.started += instance.OnOpenMapView;
				OpenMapView.performed += instance.OnOpenMapView;
				OpenMapView.canceled += instance.OnOpenMapView;
				OpenSystemMenu.started += instance.OnOpenSystemMenu;
				OpenSystemMenu.performed += instance.OnOpenSystemMenu;
				OpenSystemMenu.canceled += instance.OnOpenSystemMenu;
				QuickOpenLoadManual.started += instance.OnQuickOpenLoadManual;
				QuickOpenLoadManual.performed += instance.OnQuickOpenLoadManual;
				QuickOpenLoadManual.canceled += instance.OnQuickOpenLoadManual;
				ZoomMap.started += instance.OnZoomMap;
				ZoomMap.performed += instance.OnZoomMap;
				ZoomMap.canceled += instance.OnZoomMap;
				ZoomMapUp.started += instance.OnZoomMapUp;
				ZoomMapUp.performed += instance.OnZoomMapUp;
				ZoomMapUp.canceled += instance.OnZoomMapUp;
				ZoomMapDown.started += instance.OnZoomMapDown;
				ZoomMapDown.performed += instance.OnZoomMapDown;
				ZoomMapDown.canceled += instance.OnZoomMapDown;
				MoveMap.started += instance.OnMoveMap;
				MoveMap.performed += instance.OnMoveMap;
				MoveMap.canceled += instance.OnMoveMap;
				MoveMapCursor.started += instance.OnMoveMapCursor;
				MoveMapCursor.performed += instance.OnMoveMapCursor;
				MoveMapCursor.canceled += instance.OnMoveMapCursor;
				ScrollRectRoll.started += instance.OnScrollRectRoll;
				ScrollRectRoll.performed += instance.OnScrollRectRoll;
				ScrollRectRoll.canceled += instance.OnScrollRectRoll;
				SelectTrait.started += instance.OnSelectTrait;
				SelectTrait.performed += instance.OnSelectTrait;
				SelectTrait.canceled += instance.OnSelectTrait;
				UnEquipTrait.started += instance.OnUnEquipTrait;
				UnEquipTrait.performed += instance.OnUnEquipTrait;
				UnEquipTrait.canceled += instance.OnUnEquipTrait;
				ShowFullName.started += instance.OnShowFullName;
				ShowFullName.performed += instance.OnShowFullName;
				ShowFullName.canceled += instance.OnShowFullName;
				PackageUse.started += instance.OnPackageUse;
				PackageUse.performed += instance.OnPackageUse;
				PackageUse.canceled += instance.OnPackageUse;
				PackageBulkShop.started += instance.OnPackageBulkShop;
				PackageBulkShop.performed += instance.OnPackageBulkShop;
				PackageBulkShop.canceled += instance.OnPackageBulkShop;
				ConfirmEnhance.started += instance.OnConfirmEnhance;
				ConfirmEnhance.performed += instance.OnConfirmEnhance;
				ConfirmEnhance.canceled += instance.OnConfirmEnhance;
				ConfirmAddTalent.started += instance.OnConfirmAddTalent;
				ConfirmAddTalent.performed += instance.OnConfirmAddTalent;
				ConfirmAddTalent.canceled += instance.OnConfirmAddTalent;
				OpenTitleTraits.started += instance.OnOpenTitleTraits;
				OpenTitleTraits.performed += instance.OnOpenTitleTraits;
				OpenTitleTraits.canceled += instance.OnOpenTitleTraits;
				OpenAllTraits.started += instance.OnOpenAllTraits;
				OpenAllTraits.performed += instance.OnOpenAllTraits;
				OpenAllTraits.canceled += instance.OnOpenAllTraits;
				QuickLearnWugong.started += instance.OnQuickLearnWugong;
				QuickLearnWugong.performed += instance.OnQuickLearnWugong;
				QuickLearnWugong.canceled += instance.OnQuickLearnWugong;
				DeleteWugong.started += instance.OnDeleteWugong;
				DeleteWugong.performed += instance.OnDeleteWugong;
				DeleteWugong.canceled += instance.OnDeleteWugong;
				PackageDetail.started += instance.OnPackageDetail;
				PackageDetail.performed += instance.OnPackageDetail;
				PackageDetail.canceled += instance.OnPackageDetail;
				PackageFilter.started += instance.OnPackageFilter;
				PackageFilter.performed += instance.OnPackageFilter;
				PackageFilter.canceled += instance.OnPackageFilter;
				ConfirmBattle.started += instance.OnConfirmBattle;
				ConfirmBattle.performed += instance.OnConfirmBattle;
				ConfirmBattle.canceled += instance.OnConfirmBattle;
				AtlasNext.started += instance.OnAtlasNext;
				AtlasNext.performed += instance.OnAtlasNext;
				AtlasNext.canceled += instance.OnAtlasNext;
				AtlasPrev.started += instance.OnAtlasPrev;
				AtlasPrev.performed += instance.OnAtlasPrev;
				AtlasPrev.canceled += instance.OnAtlasPrev;
				ExpelFollower.started += instance.OnExpelFollower;
				ExpelFollower.performed += instance.OnExpelFollower;
				ExpelFollower.canceled += instance.OnExpelFollower;
				SelectDuelAlly.started += instance.OnSelectDuelAlly;
				SelectDuelAlly.performed += instance.OnSelectDuelAlly;
				SelectDuelAlly.canceled += instance.OnSelectDuelAlly;
				SelectDuelEnemy.started += instance.OnSelectDuelEnemy;
				SelectDuelEnemy.performed += instance.OnSelectDuelEnemy;
				SelectDuelEnemy.canceled += instance.OnSelectDuelEnemy;
				SelectWugongEffectNext.started += instance.OnSelectWugongEffectNext;
				SelectWugongEffectNext.performed += instance.OnSelectWugongEffectNext;
				SelectWugongEffectNext.canceled += instance.OnSelectWugongEffectNext;
				SelectWugongEffectPrev.started += instance.OnSelectWugongEffectPrev;
				SelectWugongEffectPrev.performed += instance.OnSelectWugongEffectPrev;
				SelectWugongEffectPrev.canceled += instance.OnSelectWugongEffectPrev;
				SelectSkinNext.started += instance.OnSelectSkinNext;
				SelectSkinNext.performed += instance.OnSelectSkinNext;
				SelectSkinNext.canceled += instance.OnSelectSkinNext;
				SelectSkinPrev.started += instance.OnSelectSkinPrev;
				SelectSkinPrev.performed += instance.OnSelectSkinPrev;
				SelectSkinPrev.canceled += instance.OnSelectSkinPrev;
				ConfirmCreateWugong.started += instance.OnConfirmCreateWugong;
				ConfirmCreateWugong.performed += instance.OnConfirmCreateWugong;
				ConfirmCreateWugong.canceled += instance.OnConfirmCreateWugong;
				BackCreateWugong.started += instance.OnBackCreateWugong;
				BackCreateWugong.performed += instance.OnBackCreateWugong;
				BackCreateWugong.canceled += instance.OnBackCreateWugong;
				AnyKey.started += instance.OnAnyKey;
				AnyKey.performed += instance.OnAnyKey;
				AnyKey.canceled += instance.OnAnyKey;
			}
		}

		private void UnregisterCallbacks(IUIActions instance)
		{
			Confirm.started -= instance.OnConfirm;
			Confirm.performed -= instance.OnConfirm;
			Confirm.canceled -= instance.OnConfirm;
			Cancel.started -= instance.OnCancel;
			Cancel.performed -= instance.OnCancel;
			Cancel.canceled -= instance.OnCancel;
			JumpAnimation.started -= instance.OnJumpAnimation;
			JumpAnimation.performed -= instance.OnJumpAnimation;
			JumpAnimation.canceled -= instance.OnJumpAnimation;
			ManualChangePage.started -= instance.OnManualChangePage;
			ManualChangePage.performed -= instance.OnManualChangePage;
			ManualChangePage.canceled -= instance.OnManualChangePage;
			ManualChangePageNext.started -= instance.OnManualChangePageNext;
			ManualChangePageNext.performed -= instance.OnManualChangePageNext;
			ManualChangePageNext.canceled -= instance.OnManualChangePageNext;
			ManualChangePagePrev.started -= instance.OnManualChangePagePrev;
			ManualChangePagePrev.performed -= instance.OnManualChangePagePrev;
			ManualChangePagePrev.canceled -= instance.OnManualChangePagePrev;
			RoolTraits.started -= instance.OnRoolTraits;
			RoolTraits.performed -= instance.OnRoolTraits;
			RoolTraits.canceled -= instance.OnRoolTraits;
			LockAttr.started -= instance.OnLockAttr;
			LockAttr.performed -= instance.OnLockAttr;
			LockAttr.canceled -= instance.OnLockAttr;
			CustomTraits.started -= instance.OnCustomTraits;
			CustomTraits.performed -= instance.OnCustomTraits;
			CustomTraits.canceled -= instance.OnCustomTraits;
			Rename.started -= instance.OnRename;
			Rename.performed -= instance.OnRename;
			Rename.canceled -= instance.OnRename;
			Starter3Confirm.started -= instance.OnStarter3Confirm;
			Starter3Confirm.performed -= instance.OnStarter3Confirm;
			Starter3Confirm.canceled -= instance.OnStarter3Confirm;
			Starter1_1Confirm.started -= instance.OnStarter1_1Confirm;
			Starter1_1Confirm.performed -= instance.OnStarter1_1Confirm;
			Starter1_1Confirm.canceled -= instance.OnStarter1_1Confirm;
			ShouHoverItem.started -= instance.OnShouHoverItem;
			ShouHoverItem.performed -= instance.OnShouHoverItem;
			ShouHoverItem.canceled -= instance.OnShouHoverItem;
			AutoSaveBtn.started -= instance.OnAutoSaveBtn;
			AutoSaveBtn.performed -= instance.OnAutoSaveBtn;
			AutoSaveBtn.canceled -= instance.OnAutoSaveBtn;
			ManualSaveBtn.started -= instance.OnManualSaveBtn;
			ManualSaveBtn.performed -= instance.OnManualSaveBtn;
			ManualSaveBtn.canceled -= instance.OnManualSaveBtn;
			LearnWugong.started -= instance.OnLearnWugong;
			LearnWugong.performed -= instance.OnLearnWugong;
			LearnWugong.canceled -= instance.OnLearnWugong;
			CheatInput.started -= instance.OnCheatInput;
			CheatInput.performed -= instance.OnCheatInput;
			CheatInput.canceled -= instance.OnCheatInput;
			OpenStatusMain.started -= instance.OnOpenStatusMain;
			OpenStatusMain.performed -= instance.OnOpenStatusMain;
			OpenStatusMain.canceled -= instance.OnOpenStatusMain;
			SelectCharacterPrev.started -= instance.OnSelectCharacterPrev;
			SelectCharacterPrev.performed -= instance.OnSelectCharacterPrev;
			SelectCharacterPrev.canceled -= instance.OnSelectCharacterPrev;
			SelectCharacterNext.started -= instance.OnSelectCharacterNext;
			SelectCharacterNext.performed -= instance.OnSelectCharacterNext;
			SelectCharacterNext.canceled -= instance.OnSelectCharacterNext;
			SelectMenuPrev.started -= instance.OnSelectMenuPrev;
			SelectMenuPrev.performed -= instance.OnSelectMenuPrev;
			SelectMenuPrev.canceled -= instance.OnSelectMenuPrev;
			SelectMenuNext.started -= instance.OnSelectMenuNext;
			SelectMenuNext.performed -= instance.OnSelectMenuNext;
			SelectMenuNext.canceled -= instance.OnSelectMenuNext;
			OpenLogView.started -= instance.OnOpenLogView;
			OpenLogView.performed -= instance.OnOpenLogView;
			OpenLogView.canceled -= instance.OnOpenLogView;
			OpenAtlas.started -= instance.OnOpenAtlas;
			OpenAtlas.performed -= instance.OnOpenAtlas;
			OpenAtlas.canceled -= instance.OnOpenAtlas;
			OpenJourney.started -= instance.OnOpenJourney;
			OpenJourney.performed -= instance.OnOpenJourney;
			OpenJourney.canceled -= instance.OnOpenJourney;
			OpenMapView.started -= instance.OnOpenMapView;
			OpenMapView.performed -= instance.OnOpenMapView;
			OpenMapView.canceled -= instance.OnOpenMapView;
			OpenSystemMenu.started -= instance.OnOpenSystemMenu;
			OpenSystemMenu.performed -= instance.OnOpenSystemMenu;
			OpenSystemMenu.canceled -= instance.OnOpenSystemMenu;
			QuickOpenLoadManual.started -= instance.OnQuickOpenLoadManual;
			QuickOpenLoadManual.performed -= instance.OnQuickOpenLoadManual;
			QuickOpenLoadManual.canceled -= instance.OnQuickOpenLoadManual;
			ZoomMap.started -= instance.OnZoomMap;
			ZoomMap.performed -= instance.OnZoomMap;
			ZoomMap.canceled -= instance.OnZoomMap;
			ZoomMapUp.started -= instance.OnZoomMapUp;
			ZoomMapUp.performed -= instance.OnZoomMapUp;
			ZoomMapUp.canceled -= instance.OnZoomMapUp;
			ZoomMapDown.started -= instance.OnZoomMapDown;
			ZoomMapDown.performed -= instance.OnZoomMapDown;
			ZoomMapDown.canceled -= instance.OnZoomMapDown;
			MoveMap.started -= instance.OnMoveMap;
			MoveMap.performed -= instance.OnMoveMap;
			MoveMap.canceled -= instance.OnMoveMap;
			MoveMapCursor.started -= instance.OnMoveMapCursor;
			MoveMapCursor.performed -= instance.OnMoveMapCursor;
			MoveMapCursor.canceled -= instance.OnMoveMapCursor;
			ScrollRectRoll.started -= instance.OnScrollRectRoll;
			ScrollRectRoll.performed -= instance.OnScrollRectRoll;
			ScrollRectRoll.canceled -= instance.OnScrollRectRoll;
			SelectTrait.started -= instance.OnSelectTrait;
			SelectTrait.performed -= instance.OnSelectTrait;
			SelectTrait.canceled -= instance.OnSelectTrait;
			UnEquipTrait.started -= instance.OnUnEquipTrait;
			UnEquipTrait.performed -= instance.OnUnEquipTrait;
			UnEquipTrait.canceled -= instance.OnUnEquipTrait;
			ShowFullName.started -= instance.OnShowFullName;
			ShowFullName.performed -= instance.OnShowFullName;
			ShowFullName.canceled -= instance.OnShowFullName;
			PackageUse.started -= instance.OnPackageUse;
			PackageUse.performed -= instance.OnPackageUse;
			PackageUse.canceled -= instance.OnPackageUse;
			PackageBulkShop.started -= instance.OnPackageBulkShop;
			PackageBulkShop.performed -= instance.OnPackageBulkShop;
			PackageBulkShop.canceled -= instance.OnPackageBulkShop;
			ConfirmEnhance.started -= instance.OnConfirmEnhance;
			ConfirmEnhance.performed -= instance.OnConfirmEnhance;
			ConfirmEnhance.canceled -= instance.OnConfirmEnhance;
			ConfirmAddTalent.started -= instance.OnConfirmAddTalent;
			ConfirmAddTalent.performed -= instance.OnConfirmAddTalent;
			ConfirmAddTalent.canceled -= instance.OnConfirmAddTalent;
			OpenTitleTraits.started -= instance.OnOpenTitleTraits;
			OpenTitleTraits.performed -= instance.OnOpenTitleTraits;
			OpenTitleTraits.canceled -= instance.OnOpenTitleTraits;
			OpenAllTraits.started -= instance.OnOpenAllTraits;
			OpenAllTraits.performed -= instance.OnOpenAllTraits;
			OpenAllTraits.canceled -= instance.OnOpenAllTraits;
			QuickLearnWugong.started -= instance.OnQuickLearnWugong;
			QuickLearnWugong.performed -= instance.OnQuickLearnWugong;
			QuickLearnWugong.canceled -= instance.OnQuickLearnWugong;
			DeleteWugong.started -= instance.OnDeleteWugong;
			DeleteWugong.performed -= instance.OnDeleteWugong;
			DeleteWugong.canceled -= instance.OnDeleteWugong;
			PackageDetail.started -= instance.OnPackageDetail;
			PackageDetail.performed -= instance.OnPackageDetail;
			PackageDetail.canceled -= instance.OnPackageDetail;
			PackageFilter.started -= instance.OnPackageFilter;
			PackageFilter.performed -= instance.OnPackageFilter;
			PackageFilter.canceled -= instance.OnPackageFilter;
			ConfirmBattle.started -= instance.OnConfirmBattle;
			ConfirmBattle.performed -= instance.OnConfirmBattle;
			ConfirmBattle.canceled -= instance.OnConfirmBattle;
			AtlasNext.started -= instance.OnAtlasNext;
			AtlasNext.performed -= instance.OnAtlasNext;
			AtlasNext.canceled -= instance.OnAtlasNext;
			AtlasPrev.started -= instance.OnAtlasPrev;
			AtlasPrev.performed -= instance.OnAtlasPrev;
			AtlasPrev.canceled -= instance.OnAtlasPrev;
			ExpelFollower.started -= instance.OnExpelFollower;
			ExpelFollower.performed -= instance.OnExpelFollower;
			ExpelFollower.canceled -= instance.OnExpelFollower;
			SelectDuelAlly.started -= instance.OnSelectDuelAlly;
			SelectDuelAlly.performed -= instance.OnSelectDuelAlly;
			SelectDuelAlly.canceled -= instance.OnSelectDuelAlly;
			SelectDuelEnemy.started -= instance.OnSelectDuelEnemy;
			SelectDuelEnemy.performed -= instance.OnSelectDuelEnemy;
			SelectDuelEnemy.canceled -= instance.OnSelectDuelEnemy;
			SelectWugongEffectNext.started -= instance.OnSelectWugongEffectNext;
			SelectWugongEffectNext.performed -= instance.OnSelectWugongEffectNext;
			SelectWugongEffectNext.canceled -= instance.OnSelectWugongEffectNext;
			SelectWugongEffectPrev.started -= instance.OnSelectWugongEffectPrev;
			SelectWugongEffectPrev.performed -= instance.OnSelectWugongEffectPrev;
			SelectWugongEffectPrev.canceled -= instance.OnSelectWugongEffectPrev;
			SelectSkinNext.started -= instance.OnSelectSkinNext;
			SelectSkinNext.performed -= instance.OnSelectSkinNext;
			SelectSkinNext.canceled -= instance.OnSelectSkinNext;
			SelectSkinPrev.started -= instance.OnSelectSkinPrev;
			SelectSkinPrev.performed -= instance.OnSelectSkinPrev;
			SelectSkinPrev.canceled -= instance.OnSelectSkinPrev;
			ConfirmCreateWugong.started -= instance.OnConfirmCreateWugong;
			ConfirmCreateWugong.performed -= instance.OnConfirmCreateWugong;
			ConfirmCreateWugong.canceled -= instance.OnConfirmCreateWugong;
			BackCreateWugong.started -= instance.OnBackCreateWugong;
			BackCreateWugong.performed -= instance.OnBackCreateWugong;
			BackCreateWugong.canceled -= instance.OnBackCreateWugong;
			AnyKey.started -= instance.OnAnyKey;
			AnyKey.performed -= instance.OnAnyKey;
			AnyKey.canceled -= instance.OnAnyKey;
		}

		public void RemoveCallbacks(IUIActions instance)
		{
			if (m_Wrapper.m_UIActionsCallbackInterfaces.Remove(instance))
			{
				UnregisterCallbacks(instance);
			}
		}

		public void SetCallbacks(IUIActions instance)
		{
			foreach (IUIActions uIActionsCallbackInterface in m_Wrapper.m_UIActionsCallbackInterfaces)
			{
				UnregisterCallbacks(uIActionsCallbackInterface);
			}
			m_Wrapper.m_UIActionsCallbackInterfaces.Clear();
			AddCallbacks(instance);
		}
	}

	public struct PlayerActions
	{
		private JoyInputSystemManager m_Wrapper;

		public InputAction PlayerMove => m_Wrapper.m_Player_PlayerMove;

		public InputAction ShowCharacterInfo => m_Wrapper.m_Player_ShowCharacterInfo;

		public InputAction ReturnTitleShortCut => m_Wrapper.m_Player_ReturnTitleShortCut;

		public InputAction AutoBattle => m_Wrapper.m_Player_AutoBattle;

		public InputAction AttackShortCut => m_Wrapper.m_Player_AttackShortCut;

		public InputAction OpenPackageShortCut => m_Wrapper.m_Player_OpenPackageShortCut;

		public InputAction RestShortCut => m_Wrapper.m_Player_RestShortCut;

		public InputAction EscapeShortCut => m_Wrapper.m_Player_EscapeShortCut;

		public InputAction SelectCharacterNext => m_Wrapper.m_Player_SelectCharacterNext;

		public InputAction SelectCharacterPrev => m_Wrapper.m_Player_SelectCharacterPrev;

		public InputAction Confirm => m_Wrapper.m_Player_Confirm;

		public InputAction Cancel => m_Wrapper.m_Player_Cancel;

		public InputAction ShowHp => m_Wrapper.m_Player_ShowHp;

		public InputAction BattleCurcorMove => m_Wrapper.m_Player_BattleCurcorMove;

		public bool enabled => Get().enabled;

		public PlayerActions(JoyInputSystemManager wrapper)
		{
			m_Wrapper = wrapper;
		}

		public InputActionMap Get()
		{
			return m_Wrapper.m_Player;
		}

		public void Enable()
		{
			Get().Enable();
		}

		public void Disable()
		{
			Get().Disable();
		}

		public static implicit operator InputActionMap(PlayerActions set)
		{
			return set.Get();
		}

		public void AddCallbacks(IPlayerActions instance)
		{
			if (instance != null && !m_Wrapper.m_PlayerActionsCallbackInterfaces.Contains(instance))
			{
				m_Wrapper.m_PlayerActionsCallbackInterfaces.Add(instance);
				PlayerMove.started += instance.OnPlayerMove;
				PlayerMove.performed += instance.OnPlayerMove;
				PlayerMove.canceled += instance.OnPlayerMove;
				ShowCharacterInfo.started += instance.OnShowCharacterInfo;
				ShowCharacterInfo.performed += instance.OnShowCharacterInfo;
				ShowCharacterInfo.canceled += instance.OnShowCharacterInfo;
				ReturnTitleShortCut.started += instance.OnReturnTitleShortCut;
				ReturnTitleShortCut.performed += instance.OnReturnTitleShortCut;
				ReturnTitleShortCut.canceled += instance.OnReturnTitleShortCut;
				AutoBattle.started += instance.OnAutoBattle;
				AutoBattle.performed += instance.OnAutoBattle;
				AutoBattle.canceled += instance.OnAutoBattle;
				AttackShortCut.started += instance.OnAttackShortCut;
				AttackShortCut.performed += instance.OnAttackShortCut;
				AttackShortCut.canceled += instance.OnAttackShortCut;
				OpenPackageShortCut.started += instance.OnOpenPackageShortCut;
				OpenPackageShortCut.performed += instance.OnOpenPackageShortCut;
				OpenPackageShortCut.canceled += instance.OnOpenPackageShortCut;
				RestShortCut.started += instance.OnRestShortCut;
				RestShortCut.performed += instance.OnRestShortCut;
				RestShortCut.canceled += instance.OnRestShortCut;
				EscapeShortCut.started += instance.OnEscapeShortCut;
				EscapeShortCut.performed += instance.OnEscapeShortCut;
				EscapeShortCut.canceled += instance.OnEscapeShortCut;
				SelectCharacterNext.started += instance.OnSelectCharacterNext;
				SelectCharacterNext.performed += instance.OnSelectCharacterNext;
				SelectCharacterNext.canceled += instance.OnSelectCharacterNext;
				SelectCharacterPrev.started += instance.OnSelectCharacterPrev;
				SelectCharacterPrev.performed += instance.OnSelectCharacterPrev;
				SelectCharacterPrev.canceled += instance.OnSelectCharacterPrev;
				Confirm.started += instance.OnConfirm;
				Confirm.performed += instance.OnConfirm;
				Confirm.canceled += instance.OnConfirm;
				Cancel.started += instance.OnCancel;
				Cancel.performed += instance.OnCancel;
				Cancel.canceled += instance.OnCancel;
				ShowHp.started += instance.OnShowHp;
				ShowHp.performed += instance.OnShowHp;
				ShowHp.canceled += instance.OnShowHp;
				BattleCurcorMove.started += instance.OnBattleCurcorMove;
				BattleCurcorMove.performed += instance.OnBattleCurcorMove;
				BattleCurcorMove.canceled += instance.OnBattleCurcorMove;
			}
		}

		private void UnregisterCallbacks(IPlayerActions instance)
		{
			PlayerMove.started -= instance.OnPlayerMove;
			PlayerMove.performed -= instance.OnPlayerMove;
			PlayerMove.canceled -= instance.OnPlayerMove;
			ShowCharacterInfo.started -= instance.OnShowCharacterInfo;
			ShowCharacterInfo.performed -= instance.OnShowCharacterInfo;
			ShowCharacterInfo.canceled -= instance.OnShowCharacterInfo;
			ReturnTitleShortCut.started -= instance.OnReturnTitleShortCut;
			ReturnTitleShortCut.performed -= instance.OnReturnTitleShortCut;
			ReturnTitleShortCut.canceled -= instance.OnReturnTitleShortCut;
			AutoBattle.started -= instance.OnAutoBattle;
			AutoBattle.performed -= instance.OnAutoBattle;
			AutoBattle.canceled -= instance.OnAutoBattle;
			AttackShortCut.started -= instance.OnAttackShortCut;
			AttackShortCut.performed -= instance.OnAttackShortCut;
			AttackShortCut.canceled -= instance.OnAttackShortCut;
			OpenPackageShortCut.started -= instance.OnOpenPackageShortCut;
			OpenPackageShortCut.performed -= instance.OnOpenPackageShortCut;
			OpenPackageShortCut.canceled -= instance.OnOpenPackageShortCut;
			RestShortCut.started -= instance.OnRestShortCut;
			RestShortCut.performed -= instance.OnRestShortCut;
			RestShortCut.canceled -= instance.OnRestShortCut;
			EscapeShortCut.started -= instance.OnEscapeShortCut;
			EscapeShortCut.performed -= instance.OnEscapeShortCut;
			EscapeShortCut.canceled -= instance.OnEscapeShortCut;
			SelectCharacterNext.started -= instance.OnSelectCharacterNext;
			SelectCharacterNext.performed -= instance.OnSelectCharacterNext;
			SelectCharacterNext.canceled -= instance.OnSelectCharacterNext;
			SelectCharacterPrev.started -= instance.OnSelectCharacterPrev;
			SelectCharacterPrev.performed -= instance.OnSelectCharacterPrev;
			SelectCharacterPrev.canceled -= instance.OnSelectCharacterPrev;
			Confirm.started -= instance.OnConfirm;
			Confirm.performed -= instance.OnConfirm;
			Confirm.canceled -= instance.OnConfirm;
			Cancel.started -= instance.OnCancel;
			Cancel.performed -= instance.OnCancel;
			Cancel.canceled -= instance.OnCancel;
			ShowHp.started -= instance.OnShowHp;
			ShowHp.performed -= instance.OnShowHp;
			ShowHp.canceled -= instance.OnShowHp;
			BattleCurcorMove.started -= instance.OnBattleCurcorMove;
			BattleCurcorMove.performed -= instance.OnBattleCurcorMove;
			BattleCurcorMove.canceled -= instance.OnBattleCurcorMove;
		}

		public void RemoveCallbacks(IPlayerActions instance)
		{
			if (m_Wrapper.m_PlayerActionsCallbackInterfaces.Remove(instance))
			{
				UnregisterCallbacks(instance);
			}
		}

		public void SetCallbacks(IPlayerActions instance)
		{
			foreach (IPlayerActions playerActionsCallbackInterface in m_Wrapper.m_PlayerActionsCallbackInterfaces)
			{
				UnregisterCallbacks(playerActionsCallbackInterface);
			}
			m_Wrapper.m_PlayerActionsCallbackInterfaces.Clear();
			AddCallbacks(instance);
		}
	}

	public interface IUIActions
	{
		void OnConfirm(InputAction.CallbackContext context);

		void OnCancel(InputAction.CallbackContext context);

		void OnJumpAnimation(InputAction.CallbackContext context);

		void OnManualChangePage(InputAction.CallbackContext context);

		void OnManualChangePageNext(InputAction.CallbackContext context);

		void OnManualChangePagePrev(InputAction.CallbackContext context);

		void OnRoolTraits(InputAction.CallbackContext context);

		void OnLockAttr(InputAction.CallbackContext context);

		void OnCustomTraits(InputAction.CallbackContext context);

		void OnRename(InputAction.CallbackContext context);

		void OnStarter3Confirm(InputAction.CallbackContext context);

		void OnStarter1_1Confirm(InputAction.CallbackContext context);

		void OnShouHoverItem(InputAction.CallbackContext context);

		void OnAutoSaveBtn(InputAction.CallbackContext context);

		void OnManualSaveBtn(InputAction.CallbackContext context);

		void OnLearnWugong(InputAction.CallbackContext context);

		void OnCheatInput(InputAction.CallbackContext context);

		void OnOpenStatusMain(InputAction.CallbackContext context);

		void OnSelectCharacterPrev(InputAction.CallbackContext context);

		void OnSelectCharacterNext(InputAction.CallbackContext context);

		void OnSelectMenuPrev(InputAction.CallbackContext context);

		void OnSelectMenuNext(InputAction.CallbackContext context);

		void OnOpenLogView(InputAction.CallbackContext context);

		void OnOpenAtlas(InputAction.CallbackContext context);

		void OnOpenJourney(InputAction.CallbackContext context);

		void OnOpenMapView(InputAction.CallbackContext context);

		void OnOpenSystemMenu(InputAction.CallbackContext context);

		void OnQuickOpenLoadManual(InputAction.CallbackContext context);

		void OnZoomMap(InputAction.CallbackContext context);

		void OnZoomMapUp(InputAction.CallbackContext context);

		void OnZoomMapDown(InputAction.CallbackContext context);

		void OnMoveMap(InputAction.CallbackContext context);

		void OnMoveMapCursor(InputAction.CallbackContext context);

		void OnScrollRectRoll(InputAction.CallbackContext context);

		void OnSelectTrait(InputAction.CallbackContext context);

		void OnUnEquipTrait(InputAction.CallbackContext context);

		void OnShowFullName(InputAction.CallbackContext context);

		void OnPackageUse(InputAction.CallbackContext context);

		void OnPackageBulkShop(InputAction.CallbackContext context);

		void OnConfirmEnhance(InputAction.CallbackContext context);

		void OnConfirmAddTalent(InputAction.CallbackContext context);

		void OnOpenTitleTraits(InputAction.CallbackContext context);

		void OnOpenAllTraits(InputAction.CallbackContext context);

		void OnQuickLearnWugong(InputAction.CallbackContext context);

		void OnDeleteWugong(InputAction.CallbackContext context);

		void OnPackageDetail(InputAction.CallbackContext context);

		void OnPackageFilter(InputAction.CallbackContext context);

		void OnConfirmBattle(InputAction.CallbackContext context);

		void OnAtlasNext(InputAction.CallbackContext context);

		void OnAtlasPrev(InputAction.CallbackContext context);

		void OnExpelFollower(InputAction.CallbackContext context);

		void OnSelectDuelAlly(InputAction.CallbackContext context);

		void OnSelectDuelEnemy(InputAction.CallbackContext context);

		void OnSelectWugongEffectNext(InputAction.CallbackContext context);

		void OnSelectWugongEffectPrev(InputAction.CallbackContext context);

		void OnSelectSkinNext(InputAction.CallbackContext context);

		void OnSelectSkinPrev(InputAction.CallbackContext context);

		void OnConfirmCreateWugong(InputAction.CallbackContext context);

		void OnBackCreateWugong(InputAction.CallbackContext context);

		void OnAnyKey(InputAction.CallbackContext context);
	}

	public interface IPlayerActions
	{
		void OnPlayerMove(InputAction.CallbackContext context);

		void OnShowCharacterInfo(InputAction.CallbackContext context);

		void OnReturnTitleShortCut(InputAction.CallbackContext context);

		void OnAutoBattle(InputAction.CallbackContext context);

		void OnAttackShortCut(InputAction.CallbackContext context);

		void OnOpenPackageShortCut(InputAction.CallbackContext context);

		void OnRestShortCut(InputAction.CallbackContext context);

		void OnEscapeShortCut(InputAction.CallbackContext context);

		void OnSelectCharacterNext(InputAction.CallbackContext context);

		void OnSelectCharacterPrev(InputAction.CallbackContext context);

		void OnConfirm(InputAction.CallbackContext context);

		void OnCancel(InputAction.CallbackContext context);

		void OnShowHp(InputAction.CallbackContext context);

		void OnBattleCurcorMove(InputAction.CallbackContext context);
	}

	private readonly InputActionMap m_UI;

	private List<IUIActions> m_UIActionsCallbackInterfaces = new List<IUIActions>();

	private readonly InputAction m_UI_Confirm;

	private readonly InputAction m_UI_Cancel;

	private readonly InputAction m_UI_JumpAnimation;

	private readonly InputAction m_UI_ManualChangePage;

	private readonly InputAction m_UI_ManualChangePageNext;

	private readonly InputAction m_UI_ManualChangePagePrev;

	private readonly InputAction m_UI_RoolTraits;

	private readonly InputAction m_UI_LockAttr;

	private readonly InputAction m_UI_CustomTraits;

	private readonly InputAction m_UI_Rename;

	private readonly InputAction m_UI_Starter3Confirm;

	private readonly InputAction m_UI_Starter1_1Confirm;

	private readonly InputAction m_UI_ShouHoverItem;

	private readonly InputAction m_UI_AutoSaveBtn;

	private readonly InputAction m_UI_ManualSaveBtn;

	private readonly InputAction m_UI_LearnWugong;

	private readonly InputAction m_UI_CheatInput;

	private readonly InputAction m_UI_OpenStatusMain;

	private readonly InputAction m_UI_SelectCharacterPrev;

	private readonly InputAction m_UI_SelectCharacterNext;

	private readonly InputAction m_UI_SelectMenuPrev;

	private readonly InputAction m_UI_SelectMenuNext;

	private readonly InputAction m_UI_OpenLogView;

	private readonly InputAction m_UI_OpenAtlas;

	private readonly InputAction m_UI_OpenJourney;

	private readonly InputAction m_UI_OpenMapView;

	private readonly InputAction m_UI_OpenSystemMenu;

	private readonly InputAction m_UI_QuickOpenLoadManual;

	private readonly InputAction m_UI_ZoomMap;

	private readonly InputAction m_UI_ZoomMapUp;

	private readonly InputAction m_UI_ZoomMapDown;

	private readonly InputAction m_UI_MoveMap;

	private readonly InputAction m_UI_MoveMapCursor;

	private readonly InputAction m_UI_ScrollRectRoll;

	private readonly InputAction m_UI_SelectTrait;

	private readonly InputAction m_UI_UnEquipTrait;

	private readonly InputAction m_UI_ShowFullName;

	private readonly InputAction m_UI_PackageUse;

	private readonly InputAction m_UI_PackageBulkShop;

	private readonly InputAction m_UI_ConfirmEnhance;

	private readonly InputAction m_UI_ConfirmAddTalent;

	private readonly InputAction m_UI_OpenTitleTraits;

	private readonly InputAction m_UI_OpenAllTraits;

	private readonly InputAction m_UI_QuickLearnWugong;

	private readonly InputAction m_UI_DeleteWugong;

	private readonly InputAction m_UI_PackageDetail;

	private readonly InputAction m_UI_PackageFilter;

	private readonly InputAction m_UI_ConfirmBattle;

	private readonly InputAction m_UI_AtlasNext;

	private readonly InputAction m_UI_AtlasPrev;

	private readonly InputAction m_UI_ExpelFollower;

	private readonly InputAction m_UI_SelectDuelAlly;

	private readonly InputAction m_UI_SelectDuelEnemy;

	private readonly InputAction m_UI_SelectWugongEffectNext;

	private readonly InputAction m_UI_SelectWugongEffectPrev;

	private readonly InputAction m_UI_SelectSkinNext;

	private readonly InputAction m_UI_SelectSkinPrev;

	private readonly InputAction m_UI_ConfirmCreateWugong;

	private readonly InputAction m_UI_BackCreateWugong;

	private readonly InputAction m_UI_AnyKey;

	private readonly InputActionMap m_Player;

	private List<IPlayerActions> m_PlayerActionsCallbackInterfaces = new List<IPlayerActions>();

	private readonly InputAction m_Player_PlayerMove;

	private readonly InputAction m_Player_ShowCharacterInfo;

	private readonly InputAction m_Player_ReturnTitleShortCut;

	private readonly InputAction m_Player_AutoBattle;

	private readonly InputAction m_Player_AttackShortCut;

	private readonly InputAction m_Player_OpenPackageShortCut;

	private readonly InputAction m_Player_RestShortCut;

	private readonly InputAction m_Player_EscapeShortCut;

	private readonly InputAction m_Player_SelectCharacterNext;

	private readonly InputAction m_Player_SelectCharacterPrev;

	private readonly InputAction m_Player_Confirm;

	private readonly InputAction m_Player_Cancel;

	private readonly InputAction m_Player_ShowHp;

	private readonly InputAction m_Player_BattleCurcorMove;

	private int m_KeyboardAndMouseSchemeIndex = -1;

	private int m_GamePadSchemeIndex = -1;

	private int m_OnSwitchSchemeIndex = -1;

	public InputActionAsset asset { get; }

	public InputBinding? bindingMask
	{
		get
		{
			return asset.bindingMask;
		}
		set
		{
			asset.bindingMask = value;
		}
	}

	public ReadOnlyArray<InputDevice>? devices
	{
		get
		{
			return asset.devices;
		}
		set
		{
			asset.devices = value;
		}
	}

	public ReadOnlyArray<InputControlScheme> controlSchemes => asset.controlSchemes;

	public IEnumerable<InputBinding> bindings => asset.bindings;

	public UIActions UI => new UIActions(this);

	public PlayerActions Player => new PlayerActions(this);

	public InputControlScheme KeyboardAndMouseScheme
	{
		get
		{
			if (m_KeyboardAndMouseSchemeIndex == -1)
			{
				m_KeyboardAndMouseSchemeIndex = asset.FindControlSchemeIndex("KeyboardAndMouse");
			}
			return asset.controlSchemes[m_KeyboardAndMouseSchemeIndex];
		}
	}

	public InputControlScheme GamePadScheme
	{
		get
		{
			if (m_GamePadSchemeIndex == -1)
			{
				m_GamePadSchemeIndex = asset.FindControlSchemeIndex("GamePad");
			}
			return asset.controlSchemes[m_GamePadSchemeIndex];
		}
	}

	public InputControlScheme OnSwitchScheme
	{
		get
		{
			if (m_OnSwitchSchemeIndex == -1)
			{
				m_OnSwitchSchemeIndex = asset.FindControlSchemeIndex("OnSwitch");
			}
			return asset.controlSchemes[m_OnSwitchSchemeIndex];
		}
	}

	public JoyInputSystemManager()
	{
		asset = InputActionAsset.FromJson("{\r\n    \"name\": \"JoyInputSystemManager\",\r\n    \"maps\": [\r\n        {\r\n            \"name\": \"UI\",\r\n            \"id\": \"b0332005-ac3f-4029-b179-606b653cdfe3\",\r\n            \"actions\": [\r\n                {\r\n                    \"name\": \"Confirm\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"0435110d-2c9e-443b-80a1-94a8e4b988bf\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"Cancel\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"66e8147c-6d3d-4850-a6b9-8db484392dfd\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"Hold(duration=5)\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"JumpAnimation\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"41f5e869-08cf-4f01-8d5d-4178ac1b4c2b\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ManualChangePage\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"1239048e-166d-4197-97c1-fe5a381c3c37\",\r\n                    \"expectedControlType\": \"Axis\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                },\r\n                {\r\n                    \"name\": \"ManualChangePageNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"ab23bdb7-c21a-4305-aab0-df1f937070a2\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ManualChangePagePrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"24426740-a2d8-4d25-8677-7ac099f35e00\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"RoolTraits\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"a681d39b-e92d-475b-99ed-7aac5bbdda72\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"LockAttr\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"57332116-2306-47d7-8615-1e953bbe613e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"CustomTraits\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"aa546c22-c2f7-4f3f-9294-c096d11ce705\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"Rename\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"afb1dfe6-e327-458e-b4ce-7e85e5dee451\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"Starter3Confirm\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"4c5ab86a-4094-41fe-8ff7-5df7b732dfe9\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"Starter1_1Confirm\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"33de328e-2b5c-42e9-bf10-10c28307534d\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ShouHoverItem\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"d7a228cf-7a6f-4c39-a147-25a25c9ec652\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"AutoSaveBtn\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"add509dc-d51d-43a2-ad46-2cb1d27556d0\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ManualSaveBtn\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"52c2d589-9bc0-4881-86b0-9d478a501bfe\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"LearnWugong\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"c77ecccc-b576-45ef-8ef1-677acd2c4b49\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"CheatInput\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"4055b170-ab85-478e-a988-e55640f3f55b\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenStatusMain\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"f372ce19-dc3d-4049-9400-d352a272af1e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectCharacterPrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"58ab6352-afff-408a-8952-433cdbbbd70e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectCharacterNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"c8200a91-f184-4f59-995f-8f1d84aad0a4\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectMenuPrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"4d452dea-c5c7-4e85-b97c-f64154d1f998\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectMenuNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"9db90e42-a156-4cfb-8430-d775b987149a\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenLogView\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"721aad96-1327-40b3-ad5f-f2c6e95ba3ba\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenAtlas\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"97aeaac4-4d65-4b08-980d-7efd0c85f910\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenJourney\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"57dc0a45-3299-4d25-8b8b-3845675bfbb8\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenMapView\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"13a0e0f2-c9be-413a-8888-06ec31705b87\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenSystemMenu\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"66d535d3-b3e0-4449-a207-54a73de7ee12\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"QuickOpenLoadManual\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"8c551d40-5384-490d-abc5-cacd04badd76\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ZoomMap\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"587ab044-86a4-4ee9-a38a-4b470cbc8048\",\r\n                    \"expectedControlType\": \"Axis\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                },\r\n                {\r\n                    \"name\": \"ZoomMapUp\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"03047222-f25c-4d0c-a836-72e87d8f632b\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ZoomMapDown\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"c9cd2208-ca0e-4b1f-9c5b-927e4bc25003\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"MoveMap\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"c2b58189-e3c6-4652-bacc-2add92a9f052\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"ScaleVector2(x=5,y=5)\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                },\r\n                {\r\n                    \"name\": \"MoveMapCursor\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"02a40034-40cc-425b-9bb0-a690658a6e5d\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"ScaleVector2(x=5,y=5)\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                },\r\n                {\r\n                    \"name\": \"ScrollRectRoll\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"03ffdcf5-2e50-44a1-9dcc-90ecd66519c9\",\r\n                    \"expectedControlType\": \"Axis\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                },\r\n                {\r\n                    \"name\": \"SelectTrait\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"88a61a0b-7ae3-4f83-a8ff-0d963bacb324\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"UnEquipTrait\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"a6efb4e3-3bd3-4673-aff4-b0175c33ae70\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ShowFullName\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"894754cd-1f1e-49c1-a35a-e0f13b9d1f2b\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"PackageUse\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"e9668c27-7b7c-428a-a791-2753d8c1f38f\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"PackageBulkShop\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"0d6f067c-7b21-46d2-9e02-a05a460d226e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ConfirmEnhance\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"f25e5180-8675-41ea-ae5d-f1489e7262ac\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ConfirmAddTalent\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"d94567ae-7b48-4e3a-a60b-1d3ef22b9fea\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenTitleTraits\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"19ac66ba-aefc-4332-9ed8-74e67b9e62bc\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenAllTraits\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"19cd898e-0744-4fa9-b05d-eeaebab42268\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"QuickLearnWugong\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"3476a398-e034-40ce-97e2-d1173c10c5dc\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"DeleteWugong\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"2da2efb8-8db1-4e8f-a7c2-d572ceee289e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"PackageDetail\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"53b10b8a-c204-4b86-9ce5-a750cba87efb\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"PackageFilter\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"916fa27a-3737-4cd3-a2a5-770b4f373e5c\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ConfirmBattle\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"d69bcca9-918a-48d6-b5ca-3269f9fc8446\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"AtlasNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"4ebdf625-d0f8-44c3-9aaa-5d9151b33418\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"AtlasPrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"8dcbe096-c3e2-44cb-a602-c3e5b921e413\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ExpelFollower\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"b167c4fd-8d38-4383-8615-7094070b1ab8\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectDuelAlly\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"bed63412-2765-482a-9f99-a39dfa6800a5\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectDuelEnemy\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"91555ea4-86f8-48a5-824f-f8e34ac0c60d\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectWugongEffectNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"6d53d824-3c68-438a-a130-1bc4ea63d37d\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectWugongEffectPrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"dc4894b6-c128-41b6-bad0-090d0eebc5c9\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectSkinNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"96a81459-8cec-4ad7-912e-04a793e49fa6\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectSkinPrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"af9243d7-56ed-4ad3-843e-27cbb697db55\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ConfirmCreateWugong\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"1feacbc9-eb3a-4c09-87e0-31787549a4fe\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"BackCreateWugong\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"62070fb7-ad6e-4bbd-af02-b22bdf4d298a\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"AnyKey\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"bee29773-8b39-4b98-8ba7-4a57838cf9f8\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                }\r\n            ],\r\n            \"bindings\": [\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"de0d2478-6636-4380-9170-10a0121c083e\",\r\n                    \"path\": \"<Keyboard>/space\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"81b44668-c01f-4a79-9efb-16809a2fe381\",\r\n                    \"path\": \"<Keyboard>/enter\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"508fbe10-3df5-455b-bc47-10cd0c39a97f\",\r\n                    \"path\": \"<Gamepad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a92495bf-0c76-4027-bd3c-9bccc753ba68\",\r\n                    \"path\": \"<NPad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"72b6069f-d80c-4404-ab3e-9c7287a74803\",\r\n                    \"path\": \"<Keyboard>/escape\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Cancel\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e639b0e7-ef29-4ab1-ab97-28c8f6980ca5\",\r\n                    \"path\": \"<Gamepad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Cancel\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"1D Axis\",\r\n                    \"id\": \"073597bf-b7bc-4381-a912-a708f46437c6\",\r\n                    \"path\": \"1DAxis\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"AxisDeadzone(min=0.5,max=2)\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"cb0302a4-9b45-4098-be58-930f52714c5b\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"32fec61f-9214-48ce-9449-a714d0dc4c9d\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"5fbe3a7b-1cb1-4d4d-a4c3-2037fd3bda96\",\r\n                    \"path\": \"<Keyboard>/leftArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"b885742a-53fa-460c-a792-f17c38a5da96\",\r\n                    \"path\": \"<Keyboard>/rightArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"c2666411-6baa-43e8-b52e-6b706faac3ec\",\r\n                    \"path\": \"<Gamepad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"e6d25111-9f28-45d4-b821-4349fa831b89\",\r\n                    \"path\": \"<Gamepad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"f39d08a1-2443-4989-80ec-e3a6765dd1cf\",\r\n                    \"path\": \"<NPad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"7228a8b8-cf7f-4453-aac0-204c1b8f3a67\",\r\n                    \"path\": \"<NPad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"cc694531-464c-4c0f-a3df-1a711f549147\",\r\n                    \"path\": \"<Keyboard>/alt\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ShouHoverItem\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c87edd7c-beb7-4c60-8294-3501e62319a5\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ShouHoverItem\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"414122e2-7f4b-40af-92b9-823421cc51e2\",\r\n                    \"path\": \"<NPad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ShouHoverItem\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"201dbcc9-fc0e-46a4-b2d7-4a8c88565a32\",\r\n                    \"path\": \"<Keyboard>/tab\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"CheatInput\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fe22b714-7962-4e52-b2f1-47b28d4e8cb8\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"CheatInput\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a5defd8b-e89e-4c23-8792-9d20efbecbe2\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"CheatInput\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"32e962b1-35c1-48a3-818a-25f5b2631083\",\r\n                    \"path\": \"<Keyboard>/c\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenStatusMain\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3de21c3a-40c6-4141-828a-039f91127d5f\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenStatusMain\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e98b294e-243b-4a90-9177-386b84f34571\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenStatusMain\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8d62916f-834c-4f1a-86c4-558348bd4b47\",\r\n                    \"path\": \"<Keyboard>/l\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenLogView\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"16564b4b-bda4-4552-8408-329307c42993\",\r\n                    \"path\": \"<Keyboard>/m\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenMapView\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0a1b02d0-4323-4e52-827a-4eaf4bb93558\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenMapView\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0b29667b-918b-479f-a0cf-5aeaaec80f2c\",\r\n                    \"path\": \"<NPad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenMapView\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"688f1406-849b-42f4-81d8-fbbd67795ceb\",\r\n                    \"path\": \"<Keyboard>/escape\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenSystemMenu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c0cbde68-2caf-4ff5-8f01-a8f3c0fa01dc\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenSystemMenu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0dba0555-319b-48ac-b619-7150c4f45c56\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenSystemMenu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"2cf66206-581e-4113-8ee3-575a2c093d85\",\r\n                    \"path\": \"<Mouse>/rightButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenSystemMenu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"1D Axis\",\r\n                    \"id\": \"d2bb4e93-a637-4147-a233-4d4581c6717b\",\r\n                    \"path\": \"1DAxis\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"1800280e-1030-4f52-bd35-8eec6cc9cdd6\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"f7f33e4c-6e05-4a55-9d0d-1b0b00287c85\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"cbcbaefe-ea70-443c-9074-9fa45d93ca86\",\r\n                    \"path\": \"<Mouse>/scroll/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"54f23678-5881-4a54-8e48-cf774b5edf7d\",\r\n                    \"path\": \"<Mouse>/scroll/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"37f653ea-cd60-4526-a889-25f231e73f31\",\r\n                    \"path\": \"<Gamepad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"58fa04a7-f8dc-4a0a-9570-404c8204bb59\",\r\n                    \"path\": \"<Gamepad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"be56219f-a317-4ff1-b2a8-651ca8207f2d\",\r\n                    \"path\": \"<NPad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"e33d6caa-be58-4159-8c32-2d13fadcb889\",\r\n                    \"path\": \"<NPad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ZoomMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"WASD\",\r\n                    \"id\": \"72ccc92f-68cd-4134-90d8-af07440adc5a\",\r\n                    \"path\": \"Dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"d7a69489-3292-4a17-8446-b088a530d9f8\",\r\n                    \"path\": \"<Keyboard>/w\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"5492bf67-63fd-4574-807d-8fb33d7caf87\",\r\n                    \"path\": \"<Keyboard>/s\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"5ee729e8-ffb0-4b05-9ee6-4190ad7b0b6a\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"6a5f9286-229e-416c-8f8e-a717ce3b3e57\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"dfbdba24-cbf1-429a-82f7-a6fa05dfd7fa\",\r\n                    \"path\": \"<Gamepad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7fb06866-b443-4380-b418-a582e504a966\",\r\n                    \"path\": \"<NPad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"MoveMap\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ac863daf-a6b7-422e-8ccc-f80260cd012b\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenLogView\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fac9b97f-f2d6-4882-8a2c-8f46c184821f\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenLogView\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"1D Axis\",\r\n                    \"id\": \"55d24a1c-87b3-4fe1-8746-e7eaf613fedb\",\r\n                    \"path\": \"1DAxis\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"36a1d053-fde9-426c-8d30-5981b7c9f9f7\",\r\n                    \"path\": \"<Keyboard>/w\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"f6f9066b-0217-4cbc-bf9a-095f8f560832\",\r\n                    \"path\": \"<Keyboard>/s\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"5571eab3-6453-4974-8ae2-02b5f0eaf406\",\r\n                    \"path\": \"<Keyboard>/upArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"a4f83ba0-1b9b-429c-8d95-be7b97436cd8\",\r\n                    \"path\": \"<Keyboard>/downArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"4f272dd5-82e4-4a5d-b502-1c1d680ae610\",\r\n                    \"path\": \"<Gamepad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"42cd77e9-2a9d-44d4-8aec-6834d6bebdfd\",\r\n                    \"path\": \"<Gamepad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"negative\",\r\n                    \"id\": \"5079b57a-f524-4c46-b57e-4a8f1aa4fedc\",\r\n                    \"path\": \"<NPad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"positive\",\r\n                    \"id\": \"a4d9153c-b320-43af-9e35-358d90047ceb\",\r\n                    \"path\": \"<NPad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ScrollRectRoll\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"32c7d575-61d1-4aa8-8ef8-b22c85cc48b6\",\r\n                    \"path\": \"<Keyboard>/l\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"LearnWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"eff9d6bc-311c-4bea-92eb-b518f31bda55\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"LearnWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d1414b01-a1de-4be3-9cf1-0523942e077a\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"LearnWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4300be72-03a1-4b00-be6b-51775a860ca4\",\r\n                    \"path\": \"<Keyboard>/f5\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Rename\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"f8c862c2-6673-4b00-b8a1-1b9c91d2a8f3\",\r\n                    \"path\": \"<Gamepad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Rename\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7edbf90f-939f-4c39-8c80-6cf2aa952d96\",\r\n                    \"path\": \"<NPad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Rename\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e94bc671-a31e-44f7-a68f-fe3e0e9aa8d2\",\r\n                    \"path\": \"<Keyboard>/space\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"JumpAnimation\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3c28b5f7-92cd-4943-be43-de3a2c7e39e4\",\r\n                    \"path\": \"<Gamepad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"JumpAnimation\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1b34c906-6b8f-42fc-8535-86f9688bb416\",\r\n                    \"path\": \"<Keyboard>/o\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectMenuNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"5530b81a-b1ca-4e17-94de-14756b4f87eb\",\r\n                    \"path\": \"<Gamepad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectMenuNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"22fdc756-1791-4902-b6de-d6f9b1da88bd\",\r\n                    \"path\": \"<NPad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectMenuNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"79a1461c-5678-4602-8683-5edd9b3b9091\",\r\n                    \"path\": \"<Keyboard>/u\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectMenuPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8eaab891-d146-4e62-83f6-a459d6c285f4\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectMenuPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4bf5e264-52a3-4d75-9420-95032ee92782\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectMenuPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8209ab71-4fa7-4ac7-8ba1-d329a9ea9016\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectCharacterNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"903cc6ee-d109-400b-ab6c-de54e9e4b492\",\r\n                    \"path\": \"<Gamepad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectCharacterNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a00725ef-6423-4845-aa1d-e814bc8e475d\",\r\n                    \"path\": \"<NPad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectCharacterNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"26da6ae2-bca7-4250-bcdd-c726ea9652a5\",\r\n                    \"path\": \"<Keyboard>/r\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"RoolTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e7114fb5-3c41-4d0c-b8df-cad7675ab5d0\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"RoolTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"94705fe7-f59f-47ec-9fa2-b471ea43d935\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"RoolTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a55bc11b-f8f8-4476-8a82-8f71de2dbcdb\",\r\n                    \"path\": \"<Keyboard>/c\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"CustomTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a250bc1c-b2d2-4e3b-a337-72e581b76b7c\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"CustomTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"edf14f8d-ed22-440a-90b7-625e9b6aa7b1\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"CustomTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e1a196af-4610-4586-ba18-a566ee1c5f7f\",\r\n                    \"path\": \"<Keyboard>/f\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ShowFullName\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b9533f38-1820-4597-a928-3045141d8951\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ShowFullName\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b99c8f57-266c-4b69-8993-b38af7903fa2\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ShowFullName\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"64fd2932-dff1-4602-aafe-cbcc2f228d86\",\r\n                    \"path\": \"<Keyboard>/f5\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PackageFilter\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"f0e4f346-e803-422a-b0a4-4b6876726d60\",\r\n                    \"path\": \"<Gamepad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"PackageFilter\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6757a639-11fa-46ef-87ea-7482ff290679\",\r\n                    \"path\": \"<NPad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PackageFilter\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"Keyboard\",\r\n                    \"id\": \"492b9623-0c61-40cc-9dfe-a8f1949f772f\",\r\n                    \"path\": \"2DVector\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"7a4d8364-09af-4e8b-9da9-c310c65c1e44\",\r\n                    \"path\": \"<Keyboard>/upArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"0fafdfd9-9e4f-4f52-a3e2-a1ecbdb39564\",\r\n                    \"path\": \"<Keyboard>/downArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"58420575-e2dc-4ba1-a46a-b2b2a356f6a0\",\r\n                    \"path\": \"<Keyboard>/leftArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"46d4a3cf-b528-44a6-976f-fcd05310796e\",\r\n                    \"path\": \"<Keyboard>/rightArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"56768d08-13c5-4724-abd4-a6e683fa194e\",\r\n                    \"path\": \"<Gamepad>/rightStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c0fbce01-e65e-4374-8693-a39aa34f5466\",\r\n                    \"path\": \"<NPad>/rightStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"MoveMapCursor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"df6f768f-0721-4537-8a1e-752a8cc9fb59\",\r\n                    \"path\": \"<NPad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Cancel\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"824c5604-1300-4185-b774-a8a14cc2dae9\",\r\n                    \"path\": \"<NPad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"JumpAnimation\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e8c160e4-5572-4198-b97f-792807ea73ea\",\r\n                    \"path\": \"<Keyboard>/enter\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"JumpAnimation\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ea9e14b6-84fd-4df3-8f96-099c04e29f0b\",\r\n                    \"path\": \"<Keyboard>/l\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"LockAttr\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1f38a745-b4ff-45cd-8e6c-b6b912808c18\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectTrait\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9f2d002c-e99d-4889-bfe3-a1ab3416be96\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectTrait\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c49b7477-e0c4-46d0-b15c-0fd56549cf2d\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectTrait\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"abb4c2fd-aa46-41eb-a0e3-d2da9d688140\",\r\n                    \"path\": \"<Keyboard>/alt\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"UnEquipTrait\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"2b4e7fc5-ae42-4176-bcf8-cd88c3da3437\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"UnEquipTrait\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d565d0f9-2b3f-4262-ab10-38f4e19d203c\",\r\n                    \"path\": \"<NPad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"UnEquipTrait\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b187d0d1-b39e-462f-96ec-c1dcbb18cba1\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PackageUse\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fe4ce30b-7693-4751-8e21-37cd837fe46e\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"PackageUse\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4da93996-96bf-4f23-a046-2eb363811589\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PackageUse\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6ce70dbe-f2fb-415e-8f84-770ac9cd80d2\",\r\n                    \"path\": \"<Keyboard>/alt\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PackageDetail\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"24d4a666-0605-4fc3-9e3e-a383686582ce\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"PackageDetail\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8a42db7c-65a7-4040-8a4c-c27766652946\",\r\n                    \"path\": \"<NPad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PackageDetail\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3f56e8d4-24d1-41bd-94fd-becf1d6576c5\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ConfirmBattle\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c4447fee-376b-4ad0-82da-348516b07e5f\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ConfirmBattle\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ea005051-25b3-4616-8258-6692fa7eae3d\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ConfirmBattle\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ffdd8cdd-4d8d-4745-a707-6669294407e5\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectCharacterPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a595d783-1871-4198-8741-8231bfc9839e\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectCharacterPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8e136771-2822-4a74-87bf-8023b59d9664\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectCharacterPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"26b23659-9c21-4774-9a84-aa80d9bdbb1b\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"AtlasNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6af3c44c-2fda-4b7c-b453-28c1e845afe6\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"AtlasNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"040bdc93-0a17-4ff4-9fca-760934a1f0aa\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"AtlasNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"54bf516d-e86b-44fc-9e26-2e0bc2524b8f\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"AtlasPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"23791b99-571a-48b7-9921-4d5bf6396d47\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"AtlasPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6845a575-bfa6-4278-ac74-437799859f80\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"AtlasPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6c39bf9e-183b-4761-bd96-40b852a745e4\",\r\n                    \"path\": \"<Keyboard>/g\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenAtlas\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ec169983-e876-44d3-b34c-98b94e000efe\",\r\n                    \"path\": \"<Gamepad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenAtlas\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3df0659f-a828-412d-9ccd-8196b765e6b5\",\r\n                    \"path\": \"<NPad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenAtlas\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"bb72b2fc-4e11-4e84-a9b1-783ab04c7cc5\",\r\n                    \"path\": \"<Keyboard>/h\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenJourney\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"5bc73182-b7c9-4419-8a0f-0abc2b5bd997\",\r\n                    \"path\": \"<Gamepad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenJourney\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d3cee368-d36d-4403-a07b-846972fe5f94\",\r\n                    \"path\": \"<NPad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenJourney\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9fa3bc01-9ef6-4917-bb6d-43b04cf18cc0\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"LockAttr\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d678b0f9-f96f-40b2-8174-fff018841e12\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"LockAttr\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"5f609865-e2b8-47fd-bc98-5d447729f682\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ExpelFollower\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fad3d4a4-e4be-496b-a935-0ccd1cf0a12a\",\r\n                    \"path\": \"<Gamepad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ExpelFollower\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e493f87d-1b7e-4372-84e3-ac2070c70af9\",\r\n                    \"path\": \"<NPad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ExpelFollower\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"57c93559-4c3f-431c-affb-91565bdf5e98\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectDuelEnemy\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"75a4ee7c-260c-4668-afe6-1043410affc3\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectDuelEnemy\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0c923637-4f1c-4f00-b5cd-4a2b429e9b35\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectDuelEnemy\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9688147d-0c65-461b-b464-773c4f735cfd\",\r\n                    \"path\": \"<Keyboard>/u\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectDuelAlly\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"080c3bb9-c419-4206-b5be-9a646415ca19\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectDuelAlly\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"faafefb9-0fb5-4fb4-a64d-5b1a66d6e3bb\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectDuelAlly\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"2301063e-ef89-4008-8055-47342c2a259f\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectWugongEffectPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"34087047-8cae-403f-a008-0a2079beeff4\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectWugongEffectPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c82f4cfd-4fd6-474b-bc07-4d07f152b8ad\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectWugongEffectPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7e3cb914-fcce-4d58-bd15-0f7d5f6c9341\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectWugongEffectNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"64defafb-82f4-466a-9dbf-af5ea2ce4521\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectWugongEffectNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9df64450-91b3-410b-ae70-8c27d294e669\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectWugongEffectNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d66d5deb-7c8a-4a6e-9e67-c6e9db8a63af\",\r\n                    \"path\": \"<Keyboard>/alt\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"BackCreateWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"15af7aee-bb9f-44dc-a262-4f3c488192bc\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"BackCreateWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"37d18587-21a9-4535-ae2d-48f1b838f504\",\r\n                    \"path\": \"<NPad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"BackCreateWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7815bab6-9cad-47bf-989a-9d3f4c3d5ab7\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ConfirmCreateWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1451e52b-13f3-4e83-971a-a4deee5c8e0c\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ConfirmCreateWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"eac6d475-da37-489a-a804-9e783a7075ee\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ConfirmCreateWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"babcebdf-4c4f-48d2-9f75-975711658c90\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectSkinNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1b4c8a1e-a24d-4f65-84ce-b261dad2c5b7\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectSkinNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"44e1dfe1-03c0-41ed-9056-82ec7a744cfb\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectSkinNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"dc38c78e-9106-4e0b-97fb-670eed6f21e3\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectSkinPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"60f852ed-8b53-4fec-8673-97e12c070605\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectSkinPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"40424bff-1366-4a23-9672-73ba58e8bbfe\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectSkinPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fd221d13-b810-4fb9-9136-ce19ef925d76\",\r\n                    \"path\": \"*/<Button>\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse;GamePad;OnSwitch\",\r\n                    \"action\": \"AnyKey\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1701b169-c7cb-4024-9c1b-bfcd3759e821\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ConfirmAddTalent\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3e694a7b-21cc-41d0-9313-004f9a7d5b77\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ConfirmAddTalent\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c4aa5e94-9757-41de-b7f3-069cff0678c4\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ConfirmAddTalent\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1f9ea222-8294-4d86-a0f7-06907724ac8b\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenTitleTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"833c557e-1ba8-4a77-8147-f948fe958433\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenTitleTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"095cc02d-fbc8-4692-8ec3-65d20f2bdd20\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenTitleTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1628e0f5-ad3a-4a10-8f7a-f154c9598166\",\r\n                    \"path\": \"<Keyboard>/n\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenAllTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a05cb22f-2387-4722-9e07-5a40b10c5a31\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenAllTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"53a79cf9-4b17-4d24-95e5-ac5f2f92ad52\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenAllTraits\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"2c5ab470-91af-4c33-993b-3b4d13e3c55c\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Starter3Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"f22f5924-d395-4438-b68d-711b9ff0c2f7\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Starter3Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"abec1254-c99d-4565-906c-af377ba51726\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Starter3Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8e60dcfd-131d-47ff-b6dd-333c68338d05\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"QuickLearnWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"39b7bef6-dc6c-45c9-af80-e6fbfa992f92\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"QuickLearnWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1ba427ff-4ad0-4bbe-b75c-737ad419129c\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"QuickLearnWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7c9e0381-16ef-4de9-acf5-d849991bd673\",\r\n                    \"path\": \"<Keyboard>/f5\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"QuickOpenLoadManual\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"21f3f44c-581c-43b0-8011-f81f67fdc8da\",\r\n                    \"path\": \"<Gamepad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"QuickOpenLoadManual\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"32127957-cb9b-4174-98e8-4c955974d30f\",\r\n                    \"path\": \"<NPad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"QuickOpenLoadManual\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"dd4c8655-377c-44c2-867b-2ea29bfb89e7\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Starter1_1Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"83bcc1f3-9781-41f1-b033-751677b343dc\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Starter1_1Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4be7f75e-89f0-46a1-9dd6-d7801ff870be\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Starter1_1Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c6856ce4-e6dc-4009-a6f3-41aa419e9f4d\",\r\n                    \"path\": \"<Gamepad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;GamePad\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"f0d223db-edf7-4855-b164-d3c7a7c0ebb0\",\r\n                    \"path\": \"<NPad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ManualChangePage\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"057e16fb-2c00-4416-aeeb-8064e5e9b898\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualSaveBtn\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0c3fc3c6-0269-4327-9721-86bdc867a05b\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ManualSaveBtn\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"37d4ee91-6325-4726-91c2-aaca38b77c91\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ManualSaveBtn\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8d4a1ae9-1dc2-409d-bad6-96e9d366aadf\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"AutoSaveBtn\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"96da6125-73cf-4528-a8a1-9f9251206045\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"AutoSaveBtn\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"65f5c64e-33ef-4db3-8974-51eeaee54c0b\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"AutoSaveBtn\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"2e79392f-3ef5-4341-8ec2-7f8027c7b00a\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ConfirmEnhance\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"426fa424-3494-4421-9d63-92c902615172\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ConfirmEnhance\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8cd29f84-5284-44b1-8434-3ebf2959f65c\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ConfirmEnhance\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"419e6906-45a0-4cdf-a476-6e22a725854e\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ZoomMapUp\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"2b986169-400e-425c-b633-f0ef1ed46917\",\r\n                    \"path\": \"<Gamepad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ZoomMapUp\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6745e916-b0c2-4c92-a341-0d272baa8019\",\r\n                    \"path\": \"<NPad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ZoomMapUp\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"25375225-c8fd-41ba-b6de-25752ca5aadb\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ZoomMapDown\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"067c93c9-6409-447d-a17a-d962d0a4bcac\",\r\n                    \"path\": \"<Gamepad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ZoomMapDown\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"731201e2-c923-43c7-8f55-3521472e34b9\",\r\n                    \"path\": \"<NPad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ZoomMapDown\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3df81e55-2d63-49da-9f40-a83da62b5281\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualChangePageNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ba303d83-5f76-4cfe-a30a-8c4cb2280235\",\r\n                    \"path\": \"<Gamepad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ManualChangePageNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"eec2928a-59de-43e2-af1b-5273f9b541ea\",\r\n                    \"path\": \"<NPad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ManualChangePageNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"90ea55e7-5a39-402a-9baa-39cb1e4549e3\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ManualChangePagePrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d816207a-fed0-4cc2-adf3-2bbb7329f6c1\",\r\n                    \"path\": \"<Gamepad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ManualChangePagePrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"399b1a34-2d79-45c7-a300-e9bba607749a\",\r\n                    \"path\": \"<NPad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ManualChangePagePrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"401acba4-b25d-4272-bba8-ae99b6f92674\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"DeleteWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"99001462-7f5e-40e6-bf37-6fd674b041b4\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"DeleteWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a4accb7c-0a4b-4ba4-adb9-518328e9cb2f\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"DeleteWugong\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"93eb0696-dcb4-4ea4-b7fc-965744938b9b\",\r\n                    \"path\": \"<Keyboard>/b\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PackageBulkShop\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9a086da2-9f20-47f5-b45a-f554b284207a\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"PackageBulkShop\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"715a1fcb-464e-436a-b26a-3005e78f711c\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PackageBulkShop\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"Player\",\r\n            \"id\": \"001fc653-ffe3-45df-821f-ba999a97624a\",\r\n            \"actions\": [\r\n                {\r\n                    \"name\": \"PlayerMove\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"fbd908af-e96f-48b3-b42a-c1def9794c80\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"StickDeadzone(min=0.225)\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                },\r\n                {\r\n                    \"name\": \"ShowCharacterInfo\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"2956067e-a69e-41a1-959b-b8204f5c165a\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ReturnTitleShortCut\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"49866c22-fd44-4d1a-80e6-08b70b5cf0c5\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"AutoBattle\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"9389ae84-f210-4613-be40-b340af0d3285\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"AttackShortCut\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"a1960980-2b8a-498b-aed1-24847491c7ca\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"OpenPackageShortCut\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"fd88d246-76ac-4c1e-9312-d1d3cbfce339\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"RestShortCut\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"39349ffa-67f3-452f-8a22-f7269a58c6e4\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"EscapeShortCut\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"3cf98faa-a5e1-45ec-be44-beb9058fc831\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectCharacterNext\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"172d4464-dd6e-4268-9b25-1f19937fcaa8\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"SelectCharacterPrev\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"97ea8ee8-ece3-48a4-92ed-7f446418245e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"Confirm\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"0c1e6ad9-5d78-4fb5-a793-113c43319bed\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"Cancel\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"f9d05a0a-f29f-48c9-9747-a4d2f835d745\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"ShowHp\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"5d11797d-0b79-4316-ba16-b8c8dd5097fc\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false\r\n                },\r\n                {\r\n                    \"name\": \"BattleCurcorMove\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"ffdeee03-5209-4342-9ea0-ddef0bca9b50\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true\r\n                }\r\n            ],\r\n            \"bindings\": [\r\n                {\r\n                    \"name\": \"WASD\",\r\n                    \"id\": \"67b42cf1-e1ae-427c-b4c2-1de73f0787ec\",\r\n                    \"path\": \"Dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"24ca5bb9-d351-42d5-815a-9786980191ad\",\r\n                    \"path\": \"<Keyboard>/w\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"711f91c3-5652-41c1-bc18-5ea1d771337a\",\r\n                    \"path\": \"<Keyboard>/upArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"ad17c9b3-86fe-4da6-b6b5-135d334d4072\",\r\n                    \"path\": \"<Keyboard>/s\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"63e767b0-d35e-4da6-a963-44a84cb9a0b9\",\r\n                    \"path\": \"<Keyboard>/downArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"7c78f8b4-1666-45f4-829d-83df7099bf64\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"266c29f3-1c5d-4839-b2a3-4cdc56c24f85\",\r\n                    \"path\": \"<Keyboard>/leftArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"15ac8b99-c761-478f-92f5-d47e374e1012\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"ff906603-a191-46ff-8795-aee57c15f3b6\",\r\n                    \"path\": \"<Keyboard>/rightArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8809a60b-ce6f-45ca-bbad-a0b7773c5b33\",\r\n                    \"path\": \"<Gamepad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;GamePad\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e2468770-825f-472d-9339-0fe1ebaf1acc\",\r\n                    \"path\": \"<NPad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"5b1b606e-e7b3-4e90-b631-14210cc52005\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectCharacterPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"43c56e25-4df3-4815-830c-93ce402ced69\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"SelectCharacterNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7f9e344f-e1c7-4c63-9387-a2652f01e0f4\",\r\n                    \"path\": \"<Keyboard>/tab\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ShowHp\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0390ef33-1c13-4ae5-8bc2-d61c41b75400\",\r\n                    \"path\": \"<Gamepad>/leftStickPress\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ShowHp\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9c3ccf32-67cf-4494-b796-ac70c1b231e5\",\r\n                    \"path\": \"<NPad>/leftStickPress\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ShowHp\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"a99889b7-7f38-477a-ae14-c9fdf229526b\",\r\n                    \"path\": \"<Keyboard>/v\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"AttackShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"afb931dc-1791-4cc6-9a44-e88baeb996a1\",\r\n                    \"path\": \"<Gamepad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"AttackShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"876a8dda-8502-449b-9bdf-bcfcfe86bd2e\",\r\n                    \"path\": \"<NPad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"AttackShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"da21c142-91d2-4a23-b2d4-a94e4b07ab84\",\r\n                    \"path\": \"<Keyboard>/b\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"OpenPackageShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"feefb4b9-e063-4ef7-8f5b-b3e7e46ce46d\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"OpenPackageShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"58b6e462-ca2f-4b9b-a4cb-1167ccd893d1\",\r\n                    \"path\": \"<NPad>/buttonNorth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"OpenPackageShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d1d323f5-2942-40f4-a88f-3ff876933fa9\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectCharacterNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"06ee1c77-8b84-4db9-b228-956cc6ec806d\",\r\n                    \"path\": \"<NPad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectCharacterNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"65acf18b-8727-4913-a4ae-b8a22277c07a\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"SelectCharacterPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c2bdec49-5926-4835-aa6f-473d8fff75b5\",\r\n                    \"path\": \"<NPad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"SelectCharacterPrev\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"Keyboard\",\r\n                    \"id\": \"a6171ae5-c801-43ab-bae6-faaa3a87708d\",\r\n                    \"path\": \"2DVector\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"a2c6fbde-8b6c-4602-8d12-99b4c1012cd9\",\r\n                    \"path\": \"<Keyboard>/w\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"9158dfb5-4348-4f19-b4dd-0fa0be245a0b\",\r\n                    \"path\": \"<Keyboard>/s\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"bc61c222-0024-47af-ba94-f9b2d86006ac\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"e915fa23-273c-4744-b7bb-43689e067b9e\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"f27222e9-1e9b-4d3d-848b-fab51b18a257\",\r\n                    \"path\": \"<Gamepad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;GamePad\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"166aa8e6-7942-4926-bbb0-3203817f8ea7\",\r\n                    \"path\": \"<NPad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3bce4918-7c1d-464e-a59a-2fb726ccd9d7\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"AutoBattle\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fcd4bfa6-4615-4fb7-9c71-5fcd0ee618b6\",\r\n                    \"path\": \"<Gamepad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"AutoBattle\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"11a49e51-47d0-4db7-91ed-a6c0cf462ded\",\r\n                    \"path\": \"<NPad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"AutoBattle\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d2a44e54-4c98-41da-b25b-4db9f0d4645a\",\r\n                    \"path\": \"<Keyboard>/escape\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ReturnTitleShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"914aebc2-25f5-4ac0-aefa-df3d9ac9f867\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ReturnTitleShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"29a3635e-e28c-406d-9fab-e62cec4ad539\",\r\n                    \"path\": \"<NPad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ReturnTitleShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d103dcd1-27c9-47eb-8753-31989fe75381\",\r\n                    \"path\": \"<Keyboard>/r\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"EscapeShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8e55b3c0-c251-4ff9-942f-6df20bd54783\",\r\n                    \"path\": \"<Gamepad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"EscapeShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c30d88cd-1b62-4d65-ac01-56e2f2271655\",\r\n                    \"path\": \"<NPad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"EscapeShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"71cb47f2-a868-4db0-ba59-4d727bdc6cbc\",\r\n                    \"path\": \"<Keyboard>/z\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"RestShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"aaf3ad0f-3249-4f02-8afa-cb60774cd215\",\r\n                    \"path\": \"<Gamepad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"RestShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d120dac1-03ce-4536-8814-1d34215ac8fa\",\r\n                    \"path\": \"<NPad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"RestShortCut\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"002f8a44-d57e-4332-b570-0c44477c325c\",\r\n                    \"path\": \"<Keyboard>/alt\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"ShowCharacterInfo\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4b68d8b1-cb9e-43a8-8a1e-35f9bcbeac3a\",\r\n                    \"path\": \"<Gamepad>/rightStickPress\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"ShowCharacterInfo\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b89fd98c-ea8a-4997-8cea-1f93c8452d46\",\r\n                    \"path\": \"<NPad>/rightStickPress\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"ShowCharacterInfo\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3caff798-5c9c-415f-b72e-28b8a2153408\",\r\n                    \"path\": \"<Keyboard>/space\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e767d38d-7507-4146-a654-a5f75a3200ee\",\r\n                    \"path\": \"<Keyboard>/enter\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"45bf83a9-3e96-420f-91fd-6cd05e2832a9\",\r\n                    \"path\": \"<Gamepad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1136cfe9-13c8-4ad2-bcae-de67cc493d99\",\r\n                    \"path\": \"<NPad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Confirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3dcf2a27-91d7-4c4a-aec9-60eb46011909\",\r\n                    \"path\": \"<Keyboard>/escape\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"KeyboardAndMouse\",\r\n                    \"action\": \"Cancel\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"580d3a89-79f5-4b69-bd90-b4975e80f87f\",\r\n                    \"path\": \"<Gamepad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"GamePad\",\r\n                    \"action\": \"Cancel\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8ae15fa7-f543-4c68-b1a5-9981065a74a7\",\r\n                    \"path\": \"<NPad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"Cancel\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"2D Vector\",\r\n                    \"id\": \"e5d875d6-fa29-453a-a395-01459ae10908\",\r\n                    \"path\": \"2DVector\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"Up\",\r\n                    \"id\": \"222f1437-dbde-4ac8-adfd-2c98cf82d48e\",\r\n                    \"path\": \"<NPad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Down\",\r\n                    \"id\": \"de964712-f95e-4936-b257-0e3651fbd9f4\",\r\n                    \"path\": \"<NPad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Left\",\r\n                    \"id\": \"eb842da9-ec14-4ba4-a207-fd1f645004ac\",\r\n                    \"path\": \"<NPad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Right\",\r\n                    \"id\": \"0ff36fba-9cbe-4cf1-bb25-2796e7915bde\",\r\n                    \"path\": \"<NPad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e686099c-b987-4030-a0b2-95d23ef56c89\",\r\n                    \"path\": \"<Gamepad>/dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;GamePad\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"97dcc482-54b5-4bd5-86b8-a4c5a0b9a5be\",\r\n                    \"path\": \"<NPad>/dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;OnSwitch\",\r\n                    \"action\": \"PlayerMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"2D Vector\",\r\n                    \"id\": \"4c256368-b2a7-4cdb-95bb-9b20c540192c\",\r\n                    \"path\": \"2DVector\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"Up\",\r\n                    \"id\": \"fcc9bd5b-f31f-4401-980e-7af88601134e\",\r\n                    \"path\": \"<NPad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Down\",\r\n                    \"id\": \"a9ec292b-96d6-44da-9584-08003099839d\",\r\n                    \"path\": \"<NPad>/dpad/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Left\",\r\n                    \"id\": \"fff51f82-7158-4370-8b84-63f1e9e8464e\",\r\n                    \"path\": \"<NPad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Right\",\r\n                    \"id\": \"e8dd9601-a141-466d-9b02-88dfbbfebc56\",\r\n                    \"path\": \"<NPad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"OnSwitch\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"76bf9580-0fde-4bfe-ac73-ca7d12c7b497\",\r\n                    \"path\": \"<Gamepad>/dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;GamePad\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"46cc27bf-ea9a-4e43-a499-a8872acbc6c1\",\r\n                    \"path\": \"<NPad>/dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad;OnSwitch\",\r\n                    \"action\": \"BattleCurcorMove\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                }\r\n            ]\r\n        }\r\n    ],\r\n    \"controlSchemes\": [\r\n        {\r\n            \"name\": \"KeyboardAndMouse\",\r\n            \"bindingGroup\": \"KeyboardAndMouse\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<Keyboard>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                },\r\n                {\r\n                    \"devicePath\": \"<Mouse>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"GamePad\",\r\n            \"bindingGroup\": \"GamePad\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<Gamepad>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"OnSwitch\",\r\n            \"bindingGroup\": \"OnSwitch\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<NPad>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        }\r\n    ]\r\n}");
		m_UI = asset.FindActionMap("UI", throwIfNotFound: true);
		m_UI_Confirm = m_UI.FindAction("Confirm", throwIfNotFound: true);
		m_UI_Cancel = m_UI.FindAction("Cancel", throwIfNotFound: true);
		m_UI_JumpAnimation = m_UI.FindAction("JumpAnimation", throwIfNotFound: true);
		m_UI_ManualChangePage = m_UI.FindAction("ManualChangePage", throwIfNotFound: true);
		m_UI_ManualChangePageNext = m_UI.FindAction("ManualChangePageNext", throwIfNotFound: true);
		m_UI_ManualChangePagePrev = m_UI.FindAction("ManualChangePagePrev", throwIfNotFound: true);
		m_UI_RoolTraits = m_UI.FindAction("RoolTraits", throwIfNotFound: true);
		m_UI_LockAttr = m_UI.FindAction("LockAttr", throwIfNotFound: true);
		m_UI_CustomTraits = m_UI.FindAction("CustomTraits", throwIfNotFound: true);
		m_UI_Rename = m_UI.FindAction("Rename", throwIfNotFound: true);
		m_UI_Starter3Confirm = m_UI.FindAction("Starter3Confirm", throwIfNotFound: true);
		m_UI_Starter1_1Confirm = m_UI.FindAction("Starter1_1Confirm", throwIfNotFound: true);
		m_UI_ShouHoverItem = m_UI.FindAction("ShouHoverItem", throwIfNotFound: true);
		m_UI_AutoSaveBtn = m_UI.FindAction("AutoSaveBtn", throwIfNotFound: true);
		m_UI_ManualSaveBtn = m_UI.FindAction("ManualSaveBtn", throwIfNotFound: true);
		m_UI_LearnWugong = m_UI.FindAction("LearnWugong", throwIfNotFound: true);
		m_UI_CheatInput = m_UI.FindAction("CheatInput", throwIfNotFound: true);
		m_UI_OpenStatusMain = m_UI.FindAction("OpenStatusMain", throwIfNotFound: true);
		m_UI_SelectCharacterPrev = m_UI.FindAction("SelectCharacterPrev", throwIfNotFound: true);
		m_UI_SelectCharacterNext = m_UI.FindAction("SelectCharacterNext", throwIfNotFound: true);
		m_UI_SelectMenuPrev = m_UI.FindAction("SelectMenuPrev", throwIfNotFound: true);
		m_UI_SelectMenuNext = m_UI.FindAction("SelectMenuNext", throwIfNotFound: true);
		m_UI_OpenLogView = m_UI.FindAction("OpenLogView", throwIfNotFound: true);
		m_UI_OpenAtlas = m_UI.FindAction("OpenAtlas", throwIfNotFound: true);
		m_UI_OpenJourney = m_UI.FindAction("OpenJourney", throwIfNotFound: true);
		m_UI_OpenMapView = m_UI.FindAction("OpenMapView", throwIfNotFound: true);
		m_UI_OpenSystemMenu = m_UI.FindAction("OpenSystemMenu", throwIfNotFound: true);
		m_UI_QuickOpenLoadManual = m_UI.FindAction("QuickOpenLoadManual", throwIfNotFound: true);
		m_UI_ZoomMap = m_UI.FindAction("ZoomMap", throwIfNotFound: true);
		m_UI_ZoomMapUp = m_UI.FindAction("ZoomMapUp", throwIfNotFound: true);
		m_UI_ZoomMapDown = m_UI.FindAction("ZoomMapDown", throwIfNotFound: true);
		m_UI_MoveMap = m_UI.FindAction("MoveMap", throwIfNotFound: true);
		m_UI_MoveMapCursor = m_UI.FindAction("MoveMapCursor", throwIfNotFound: true);
		m_UI_ScrollRectRoll = m_UI.FindAction("ScrollRectRoll", throwIfNotFound: true);
		m_UI_SelectTrait = m_UI.FindAction("SelectTrait", throwIfNotFound: true);
		m_UI_UnEquipTrait = m_UI.FindAction("UnEquipTrait", throwIfNotFound: true);
		m_UI_ShowFullName = m_UI.FindAction("ShowFullName", throwIfNotFound: true);
		m_UI_PackageUse = m_UI.FindAction("PackageUse", throwIfNotFound: true);
		m_UI_PackageBulkShop = m_UI.FindAction("PackageBulkShop", throwIfNotFound: true);
		m_UI_ConfirmEnhance = m_UI.FindAction("ConfirmEnhance", throwIfNotFound: true);
		m_UI_ConfirmAddTalent = m_UI.FindAction("ConfirmAddTalent", throwIfNotFound: true);
		m_UI_OpenTitleTraits = m_UI.FindAction("OpenTitleTraits", throwIfNotFound: true);
		m_UI_OpenAllTraits = m_UI.FindAction("OpenAllTraits", throwIfNotFound: true);
		m_UI_QuickLearnWugong = m_UI.FindAction("QuickLearnWugong", throwIfNotFound: true);
		m_UI_DeleteWugong = m_UI.FindAction("DeleteWugong", throwIfNotFound: true);
		m_UI_PackageDetail = m_UI.FindAction("PackageDetail", throwIfNotFound: true);
		m_UI_PackageFilter = m_UI.FindAction("PackageFilter", throwIfNotFound: true);
		m_UI_ConfirmBattle = m_UI.FindAction("ConfirmBattle", throwIfNotFound: true);
		m_UI_AtlasNext = m_UI.FindAction("AtlasNext", throwIfNotFound: true);
		m_UI_AtlasPrev = m_UI.FindAction("AtlasPrev", throwIfNotFound: true);
		m_UI_ExpelFollower = m_UI.FindAction("ExpelFollower", throwIfNotFound: true);
		m_UI_SelectDuelAlly = m_UI.FindAction("SelectDuelAlly", throwIfNotFound: true);
		m_UI_SelectDuelEnemy = m_UI.FindAction("SelectDuelEnemy", throwIfNotFound: true);
		m_UI_SelectWugongEffectNext = m_UI.FindAction("SelectWugongEffectNext", throwIfNotFound: true);
		m_UI_SelectWugongEffectPrev = m_UI.FindAction("SelectWugongEffectPrev", throwIfNotFound: true);
		m_UI_SelectSkinNext = m_UI.FindAction("SelectSkinNext", throwIfNotFound: true);
		m_UI_SelectSkinPrev = m_UI.FindAction("SelectSkinPrev", throwIfNotFound: true);
		m_UI_ConfirmCreateWugong = m_UI.FindAction("ConfirmCreateWugong", throwIfNotFound: true);
		m_UI_BackCreateWugong = m_UI.FindAction("BackCreateWugong", throwIfNotFound: true);
		m_UI_AnyKey = m_UI.FindAction("AnyKey", throwIfNotFound: true);
		m_Player = asset.FindActionMap("Player", throwIfNotFound: true);
		m_Player_PlayerMove = m_Player.FindAction("PlayerMove", throwIfNotFound: true);
		m_Player_ShowCharacterInfo = m_Player.FindAction("ShowCharacterInfo", throwIfNotFound: true);
		m_Player_ReturnTitleShortCut = m_Player.FindAction("ReturnTitleShortCut", throwIfNotFound: true);
		m_Player_AutoBattle = m_Player.FindAction("AutoBattle", throwIfNotFound: true);
		m_Player_AttackShortCut = m_Player.FindAction("AttackShortCut", throwIfNotFound: true);
		m_Player_OpenPackageShortCut = m_Player.FindAction("OpenPackageShortCut", throwIfNotFound: true);
		m_Player_RestShortCut = m_Player.FindAction("RestShortCut", throwIfNotFound: true);
		m_Player_EscapeShortCut = m_Player.FindAction("EscapeShortCut", throwIfNotFound: true);
		m_Player_SelectCharacterNext = m_Player.FindAction("SelectCharacterNext", throwIfNotFound: true);
		m_Player_SelectCharacterPrev = m_Player.FindAction("SelectCharacterPrev", throwIfNotFound: true);
		m_Player_Confirm = m_Player.FindAction("Confirm", throwIfNotFound: true);
		m_Player_Cancel = m_Player.FindAction("Cancel", throwIfNotFound: true);
		m_Player_ShowHp = m_Player.FindAction("ShowHp", throwIfNotFound: true);
		m_Player_BattleCurcorMove = m_Player.FindAction("BattleCurcorMove", throwIfNotFound: true);
	}

	public void Dispose()
	{
		UnityEngine.Object.Destroy(asset);
	}

	public bool Contains(InputAction action)
	{
		return asset.Contains(action);
	}

	public IEnumerator<InputAction> GetEnumerator()
	{
		return asset.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}

	public void Enable()
	{
		asset.Enable();
	}

	public void Disable()
	{
		asset.Disable();
	}

	public InputAction FindAction(string actionNameOrId, bool throwIfNotFound = false)
	{
		return asset.FindAction(actionNameOrId, throwIfNotFound);
	}

	public int FindBinding(InputBinding bindingMask, out InputAction action)
	{
		return asset.FindBinding(bindingMask, out action);
	}
}
