using System;
using UnityEngine;

[Serializable]
public class SkinDependence
{
	public string SkinSkeletonType = "";

	public TextAsset skeletonJson_top;

	public TextAsset atlasText_top;

	public Texture2D texture_top;

	public TextAsset skeletonJson_left;

	public TextAsset atlasText_left;

	public Texture2D texture_left;

	public TextAsset skeletonJson_back;

	public TextAsset atlasText_back;

	public Texture2D texture_back;
}
