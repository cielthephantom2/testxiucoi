using System.Collections.Generic;
using System.Xml.Serialization;

[XmlRoot("ConfigData")]
public class ConfigDataEA
{
	public List<string> saveDataList = new List<string>();

	public int lastSaveId = 1;

	public int playRound;

	public float masterVolume = -6f;

	public float musicVolume = -6f;

	public float seVolume = -6f;

	public int screenmode;

	public int resolution = 2;

	public string inheritItems = "";

	public string language = "";
}
