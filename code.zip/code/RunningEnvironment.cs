using System;
using Steamworks;

public static class RunningEnvironment
{
	public static bool isSteamDeck
	{
		get
		{
			try
			{
				if (SteamUtils.IsSteamRunningOnSteamDeck())
				{
					return true;
				}
				return false;
			}
			catch (Exception)
			{
				return false;
			}
		}
	}
}
