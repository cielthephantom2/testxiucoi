using System;
using System.Collections;
using System.Text.RegularExpressions;
using OpenCCNET;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

public static class CommonFunc
{
	public static float saturate(float _input)
	{
		if (_input > 1f)
		{
			return 1f;
		}
		if (_input < 0f)
		{
			return 0f;
		}
		return _input;
	}

	public static string ShortLangSel(string _str_def, string _str_en, string _str_tw = "")
	{
		string text = "";
		string language = GameDataManager.Instance().configdata.language;
		if (!(language == "English"))
		{
			if (language == "ChineseTraditional")
			{
				return (_str_tw == "") ? ZhConverter.HansToHant(_str_def) : _str_tw;
			}
			return _str_def;
		}
		return _str_en;
	}

	public static string I18nGetLocalizedValue(string _id)
	{
		gang_t01Table.Row row = CommonResourcesData.t01.Find_id(_id);
		if (row != null)
		{
			return row.str_Trans;
		}
		return "";
	}

	public static string ConvertToChineseNumber(int number)
	{
		if (number == 0)
		{
			return "零";
		}
		string[] array = new string[10] { "零", "一", "二", "三", "四", "五", "六", "七", "八", "九" };
		string text = "";
		int num = 0;
		while (number > 0)
		{
			int num2 = number % 10;
			if (num2 > 0 || num == 0 || (num > 0 && text[0] != '零'))
			{
				text = array[num2] + text;
			}
			number /= 10;
			num++;
		}
		return text;
	}

	public static string GetWugongStyle(string style)
	{
		string result = "";
		switch (style)
		{
		case "101":
			result = I18nGetLocalizedValue("I18N_SwordWugong");
			break;
		case "201":
			result = I18nGetLocalizedValue("I18N_KnifeWugong");
			break;
		case "301":
			result = I18nGetLocalizedValue("I18N_StickWugong");
			break;
		case "401":
			result = I18nGetLocalizedValue("I18N_HandWugong");
			break;
		case "501":
			result = I18nGetLocalizedValue("I18N_FingerWugong");
			break;
		case "601":
			result = I18nGetLocalizedValue("I18N_DartsWugong");
			break;
		case "701":
			result = I18nGetLocalizedValue("I18N_MelodyWugong");
			break;
		case "801":
			result = I18nGetLocalizedValue("I18N_WineartWugong");
			break;
		case "901":
			result = I18nGetLocalizedValue("I18N_InnerWugong");
			break;
		case "1001":
			result = I18nGetLocalizedValue("I18N_SpecialWugong");
			break;
		case "9101":
			result = I18nGetLocalizedValue("I18N_FormationWugong");
			break;
		case "9301":
			result = I18nGetLocalizedValue("I18N_AssistWugong");
			break;
		case "9401":
			result = I18nGetLocalizedValue("I18N_RecipeWugong");
			break;
		case "9501":
			result = I18nGetLocalizedValue("I18N_SpWugong");
			break;
		case "9601":
			result = I18nGetLocalizedValue("I18N_SpuerWugong");
			break;
		}
		return result;
	}

	public static void AdjustScrollView(ScrollRect ScrollViewRect)
	{
		int num = 0;
		float num2 = 0f;
		float num3 = 0f;
		float num4 = 0f;
		float num5 = 0f;
		float num6 = 0f;
		float num7 = 0f;
		int num8 = 0;
		int num9 = 0;
		for (int i = 0; i < ScrollViewRect.content.childCount; i++)
		{
			Transform child = ScrollViewRect.content.transform.GetChild(i);
			if (child.gameObject.activeSelf)
			{
				num++;
				if (num == 1)
				{
					num3 = child.GetComponent<RectTransform>().rect.width;
					num2 = child.GetComponent<RectTransform>().rect.height;
				}
			}
		}
		if (ScrollViewRect.content.GetComponent<GridLayoutGroup>() != null)
		{
			num3 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().cellSize.x;
			num2 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().cellSize.y;
			num4 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().spacing.x;
			num5 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().spacing.y;
			_ = ScrollViewRect.content.GetComponent<GridLayoutGroup>().padding.top;
			num6 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().padding.left;
			num7 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().padding.right;
			_ = ScrollViewRect.content.GetComponent<GridLayoutGroup>().padding.bottom;
			num8 = (int)((ScrollViewRect.GetComponent<RectTransform>().rect.width - num6 - num7 + num4) / (num3 + num4));
			num8 = ((num8 > num) ? num : num8);
			num8 = ((num8 <= 0) ? 1 : num8);
			num9 = num / num8 + ((num % num8 > 0) ? 1 : 0);
		}
		else if (ScrollViewRect.content.GetComponent<VerticalLayoutGroup>() != null)
		{
			num5 = ScrollViewRect.content.GetComponent<VerticalLayoutGroup>().spacing;
			_ = ScrollViewRect.content.GetComponent<VerticalLayoutGroup>().padding.top;
			num6 = ScrollViewRect.content.GetComponent<VerticalLayoutGroup>().padding.left;
			num7 = ScrollViewRect.content.GetComponent<VerticalLayoutGroup>().padding.right;
			_ = ScrollViewRect.content.GetComponent<VerticalLayoutGroup>().padding.bottom;
			num8 = 1;
			num9 = num;
		}
		else if (ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>() != null)
		{
			num4 = ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>().spacing;
			_ = ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>().padding.top;
			num6 = ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>().padding.left;
			num7 = ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>().padding.right;
			_ = ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>().padding.bottom;
			num8 = num;
			num9 = 1;
		}
		RectTransform component = ScrollViewRect.content.GetComponent<RectTransform>();
		RectTransform component2 = ScrollViewRect.GetComponent<RectTransform>();
		float y = (((float)num9 * (num2 + num5) > component2.rect.height) ? ((float)num9 * (num2 + num5)) : component2.rect.height);
		if (!((float)num8 * (num3 + num4) > component2.rect.width))
		{
			_ = component2.rect.width;
		}
		component.sizeDelta = new Vector2(component.sizeDelta.x, y);
		component.anchoredPosition = new Vector2(0f, 0f);
	}

	public static void CloseHover()
	{
		if (CommonResourcesData.HoverItem.activeInHierarchy)
		{
			CommonResourcesData.HoverItem.SetActive(value: false);
		}
		if (CommonResourcesData.HoverWuGong.activeInHierarchy)
		{
			CommonResourcesData.HoverWuGong.SetActive(value: false);
		}
		if (HoverController.isOpen)
		{
			HoverController.currentHover?.HoverDeselect();
		}
		SharedData.Instance().m_OpenDetail = "";
	}

	public static bool IsHoverOpen()
	{
		if (CommonResourcesData.HoverItem.activeInHierarchy || CommonResourcesData.HoverWuGong.activeInHierarchy || HoverController.isOpen)
		{
			return true;
		}
		return false;
	}

	public static IEnumerator DelayedOpenHoverOperation(GameObject go, bool showEquip = true, bool useCharaData = true)
	{
		yield return null;
		HoverWGController component = go.GetComponent<HoverWGController>();
		if (component != null && !IsHoverOpen())
		{
			component.HoverSelect(go, showEquip, useCharaData);
		}
	}

	public static void CheckSensitiveWords(string input, Action<bool> onComplete)
	{
		bool flag = CheckSensitiveWordsLocal(input);
		if (flag)
		{
			onComplete?.Invoke(flag);
		}
		else if (SteamAPI.Init() && SteamUtils.InitFilterText())
		{
			CSteamID steamID = SteamUser.GetSteamID();
			_ = input.Length;
			SteamUtils.FilterText(ETextFilteringContext.k_ETextFilteringContextUnknown, steamID, input, out var pchOutFilteredText, 100u);
			Debug.Log("ENABLESTEAMWORKS Filtered Text: input = " + input + "; output = " + pchOutFilteredText);
			onComplete?.Invoke(input != pchOutFilteredText);
		}
		else
		{
			onComplete?.Invoke(obj: false);
		}
	}

	private static bool CheckSensitiveWordsLocal(string input)
	{
		bool result = false;
		foreach (SensitiveWord0Table.Row row in CommonResourcesData.sw0.GetRowList())
		{
			if (Regex.IsMatch(input, row.Content))
			{
				Debug.LogWarning("Illegal input: [" + input + "] vs [" + row.Content + "]");
				result = true;
				break;
			}
		}
		return result;
	}
}
