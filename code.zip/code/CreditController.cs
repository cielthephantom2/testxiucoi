using UnityEngine;
using UnityEngine.SceneManagement;

public class CreditController : MonoBehaviour
{
	public SpriteRenderer pageimage;

	private bool exiting;

	private int pageno = 1;

	private AudioSource m_AudioSource;

	private float changePageIntervalTime = 0.5f;

	private float timer;

	private bool isContinueChangePage;

	private void Start()
	{
		timer = 0f;
		InputSystemCustom.Instance().UI.Enable();
		m_AudioSource = GetComponent<AudioSource>();
		m_AudioSource.PlayDelayed(0.5f);
		pageimage.sprite = Resources.Load("images/Credits/Credits-0" + pageno + CommonFunc.ShortLangSel("", "-EN", "-TW"), typeof(Sprite)) as Sprite;
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExitScene();
		}
		if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() > 0f && !isContinueChangePage)
		{
			isContinueChangePage = true;
			NextPage();
		}
		else if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() < 0f && !isContinueChangePage)
		{
			isContinueChangePage = true;
			PrevPage();
		}
		if (InputSystemCustom.Instance().UI.ManualChangePage.ReadValue<float>() != 0f && timer < changePageIntervalTime)
		{
			timer += Time.deltaTime;
			return;
		}
		timer = 0f;
		isContinueChangePage = false;
	}

	public void NextPage()
	{
		pageno++;
		if (pageno >= 3)
		{
			pageno = 1;
		}
		pageimage.sprite = Resources.Load("images/Credits/Credits-0" + pageno + CommonFunc.ShortLangSel("", "-EN", "-TW"), typeof(Sprite)) as Sprite;
	}

	public void PrevPage()
	{
		pageno--;
		if (pageno <= 0)
		{
			pageno = 2;
		}
		pageimage.sprite = Resources.Load("images/Credits/Credits-0" + pageno + CommonFunc.ShortLangSel("", "-EN", "-TW"), typeof(Sprite)) as Sprite;
	}

	public void ExitScene()
	{
		if (!exiting)
		{
			exiting = true;
			SceneManager.LoadScene("Title");
		}
	}
}
