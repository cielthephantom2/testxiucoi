using System;
using System.Collections.Generic;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class SimpleCharaData
{
	[Key(0)]
	public string m_Table = "";

	[Key(1)]
	public string m_Id = "";

	[Key(2)]
	public string m_Prefab = "";

	[Key(3)]
	public string m_BattleIcon = "";

	[Key(4)]
	public string m_DefaultPrefab = "";

	[Key(5)]
	public string m_DefaultBattleIcon = "";

	[Key(6)]
	public float m_Hp;

	[Key(7)]
	public float m_Mp;

	[Key(8)]
	public string m_Training_Id = "";

	[Key(9)]
	public int m_Level = 1;

	[Key(10)]
	public int m_Exp;

	[Key(11)]
	public int m_Relationship;

	[Key(12)]
	public int m_Ranking = 999;

	[Key(13)]
	public int m_Talent;

	[Key(14)]
	public List<SimpleKongFuData> m_KongFuData = new List<SimpleKongFuData>();

	[Key(15)]
	public List<string> sz_KongFuData = new List<string>();

	[Key(16)]
	public List<string> m_KongFuListInBattle = new List<string>();

	[Key(17)]
	public List<SimpleAtomData> m_AtomData = new List<SimpleAtomData>();

	[Key(18)]
	public List<string> sz_AtomData = new List<string>();

	[Key(19)]
	public List<string> m_TraitList;

	[Key(20)]
	public List<string> m_EquipSlot;

	[Key(21)]
	public List<string> m_NicknameList;

	[Key(22)]
	public List<string> m_EquipTraitList = new List<string>();

	[Key(23)]
	public List<string> m_titleExpList = new List<string>();

	[Key(24)]
	public string m_currentTitleID = "";

	[Key(25)]
	public string m_NickName = "";

	[Key(26)]
	public string m_Guild = "";

	[Key(27)]
	[IgnoreMember]
	public SkinData m_SkinData = new SkinData();

	[Key(28)]
	public int totalTalentCost;
}
