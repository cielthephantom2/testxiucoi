using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public static class SkillKeyWordManage
{
	public static void ClearDebuffFunction(BattleObject _attacker, BattleObject curTarget, float injury = 0f)
	{
		float num = 0f;
		for (int i = 0; i < curTarget.m_Buffs.Count; i++)
		{
			BuffData buffData = curTarget.m_Buffs[i];
			if (SharedData.Instance().m_A01NameRowDirec[buffData.name].Digest.Contains("debuff"))
			{
				buffData.turn = 0;
				num = ((!(SharedData.Instance().m_A01NameRowDirec[buffData.name].Type == "1")) ? (num + buffData.value) : (num + buffData.value / float.Parse(SharedData.Instance().m_A01NameRowDirec[buffData.name].Limit, CultureInfo.InvariantCulture)));
				curTarget.RemoveBuff(buffData);
				i--;
			}
		}
		float num2 = float.Parse(SharedData.Instance().m_A01NameRowDirec["Mad"].Limit, CultureInfo.InvariantCulture);
		num += CommonFunc.saturate(curTarget.charadata.Indexs_Name["Mad"].fightValue / num2) + CommonFunc.saturate(curTarget.charadata.Indexs_Name["Seal"].fightValue / num2) + CommonFunc.saturate(curTarget.charadata.Indexs_Name["Hurt"].fightValue / num2) + CommonFunc.saturate(curTarget.charadata.Indexs_Name["Poison"].fightValue / num2) + CommonFunc.saturate(curTarget.charadata.Indexs_Name["Bleed"].fightValue / num2) + CommonFunc.saturate(curTarget.charadata.Indexs_Name["Burn"].fightValue / num2);
		curTarget.charadata.Indexs_Name["Mad"].fightValue = 0f;
		curTarget.charadata.Indexs_Name["Seal"].fightValue = 0f;
		curTarget.charadata.Indexs_Name["Hurt"].fightValue = 0f;
		curTarget.charadata.Indexs_Name["Poison"].fightValue = 0f;
		curTarget.charadata.Indexs_Name["Bleed"].fightValue = 0f;
		curTarget.charadata.Indexs_Name["Burn"].fightValue = 0f;
		if (!(_attacker.charadata.GetBattleValueByName("ClearDebuffHealHp") > 0f) && (_attacker.m_SkillRow == null || !KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "ClearDebuffHealHp")))
		{
			return;
		}
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			if (!allBattleObj.isDead && !(allBattleObj.race != _attacker.race))
			{
				allBattleObj.AddDamageInfo(((int)(injury * (1f + num))).ToString(), "HEAL");
			}
		}
	}

	public static void ClearGainBuffFunction(BattleObject _attacker, BattleObject curTarget, float injury = 0f)
	{
		float num = 0f;
		for (int i = 0; i < curTarget.m_Buffs.Count; i++)
		{
			BuffData buffData = curTarget.m_Buffs[i];
			if (SharedData.Instance().m_A01NameRowDirec[buffData.name].Digest.Contains("gainbuff"))
			{
				if (Random.Range(0f, 1f) < _attacker.charadata.GetBattleValueByName("StealGainBuff"))
				{
					_attacker.AddBuff(buffData.name, buffData.source, buffData.value, buffData.turn, "", buffData.drunk);
				}
				buffData.turn = 0;
				num = ((!(SharedData.Instance().m_A01NameRowDirec[buffData.name].Type == "1")) ? (num + buffData.value) : (num + buffData.value / float.Parse(SharedData.Instance().m_A01NameRowDirec[buffData.name].Limit, CultureInfo.InvariantCulture)));
				curTarget.RemoveBuff(buffData);
				i--;
			}
		}
		if (!(_attacker.charadata.GetBattleValueByName("ClearGainBuffHealHp") > 0f) && !KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "ClearGainBuffHealHp"))
		{
			return;
		}
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			if (!allBattleObj.isDead && !(allBattleObj.race != _attacker.race))
			{
				allBattleObj.AddDamageInfo(((int)(injury * (1f + num))).ToString(), "HEAL");
			}
		}
	}

	public static void StealGainBuff(BattleObject _attacker, BattleObject curTarget, float injury = 0f)
	{
		for (int i = 0; i < curTarget.m_Buffs.Count; i++)
		{
			BuffData buffData = curTarget.m_Buffs[i];
			if (SharedData.Instance().m_A01NameRowDirec[buffData.name].Digest.Contains("gainbuff") && Random.Range(0f, 1f) < _attacker.charadata.GetBattleValueByName("StealGainBuff"))
			{
				_attacker.AddBuff(buffData.name, buffData.source, buffData.value, buffData.turn, "", buffData.drunk);
				buffData.turn = 0;
				curTarget.RemoveBuff(buffData);
				i--;
			}
		}
	}

	public static void StealHpOrMp(BattleObject _attacker, BattleObject _defender, string _type, float _injury, float _finalval)
	{
		if (_defender.charadata.GetBattleValueByName(_type + "resist") > 0f)
		{
			_defender.AddBuffInfo((_type + "resist").ToLower(), CommonFunc.I18nGetLocalizedValue("I18N_Resist"));
			return;
		}
		float num = _defender.charadata.GetBattleValueByName("MP") * (1f - CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Hurt") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Hurt"].Limit, CultureInfo.InvariantCulture)));
		float num2 = ((_type == "HPsteal") ? Mathf.Floor(_injury * _finalval) : Mathf.Floor(_finalval * num));
		if (!(num2 > 0f))
		{
			return;
		}
		_defender.AddBuffInfo(_type.ToLower(), num2.ToString());
		if (_type == "HPsteal")
		{
			_attacker.stealhptotal += num2;
		}
		else
		{
			_attacker.stealmptotal += num2;
		}
		float battleValueByName = _defender.charadata.GetBattleValueByName("Poison");
		if (battleValueByName > 0f)
		{
			if (_attacker.charadata.Indexs_Name["Poison"].fightValue + battleValueByName * 0.2f < battleValueByName)
			{
				_attacker.charadata.Indexs_Name["Poison"].fightValue += (int)(battleValueByName * 0.2f);
				_defender.charadata.Indexs_Name["Poison"].fightValue -= (int)(battleValueByName * 0.2f);
			}
			_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_PoisonCharacter"), "");
		}
		if (_attacker.charadata.GetBattleValueByName("StealHpMpAddCrazyBuff") > 0f)
		{
			BuffData buffData = _attacker.m_Buffs.Find((BuffData x) => x.name == "StealHpMpAddCrazyBuff");
			if (buffData == null)
			{
				_attacker.AddBuff("StealHpMpAddCrazyBuff", "", 1f, 4);
				return;
			}
			buffData.value = ((buffData.value >= 5f) ? buffData.value : (buffData.value + 1f));
			buffData.turn = 4;
		}
	}

	public static void TransHPOrMP(BattleObject _source, BattleObject _target, string _type, float _rate = 1f)
	{
		float num = _source.charadata.GetBattleValueByName(_type) * _rate / (float)_source.attackObjs.Count;
		float num2 = ((_type == "HP") ? (_source.charadata.m_Hp - 1f) : _source.charadata.m_Mp);
		if (num >= num2)
		{
			num = num2;
		}
		if (!(num <= 0f))
		{
			float battleValueByName = _source.charadata.GetBattleValueByName("Poison");
			if (battleValueByName > 0f && _target.charadata.Indexs_Name["Poison"].fightValue + battleValueByName * 0.2f < battleValueByName)
			{
				_target.charadata.Indexs_Name["Poison"].fightValue += (int)(battleValueByName * 0.2f);
				_source.charadata.Indexs_Name["Poison"].fightValue -= (int)(battleValueByName * 0.2f);
			}
			if (_type == "HP")
			{
				_target.AddDamageInfo(num.ToString(), "HEAL");
				_source.AddDamageInfo(num.ToString(), "DAMAGE");
			}
			else
			{
				_target.AddDamageInfo(num.ToString(), "HEALMP");
				_source.AddDamageInfo(num.ToString(), "MP");
			}
		}
	}

	public static void ExchangeHpBetweenMp(BattleObject _attacker, BattleObject curTarget, string _type, float _finalval)
	{
		string text = _type.Substring(8, 2);
		_type.Substring(12, 2);
		float num = ((text == "Hp") ? (curTarget.charadata.m_Hp - 1f) : curTarget.charadata.m_Mp);
		float num2 = (int)(_finalval * curTarget.charadata.GetBattleValueByName(text));
		if (num2 >= num)
		{
			num2 = num;
		}
		if (_attacker.charadata.GetBattleValueByName("HpToMpCrazyBuff") > 0f || KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "HpToMpCrazyBuff"))
		{
			BuffData buffData = _attacker.m_Buffs.Find((BuffData x) => x.name == "HpToMpCrazyBuff");
			if (buffData == null)
			{
				_attacker.AddBuff("HpToMpCrazyBuff", "", 0.1f, 4);
			}
			else
			{
				buffData.value = (((double)buffData.value >= 0.5) ? buffData.value : (buffData.value + 0.1f));
				buffData.turn = 4;
			}
		}
		if (text == "Hp")
		{
			_attacker.AddDamageInfo(num2.ToString(), "DAMAGE");
			curTarget.AddDamageInfo(num2.ToString(), "HealMP");
		}
		else
		{
			_attacker.AddDamageInfo(num2.ToString(), "HEAL");
			curTarget.AddDamageInfo(num2.ToString(), "MP");
		}
	}

	public static void ExchangeDebuff(BattleObject _source, BattleObject _target, string _buffName, float _rate = 1f)
	{
		float num = _source.charadata.Indexs_Name[_buffName].fightValue / Mathf.Pow(1f - _rate, SharedData.Instance().m_BattleController.current.AlreadyAttackObjCount) * _rate;
		if (SharedData.Instance().m_BattleController.current.AlreadyAttackObjCount + 1 == SharedData.Instance().m_BattleController.current.attackObjs.Count)
		{
			num = _source.charadata.Indexs_Name[_buffName].fightValue;
		}
		float fightValue = _target.charadata.Indexs_Name[_buffName].fightValue;
		if (!(num <= 0f))
		{
			gang_a01Table.Row row = SharedData.Instance().m_A01NameRowDirec[_buffName];
			float num2 = num + fightValue;
			float num3 = (int)num;
			_target.charadata.Indexs_Name[_buffName].fightValue = (int)num2;
			string damageinfo = row.NameScene_Trans + " " + ((num3 > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (row.Type.Equals("2") ? (num3 * 100f) : num3) + (row.Type.Equals("2") ? "%" : "") + "</color>";
			_target.AddDamageInfo(damageinfo, _buffName);
			num2 = _source.charadata.Indexs_Name[_buffName].fightValue - num;
			num3 = -(int)num;
			_source.charadata.Indexs_Name[_buffName].fightValue = (int)num2;
			damageinfo = row.NameScene_Trans + " " + ((num3 > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (row.Type.Equals("2") ? (num3 * 100f) : num3) + (row.Type.Equals("2") ? "%" : "") + "</color>";
			_source.AddDamageInfo(damageinfo, _buffName);
		}
	}

	public static string StealAnItem(BattleObject _attacker, BattleObject _defender, int _steal)
	{
		string text = "";
		bool flag = false;
		for (int i = 0; i < _defender.m_StealableItemsName.Count; i++)
		{
			if (_defender.m_StealableItemsNum[i] != 0)
			{
				flag = true;
				gang_c04Table.Row row = _defender.m_StealableItemsName[i];
				int num = int.Parse(row.DD);
				int num2 = _steal - num;
				int num3 = Random.Range(1, 101);
				if (num2 > num3)
				{
					text = row.Item + "|" + _defender.m_StealableItemsNum[i] + "|" + i;
				}
				break;
			}
		}
		if (!text.Equals(""))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1027");
		}
		if ("".Equals(text))
		{
			text = ((!flag) ? "EMPTY" : "FAILED");
		}
		if (_attacker.m_StealSuccess.ContainsKey(_defender))
		{
			_attacker.m_StealSuccess[_defender] = text;
		}
		else
		{
			_attacker.m_StealSuccess.Add(_defender, text);
		}
		return text;
	}

	public static void TriggerDebuff(BattleObject _attacker, BattleObject _defender, string _debuffName, float injury)
	{
		float num = 35f;
		if (Random.Range(0f, 1f) < _attacker.charadata.GetBattleValueByName("TriggerDebuffAttackDizzy"))
		{
			_defender.AddBuff("Dizzy", "Skill", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_Dizzy"));
		}
		switch (_debuffName)
		{
		case "Poison":
		case "Burn":
		case "Bleed":
		case "Hurt":
		case "Seal":
		case "Mad":
		{
			float battleValueByName = _defender.charadata.GetBattleValueByName(_debuffName, isOrigin: true);
			float num2 = injury * battleValueByName / num;
			_defender.charadata.Indexs_Name[_debuffName].fightValue = 0f;
			List<Vector3Int> gridNeighbors = SharedData.Instance().m_BattleController.GetGridNeighbors(_defender.GetGridPosition());
			if (num2 > 0f)
			{
				string type = "DAMAGE";
				switch (_debuffName)
				{
				case "Poison":
				case "Burn":
				case "Bleed":
					type = _debuffName.ToUpper();
					break;
				}
				_defender.AddDamageInfo(((int)num2).ToString(), type);
				foreach (Vector3Int item in gridNeighbors)
				{
					BattleObject battleObjectInPos = SharedData.Instance().m_BattleController.GetBattleObjectInPos(item);
					if (battleObjectInPos != null)
					{
						float num3 = num2 * SharedData.Instance().m_BattleController.current.charadata.GetBattleValueByName("TriggerDebuffSputter");
						num3 = (((int)num3 <= 0) ? 1 : ((int)num3));
						if (num3 > 0f)
						{
							battleObjectInPos.AddDamageInfo(((int)num3).ToString(), type);
						}
					}
				}
			}
			if ((!(_debuffName == "Poison") && !(_debuffName == "Burn")) || !(battleValueByName >= 25f))
			{
				break;
			}
			{
				foreach (Vector3Int item2 in gridNeighbors)
				{
					if (_debuffName == "Poison")
					{
						SharedData.Instance().m_BattleController.AddTerrain(item2, (battleValueByName < 125f) ? TerrainType.PoisonLv1 : TerrainType.PoisonLv2);
					}
					else if (_debuffName == "Burn")
					{
						SharedData.Instance().m_BattleController.AddTerrain(item2, (battleValueByName < 125f) ? TerrainType.FireLv1 : TerrainType.FireLv2);
					}
				}
				break;
			}
		}
		}
	}
}
