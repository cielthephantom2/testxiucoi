using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class StatusSub3 : MonoBehaviour
{
	private TraitNineGirdController TraitNineGirdController;

	private Button TraitPackBtn;

	private Button TitlePackBtn;

	private ScrollRect TraitInfoScrollRect;

	public CharaData curdata;

	private GameObject TraitDetail;

	private List<GameObject> TraitDetailList = new List<GameObject>();

	private void Awake()
	{
		TraitNineGirdController = base.transform.Find("Panel/TraitNineGrid").GetComponent<TraitNineGirdController>();
		TraitPackBtn = base.transform.Find("Panel/TraitPack").GetComponent<Button>();
		TitlePackBtn = base.transform.Find("Panel/Title/TitlePack").GetComponent<Button>();
		TraitInfoScrollRect = base.transform.Find("Panel/TraitInfoScrollRect").GetComponent<ScrollRect>();
		TraitDetail = Resources.Load("Prefabs/NewUI/TraitDetails") as GameObject;
		EventTriggerListener.Get(TraitPackBtn.gameObject).onClick = OnButtonClick;
		EventTriggerListener.Get(TitlePackBtn.gameObject).onClick = OnButtonClick;
		SharedData.Instance().m_StatusSub3 = this;
	}

	private void OnEnable()
	{
		if (SharedData.Instance().CurrentChara == "")
		{
			return;
		}
		curdata = SharedData.Instance().CurrentCharaData;
		if (curdata == null)
		{
			return;
		}
		foreach (GameObject traitDetail in TraitDetailList)
		{
			Object.Destroy(traitDetail.gameObject);
		}
		TraitDetailList.Clear();
		TitlePackBtn.transform.parent.Find("Text").GetComponent<Text>().text = "";
		if (curdata.m_currentTitleID != "")
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(curdata.m_currentTitleID);
			if (row != null)
			{
				TitlePackBtn.transform.parent.Find("Text").GetComponent<Text>().text = row.name_Trans;
			}
		}
		TraitNineGirdController.statusSub3 = this;
		foreach (KeyValuePair<string, string> item in curdata.m_EquipTraitDict)
		{
			if (TraitNineGirdController.TraitDict.ContainsKey(item.Key))
			{
				TraitNineGirdController.TraitDict[item.Key] = item.Value;
			}
		}
		List<string> chainIndexList = curdata.CalAdditionalTrait();
		TraitNineGirdController.RefreshTraitIcon(chainIndexList);
		for (int i = 1; i <= curdata.m_EquipTraitDict.Count; i++)
		{
			if (!curdata.m_EquipTraitDict[i.ToString()].Equals(""))
			{
				InitTraitDetail(curdata.m_EquipTraitDict[i.ToString()]);
			}
		}
		StartCoroutine(DelayRefreshTraitDetail());
		SetAdditionalTrait();
	}

	private void Update()
	{
		if (!SharedData.Instance().m_TraitPackageController.isOpen)
		{
			if (InputSystemCustom.Instance().UI.OpenAllTraits.WasReleasedThisFrame())
			{
				StartCoroutine(DelayGamePadClick(base.transform.Find("Panel/TraitPack").gameObject));
			}
			else if (InputSystemCustom.Instance().UI.OpenTitleTraits.WasReleasedThisFrame())
			{
				StartCoroutine(DelayGamePadClick(base.transform.Find("Panel/Title/TitlePack").gameObject));
			}
		}
	}

	private IEnumerator DelayGamePadClick(GameObject button)
	{
		yield return null;
		EventSystem.current.SetSelectedGameObject(button);
		ExecuteEvents.Execute(button, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
	}

	private GameObject InitTraitDetail(string id)
	{
		gang_b06Table.Row row = CommonResourcesData.b06.Find_id(id);
		if (row == null)
		{
			return null;
		}
		GameObject gameObject = Object.Instantiate(TraitDetail, TraitInfoScrollRect.content.transform);
		string text = row.traitEquipIndex;
		if (curdata.m_EquipTraitDict.ContainsValue(row.id))
		{
			foreach (KeyValuePair<string, string> item in curdata.m_EquipTraitDict)
			{
				if (item.Value == row.id)
				{
					text = item.Key;
					break;
				}
			}
		}
		gameObject.transform.Find("TraitIcon").GetComponent<TraitIconController>().InitTraitIcon(row.id, text, int.Parse(text) >= 10);
		gameObject.name = row.id + "|" + row.traitEquipIndex;
		gameObject.transform.Find("Name/Text").GetComponent<Text>().text = row.name_Trans;
		gameObject.transform.Find("Lock").gameObject.SetActive(value: false);
		gameObject.transform.Find("Info/Text").GetComponent<Text>().text = row.note_Trans;
		gameObject.transform.Find("Hover/Text").GetComponent<Text>().text = row.comment_Trans;
		TraitDetailList.Add(gameObject);
		return gameObject;
	}

	private IEnumerator DelayRefreshTraitDetail()
	{
		yield return null;
		RectTransform component = TraitInfoScrollRect.content.GetComponent<RectTransform>();
		component.sizeDelta = new Vector2(component.sizeDelta.x, 0f);
		foreach (GameObject traitDetail in TraitDetailList)
		{
			float preferredHeight = traitDetail.transform.Find("Info/Text").GetComponent<Text>().preferredHeight;
			RectTransform component2 = traitDetail.transform.Find("Info").GetComponent<RectTransform>();
			component2.sizeDelta = new Vector2(component2.sizeDelta.x, preferredHeight + 40f);
			RectTransform component3 = traitDetail.GetComponent<RectTransform>();
			component3.sizeDelta = new Vector2(component3.sizeDelta.x, component2.sizeDelta.y + 90f);
			component.sizeDelta = new Vector2(component.sizeDelta.x, component.sizeDelta.y + component3.sizeDelta.y + 10f);
		}
		component.anchoredPosition = new Vector2(component.anchoredPosition.x, 0f);
	}

	public void EquipTrait()
	{
		foreach (KeyValuePair<string, string> item in TraitNineGirdController.TraitDict)
		{
			curdata.m_EquipTraitDict[item.Key] = item.Value;
		}
		List<string> chainIndexList = curdata.CalAdditionalTrait();
		TraitNineGirdController.RefreshTraitIcon(chainIndexList);
		foreach (GameObject traitDetail in TraitDetailList)
		{
			Object.Destroy(traitDetail.gameObject);
		}
		TraitDetailList.Clear();
		for (int i = 1; i <= curdata.m_EquipTraitDict.Count; i++)
		{
			if (!curdata.m_EquipTraitDict[i.ToString()].Equals(""))
			{
				InitTraitDetail(curdata.m_EquipTraitDict[i.ToString()]);
			}
		}
		StartCoroutine(DelayRefreshTraitDetail());
		SetAdditionalTrait();
	}

	private void SetAdditionalTrait()
	{
		bool flag = curdata.m_EquipTraitDict.ContainsKey("10");
		base.transform.Find("Panel/TraitInfo").gameObject.SetActive(!flag);
		base.transform.Find("Panel/ChainTrait").gameObject.SetActive(flag);
		if (flag)
		{
			gang_b06ChainTable.Row row = CommonResourcesData.b06Chain.Find_id(curdata.m_EquipTraitDict["10"]);
			gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(curdata.m_EquipTraitDict["10"]);
			for (int i = 1; i <= 9; i++)
			{
				string text = row.nineGridDict[i.ToString()];
				base.transform.Find("Panel/ChainTrait/Index/Index" + i).gameObject.SetActive(!text.Equals("0"));
			}
			base.transform.Find("Panel/ChainTrait/Index/Name/Text").GetComponent<Text>().text = row2.name_Trans;
			base.transform.Find("Panel/ChainTrait/Info").GetComponent<Text>().text = row2.note_Trans;
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			if (go.name == "TraitPack")
			{
				CommonResourcesData.inputDeviceDetector.PushJoyStack();
				SharedData.Instance().m_TraitPackageController.OpenTraitPackage(TraitPackageType.AllTraits, curdata.m_TraitList, "", curdata.m_EquipTraitDict.Values.ToList(), "");
			}
			else if (go.name == "TitlePack")
			{
				CommonResourcesData.inputDeviceDetector.PushJoyStack();
				SharedData.Instance().m_TraitPackageController.OpenTraitPackage(TraitPackageType.Title, curdata.m_TraitList, "", new List<string> { curdata.m_currentTitleID }, curdata.m_currentTitleID);
			}
		}
	}
}
