using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class JourneyListController : MonoBehaviour
{
	private bool exiting;

	private Transform JiangHuAtlas;

	private Transform WuXueAtlas;

	private Transform BaoDianAtlas;

	private Transform JiangHuContent;

	private Transform WuXueContent;

	private Transform BaoDianContent;

	private Transform InfoContent;

	private GameObject SelectedTopBtn;

	private GameObject SelectedSubBtn;

	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	private Sprite SubNormalSprite;

	private Sprite SubSelectedSprite;

	private GameObject JourneyTopPrefab;

	private GameObject JourneyGroupPrefab;

	private GameObject JourneySubPrefab;

	private GameObject BlockPrefab;

	private Dictionary<string, List<gang_f01Table.Row>> m_SubTables = new Dictionary<string, List<gang_f01Table.Row>>();

	private List<GameObject> m_InfoList = new List<GameObject>();

	private void Start()
	{
		NormalSprite = Resources.Load("images/01-border/boder-chuanwen-04", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-chuanwen-03", typeof(Sprite)) as Sprite;
		SubNormalSprite = Resources.Load("images/01-border/boder-chuanwen-02", typeof(Sprite)) as Sprite;
		SubSelectedSprite = Resources.Load("images/01-border/boder-chuanwen-01", typeof(Sprite)) as Sprite;
		JiangHuAtlas = base.transform.Find("Panel/BG/JiangHu");
		JiangHuContent = JiangHuAtlas.Find("Selecter/Body/Viewport/Content");
		WuXueAtlas = base.transform.Find("Panel/BG/WuXue");
		WuXueContent = WuXueAtlas.Find("Selecter/Body/Viewport/Content");
		BaoDianAtlas = base.transform.Find("Panel/BG/BaoDian");
		BaoDianContent = BaoDianAtlas.Find("Selecter/Body/Viewport/Content");
		InfoContent = base.transform.Find("Panel/BG/Info/ScrollView/Viewport/Content");
		JiangHuAtlas.gameObject.SetActive(value: true);
		WuXueAtlas.gameObject.SetActive(value: false);
		BaoDianAtlas.gameObject.SetActive(value: false);
		JourneyTopPrefab = Resources.Load("Prefabs/NewUI/JourneyTop") as GameObject;
		JourneyGroupPrefab = Resources.Load("Prefabs/NewUI/JourneyGroup") as GameObject;
		JourneySubPrefab = Resources.Load("Prefabs/NewUI/JourneySub") as GameObject;
		BlockPrefab = Resources.Load("Prefabs/NewUI/JourneyBlock") as GameObject;
		GameObject gameObject = null;
		GameObject gameObject2 = null;
		SelectedTopBtn = null;
		SelectedSubBtn = null;
		string text = "";
		Text text2 = null;
		List<gang_f01Table.Row> list = null;
		bool flag = false;
		foreach (gang_f01Table.Row row in CommonResourcesData.f01.GetRowList())
		{
			if ("1".Equals(row.level))
			{
				gameObject = null;
				if (!"".Equals(text))
				{
					m_SubTables.Add(text, list);
					if (text2 != null)
					{
						int num = 0;
						foreach (gang_f01Table.Row item in list)
						{
							if (!CheckCloseFlags(item.closeflag))
							{
								break;
							}
							num++;
						}
						if (num != list.Count)
						{
							text2.text = "* " + text2.text;
							if (!flag)
							{
								gameObject2.transform.Find("Text").GetComponent<Text>().text = "* " + gameObject2.transform.Find("Text").GetComponent<Text>().text;
								flag = true;
							}
						}
					}
				}
				text = "";
				text2 = null;
				list = null;
			}
			else if ("2".Equals(row.level))
			{
				if (!"".Equals(text))
				{
					m_SubTables.Add(text, list);
					if (text2 != null)
					{
						int num2 = 0;
						foreach (gang_f01Table.Row item2 in list)
						{
							if (!CheckCloseFlags(item2.closeflag))
							{
								break;
							}
							num2++;
						}
						if (num2 != list.Count)
						{
							text2.text = "* " + text2.text;
							if (!flag)
							{
								gameObject2.transform.Find("Text").GetComponent<Text>().text = "* " + gameObject2.transform.Find("Text").GetComponent<Text>().text;
								flag = true;
							}
						}
					}
				}
				text = row.id;
				text2 = null;
				list = new List<gang_f01Table.Row>();
			}
			if (!"1".Equals(row.openflag) && !CheckOpenFlags(row.openflag, row.catalog))
			{
				continue;
			}
			Transform transform = null;
			string text3 = "";
			string catalog = row.catalog;
			if (!(catalog == "2"))
			{
				if (catalog == "3")
				{
					transform = BaoDianContent;
					text3 = "BD";
				}
				else
				{
					transform = JiangHuContent;
					text3 = "JH";
				}
			}
			else
			{
				transform = WuXueContent;
				text3 = "WX";
			}
			switch (row.level)
			{
			case "1":
			{
				GameObject obj = Object.Instantiate(JourneyTopPrefab, transform);
				obj.name = text3 + "_Top_" + row.id;
				obj.transform.Find("Text").GetComponent<Text>().text = row.note_Trans;
				gameObject2 = obj;
				flag = false;
				GameObject obj2 = Object.Instantiate(JourneyGroupPrefab, transform);
				obj2.name = text3 + "_Group_" + row.id;
				obj2.SetActive(value: false);
				gameObject = obj2;
				break;
			}
			case "2":
			{
				GameObject obj3 = Object.Instantiate(JourneySubPrefab, gameObject.transform);
				obj3.name = text3 + "_Sub_" + row.id;
				text2 = obj3.transform.Find("Text").GetComponent<Text>();
				text2.text = row.note_Trans;
				break;
			}
			case "3":
				list?.Add(row);
				break;
			}
		}
		if (!"".Equals(text) && !m_SubTables.ContainsKey(text))
		{
			m_SubTables.Add(text, list);
			if (text2 != null)
			{
				int num3 = 0;
				foreach (gang_f01Table.Row item3 in list)
				{
					if (!CheckCloseFlags(item3.closeflag))
					{
						break;
					}
					num3++;
				}
				if (num3 != list.Count)
				{
					text2.text = "* " + text2.text;
					if (!flag)
					{
						gameObject2.transform.Find("Text").GetComponent<Text>().text = "* " + gameObject2.transform.Find("Text").GetComponent<Text>().text;
						flag = true;
					}
				}
			}
		}
		Button[] componentsInChildren = base.transform.Find("Panel/BG").GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button obj4 in componentsInChildren)
		{
			obj4.gameObject.AddComponent<GDragEventDispatcher>();
			EventTriggerListener.Get(obj4.gameObject).onClick = OnButtonClick;
		}
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/JiangHuPanel").gameObject);
		OnButtonClick(base.transform.Find("Panel/BG/Title/JiangHuPanel").gameObject);
	}

	private void SelectDefaultButtonsInContent(Transform _content)
	{
		if (SelectedTopBtn != null)
		{
			SelectedTopBtn.GetComponent<Image>().sprite = NormalSprite;
			string[] array = SelectedTopBtn.name.Split('_');
			SelectedTopBtn.transform.parent.Find(array[0] + "_Group_" + array[2]).gameObject.SetActive(value: false);
			SelectedTopBtn = null;
		}
		if (SelectedSubBtn != null)
		{
			SelectedSubBtn.GetComponent<Image>().sprite = SubNormalSprite;
			SelectedSubBtn = null;
		}
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.AtlasNext.WasReleasedThisFrame())
		{
			PointerEventData eventData = new PointerEventData(EventSystem.current);
			if (JiangHuAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/WuXuePanel").gameObject, eventData, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/WuXuePanel").gameObject);
			}
			else if (WuXueAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/BaoDianPanel").gameObject, eventData, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/BaoDianPanel").gameObject);
			}
			else if (BaoDianAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/JiangHuPanel").gameObject, eventData, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/JiangHuPanel").gameObject);
			}
		}
		else if (InputSystemCustom.Instance().UI.AtlasPrev.WasReleasedThisFrame())
		{
			PointerEventData eventData2 = new PointerEventData(EventSystem.current);
			if (JiangHuAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/BaoDianPanel").gameObject, eventData2, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/BaoDianPanel").gameObject);
			}
			else if (WuXueAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/JiangHuPanel").gameObject, eventData2, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/JiangHuPanel").gameObject);
			}
			else if (BaoDianAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/WuXuePanel").gameObject, eventData2, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/WuXuePanel").gameObject);
			}
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			PointerEventData eventData3 = new PointerEventData(EventSystem.current);
			ExecuteEvents.Execute(base.transform.Find("Panel/BG/Return").gameObject, eventData3, ExecuteEvents.pointerClickHandler);
		}
	}

	private void OnDestroy()
	{
		SharedData.Instance().IsViewOpen = false;
	}

	private void OnButtonClick(GameObject go)
	{
		if (exiting || go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		Debug.Log("OnButtonClick(): " + go.name);
		if (go.name.Equals("Return") && !exiting)
		{
			exiting = true;
			SceneManager.UnloadSceneAsync("JourneyList");
			return;
		}
		if (go.name.Equals("JiangHuPanel"))
		{
			if (!JiangHuAtlas.gameObject.activeInHierarchy)
			{
				JiangHuAtlas.gameObject.SetActive(value: true);
				ClearInfoBlock();
				SelectDefaultButtonsInContent(JiangHuContent);
				WuXueAtlas.gameObject.SetActive(value: false);
				BaoDianAtlas.gameObject.SetActive(value: false);
			}
			return;
		}
		if (go.name.Equals("WuXuePanel"))
		{
			if (!WuXueAtlas.gameObject.activeInHierarchy)
			{
				WuXueAtlas.gameObject.SetActive(value: true);
				ClearInfoBlock();
				SelectDefaultButtonsInContent(WuXueContent);
				JiangHuAtlas.gameObject.SetActive(value: false);
				BaoDianAtlas.gameObject.SetActive(value: false);
			}
			return;
		}
		if (go.name.Equals("BaoDianPanel"))
		{
			if (!BaoDianAtlas.gameObject.activeInHierarchy)
			{
				BaoDianAtlas.gameObject.SetActive(value: true);
				ClearInfoBlock();
				SelectDefaultButtonsInContent(BaoDianContent);
				JiangHuAtlas.gameObject.SetActive(value: false);
				WuXueAtlas.gameObject.SetActive(value: false);
			}
			return;
		}
		string[] array = go.name.Split('_');
		if (array.Length <= 1)
		{
			return;
		}
		if (array[1].Equals("Top"))
		{
			Transform transform = go.transform.parent.Find(array[0] + "_Group_" + array[2]);
			transform.gameObject.SetActive(!transform.gameObject.activeInHierarchy);
			if (transform.gameObject.activeInHierarchy)
			{
				if (go != SelectedTopBtn)
				{
					if (SelectedTopBtn != null)
					{
						string[] array2 = SelectedTopBtn.name.Split('_');
						SelectedTopBtn.transform.parent.Find(array2[0] + "_Group_" + array2[2]).gameObject.SetActive(value: false);
						SelectedTopBtn.GetComponent<Image>().sprite = NormalSprite;
					}
					Button[] componentsInChildren = transform.GetComponentsInChildren<Button>();
					if (componentsInChildren.Length != 0)
					{
						if (SelectedSubBtn != null)
						{
							SelectedSubBtn.GetComponent<Image>().sprite = SubNormalSprite;
						}
						componentsInChildren[0].GetComponent<Image>().sprite = SubSelectedSprite;
						SelectedSubBtn = componentsInChildren[0].gameObject;
						SubButtonProcess(SelectedSubBtn.name);
					}
					go.GetComponent<Image>().sprite = SelectedSprite;
					SelectedTopBtn = go;
				}
				else
				{
					SelectedTopBtn.GetComponent<Image>().sprite = SelectedSprite;
					if (SelectedSubBtn != null)
					{
						SubButtonProcess(SelectedSubBtn.name);
					}
				}
			}
			else
			{
				SelectedTopBtn.GetComponent<Image>().sprite = NormalSprite;
				ClearInfoBlock();
			}
		}
		else if (array[1].Equals("Sub") && go != SelectedSubBtn)
		{
			SelectedSubBtn.GetComponent<Image>().sprite = SubNormalSprite;
			go.GetComponent<Image>().sprite = SubSelectedSprite;
			SelectedSubBtn = go;
			SubButtonProcess(SelectedSubBtn.name);
		}
	}

	private void SubButtonProcess(string _btn_name)
	{
		string[] array = _btn_name.Split('_');
		ClearInfoBlock();
		if (!m_SubTables.ContainsKey(array[2]))
		{
			return;
		}
		foreach (gang_f01Table.Row item in m_SubTables[array[2]])
		{
			GameObject gameObject = Object.Instantiate(BlockPrefab, InfoContent);
			gameObject.name = "SubInfo_ " + item.id;
			Text component = gameObject.transform.Find("Text").GetComponent<Text>();
			component.text = (CheckCloseFlags(item.closeflag) ? "▣\u00a0" : "□\u00a0") + SharedData.Instance().FormatDynamicText(item.note_Trans);
			component.rectTransform.sizeDelta = new Vector2(component.rectTransform.sizeDelta.x, (float)Mathf.CeilToInt(component.preferredHeight) + 50f);
			component.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(component.transform.parent.GetComponent<RectTransform>().sizeDelta.x, component.rectTransform.sizeDelta.y);
			m_InfoList.Add(gameObject);
		}
	}

	private bool CheckOpenFlags(string _flags, string _catalog)
	{
		bool flag = false;
		if (_flags.Contains("&"))
		{
			flag = true;
			string[] array = _flags.Split('&');
			foreach (string func in array)
			{
				if (!CheckOpenFlagFunc(func, _catalog))
				{
					flag = false;
					break;
				}
			}
		}
		else if (_flags.Contains("|"))
		{
			flag = false;
			string[] array = _flags.Split('|');
			foreach (string func2 in array)
			{
				if (CheckOpenFlagFunc(func2, _catalog))
				{
					flag = true;
					break;
				}
			}
		}
		else
		{
			flag = CheckOpenFlagFunc(_flags, _catalog);
		}
		return flag;
	}

	private bool CheckOpenFlagFunc(string _func, string _catalog)
	{
		bool result = false;
		if ("1".Equals(_catalog))
		{
			if (SharedData.Instance().m_Mesg_News.Contains(_func))
			{
				result = true;
			}
		}
		else if ("2".Equals(_catalog) && SharedData.Instance().m_Mesg_Tecs.Contains(_func))
		{
			result = true;
		}
		return result;
	}

	private bool CheckCloseFlags(string _flags)
	{
		if ("0".Equals(_flags))
		{
			return false;
		}
		if ("1".Equals(_flags))
		{
			return true;
		}
		bool flag = false;
		if (_flags.Contains("&"))
		{
			flag = true;
			string[] array = _flags.Split('&');
			foreach (string func in array)
			{
				if (!CheckCloseFlagFunc(func))
				{
					flag = false;
					break;
				}
			}
		}
		else if (_flags.Contains("|"))
		{
			flag = false;
			string[] array = _flags.Split('|');
			foreach (string func2 in array)
			{
				if (CheckCloseFlagFunc(func2))
				{
					flag = true;
					break;
				}
			}
		}
		else
		{
			flag = CheckCloseFlagFunc(_flags);
		}
		return flag;
	}

	private bool CheckCloseFlagFunc(string _func)
	{
		bool result = false;
		if (_func.Contains(">"))
		{
			string[] array = _func.Split('>');
			if (SharedData.Instance().FlagList.ContainsKey(array[0]))
			{
				result = SharedData.Instance().FlagList[array[0]] > int.Parse(array[1]);
			}
		}
		else if (_func.Contains("<"))
		{
			string[] array2 = _func.Split('<');
			if (SharedData.Instance().FlagList.ContainsKey(array2[0]))
			{
				result = SharedData.Instance().FlagList[array2[0]] < int.Parse(array2[1]);
			}
		}
		else if (_func.Contains("="))
		{
			string[] array3 = _func.Split('=');
			if (SharedData.Instance().FlagList.ContainsKey(array3[0]))
			{
				result = SharedData.Instance().FlagList[array3[0]] == int.Parse(array3[1]);
			}
		}
		else if (SharedData.Instance().FlagList.ContainsKey(_func))
		{
			result = SharedData.Instance().FlagList[_func] > 0;
		}
		return result;
	}

	private void ClearInfoBlock()
	{
		foreach (GameObject info in m_InfoList)
		{
			Object.Destroy(info);
		}
		m_InfoList.Clear();
	}
}
