using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BulkWallet : MonoBehaviour
{
	[SerializeField]
	private PackageController packageController;

	[SerializeField]
	private CanvasGroup m_CanvasGroup;

	[SerializeField]
	private Slider moneySlider;

	[SerializeField]
	private Text currentExpend;

	[SerializeField]
	private Text currentCount;

	[SerializeField]
	private Image currencyIcon;

	[SerializeField]
	private Text currencyTypeText;

	private PackageItemData packageItemData;

	private bool isClosing;

	public static bool isOpen;

	public static BulkType bulkType;

	private void Start()
	{
		moneySlider.onValueChanged.AddListener(OnSliderValueChange);
		m_CanvasGroup.alpha = 0f;
		m_CanvasGroup.interactable = false;
		m_CanvasGroup.blocksRaycasts = false;
	}

	private void LateUpdate()
	{
		if (!isClosing && !m_CanvasGroup.interactable.Equals(obj: false))
		{
			if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
			{
				Confirm();
			}
			else if (InputDeviceDetector.isMouse1Up || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
			{
				Cancel();
			}
		}
	}

	public void Confirm()
	{
		packageController.ShopBuySomething(bulkType, SharedData.Instance().OpenShopID, packageItemData.ID, packageItemData.effectPrice, (int)moneySlider.value);
		Hide();
	}

	public void Cancel()
	{
		Hide();
	}

	private void OnSliderValueChange(float vlaue)
	{
		currentExpend.text = ((int)moneySlider.value * packageItemData.effectPrice).ToString();
		currentCount.text = ((int)moneySlider.value).ToString();
	}

	private void Init()
	{
		moneySlider.value = 1f;
		moneySlider.minValue = 1f;
		moneySlider.maxValue = SharedData.Instance().m_Money / packageItemData.effectPrice;
		if (moneySlider.maxValue > (float)packageItemData.number)
		{
			moneySlider.maxValue = packageItemData.number;
		}
		if (bulkType.Equals(BulkType.Loan))
		{
			moneySlider.maxValue = packageItemData.number;
		}
		currentExpend.text = packageItemData.effectPrice.ToString();
		switch (packageItemData.priceType)
		{
		case PriceType.money:
			currencyIcon.sprite = CommonResourcesData.GetBookIcon("Money");
			currencyTypeText.text = CommonFunc.I18nGetLocalizedValue("I18N_Money_1");
			break;
		case PriceType.oldcoin:
			currencyIcon.sprite = CommonResourcesData.GetBookIcon("icon-0223-998");
			currencyTypeText.text = CommonFunc.I18nGetLocalizedValue("I18N_Package_Currency_OldCoin");
			break;
		case PriceType.bone:
			currencyIcon.sprite = CommonResourcesData.GetBookIcon("icon-0223-997");
			currencyTypeText.text = CommonFunc.I18nGetLocalizedValue("I18N_Package_Currency_Bone");
			break;
		}
		currentCount.text = "1";
	}

	public void Show(PackageItemData _packageItemData)
	{
		isOpen = true;
		packageController.transform.Find("Panel").GetComponent<CanvasGroup>().interactable = false;
		isClosing = false;
		packageItemData = _packageItemData;
		Init();
		InputDeviceDetector.instance.PushJoyStack();
		EventSystem.current.SetSelectedGameObject(moneySlider.gameObject);
		m_CanvasGroup.alpha = 1f;
		m_CanvasGroup.interactable = true;
		m_CanvasGroup.blocksRaycasts = true;
	}

	public void Hide()
	{
		isOpen = false;
		packageController.transform.Find("Panel").GetComponent<CanvasGroup>().interactable = true;
		isClosing = true;
		m_CanvasGroup.alpha = 0f;
		m_CanvasGroup.interactable = false;
		m_CanvasGroup.blocksRaycasts = false;
		InputDeviceDetector.instance.ResetJoyCurce();
	}
}
