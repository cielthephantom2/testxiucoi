using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using Spine.Unity;
using SuperScrollView;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class EvolutionWGController : MonoBehaviour
{
	private Transform CreatePanel1;

	[HideInInspector]
	public Transform CreatePanel2;

	private Transform CreatePanel3;

	private LoopGridView _packageLoopGrid;

	private List<PackageItemData> _mPackageDataSourceMgrFilter = new List<PackageItemData>();

	private PackageItemData _selectedPackageItem;

	private readonly PackagerFunction packagerFunction = PackagerFunction.Wugong;

	private string _packageTopFilter = "00000000100";

	private string _packageSubFilter = "";

	private string _tmpTopFilter = "00000000100";

	private string _tmpSubFilter = "";

	private Sprite _normalSprite;

	private Sprite _selectedSprite;

	private CharaData _charaData;

	private GameObject _selectedWugong;

	private PackageIconController _packageIconController;

	public Dictionary<string, TraitIconController> _traitDict = new Dictionary<string, TraitIconController>();

	[HideInInspector]
	public string currentSelectTraitIndex = "1";

	private gang_b03Table.Row _b03TaritEffectRow;

	private PointerEventData pointerEventData;

	private bool isPanel0EffectFinish = true;

	private bool isNeedFullTrait;

	private Transform ConfirmBtn;

	private Transform infoPanel;

	private Sprite _canNotForgeSprit;

	private Sprite _canForgeSprit;

	public GameObject SelectPanel;

	private PackageFilterPanelType packageFilterPanelType = PackageFilterPanelType.Equip;

	private PackageFilterType packageFilterType;

	private PackageSortType packageSortType;

	private GameObject FilterBtn;

	private void Start()
	{
		SharedData.Instance().OpenPackagerFunction = PackagerFunction.PlayerPackage;
		if (SharedData.Instance().m_MapController != null)
		{
			SharedData.Instance().m_MapController.m_AudioSource.Pause();
		}
		InputDeviceDetector.instance.ClearJoyStack();
		CreateWGController.enhanceWuGongType = EnhanceWuGongType.Break;
		_normalSprite = Resources.Load("images/01-border/boder-20231228-button-03", typeof(Sprite)) as Sprite;
		_selectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		_canNotForgeSprit = Resources.Load("images/01-border/boder-20231228-06", typeof(Sprite)) as Sprite;
		_canForgeSprit = Resources.Load("images/01-border/boder-20231228-highlihgt-01", typeof(Sprite)) as Sprite;
		CreatePanel1 = base.transform.Find("Panel1");
		CreatePanel2 = base.transform.Find("Panel2");
		CreatePanel3 = base.transform.Find("Panel3");
		SelectPanel = base.transform.Find("Panel1/WugongList/Select").gameObject;
		FilterBtn = base.transform.Find("Panel1/WugongList/FilterPanel").gameObject;
		CreatePanel1.transform.Find("HoverWuGong/Warning").gameObject.SetActive(value: false);
		_packageLoopGrid = GetComponentInChildren<LoopGridView>();
		_packageLoopGrid.InitGridView(_mPackageDataSourceMgrFilter.Count, OnGetPackageItemByRowColumn);
		RefreshPackageUIList();
		_charaData = SharedData.Instance().CurrentCharaData;
		_packageIconController = CreatePanel2.Find("Traits/Wugong").GetComponent<PackageIconController>();
		for (int i = 1; i <= 4; i++)
		{
			_traitDict.Add(i.ToString(), CreatePanel2.Find("Traits/Trait|" + i).GetComponent<TraitIconController>());
			_traitDict[i.ToString()].InitTraitIcon("");
		}
		Button[] componentsInChildren = base.transform.GetComponentsInChildren<Button>(includeInactive: true);
		for (int j = 0; j < componentsInChildren.Length; j++)
		{
			EventTriggerListener.Get(componentsInChildren[j].gameObject).onClick = OnButtonClick;
		}
		infoPanel = base.transform.Find("Info");
		ConfirmBtn = CreatePanel2.Find("Confirm");
		StartCoroutine(ExecuteAfterAllStart());
		SharedData.Instance().evolutionWgController = this;
	}

	private void Update()
	{
		if (infoPanel.gameObject.activeSelf && (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame()))
		{
			StartCoroutine(DelayControllInfoPanel(active: false));
		}
		else
		{
			if (!isPanel0EffectFinish)
			{
				return;
			}
			if (InputSystemCustom.Instance().UI.ConfirmCreateWugong.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				if (CreatePanel1.gameObject.activeInHierarchy)
				{
					ExecuteEvents.Execute(CreatePanel1.Find("Next").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
				}
				else if (CreatePanel2.gameObject.activeInHierarchy)
				{
					ExecuteEvents.Execute(CreatePanel2.Find("Confirm").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
				}
				else if (CreatePanel3.gameObject.activeInHierarchy)
				{
					ExecuteEvents.Execute(CreatePanel3.Find("ConfirmDone").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
				}
			}
			else if (InputSystemCustom.Instance().UI.BackCreateWugong.WasReleasedThisFrame())
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(CreatePanel2.Find("Back").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && SharedData.Instance().m_TraitPackageController.isOpen.Equals(obj: false))
			{
				pointerEventData = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(base.transform.Find("TopBanner/Return").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (InputSystemCustom.Instance().UI.PackageFilter.WasReleasedThisFrame())
			{
				OnButtonClick(FilterBtn);
			}
			else if (InputSystemCustom.Instance().UI.ShowFullName.WasReleasedThisFrame())
			{
				ExecuteEvents.Execute(base.transform.Find("Panel1/WugongList/FullNameArea/FullName").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
	}

	private IEnumerator DelayControllInfoPanel(bool active)
	{
		yield return null;
		base.transform.GetComponent<CanvasGroup>().interactable = !active;
		infoPanel.gameObject.SetActive(active);
	}

	private IEnumerator ExecuteAfterAllStart()
	{
		yield return null;
		EventSystem.current.SetSelectedGameObject(_selectedWugong);
		OnButtonClickWugong(_selectedWugong.GetComponent<Button>());
	}

	private LoopGridViewItem OnGetPackageItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		PackageItemData packageItemData = _mPackageDataSourceMgrFilter[index];
		if (packageItemData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("PackageIcon");
		PackageIconController component = loopGridViewItem.GetComponent<PackageIconController>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		component.InitPackageIcon(packageItemData, isShowHeadIcoN: false);
		EventTriggerListener.Get(loopGridViewItem.gameObject).onClick = OnButtonClick;
		return loopGridViewItem;
	}

	private void RefreshPackageUIList()
	{
		List<PackageItemData> packageList = PackageController.GetPackageList(packagerFunction, packageSortType);
		packageList.RemoveAll((PackageItemData t) => !PackageController.CouldPassUseFilter(t.b07Row, _tmpTopFilter, _tmpSubFilter, isFilterBtnActive: true, _packageTopFilter, _packageSubFilter));
		packageList.RemoveAll((PackageItemData t) => t.b07Row.Name_Trans.StartsWith("★ "));
		_mPackageDataSourceMgrFilter = packageList;
		int num = 4 - _mPackageDataSourceMgrFilter.Count % 4;
		if (num == 0)
		{
			num = 4;
		}
		while (--num >= 0)
		{
			_mPackageDataSourceMgrFilter.Add(new PackageItemData
			{
				ID = num.ToString()
			});
		}
		_packageLoopGrid.SetListItemCount(_mPackageDataSourceMgrFilter.Count, resetPos: false);
		_packageLoopGrid.RefreshAllShownItem();
		int num2 = -1;
		if (_selectedPackageItem != null)
		{
			PackageItemData item = _mPackageDataSourceMgrFilter.Find((PackageItemData x) => x.ID.Equals(_selectedPackageItem.ID));
			num2 = _mPackageDataSourceMgrFilter.IndexOf(item);
		}
		if (num2 == -1)
		{
			num2 = 0;
		}
		_selectedPackageItem = _mPackageDataSourceMgrFilter[num2];
		_packageLoopGrid.MovePanelToItemByIndex(num2);
		StartCoroutine(DelayClickSelectedWugong());
	}

	private IEnumerator DelayClickSelectedWugong()
	{
		yield return null;
		string n = "Viewport/Content/ItemBtn|" + _selectedPackageItem.ID + "|" + ((_selectedPackageItem.b07Row != null) ? _selectedPackageItem.b07Row.Use : "") + "|" + ((_selectedPackageItem.userData != null) ? _selectedPackageItem.userData.m_Id : "null");
		_selectedWugong = _packageLoopGrid.transform.Find(n)?.gameObject;
		InputDeviceDetector.instance.ClearJoyStack();
		EventSystem.current.SetSelectedGameObject(_selectedWugong);
		OnButtonClickWugong(_selectedWugong.GetComponent<Button>());
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || !isPanel0EffectFinish || infoPanel.gameObject.activeSelf)
		{
			return;
		}
		Button component = go.GetComponent<Button>();
		string[] array = component.name.Split('|');
		if (array[0] == "Return")
		{
			ExitScene();
		}
		else if (go.name.Equals("Next"))
		{
			if (_selectedWugong.GetComponent<PackageIconController>().itemData.b07Row != null)
			{
				CreatePanel1.gameObject.SetActive(value: false);
				CreatePanel2.gameObject.SetActive(value: true);
				CreatePanel3.gameObject.SetActive(value: false);
				EventSystem.current.SetSelectedGameObject(CreatePanel2.Find("Traits/Trait|1/Btn").gameObject);
				RefreshTraitEffect(isNeedBeforeB03: false);
				_packageIconController.GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(_b03TaritEffectRow.BookIcon);
			}
		}
		else if (go.name.Equals("Back"))
		{
			CreatePanel1.gameObject.SetActive(value: true);
			CreatePanel2.gameObject.SetActive(value: false);
			CreatePanel3.gameObject.SetActive(value: false);
			foreach (KeyValuePair<string, TraitIconController> item in _traitDict)
			{
				item.Value.GetComponent<TraitIconController>().InitTraitIcon("");
			}
			_b03TaritEffectRow = null;
			EventSystem.current.SetSelectedGameObject(_selectedWugong);
			OnButtonClick(_selectedWugong);
		}
		else if (go.name.Equals("Confirm"))
		{
			if (go.GetComponent<Image>().sprite != _canForgeSprit)
			{
				StartCoroutine(DelayControllInfoPanel(active: true));
				infoPanel.transform.Find("Banner1/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_CreateWugong_Cant_Info");
				return;
			}
			CreatePanel1.gameObject.SetActive(value: false);
			CreatePanel2.gameObject.SetActive(value: false);
			CreatePanel3.gameObject.SetActive(value: true);
			KongFuData kfdata = new KongFuData
			{
				kf = _b03TaritEffectRow,
				lv = int.Parse(_b03TaritEffectRow.LV),
				exp = 0f,
				proficiency = 0
			};
			float num = 0f;
			if (_b03TaritEffectRow.Star.Equals("10"))
			{
				SkeletonGraphic[] componentsInChildren = CreatePanel3.Find("Effect_Special").GetComponentsInChildren<SkeletonGraphic>(includeInactive: true);
				foreach (SkeletonGraphic skeletonGraphic in componentsInChildren)
				{
					if (CommonFunc.ShortLangSel("CN", "EN", "CN").Equals(skeletonGraphic.gameObject.name))
					{
						skeletonGraphic.gameObject.SetActive(value: true);
						skeletonGraphic.AnimationState.SetAnimation(0, "animation", loop: false);
						skeletonGraphic.AnimationState.Complete += delegate
						{
							isPanel0EffectFinish = true;
						};
					}
					else
					{
						skeletonGraphic.gameObject.SetActive(value: false);
					}
				}
				num = 1.23f;
			}
			else
			{
				SkeletonGraphic componentInChildren = CreatePanel3.Find("Effect_Normal").GetComponentInChildren<SkeletonGraphic>(includeInactive: true);
				componentInChildren.gameObject.SetActive(value: true);
				componentInChildren.AnimationState.SetAnimation(0, "animation", loop: false);
				componentInChildren.AnimationState.Complete += delegate
				{
					isPanel0EffectFinish = true;
				};
				num = 0.21f;
			}
			CreatePanel3.Find("HoverWuGong").gameObject.SetActive(value: false);
			DOVirtual.DelayedCall(num, delegate
			{
				Transform obj = CreatePanel3.Find("HoverWuGong");
				obj.gameObject.SetActive(value: true);
				CanvasGroup component4 = obj.GetComponent<CanvasGroup>();
				component4.alpha = 0f;
				component4.DOFade(1f, 0.2f);
				SkillHoverShowInfo.SetHoverWugongItem(null, kfdata, CreatePanel3.Find("HoverWuGong"));
			});
		}
		else if (go.name.Equals("ConfirmDone"))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1035");
			PackageIconController component2 = _selectedWugong.GetComponent<PackageIconController>();
			gang_b07Table.Row b07Row = component2.b07Row;
			gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(component2.b07Row.Relateid);
			gang_b07Table.Row row2 = JsonUtility.FromJson<gang_b07Table.Row>(JsonUtility.ToJson(b07Row));
			gang_b03Table.Row row3 = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(_b03TaritEffectRow));
			string text = Guid.NewGuid().ToString();
			row2.ID = "MB03_" + row.ID + "_" + text;
			row2.Relateid = row2.ID;
			row3.ID = row2.ID;
			row2.Name = "★ " + row2.Name;
			row2.Name_EN = "★ " + row2.Name_EN;
			row3.Name = "★ " + row3.Name;
			row3.Name_EN = "★ " + row3.Name_EN;
			CommonResourcesData.b07.GetRowList().Add(row2);
			CommonResourcesData.b07append.Add(row2);
			CommonResourcesData.b03.GetRowList().Add(row3);
			CommonResourcesData.b03append.Add(row3);
			if (row3.Star.Equals("10"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1034");
			}
			SharedData.Instance().PackageAdd(row2.ID, 1);
			foreach (KeyValuePair<string, TraitIconController> item2 in _traitDict)
			{
				TraitIconController component3 = item2.Value.GetComponent<TraitIconController>();
				if (component3.traitItemData.b06Row != null)
				{
					_charaData.m_TraitList.Remove(component3.traitItemData.b06Row.id);
					for (int j = 1; j < 9; j++)
					{
						if (_charaData.m_EquipTraitDict[j.ToString()].Equals(component3.traitItemData.b06Row.id))
						{
							_charaData.m_EquipTraitDict[j.ToString()] = "";
						}
					}
				}
				component3.InitTraitIcon("");
			}
			CreatePanel1.gameObject.SetActive(value: true);
			CreatePanel2.gameObject.SetActive(value: false);
			CreatePanel3.gameObject.SetActive(value: false);
			foreach (KeyValuePair<string, TraitIconController> item3 in _traitDict)
			{
				item3.Value.GetComponent<TraitIconController>().InitTraitIcon("");
			}
			_selectedPackageItem.b07Row = row2;
			_selectedPackageItem.ID = row2.ID;
			_selectedPackageItem.number = 1;
			_selectedPackageItem.originPrice = int.Parse(row2.Value);
			_selectedPackageItem.effectPrice = int.Parse(row2.Value);
			_selectedPackageItem.userData = null;
			RefreshPackageUIList();
		}
		else if (array[0] == "ItemBtn")
		{
			OnButtonClickWugong(component);
		}
		else if (go.transform.parent.name.StartsWith("Trait"))
		{
			InputDeviceDetector.instance.PushJoyStack();
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, TraitIconController> item4 in _traitDict)
			{
				if (item4.Value.traitItemData.b06Row != null)
				{
					list.Add(item4.Value.traitItemData.b06Row.id);
				}
			}
			foreach (KeyValuePair<string, string> item5 in _charaData.m_EquipTraitDict)
			{
				list.Add(item5.Value);
			}
			string currentEffectTraitID = "";
			currentSelectTraitIndex = go.transform.parent.name.Split('|')[1];
			if (_traitDict[currentSelectTraitIndex].traitItemData.b06Row != null)
			{
				currentEffectTraitID = _traitDict[currentSelectTraitIndex].traitItemData.b06Row.id;
			}
			SharedData.Instance().m_TraitPackageController.OpenTraitPackage(TraitPackageType.AllTraits, _charaData.m_TraitList, "", list, currentEffectTraitID);
		}
		else if (array[0].Equals("FilterPanel"))
		{
			SelectPanel.gameObject.SetActive(!SelectPanel.gameObject.activeSelf);
			_packageLoopGrid.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
			if (SelectPanel.gameObject.activeSelf)
			{
				CommonResourcesData.inputDeviceDetector.PushJoyStack();
				if (packageFilterPanelType.Equals(PackageFilterPanelType.Equip))
				{
					EventSystem.current.SetSelectedGameObject(SelectPanel.transform.Find("Viewport/Content/Sorter|Forward|Fix").gameObject);
				}
			}
			else
			{
				CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
			}
		}
		else if (array[0] == "Filter")
		{
			if (array[1].Equals("Use"))
			{
				_packageTopFilter = array[2];
				_packageSubFilter = "";
				if (array.Length >= 4)
				{
					_packageSubFilter = array[3];
				}
			}
			if (go.name == "Filter|Use|1111111111||Fix")
			{
				FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter");
			}
			else
			{
				FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter") + " : " + go.transform.Find("Text").GetComponent<Text>().text;
			}
			_selectedWugong = null;
			if (array[1].Equals("Use"))
			{
				RefreshPackageUIList();
			}
			SelectPanel.gameObject.SetActive(value: false);
			_packageLoopGrid.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
		}
		else if (array[0] == "Sorter")
		{
			switch (array[1])
			{
			case "Forward":
				packageSortType = PackageSortType.Forward;
				break;
			case "Reverse":
				packageSortType = PackageSortType.Reverse;
				break;
			case "Resort":
				packageSortType = PackageSortType.Resort;
				break;
			}
			_selectedWugong = null;
			RefreshPackageUIList();
			SelectPanel.gameObject.SetActive(value: false);
			_packageLoopGrid.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
			SelectPanel.transform.Find("Viewport/Content/Sorter|Forward|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Forward) ? CommonResourcesData.SelectedSprite : CommonResourcesData.NormalPackageIconSprite);
			SelectPanel.transform.Find("Viewport/Content/Sorter|Reverse|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Reverse) ? CommonResourcesData.SelectedSprite : CommonResourcesData.NormalPackageIconSprite);
			SelectPanel.transform.Find("Viewport/Content/Sorter|Resort|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Resort) ? CommonResourcesData.SelectedSprite : CommonResourcesData.NormalPackageIconSprite);
		}
		else
		{
			if (!array[0].StartsWith("FullName"))
			{
				return;
			}
			SharedData.Instance().isShowFullName = !SharedData.Instance().isShowFullName;
			if (SharedData.Instance().isShowFullName)
			{
				base.transform.Find("Panel1/WugongList/FullNameArea/FullName/Checkmark").gameObject.SetActive(value: true);
			}
			else
			{
				base.transform.Find("Panel1/WugongList/FullNameArea/FullName/Checkmark").gameObject.SetActive(value: false);
			}
			foreach (PackageIconController item6 in _packageLoopGrid.GetComponentsInChildren<PackageIconController>(includeInactive: true).ToList())
			{
				item6.transform.Find("FullName").gameObject.SetActive(SharedData.Instance().isShowFullName);
				item6.transform.Find("FullInfo").gameObject.SetActive(!SharedData.Instance().isShowFullName);
			}
		}
	}

	private void OnButtonClickWugong(Button btn)
	{
		if (_selectedWugong != null)
		{
			_selectedWugong.GetComponent<Image>().sprite = _normalSprite;
		}
		_selectedWugong = btn.gameObject;
		_selectedWugong.GetComponent<Image>().sprite = _selectedSprite;
		PackageIconController component = btn.GetComponent<PackageIconController>();
		component.HideNewInfo();
		if (component.b07Row == null)
		{
			CreatePanel1.Find("HoverWuGong").gameObject.SetActive(value: false);
			CreatePanel1.Find("Next").GetComponent<Button>().interactable = false;
			return;
		}
		CreatePanel1.Find("Next").GetComponent<Button>().interactable = true;
		CreatePanel1.Find("HoverWuGong").gameObject.SetActive(value: true);
		gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(component.b07Row.Relateid);
		KongFuData kfdata = new KongFuData
		{
			kf = row,
			lv = int.Parse(row.LV),
			exp = 0f,
			proficiency = 0
		};
		SkillHoverShowInfo.SetHoverWugongItem(null, kfdata, CreatePanel1.Find("HoverWuGong"));
	}

	public void RefreshTraitEffect(bool isNeedBeforeB03 = true)
	{
		string relateid = _selectedWugong.GetComponent<PackageIconController>().b07Row.Relateid;
		gang_b03Table.Row row = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(CommonResourcesData.b03.Find_ID(relateid)));
		gang_b03Table.Row originB03Row = row;
		if (_b03TaritEffectRow != null)
		{
			originB03Row = JsonUtility.FromJson<gang_b03Table.Row>(JsonUtility.ToJson(_b03TaritEffectRow));
		}
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, TraitIconController> item in _traitDict)
		{
			if (item.Value.traitItemData.b06Row != null)
			{
				list.Add(item.Value.traitItemData.b06Row.id);
			}
		}
		CreatePanel2.Find("Confirm").GetComponent<Button>().interactable = list.Count >= 1;
		_b03TaritEffectRow = CreateWGController.RefreshTraitEffectBasic(row, list);
		KongFuData kfdata = new KongFuData
		{
			kf = _b03TaritEffectRow,
			lv = int.Parse(_b03TaritEffectRow.LV),
			exp = 0f,
			proficiency = 0
		};
		if (!isNeedBeforeB03)
		{
			originB03Row = null;
		}
		bool flag = true;
		foreach (KeyValuePair<string, TraitIconController> item2 in _traitDict)
		{
			if (item2.Value.traitItemData == null || item2.Value.traitItemData.b06Row == null)
			{
				flag = false;
				break;
			}
		}
		if (!flag && isNeedFullTrait)
		{
			ConfirmBtn.GetComponent<Image>().sprite = _canNotForgeSprit;
		}
		else
		{
			ConfirmBtn.GetComponent<Image>().sprite = _canForgeSprit;
		}
		SkillHoverShowInfo.SetHoverWugongItem(null, kfdata, CreatePanel2.Find("HoverWuGong"), showCharacterIcon: false, originB03Row);
	}

	private void ExitScene()
	{
		if (SharedData.Instance().m_MapController != null)
		{
			SharedData.Instance().m_MapController.m_AudioSource.Play();
		}
		InputDeviceDetector.instance.ClearJoyStack();
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			int index = SharedData.Instance().LoadedSceneStack.Count - 1;
			SharedData.Instance().LoadedSceneStack.RemoveAt(index);
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				index = SharedData.Instance().LoadedSceneStack.Count - 1;
				SceneManager.LoadScene(SharedData.Instance().LoadedSceneStack[index], LoadSceneMode.Additive);
			}
		}
		SharedData.Instance().m_Transfer_Info = "";
		SceneManager.UnloadSceneAsync("EvolutionWG");
	}
}
