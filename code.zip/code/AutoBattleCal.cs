using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using SuperTiled2Unity;
using UnityEngine;

public class AutoBattleCal
{
	private static List<BattleObject> allies = new List<BattleObject>();

	private static List<BattleObject> opponents = new List<BattleObject>();

	protected const float MovementBlockSize = 50f;

	public static BestActionInfo m_BestActionInfo = new BestActionInfo();

	public static List<BestActionInfo> m_BestActionInfoList = new List<BestActionInfo>();

	private static int maxAttackNumber = 0;

	private static int maxDamgeNumber = 0;

	private static int maxAlliesDis = 0;

	private static int maxEnemiesDis = 0;

	private static float maxTerrainDamgeValue = 1f;

	private static List<float> moveToPosCouse = new List<float>();

	public static Dictionary<Vector3Int, List<Vector3Int>> alreadyAStarPathDict = new Dictionary<Vector3Int, List<Vector3Int>>();

	public static Dictionary<List<Vector3Int>, float> AStarPathDamageDict = new Dictionary<List<Vector3Int>, float>();

	public static IEnumerator AutoMoveAction()
	{
		BattleObject current = SharedData.Instance().m_BattleController.current;
		List<BattleObject> list = new List<BattleObject>();
		allies = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race == current.race);
		opponents = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race != current.race);
		foreach (BattleObject opponent in opponents)
		{
			if (!opponent.isDead)
			{
				Vector3Int gridPosition = opponent.GetGridPosition();
				if (current.AttackForecastRange.ContainsKey(gridPosition))
				{
					list.Add(opponent);
				}
			}
		}
		BattleObject battleObject = ((current.GetBuffByName("Spit") != null) ? SharedData.Instance().m_BattleController.allBattleObjs.Find((BattleObject x) => x.name == current.GetBuffByName("Spit").source.Split("|")[2]) : null);
		if (battleObject != null && !battleObject.isDead && !current.CheckBuffEffectOn("Dizzy"))
		{
			if (list.Contains(battleObject))
			{
				BattleObject battleObject2 = battleObject;
				Vector3Int spitObjPos = battleObject2.GetGridPosition();
				List<Forecast> list2 = new List<Forecast>();
				foreach (KeyValuePair<Vector3Int, List<Forecast>> item in current.AttackForecastDict)
				{
					List<Forecast> collection = item.Value.FindAll((Forecast x) => x.effectPosList.Contains(spitObjPos));
					list2.AddRange(collection);
				}
				int index = Random.Range(0, list2.Count);
				current.currentForecast = list2[index];
				Vector3Int actionPos = current.currentForecast.actionPos;
				SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos);
				if (!actionPos.Equals(current.GetGridPosition()))
				{
					AStarAlgorithmBattleField.Move(current, actionPos);
				}
				else
				{
					current.SetBattleObjState(BattleObjectState.ActionInit);
				}
			}
			else
			{
				List<BattleObject> list3 = new List<BattleObject>();
				list3.Add(battleObject);
				current.currentForecast = null;
				Vector3Int position = AStarAlgorithmBattleField.Trace(current, list3);
				SharedData.Instance().m_BattleController.m_curcor.SetPosition(position);
				AStarAlgorithmBattleField.TraceMove(current);
			}
		}
		else
		{
			string nextAction = GetNextAction(current);
			BestActionInfo bestActionInfo = GetBestActionInfo(current, nextAction);
			if (bestActionInfo.skill == "" && bestActionInfo.itemID == "")
			{
				switch (nextAction)
				{
				case "Attack":
					current.currentForecast = null;
					if (bestActionInfo.actionPos.Equals(current.GetGridPosition()) || bestActionInfo.actionPos.Equals(Vector3Int.zero))
					{
						SharedData.Instance().m_BattleController.RecoveryCurrentMp();
						break;
					}
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(bestActionInfo.actionPos);
					AStarAlgorithmBattleField.Move(current, bestActionInfo.actionPos);
					break;
				case "Heal":
					current.prevRoundIsHeal = true;
					current.currentForecast = null;
					if (!bestActionInfo.actionPos.Equals(current.GetGridPosition()))
					{
						AStarAlgorithmBattleField.Move(current, bestActionInfo.actionPos);
					}
					break;
				case "Escape":
				{
					current.CheckBuffEffectOn("Fear");
					Vector3Int actionPos4 = bestActionInfo.actionPos;
					if (actionPos4.Equals(current.GetGridPosition()))
					{
						SharedData.Instance().m_BattleController.RecoveryCurrentMp();
						break;
					}
					current.currentForecast = null;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos4);
					AStarAlgorithmBattleField.Move(current, actionPos4);
					break;
				}
				case "Rest":
					if (!current.CheckBuffEffectOn("Dizzy"))
					{
						current.CheckBuffEffectOn("Fear");
					}
					SharedData.Instance().m_BattleController.RecoveryCurrentMp();
					break;
				case "BlindWalk":
				{
					Vector3Int actionPos3 = bestActionInfo.actionPos;
					if (actionPos3.Equals(current.GetGridPosition()))
					{
						SharedData.Instance().m_BattleController.RecoveryCurrentMp();
						break;
					}
					current.currentForecast = null;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos3);
					AStarAlgorithmBattleField.Move(current, actionPos3);
					break;
				}
				case "MoveTarget":
				{
					current.CheckBuffEffectOn("Fear");
					Vector3Int actionPos2 = bestActionInfo.actionPos;
					if (actionPos2.Equals(current.GetGridPosition()))
					{
						SharedData.Instance().m_BattleController.RecoveryCurrentMp();
						break;
					}
					current.currentForecast = null;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos2);
					AStarAlgorithmBattleField.Move(current, actionPos2);
					break;
				}
				}
			}
			else
			{
				switch (nextAction)
				{
				case "Attack":
				{
					current.currentForecast = new Forecast();
					current.currentForecast.actionName = bestActionInfo.skill;
					current.currentForecast.targetPos = bestActionInfo.targetPos;
					current.currentForecast.actionPos = bestActionInfo.actionPos;
					Vector3Int actionPos7 = current.currentForecast.actionPos;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos7);
					if (!actionPos7.Equals(current.GetGridPosition()))
					{
						AStarAlgorithmBattleField.Move(current, actionPos7);
					}
					else
					{
						current.SetBattleObjState(BattleObjectState.ActionInit);
					}
					break;
				}
				case "Heal":
				{
					current.currentForecast = new Forecast();
					current.currentForecast.actionName = bestActionInfo.skill;
					current.currentForecast.targetPos = bestActionInfo.targetPos;
					current.currentForecast.actionPos = bestActionInfo.actionPos;
					Vector3Int actionPos6 = current.currentForecast.actionPos;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos6);
					if (!actionPos6.Equals(current.GetGridPosition()))
					{
						AStarAlgorithmBattleField.Move(current, actionPos6);
					}
					else
					{
						current.SetBattleObjState(BattleObjectState.ActionInit);
					}
					break;
				}
				case "Escape":
				{
					current.CheckBuffEffectOn("Fear");
					current.currentForecast = new Forecast();
					current.currentForecast.actionName = bestActionInfo.skill;
					current.currentForecast.targetPos = bestActionInfo.targetPos;
					current.currentForecast.actionPos = bestActionInfo.actionPos;
					Vector3Int actionPos8 = current.currentForecast.actionPos;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos8);
					if (!actionPos8.Equals(current.GetGridPosition()))
					{
						AStarAlgorithmBattleField.Move(current, actionPos8);
					}
					else
					{
						current.SetBattleObjState(BattleObjectState.ActionInit);
					}
					break;
				}
				case "MoveTarget":
				{
					current.CheckBuffEffectOn("Fear");
					current.currentForecast = new Forecast();
					current.currentForecast.actionName = bestActionInfo.skill;
					current.currentForecast.targetPos = bestActionInfo.targetPos;
					current.currentForecast.actionPos = bestActionInfo.actionPos;
					Vector3Int actionPos5 = current.currentForecast.actionPos;
					SharedData.Instance().m_BattleController.m_curcor.SetPosition(actionPos5);
					if (!actionPos5.Equals(current.GetGridPosition()))
					{
						AStarAlgorithmBattleField.Move(current, actionPos5);
					}
					else
					{
						current.SetBattleObjState(BattleObjectState.ActionInit);
					}
					break;
				}
				}
			}
		}
		yield return new WaitForSeconds(0.1f);
	}

	public static string GetNextAction(BattleObject current)
	{
		if (current.CheckBuffEffectOn("Dizzy"))
		{
			return "Rest";
		}
		if (current.CheckBuffEffectOn("Fear"))
		{
			if (current.m_couldEscape)
			{
				return "Escape";
			}
			return "Rest";
		}
		if (current.CheckBuffEffectOn("Blind"))
		{
			return "BlindWalk";
		}
		if (current.race == "enemy" && current.charadata.originRace == "enemy" && current.m_AiType.Split("|").Length == 4)
		{
			string name = current.m_AiType.Split("|")[3];
			SuperObject[] byName = SharedData.Instance().m_BattleController.getByName(name);
			foreach (SuperObject superObject in byName)
			{
				_ = superObject.transform.position;
				Vector3Int zero = Vector3Int.zero;
				zero.x = Mathf.FloorToInt(superObject.transform.position.x / 50f);
				zero.y = Mathf.FloorToInt(Mathf.Abs(superObject.transform.position.y) / 50f);
				current.targetGridList.Add(zero);
			}
			return "MoveTarget";
		}
		float hp = current.charadata.m_Hp;
		float battleValueByName = current.charadata.GetBattleValueByName("HP");
		string text = "10005";
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		float num4 = 1f;
		string text2 = "Rest";
		if (current.m_AiType != "0")
		{
			text = current.m_AiType.Split("|")[2];
			gang_b14Table.Row row = CommonResourcesData.b14.Find_ID(text);
			if (hp / battleValueByName > 0.8f)
			{
				num = float.Parse(row.SafeAtkRate, CultureInfo.InvariantCulture);
				num2 = float.Parse(row.SafeHealRate, CultureInfo.InvariantCulture);
				num4 = float.Parse(row.SafeRestRate, CultureInfo.InvariantCulture);
				num3 = float.Parse(row.SafeEscapeRate, CultureInfo.InvariantCulture);
			}
			else if (hp / battleValueByName > 0.2f)
			{
				num = float.Parse(row.InjuredAtkRate, CultureInfo.InvariantCulture);
				num2 = float.Parse(row.InjuredHealRate, CultureInfo.InvariantCulture);
				num4 = float.Parse(row.InjuredRestRate, CultureInfo.InvariantCulture);
				num3 = float.Parse(row.InjuredEscapeRate, CultureInfo.InvariantCulture);
			}
			else
			{
				num = float.Parse(row.NearDeathAtkRate, CultureInfo.InvariantCulture);
				num2 = float.Parse(row.NearDeathHealRate, CultureInfo.InvariantCulture);
				num4 = float.Parse(row.NearDeathRestRate, CultureInfo.InvariantCulture);
				num3 = float.Parse(row.NearDeathEscapeRate, CultureInfo.InvariantCulture);
			}
			if (!current.m_couldAttack)
			{
				num = 0f;
			}
			if ((!current.m_couldHealHp || !isAnyoneNeedHealHp(current)) && !current.m_couldAddBuff)
			{
				num2 = 0f;
				current.prevRoundIsHeal = false;
			}
			if (!current.m_couldEscape)
			{
				num3 = 0f;
			}
			int num5 = 0;
			int num6 = 0;
			foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
			{
				if (!allBattleObj.isDead)
				{
					if (allBattleObj.race == "player")
					{
						num5++;
					}
					else
					{
						num6++;
					}
				}
			}
			if (num5 == 0 || num6 == 0)
			{
				num = 1f;
				num2 = 0f;
				num4 = 0f;
				num3 = 0f;
			}
			int num7 = 0;
			int num8 = 0;
			foreach (BattleObject allBattleObj2 in SharedData.Instance().m_BattleController.allBattleObjs)
			{
				if (!allBattleObj2.isDead && !(allBattleObj2 == current))
				{
					if (allBattleObj2.race == "player" && allBattleObj2.isSelectable)
					{
						num7++;
					}
					else if (allBattleObj2.race == "enemy" && allBattleObj2.isSelectable)
					{
						num8++;
					}
				}
			}
			if (current.race == "player" && num8 == 0)
			{
				num = 0f;
				num3 = 0f;
				num2 = 0f;
			}
			if (current.race == "enemy" && num7 == 0)
			{
				num = 0f;
				num3 = 0f;
				num2 = 0f;
			}
			if (num + num2 + num4 + num3 == 0f)
			{
				num4 = 1f;
				UnityEngine.Debug.LogWarning("Battle AI : obj = [" + current.name + "] get action rate wrong!");
			}
			else
			{
				num /= num + num2 + num4 + num3;
				num2 /= num + num2 + num4 + num3;
				num4 /= num + num2 + num4 + num3;
				num3 /= num + num2 + num4 + num3;
			}
		}
		float num9 = Random.Range(0f, 1f);
		if (num9 < num)
		{
			text2 = "Attack";
		}
		else if (num9 < num + num2)
		{
			text2 = "Heal";
		}
		else if (num9 < num + num2 + num3)
		{
			text2 = "Escape";
		}
		else if (num9 < num + num2 + num3 + num4)
		{
			text2 = "Rest";
		}
		if (current.prevRoundIsHeal && text2 == "Attack")
		{
			text2 = "Heal";
			current.prevRoundIsHeal = false;
		}
		return text2;
	}

	public static BestActionInfo GetBestActionInfo(BattleObject _BattleObject, string m_ActionType)
	{
		m_BestActionInfo = new BestActionInfo();
		m_BestActionInfoList.Clear();
		maxAttackNumber = 0;
		maxDamgeNumber = 0;
		maxAlliesDis = 0;
		maxEnemiesDis = 0;
		maxTerrainDamgeValue = 1f;
		switch (m_ActionType)
		{
		case "Attack":
			GetBestAttackActionInfo(_BattleObject);
			if (m_BestActionInfo.skill == "")
			{
				GetBestTraceActionInfo(_BattleObject);
			}
			break;
		case "Heal":
			if (_BattleObject.m_couldHealHp && isAnyoneNeedHealHp(_BattleObject))
			{
				GetBestHealActionInfo(_BattleObject);
			}
			if (m_BestActionInfo.skill == "" && _BattleObject.m_couldAddBuff)
			{
				GetBestAddBuffActionInfo(_BattleObject);
			}
			if (m_BestActionInfo.skill == "")
			{
				GetBestHealToAttackActionInfo(_BattleObject);
			}
			break;
		case "Escape":
			GetBestEscapeActionInfo(_BattleObject);
			break;
		case "BlindWalk":
		{
			m_BestActionInfo.actionPos = _BattleObject.GetGridPosition();
			if (_BattleObject.standPosList.ContainsValue(5))
			{
				List<Vector3Int> list = new List<Vector3Int>();
				foreach (KeyValuePair<Vector3Int, int> standPos in _BattleObject.standPosList)
				{
					if (standPos.Value < 4)
					{
						list.Add(standPos.Key);
					}
				}
				foreach (Vector3Int item in list)
				{
					_BattleObject.standPosList.Remove(item);
				}
			}
			_BattleObject.standPosList.Remove(m_BestActionInfo.actionPos);
			if (_BattleObject.standPosList.Count <= 0)
			{
				break;
			}
			int num = Random.Range(0, _BattleObject.standPosList.Count);
			int num2 = 0;
			foreach (KeyValuePair<Vector3Int, int> standPos2 in _BattleObject.standPosList)
			{
				if (num == num2)
				{
					m_BestActionInfo.actionPos = standPos2.Key;
					break;
				}
				num2++;
			}
			break;
		}
		case "MoveTarget":
			GetBestEscapeActionInfo(_BattleObject, isTargetMove: true);
			break;
		}
		return m_BestActionInfo;
	}

	private static BestActionInfo CalParetoGetBestActionInfo(BattleObject _BattleObject, string m_ActionType)
	{
		if (m_BestActionInfoList == null)
		{
			return null;
		}
		string[] array = _BattleObject.m_AiType.Split("|");
		int num = int.Parse(array[0]);
		int num2 = int.Parse(array[1]);
		if (m_ActionType == "Attack" || m_ActionType == "Heal")
		{
			foreach (BestActionInfo bestActionInfo in m_BestActionInfoList)
			{
				float paretoValue = (float)bestActionInfo.skillEffectNumber / (float)maxAttackNumber + (float)bestActionInfo.skillEffectValue / (float)maxDamgeNumber + (float)bestActionInfo.enemiesDisAverage / (float)maxEnemiesDis * (float)num2 - bestActionInfo.terrainDamageValue / maxTerrainDamgeValue;
				bestActionInfo.paretoValue = paretoValue;
			}
			m_BestActionInfoList.Sort((BestActionInfo a, BestActionInfo b) => (int)((a.paretoValue - b.paretoValue) * 100f));
		}
		List<float> list = new List<float>();
		foreach (BestActionInfo bestActionInfo2 in m_BestActionInfoList)
		{
			if (list.Count == 0)
			{
				list.Add(bestActionInfo2.paretoValue);
			}
			else if (list[list.Count - 1] != bestActionInfo2.paretoValue)
			{
				list.Add(bestActionInfo2.paretoValue);
			}
		}
		float num3 = 0f;
		num3 = num switch
		{
			3 => list[list.Count - 1], 
			2 => list[list.Count / 2], 
			_ => list[0], 
		};
		List<BestActionInfo> list2 = new List<BestActionInfo>();
		foreach (BestActionInfo bestActionInfo3 in m_BestActionInfoList)
		{
			if (bestActionInfo3.paretoValue == num3)
			{
				list2.Add(bestActionInfo3);
			}
		}
		if (list2.Count > 0)
		{
			m_BestActionInfo = list2[Random.Range(0, list2.Count)];
		}
		return m_BestActionInfo;
	}

	private static BestActionInfo GetBestAttackActionInfo(BattleObject _BattleObject)
	{
		Stopwatch stopwatch = new Stopwatch();
		stopwatch.Start();
		GetBestAttackActionInfoList(_BattleObject);
		stopwatch.Stop();
		stopwatch.Restart();
		if (m_BestActionInfoList.Count > 0)
		{
			CalParetoGetBestActionInfo(_BattleObject, "Attack");
		}
		stopwatch.Stop();
		stopwatch.Restart();
		return m_BestActionInfo;
	}

	private static List<BestActionInfo> GetBestAttackActionInfoList(BattleObject _BattleObject)
	{
		new Stopwatch();
		foreach (KeyValuePair<Vector3Int, List<Forecast>> item in _BattleObject.AttackForecastDict)
		{
			List<Vector3Int> list = new List<Vector3Int>();
			float num = 0f;
			if (alreadyAStarPathDict.ContainsKey(item.Key))
			{
				list = alreadyAStarPathDict[item.Key];
				num = AStarPathDamageDict[list];
			}
			if (num > _BattleObject.charadata.m_Hp)
			{
				continue;
			}
			foreach (Forecast item2 in item.Value)
			{
				KongFuData kongFuByID = _BattleObject.charadata.GetKongFuByID(item2.actionName.Split("|")[0]);
				int num2 = 0;
				int num3 = 0;
				if (kongFuByID.isSummonSkill)
				{
					foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
					{
						if (!(allBattleObj == _BattleObject) && !item2.effectPosList.Contains(allBattleObj.GetGridPosition()))
						{
							num2++;
							num3++;
						}
					}
				}
				else
				{
					if (!kongFuByID.isAttackSkill)
					{
						continue;
					}
					foreach (BattleObject allBattleObj2 in SharedData.Instance().m_BattleController.allBattleObjs)
					{
						if (!allBattleObj2.isDead && !(allBattleObj2 == _BattleObject) && allBattleObj2.isSelectable && !(_BattleObject.race == allBattleObj2.race) && !allBattleObj2.CheckBuffEffectOn("TurtleBreath") && item2.effectPosList.Contains(allBattleObj2.GetGridPosition()))
						{
							num2++;
							num3++;
						}
					}
				}
				if (num2 > 0)
				{
					BestActionInfo bestActionInfo = new BestActionInfo();
					bestActionInfo.skill = item2.actionName;
					bestActionInfo.actionPos = item2.actionPos;
					bestActionInfo.targetPos = item2.targetPos;
					bestActionInfo.itemID = "";
					bestActionInfo.skillEffectNumber = num2;
					bestActionInfo.skillEffectValue = num3;
					bestActionInfo.alliesDisAverage = GetOthersDistance(_BattleObject, _isEnemy: false, bestActionInfo.actionPos);
					bestActionInfo.enemiesDisAverage = GetOthersDistance(_BattleObject, _isEnemy: true, bestActionInfo.actionPos);
					bestActionInfo.terrainDamageValue = num;
					bestActionInfo.paretoValue = 0f;
					m_BestActionInfoList.Add(bestActionInfo);
					maxAttackNumber = ((num2 > maxAttackNumber) ? num2 : maxAttackNumber);
					maxDamgeNumber = ((bestActionInfo.skillEffectValue > maxDamgeNumber) ? bestActionInfo.skillEffectValue : maxDamgeNumber);
					maxAlliesDis = ((maxAlliesDis > bestActionInfo.alliesDisAverage) ? maxAlliesDis : bestActionInfo.alliesDisAverage);
					maxEnemiesDis = ((maxEnemiesDis > bestActionInfo.enemiesDisAverage) ? maxEnemiesDis : bestActionInfo.enemiesDisAverage);
					maxTerrainDamgeValue = ((maxTerrainDamgeValue > bestActionInfo.terrainDamageValue) ? maxTerrainDamgeValue : bestActionInfo.terrainDamageValue);
				}
			}
		}
		foreach (BestActionInfo item3 in m_BestActionInfoList.FindAll((BestActionInfo x) => x.skillEffectNumber == 0))
		{
			m_BestActionInfoList.Remove(item3);
		}
		return m_BestActionInfoList;
	}

	private static BestActionInfo GetBestTraceActionInfo(BattleObject _BattleObject)
	{
		int num = int.MaxValue;
		m_BestActionInfo.actionPos = _BattleObject.GetGridPosition();
		Dictionary<Vector3Int, List<Vector3Int>> dictionary = new Dictionary<Vector3Int, List<Vector3Int>>();
		foreach (KeyValuePair<Vector3Int, int> standPos in _BattleObject.standPosList)
		{
			List<Vector3Int> list = new List<Vector3Int>();
			if (dictionary.ContainsKey(standPos.Key))
			{
				list = dictionary[standPos.Key];
			}
			else
			{
				list = AStarAlgorithmBattleField.GetAStarPath(_BattleObject, _BattleObject.GetGridPosition(), standPos.Key);
				dictionary.Add(standPos.Key, list);
			}
			if (!(GetPathTerrainDamage(_BattleObject, list) > _BattleObject.charadata.m_Hp))
			{
				int othersDistance = GetOthersDistance(_BattleObject, _isEnemy: true, standPos.Key);
				if (othersDistance < num)
				{
					num = othersDistance;
					m_BestActionInfo.actionPos = standPos.Key;
				}
			}
		}
		if (_BattleObject.m_couldSwapPos)
		{
			int num2 = num;
			if (_BattleObject.AttackForecastDict.ContainsKey(m_BestActionInfo.actionPos))
			{
				foreach (Forecast actionForecast in _BattleObject.AttackForecastDict[m_BestActionInfo.actionPos])
				{
					if (_BattleObject.charadata.GetKongFuByID(actionForecast.actionName.Split("|")[0]).isSwapPosSkill && !(SharedData.Instance().m_BattleController.allBattleObjs.Find((BattleObject x) => (x.race == _BattleObject.race && x.GetGridPosition() == actionForecast.targetPos) || (x.race != _BattleObject.race && x.GetGridPosition() == actionForecast.targetPos)) != null))
					{
						int othersDistance2 = GetOthersDistance(_BattleObject, _isEnemy: true, actionForecast.targetPos);
						GetOthersDistance(_BattleObject, _isEnemy: false, actionForecast.targetPos);
						int num3 = othersDistance2;
						if (num3 <= num2)
						{
							num2 = num3;
							m_BestActionInfo.skill = actionForecast.actionName;
							m_BestActionInfo.targetPos = actionForecast.targetPos;
							m_BestActionInfo.itemID = "";
						}
					}
				}
			}
		}
		return m_BestActionInfo;
	}

	private static List<BestActionInfo> GetBestHealActionInfoList(BattleObject _BattleObject)
	{
		Dictionary<Vector3Int, List<Vector3Int>> dictionary = new Dictionary<Vector3Int, List<Vector3Int>>();
		foreach (KeyValuePair<Vector3Int, List<Forecast>> item in _BattleObject.AttackForecastDict)
		{
			List<Vector3Int> list = new List<Vector3Int>();
			if (dictionary.ContainsKey(item.Key))
			{
				list = dictionary[item.Key];
			}
			else
			{
				list = AStarAlgorithmBattleField.GetAStarPath(_BattleObject, _BattleObject.GetGridPosition(), item.Key);
				dictionary.Add(item.Key, list);
			}
			float pathTerrainDamage = GetPathTerrainDamage(_BattleObject, list);
			if (pathTerrainDamage > _BattleObject.charadata.m_Hp)
			{
				continue;
			}
			foreach (Forecast item2 in item.Value)
			{
				if (!_BattleObject.charadata.GetKongFuByID(item2.actionName.Split("|")[0]).isHealHpSkill)
				{
					continue;
				}
				int num = 0;
				int num2 = 0;
				foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
				{
					if (!allBattleObj.isDead && allBattleObj.isSelectable && !(_BattleObject.race != allBattleObj.race))
					{
						if (allBattleObj != _BattleObject && item2.effectPosList.Contains(allBattleObj.GetGridPosition()) && allBattleObj.charadata.m_Hp < allBattleObj.charadata.GetBattleValueByName("HP"))
						{
							num++;
							num2++;
						}
						if (allBattleObj == _BattleObject && item2.effectPosList.Contains(item.Key) && allBattleObj.charadata.m_Hp < allBattleObj.charadata.GetBattleValueByName("HP"))
						{
							num++;
							num2++;
						}
					}
				}
				if (num > 0)
				{
					BestActionInfo bestActionInfo = new BestActionInfo();
					bestActionInfo.skill = item2.actionName;
					bestActionInfo.actionPos = item2.actionPos;
					bestActionInfo.targetPos = item2.targetPos;
					bestActionInfo.itemID = "";
					bestActionInfo.skillEffectNumber = num;
					bestActionInfo.skillEffectValue = num2;
					bestActionInfo.alliesDisAverage = GetOthersDistance(_BattleObject, _isEnemy: false, bestActionInfo.actionPos);
					bestActionInfo.enemiesDisAverage = GetOthersDistance(_BattleObject, _isEnemy: true, bestActionInfo.actionPos);
					bestActionInfo.terrainDamageValue = pathTerrainDamage;
					bestActionInfo.paretoValue = 0f;
					m_BestActionInfoList.Add(bestActionInfo);
					maxAttackNumber = ((num > maxAttackNumber) ? num : maxAttackNumber);
					maxDamgeNumber = ((bestActionInfo.skillEffectValue > maxDamgeNumber) ? bestActionInfo.skillEffectValue : maxDamgeNumber);
					maxAlliesDis = ((maxAlliesDis > bestActionInfo.alliesDisAverage) ? maxAlliesDis : bestActionInfo.alliesDisAverage);
					maxEnemiesDis = ((maxEnemiesDis > bestActionInfo.enemiesDisAverage) ? maxEnemiesDis : bestActionInfo.enemiesDisAverage);
					maxTerrainDamgeValue = ((maxTerrainDamgeValue > bestActionInfo.terrainDamageValue) ? maxTerrainDamgeValue : bestActionInfo.terrainDamageValue);
				}
			}
		}
		return m_BestActionInfoList;
	}

	private static BestActionInfo GetBestHealActionInfo(BattleObject _BattleObject)
	{
		GetBestHealActionInfoList(_BattleObject);
		if (m_BestActionInfoList.Count > 0)
		{
			CalParetoGetBestActionInfo(_BattleObject, "Heal");
			_BattleObject.prevRoundIsHeal = false;
		}
		return m_BestActionInfo;
	}

	private static List<BestActionInfo> GetBestAddBuffActionInfoList(BattleObject _BattleObject)
	{
		Dictionary<Vector3Int, List<Vector3Int>> dictionary = new Dictionary<Vector3Int, List<Vector3Int>>();
		foreach (KeyValuePair<Vector3Int, List<Forecast>> item in _BattleObject.AttackForecastDict)
		{
			List<Vector3Int> list = new List<Vector3Int>();
			if (dictionary.ContainsKey(item.Key))
			{
				list = dictionary[item.Key];
			}
			else
			{
				list = AStarAlgorithmBattleField.GetAStarPath(_BattleObject, _BattleObject.GetGridPosition(), item.Key);
				dictionary.Add(item.Key, list);
			}
			float pathTerrainDamage = GetPathTerrainDamage(_BattleObject, list);
			if (pathTerrainDamage > _BattleObject.charadata.m_Hp)
			{
				continue;
			}
			foreach (Forecast item2 in item.Value)
			{
				if (!_BattleObject.charadata.GetKongFuByID(item2.actionName.Split("|")[0]).isBuffSkill)
				{
					continue;
				}
				int num = 0;
				int num2 = 0;
				foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
				{
					if (!allBattleObj.isDead && !(allBattleObj == _BattleObject) && allBattleObj.isSelectable && !(_BattleObject.race != allBattleObj.race) && !allBattleObj.CheckBuffEffectOn("TurtleBreath") && item2.effectPosList.Contains(allBattleObj.GetGridPosition()))
					{
						num++;
						num2++;
					}
				}
				if (num > 0)
				{
					BestActionInfo bestActionInfo = new BestActionInfo();
					bestActionInfo.skill = item2.actionName;
					bestActionInfo.actionPos = item2.actionPos;
					bestActionInfo.targetPos = item2.targetPos;
					bestActionInfo.itemID = "";
					bestActionInfo.skillEffectNumber = num;
					bestActionInfo.skillEffectValue = num2;
					bestActionInfo.alliesDisAverage = GetOthersDistance(_BattleObject, _isEnemy: false, bestActionInfo.actionPos);
					bestActionInfo.enemiesDisAverage = GetOthersDistance(_BattleObject, _isEnemy: true, bestActionInfo.actionPos);
					bestActionInfo.terrainDamageValue = pathTerrainDamage;
					bestActionInfo.paretoValue = 0f;
					m_BestActionInfoList.Add(bestActionInfo);
					maxAttackNumber = ((num > maxAttackNumber) ? num : maxAttackNumber);
					maxDamgeNumber = ((bestActionInfo.skillEffectValue > maxDamgeNumber) ? bestActionInfo.skillEffectValue : maxDamgeNumber);
					maxAlliesDis = ((maxAlliesDis > bestActionInfo.alliesDisAverage) ? maxAlliesDis : bestActionInfo.alliesDisAverage);
					maxEnemiesDis = ((maxEnemiesDis > bestActionInfo.enemiesDisAverage) ? maxEnemiesDis : bestActionInfo.enemiesDisAverage);
					maxTerrainDamgeValue = ((maxTerrainDamgeValue > bestActionInfo.terrainDamageValue) ? maxTerrainDamgeValue : bestActionInfo.terrainDamageValue);
				}
			}
		}
		return m_BestActionInfoList;
	}

	private static BestActionInfo GetBestAddBuffActionInfo(BattleObject _BattleObject)
	{
		GetBestAddBuffActionInfoList(_BattleObject);
		if (m_BestActionInfoList.Count > 0)
		{
			CalParetoGetBestActionInfo(_BattleObject, "Heal");
			_BattleObject.prevRoundIsHeal = false;
		}
		return m_BestActionInfo;
	}

	private static BestActionInfo GetBestHealToAttackActionInfo(BattleObject _BattleObject)
	{
		GetBestAttackActionInfoList(_BattleObject);
		Vector3Int vector3Int = Vector3Int.zero;
		float num = float.MaxValue;
		foreach (BattleObject ally in allies)
		{
			if (!(ally == _BattleObject) && !ally.isDead)
			{
				float num2 = ally.charadata.m_Hp / ally.charadata.GetBattleValueByName("HP");
				if (num2 < num)
				{
					num = num2;
					vector3Int = ally.GetGridPosition();
				}
			}
		}
		if (m_BestActionInfoList.Count > 0)
		{
			List<int> list = new List<int>();
			List<int> list2 = new List<int>();
			int num3 = int.MaxValue;
			int num4 = 0;
			foreach (BestActionInfo bestActionInfo in m_BestActionInfoList)
			{
				int heuristic = AStarAlgorithmBattleField.GetHeuristic(bestActionInfo.actionPos, vector3Int);
				list.Add(heuristic);
				if (heuristic < num3)
				{
					num3 = heuristic;
				}
			}
			foreach (int item in list)
			{
				if (item == num3)
				{
					list2.Add(num4);
				}
				num4++;
			}
			int index = Random.Range(0, list2.Count);
			m_BestActionInfo = m_BestActionInfoList[list2[index]];
		}
		else
		{
			m_BestActionInfo.actionPos = vector3Int;
		}
		return m_BestActionInfo;
	}

	private static BestActionInfo GetBestEscapeActionInfo(BattleObject _BattleObject, bool isTargetMove = false)
	{
		Vector3Int zero = Vector3Int.zero;
		zero = (isTargetMove ? GetSingelMoveTargetPos(_BattleObject) : GetSingelMoveEscapePos(_BattleObject));
		if (_BattleObject.m_couldSwapPos)
		{
			int othersDistance = GetOthersDistance(_BattleObject, _isEnemy: true, zero);
			int num = int.MinValue;
			int num2 = int.MaxValue;
			Vector3Int gridPosition = _BattleObject.GetGridPosition();
			Dictionary<Vector3Int, List<Vector3Int>> dictionary = new Dictionary<Vector3Int, List<Vector3Int>>();
			foreach (KeyValuePair<Vector3Int, int> standPos in _BattleObject.standPosList)
			{
				float num3 = 0f;
				List<Vector3Int> list = new List<Vector3Int>();
				if (dictionary.ContainsKey(standPos.Key))
				{
					list = dictionary[standPos.Key];
				}
				else
				{
					list = AStarAlgorithmBattleField.GetAStarPath(_BattleObject, _BattleObject.GetGridPosition(), standPos.Key);
					dictionary.Add(standPos.Key, list);
				}
				num3 = GetPathTerrainDamage(_BattleObject, list);
				moveToPosCouse.Add(num3);
				if (num3 > _BattleObject.charadata.m_Hp)
				{
					continue;
				}
				foreach (string skill in _BattleObject.m_SkillList)
				{
					string[] array = skill.Split('|');
					KongFuData kongFuByID = _BattleObject.charadata.GetKongFuByID(array[0]);
					if (array[5] == "MP-POOR" || !kongFuByID.isSwapPosSkill)
					{
						continue;
					}
					foreach (KeyValuePair<Vector3Int, int> item in AttackData.GetRange1ByAttackType(array, standPos.Key, _BattleObject))
					{
						foreach (KeyValuePair<Vector3Int, int> item2 in AttackData.GetRange2ByAttackType(array, item.Key, item.Value, _BattleObject.GetGridPosition()))
						{
							if (!isTargetMove)
							{
								int othersDistance2 = GetOthersDistance(_BattleObject, _isEnemy: true, item2.Key);
								GetOthersDistance(_BattleObject, _isEnemy: false, item2.Key);
								int num4 = othersDistance2;
								if (num4 >= num && num4 > othersDistance && item2.Key != gridPosition)
								{
									num = num4;
									m_BestActionInfo.skill = skill;
									m_BestActionInfo.targetPos = item.Key;
									m_BestActionInfo.actionPos = standPos.Key;
									m_BestActionInfo.itemID = "";
								}
								continue;
							}
							int targetDistance = GetTargetDistance(_BattleObject, item2.Key);
							if (targetDistance <= num2)
							{
								num2 = targetDistance;
								m_BestActionInfo.skill = skill;
								m_BestActionInfo.targetPos = item.Key;
								m_BestActionInfo.actionPos = standPos.Key;
								m_BestActionInfo.itemID = "";
								if (num2 == 0)
								{
									m_BestActionInfo.skill = "";
									m_BestActionInfo.targetPos = Vector3Int.zero;
									m_BestActionInfo.actionPos = Vector3Int.zero;
									m_BestActionInfo.itemID = "";
									m_BestActionInfo.skillEffectNumber = 0;
									m_BestActionInfo.actionPos = standPos.Key;
									return m_BestActionInfo;
								}
							}
						}
					}
				}
			}
			if (m_BestActionInfo.skill == "" || num <= othersDistance)
			{
				m_BestActionInfo.skill = "";
				m_BestActionInfo.targetPos = Vector3Int.zero;
				m_BestActionInfo.actionPos = Vector3Int.zero;
				m_BestActionInfo.itemID = "";
				m_BestActionInfo.skillEffectNumber = 0;
				m_BestActionInfo.actionPos = zero;
			}
		}
		else
		{
			m_BestActionInfo.actionPos = zero;
		}
		return m_BestActionInfo;
	}

	public static Vector3Int GetSingelMoveEscapePos(BattleObject _BattleObject)
	{
		int num = int.MinValue;
		int num2 = int.MinValue;
		List<float> list = new List<float>();
		List<float> list2 = new List<float>();
		List<Vector3Int> list3 = new List<Vector3Int>();
		foreach (KeyValuePair<Vector3Int, int> standPos in _BattleObject.standPosList)
		{
			int othersDistance = GetOthersDistance(_BattleObject, _isEnemy: true, standPos.Key);
			int othersDistance2 = GetOthersDistance(_BattleObject, _isEnemy: false, standPos.Key);
			list.Add(othersDistance);
			list2.Add(othersDistance2);
			if (othersDistance > num)
			{
				num = othersDistance;
			}
			if (othersDistance2 > num2)
			{
				num2 = othersDistance2;
			}
			list3.Add(standPos.Key);
		}
		List<float> list4 = new List<float>();
		float num3 = -2.1474836E+09f;
		for (int i = 0; i < list.Count; i++)
		{
			list[i] /= ((num == 0) ? 1 : num);
			list2[i] /= ((num2 == 0) ? 1 : num2);
			float num4 = list[i] - list2[i];
			list4.Add(num4);
			if (num4 > num3)
			{
				num3 = num4;
			}
		}
		List<int> list5 = new List<int>();
		for (int j = 0; j < list4.Count; j++)
		{
			if (list4[j] == num3)
			{
				list5.Add(j);
			}
		}
		int index = list5[Random.Range(0, list5.Count)];
		return list3[index];
	}

	public static Vector3Int GetSingelMoveTargetPos(BattleObject _BattleObject)
	{
		int num = int.MaxValue;
		Vector3Int result = Vector3Int.zero;
		Dictionary<Vector3Int, List<Vector3Int>> dictionary = new Dictionary<Vector3Int, List<Vector3Int>>();
		foreach (KeyValuePair<Vector3Int, int> standPos in _BattleObject.standPosList)
		{
			float num2 = 0f;
			List<Vector3Int> list = new List<Vector3Int>();
			if (dictionary.ContainsKey(standPos.Key))
			{
				list = dictionary[standPos.Key];
			}
			else
			{
				list = AStarAlgorithmBattleField.GetAStarPath(_BattleObject, _BattleObject.GetGridPosition(), standPos.Key);
				dictionary.Add(standPos.Key, list);
			}
			num2 = GetPathTerrainDamage(_BattleObject, list);
			moveToPosCouse.Add(num2);
			if (num2 > _BattleObject.charadata.m_Hp)
			{
				continue;
			}
			int targetDistance = GetTargetDistance(_BattleObject, standPos.Key);
			if (targetDistance < num)
			{
				result = standPos.Key;
				num = targetDistance;
				if (num == 0)
				{
					return result;
				}
			}
		}
		return result;
	}

	private static Dictionary<string, Vector3Int> GetAlliesPosDirec(BattleObject _BattleObject)
	{
		Dictionary<string, Vector3Int> dictionary = new Dictionary<string, Vector3Int>();
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			if (!allBattleObj.isDead && !(allBattleObj.race != _BattleObject.race) && !(allBattleObj == _BattleObject) && !allBattleObj.CheckBuffEffectOn("TurtleBreath"))
			{
				dictionary.Add(allBattleObj.name, allBattleObj.GetGridPosition());
			}
		}
		return dictionary;
	}

	private static Dictionary<string, Vector3Int> GetOpponentsPosDirec(BattleObject _BattleObject)
	{
		Dictionary<string, Vector3Int> dictionary = new Dictionary<string, Vector3Int>();
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			if (!allBattleObj.isDead && !(allBattleObj.race == _BattleObject.race) && !(allBattleObj == _BattleObject) && !allBattleObj.CheckBuffEffectOn("TurtleBreath"))
			{
				dictionary.Add(allBattleObj.name, allBattleObj.GetGridPosition());
			}
		}
		return dictionary;
	}

	private static int GetOthersDistance(BattleObject _BattleObject, bool _isEnemy, Vector3Int pos)
	{
		int num = 0;
		if (_isEnemy)
		{
			if (opponents.Count == 0)
			{
				return int.MaxValue;
			}
			foreach (BattleObject opponent in opponents)
			{
				if (!opponent.isDead)
				{
					num += AStarAlgorithmBattleField.GetHeuristic(pos, opponent.GetGridPosition());
				}
			}
		}
		else
		{
			if (allies.Count == 0)
			{
				return int.MaxValue;
			}
			foreach (BattleObject ally in allies)
			{
				if (!ally.isDead && !(ally == _BattleObject))
				{
					num += AStarAlgorithmBattleField.GetHeuristic(pos, ally.GetGridPosition());
				}
			}
		}
		return num;
	}

	public static float GetPathTerrainDamage(BattleObject _BattleObject, List<Vector3Int> astarPath)
	{
		float num = 0f;
		foreach (Vector3Int item in astarPath)
		{
			if (SharedData.Instance().m_BattleController.terrain.ContainsKey(item) && SharedData.Instance().m_BattleController.terrain[item].ToString().Contains("Fire") && _BattleObject.charadata.GetBattleValueByName("Burnresist") <= 0f)
			{
				float damageValue = SharedData.Instance().m_BattleController.terrain[item].damageValue;
				num += _BattleObject.charadata.GetBattleValueByName("HP") * damageValue;
			}
			else if (SharedData.Instance().m_BattleController.terrain.ContainsKey(item) && SharedData.Instance().m_BattleController.terrain[item].ToString().Contains("Poison") && _BattleObject.charadata.GetBattleValueByName("Poisonresist") <= 0f)
			{
				float damageValue2 = SharedData.Instance().m_BattleController.terrain[item].damageValue;
				float num2 = _BattleObject.charadata.GetBattleValueByName("HP") * damageValue2;
				if (num2 >= _BattleObject.charadata.m_Hp)
				{
					num2 = _BattleObject.charadata.m_Hp - 1f;
				}
				num += num2;
			}
			else if (SharedData.Instance().m_BattleController.terrain.ContainsKey(item) && SharedData.Instance().m_BattleController.terrain[item].t_type == TerrainType.TrapBlast && _BattleObject.charadata.GetBattleValueByName("Trapresist") <= 0f)
			{
				num += SharedData.Instance().m_BattleController.terrain[item].damageValue;
			}
		}
		return num;
	}

	private static int GetTargetDistance(BattleObject _BattleObject, Vector3Int pos)
	{
		int num = 0;
		if (_BattleObject.targetGridList.Count == 0)
		{
			return int.MaxValue;
		}
		foreach (Vector3Int targetGrid in _BattleObject.targetGridList)
		{
			int heuristic = AStarAlgorithmBattleField.GetHeuristic(pos, targetGrid);
			if (heuristic == 0)
			{
				return 0;
			}
			num += heuristic;
		}
		return num;
	}

	private static bool isAnyoneNeedHealHp(BattleObject _BattleObject)
	{
		foreach (BattleObject ally in allies)
		{
			if (!(_BattleObject == ally) && !ally.isDead && ally.charadata.m_Hp < ally.charadata.GetBattleValueByName("HP") * 0.5f)
			{
				return true;
			}
		}
		return false;
	}

	public bool isAnyoneNeedHealNegativeBuff(BattleObject _BattleObject)
	{
		foreach (BattleObject ally in allies)
		{
			if (!(_BattleObject == ally) && !ally.isDead)
			{
				float battleValueByName = ally.charadata.GetBattleValueByName("Poison");
				float battleValueByName2 = ally.charadata.GetBattleValueByName("Bleed");
				float battleValueByName3 = ally.charadata.GetBattleValueByName("Burn");
				float battleValueByName4 = ally.charadata.GetBattleValueByName("Hurt");
				float battleValueByName5 = ally.charadata.GetBattleValueByName("Mad");
				if (battleValueByName > 25f || battleValueByName2 > 25f || battleValueByName3 > 25f || battleValueByName4 > 25f || battleValueByName5 > 25f)
				{
					return true;
				}
			}
		}
		return false;
	}

	private int isPosCouldHealHp(BattleObject _BattleObject, Vector3Int pos)
	{
		foreach (BattleObject ally in allies)
		{
			if (!(_BattleObject == ally) && !ally.isDead && ally.GetGridPosition() == pos)
			{
				float battleValueByName = ally.charadata.GetBattleValueByName("HP");
				if (ally.charadata.m_Hp < battleValueByName)
				{
					return (int)(battleValueByName - ally.charadata.m_Hp);
				}
			}
		}
		return 0;
	}
}
