using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
	private BattleController m_BattleController;

	private GameObject CurrentPlayer;

	private GameObject joyInfo;

	public GameObject TurnDisp;

	private GameObject CurrentLevel;

	private GameObject WuGongDisp;

	[HideInInspector]
	public GameObject m_ActionMenu;

	[HideInInspector]
	private GameObject m_WugongListMenu;

	[HideInInspector]
	public GameObject m_WugongListMenu_Content;

	[HideInInspector]
	public GameObject m_GameSet;

	private BattleMenuState _menuState;

	private GameObject AtkBtnPrefab;

	public List<GameObject> AtkBtnList = new List<GameObject>();

	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	private Sprite DisInteractableSprite;

	private Sprite TransSprite;

	public GameObject m_PauseMenu;

	public GameObject m_InteruptInfo;

	public GameObject m_FlowStatus;

	[HideInInspector]
	public BattleObject m_Interupter;

	[HideInInspector]
	private List<Transform> AchievementsInfoList = new List<Transform>();

	[HideInInspector]
	private List<Transform> AtlasInfoList = new List<Transform>();

	private float m_FlowStatusTimemark = 0.5f;

	private Vector3Int preFlowPos = Vector3Int.zero;

	private BattleObject _currentShowPlayer;

	private GameObject KFSimpleItemPrefab;

	private GameObject TraitDetailsPrefab;

	public BattleMenuState m_menuState
	{
		get
		{
			return _menuState;
		}
		set
		{
			_menuState = value;
			SetMenuStatue(_menuState);
		}
	}

	private void Awake()
	{
		CurrentPlayer = base.transform.Find("CurrentPlayer").gameObject;
		joyInfo = base.transform.Find("JoyInfo").gameObject;
		CurrentPlayer.SetActive(value: false);
		TurnDisp = base.transform.Find("TurnDisp").gameObject;
		if (SharedData.Instance().m_isDaTianWangSiChallenge)
		{
			CurrentLevel = base.transform.Find("CurrentLevel").gameObject;
			CurrentLevel.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Level") + " <color=#E3D1AD><size=35>" + SharedData.Instance().m_DaTianWangSiLevel + "</size></color>";
		}
		else
		{
			CurrentLevel = base.transform.Find("CurrentLevel")?.gameObject;
			if (CurrentLevel != null)
			{
				CurrentLevel.SetActive(value: false);
				CurrentLevel.SetActive(SharedData.Instance().m_isDaTianWangSiChallenge);
			}
		}
		WuGongDisp = base.transform.Find("WuGongDisp").gameObject;
		WuGongDisp.SetActive(value: false);
		NormalSprite = Resources.Load("images/01-border/boder-20231228-fight-01", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-20231228-fight-04", typeof(Sprite)) as Sprite;
		DisInteractableSprite = Resources.Load("images/01-border/boder-20231228-highlihgt-02", typeof(Sprite)) as Sprite;
		TransSprite = CommonResourcesData.TransprantSprite;
		m_BattleController = GameObject.Find("Camera").GetComponent<BattleController>();
		EventTriggerListener.Get(base.transform.Find("FlowStatus/CloseFlowStatus").gameObject).onClick = OnButtonClick;
		m_ActionMenu = base.transform.Find("ActionMenu").gameObject;
		Button[] componentsInChildren = m_ActionMenu.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		m_WugongListMenu = base.transform.Find("WugongList").gameObject;
		componentsInChildren = m_WugongListMenu.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonAtkClick;
		}
		m_WugongListMenu_Content = base.transform.Find("WugongList/Viewport/Content").gameObject;
		componentsInChildren = m_WugongListMenu_Content.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonAtkClick;
		}
		AtkBtnPrefab = (GameObject)Resources.Load("Prefabs/BattleMenu/AttackButton");
		m_GameSet = base.transform.Find("GameSet").gameObject;
		componentsInChildren = m_GameSet.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonSetClick;
		}
		m_PauseMenu = base.transform.Find("PauseMenu").gameObject;
		componentsInChildren = m_PauseMenu.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonSetClick;
		}
		m_InteruptInfo = base.transform.Find("InteruptInfo").gameObject;
		AchievementsInfoList.Add(base.transform.Find("AchievementsInfoList/AchievementsInfo1"));
		AchievementsInfoList.Add(base.transform.Find("AchievementsInfoList/AchievementsInfo2"));
		AchievementsInfoList.Add(base.transform.Find("AchievementsInfoList/AchievementsInfo3"));
		AchievementsInfoList.Add(base.transform.Find("AchievementsInfoList/AchievementsInfo4"));
		AchievementsInfoList.Add(base.transform.Find("AchievementsInfoList/AchievementsInfo5"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo1"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo2"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo3"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo4"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo5"));
	}

	private void Start()
	{
		m_FlowStatus = base.transform.Find("FlowStatus").gameObject;
		KFSimpleItemPrefab = Resources.Load("Prefabs/NewUI/KFSimpleItem") as GameObject;
		TraitDetailsPrefab = Resources.Load("Prefabs/NewUI/TraitDetails") as GameObject;
		base.transform.Find("TurnDisp").GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Round") + " <color=#E3D1AD><size=35>" + 1 + "</size></color>";
		SharedData.Instance().m_MenuController = this;
	}

	public void ClearAttackMenu()
	{
		foreach (GameObject atkBtn in AtkBtnList)
		{
			Object.Destroy(atkBtn);
		}
		AtkBtnList.Clear();
	}

	private void SetMenuStatue(BattleMenuState _state)
	{
		CurrentPlayer.transform.Find("Tachie").gameObject.SetActive(value: false);
		joyInfo.SetActive(value: false);
		switch (_state)
		{
		case BattleMenuState.AutoBattleShow:
			m_ActionMenu.SetActive(value: true);
			m_WugongListMenu.SetActive(value: false);
			m_ActionMenu.transform.Find("Attack").gameObject.SetActive(value: true);
			m_ActionMenu.transform.Find("Item").gameObject.SetActive(value: true);
			m_ActionMenu.transform.Find("Attack").GetComponent<Button>().interactable = m_BattleController.GetCurrentObjActionType() != ActionType.Runaway;
			m_ActionMenu.transform.Find("Cancel").gameObject.SetActive(value: true);
			m_ActionMenu.transform.Find("Auto").gameObject.SetActive(value: true);
			m_ActionMenu.transform.Find("CancelAuto").gameObject.SetActive(value: false);
			m_ActionMenu.transform.Find("Escape").gameObject.SetActive(SharedData.Instance().isRandomFight);
			WuGongDisp.SetActive(value: false);
			m_ActionMenu.transform.Find("Item").GetComponent<Button>().interactable = true;
			if (m_BattleController.current.CheckBuffEffectOn("Dexterous"))
			{
				m_ActionMenu.transform.Find("Item").GetComponent<Button>().interactable = false;
			}
			m_ActionMenu.transform.Find("Item").GetComponent<Button>().interactable = m_BattleController.GetCurrentObjActionType() != ActionType.Runaway;
			if (m_BattleController.current.GetGridPosition() == m_BattleController.current.handInPos)
			{
				m_ActionMenu.transform.Find("Cancel/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Meditate");
			}
			else
			{
				m_ActionMenu.transform.Find("Cancel/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Standby");
			}
			UpdateCharacterInfo(m_BattleController.current);
			CurrentPlayer.transform.Find("Tachie").gameObject.SetActive(value: true);
			joyInfo.SetActive(value: true);
			break;
		case BattleMenuState.CancelAutoBattleShow:
			m_ActionMenu.SetActive(value: true);
			m_ActionMenu.transform.Find("Attack").gameObject.SetActive(value: false);
			m_ActionMenu.transform.Find("Item").gameObject.SetActive(value: false);
			m_ActionMenu.transform.Find("Cancel").gameObject.SetActive(value: false);
			m_ActionMenu.transform.Find("Auto").gameObject.SetActive(value: false);
			m_ActionMenu.transform.Find("CancelAuto").gameObject.SetActive(value: true);
			m_ActionMenu.transform.Find("Escape").gameObject.SetActive(value: false);
			break;
		case BattleMenuState.WugongListShow:
			m_ActionMenu.SetActive(value: false);
			m_WugongListMenu.SetActive(value: true);
			UpdateCharacterInfo(m_BattleController.current);
			m_BattleController.m_curcor.SetPosition(m_BattleController.current);
			break;
		case BattleMenuState.None:
			m_ActionMenu.SetActive(value: false);
			m_WugongListMenu.SetActive(value: false);
			if (m_BattleController.current.m_State == BattleObjectState.AStarMoving)
			{
				CurrentPlayer.SetActive(value: true);
			}
			else
			{
				CurrentPlayer.SetActive(value: false);
			}
			WuGongDisp.SetActive(value: false);
			break;
		}
	}

	private void AddAttackMenu(List<string> SkillList)
	{
		ClearAttackMenu();
		BattleJoyController.currentSelectWugong = null;
		bool flag = true;
		foreach (string Skill in SkillList)
		{
			GameObject gameObject = Object.Instantiate(AtkBtnPrefab, m_WugongListMenu_Content.transform);
			gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, -5f + (float)AtkBtnList.Count * -95f);
			gameObject.name = "Attack&" + Skill;
			string[] array = Skill.Split('|');
			Image component = gameObject.transform.Find("Icon").GetComponent<Image>();
			component.sprite = Resources.Load("images/07-icon/" + CommonResourcesData.b03.Find_ID(array[0]).Icon, typeof(Sprite)) as Sprite;
			component.color = ((array[5] == "MP-POOR") ? Color.red : Color.white);
			if ((array[0].Equals(m_BattleController.current.GetEffectOnSuperWugongID()) || array[0].Equals(m_BattleController.current.GetEffectOnSuperWugongID())) && array[5] == "MP-GOOD")
			{
				component.color = Color.yellow;
			}
			gameObject.transform.Find("Lv/Num").GetComponent<Text>().text = array[4];
			gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(array[0]);
			gameObject.transform.Find("Text").GetComponent<Text>().text = ((m_BattleController.current.charadata.m_Training_Id == array[0]) ? "* " : "") + row.Name_Trans;
			if (array[5] != "MP-POOR")
			{
				EventTriggerListener.Get(gameObject).onClick = OnButtonAtkClick;
				gameObject.GetComponent<Image>().sprite = NormalSprite;
			}
			else
			{
				gameObject.GetComponent<Button>().interactable = false;
				gameObject.GetComponent<Image>().sprite = DisInteractableSprite;
			}
			int num = Mathf.FloorToInt(float.Parse(array[4], CultureInfo.InvariantCulture) / 3f);
			if (num > 0)
			{
				Text component2 = gameObject.transform.Find("Text").GetComponent<Text>();
				component2.text = component2.text + "+" + num;
			}
			gameObject.transform.Find("Mp").GetComponent<Text>().text = ((array[5] == "MP-POOR") ? "<color=#EE3B17>" : "") + array[6] + ((array[5] == "MP-POOR") ? "</color>" : "");
			AtkBtnList.Add(gameObject);
			if (flag)
			{
				EventSystem.current.SetSelectedGameObject(gameObject.gameObject);
				flag = false;
			}
		}
		RectTransform component3 = m_WugongListMenu_Content.GetComponent<RectTransform>();
		Vector2 sizeDelta = component3.sizeDelta;
		sizeDelta.y = 10f + 95f * (float)AtkBtnList.Count;
		component3.sizeDelta = sizeDelta;
		RectTransform component4 = m_WugongListMenu.GetComponent<RectTransform>();
		sizeDelta = component4.sizeDelta;
		sizeDelta.y = 10f + 95f * (float)AtkBtnList.Count;
		component4.sizeDelta = sizeDelta;
	}

	private void Update()
	{
		if (m_BattleController.IsSaveRoundRecordRunning || m_BattleController.IsLoadRoundRecordRunning || (SharedData.Instance().debugBattle != null && SharedData.Instance().debugBattle.DebugPanel.activeInHierarchy))
		{
			return;
		}
		UnlockAchievement();
		UnlockAtlas();
		if (CommonFunc.IsHoverOpen() || m_BattleController.AutoBattle || m_BattleController.isLostControl || SharedData.Instance().m_PackageController.isOpen || SharedData.Instance().m_TraitPackageController.isOpen || SceneManager.sceneCount > 1)
		{
			return;
		}
		if (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			if (m_InteruptInfo.activeInHierarchy)
			{
				m_Interupter.InteruptOut();
			}
		}
		else if (InputDeviceDetector.isMouse1Up || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputSystemCustom.Instance().Player.ReturnTitleShortCut.WasReleasedThisFrame())
		{
			if (m_InteruptInfo.activeInHierarchy)
			{
				m_Interupter.InteruptOut();
			}
			else if (m_PauseMenu.activeInHierarchy)
			{
				m_PauseMenu.SetActive(value: false);
				CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
			}
			else if (m_FlowStatus.activeInHierarchy)
			{
				CloseFlowStatus();
			}
			else if (m_menuState == BattleMenuState.WugongListShow)
			{
				if (!EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").enabled && m_WugongListMenu_Content.transform.childCount != 0)
				{
					EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").Enable();
					Vector3Int vector3Int = m_BattleController.tilemap.WorldToCell(m_BattleController.m_curcor.transform.position);
					m_BattleController.m_curcor.CurcorPosition(new Vector3Int(vector3Int.x, -vector3Int.y, 0), pressing: true);
				}
				else
				{
					MenuAtkClickCancel();
				}
			}
			else if (m_menuState == BattleMenuState.CancelAutoBattleShow)
			{
				m_menuState = BattleMenuState.None;
				m_BattleController.AutoBattle = false;
			}
			else if (m_BattleController.m_Flow != BattleControllerFlow.Action && m_BattleController.current.m_State != BattleObjectState.Action && (m_BattleController.m_Flow != BattleControllerFlow.MoveWait || m_BattleController.current.m_State != BattleObjectState.WaitingForInput || m_BattleController.current.handInPos != m_BattleController.current.GetGridPosition() || m_BattleController.m_curcor.GetGridPosition() != m_BattleController.current.GetGridPosition()))
			{
				m_BattleController.RoundReSet();
			}
			else
			{
				OnPauseMenuCall();
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit1Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(0);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit2Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(1);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit3Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(2);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit4Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(3);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit5Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(4);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit6Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(5);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit7Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(6);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit8Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(7);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit9Key.wasReleasedThisFrame)
		{
			if ((m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
			{
				AttackButtonSelected();
				SelectAtkBtnById(8);
			}
		}
		else if (Keyboard.current != null && Keyboard.current.digit0Key.wasReleasedThisFrame && (m_ActionMenu.activeInHierarchy || m_WugongListMenu.activeInHierarchy) && !m_FlowStatus.activeInHierarchy)
		{
			AttackButtonSelected();
			SelectAtkBtnById(9);
		}
	}

	private void SelectAtkBtnById(int _id)
	{
		if (AtkBtnList.Count > _id && AtkBtnList[_id].GetComponent<Button>().interactable)
		{
			OnButtonAtkClick(AtkBtnList[_id]);
		}
	}

	public void OpenInteruptInfo(BattleObject _who, string _info, string _icon = "")
	{
		m_Interupter = _who;
		m_InteruptInfo.transform.Find("Info/Text").GetComponent<Text>().text = _info;
		if (!"".Equals(_icon))
		{
			m_InteruptInfo.transform.Find("IconFrame").gameObject.SetActive(value: true);
			m_InteruptInfo.transform.Find("IconFrame/Icon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(_icon);
		}
		else
		{
			m_InteruptInfo.transform.Find("IconFrame").gameObject.SetActive(value: false);
		}
		m_InteruptInfo.SetActive(value: true);
	}

	private bool couldSubdue()
	{
		foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
		{
			if (!(allBattleObj.charadata.originRace != "player") && allBattleObj.charadata.GetBattleValueByName("Subdue") > 0f)
			{
				return true;
			}
		}
		return false;
	}

	private void AttackButtonSelected(bool _camera_work = true)
	{
		m_menuState = BattleMenuState.WugongListShow;
		AddAttackMenu(m_BattleController.current.m_SkillList);
		m_BattleController.SetFlowState(BattleControllerFlow.PlayerMenuClick);
		if (_camera_work)
		{
			m_BattleController.SetCameraSmooth(new Vector3(m_BattleController.current.transform.position.x + 150f, m_BattleController.current.transform.position.y, -10f));
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		if (go.name == "Attack")
		{
			AttackButtonSelected();
		}
		else if (go.name == "Item")
		{
			if (m_BattleController.current.CheckBuffEffectOn("Dexterous"))
			{
				return;
			}
			m_menuState = BattleMenuState.None;
			SharedData.Instance().OpenPackageFor = "BattleField";
			SharedData.Instance().m_BattlePackageStatus = 1;
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.BattleField, "01000000000");
			m_BattleController.SetFlowState(BattleControllerFlow.PlayerPackOpen);
		}
		else if (go.name == "Cancel")
		{
			if (m_BattleController.current.charadata.GetBattleValueByName("KeJi") > 0f)
			{
				BuffData buffByName = m_BattleController.current.GetBuffByName("KeJi");
				if (buffByName != null)
				{
					buffByName.value += 0.15f;
				}
				else
				{
					m_BattleController.current.AddBuff("KeJi", "", 0.15f, int.MaxValue);
				}
			}
			if (m_BattleController.current.charadata.GetBattleValueByName("MiYingCangXing") > 0f)
			{
				m_BattleController.current.AddBuff("Invisible", "", 1f, 2);
			}
			m_menuState = BattleMenuState.None;
			m_BattleController.RecoveryCurrentMp();
		}
		else if (go.name == "Auto")
		{
			m_menuState = BattleMenuState.CancelAutoBattleShow;
			m_BattleController.AutoBattle = true;
			m_BattleController.isLostControl = true;
			m_BattleController.SetFlowState(BattleControllerFlow.CharacterInit);
		}
		else if (go.name == "CancelAuto")
		{
			m_menuState = BattleMenuState.None;
			m_BattleController.AutoBattle = false;
		}
		else if (go.name == "Escape")
		{
			m_menuState = BattleMenuState.None;
			int num = 0;
			int num2 = 0;
			foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
			{
				if (allBattleObj.race == "enemy")
				{
					num += allBattleObj.charadata.m_Level;
					num2++;
				}
			}
			num /= num2;
			float num3 = 0f;
			if (m_BattleController.current.charadata.m_Level > num)
			{
				num3 = (m_BattleController.current.charadata.m_Level - num) / 10;
			}
			num3 += m_BattleController.current.charadata.GetBattleValueByName("EscapeRate");
			if (Random.Range(0f, 1f) > num3)
			{
				m_menuState = BattleMenuState.None;
				OpenInteruptInfo(m_BattleController.current, CommonFunc.I18nGetLocalizedValue("I18N_EscapeFailed"));
				m_BattleController.current.InteruptIn(BattleObjectState.RoundOff, BattleControllerFlow.RoundOff);
			}
			else
			{
				m_BattleController.GameSetCommon();
				if (SharedData.Instance().SceneBefore4Camp.Length > 0)
				{
					m_BattleController.LoadScene(SharedData.Instance().SceneBefore4Camp);
				}
				else if (SharedData.Instance().SceneBefore.Length > 0)
				{
					SharedData.Instance().BackFromOtherScene = true;
					m_BattleController.LoadScene(SharedData.Instance().SceneBefore);
				}
				else
				{
					m_BattleController.LoadScene("BattleField");
				}
			}
		}
		else if (go.name == "SaveRound")
		{
			m_BattleController.RecordCurrentRoundInfo();
		}
		else if (go.name == "BackPrevRound")
		{
			m_BattleController.BackPrevRound();
		}
		else if (go.name == "FlowStatus")
		{
			if (m_BattleController.m_curcor.selected != null)
			{
				SetFlowStatus(m_BattleController.m_curcor.selected);
			}
		}
		else if (go.name == "CloseFlowStatus")
		{
			CloseFlowStatus();
		}
		else if (go.name == "MTSystem")
		{
			OnPauseMenuCall();
		}
		string[] array = go.name.Split('|');
		if ((array[0] == "ItemBtn" || array[0] == "WuGong") && !CommonFunc.IsHoverOpen())
		{
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(go));
		}
	}

	private void OnPauseMenuCall()
	{
		m_PauseMenu.SetActive(!m_PauseMenu.activeInHierarchy);
		if (m_PauseMenu.activeInHierarchy)
		{
			if (EventSystem.current.currentSelectedGameObject != null)
			{
				CommonResourcesData.inputDeviceDetector.PushJoyStack();
			}
			m_PauseMenu.transform.Find("ReBattle").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("LoadRecord").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("Title").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("Cancel").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("ConfirmBackTitle").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("ConfirmReBattle").gameObject.SetActive(value: false);
			EventSystem.current.SetSelectedGameObject(m_PauseMenu.transform.Find("ReBattle").gameObject);
		}
		else
		{
			CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
		}
	}

	public void OnButtonAtkClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().interactable)
		{
			BattleJoyController.currentSelectWugong = go;
			m_BattleController.m_curcor.m_RemoteFirstClickPos = null;
			string[] array = go.name.Split('&');
			if (array[0] == "Cancel")
			{
				MenuAtkClickCancel();
			}
			else if (array[0] == "Attack")
			{
				StartCoroutine(DelayClickAttackBtn(go));
			}
		}
	}

	private IEnumerator DelayClickAttackBtn(GameObject go)
	{
		yield return null;
		string[] array = go.name.Split('&');
		WuGongDisp.SetActive(value: false);
		foreach (GameObject atkBtn in AtkBtnList)
		{
			if (atkBtn.GetComponent<Button>().interactable)
			{
				if (atkBtn == go)
				{
					atkBtn.GetComponent<Image>().sprite = SelectedSprite;
				}
				else
				{
					atkBtn.GetComponent<Image>().sprite = NormalSprite;
				}
			}
		}
		m_BattleController.current.SelectWuGong(array[1], _byhand: true);
		m_BattleController.current.m_LastSelectedAtkBtnName = go.name;
		m_BattleController.SetFlowState(BattleControllerFlow.ActionWaitAttack);
		m_BattleController.m_curcor.ResetCurcorPosition();
		Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position);
		m_BattleController.m_curcor.CurcorPosition(new Vector3Int(vector3Int.x, -vector3Int.y, 0), pressing: true);
	}

	public void OnButtonSetClick(GameObject go)
	{
		if (!go.GetComponent<Button>().interactable)
		{
			return;
		}
		if (go.name == "Return")
		{
			if (SharedData.Instance().m_isDaTianWangSiChallenge)
			{
				SharedData.Instance().m_DaTianWangSiLevel = 0;
				if (SharedData.Instance().AfterBattleWin.Length > 0 && SharedData.Instance().m_isBattleWin)
				{
					SharedData.Instance().FlagList[SharedData.Instance().AfterBattleWin] = 1;
				}
			}
			if (couldSubdue() && SharedData.Instance().m_SubdueList.Count > 0)
			{
				SharedData.Instance().SubdueManageFor = "Subdue";
				m_BattleController.LoadScene("SubdueManage");
			}
			else if (SharedData.Instance().SceneBefore4Camp.Length > 0)
			{
				m_BattleController.LoadScene(SharedData.Instance().SceneBefore4Camp);
			}
			else if (SharedData.Instance().SceneBefore.Length > 0)
			{
				SharedData.Instance().BackFromOtherScene = true;
				m_BattleController.LoadScene(SharedData.Instance().SceneBefore);
			}
			else
			{
				m_BattleController.LoadScene("BattleField");
			}
		}
		else if (go.name == "Continue")
		{
			SharedData.Instance().m_DaTianWangSiLevel++;
			string text = "";
			text = SharedData.Instance().m_DaTianWangSiLevel.ToString();
			SharedData.Instance().m_isDaTianWangSiChallenge = true;
			List<gang_b11Table.Row> list = CommonResourcesData.b11.FindAll_Arena("DaTianWangSi");
			if (list != null && list.Count > 0)
			{
				foreach (gang_b11Table.Row item in list)
				{
					if (item.Wave.Equals(text))
					{
						string[] array = item.Members.Split('|');
						int num = Random.Range(0, array.Length);
						SharedData.Instance().m_ArenaFightID = array[num];
						Debug.LogWarning("SharedData.Instance().m_ArenaFightID = " + SharedData.Instance().m_ArenaFightID);
						break;
					}
				}
			}
			string text2 = "BattleField-DaTianWangSi-" + Random.Range(1, 4) + "F";
			SharedData.Instance().b04BattleID = SharedData.Instance().m_ArenaFightID;
			SharedData.Instance().BattleGround = text2;
			foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
			{
				if (!(allBattleObj.charadata.originRace == "player") || !allBattleObj.isDead)
				{
					continue;
				}
				string id = allBattleObj.charadata.m_Id;
				string text3 = "";
				foreach (KeyValuePair<string, string> item2 in SharedData.Instance().PlayerSetting)
				{
					if (item2.Value == id)
					{
						text3 = item2.Key;
					}
				}
				if (text3 != "")
				{
					SharedData.Instance().PlayerSetting.Remove(text3);
				}
			}
			m_BattleController.LoadScene(text2);
		}
		else if (go.name == "Cancel" || go.name == "ConfirmBackTitleCancel" || go.name == "ConfirmReBattleCancel")
		{
			m_PauseMenu.SetActive(value: false);
			CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
			m_PauseMenu.transform.Find("ReBattle").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("LoadRecord").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("Title").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("Cancel").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("ConfirmBackTitle").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("ConfirmReBattle").gameObject.SetActive(value: false);
		}
		else if (go.name == "Title")
		{
			m_PauseMenu.transform.Find("ReBattle").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("LoadRecord").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("Title").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("Cancel").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("ConfirmBackTitle").gameObject.SetActive(value: true);
			m_PauseMenu.transform.Find("ConfirmReBattle").gameObject.SetActive(value: false);
			EventSystem.current.SetSelectedGameObject(m_PauseMenu.transform.Find("ConfirmBackTitle/ConfirmBackTitleCancel").gameObject);
		}
		else if (go.name == "ReBattle")
		{
			m_PauseMenu.transform.Find("ReBattle").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("LoadRecord").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("Title").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("Cancel").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("ConfirmBackTitle").gameObject.SetActive(value: false);
			m_PauseMenu.transform.Find("ConfirmReBattle").gameObject.SetActive(value: true);
			EventSystem.current.SetSelectedGameObject(m_PauseMenu.transform.Find("ConfirmReBattle/ConfirmReBattleCancel").gameObject);
		}
		else if (go.name == "LoadRecord")
		{
			GetComponent<CanvasGroup>().interactable = false;
			m_PauseMenu.SetActive(value: false);
			SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
			SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Load;
			SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
		}
		else if (go.name == "ConfirmBackTitleYes")
		{
			m_BattleController.LoadScene("Title");
		}
		else if (go.name == "ConfirmReBattleYes")
		{
			m_BattleController.ReLoadBattle();
		}
		else if (go.name == "ReLoad")
		{
			if (SharedData.Instance().AfterBattleWin.Length > 0)
			{
				SharedData.Instance().FlagList[SharedData.Instance().AfterBattleWin] = 0;
			}
			if (SharedData.Instance().AfterBattleLose.Length > 0)
			{
				SharedData.Instance().FlagList[SharedData.Instance().AfterBattleLose] = 0;
			}
			m_BattleController.ReLoadBattle();
		}
	}

	public void MenuAtkClickCancel()
	{
		m_menuState = BattleMenuState.AutoBattleShow;
		RangeManager.ClearAllRange();
		BattleControllerFlow battleControllerFlow = BattleControllerFlow.None;
		if (m_BattleController.m_Flow == BattleControllerFlow.ActionWaitAttack)
		{
			battleControllerFlow = BattleControllerFlow.PlayerMenuClick;
		}
		StartCoroutine(RangeManager.ShowUnitRangeCoroutine(m_BattleController.current, reCallAStarPathDict: false, battleControllerFlow));
		m_BattleController.m_curcor.ResetCurcorPosition();
		StartCoroutine(OnButtonAtkClick_Callback());
	}

	protected IEnumerator OnButtonAtkClick_Callback()
	{
		yield return new WaitForSeconds(0.1f);
		m_BattleController.SetCameraSmooth(m_BattleController.current);
		m_BattleController.SetFlowState(BattleControllerFlow.MoveWait);
	}

	private void UnlockAchievement()
	{
		if (SharedData.Instance().UnlockAchievementInfoList.Count == 0)
		{
			return;
		}
		foreach (KeyValuePair<string, Sprite> unlockAchievementInfo in SharedData.Instance().UnlockAchievementInfoList)
		{
			if (SharedData.Instance().UnlockAchievementInfoAlreadyShow.Contains(unlockAchievementInfo.Key))
			{
				continue;
			}
			foreach (Transform achievementsInfo in AchievementsInfoList)
			{
				if (!achievementsInfo.GetComponent<Animation>().isPlaying)
				{
					achievementsInfo.Find("Text").GetComponent<Text>().text = unlockAchievementInfo.Key;
					achievementsInfo.Find("Image").GetComponent<Image>().sprite = unlockAchievementInfo.Value;
					achievementsInfo.GetComponent<Animation>()["Achievements" + achievementsInfo.gameObject.name[achievementsInfo.gameObject.name.Length - 1]].speed = 1f;
					achievementsInfo.GetComponent<Animation>().Play();
					SharedData.Instance().UnlockAchievementInfoAlreadyShow.Add(unlockAchievementInfo.Key);
					break;
				}
			}
		}
	}

	private void UnlockAtlas()
	{
		if (SharedData.Instance().UnlockAtlasInfoList.Count == 0)
		{
			return;
		}
		foreach (KeyValuePair<string, Sprite> unlockAtlasInfo in SharedData.Instance().UnlockAtlasInfoList)
		{
			if (SharedData.Instance().UnlockAtlasInfoAlreadyShow.Contains(unlockAtlasInfo.Key))
			{
				continue;
			}
			foreach (Transform atlasInfo in AtlasInfoList)
			{
				if (!atlasInfo.GetComponent<Animation>().isPlaying)
				{
					atlasInfo.Find("Text").GetComponent<Text>().text = CommonFunc.ShortLangSel("解锁图鉴", "Unlock Atlas ") + "[" + unlockAtlasInfo.Key + "]";
					atlasInfo.Find("Image").GetComponent<Image>().sprite = unlockAtlasInfo.Value;
					atlasInfo.GetComponent<Animation>()["Achievements" + atlasInfo.gameObject.name[atlasInfo.gameObject.name.Length - 1]].speed = 1f;
					atlasInfo.GetComponent<Animation>().Play();
					SharedData.Instance().UnlockAtlasInfoAlreadyShow.Add(unlockAtlasInfo.Key);
					break;
				}
			}
		}
	}

	public void ShowAfterBattleCal(int money, int TotalExp, string dropItemString)
	{
		m_GameSet.transform.Find("Player/Money/Info").GetComponent<Text>().text = money.ToString();
		m_GameSet.transform.Find("Player/EXP/Info").GetComponent<Text>().text = TotalExp.ToString();
		m_GameSet.transform.Find("Player/Item/Info").GetComponent<Text>().text = dropItemString.ToString();
		int num = 0;
		foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
		{
			if (!(allBattleObj.charadata.originRace == "enemy") && (!(allBattleObj.charadata.m_Table == "b04") || SharedData.Instance().FollowList.Contains(allBattleObj.charadata.m_Id)))
			{
				num++;
				m_GameSet.transform.Find("Player/CharacterList/Character" + num).gameObject.SetActive(value: true);
				m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(allBattleObj.charadata);
				m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/Name").GetComponent<Text>().text = allBattleObj.charadata.Indexs_Name["Name"].stringValue;
				m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/LV").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + "<size=35>" + allBattleObj.charadata.m_Level + "</size>";
				gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(allBattleObj.charadata.m_Level.ToString() ?? "");
				if (row != null)
				{
					float num2 = float.Parse(row.EXP, CultureInfo.InvariantCulture);
					m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/Exp").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Exp") + allBattleObj.charadata.m_Exp + "/" + num2;
					m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/ExpBar").GetComponent<Slider>().value = (float)allBattleObj.charadata.m_Exp / num2;
				}
				else
				{
					m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/Exp").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Exp") + allBattleObj.charadata.m_Exp + "/0";
					m_GameSet.transform.Find("Player/CharacterList/Character" + num + "/ExpBar").GetComponent<Slider>().value = 100f;
				}
			}
		}
	}

	public void ShowChallengInfo()
	{
		List<string> list = new List<string>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < SharedData.Instance().m_challengePrizeItemList.Count; i++)
		{
			if (list.Contains(SharedData.Instance().m_challengePrizeItemList[i]))
			{
				list2[list.IndexOf(SharedData.Instance().m_challengePrizeItemList[i])] += SharedData.Instance().m_challengePrizeNumberList[i];
				continue;
			}
			list.Add(SharedData.Instance().m_challengePrizeItemList[i]);
			list2.Add(SharedData.Instance().m_challengePrizeNumberList[i]);
		}
		m_GameSet.transform.Find("Player/ChallengeInfo").gameObject.SetActive(value: true);
		string text = "";
		for (int j = 0; j < list.Count; j++)
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(list[j]);
			text = text + row.Name_Trans + " * " + list2[j] + "\n";
		}
		m_GameSet.transform.Find("Player/ChallengeInfo/Info").GetComponent<Text>().text = text;
	}

	public void UpdateCharacterInfo(BattleObject _selected)
	{
		_currentShowPlayer = _selected;
		CurrentPlayer.SetActive(value: true);
		if (_selected.charadata.m_BattleIcon != "" && m_menuState == BattleMenuState.AutoBattleShow)
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(_selected.charadata.m_BattleIcon);
			if (tachieFull != null)
			{
				CurrentPlayer.transform.Find("Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
				CurrentPlayer.transform.Find("Tachie").gameObject.SetActive(value: true);
			}
			else
			{
				CurrentPlayer.transform.Find("Tachie").gameObject.SetActive(value: false);
				CurrentPlayer.transform.Find("Tachie/Tachie").GetComponent<Image>().sprite = TransSprite;
			}
		}
		CurrentPlayer.transform.Find("NameUI/LV").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + "<size=35>" + _selected.charadata.m_Level + "</size>";
		CurrentPlayer.transform.Find("NameUI/Name").GetComponent<Text>().text = _selected.charadata.Indexs_Name["Name"].stringValue;
		CurrentPlayer.transform.Find("Border/HP").GetComponent<Text>().text = _selected.charadata.m_Hp + "/" + _selected.charadata.GetBattleValueByName("HP");
		float num = saturate(_selected.charadata.GetBattleValueByName("Hurt") / 255f);
		float num2 = Mathf.Floor(_selected.charadata.GetBattleValueByName("MP"));
		float num3 = Mathf.Floor(num2 * (1f - num));
		CurrentPlayer.transform.Find("Border/MP").GetComponent<Text>().text = _selected.charadata.m_Mp + "/" + num2;
		CurrentPlayer.transform.Find("Border/SP").GetComponent<Text>().text = _selected.charadata.GetBattleValueByName("SP").ToString() ?? "";
		CurrentPlayer.transform.Find("Border/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(_selected.charadata);
		CurrentPlayer.transform.Find("States/HpBar").GetComponent<Slider>().value = _selected.charadata.m_Hp / _selected.charadata.GetBattleValueByName("HP");
		CurrentPlayer.transform.Find("States/MpBar/CurMp").GetComponent<Image>().fillAmount = _selected.charadata.m_Mp / num2;
		CurrentPlayer.transform.Find("States/MpBar/GrayMp").GetComponent<Image>().fillAmount = (num2 - num3) / num2;
		gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(_selected.charadata.m_Level.ToString() ?? "");
		if (row != null)
		{
			float num4 = float.Parse(row.EXP, CultureInfo.InvariantCulture);
			CurrentPlayer.transform.Find("NameUI/Exp").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Exp") + _selected.charadata.m_Exp + "/" + num4;
			CurrentPlayer.transform.Find("NameUI/ExpBar").GetComponent<Slider>().value = (float)_selected.charadata.m_Exp / num4;
		}
		else
		{
			CurrentPlayer.transform.Find("NameUI/Exp").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Exp") + _selected.charadata.m_Exp + "/0";
			CurrentPlayer.transform.Find("NameUI/ExpBar").GetComponent<Slider>().value = 100f;
		}
		UpdateBuffs(_selected);
	}

	private void UpdateBuffs(BattleObject _target = null)
	{
		if (_target == null)
		{
			_target = m_BattleController.current;
		}
		Transform transform = base.transform.Find("CurrentPlayer/BuffList");
		foreach (Transform item in transform)
		{
			Object.Destroy(item.gameObject);
		}
		Dictionary<string, float> dictionary = new Dictionary<string, float>();
		foreach (BuffData buff in _target.m_Buffs)
		{
			if (dictionary.ContainsKey(buff.name))
			{
				dictionary[buff.name] += buff.value;
			}
			else
			{
				dictionary.Add(buff.name, buff.value);
			}
		}
		Text[] componentsInChildren = base.transform.Find("CurrentPlayer/SimpBuffs").GetComponentsInChildren<Text>();
		foreach (Text text in componentsInChildren)
		{
			if (!"Text".Equals(text.transform.parent.name))
			{
				float battleValueByName = _target.charadata.GetBattleValueByName(text.transform.parent.name, isOrigin: true);
				if (battleValueByName > 0f)
				{
					dictionary.Add(text.transform.parent.name, battleValueByName);
				}
			}
		}
		GameObject original = (GameObject)Resources.Load("Prefabs/BattleMenu/BuffUI");
		int num = 0;
		foreach (KeyValuePair<string, float> item2 in dictionary)
		{
			if (item2.Key == "Goldenbell" && m_BattleController.current.CheckBuffEffectOn("Goldenbell"))
			{
				continue;
			}
			GameObject gameObject = Object.Instantiate(original, transform);
			gameObject.transform.localPosition = new Vector3(0f, 50f * (float)num, 0f);
			Sprite sprite = Resources.Load("images/07-icon/300-" + item2.Key, typeof(Sprite)) as Sprite;
			if (sprite == null)
			{
				sprite = Resources.Load("images/07-icon/300-Common", typeof(Sprite)) as Sprite;
			}
			gameObject.transform.Find("Image").GetComponent<Image>().sprite = sprite;
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(item2.Key);
			string text2 = "";
			if (item2.Value != 0f)
			{
				float num2 = ("2".Equals(row.Type) ? 100f : 1f);
				string text3 = ("2".Equals(row.Type) ? "%" : "");
				text2 = ((item2.Value > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num2 * item2.Value)) + text3;
			}
			string nameUI_Trans = row.NameUI_Trans;
			gameObject.transform.Find("Text").GetComponent<Text>().text = nameUI_Trans + text2;
			if ("Spit".Equals(item2.Key))
			{
				BattleObject battleObject = ((_target.GetBuffByName("Spit") != null) ? SharedData.Instance().m_BattleController.allBattleObjs.Find((BattleObject x) => x.name == _target.GetBuffByName("Spit").source.Split("|")[2]) : null);
				if (battleObject != null)
				{
					if (battleObject.isDead)
					{
						gameObject.transform.Find("Text").GetComponent<Text>().text = "<color=red>" + battleObject.charadata.Indexs_Name["Name"].stringValue + "</color> " + CommonFunc.I18nGetLocalizedValue("I18N_Revenge");
					}
					else
					{
						gameObject.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_TauntedBy") + " <color=red>" + battleObject.charadata.Indexs_Name["Name"].stringValue + "</color> " + CommonFunc.I18nGetLocalizedValue("I18N_Spiting");
					}
				}
			}
			else if ("StealHpMpAddCrazyBuff".Equals(item2.Key))
			{
				gameObject.transform.Find("Text").GetComponent<Text>().text = string.Format(nameUI_Trans, text2, _target.GetBuffByName("StealHpMpAddCrazyBuff").turn);
			}
			else if ("KillAddCrazyBuff".Equals(item2.Key))
			{
				gameObject.transform.Find("Text").GetComponent<Text>().text = string.Format(nameUI_Trans, _target.GetBuffByName("KillAddCrazyBuff").value * 0.25f * 100f, _target.GetBuffByName("KillAddCrazyBuff").value * 0.1f * 100f);
			}
			else if ("FoMoZhiJian".Equals(item2.Key))
			{
				gameObject.transform.Find("Text").GetComponent<Text>().text = string.Format(nameUI_Trans, _target.GetBuffByName("FoMoZhiJian").value * 0.25f * 100f, _target.GetBuffByName("FoMoZhiJian").value * 0.1f * 100f);
			}
			else if ("Ironvest".Equals(item2.Key))
			{
				gameObject.transform.Find("Text").GetComponent<Text>().text = nameUI_Trans + item2.Value + CommonFunc.I18nGetLocalizedValue("I18N_Times");
			}
			num++;
		}
	}

	private float saturate(float _input)
	{
		if (_input > 1f)
		{
			return 1f;
		}
		if (_input < 0f)
		{
			return 0f;
		}
		return _input;
	}

	public void FlowStatusHoverCheck()
	{
		if (!InputDeviceDetector.instance.isMouseInput)
		{
			return;
		}
		Vector3Int vector3Int = m_BattleController.tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
		Vector3Int cur = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		BattleObject battleObject = m_BattleController.allBattleObjs.Find((BattleObject x) => x.GetGridPosition() == cur && !x.isDead && x.isSelectable);
		if (battleObject != null)
		{
			base.transform.Find("FlowStatusInfo").gameObject.SetActive(value: true);
		}
		else
		{
			base.transform.Find("FlowStatusInfo").gameObject.SetActive(value: false);
		}
		if (cur.Equals(preFlowPos) && Input.GetMouseButton(0))
		{
			if (m_FlowStatusTimemark > 0f)
			{
				m_FlowStatusTimemark -= Time.deltaTime;
			}
			else if (!m_FlowStatus.activeInHierarchy && battleObject != null)
			{
				SetFlowStatus(battleObject);
			}
		}
		else
		{
			preFlowPos = cur;
			m_FlowStatusTimemark = 1f;
		}
	}

	public void SetFlowStatus(BattleObject obj)
	{
		m_FlowStatus.SetActive(value: true);
		EventSystem.current.SetSelectedGameObject(m_FlowStatus.transform.Find("Area/Area1/Status1/STR").gameObject);
		m_ActionMenu.GetComponent<CanvasGroup>().interactable = false;
		CommonFunc.CloseHover();
		m_FlowStatus.transform.Find("Title/Name").GetComponent<Text>().text = obj.charadata.Indexs_Name["Name"].stringValue;
		m_FlowStatus.transform.Find("Title/Lv").GetComponent<Text>().text = obj.charadata.m_Level.ToString();
		gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(obj.charadata.m_Level.ToString() ?? "");
		if (row != null)
		{
			float num = float.Parse(row.EXP, CultureInfo.InvariantCulture);
			m_FlowStatus.transform.Find("Title/Exp").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Exp") + obj.charadata.m_Exp + "/" + num;
			m_FlowStatus.transform.Find("Title/ExpBar").GetComponent<Slider>().value = (float)obj.charadata.m_Exp / num;
		}
		else
		{
			m_FlowStatus.transform.Find("Title/Exp").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Exp") + obj.charadata.m_Exp + "/0";
			m_FlowStatus.transform.Find("Title/ExpBar").GetComponent<Slider>().value = 100f;
		}
		Transform obj2 = m_FlowStatus.transform.Find("Area");
		Transform transform = obj2.Find("Area1");
		Transform transform2 = obj2.Find("Area2");
		Transform area3Trans = obj2.Find("Area3");
		Transform transform3 = obj2.Find("Area4");
		Transform transform4 = obj2.Find("Area5");
		Transform transform5 = obj2.Find("Area6");
		transform.Find("SelcetTeammate/IconMask/IconBG").gameObject.SetActive(value: true);
		transform.Find("IsPokemon").gameObject.SetActive(obj.isPokemon);
		Sprite tachieHead = CommonResourcesData.GetTachieHead(obj.charadata.m_BattleIcon);
		if (tachieHead == null)
		{
			transform.Find("SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: false);
			transform.Find("SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
			transform.Find("SelcetTeammate/IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(obj.charadata);
		}
		else
		{
			transform.Find("SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: true);
			transform.Find("SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
			transform.Find("SelcetTeammate/IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
		}
		foreach (IronMan item in transform.Find("Status1").GetComponentsInChildren<IronMan>(includeInactive: true).ToList())
		{
			item.transform.Find("Title/Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[item.gameObject.name].NameUI_Trans;
			item.atomData = obj.charadata.Indexs_Name[item.gameObject.name];
			item.transform.Find("Hover/Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[item.gameObject.name].Note_Trans;
			item.Init(obj.charadata.Indexs_Name[item.gameObject.name], obj.charadata);
			item.transform.Find("Num").GetComponent<Text>().text = obj.charadata.GetFieldValueByName(item.gameObject.name).ToString();
		}
		transform2.Find("Status/HP/Num").GetComponent<Text>().text = obj.charadata.m_Hp + "/" + obj.charadata.GetFieldValueByName("HP");
		transform2.Find("Status/MP/Num").GetComponent<Text>().text = obj.charadata.m_Mp + "/" + obj.charadata.GetFieldValueByName("MP");
		transform2.Find("Status/Line1/ATK/Num").GetComponent<Text>().text = obj.charadata.GetFieldValueByName("ATK").ToString() ?? "";
		transform2.Find("Status/Line2/DEF/Num").GetComponent<Text>().text = obj.charadata.GetFieldValueByName("DEF").ToString() ?? "";
		transform2.Find("Status/Line3/SP/Num").GetComponent<Text>().text = obj.charadata.GetFieldValueByName("SP").ToString() ?? "";
		transform2.Find("Status/Line1/Crit/Num").GetComponent<Text>().text = Mathf.RoundToInt(obj.charadata.GetFieldValueByName("Crit") * 100f) + "%";
		transform2.Find("Status/Line2/Crit1/Num").GetComponent<Text>().text = Mathf.RoundToInt(obj.charadata.GetFieldValueByName("Crit1") * 100f) + "%";
		transform2.Find("Status/Line3/Combo/Num").GetComponent<Text>().text = Mathf.RoundToInt(obj.charadata.GetFieldValueByName("Combo") * 100f) + "%";
		SetFlowStatusArea3(obj.charadata, "Sword", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Knife", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Stick", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Hand", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Finger", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Special", area3Trans);
		SetFlowStatusArea3(obj.charadata, "YinYang", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Melody", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Medical", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Wineart", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Darts", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Steal", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Forge", area3Trans);
		SetFlowStatusArea3(obj.charadata, "Percept", area3Trans);
		Transform transform6 = transform3.Find("KFList/Viewport/Content");
		for (int num2 = transform6.childCount - 1; num2 >= 0; num2--)
		{
			Object.DestroyImmediate(transform6.GetChild(num2).gameObject);
		}
		foreach (KongFuData kongFu in obj.charadata.m_KongFuList)
		{
			string text = "";
			text = ((!kongFu.kf.ID.Equals(obj.charadata.m_Training_Id)) ? kongFu.kf.Name_Trans : ("*" + kongFu.kf.Name_Trans));
			GameObject obj3 = Object.Instantiate(KFSimpleItemPrefab, transform3.Find("KFList/Viewport/Content"));
			gang_b07Table.Row row2 = CommonResourcesData.b07.Find_Relate_Wugong_id(kongFu.kf.ID);
			obj3.name = "WuGong|" + row2.ID;
			obj3.transform.Find("LV/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + kongFu.lv + "/" + kongFu.kf.LV;
			obj3.transform.Find("Name").GetComponent<Text>().text = text;
			obj3.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + kongFu.kf.Icon, typeof(Sprite)) as Sprite;
			EventTriggerListener.Get(obj3).onClick = OnButtonClick;
		}
		AdjustScrollView(transform3.Find("KFList").GetComponent<ScrollRect>());
		Transform transform7 = transform4.Find("TraitList/Viewport/Content");
		for (int num3 = transform7.childCount - 1; num3 >= 0; num3--)
		{
			Object.DestroyImmediate(transform7.GetChild(num3).gameObject);
		}
		foreach (string trait in obj.charadata.m_TraitList)
		{
			gang_b06Table.Row row3 = CommonResourcesData.b06.Find_id(trait);
			if (row3 == null || !obj.charadata.m_EquipTraitDict.ContainsValue(row3.id))
			{
				continue;
			}
			GameObject gameObject = Object.Instantiate(TraitDetailsPrefab, transform4.Find("TraitList/Viewport/Content"));
			string text2 = row3.traitEquipIndex;
			if (obj.charadata.m_EquipTraitDict.ContainsValue(row3.id))
			{
				foreach (KeyValuePair<string, string> item2 in obj.charadata.m_EquipTraitDict)
				{
					if (item2.Value == row3.id)
					{
						text2 = item2.Key;
						break;
					}
				}
			}
			gameObject.transform.Find("TraitIcon").GetComponent<TraitIconController>().InitTraitIcon(row3.id, text2, int.Parse(text2) >= 10);
			gameObject.name = row3.id + "|" + row3.traitEquipIndex;
			gameObject.transform.Find("Name/Text").GetComponent<Text>().text = row3.name_Trans;
			gameObject.transform.Find("Lock").gameObject.SetActive(value: false);
			gameObject.transform.Find("Info/Text").GetComponent<Text>().text = row3.note_Trans;
			gameObject.transform.Find("Hover/Text").GetComponent<Text>().text = row3.comment_Trans;
			float preferredHeight = gameObject.transform.Find("Info/Text").GetComponent<Text>().preferredHeight;
			RectTransform component = gameObject.transform.Find("Info").GetComponent<RectTransform>();
			component.sizeDelta = new Vector2(component.sizeDelta.x, preferredHeight + 35f);
			RectTransform component2 = gameObject.GetComponent<RectTransform>();
			component2.sizeDelta = new Vector2(component2.sizeDelta.x, component.sizeDelta.y + 100f);
		}
		AdjustScrollView(transform4.Find("TraitList").GetComponent<ScrollRect>());
		int num4 = 1;
		foreach (Transform item3 in transform5.Find("ItemList/Viewport/Content").transform)
		{
			item3.name = "Stealable" + num4;
			num4++;
		}
		Transform transform8 = transform5.Find("ItemList/Viewport/Content");
		for (int i = 0; i < transform8.childCount; i++)
		{
			GameObject obj4 = transform8.GetChild(i).gameObject;
			obj4.GetComponent<PackageIconController>().InitPackageIcon(null, 0, null, 0);
			obj4.GetComponent<HoverWGController>().enabled = false;
		}
		if (obj.m_StealableItemsName == null)
		{
			return;
		}
		for (int j = 1; j <= obj.m_StealableItemsName.Count; j++)
		{
			int num5 = obj.m_StealableItemsNum[j - 1];
			if (num5 > 0)
			{
				gang_b07Table.Row row4 = CommonResourcesData.b07.Find_ID(obj.m_StealableItemsName[j - 1].Item);
				if (row4 != null)
				{
					GameObject obj5 = transform8.GetChild(j - 1).gameObject;
					EventTriggerListener.Get(obj5).onClick = OnButtonClick;
					obj5.GetComponent<HoverWGController>().enabled = true;
					obj5.GetComponent<PackageIconController>().InitPackageIcon(row4, num5, null, 0);
					obj5.name = "Stealable|" + row4.ID;
				}
			}
		}
	}

	private void SetFlowStatusArea3(CharaData _curdata, string _name, Transform area3Trans)
	{
		IronMan component = area3Trans.Find("SkillAttr/" + _name).GetComponent<IronMan>();
		component.atomData = _curdata.Indexs_Name[_name];
		component.Init(_curdata.Indexs_Name[_name], _curdata);
		area3Trans.Find("SkillAttr/" + _name + "/NameText").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[_name].NameScene_Trans;
		area3Trans.Find("SkillAttr/" + _name + "/Text").GetComponent<Text>().text = _curdata.GetFieldValueByName(_name).ToString();
		area3Trans.Find("SkillAttr/" + _name + "/Hover/Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[_name].Note_Trans;
	}

	private void AdjustScrollView(ScrollRect ScrollViewRect)
	{
		int num = 0;
		float num2 = 0f;
		float num3 = 0f;
		for (int i = 0; i < ScrollViewRect.content.childCount; i++)
		{
			Transform child = ScrollViewRect.content.transform.GetChild(i);
			if (child.gameObject.activeInHierarchy)
			{
				num++;
				if (num == 1)
				{
					num3 = child.GetComponent<RectTransform>().sizeDelta.x;
					num2 = child.GetComponent<RectTransform>().sizeDelta.y;
				}
			}
		}
		float num4 = 0f;
		if (ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>() != null)
		{
			num4 = ScrollViewRect.content.GetComponent<HorizontalLayoutGroup>().spacing;
		}
		else if (ScrollViewRect.content.GetComponent<GridLayoutGroup>() != null)
		{
			num4 = ScrollViewRect.content.GetComponent<GridLayoutGroup>().spacing.x;
		}
		RectTransform component = ScrollViewRect.content.GetComponent<RectTransform>();
		int num5 = (int)(component.sizeDelta.x / (num3 + num4));
		num5 = ((num5 == 0) ? 1 : num5);
		int num6 = num / num5;
		num6 = ((num6 == 0) ? 1 : num6);
		RectTransform component2 = ScrollViewRect.GetComponent<RectTransform>();
		float y = (((float)num6 * num2 > component2.sizeDelta.y) ? ((float)num6 * num2) : component2.sizeDelta.y);
		component.sizeDelta = new Vector2(component.sizeDelta.x, y);
		component.anchoredPosition = new Vector2(component.anchoredPosition.x, 0f);
	}

	public void CloseFlowStatus()
	{
		m_FlowStatus.SetActive(value: false);
		EventSystem.current.SetSelectedGameObject(null);
		m_ActionMenu.GetComponent<CanvasGroup>().interactable = true;
	}

	public void DisplayWuGongInfo(KongFuData _kfdata)
	{
		string text = "";
		float num = float.Parse(_kfdata.kf.Damage, CultureInfo.InvariantCulture) + float.Parse(_kfdata.kf.Damageadd, CultureInfo.InvariantCulture) * (float)(_kfdata.lv - 1);
		if (num > 0f)
		{
			switch (_kfdata.kf.Style)
			{
			case "101":
				text += CommonFunc.I18nGetLocalizedValue("I18N_SwordDamage");
				break;
			case "201":
				text += CommonFunc.I18nGetLocalizedValue("I18N_SaberDamage");
				break;
			case "301":
				text += CommonFunc.I18nGetLocalizedValue("I18N_StaffDamage");
				break;
			case "401":
				text += CommonFunc.I18nGetLocalizedValue("I18N_HandDamage");
				break;
			case "501":
				text += CommonFunc.I18nGetLocalizedValue("I18N_FingerDamage");
				break;
			case "601":
				text += CommonFunc.I18nGetLocalizedValue("I18N_ConcealedDamage");
				break;
			case "701":
				text += CommonFunc.I18nGetLocalizedValue("I18N_MusicalDamage");
				break;
			case "801":
				text += CommonFunc.I18nGetLocalizedValue("I18N_DrunkenDamage");
				break;
			case "901":
				text += CommonFunc.I18nGetLocalizedValue("I18N_InnerHeartPower");
				break;
			case "1001":
				text += CommonFunc.I18nGetLocalizedValue("I18N_SpecialDamage");
				break;
			case "9101":
				text += CommonFunc.I18nGetLocalizedValue("I18N_FormationWugongDamage");
				break;
			case "9301":
				text += CommonFunc.I18nGetLocalizedValue("I18N_AssistWugongDamage");
				break;
			case "9401":
				text += CommonFunc.I18nGetLocalizedValue("I18N_RecipeDamage");
				break;
			case "9501":
				text += CommonFunc.I18nGetLocalizedValue("I18N_SpWugongDamage");
				break;
			case "9601":
				text += CommonFunc.I18nGetLocalizedValue("I18N_SpuerDamage");
				break;
			}
			text = text + " " + Mathf.RoundToInt(num);
		}
		if (int.Parse(_kfdata.kf.Beat) > 1)
		{
			text = text + ((!text.Equals("")) ? " | " : "") + _kfdata.kf.Beat + " " + CommonFunc.I18nGetLocalizedValue("I18N_MultiHit_2");
		}
		foreach (SkillShowInfoItem item in SkillHoverShowInfo.GetSkillShowInfo(_kfdata))
		{
			text = text + ((!text.Equals("")) ? (item.skillInfoType.Equals(SkillInfoType.Skill) ? "\n" : " | ") : "") + item.info;
		}
		string[] type = (_kfdata.kf.ID + "|" + _kfdata.kf.Attckstyle + "|" + _kfdata.lv).Split("|");
		WuGongDisp.transform.Find("Info/SelectRange/Value").GetComponent<Text>().text = AttackData.GetSelectRange(type).ToString();
		WuGongDisp.transform.Find("Info/AtkRange/Value").GetComponent<Text>().text = AttackData.GetRange2ByAttackType(type).Count.ToString();
		WuGongDisp.transform.Find("Info/SpaceRange/Value").GetComponent<Text>().text = _kfdata.kf.Space;
		WuGongDisp.transform.Find("Info/Decrease/Value").GetComponent<Text>().text = _kfdata.kf.Decreaserate;
		WuGongDisp.transform.Find("Txt").GetComponent<Text>().text = text;
		WuGongDisp.SetActive(value: true);
	}

	public void RefreshBattleInfo()
	{
		if (CurrentPlayer.activeInHierarchy)
		{
			float num = saturate(_currentShowPlayer.charadata.GetBattleValueByName("Hurt") / 255f);
			float num2 = Mathf.Floor(_currentShowPlayer.charadata.GetBattleValueByName("MP"));
			float num3 = Mathf.Floor(num2 * (1f - num));
			CurrentPlayer.transform.Find("Border/HP").GetComponent<Text>().text = _currentShowPlayer.charadata.m_Hp + "/" + _currentShowPlayer.charadata.GetBattleValueByName("HP");
			CurrentPlayer.transform.Find("Border/MP").GetComponent<Text>().text = _currentShowPlayer.charadata.m_Mp + "/" + num2;
			CurrentPlayer.transform.Find("States/HpBar").GetComponent<Slider>().value = _currentShowPlayer.charadata.m_Hp / _currentShowPlayer.charadata.GetBattleValueByName("HP");
			CurrentPlayer.transform.Find("States/MpBar/CurMp").GetComponent<Image>().fillAmount = _currentShowPlayer.charadata.m_Mp / num2;
			CurrentPlayer.transform.Find("States/MpBar/GrayMp").GetComponent<Image>().fillAmount = (num2 - num3) / num2;
		}
	}

	public void OnWinButtonClick()
	{
		SharedData.Instance().m_BattleController.isDebugWin = true;
	}

	public void OnLoseButtonClick()
	{
		SharedData.Instance().m_BattleController.isDebugLose = true;
	}
}
