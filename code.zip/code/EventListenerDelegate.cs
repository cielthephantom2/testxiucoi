public delegate void EventListenerDelegate(Message data);
