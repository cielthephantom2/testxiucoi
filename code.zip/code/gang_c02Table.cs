using System.Collections.Generic;
using UnityEngine;

public class gang_c02Table
{
	public class Row
	{
		public string roleid;

		public string itemid;

		public string point;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				roleid = list[i][num++],
				itemid = list[i][num++],
				point = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_roleid(string find)
	{
		return rowList.Find((Row x) => x.roleid == find);
	}

	public List<Row> FindAll_roleid(string find)
	{
		return rowList.FindAll((Row x) => x.roleid == find);
	}

	public Row Find_itemid(string find)
	{
		return rowList.Find((Row x) => x.itemid == find);
	}

	public List<Row> FindAll_itemid(string find)
	{
		return rowList.FindAll((Row x) => x.itemid == find);
	}

	public Row Find_point(string find)
	{
		return rowList.Find((Row x) => x.point == find);
	}

	public List<Row> FindAll_point(string find)
	{
		return rowList.FindAll((Row x) => x.point == find);
	}
}
