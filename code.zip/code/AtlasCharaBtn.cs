using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class AtlasCharaBtn : MonoBehaviour
{
	private AtlasCharaData atlasCharaData = new AtlasCharaData();

	public void Init(AtlasCharaData atlasChara)
	{
		List<gang_b10Table.Row> list = new List<gang_b10Table.Row>();
		for (int i = 20001; i <= 20010; i++)
		{
			list.Add(CommonResourcesData.b10.Find_ID(i.ToString()));
		}
		atlasCharaData = atlasChara;
		Sprite tachieFull = CommonResourcesData.GetTachieFull(atlasCharaData.b01Row.BattleIcon);
		base.transform.Find("Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
		base.transform.Find("Tachie/Tachie").GetComponent<Image>().color = (atlasCharaData.isUnlock ? Color.white : Color.black);
		base.transform.Find("Name/Text").GetComponent<Text>().text = (atlasCharaData.isUnlock ? atlasCharaData.b01Row.Name_Trans : "???");
		string iD = atlasCharaData.b01Row.ID;
		string text = "";
		string name_Trans = atlasCharaData.b01Row.Name_Trans;
		foreach (gang_b10Table.Row item in list)
		{
			if (item.Members.Split("|").ToList().Contains(atlasCharaData.b01Row.ID))
			{
				text = text + item.ID + "&";
			}
		}
		atlasCharaData.level1 = iD;
		atlasCharaData.level2 = text;
		atlasCharaData.level3 = name_Trans;
	}
}
