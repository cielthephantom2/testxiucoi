using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SkinDependences", menuName = "ScriptableObjects/SkinDependences", order = 1)]
public class SkinDependences : ScriptableObject
{
	public List<SkinDependence> skinDependences;
}
