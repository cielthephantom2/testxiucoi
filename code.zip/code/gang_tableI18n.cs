using System.Collections.Generic;
using UnityEngine;

public class gang_tableI18n
{
	public class Row
	{
		public string ID;

		public string zh_CH;

		public string en_US;

		public Row()
		{
			ID = "";
			zh_CH = "";
			en_US = "";
		}
	}

	private Dictionary<string, Row> rowDict = new Dictionary<string, Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public void Load(TextAsset csv)
	{
		rowDict.Clear();
		AddLoad(csv);
	}

	public void AddLoad(TextAsset csv)
	{
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row();
			row.ID = list[i][num++];
			row.zh_CH = list[i][num++];
			row.en_US = list[i][num++];
			rowDict.Add(row.ID, row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowDict.Count;
	}

	public Row Find_ID(string find)
	{
		if (!rowDict.ContainsKey(find))
		{
			Debug.LogWarning("gang_tableI18n no i18N data : " + find);
			return new Row
			{
				ID = "待翻译数据",
				zh_CH = "待翻译数据",
				en_US = "待翻译数据"
			};
		}
		if (rowDict[find].en_US.Equals(""))
		{
			rowDict[find].en_US = rowDict[find].zh_CH;
		}
		return rowDict[find];
	}
}
