using System;
using MessagePack;
using UnityEngine;

[Serializable]
[MessagePackObject(false)]
public class MineInfo
{
	[Key(0)]
	public string _scenename;

	[Key(1)]
	public Vector3Int _grid = Vector3Int.zero;

	[Key(2)]
	public string _tileObjName = "";

	[Key(3)]
	public string _c04ID = "";

	[Key(4)]
	public bool _isDigged;
}
