using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class MapIconController : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	private Vector3 originalScale;

	private Vector3 onEnterScale;

	public float scaleFactor = 2f;

	private RectTransform parentRT;

	private Vector3 parentScale;

	private Transform NameInfo;

	public gang_e07Table.Row e07Row;

	public Transform MapAreaItem;

	private bool isPointerStay;

	private void Start()
	{
		onEnterScale = base.transform.localScale;
		originalScale = base.transform.localScale;
		parentRT = base.transform.parent.parent.GetComponent<RectTransform>();
		parentScale = parentRT.localScale;
		NameInfo = base.transform.Find("Name");
		e07Row = CommonResourcesData.e07.Find_id(base.gameObject.name);
		if (e07Row == null)
		{
			Debug.LogWarning("Not found B07-ID: " + base.gameObject.name);
		}
		NameInfo.Find("Text").GetComponent<Text>().text = e07Row.name_Trans;
		if (!SharedData.Instance().m_UnLockMapIconList.Contains(base.gameObject.name))
		{
			base.gameObject.SetActive(value: false);
		}
	}

	private void Update()
	{
		if (!isPointerStay)
		{
			base.transform.localScale = onEnterScale / SharedData.Instance().m_MapViewController.MapImage.localScale.x;
		}
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		isPointerStay = true;
		base.transform.localScale = base.transform.localScale * scaleFactor;
		SharedData.Instance().m_MapViewController.ShowIconInfo(this);
		if (MapAreaItem.gameObject.activeInHierarchy)
		{
			MapAreaItem.GetComponent<MapAreaItemController>().OnEnter(isCallBySelf: false);
		}
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		isPointerStay = false;
		SharedData.Instance().m_MapViewController.HideIconInfo();
		base.transform.localScale = onEnterScale / SharedData.Instance().m_MapViewController.MapImage.localScale.x;
		if (MapAreaItem.gameObject.activeInHierarchy)
		{
			MapAreaItem.GetComponent<MapAreaItemController>().OnExit(isCallBySelf: false);
		}
	}
}
