using System.Collections.Generic;
using UnityEngine;

public class gang_b01Table
{
	public class Row
	{
		public string ID;

		public string Sex;

		public string Prefab;

		public string Sound;

		public string BattleIcon;

		public string Name;

		public string Name_EN;

		public string Age;

		public string Ranking;

		public string Nickname;

		public string Nickname_EN;

		public string Guild;

		public string Guild_EN;

		public string Duty;

		public string Duty_EN;

		public string Birthplace;

		public string Birthplace_EN;

		public string Birthdate;

		public string Birthdate_EN;

		public string Lifecode;

		public string Lifecode_EN;

		public string Position;

		public string Position_EN;

		public string Background;

		public string Background_EN;

		public string Depth;

		public string Depthvalue;

		public string LV;

		public string HP;

		public string MP;

		public string ATK;

		public string DEF;

		public string SP;

		public string STR;

		public string AGI;

		public string BON;

		public string WIL;

		public string LER;

		public string MOR;

		public string Sword;

		public string Knife;

		public string Stick;

		public string Hand;

		public string Finger;

		public string Special;

		public string YinYang;

		public string Melody;

		public string Medical;

		public string Darts;

		public string Wineart;

		public string Steal;

		public string Forge;

		public string Percept;

		public string kongfu1;

		public string KFLV1;

		public string kongfu2;

		public string KFLV2;

		public string kongfu3;

		public string KFLV3;

		public string kongfu4;

		public string KFLV4;

		public string kongfu5;

		public string KFLV5;

		public string Like;

		public string Hate;

		public string Favorite;

		public string Relationship;

		public string AiType;

		public string DropGroup;

		public string Traits;

		public string isAtlas;

		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);

		public string Nickname_Trans => CommonFunc.ShortLangSel(Nickname, Nickname_EN);

		public string Guild_Trans => CommonFunc.ShortLangSel(Guild, Guild_EN);

		public string Duty_Trans => CommonFunc.ShortLangSel(Duty, Duty_EN);

		public string Birthplace_Trans => CommonFunc.ShortLangSel(Birthplace, Birthplace_EN);

		public string Birthdate_Trans => CommonFunc.ShortLangSel(Birthdate, Birthdate_EN);

		public string Lifecode_Trans => CommonFunc.ShortLangSel(Lifecode, Lifecode_EN);

		public string Position_Trans => CommonFunc.ShortLangSel(Position, Position_EN);

		public string Background_Trans => CommonFunc.ShortLangSel(Background, Background_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Sex = list[i][num++],
				Prefab = list[i][num++],
				Sound = list[i][num++],
				BattleIcon = list[i][num++],
				Name = list[i][num++],
				Age = list[i][num++],
				Ranking = list[i][num++],
				Nickname = list[i][num++],
				Guild = list[i][num++],
				Duty = list[i][num++],
				Birthplace = list[i][num++],
				Birthdate = list[i][num++],
				Lifecode = list[i][num++],
				Position = list[i][num++],
				Background = list[i][num++],
				Depth = list[i][num++],
				Depthvalue = list[i][num++],
				LV = list[i][num++],
				HP = list[i][num++],
				MP = list[i][num++],
				ATK = list[i][num++],
				DEF = list[i][num++],
				SP = list[i][num++],
				STR = list[i][num++],
				AGI = list[i][num++],
				BON = list[i][num++],
				WIL = list[i][num++],
				LER = list[i][num++],
				MOR = list[i][num++],
				Sword = list[i][num++],
				Knife = list[i][num++],
				Stick = list[i][num++],
				Hand = list[i][num++],
				Finger = list[i][num++],
				Special = list[i][num++],
				YinYang = list[i][num++],
				Melody = list[i][num++],
				Medical = list[i][num++],
				Darts = list[i][num++],
				Wineart = list[i][num++],
				Steal = list[i][num++],
				Forge = list[i][num++],
				Percept = list[i][num++],
				kongfu1 = list[i][num++],
				KFLV1 = list[i][num++],
				kongfu2 = list[i][num++],
				KFLV2 = list[i][num++],
				kongfu3 = list[i][num++],
				KFLV3 = list[i][num++],
				kongfu4 = list[i][num++],
				KFLV4 = list[i][num++],
				kongfu5 = list[i][num++],
				KFLV5 = list[i][num++],
				Like = list[i][num++],
				Hate = list[i][num++],
				Favorite = list[i][num++],
				Relationship = list[i][num++],
				AiType = list[i][num++],
				DropGroup = list[i][num++],
				Traits = list[i][num++],
				isAtlas = list[i][num++]
			};
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Name")?.en_US;
			row.Nickname = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Nickname")?.zh_CH;
			row.Nickname_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Nickname")?.en_US;
			row.Guild = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Guild")?.zh_CH;
			row.Guild_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Guild")?.en_US;
			row.Duty = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Duty")?.zh_CH;
			row.Duty_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Duty")?.en_US;
			row.Birthplace = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Birthplace")?.zh_CH;
			row.Birthplace_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Birthplace")?.en_US;
			row.Birthdate = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Birthdate")?.zh_CH;
			row.Birthdate_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Birthdate")?.en_US;
			row.Lifecode = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Lifecode")?.zh_CH;
			row.Lifecode_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Lifecode")?.en_US;
			row.Position = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Position")?.zh_CH;
			row.Position_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Position")?.en_US;
			row.Background = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Background")?.zh_CH;
			row.Background_EN = I18nData.Instance().tableI18N.Find_ID("gang_b01_" + row.ID + "_Background")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		if (find.Contains("_"))
		{
			find = find.Split("_")[0];
		}
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Sex(string find)
	{
		return rowList.Find((Row x) => x.Sex == find);
	}

	public List<Row> FindAll_Sex(string find)
	{
		return rowList.FindAll((Row x) => x.Sex == find);
	}

	public Row Find_Prefab(string find)
	{
		return rowList.Find((Row x) => x.Prefab == find);
	}

	public List<Row> FindAll_Prefab(string find)
	{
		return rowList.FindAll((Row x) => x.Prefab == find);
	}

	public Row Find_Sound(string find)
	{
		return rowList.Find((Row x) => x.Sound == find);
	}

	public List<Row> FindAll_Sound(string find)
	{
		return rowList.FindAll((Row x) => x.Sound == find);
	}

	public Row Find_BattleIcon(string find)
	{
		return rowList.Find((Row x) => x.BattleIcon == find);
	}

	public List<Row> FindAll_BattleIcon(string find)
	{
		return rowList.FindAll((Row x) => x.BattleIcon == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Age(string find)
	{
		return rowList.Find((Row x) => x.Age == find);
	}

	public List<Row> FindAll_Age(string find)
	{
		return rowList.FindAll((Row x) => x.Age == find);
	}

	public Row Find_Ranking(string find)
	{
		return rowList.Find((Row x) => x.Ranking == find);
	}

	public List<Row> FindAll_Ranking(string find)
	{
		return rowList.FindAll((Row x) => x.Ranking == find);
	}

	public Row Find_Nickname(string find)
	{
		return rowList.Find((Row x) => x.Nickname == find);
	}

	public List<Row> FindAll_Nickname(string find)
	{
		return rowList.FindAll((Row x) => x.Nickname == find);
	}

	public Row Find_Guild(string find)
	{
		return rowList.Find((Row x) => x.Guild == find);
	}

	public List<Row> FindAll_Guild(string find)
	{
		return rowList.FindAll((Row x) => x.Guild == find);
	}

	public Row Find_Duty(string find)
	{
		return rowList.Find((Row x) => x.Duty == find);
	}

	public List<Row> FindAll_Duty(string find)
	{
		return rowList.FindAll((Row x) => x.Duty == find);
	}

	public Row Find_Birthplace(string find)
	{
		return rowList.Find((Row x) => x.Birthplace == find);
	}

	public List<Row> FindAll_Birthplace(string find)
	{
		return rowList.FindAll((Row x) => x.Birthplace == find);
	}

	public Row Find_Birthdate(string find)
	{
		return rowList.Find((Row x) => x.Birthdate == find);
	}

	public List<Row> FindAll_Birthdate(string find)
	{
		return rowList.FindAll((Row x) => x.Birthdate == find);
	}

	public Row Find_Lifecode(string find)
	{
		return rowList.Find((Row x) => x.Lifecode == find);
	}

	public List<Row> FindAll_Lifecode(string find)
	{
		return rowList.FindAll((Row x) => x.Lifecode == find);
	}

	public Row Find_Position(string find)
	{
		return rowList.Find((Row x) => x.Position == find);
	}

	public List<Row> FindAll_Position(string find)
	{
		return rowList.FindAll((Row x) => x.Position == find);
	}

	public Row Find_Background(string find)
	{
		return rowList.Find((Row x) => x.Background == find);
	}

	public List<Row> FindAll_Background(string find)
	{
		return rowList.FindAll((Row x) => x.Background == find);
	}

	public Row Find_Depth(string find)
	{
		return rowList.Find((Row x) => x.Depth == find);
	}

	public List<Row> FindAll_Depth(string find)
	{
		return rowList.FindAll((Row x) => x.Depth == find);
	}

	public Row Find_Depthvalue(string find)
	{
		return rowList.Find((Row x) => x.Depthvalue == find);
	}

	public List<Row> FindAll_Depthvalue(string find)
	{
		return rowList.FindAll((Row x) => x.Depthvalue == find);
	}

	public Row Find_LV(string find)
	{
		return rowList.Find((Row x) => x.LV == find);
	}

	public List<Row> FindAll_LV(string find)
	{
		return rowList.FindAll((Row x) => x.LV == find);
	}

	public Row Find_HP(string find)
	{
		return rowList.Find((Row x) => x.HP == find);
	}

	public List<Row> FindAll_HP(string find)
	{
		return rowList.FindAll((Row x) => x.HP == find);
	}

	public Row Find_MP(string find)
	{
		return rowList.Find((Row x) => x.MP == find);
	}

	public List<Row> FindAll_MP(string find)
	{
		return rowList.FindAll((Row x) => x.MP == find);
	}

	public Row Find_ATK(string find)
	{
		return rowList.Find((Row x) => x.ATK == find);
	}

	public List<Row> FindAll_ATK(string find)
	{
		return rowList.FindAll((Row x) => x.ATK == find);
	}

	public Row Find_DEF(string find)
	{
		return rowList.Find((Row x) => x.DEF == find);
	}

	public List<Row> FindAll_DEF(string find)
	{
		return rowList.FindAll((Row x) => x.DEF == find);
	}

	public Row Find_SP(string find)
	{
		return rowList.Find((Row x) => x.SP == find);
	}

	public List<Row> FindAll_SP(string find)
	{
		return rowList.FindAll((Row x) => x.SP == find);
	}

	public Row Find_STR(string find)
	{
		return rowList.Find((Row x) => x.STR == find);
	}

	public List<Row> FindAll_STR(string find)
	{
		return rowList.FindAll((Row x) => x.STR == find);
	}

	public Row Find_AGI(string find)
	{
		return rowList.Find((Row x) => x.AGI == find);
	}

	public List<Row> FindAll_AGI(string find)
	{
		return rowList.FindAll((Row x) => x.AGI == find);
	}

	public Row Find_BON(string find)
	{
		return rowList.Find((Row x) => x.BON == find);
	}

	public List<Row> FindAll_BON(string find)
	{
		return rowList.FindAll((Row x) => x.BON == find);
	}

	public Row Find_WIL(string find)
	{
		return rowList.Find((Row x) => x.WIL == find);
	}

	public List<Row> FindAll_WIL(string find)
	{
		return rowList.FindAll((Row x) => x.WIL == find);
	}

	public Row Find_LER(string find)
	{
		return rowList.Find((Row x) => x.LER == find);
	}

	public List<Row> FindAll_LER(string find)
	{
		return rowList.FindAll((Row x) => x.LER == find);
	}

	public Row Find_MOR(string find)
	{
		return rowList.Find((Row x) => x.MOR == find);
	}

	public List<Row> FindAll_MOR(string find)
	{
		return rowList.FindAll((Row x) => x.MOR == find);
	}

	public Row Find_Sword(string find)
	{
		return rowList.Find((Row x) => x.Sword == find);
	}

	public List<Row> FindAll_Sword(string find)
	{
		return rowList.FindAll((Row x) => x.Sword == find);
	}

	public Row Find_Knife(string find)
	{
		return rowList.Find((Row x) => x.Knife == find);
	}

	public List<Row> FindAll_Knife(string find)
	{
		return rowList.FindAll((Row x) => x.Knife == find);
	}

	public Row Find_Stick(string find)
	{
		return rowList.Find((Row x) => x.Stick == find);
	}

	public List<Row> FindAll_Stick(string find)
	{
		return rowList.FindAll((Row x) => x.Stick == find);
	}

	public Row Find_Hand(string find)
	{
		return rowList.Find((Row x) => x.Hand == find);
	}

	public List<Row> FindAll_Hand(string find)
	{
		return rowList.FindAll((Row x) => x.Hand == find);
	}

	public Row Find_Finger(string find)
	{
		return rowList.Find((Row x) => x.Finger == find);
	}

	public List<Row> FindAll_Finger(string find)
	{
		return rowList.FindAll((Row x) => x.Finger == find);
	}

	public Row Find_Special(string find)
	{
		return rowList.Find((Row x) => x.Special == find);
	}

	public List<Row> FindAll_Special(string find)
	{
		return rowList.FindAll((Row x) => x.Special == find);
	}

	public Row Find_YinYang(string find)
	{
		return rowList.Find((Row x) => x.YinYang == find);
	}

	public List<Row> FindAll_YinYang(string find)
	{
		return rowList.FindAll((Row x) => x.YinYang == find);
	}

	public Row Find_Melody(string find)
	{
		return rowList.Find((Row x) => x.Melody == find);
	}

	public List<Row> FindAll_Melody(string find)
	{
		return rowList.FindAll((Row x) => x.Melody == find);
	}

	public Row Find_Medical(string find)
	{
		return rowList.Find((Row x) => x.Medical == find);
	}

	public List<Row> FindAll_Medical(string find)
	{
		return rowList.FindAll((Row x) => x.Medical == find);
	}

	public Row Find_Darts(string find)
	{
		return rowList.Find((Row x) => x.Darts == find);
	}

	public List<Row> FindAll_Darts(string find)
	{
		return rowList.FindAll((Row x) => x.Darts == find);
	}

	public Row Find_Wineart(string find)
	{
		return rowList.Find((Row x) => x.Wineart == find);
	}

	public List<Row> FindAll_Wineart(string find)
	{
		return rowList.FindAll((Row x) => x.Wineart == find);
	}

	public Row Find_Steal(string find)
	{
		return rowList.Find((Row x) => x.Steal == find);
	}

	public List<Row> FindAll_Steal(string find)
	{
		return rowList.FindAll((Row x) => x.Steal == find);
	}

	public Row Find_kongfu1(string find)
	{
		return rowList.Find((Row x) => x.kongfu1 == find);
	}

	public List<Row> FindAll_kongfu1(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu1 == find);
	}

	public Row Find_KFLV1(string find)
	{
		return rowList.Find((Row x) => x.KFLV1 == find);
	}

	public List<Row> FindAll_KFLV1(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV1 == find);
	}

	public Row Find_kongfu2(string find)
	{
		return rowList.Find((Row x) => x.kongfu2 == find);
	}

	public List<Row> FindAll_kongfu2(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu2 == find);
	}

	public Row Find_KFLV2(string find)
	{
		return rowList.Find((Row x) => x.KFLV2 == find);
	}

	public List<Row> FindAll_KFLV2(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV2 == find);
	}

	public Row Find_kongfu3(string find)
	{
		return rowList.Find((Row x) => x.kongfu3 == find);
	}

	public List<Row> FindAll_kongfu3(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu3 == find);
	}

	public Row Find_KFLV3(string find)
	{
		return rowList.Find((Row x) => x.KFLV3 == find);
	}

	public List<Row> FindAll_KFLV3(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV3 == find);
	}

	public Row Find_kongfu4(string find)
	{
		return rowList.Find((Row x) => x.kongfu4 == find);
	}

	public List<Row> FindAll_kongfu4(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu4 == find);
	}

	public Row Find_KFLV4(string find)
	{
		return rowList.Find((Row x) => x.KFLV4 == find);
	}

	public List<Row> FindAll_KFLV4(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV4 == find);
	}

	public Row Find_kongfu5(string find)
	{
		return rowList.Find((Row x) => x.kongfu5 == find);
	}

	public List<Row> FindAll_kongfu5(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu5 == find);
	}

	public Row Find_KFLV5(string find)
	{
		return rowList.Find((Row x) => x.KFLV5 == find);
	}

	public List<Row> FindAll_KFLV5(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV5 == find);
	}

	public Row Find_Like(string find)
	{
		return rowList.Find((Row x) => x.Like == find);
	}

	public List<Row> FindAll_Like(string find)
	{
		return rowList.FindAll((Row x) => x.Like == find);
	}

	public Row Find_Hate(string find)
	{
		return rowList.Find((Row x) => x.Hate == find);
	}

	public List<Row> FindAll_Hate(string find)
	{
		return rowList.FindAll((Row x) => x.Hate == find);
	}

	public Row Find_Favorite(string find)
	{
		return rowList.Find((Row x) => x.Favorite == find);
	}

	public List<Row> FindAll_Favorite(string find)
	{
		return rowList.FindAll((Row x) => x.Favorite == find);
	}

	public Row Find_Relationship(string find)
	{
		return rowList.Find((Row x) => x.Relationship == find);
	}

	public List<Row> FindAll_Relationship(string find)
	{
		return rowList.FindAll((Row x) => x.Relationship == find);
	}

	public Row Find_AiType(string find)
	{
		return rowList.Find((Row x) => x.AiType == find);
	}

	public List<Row> FindAll_AiType(string find)
	{
		return rowList.FindAll((Row x) => x.AiType == find);
	}

	public Row Find_DropGroup(string find)
	{
		return rowList.Find((Row x) => x.DropGroup == find);
	}

	public List<Row> FindAll_DropGroup(string find)
	{
		return rowList.FindAll((Row x) => x.DropGroup == find);
	}

	public Row Find_Traits(string find)
	{
		return rowList.Find((Row x) => x.Traits == find);
	}

	public List<Row> FindAll_Traits(string find)
	{
		return rowList.FindAll((Row x) => x.Traits == find);
	}
}
