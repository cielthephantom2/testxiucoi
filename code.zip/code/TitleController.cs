using System.Globalization;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TitleController : MonoBehaviour
{
	private Transform m_QuitBtn;

	private void Start()
	{
		SharedData.Instance(init: true);
		SharedData.Instance().PlayerPackage.Clear();
		Button[] componentsInChildren = base.transform.Find("Panel/Buttons").GetComponentsInChildren<Button>();
		m_QuitBtn = base.transform.Find("Panel/Buttons/Quit");
		Button[] array = componentsInChildren;
		foreach (Button button in array)
		{
			EventTriggerListener.Get(button.gameObject).onClick = OnButtonClick;
			if (button.name == "Load")
			{
				if (!GameDataManager.Instance().HasSaveData())
				{
					button.interactable = false;
				}
				else
				{
					button.transition = Selectable.Transition.SpriteSwap;
				}
			}
			else if (button.name == "Manual" && "English".Equals(GameDataManager.Instance().configdata.language))
			{
				button.gameObject.SetActive(value: false);
			}
		}
		base.transform.Find("Panel/Version").GetComponent<Text>().text = SharedData.Instance().LocalVersion + " [" + CultureInfo.CurrentCulture?.ToString() + "]";
		SharedData.Instance().m_titleController = this;
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Buttons/New").gameObject);
		base.transform.Find("Panel/STEAM")?.gameObject.SetActive(value: false);
		base.transform.Find("Panel/STEAM (1)")?.gameObject.SetActive(value: false);
		base.transform.Find("Panel/STEAM (2)")?.gameObject.SetActive(value: false);
		base.transform.Find("Panel/STEAM (3)")?.gameObject.SetActive(value: false);
	}

	private void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			switch (go.name)
			{
			case "New":
				SharedData.Instance().playerid = "10016";
				SharedData.Instance().m_Game_Mode = 2;
				SharedData.Instance().BornID = "";
				SharedData.Instance().ASyncLoadScene("Starter1");
				break;
			case "Load":
				InputDeviceDetector.instance.PushJoyStack();
				GetComponent<CanvasGroup>().interactable = false;
				SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Load;
				SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
				break;
			case "Config":
				SceneManager.LoadScene("Config");
				break;
			case "Manual":
				SceneManager.LoadScene("Manual");
				break;
			case "Credit":
				SceneManager.LoadScene("Credit");
				break;
			case "Quit":
				Application.Quit();
				break;
			case "Achievement":
				SceneManager.LoadScene("Achievement");
				break;
			case "Atlas":
				InputDeviceDetector.instance.PushJoyStack();
				GetComponent<CanvasGroup>().interactable = false;
				SharedData.Instance().m_AtlasManagerNewController.OpenAtlas();
				break;
			}
		}
	}

	public void OnBrowseURL1()
	{
		Application.OpenURL("https://store.steampowered.com/app/1407450");
	}

	public void OnBrowseURL2()
	{
		Application.OpenURL("https://wj.qq.com/s2/14313904/7621/");
	}

	public void OnBrowseURL3()
	{
		Application.OpenURL("https://wj.qq.com/s2/15089293/224c/");
	}
}
