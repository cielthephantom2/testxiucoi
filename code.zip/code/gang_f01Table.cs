using System.Collections.Generic;
using UnityEngine;

public class gang_f01Table
{
	public class Row
	{
		public string id;

		public string openflag;

		public string closeflag;

		public string catalog;

		public string level;

		public string note;

		public string note_en;

		public string mapanchor;

		public string note_Trans => CommonFunc.ShortLangSel(note, note_en);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			Row item = new Row
			{
				id = list[i][0],
				openflag = list[i][1],
				closeflag = list[i][2],
				catalog = list[i][3],
				level = list[i][4],
				note = list[i][5],
				note_en = list[i][6],
				mapanchor = list[i][7]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		return rowList.Find((Row x) => x.id == find);
	}

	public List<Row> FindAll_id(string find)
	{
		return rowList.FindAll((Row x) => x.id == find);
	}

	public Row Find_openflag(string find)
	{
		return rowList.Find((Row x) => x.openflag == find);
	}

	public List<Row> FindAll_openflag(string find)
	{
		return rowList.FindAll((Row x) => x.openflag == find);
	}

	public Row Find_closeflag(string find)
	{
		return rowList.Find((Row x) => x.closeflag == find);
	}

	public List<Row> FindAll_closeflag(string find)
	{
		return rowList.FindAll((Row x) => x.closeflag == find);
	}

	public Row Find_catalog(string find)
	{
		return rowList.Find((Row x) => x.catalog == find);
	}

	public List<Row> FindAll_catalog(string find)
	{
		return rowList.FindAll((Row x) => x.catalog == find);
	}

	public Row Find_level(string find)
	{
		return rowList.Find((Row x) => x.level == find);
	}

	public List<Row> FindAll_level(string find)
	{
		return rowList.FindAll((Row x) => x.level == find);
	}

	public Row Find_note(string find)
	{
		return rowList.Find((Row x) => x.note == find);
	}

	public List<Row> FindAll_note(string find)
	{
		return rowList.FindAll((Row x) => x.note == find);
	}

	public Row Find_note_en(string find)
	{
		return rowList.Find((Row x) => x.note_en == find);
	}

	public List<Row> FindAll_note_en(string find)
	{
		return rowList.FindAll((Row x) => x.note_en == find);
	}

	public Row Find_mapanchor(string find)
	{
		return rowList.Find((Row x) => x.mapanchor == find);
	}

	public List<Row> FindAll_mapanchor(string find)
	{
		return rowList.FindAll((Row x) => x.mapanchor == find);
	}
}
