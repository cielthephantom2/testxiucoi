using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class AttackData
{
	public static Dictionary<Vector3Int, int> GetRange1ByAttackType(string[] _type, Vector3Int _base, BattleObject _battleObj = null, gang_b03Table.Row b03RowIn = null)
	{
		Dictionary<Vector3Int, int> dictionary = new Dictionary<Vector3Int, int>();
		string text = _type[1];
		int num = 0;
		int num2 = 0;
		gang_b03Table.Row row = null;
		if ("ITEM".Equals(_type[0]))
		{
			num2 = Mathf.FloorToInt(float.Parse(_type[3], CultureInfo.InvariantCulture));
		}
		else
		{
			num = Mathf.FloorToInt(float.Parse(_type[4], CultureInfo.InvariantCulture) / 3f);
			row = ((b03RowIn == null) ? CommonResourcesData.b03.Find_ID(_type[0]) : b03RowIn);
			if (num > int.Parse(row.Area) - 1)
			{
				num = int.Parse(row.Area) - 1;
			}
			num2 = ((!(text == "D")) ? (num + 1) : (num + 3));
		}
		if (text == "A" && _type[2] != "07" && _type[2] != "08")
		{
			int.Parse(row.Area);
			int num3 = int.Parse(row.Space);
			dictionary = new Dictionary<Vector3Int, int>();
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = false;
			num = num + num3 + 1;
			for (int i = 1; i <= num; i++)
			{
				if (i > num3)
				{
					if (!flag)
					{
						dictionary.Add(_base + i * Vector3Int.up, 2);
					}
					if (!flag && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base + i * Vector3Int.up, _battleObj))
					{
						flag = true;
					}
					if (!flag3)
					{
						dictionary.Add(_base - i * Vector3Int.right, 4);
					}
					if (!flag3 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base - i * Vector3Int.right, _battleObj))
					{
						flag3 = true;
					}
					if (!flag4)
					{
						dictionary.Add(_base + i * Vector3Int.right, 6);
					}
					if (!flag4 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base + i * Vector3Int.right, _battleObj))
					{
						flag4 = true;
					}
					if (!flag2)
					{
						dictionary.Add(_base - i * Vector3Int.up, 8);
					}
					if (!flag2 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base - i * Vector3Int.up, _battleObj))
					{
						flag2 = true;
					}
				}
				else
				{
					if (!flag && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base + i * Vector3Int.up, _battleObj))
					{
						flag = true;
					}
					if (!flag3 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base - i * Vector3Int.right, _battleObj))
					{
						flag3 = true;
					}
					if (!flag4 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base + i * Vector3Int.right, _battleObj))
					{
						flag4 = true;
					}
					if (!flag2 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(_base - i * Vector3Int.up, _battleObj))
					{
						flag2 = true;
					}
				}
			}
		}
		else if (text == "A" && _type[2] == "07")
		{
			int.Parse(row.Area);
			int num4 = int.Parse(row.Space);
			dictionary = new Dictionary<Vector3Int, int>();
			bool flag5 = false;
			bool flag6 = false;
			bool flag7 = false;
			bool flag8 = false;
			if (num < 2)
			{
				num = 2;
			}
			num += num4;
			for (int j = 1; j <= num; j++)
			{
				if (j > num4)
				{
					if (!flag5 && SharedData.Instance().m_BattleController != null && !SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + j * Vector3Int.up, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base + j * Vector3Int.up))
					{
						dictionary.Add(_base + j * Vector3Int.up, 2);
					}
					if (!flag7 && SharedData.Instance().m_BattleController != null && !SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base - j * Vector3Int.right, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base - j * Vector3Int.right))
					{
						dictionary.Add(_base - j * Vector3Int.right, 4);
					}
					if (!flag8 && SharedData.Instance().m_BattleController != null && !SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + j * Vector3Int.right, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base + j * Vector3Int.right))
					{
						dictionary.Add(_base + j * Vector3Int.right, 6);
					}
					if (!flag6 && SharedData.Instance().m_BattleController != null && !SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base - j * Vector3Int.up, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base - j * Vector3Int.up))
					{
						dictionary.Add(_base - j * Vector3Int.up, 8);
					}
				}
			}
		}
		else if (text == "A" && _type[2] == "08")
		{
			int.Parse(row.Area);
			int num5 = int.Parse(row.Space);
			dictionary = new Dictionary<Vector3Int, int>();
			bool flag9 = false;
			bool flag10 = false;
			bool flag11 = false;
			bool flag12 = false;
			num = num + num5 + 1;
			for (int k = 1; k <= num; k++)
			{
				if (k > num5)
				{
					if (!flag9 && !SharedData.Instance().m_BattleController.CheckIsTeammateOnGrid(_base + k * Vector3Int.up, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base + k * Vector3Int.up))
					{
						dictionary.Add(_base + k * Vector3Int.up, 2);
					}
					if (!flag9 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + k * Vector3Int.up, _battleObj))
					{
						flag9 = true;
					}
					if (!flag11 && !SharedData.Instance().m_BattleController.CheckIsTeammateOnGrid(_base - k * Vector3Int.right, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base - k * Vector3Int.right))
					{
						dictionary.Add(_base - k * Vector3Int.right, 4);
					}
					if (!flag11 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base - k * Vector3Int.right, _battleObj))
					{
						flag11 = true;
					}
					if (!flag12 && !SharedData.Instance().m_BattleController.CheckIsTeammateOnGrid(_base + k * Vector3Int.right, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base + k * Vector3Int.right))
					{
						dictionary.Add(_base + k * Vector3Int.right, 6);
					}
					if (!flag12 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + k * Vector3Int.right, _battleObj))
					{
						flag12 = true;
					}
					if (!flag10 && !SharedData.Instance().m_BattleController.CheckIsTeammateOnGrid(_base - k * Vector3Int.up, _battleObj) && SharedData.Instance().m_BattleController.obstacle.Contains(_base - k * Vector3Int.up))
					{
						dictionary.Add(_base - k * Vector3Int.up, 8);
					}
					if (!flag10 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base - k * Vector3Int.up, _battleObj))
					{
						flag10 = true;
					}
				}
				else
				{
					if (!flag9 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + k * Vector3Int.up, _battleObj))
					{
						flag9 = true;
					}
					if (!flag11 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base - k * Vector3Int.right, _battleObj))
					{
						flag11 = true;
					}
					if (!flag12 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + k * Vector3Int.right, _battleObj))
					{
						flag12 = true;
					}
					if (!flag10 && SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base - k * Vector3Int.up, _battleObj))
					{
						flag10 = true;
					}
				}
			}
		}
		else if (text == "C" && _type[2] == "05")
		{
			int num6 = 0;
			if (row != null)
			{
				num6 = int.Parse(row.Space);
			}
			dictionary = new Dictionary<Vector3Int, int>();
			num2 += num6;
			for (int l = -num2; l <= num2; l++)
			{
				int num7 = num2 - Mathf.Abs(l);
				for (int m = -num7; m <= num7; m++)
				{
					if (Mathf.Abs(l) + Mathf.Abs(m) <= num6)
					{
						continue;
					}
					int value = 0;
					if (m > 0)
					{
						if (Mathf.Abs(l) > Mathf.Abs(m))
						{
							if (l > 0)
							{
								value = 2;
							}
							else if (l < 0)
							{
								value = 8;
							}
						}
						else
						{
							value = 6;
						}
					}
					else if (m < 0)
					{
						if (Mathf.Abs(l) > Mathf.Abs(m))
						{
							if (l > 0)
							{
								value = 2;
							}
							else if (l < 0)
							{
								value = 8;
							}
						}
						else
						{
							value = 4;
						}
					}
					else if (l > 0)
					{
						value = 2;
					}
					else if (l < 0)
					{
						value = 8;
					}
					if (SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.CheckIsTeammateOnGrid(_base + Vector3Int.up * l + Vector3Int.right * m, _battleObj))
					{
						dictionary.Add(_base + Vector3Int.up * l + Vector3Int.right * m, value);
					}
				}
			}
		}
		else if (text == "C" && _type[2] == "06")
		{
			int num8 = 0;
			if (row != null)
			{
				num8 = int.Parse(row.Space);
			}
			dictionary = new Dictionary<Vector3Int, int>();
			num2 += num8;
			for (int n = -num2; n <= num2; n++)
			{
				int num9 = num2 - Mathf.Abs(n);
				for (int num10 = -num9; num10 <= num9; num10++)
				{
					if (Mathf.Abs(n) + Mathf.Abs(num10) <= num8)
					{
						continue;
					}
					int value2 = 0;
					if (num10 > 0)
					{
						if (Mathf.Abs(n) > Mathf.Abs(num10))
						{
							if (n > 0)
							{
								value2 = 2;
							}
							else if (n < 0)
							{
								value2 = 8;
							}
						}
						else
						{
							value2 = 6;
						}
					}
					else if (num10 < 0)
					{
						if (Mathf.Abs(n) > Mathf.Abs(num10))
						{
							if (n > 0)
							{
								value2 = 2;
							}
							else if (n < 0)
							{
								value2 = 8;
							}
						}
						else
						{
							value2 = 4;
						}
					}
					else if (n > 0)
					{
						value2 = 2;
					}
					else if (n < 0)
					{
						value2 = 8;
					}
					if ((!(SharedData.Instance().m_BattleController != null) || !SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(_base + Vector3Int.up * n + Vector3Int.right * num10, _battleObj)) && SharedData.Instance().m_BattleController.obstacle.Contains(_base + Vector3Int.up * n + Vector3Int.right * num10))
					{
						dictionary.Add(_base + Vector3Int.up * n + Vector3Int.right * num10, value2);
					}
				}
			}
		}
		else
		{
			switch (text)
			{
			case "C":
			{
				int num14 = 0;
				if (row != null)
				{
					num14 = int.Parse(row.Space);
				}
				dictionary = new Dictionary<Vector3Int, int>();
				num2 += num14;
				for (int num15 = -num2; num15 <= num2; num15++)
				{
					int num16 = num2 - Mathf.Abs(num15);
					for (int num17 = -num16; num17 <= num16; num17++)
					{
						if (Mathf.Abs(num15) + Mathf.Abs(num17) <= num14)
						{
							continue;
						}
						int value4 = 0;
						if (num17 > 0)
						{
							if (Mathf.Abs(num15) > Mathf.Abs(num17))
							{
								if (num15 > 0)
								{
									value4 = 2;
								}
								else if (num15 < 0)
								{
									value4 = 8;
								}
							}
							else
							{
								value4 = 6;
							}
						}
						else if (num17 < 0)
						{
							if (Mathf.Abs(num15) > Mathf.Abs(num17))
							{
								if (num15 > 0)
								{
									value4 = 2;
								}
								else if (num15 < 0)
								{
									value4 = 8;
								}
							}
							else
							{
								value4 = 4;
							}
						}
						else if (num15 > 0)
						{
							value4 = 2;
						}
						else if (num15 < 0)
						{
							value4 = 8;
						}
						dictionary.Add(_base + Vector3Int.up * num15 + Vector3Int.right * num17, value4);
					}
				}
				dictionary.Add(_base, 0);
				break;
			}
			case "D":
			{
				dictionary = new Dictionary<Vector3Int, int>();
				for (int num11 = -num2; num11 <= num2; num11++)
				{
					int num12 = num2 - Mathf.Abs(num11);
					for (int num13 = -num12; num13 <= num12; num13++)
					{
						if (Mathf.Abs(num11) + Mathf.Abs(num13) <= 2)
						{
							continue;
						}
						int value3 = 0;
						if (num13 > 0)
						{
							if (Mathf.Abs(num11) > Mathf.Abs(num13))
							{
								if (num11 > 0)
								{
									value3 = 2;
								}
								else if (num11 < 0)
								{
									value3 = 8;
								}
							}
							else
							{
								value3 = 6;
							}
						}
						else if (num13 < 0)
						{
							if (Mathf.Abs(num11) > Mathf.Abs(num13))
							{
								if (num11 > 0)
								{
									value3 = 2;
								}
								else if (num11 < 0)
								{
									value3 = 8;
								}
							}
							else
							{
								value3 = 4;
							}
						}
						else if (num11 > 0)
						{
							value3 = 2;
						}
						else if (num11 < 0)
						{
							value3 = 8;
						}
						dictionary.Add(_base + Vector3Int.up * num11 + Vector3Int.right * num13, value3);
					}
				}
				break;
			}
			case "B":
				dictionary.Add(_base, 2);
				break;
			}
		}
		return dictionary;
	}

	public static int GetSelectRange(string[] _type, gang_b03Table.Row b03RowIn = null)
	{
		gang_b03Table.Row row = null;
		row = ((b03RowIn == null) ? CommonResourcesData.b03.Find_ID(_type[0]) : b03RowIn);
		int result = 0;
		int num = Mathf.FloorToInt(float.Parse(_type[4], CultureInfo.InvariantCulture) / 3f);
		int num2 = 0;
		if (num > int.Parse(row.Area) - 1)
		{
			num = int.Parse(row.Area) - 1;
		}
		num2 = ((!(_type[1] == "D")) ? (num + 1) : (num + 3));
		if (_type[1] == "A" && _type[2] != "07")
		{
			result = num + 1;
		}
		else if (_type[1] == "A" && _type[2] == "07")
		{
			if (num < 2)
			{
				num = 2;
			}
			result = num;
		}
		else if (_type[1] == "C" && _type[2] == "05")
		{
			result = num2;
		}
		else if (_type[1] == "C" && _type[2] == "06")
		{
			result = num2;
		}
		else if (_type[1] == "C")
		{
			result = num2;
		}
		else if (_type[1] == "D")
		{
			result = num2;
		}
		else if (_type[1] == "B")
		{
			result = Mathf.Clamp(GetRange2ByAttackType(_type, default(Vector3Int), 2, default(Vector3Int), row).Count / 4, 1, 10);
		}
		return result;
	}

	public static Dictionary<Vector3Int, int> GetRange2ByAttackType(string[] _type, Vector3Int _base = default(Vector3Int), int _direction = 2, Vector3Int _standPos = default(Vector3Int), gang_b03Table.Row b03RowIn = null)
	{
		Dictionary<Vector3Int, int> dictionary = new Dictionary<Vector3Int, int>();
		string text = _type[1] + _type[2];
		int num = 0;
		if ("ITEM".Equals(_type[0]))
		{
			num = Mathf.FloorToInt(float.Parse(_type[4], CultureInfo.InvariantCulture));
		}
		else
		{
			num = Mathf.FloorToInt(float.Parse(_type[4], CultureInfo.InvariantCulture) / 3f);
			gang_b03Table.Row row = null;
			row = ((b03RowIn == null) ? CommonResourcesData.b03.Find_ID(_type[0]) : b03RowIn);
			if (num > int.Parse(row.Range) - 1)
			{
				num = int.Parse(row.Range) - 1;
			}
		}
		switch (text)
		{
		case "A01":
			switch (_direction)
			{
			case 2:
			{
				for (int num62 = 0; num62 <= num; num62++)
				{
					dictionary.Add(_base + Vector3Int.up * num62, _direction);
				}
				break;
			}
			case 4:
			{
				for (int num60 = 0; num60 <= num; num60++)
				{
					dictionary.Add(_base - Vector3Int.right * num60, _direction);
				}
				break;
			}
			case 6:
			{
				for (int num61 = 0; num61 <= num; num61++)
				{
					dictionary.Add(_base + Vector3Int.right * num61, _direction);
				}
				break;
			}
			case 8:
			{
				for (int num59 = 0; num59 <= num; num59++)
				{
					dictionary.Add(_base - Vector3Int.up * num59, _direction);
				}
				break;
			}
			}
			break;
		case "A02":
			switch (_direction)
			{
			case 2:
			{
				dictionary.Add(_base, _direction);
				for (int num69 = 1; num69 <= num; num69++)
				{
					dictionary.Add(_base + Vector3Int.right * num69, _direction);
					dictionary.Add(_base - Vector3Int.right * num69, _direction);
				}
				break;
			}
			case 4:
			{
				dictionary.Add(_base, _direction);
				for (int num67 = 1; num67 <= num; num67++)
				{
					dictionary.Add(_base + Vector3Int.up * num67, _direction);
					dictionary.Add(_base - Vector3Int.up * num67, _direction);
				}
				break;
			}
			case 6:
			{
				dictionary.Add(_base, _direction);
				for (int num68 = 1; num68 <= num; num68++)
				{
					dictionary.Add(_base + Vector3Int.up * num68, _direction);
					dictionary.Add(_base - Vector3Int.up * num68, _direction);
				}
				break;
			}
			case 8:
			{
				dictionary.Add(_base, _direction);
				for (int num66 = 1; num66 <= num; num66++)
				{
					dictionary.Add(_base + Vector3Int.right * num66, _direction);
					dictionary.Add(_base - Vector3Int.right * num66, _direction);
				}
				break;
			}
			}
			break;
		case "A03":
			switch (_direction)
			{
			case 2:
			{
				for (int num28 = 0; num28 <= num; num28++)
				{
					dictionary.Add(_base + Vector3Int.up * num28, _direction);
					for (int num29 = 1; num29 <= num28; num29++)
					{
						dictionary.Add(_base + Vector3Int.up * num28 + Vector3Int.right * num29, _direction);
						dictionary.Add(_base + Vector3Int.up * num28 - Vector3Int.right * num29, _direction);
					}
				}
				break;
			}
			case 4:
			{
				for (int num24 = 0; num24 <= num; num24++)
				{
					dictionary.Add(_base - Vector3Int.right * num24, _direction);
					for (int num25 = 1; num25 <= num24; num25++)
					{
						dictionary.Add(_base - Vector3Int.right * num24 + Vector3Int.up * num25, _direction);
						dictionary.Add(_base - Vector3Int.right * num24 - Vector3Int.up * num25, _direction);
					}
				}
				break;
			}
			case 6:
			{
				for (int num26 = 0; num26 <= num; num26++)
				{
					dictionary.Add(_base + Vector3Int.right * num26, _direction);
					for (int num27 = 1; num27 <= num26; num27++)
					{
						dictionary.Add(_base + Vector3Int.right * num26 + Vector3Int.up * num27, _direction);
						dictionary.Add(_base + Vector3Int.right * num26 - Vector3Int.up * num27, _direction);
					}
				}
				break;
			}
			case 8:
			{
				for (int num22 = 0; num22 <= num; num22++)
				{
					dictionary.Add(_base - Vector3Int.up * num22, _direction);
					for (int num23 = 1; num23 <= num22; num23++)
					{
						dictionary.Add(_base - Vector3Int.up * num22 + Vector3Int.right * num23, _direction);
						dictionary.Add(_base - Vector3Int.up * num22 - Vector3Int.right * num23, _direction);
					}
				}
				break;
			}
			}
			break;
		case "A04":
			switch (_direction)
			{
			case 2:
			{
				for (int num39 = 0; num39 <= num; num39++)
				{
					dictionary.Add(_base + Vector3Int.up * num39, _direction);
					for (int num40 = 1; num40 <= num - num39; num40++)
					{
						dictionary.Add(_base + Vector3Int.up * num39 + Vector3Int.right * num40, _direction);
						dictionary.Add(_base + Vector3Int.up * num39 - Vector3Int.right * num40, _direction);
					}
				}
				break;
			}
			case 4:
			{
				for (int num35 = 0; num35 <= num; num35++)
				{
					dictionary.Add(_base - Vector3Int.right * num35, _direction);
					for (int num36 = 1; num36 <= num - num35; num36++)
					{
						dictionary.Add(_base - Vector3Int.right * num35 + Vector3Int.up * num36, _direction);
						dictionary.Add(_base - Vector3Int.right * num35 - Vector3Int.up * num36, _direction);
					}
				}
				break;
			}
			case 6:
			{
				for (int num37 = 0; num37 <= num; num37++)
				{
					dictionary.Add(_base + Vector3Int.right * num37, _direction);
					for (int num38 = 1; num38 <= num - num37; num38++)
					{
						dictionary.Add(_base + Vector3Int.right * num37 + Vector3Int.up * num38, _direction);
						dictionary.Add(_base + Vector3Int.right * num37 - Vector3Int.up * num38, _direction);
					}
				}
				break;
			}
			case 8:
			{
				for (int num33 = 0; num33 <= num; num33++)
				{
					dictionary.Add(_base - Vector3Int.up * num33, _direction);
					for (int num34 = 1; num34 <= num - num33; num34++)
					{
						dictionary.Add(_base - Vector3Int.up * num33 + Vector3Int.right * num34, _direction);
						dictionary.Add(_base - Vector3Int.up * num33 - Vector3Int.right * num34, _direction);
					}
				}
				break;
			}
			}
			break;
		case "A05":
		{
			if (num < 2)
			{
				num = 2;
			}
			int num45 = -1;
			switch (_direction)
			{
			case 2:
			{
				dictionary.TryAdd(_base, _direction);
				for (int num52 = 1; num52 <= num; num52++)
				{
					int num53 = num52 % 2;
					if (num53 != 0)
					{
						num53 *= num45;
						num45 = -num45;
					}
					dictionary.TryAdd(_base + Vector3Int.up * num52 + Vector3Int.right * num53, _direction);
				}
				break;
			}
			case 4:
			{
				dictionary.TryAdd(_base, _direction);
				for (int num48 = 1; num48 <= num; num48++)
				{
					int num49 = num48 % 2;
					if (num49 != 0)
					{
						num49 *= num45;
						num45 = -num45;
					}
					dictionary.TryAdd(_base - Vector3Int.right * num48 + Vector3Int.up * num49, _direction);
				}
				break;
			}
			case 6:
			{
				dictionary.TryAdd(_base, _direction);
				for (int num50 = 1; num50 <= num; num50++)
				{
					int num51 = num50 % 2;
					if (num51 != 0)
					{
						num51 *= num45;
						num45 = -num45;
					}
					dictionary.TryAdd(_base + Vector3Int.right * num50 + Vector3Int.up * num51, _direction);
				}
				break;
			}
			case 8:
			{
				dictionary.TryAdd(_base, _direction);
				for (int num46 = 1; num46 <= num; num46++)
				{
					int num47 = num46 % 2;
					if (num47 != 0)
					{
						num47 *= num45;
						num45 = -num45;
					}
					dictionary.TryAdd(_base - Vector3Int.up * num46 + Vector3Int.right * num47, _direction);
				}
				break;
			}
			}
			break;
		}
		case "A06":
			if (num < 1)
			{
				num = 1;
			}
			switch (_direction)
			{
			case 2:
			{
				for (int num18 = 0; num18 <= num; num18++)
				{
					dictionary.Add(_base + Vector3Int.up * num18 + Vector3Int.right, _direction);
					dictionary.Add(_base + Vector3Int.up * num18 - Vector3Int.right, _direction);
				}
				break;
			}
			case 4:
			{
				for (int num16 = 0; num16 <= num; num16++)
				{
					dictionary.Add(_base - Vector3Int.right * num16 + Vector3Int.up, _direction);
					dictionary.Add(_base - Vector3Int.right * num16 - Vector3Int.up, _direction);
				}
				break;
			}
			case 6:
			{
				for (int num17 = 0; num17 <= num; num17++)
				{
					dictionary.Add(_base + Vector3Int.right * num17 + Vector3Int.up, _direction);
					dictionary.Add(_base + Vector3Int.right * num17 - Vector3Int.up, _direction);
				}
				break;
			}
			case 8:
			{
				for (int num15 = 0; num15 <= num; num15++)
				{
					dictionary.Add(_base - Vector3Int.up * num15 + Vector3Int.right, _direction);
					dictionary.Add(_base - Vector3Int.up * num15 - Vector3Int.right, _direction);
				}
				break;
			}
			}
			break;
		case "A07":
			num = Mathf.Abs((_standPos - _base).x) + Mathf.Abs((_standPos - _base).y);
			switch (_direction)
			{
			case 2:
			{
				for (int num11 = 1; num11 <= num; num11++)
				{
					dictionary.Add(_standPos + Vector3Int.up * num11, _direction);
				}
				break;
			}
			case 4:
			{
				for (int num9 = 1; num9 <= num; num9++)
				{
					dictionary.Add(_standPos - Vector3Int.right * num9, _direction);
				}
				break;
			}
			case 6:
			{
				for (int num10 = 1; num10 <= num; num10++)
				{
					dictionary.Add(_standPos + Vector3Int.right * num10, _direction);
				}
				break;
			}
			case 8:
			{
				for (int num8 = 1; num8 <= num; num8++)
				{
					dictionary.Add(_standPos - Vector3Int.up * num8, _direction);
				}
				break;
			}
			}
			break;
		case "A08":
			switch (_direction)
			{
			case 2:
			{
				for (int n = 0; n <= num; n++)
				{
					dictionary.Add(_base + Vector3Int.up * n, _direction);
				}
				break;
			}
			case 4:
			{
				for (int l = 0; l <= num; l++)
				{
					dictionary.Add(_base - Vector3Int.right * l, _direction);
				}
				break;
			}
			case 6:
			{
				for (int m = 0; m <= num; m++)
				{
					dictionary.Add(_base + Vector3Int.right * m, _direction);
				}
				break;
			}
			case 8:
			{
				for (int k = 0; k <= num; k++)
				{
					dictionary.Add(_base - Vector3Int.up * k, _direction);
				}
				break;
			}
			}
			break;
		case "B01":
		{
			int num63 = num + 1;
			for (int num64 = -num63; num64 <= num63; num64++)
			{
				for (int num65 = -num63; num65 <= num63; num65++)
				{
					if ((num64 == 0 || num65 == 0) && (num64 != 0 || num65 != 0))
					{
						int value5 = 0;
						if (num65 > 0)
						{
							value5 = 6;
						}
						else if (num65 < 0)
						{
							value5 = 4;
						}
						else if (num64 > 0)
						{
							value5 = 2;
						}
						else if (num64 < 0)
						{
							value5 = 8;
						}
						dictionary.Add(_base + Vector3Int.up * num64 + Vector3Int.right * num65, value5);
					}
				}
			}
			break;
		}
		case "B02":
		{
			int num54 = num + 1;
			for (int num55 = -num54; num55 <= num54; num55++)
			{
				for (int num56 = -num54; num56 <= num54; num56++)
				{
					int num57 = Mathf.Abs(num55);
					int num58 = Mathf.Abs(num56);
					if (num57 == num58 && (num55 != 0 || num56 != 0))
					{
						int value4 = 0;
						if (num56 > 0)
						{
							value4 = 6;
						}
						else if (num56 < 0)
						{
							value4 = 4;
						}
						else if (num55 > 0)
						{
							value4 = 2;
						}
						else if (num55 < 0)
						{
							value4 = 8;
						}
						dictionary.Add(_base + Vector3Int.up * num55 + Vector3Int.right * num56, value4);
					}
				}
			}
			break;
		}
		case "B03":
		{
			int num41 = num + 1;
			for (int num42 = -num41; num42 <= num41; num42++)
			{
				int num43 = num41 - Mathf.Abs(num42);
				for (int num44 = -num43; num44 <= num43; num44++)
				{
					if (num42 != 0 || num44 != 0)
					{
						int value3 = 0;
						if (num44 > 0)
						{
							value3 = 6;
						}
						else if (num44 < 0)
						{
							value3 = 4;
						}
						else if (num42 > 0)
						{
							value3 = 2;
						}
						else if (num42 < 0)
						{
							value3 = 8;
						}
						dictionary.Add(_base + Vector3Int.up * num42 + Vector3Int.right * num44, value3);
					}
				}
			}
			break;
		}
		case "B04":
			dictionary.Add(_base, _direction);
			break;
		case "B05":
		{
			int num30 = num + 1;
			for (int num31 = -num30; num31 <= num30; num31++)
			{
				for (int num32 = -num30; num32 <= num30; num32++)
				{
					if (num31 != 0 && num32 != 0 && Mathf.Abs(num31) + Mathf.Abs(num32) <= num30 + 1)
					{
						int value2 = 0;
						if (num32 > 0)
						{
							value2 = 6;
						}
						else if (num32 < 0)
						{
							value2 = 4;
						}
						else if (num31 > 0)
						{
							value2 = 2;
						}
						else if (num31 < 0)
						{
							value2 = 8;
						}
						dictionary.TryAdd(_base + Vector3Int.up * num31 + Vector3Int.right * num32, value2);
					}
				}
			}
			break;
		}
		case "C01":
		{
			for (int num19 = -num; num19 <= num; num19++)
			{
				int num20 = num - Mathf.Abs(num19);
				for (int num21 = -num20; num21 <= num20; num21++)
				{
					dictionary.Add(_base + Vector3Int.up * num19 + Vector3Int.right * num21, _direction);
				}
			}
			break;
		}
		case "C02":
		{
			for (int num12 = -num; num12 <= num; num12++)
			{
				int num13 = num - Mathf.Abs(num12);
				for (int num14 = -num13; num14 <= num13; num14++)
				{
					dictionary.Add(_base + Vector3Int.up * num12 + Vector3Int.right * num14, _direction);
				}
			}
			break;
		}
		case "C03":
		{
			dictionary.TryAdd(_base, 0);
			int num3 = num;
			for (int num4 = -num3; num4 <= num3; num4++)
			{
				for (int num5 = -num3; num5 <= num3; num5++)
				{
					int num6 = Mathf.Abs(num4);
					int num7 = Mathf.Abs(num5);
					if (num6 == num7)
					{
						int value = 0;
						if (num5 > 0)
						{
							value = 6;
						}
						else if (num5 < 0)
						{
							value = 4;
						}
						else if (num4 > 0)
						{
							value = 2;
						}
						else if (num4 < 0)
						{
							value = 8;
						}
						dictionary.TryAdd(_base + Vector3Int.up * num4 + Vector3Int.right * num5, value);
					}
				}
			}
			break;
		}
		case "C04":
			dictionary.TryAdd(_base, 0);
			break;
		case "C05":
			dictionary.Add(_base, _direction);
			break;
		case "C06":
			dictionary.Add(_base, _direction);
			break;
		case "D01":
		{
			for (int i = -num; i <= num; i++)
			{
				int num2 = num - Mathf.Abs(i);
				for (int j = -num2; j <= num2; j++)
				{
					dictionary.Add(_base + Vector3Int.up * i + Vector3Int.right * j, _direction);
				}
			}
			break;
		}
		}
		return dictionary;
	}
}
