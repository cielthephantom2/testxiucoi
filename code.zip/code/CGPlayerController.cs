using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public class CGPlayerController : MonoBehaviour
{
	private SkeletonAnimation m_animation;

	private float jumpTime = 1.5f;

	private float timer;

	private bool isExiting;

	private Transform m_joyicon_bg;

	private Transform m_joyicon;

	private void Start()
	{
		m_joyicon_bg = base.transform.Find("Panel/JoyIcon");
		m_joyicon = base.transform.Find("Panel/JoyIcon/JoyIcon");
		GameObject gameObject = base.transform.Find("Panel/" + SharedData.Instance().PlayCGName + CommonFunc.ShortLangSel("", "_EN", "_TW")).gameObject;
		if (gameObject != null)
		{
			if (SharedData.Instance().PlayCGName.Contains("SPINE-END"))
			{
				m_joyicon_bg.gameObject.SetActive(value: false);
			}
			gameObject.SetActive(value: true);
			m_animation = gameObject.GetComponent<SkeletonAnimation>();
			m_animation.AnimationState.Event += State_Event;
			m_animation.AnimationState.Complete += State_Complete;
			if (SharedData.Instance().PlayCGBGM != "")
			{
				AudioSource component = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<AudioSource>();
				component.clip = CommonResourcesData.LoadBgm(SharedData.Instance().PlayCGBGM);
				component.Play();
			}
		}
		else
		{
			ExitScene();
		}
	}

	private void Update()
	{
		if (isExiting)
		{
			return;
		}
		if (m_animation.AnimationState.TimeScale == 0f)
		{
			if (InputSystemCustom.Instance().UI.JumpAnimation.IsPressed() || Input.GetMouseButton(1) || Input.GetMouseButton(0))
			{
				m_animation.AnimationState.TimeScale = 1f;
			}
		}
		else
		{
			if (!m_joyicon_bg.gameObject.activeInHierarchy)
			{
				return;
			}
			m_joyicon.GetComponent<Image>().fillAmount = timer / jumpTime;
			if (InputSystemCustom.Instance().UI.JumpAnimation.IsPressed() || Input.GetMouseButton(1) || Input.GetMouseButton(0))
			{
				timer += Time.deltaTime;
				if (timer > jumpTime && m_animation != null)
				{
					ExitScene();
				}
			}
			else
			{
				timer = Mathf.Clamp(timer - Time.deltaTime, 0f, jumpTime);
			}
		}
	}

	private void State_Event(TrackEntry trackEntry, Spine.Event e)
	{
		if ("click".Equals(e.Data.Name))
		{
			m_animation.AnimationState.TimeScale = 0f;
		}
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		MonoBehaviour.print("=======>> Play CG Complete.");
		ExitScene();
	}

	private void ExitScene()
	{
		isExiting = true;
		if (SharedData.Instance().AfterCGPlayComplete.Length > 0)
		{
			SharedData.Instance().FlagList[SharedData.Instance().AfterCGPlayComplete] = 1;
		}
		if (SharedData.Instance().SceneBefore.Length > 0)
		{
			SharedData.Instance().BackFromOtherScene = true;
			SharedData.Instance().ASyncLoadScene(SharedData.Instance().SceneBefore);
			return;
		}
		Debug.Log("CGPlayerController::ExitScene(): Set Flag[STAGE_01_0_1] = 1.");
		SharedData.Instance().FlagList["STAGE_01_0_1"] = 1;
		SharedData.Instance().SpawnPoint = "Spawn_01";
		SharedData.Instance().ASyncLoadScene("Field_YangTaiFuMiao");
	}
}
