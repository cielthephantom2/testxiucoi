using System.Collections.Generic;
using UnityEngine;

public class gang_b06ChainTable
{
	public class Row
	{
		public string id;

		public string name;

		public string one;

		public string two;

		public string three;

		public string four;

		public string five;

		public string six;

		public string seven;

		public string eight;

		public string nine;

		public Dictionary<string, string> nineGridDict = new Dictionary<string, string>();
	}

	private List<Row> rowList = new List<Row>();

	private Dictionary<string, Row> rowDict = new Dictionary<string, Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				id = list[i][num++],
				name = list[i][num++],
				one = list[i][num++],
				two = list[i][num++],
				three = list[i][num++],
				four = list[i][num++],
				five = list[i][num++],
				six = list[i][num++],
				seven = list[i][num++],
				eight = list[i][num++],
				nine = list[i][num++]
			};
			row.nineGridDict.Add("1", row.one);
			row.nineGridDict.Add("2", row.two);
			row.nineGridDict.Add("3", row.three);
			row.nineGridDict.Add("4", row.four);
			row.nineGridDict.Add("5", row.five);
			row.nineGridDict.Add("6", row.six);
			row.nineGridDict.Add("7", row.seven);
			row.nineGridDict.Add("8", row.eight);
			row.nineGridDict.Add("9", row.nine);
			rowList.Add(row);
			rowDict.Add(row.id, row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		if (rowDict.ContainsKey(find))
		{
			return rowDict[find];
		}
		return null;
	}
}
