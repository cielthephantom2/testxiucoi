using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class StatusSub5 : MonoBehaviour
{
	public StatusSub5Type statusSub5Type;

	private Transform DeleteWugongPanel;

	private Transform currentDeleteWugongBtn;

	private CharaData curdata;

	private GameObject InfoPanel;

	private AudioSource m_AudioSource;

	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	public GameObject learnBtn;

	private ScrollRect WuGongScrollRect;

	private GameObject WuGongBtnPrefab;

	private GameObject SelectedBtn;

	private List<GameObject> m_WuGongSelectList = new List<GameObject>();

	private List<GameObject> WuGongBtnList = new List<GameObject>();

	private void Awake()
	{
		NormalSprite = Resources.Load("images/01-border/boder-20231228-texing-00", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-20231228-texing-01", typeof(Sprite)) as Sprite;
		WuGongBtnPrefab = (GameObject)Resources.Load("Prefabs/NewUI/WuGongBtn");
		m_AudioSource = base.gameObject.GetComponent<AudioSource>();
		InfoPanel = base.transform.Find("Panel/Info").gameObject;
		learnBtn = base.transform.Find("Panel/WuGong/Study/Learn/Learn").gameObject;
		WuGongScrollRect = base.transform.Find("Panel/WuGong/ScrollView").GetComponent<ScrollRect>();
		DeleteWugongPanel = base.transform.Find("Panel/DeleteWugongPanel");
		Button[] componentsInChildren = GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		WuGongScrollRect.onValueChanged.AddListener(OnScrollValueChanged);
		SharedData.Instance().m_StatusSub5 = this;
	}

	private void OnScrollValueChanged(Vector2 position)
	{
		currentDeleteWugongBtn = null;
	}

	private void OnEnable()
	{
		if (!(SharedData.Instance().CurrentChara == ""))
		{
			curdata = SharedData.Instance().CurrentCharaData;
			if (curdata != null)
			{
				RefreshUI();
			}
		}
	}

	private void OnDisable()
	{
		if (statusSub5Type.Equals(StatusSub5Type.Deletewugong))
		{
			SharedData.Instance().LoadedSceneStack.Clear();
		}
		statusSub5Type = StatusSub5Type.Showwugong;
		currentDeleteWugongBtn = null;
	}

	private void Update()
	{
		if (EventSystem.current.currentSelectedGameObject != null && statusSub5Type.Equals(StatusSub5Type.Deletewugong))
		{
			HoverWGController componentInParent = EventSystem.current.currentSelectedGameObject.GetComponentInParent<HoverWGController>();
			if (componentInParent != null && currentDeleteWugongBtn != componentInParent.transform.Find("Delete"))
			{
				currentDeleteWugongBtn = componentInParent.transform.Find("Delete");
			}
		}
		if (InputSystemCustom.Instance().UI.QuickLearnWugong.WasReleasedThisFrame() && statusSub5Type.Equals(StatusSub5Type.Showwugong))
		{
			StartCoroutine(DelayGamePadClick(base.transform.Find("Panel/WuGong/Study/Learn/Learn").gameObject));
		}
		else if (InputSystemCustom.Instance().UI.DeleteWugong.WasReleasedThisFrame() && statusSub5Type.Equals(StatusSub5Type.Deletewugong) && (object)currentDeleteWugongBtn != null)
		{
			StartCoroutine(DelayGamePadClick(currentDeleteWugongBtn.gameObject));
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && statusSub5Type.Equals(StatusSub5Type.Deletewugong) && !CommonFunc.IsHoverOpen() && !InfoPanel.activeInHierarchy)
		{
			StartCoroutine(DelayGamePadClick(DeleteWugongPanel.Find("TopBanner/Return").gameObject));
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && InfoPanel.activeInHierarchy)
		{
			StartCoroutine(DelayGamePadClick(InfoPanel.transform.Find("No").gameObject));
		}
		if (InfoPanel.activeInHierarchy && statusSub5Type.Equals(StatusSub5Type.Showwugong) && (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame()))
		{
			InfoPanel.SetActive(value: false);
		}
	}

	private IEnumerator DelayGamePadClick(GameObject button)
	{
		yield return null;
		EventSystem.current.SetSelectedGameObject(button);
		ExecuteEvents.Execute(button, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
	}

	public void RefreshUI()
	{
		DeleteWugongPanel.gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Deletewugong));
		learnBtn.gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Showwugong));
		if (statusSub5Type.Equals(StatusSub5Type.Deletewugong))
		{
			Transform transform = DeleteWugongPanel.Find("Character");
			CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
			transform.Find("Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(currentCharaData);
			transform.Find("Tachie").gameObject.SetActive(value: false);
			if (currentCharaData.m_BattleIcon != "")
			{
				Sprite tachieFull = CommonResourcesData.GetTachieFull(currentCharaData.m_BattleIcon);
				if (tachieFull != null)
				{
					transform.Find("Tachie").gameObject.SetActive(value: true);
					transform.Find("Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
				}
			}
		}
		if (!"".Equals(SharedData.Instance().m_Transfer_Info))
		{
			m_AudioSource.Play();
			InfoPanel.transform.Find("Banner/Text").GetComponent<Text>().text = SharedData.Instance().m_Transfer_Info;
			InfoPanel.SetActive(value: true);
			InfoPanel.transform.Find("Yes").gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Deletewugong));
			InfoPanel.transform.Find("No").gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Deletewugong));
			SharedData.Instance().m_OpenDetail = "InfoPanel";
			SharedData.Instance().m_Transfer_Info = "";
		}
		else
		{
			InfoPanel.SetActive(value: false);
			SharedData.Instance().m_OpenDetail = "";
		}
		curdata = SharedData.Instance().CurrentCharaData;
		base.transform.Find("Panel/WuGong/Basic/LVLimit/WIL/Value").GetComponent<Text>().text = curdata.GetFieldValueByName("WIL").ToString() ?? "";
		base.transform.Find("Panel/WuGong/Basic/LVLimit/Limit/Value").GetComponent<Text>().text = curdata.GetFieldValueByName("WIL").ToString() ?? "";
		int num = Mathf.FloorToInt(curdata.GetFieldValueByName("BON"));
		base.transform.Find("Panel/WuGong/Basic/NumLimit/BON/Value").GetComponent<Text>().text = num.ToString() ?? "";
		base.transform.Find("Panel/WuGong/Basic/NumLimit/Limit/Value").GetComponent<Text>().text = num.ToString() ?? "";
		base.transform.Find("Panel/WuGong/Basic/Current/Text/Value").GetComponent<Text>().text = curdata.m_KongFuList.Count + " / " + num;
		for (int i = 0; i < WuGongBtnList.Count; i++)
		{
			Object.DestroyImmediate(WuGongBtnList[i].gameObject);
		}
		WuGongBtnList.Clear();
		m_WuGongSelectList.Clear();
		GameObject gameObject = null;
		foreach (KongFuData kongFu in curdata.m_KongFuList)
		{
			GameObject gameObject2 = Object.Instantiate(WuGongBtnPrefab, WuGongScrollRect.content.transform);
			gameObject2.transform.Find("Delete").gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Deletewugong));
			EventTriggerListener.Get(gameObject2.transform.Find("Delete").gameObject).onClick = OnButtonClick;
			EventTriggerListener.Get(gameObject2.gameObject).onClick = OnButtonClick;
			gameObject2.AddComponent<HoverWGController>();
			WuGongBtnList.Add(gameObject2);
			GameObject gameObject3 = gameObject2.transform.Find("Select").gameObject;
			EventTriggerListener.Get(gameObject3.gameObject).onClick = OnButtonClick;
			m_WuGongSelectList.Add(gameObject3);
			gang_b07Table.Row row = CommonResourcesData.b07.Find_Relate_Wugong_id(kongFu.kf.ID);
			gameObject2.name = "WuGong|" + row.ID + "|" + kongFu.kf.ID;
			string[] array = kongFu.kf.Attckstyle.Split('|');
			string text = array[0] + array[1];
			int num2 = int.Parse(kongFu.kf.Range);
			if ("C01".Equals(text) && num2 > 1)
			{
				text += "-1";
			}
			gameObject2.transform.Find("RangeBG/Range").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + text, typeof(Sprite)) as Sprite;
			gameObject2.transform.Find("InfoBG/Name/Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + kongFu.kf.Icon, typeof(Sprite)) as Sprite;
			gameObject2.transform.Find("InfoBG/Name/Text").GetComponent<Text>().text = kongFu.kf.Name_Trans;
			gameObject2.transform.Find("InfoBG/Name/Damage").GetComponent<Text>().text = (float.Parse(kongFu.kf.Damage, CultureInfo.InvariantCulture) + (float)(kongFu.lv - 1) * float.Parse(kongFu.kf.Damageadd, CultureInfo.InvariantCulture)).ToString();
			int num3 = int.Parse(kongFu.kf.Star);
			for (int j = 1; j <= 10; j++)
			{
				gameObject2.transform.Find("InfoBG/Stars/Stars" + j).gameObject.SetActive(value: false);
			}
			for (int k = 1; k <= num3; k++)
			{
				gameObject2.transform.Find("InfoBG/Stars/Stars" + k).gameObject.SetActive(value: true);
			}
			gameObject2.transform.Find("Level").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + kongFu.lv + "<size=22><color=#85796A>/" + kongFu.kf.LV + "</color></size>";
			if (gameObject == null)
			{
				gameObject = gameObject2;
			}
		}
		if (statusSub5Type.Equals(StatusSub5Type.Deletewugong) && gameObject != null)
		{
			EventSystem.current.SetSelectedGameObject(gameObject.transform.Find("InfoBG").gameObject);
		}
		StartCoroutine(DelayResetScrollViewPos());
		RefreshSelectedList();
		UpdateInfo();
	}

	private IEnumerator DelayResetScrollViewPos()
	{
		yield return null;
		RectTransform component = WuGongScrollRect.content.GetComponent<RectTransform>();
		component.anchoredPosition = new Vector2(component.anchoredPosition.x, 0f);
	}

	private void RefreshSelectedList()
	{
		foreach (GameObject wuGongSelect in m_WuGongSelectList)
		{
			string[] array = wuGongSelect.transform.parent.gameObject.name.Split('|');
			if (curdata.m_KongFuListInBattle.Contains(array[2]))
			{
				wuGongSelect.transform.GetComponent<Image>().sprite = SelectedSprite;
				wuGongSelect.transform.Find("Text").GetComponent<Text>().text = (curdata.m_KongFuListInBattle.IndexOf(array[2]) + 1).ToString() ?? "";
			}
			else
			{
				wuGongSelect.transform.GetComponent<Image>().sprite = NormalSprite;
				wuGongSelect.transform.Find("Text").GetComponent<Text>().text = "";
			}
		}
	}

	private void UpdateInfo()
	{
		bool flag = false;
		if (!curdata.m_Training_Id.Equals("0"))
		{
			float fieldValueByName = curdata.GetFieldValueByName("LER");
			foreach (KongFuData kongFu in curdata.m_KongFuList)
			{
				if (kongFu.kf.ID.Equals(curdata.m_Training_Id))
				{
					base.transform.Find("Panel/WuGong/Study/Training/Frame/Icon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(kongFu.kf.BookIcon);
					base.transform.Find("Panel/WuGong/Study/Lv/Text/Num").GetComponent<Text>().text = kongFu.lv.ToString() ?? "";
					base.transform.Find("Panel/WuGong/Study/Training/Now/Name").GetComponent<Text>().text = kongFu.kf.Name_Trans ?? "";
					int num = Mathf.RoundToInt(float.Parse(kongFu.kf.EXP, CultureInfo.InvariantCulture) + (float)(kongFu.lv - 1) * float.Parse(kongFu.kf.EXPadd, CultureInfo.InvariantCulture) * Mathf.Abs(3f - fieldValueByName / 10f));
					if (kongFu.lv >= int.Parse(kongFu.kf.LV))
					{
						kongFu.exp = 0f;
						num = 0;
					}
					base.transform.Find("Panel/WuGong/Study/Lv/ExpBar").GetComponent<Slider>().value = ((num == 0) ? 0f : (kongFu.exp / (float)num));
					base.transform.Find("Panel/WuGong/Study/Lv/Exp/Num").GetComponent<Text>().text = kongFu.exp + "/" + num;
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			base.transform.Find("Panel/WuGong/Study/Training/Frame/Icon").GetComponent<Image>().sprite = Resources.Load("images/01-border/0508-icon-Equipment", typeof(Sprite)) as Sprite;
			base.transform.Find("Panel/WuGong/Study/Lv/Text/Num").GetComponent<Text>().text = "0";
			base.transform.Find("Panel/WuGong/Study/Training/Now/Name").GetComponent<Text>().text = "";
			base.transform.Find("Panel/WuGong/Study/Lv/ExpBar").GetComponent<Slider>().value = 0f;
			base.transform.Find("Panel/WuGong/Study/Lv/Exp/Num").GetComponent<Text>().text = "0/0";
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (SharedData.Instance().m_OpenDetail.Length > 0)
		{
			return;
		}
		string[] array = go.name.Split('|');
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MonoBehaviour.print("OnButtonClick: " + go.name);
		if (array[0] == "WuGong")
		{
			SelectedBtn = go;
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(SelectedBtn));
			if (statusSub5Type.Equals(StatusSub5Type.Deletewugong))
			{
				currentDeleteWugongBtn = go.transform.Find("Delete");
			}
		}
		else if (array[0] == "Learn")
		{
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.Wugong, "00000000100");
			CommonResourcesData.inputDeviceDetector.PushJoyStack(go.transform);
		}
		else if (array[0] == "Select")
		{
			if (statusSub5Type.Equals(StatusSub5Type.Deletewugong))
			{
				return;
			}
			string[] array2 = go.transform.parent.gameObject.name.Split('|');
			if (curdata.m_KongFuListInBattle.Contains(array2[2]))
			{
				if (curdata.m_KongFuListInBattle.Count > 1)
				{
					curdata.m_KongFuListInBattle.Remove(array2[2]);
					List<string> list = new List<string>();
					list.AddRange(curdata.m_KongFuListInBattle);
					curdata.m_KongFuListInBattle = list;
					RefreshSelectedList();
				}
			}
			else
			{
				curdata.m_KongFuListInBattle.Add(array2[2]);
				RefreshSelectedList();
			}
		}
		else if (array[0].Equals("Delete"))
		{
			currentDeleteWugongBtn = go.transform;
			InputDeviceDetector.instance.PushJoyStack(currentDeleteWugongBtn?.parent?.transform.Find("InfoBG"));
			InfoPanel.SetActive(value: true);
			string[] array3 = currentDeleteWugongBtn.parent.gameObject.name.Split('|');
			KongFuData kongFuByID = curdata.GetKongFuByID(array3[2]);
			InfoPanel.transform.Find("Banner/Text").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Delete_Wugong_Info1"), kongFuByID.kf.Name_Trans);
			InfoPanel.transform.Find("Yes").gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Deletewugong));
			InfoPanel.transform.Find("No").gameObject.SetActive(statusSub5Type.Equals(StatusSub5Type.Deletewugong));
			EventSystem.current.SetSelectedGameObject(InfoPanel.transform.Find("No").gameObject);
		}
		else if (array[0].Equals("Yes"))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1037");
			InfoPanel.SetActive(value: false);
			InputDeviceDetector.instance.ClearJoyStack();
			string[] array4 = currentDeleteWugongBtn.parent.gameObject.name.Split('|');
			KongFuData kongFuByID2 = curdata.GetKongFuByID(array4[2]);
			if (kongFuByID2 != null)
			{
				if (kongFuByID2.kf.ID.Equals(curdata.m_Training_Id))
				{
					curdata.m_Training_Id = "0";
					SharedData.Instance().PackageAdd(array4[1], 1);
				}
				curdata.KongFuListRemove(kongFuByID2);
				SharedData.Instance().m_TempParas["teammates"] = curdata.Indexs_Name["Name"].stringValue;
				SharedData.Instance().m_TempParas["forgotwugong"] = kongFuByID2.kf.Name_Trans;
				SharedData.Instance().FlagList[SharedData.Instance().m_TempParas["operateflag"] + "_YES"] = 1;
				Debug.Log("StatusSub5::OnButtonClick(Yes): " + SharedData.Instance().m_TempParas["operateflag"] + "_YES = 1");
			}
			else
			{
				SharedData.Instance().FlagList[SharedData.Instance().m_TempParas["operateflag"] + "_ERR"] = 1;
				Debug.Log("StatusSub5::OnButtonClick(Yes): " + SharedData.Instance().m_TempParas["operateflag"] + "_ERR = 1");
			}
			currentDeleteWugongBtn = null;
			RefreshUI();
			base.gameObject.SetActive(value: false);
		}
		else if (array[0].Equals("No"))
		{
			InputDeviceDetector.instance.ResetJoyCurce();
			InfoPanel.SetActive(value: false);
		}
		else if (array[0].Equals("Return"))
		{
			SharedData.Instance().FlagList[SharedData.Instance().m_TempParas["operateflag"] + "_ERR"] = 1;
			Debug.Log("StatusSub5::OnButtonClick(Return): " + SharedData.Instance().m_TempParas["operateflag"] + "_ERR = 1");
			base.gameObject.SetActive(value: false);
		}
	}
}
