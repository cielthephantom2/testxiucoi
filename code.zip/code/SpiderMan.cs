using UnityEngine;

public class SpiderMan : MonoBehaviour
{
	public string traitValue = "";

	private void Start()
	{
	}

	private void Update()
	{
	}
}
