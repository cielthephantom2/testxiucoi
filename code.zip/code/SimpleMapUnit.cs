using System;
using MessagePack;
using UnityEngine;

[Serializable]
[MessagePackObject(false)]
public class SimpleMapUnit
{
	[Key(0)]
	public string map_id = "";

	[Key(1)]
	public Vector3Int unit_pos = Vector3Int.zero;
}
