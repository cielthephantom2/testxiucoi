using System.Collections.Generic;
using UnityEngine;

public class gang_a07Table
{
	public class Row
	{
		public string ID;

		public string Achieved;

		public string Hidden;

		public string GetWay;

		public string UnAchievedIcon;

		public string AchievedIcon;

		public string Type;

		public string TotalValue;

		public string CurValue;

		public string AchieveCondition;

		public string Name;

		public string Name_EN;

		public string Describe;

		public string Describe_EN;

		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);

		public string Describe_Trans => CommonFunc.ShortLangSel(Describe, Describe_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Achieved = list[i][num++],
				Hidden = list[i][num++],
				GetWay = list[i][num++],
				UnAchievedIcon = list[i][num++],
				AchievedIcon = list[i][num++],
				Type = list[i][num++],
				TotalValue = list[i][num++],
				CurValue = list[i][num++],
				AchieveCondition = list[i][num++],
				Name = list[i][num++],
				Describe = list[i][num++]
			};
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_a07_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_a07_" + row.ID + "_Name")?.en_US;
			row.Describe = I18nData.Instance().tableI18N.Find_ID("gang_a07_" + row.ID + "_Describe")?.zh_CH;
			row.Describe_EN = I18nData.Instance().tableI18N.Find_ID("gang_a07_" + row.ID + "_Describe")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}
}
