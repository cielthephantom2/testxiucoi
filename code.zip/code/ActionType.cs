public enum ActionType
{
	None,
	Formless,
	WugongCounter,
	Return,
	FormlessSuper,
	Ambush,
	Runaway,
	Multikill,
	WugongAssist,
	RoleAssist,
	Fantan
}
