using System.Collections.Generic;
using UnityEngine;

public class gang_b16Table
{
	public class Row
	{
		public string ID;

		public string Name;

		public string BattleIcon;

		public string Kungfus;

		public string Traits;

		public string Items;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Name = list[i][num++],
				BattleIcon = list[i][num++],
				Kungfus = list[i][num++],
				Traits = list[i][num++],
				Items = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}
}
