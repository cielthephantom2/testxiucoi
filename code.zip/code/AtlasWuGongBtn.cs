using System.Globalization;
using SuperScrollView;
using UnityEngine;
using UnityEngine.UI;

public class AtlasWuGongBtn : MonoBehaviour
{
	public AtlasWugongData atlasWugongData = new AtlasWugongData();

	private void OnEnable()
	{
		LoopGridView componentInParent = GetComponentInParent<LoopGridView>(includeInactive: true);
		if (componentInParent != null)
		{
			base.transform.GetComponent<RectTransform>().sizeDelta = new Vector2(componentInParent.ItemSize.x, componentInParent.ItemSize.y);
		}
	}

	public void Init(AtlasWugongData atlasWugong)
	{
		atlasWugongData = atlasWugong;
		EventTriggerListener.Get(base.gameObject).onClick = OnHoverButtonClick;
		base.transform.Find("Unlock").gameObject.SetActive(atlasWugongData.isUnlock);
		base.transform.Find("Lock").gameObject.SetActive(!atlasWugongData.isUnlock);
		if (atlasWugongData.isUnlock)
		{
			string[] array = atlasWugongData.b03Row.Attckstyle.Split('|');
			string text = array[0] + array[1];
			int num = int.Parse(atlasWugongData.b03Row.Range);
			if ("C01".Equals(text) && num > 1)
			{
				text += "-1";
			}
			base.transform.Find("Unlock/icon1/Image").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(atlasWugongData.b03Row.BookIcon);
			base.transform.Find("Unlock/RangeBG/Range").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + text, typeof(Sprite)) as Sprite;
			base.transform.Find("Unlock/InfoBG/Name/Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + atlasWugongData.b03Row.Icon, typeof(Sprite)) as Sprite;
			base.transform.Find("Unlock/InfoBG/Name/Text").GetComponent<Text>().text = atlasWugongData.b03Row.Name_Trans;
			base.transform.Find("Unlock/InfoBG/Name/Damage").GetComponent<Text>().text = (float.Parse(atlasWugongData.b03Row.Damage, CultureInfo.InvariantCulture) + (float)(int.Parse(atlasWugongData.b03Row.LV) - 1) * float.Parse(atlasWugongData.b03Row.Damageadd, CultureInfo.InvariantCulture)).ToString();
			for (int i = 1; i <= 10; i++)
			{
				base.transform.Find("Unlock/InfoBG/Stars/Stars" + i).gameObject.SetActive(value: false);
			}
			int num2 = int.Parse(atlasWugongData.b03Row.Star);
			for (int j = 1; j <= num2; j++)
			{
				base.transform.Find("Unlock/InfoBG/Stars/Stars" + j).gameObject.SetActive(value: true);
			}
			base.transform.Find("Unlock/Level").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + atlasWugongData.b03Row.LV;
			switch (atlasWugongData.b03Row.Origin)
			{
			case "1":
				base.transform.Find("Unlock/icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-fo", typeof(Sprite)) as Sprite;
				break;
			case "2":
				base.transform.Find("Unlock/icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-dao", typeof(Sprite)) as Sprite;
				break;
			case "3":
				base.transform.Find("Unlock/icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-ru", typeof(Sprite)) as Sprite;
				break;
			case "4":
				base.transform.Find("Unlock/icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-xie", typeof(Sprite)) as Sprite;
				break;
			case "5":
				base.transform.Find("Unlock/icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-za", typeof(Sprite)) as Sprite;
				break;
			}
			string level = "";
			string level2 = "";
			string name_Trans = atlasWugongData.b03Row.Name_Trans;
			switch (atlasWugongData.b03Row.Style)
			{
			case "101":
			case "201":
			case "301":
			case "401":
			case "501":
			case "601":
			case "701":
			case "801":
			case "1001":
				level = atlasWugongData.b03Row.atlasType.Split('_')[0];
				level2 = atlasWugongData.b03Row.atlasType.Split('_')[1];
				break;
			case "901":
			case "9101":
			case "9301":
			case "9401":
			case "9501":
				level = "Skill";
				if (atlasWugongData.b03Row.Style == "901")
				{
					level2 = "Inner";
				}
				else if (atlasWugongData.b03Row.Style == "9501")
				{
					level2 = "Lightness";
				}
				else if (atlasWugongData.b03Row.Style == "9101")
				{
					level2 = "Formation";
				}
				else if (atlasWugongData.b03Row.Style == "9301")
				{
					level2 = "Assist";
				}
				else if (atlasWugongData.b03Row.Style == "9401")
				{
					level2 = "Recipe";
				}
				break;
			case "9601":
				level = "Ultimate";
				break;
			}
			atlasWugongData.level1 = level;
			atlasWugongData.level2 = level2;
			atlasWugongData.level3 = name_Trans;
		}
		else
		{
			base.transform.Find("Lock/Name").GetComponent<Text>().text = atlasWugongData.b03Row.Name_Trans;
			base.transform.Find("Lock/Des").GetComponent<Text>().text = atlasWugongData.b07Row.note_Trans;
		}
		base.gameObject.name = "WuGong|" + atlasWugongData.b07Row.ID;
	}

	private void OnHoverButtonClick(GameObject go)
	{
		if (atlasWugongData.isUnlock && !CommonFunc.IsHoverOpen())
		{
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(go, showEquip: false, useCharaData: false));
		}
	}
}
