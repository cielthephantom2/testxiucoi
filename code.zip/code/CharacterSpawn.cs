using UnityEngine;

public static class CharacterSpawn
{
	private static bool init = false;

	public static SkinDependences skinDependences = new SkinDependences();

	public static void Init()
	{
		skinDependences = Resources.Load<SkinDependences>("SkinCharacter/01-spine-role/SkinDependences");
		init = true;
	}

	public static SkinDependence GetSkinDependence(string name)
	{
		if (!init)
		{
			Init();
		}
		return skinDependences.skinDependences.Find((SkinDependence x) => x.SkinSkeletonType.Equals(name));
	}
}
