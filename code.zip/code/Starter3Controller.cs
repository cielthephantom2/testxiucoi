using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Starter3Controller : MonoBehaviour
{
	private Color unInteractableColor = new Color(40f / 51f, 40f / 51f, 40f / 51f, 0.5019608f);

	private Color stat_txt_common = new Color(0.62f, 0.56f, 0.49f, 1f);

	private Color stat_txt_highlight = new Color(0.93f, 0.89f, 0.8f, 1f);

	private Color stat_txt_darklight = new Color(0.23f, 0.22f, 0.18f, 1f);

	private Color stat_txt_good_2 = new Color(1f, 1f, 0.5f, 1f);

	private Color stat_txt_good_3 = new Color(1f, 0.49f, 0.15f, 1f);

	private Color stat_txt_reduce = Color.white;

	private Color stat_txt_add = Color.white;

	private string stat_txt_common_color = "#9a8b76";

	private string stat_txt_highlight_color = "#e3d1ad";

	private string stat_txt_reduce_color = "#cd451b";

	private string stat_txt_add_color = "#ebac34";

	private Sprite normalSprite;

	private Sprite selectedSprite;

	private List<IronMan> IronMenRoll;

	private List<SpiderMan> SpiderMenRoll;

	private List<IronMan> IronMenSpecify;

	private Dictionary<string, float> AddList = new Dictionary<string, float>();

	private gang_a02Table.Row a02row;

	private long RollCount;

	private Text RollCountText;

	private TMP_InputField m_InputField;

	private HoverController[] hovers;

	public GameObject eventSystem;

	public GameObject mainCamera;

	private Text PlayRoundText;

	private Text LockCountText;

	private Text AttrPointsText;

	private int lockNumber;

	private int totalAtPoints;

	private int attrCostAtPoints;

	private List<int> traitCostAtPointsList = new List<int> { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	[HideInInspector]
	public List<Transform> AtlasInfoList = new List<Transform>();

	public TraitNineGirdController customTraitNineGirdController;

	private bool isRenaming;

	private int traitCostAtPoints
	{
		get
		{
			int num = 0;
			foreach (int traitCostAtPoints in traitCostAtPointsList)
			{
				num += traitCostAtPoints;
			}
			return num;
		}
	}

	private void Start()
	{
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		ColorUtility.TryParseHtmlString(stat_txt_common_color, out stat_txt_common);
		ColorUtility.TryParseHtmlString(stat_txt_highlight_color, out stat_txt_highlight);
		ColorUtility.TryParseHtmlString(stat_txt_add_color, out stat_txt_add);
		ColorUtility.TryParseHtmlString(stat_txt_reduce_color, out stat_txt_reduce);
		customTraitNineGirdController = base.transform.Find("Panel/Specify").GetComponentInChildren<TraitNineGirdController>(includeInactive: true);
		customTraitNineGirdController.starter3Controller = this;
		normalSprite = Resources.Load("images/01-border/boder-20231228-01", typeof(Sprite)) as Sprite;
		selectedSprite = Resources.Load("images/01-border/boder-20231228-05", typeof(Sprite)) as Sprite;
		GameObject.FindGameObjectWithTag("MainCamera").GetComponent<AudioSource>();
		gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(SharedData.Instance().playerid);
		if (SharedData.Instance().protagonistSkinDataNew.isCustom)
		{
			base.transform.Find("Panel/CharacterIcon/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(SharedData.Instance().playerid, 0, SharedData.Instance().protagonistSkinB01SkinTable);
		}
		else
		{
			base.transform.Find("Panel/CharacterIcon/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(SharedData.Instance().playerid);
		}
		base.transform.Find("Panel/Tachie").gameObject.SetActive(value: false);
		if (row.BattleIcon != "")
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(row.BattleIcon);
			if (tachieFull != null)
			{
				base.transform.Find("Panel/Tachie").gameObject.SetActive(value: true);
				base.transform.Find("Panel/Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
			}
		}
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button button in componentsInChildren)
		{
			if (!(button.transform.parent.name == "TraitNineGrid"))
			{
				EventTriggerListener.Get(button.gameObject).onClick = OnButtonClick;
			}
		}
		if (SharedData.Instance().m_Player_Reset == 1)
		{
			base.transform.Find("Panel/Return").gameObject.SetActive(value: false);
			eventSystem.SetActive(value: false);
			mainCamera.transform.GetComponent<AudioListener>().enabled = false;
			mainCamera.transform.GetComponent<AudioSource>().enabled = false;
		}
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo1"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo2"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo3"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo4"));
		AtlasInfoList.Add(base.transform.Find("AtlasInfoList/AtlasInfo5"));
		IronMenRoll = base.transform.Find("Panel/Roll/Status").GetComponentsInChildren<IronMan>(includeInactive: true).ToList();
		SpiderMenRoll = base.transform.Find("Panel/Roll/Traits").GetComponentsInChildren<SpiderMan>(includeInactive: true).ToList();
		IronMenSpecify = base.transform.Find("Panel/Specify/Status").GetComponentsInChildren<IronMan>(includeInactive: true).ToList();
		foreach (IronMan item in IronMenRoll)
		{
			item.GetComponent<HoverController>().enabled = true;
			gang_a01Table.Row row2 = CommonResourcesData.a01.Find_Name(item.name);
			item.atomData.a01Name = row2.Name;
			item.atomData.a01ID = row2.ID;
			item.Init();
			item.transform.Find("Title/Text").GetComponent<Text>().text = row2.NameUI_Trans;
		}
		foreach (IronMan item2 in IronMenSpecify)
		{
			item2.GetComponent<HoverController>().enabled = true;
			gang_a01Table.Row row3 = CommonResourcesData.a01.Find_Name(item2.name);
			item2.atomData = charaData.Indexs_Name[item2.name];
			item2.atomData.a01Name = row3.Name;
			item2.atomData.a01ID = row3.ID;
			item2.Init();
			item2.transform.Find("Title/Text").GetComponent<Text>().text = row3.NameUI_Trans;
		}
		if (SharedData.Instance().BornID.Length == 0)
		{
			SharedData.Instance().BornID = "1001";
		}
		a02row = CommonResourcesData.a02.Find_ID(SharedData.Instance().BornID);
		base.transform.Find("Panel/Name/Text").GetComponent<Text>().text = a02row.Name_Trans;
		base.transform.Find("Panel/Born/Text").GetComponent<Text>().text = a02row.Scenario_Trans;
		base.transform.Find("Panel/GoodAt/Text").GetComponent<Text>().text = a02row.GoodAt_Trans;
		m_InputField = base.transform.Find("Panel/InputField").GetComponent<TMP_InputField>();
		if (GameDataManager.Instance().configdata.language == "English")
		{
			m_InputField.characterLimit = 15;
		}
		else
		{
			m_InputField.characterLimit = 5;
		}
		m_InputField.text = a02row.Name_Trans;
		m_InputField.onEndEdit.AddListener(delegate
		{
			StartCoroutine(SetSelectedGameObjectNextFrame());
		});
		RollCountText = base.transform.Find("RollCount").GetComponent<Text>();
		Roll();
		Custom();
		hovers = base.transform.Find("Panel").GetComponentsInChildren<HoverController>();
		PlayRoundText = base.transform.Find("Panel/RoundNum/Num").GetComponent<Text>();
		PlayRoundText.text = (GameDataManager.Instance().configdata.playRound + 1).ToString();
		LockCountText = base.transform.Find("Panel/Roll/Status/Title/LockCount/Num").GetComponent<Text>();
		LockCountText.text = (GameDataManager.Instance().configdata.playRound + 1).ToString();
		lockNumber = GameDataManager.Instance().configdata.playRound + 1;
		totalAtPoints = 30 + GameDataManager.Instance().configdata.playRound;
		AttrPointsText = base.transform.Find("Panel/Specify/Status/Title/AtPoints/Num").GetComponent<Text>();
		AttrPointsText.text = (totalAtPoints - attrCostAtPoints - traitCostAtPoints).ToString();
		SharedData.Instance().starGameTimeSpan = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Roll/Status/Basic1/HP").gameObject);
		ReFreshPlusAndReduceBtn();
	}

	private IEnumerator SetSelectedGameObjectNextFrame()
	{
		yield return null;
		if (EventSystem.current.currentSelectedGameObject != base.transform.Find("Panel/ReName").gameObject)
		{
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/ReName").gameObject);
		}
	}

	private void Update()
	{
		if (CommonFunc.IsHoverOpen() || !(SharedData.Instance().m_TraitPackageController != null) || SharedData.Instance().m_TraitPackageController.isOpen)
		{
			return;
		}
		if (m_InputField.isFocused && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			m_InputField.DeactivateInputField();
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/ReName").gameObject);
		}
		else if (InputSystemCustom.Instance().UI.RoolTraits.WasReleasedThisFrame() && !m_InputField.gameObject.activeInHierarchy)
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Random").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.CustomTraits.WasReleasedThisFrame() && !m_InputField.gameObject.activeInHierarchy)
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Custom").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.LockAttr.WasReleasedThisFrame() && !m_InputField.gameObject.activeInHierarchy)
		{
			if (CommonResourcesData.inputDeviceDetector.JoyCursor.parent.name == "Lock")
			{
				ExecuteEvents.Execute(CommonResourcesData.inputDeviceDetector.JoyCursor.parent.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
				return;
			}
			GameObject gameObject = CommonResourcesData.inputDeviceDetector.JoyCursor.parent.Find("Lock")?.gameObject;
			if (gameObject == null)
			{
				gameObject = CommonResourcesData.inputDeviceDetector.JoyCursor.parent.parent.Find("Lock")?.gameObject;
			}
			if (gameObject != null)
			{
				ExecuteEvents.Execute(gameObject.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
		else if (InputSystemCustom.Instance().UI.Rename.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/ReName").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && !m_InputField.gameObject.activeInHierarchy)
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Return").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.Starter3Confirm.WasReleasedThisFrame() && !m_InputField.gameObject.activeInHierarchy)
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Next").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	private void Roll()
	{
		Type type = a02row.GetType();
		foreach (IronMan item in IronMenRoll)
		{
			string value = item.name;
			string text = item.name + "1";
			int num = (int)item.atomData.rollValue;
			item.atomData.ResetValue();
			FieldInfo field = type.GetField(value);
			if (field == null)
			{
				if ("TALENT".Equals(value))
				{
					item.transform.Find("Num").GetComponent<Text>().text = "5";
					item.atomData.rollValue = 5f;
				}
				continue;
			}
			FieldInfo field2 = type.GetField(text);
			int num2 = int.Parse(field.GetValue(a02row).ToString());
			int num3 = int.Parse(field2.GetValue(a02row).ToString());
			int num4 = UnityEngine.Random.Range(num2, num3 + 1);
			if (item.transform.Find("Lock/Lock").gameObject.activeInHierarchy)
			{
				num4 = num;
			}
			item.atomData.rollValue = num4;
			if (num4 == num3)
			{
				item.transform.Find("Num").GetComponent<Text>().color = stat_txt_highlight;
			}
			else if (num4 == num2)
			{
				item.transform.Find("Num").GetComponent<Text>().color = stat_txt_darklight;
			}
			else
			{
				item.transform.Find("Num").GetComponent<Text>().color = stat_txt_common;
			}
		}
		RollTraits(a02row.Features);
		RollCount++;
		RollCountText.text = RollCount.ToString() ?? "";
	}

	private void RollTraits(string _traitlist)
	{
		List<string> list = new List<string>(_traitlist.Split('|'));
		int num = UnityEngine.Random.Range(1, 4);
		num = 3;
		AddList.Clear();
		List<gang_b06Table.Row> list2 = new List<gang_b06Table.Row>();
		foreach (SpiderMan item in SpiderMenRoll)
		{
			if (item.transform.Find("Lock/Lock").gameObject.activeInHierarchy)
			{
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.traitValue);
				list2.Add(row);
				RunTrait(row.add1, row.attribute1);
				RunTrait(row.add2, row.attribute2);
				RunTrait(row.add3, row.attribute3);
				RunTrait(row.add4, row.attribute4);
				list.Remove(item.traitValue);
				num--;
			}
			else if (num > 0)
			{
				int index;
				gang_b06Table.Row row2;
				while (true)
				{
					index = UnityEngine.Random.Range(0, list.Count);
					row2 = CommonResourcesData.b06.Find_id(list[index]);
					if (row2 == null)
					{
						Debug.LogWarning("traits.Count = " + list.Count);
						Debug.LogWarning("rid = " + index);
						Debug.LogWarning("rndcnt = " + num);
						Debug.LogWarning("traits[rid] = [" + list[index] + "]");
					}
					else
					{
						float num2 = float.Parse(row2.probability, CultureInfo.InvariantCulture);
						if (!(UnityEngine.Random.Range(0f, 1f) > num2) && row2.traitEquipIndex.Contains(item.name.Split("|")[1]))
						{
							break;
						}
					}
				}
				item.traitValue = list[index];
				GameDataManager.Instance().AddUnlockAtlasList(item.traitValue, "b06");
				item.transform.Find("TraitIcon").GetComponent<TraitIconController>().InitTraitIcon(item.traitValue, item.gameObject.name.Split("|")[1]);
				item.transform.Find("Name/Text").GetComponent<Text>().text = row2.name_Trans;
				item.transform.Find("Info/Text").GetComponent<Text>().text = row2.note_Trans;
				item.transform.Find("Hover/Text").GetComponent<Text>().text = row2.comment_Trans;
				item.transform.Find("Info").GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, item.transform.Find("Info/Text").GetComponent<Text>().preferredHeight + 30f);
				RunTrait(row2.add1, row2.attribute1);
				RunTrait(row2.add2, row2.attribute2);
				RunTrait(row2.add3, row2.attribute3);
				RunTrait(row2.add4, row2.attribute4);
				list.RemoveAt(index);
				num--;
				item.gameObject.SetActive(value: true);
			}
			else
			{
				item.transform.Find("Name/Text").GetComponent<Text>().text = "";
				item.transform.Find("Name/Text").GetComponent<Text>().text = "";
				item.traitValue = "";
				item.gameObject.SetActive(value: false);
			}
		}
		foreach (IronMan item2 in IronMenRoll)
		{
			if (AddList.ContainsKey(item2.name))
			{
				int num3 = Mathf.RoundToInt(AddList[item2.name]);
				item2.atomData.traitValue = num3;
			}
			item2.transform.Find("Num").GetComponent<Text>().text = item2.atomData.totalValue.ToString();
			item2.Init();
		}
	}

	private void Custom()
	{
		Type type = a02row.GetType();
		foreach (IronMan item in IronMenSpecify)
		{
			string value = item.name;
			string text = item.name + "1";
			_ = item.atomData.rollValue;
			item.atomData.ResetValue();
			FieldInfo field = type.GetField(value);
			if (field == null)
			{
				if ("TALENT".Equals(value))
				{
					item.transform.Find("Num").GetComponent<Text>().text = "5";
					item.atomData.rollValue = 5f;
				}
				continue;
			}
			if ("STR".Equals(value) || "AGI".Equals(value) || "BON".Equals(value) || "WIL".Equals(value) || "LER".Equals(value) || "MOR".Equals(value))
			{
				item.atomData.rollValue = int.Parse(field.GetValue(a02row).ToString());
				item.transform.Find("Num").GetComponent<Text>().text = item.atomData.rollValue.ToString();
				item.Init();
				continue;
			}
			FieldInfo field2 = type.GetField(text);
			int num = int.Parse(field.GetValue(a02row).ToString());
			int num2 = int.Parse(field2.GetValue(a02row).ToString());
			int num3 = (num + num2) / 2;
			item.atomData.rollValue = num3;
			if (num3 == num2)
			{
				item.transform.Find("Num").GetComponent<Text>().color = stat_txt_highlight;
			}
			else if (num3 == num)
			{
				item.transform.Find("Num").GetComponent<Text>().color = stat_txt_darklight;
			}
			else
			{
				item.transform.Find("Num").GetComponent<Text>().color = stat_txt_common;
			}
			item.transform.Find("Num").GetComponent<Text>().text = item.atomData.totalValue.ToString();
			item.Init();
		}
	}

	public void CustomTrait()
	{
		foreach (IronMan item in IronMenSpecify)
		{
			item.atomData.traitValue = 0f;
		}
		AddList.Clear();
		int num = 0;
		foreach (KeyValuePair<string, string> item2 in customTraitNineGirdController.TraitDict)
		{
			if (item2.Value != "")
			{
				num++;
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item2.Value);
				traitCostAtPointsList[int.Parse(item2.Key) - 1] = int.Parse(row.traitCost);
				RunTrait(row.add1, row.attribute1);
				RunTrait(row.add2, row.attribute2);
				RunTrait(row.add3, row.attribute3);
				RunTrait(row.add4, row.attribute4);
			}
			else
			{
				traitCostAtPointsList[int.Parse(item2.Key) - 1] = 0;
			}
		}
		foreach (IronMan item3 in IronMenSpecify)
		{
			int num2 = 0;
			if (AddList.ContainsKey(item3.name))
			{
				num2 = Mathf.RoundToInt(AddList[item3.name]);
			}
			item3.atomData.traitValue = num2;
			item3.transform.Find("Num").GetComponent<Text>().text = item3.atomData.totalValue.ToString();
			item3.Init();
		}
		AttrPointsText.text = (totalAtPoints - attrCostAtPoints - traitCostAtPoints).ToString();
		base.transform.Find("Panel/Specify/Traits/Title/Cost/Num").GetComponent<Text>().text = traitCostAtPoints.ToString();
		ReFreshPlusAndReduceBtn();
	}

	private void RunTrait(string _add, string _attribute)
	{
		if (_add != "0")
		{
			if (!AddList.ContainsKey(_add))
			{
				AddList.Add(_add, float.Parse(_attribute, CultureInfo.InvariantCulture));
			}
			else
			{
				AddList[_add] += float.Parse(_attribute, CultureInfo.InvariantCulture);
			}
		}
	}

	private void ReFreshPlusAndReduceBtn()
	{
		Transform transform = base.transform.Find("Panel/Specify/Status/Basic2");
		for (int i = 0; i < transform.childCount; i++)
		{
			IronMan component = transform.GetChild(i).GetComponent<IronMan>();
			Button component2 = component.transform.Find("Specify/plus").GetComponent<Button>();
			Button component3 = component.transform.Find("Specify/reduce").GetComponent<Button>();
			int num = (int)component.atomData.totalValue;
			int num2 = int.MaxValue;
			switch (component.transform.gameObject.name)
			{
			case "STR":
				num2 = int.Parse(a02row.STR1);
				break;
			case "WIL":
				num2 = int.Parse(a02row.WIL1);
				break;
			case "LER":
				num2 = int.Parse(a02row.LER1);
				break;
			case "MOR":
				num2 = int.Parse(a02row.MOR1);
				break;
			case "AGI":
				num2 = int.Parse(a02row.AGI1);
				break;
			case "BON":
				num2 = int.Parse(a02row.BON1);
				break;
			}
			int num3 = int.MaxValue;
			if (num >= 0 && num <= 9)
			{
				num3 = 1;
			}
			else if (num >= 10 && num <= 19)
			{
				num3 = 2;
			}
			else if (num >= 20 && num <= 29)
			{
				num3 = 3;
			}
			if (component.atomData.talentValue > 0f)
			{
				component3.GetComponent<Image>().color = Color.white;
			}
			else
			{
				component3.GetComponent<Image>().color = unInteractableColor;
			}
			if (num3 > 0 && totalAtPoints - attrCostAtPoints - traitCostAtPoints >= num3 && num < 30 && (float)num - component.atomData.traitValue <= (float)num2)
			{
				component2.GetComponent<Image>().color = Color.white;
			}
			else
			{
				component2.GetComponent<Image>().color = unInteractableColor;
			}
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || go.GetComponent<Image>()?.color == unInteractableColor)
		{
			return;
		}
		MonoBehaviour.print("OnButtonClick -> " + go.name);
		if (go.name == "plus" || go.name == "reduce")
		{
			string text = go.transform.parent.parent.name;
			IronMan component = base.transform.Find("Panel/Specify/Status/Basic2/" + text).GetComponent<IronMan>();
			int num = (int)component.atomData.rollValue + (int)component.atomData.talentValue + ((!(go.name == "plus")) ? (-1) : 0);
			int num2 = int.MaxValue;
			if (num >= 0 && num <= 9)
			{
				num2 = 1;
			}
			else if (num <= 19)
			{
				num2 = 2;
			}
			else if (num <= 29)
			{
				num2 = 3;
			}
			if (totalAtPoints - attrCostAtPoints - traitCostAtPoints >= num2 || !(go.name == "plus"))
			{
				if (go.name == "plus")
				{
					component.atomData.talentValue += 1f;
					attrCostAtPoints += num2;
				}
				else if (go.name == "reduce")
				{
					component.atomData.talentValue -= 1f;
					attrCostAtPoints -= num2;
				}
				AttrPointsText.text = (totalAtPoints - attrCostAtPoints - traitCostAtPoints).ToString();
				component.transform.Find("Num").GetComponent<Text>().text = component.atomData.totalValue.ToString();
				component.Init();
				ReFreshPlusAndReduceBtn();
			}
		}
		else if (go.name == "Next")
		{
			string bornID = SharedData.Instance().BornID;
			string playerid = SharedData.Instance().playerid;
			SharedData.Instance().starGameTimeSpan = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			SharedData.Instance().playerid = playerid;
			SharedData.Instance().BornID = bornID;
			SharedData.Instance().m_Game_Mode = 2;
			if (SharedData.Instance().m_Player_Reset == 1)
			{
				SharedData.Instance().RemoveCharaData(SharedData.Instance().playerid);
			}
			CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
			charaData.m_SkinData.isInit = true;
			if (SharedData.Instance().protagonistSkinDataNew.isCustom)
			{
				charaData.b01SkinRow = SharedData.Instance().protagonistSkinB01SkinTable;
			}
			else
			{
				charaData.b01SkinRow = null;
			}
			if (m_InputField.gameObject.activeInHierarchy)
			{
				charaData.Indexs_Name["Name"].stringValue = base.transform.Find("Panel/Name/Text").GetComponent<Text>().text;
			}
			else
			{
				charaData.Indexs_Name["Name"].stringValue = m_InputField.text;
			}
			SetCharacterData();
			if (SharedData.Instance().m_Player_Reset == 0)
			{
				SharedData.Instance().m_Money = 0;
				SharedData.Instance().m_Money += int.Parse(a02row.Money);
				SharedData.Instance().PlayerPackage.Add("999", 0);
			}
			charaData.m_KongFuList.Clear();
			charaData.m_KongFuListInBattle.Clear();
			string[] array = a02row.Kongfu.Split('|');
			foreach (string find in array)
			{
				KongFuData kongFuData = new KongFuData();
				kongFuData.kf = CommonResourcesData.b03.Find_ID(find);
				kongFuData.lv = 1;
				kongFuData.exp = 0f;
				charaData.KongFuListAdd(kongFuData);
			}
			charaData.m_Training_Id = "0";
			charaData.GetFieldValueByName("HP");
			charaData.GetFieldValueByName("MP");
			charaData.m_NicknameList.Add("破庙大侠");
			if (SharedData.Instance().m_Player_Reset == 0)
			{
				SharedData.Instance().m_PlayRound = GameDataManager.Instance().configdata.playRound + 1;
				SharedData.Instance().PlayCGName = "OP1";
				SharedData.Instance().AfterCGPlayComplete = "";
				SharedData.Instance().SceneBefore = "";
				SharedData.Instance().ASyncLoadScene("CGPlayer");
			}
			else
			{
				SharedData.Instance().m_Player_Reset = 0;
				SharedData.Instance().LoadedSceneStack.Clear();
				SceneManager.UnloadSceneAsync("Starter3");
			}
		}
		else if (go.name == "ReName")
		{
			OnButtonRenameClick();
		}
		else if (go.name == "Random")
		{
			if (base.transform.Find("Panel/Roll").gameObject.activeInHierarchy)
			{
				Roll();
				return;
			}
			base.transform.Find("Panel/Roll").gameObject.SetActive(value: true);
			base.transform.Find("Panel/Specify").gameObject.SetActive(value: false);
			base.transform.Find("Panel/Random").GetComponent<Image>().sprite = selectedSprite;
			base.transform.Find("Panel/Custom").GetComponent<Image>().sprite = normalSprite;
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Roll/Status/Basic1/HP").gameObject);
		}
		else if (go.name == "Custom")
		{
			if (!base.transform.Find("Panel/Specify").gameObject.activeInHierarchy)
			{
				base.transform.Find("Panel/Roll").gameObject.SetActive(value: false);
				base.transform.Find("Panel/Specify").gameObject.SetActive(value: true);
				base.transform.Find("Panel/Random").GetComponent<Image>().sprite = normalSprite;
				base.transform.Find("Panel/Custom").GetComponent<Image>().sprite = selectedSprite;
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Specify/Status/Basic1/HP").gameObject);
			}
		}
		else if (go.name == "Return")
		{
			SharedData.Instance().ASyncLoadScene("Starter2");
		}
		else
		{
			if (!(go.name == "Lock"))
			{
				return;
			}
			bool activeInHierarchy = go.transform.Find("UnLock").gameObject.activeInHierarchy;
			if (activeInHierarchy && lockNumber > 0)
			{
				lockNumber--;
				go.transform.Find("UnLock").gameObject.SetActive(!activeInHierarchy);
				go.transform.Find("Lock").gameObject.SetActive(activeInHierarchy);
			}
			else if (!activeInHierarchy)
			{
				lockNumber++;
				go.transform.Find("UnLock").gameObject.SetActive(!activeInHierarchy);
				go.transform.Find("Lock").gameObject.SetActive(activeInHierarchy);
			}
			LockCountText.text = lockNumber.ToString();
			foreach (IronMan item in IronMenRoll)
			{
				if (item.transform.Find("Lock/UnLock").gameObject.activeInHierarchy && lockNumber <= 0)
				{
					item.transform.Find("Lock/UnLock/Image").GetComponent<Image>().color = Color.gray;
				}
				else
				{
					item.transform.Find("Lock/UnLock/Image").GetComponent<Image>().color = Color.white;
				}
			}
			foreach (SpiderMan item2 in SpiderMenRoll)
			{
				if (item2.transform.Find("Lock/UnLock").gameObject.activeInHierarchy && lockNumber <= 0)
				{
					item2.transform.Find("Lock/UnLock/Image").GetComponent<Image>().color = Color.gray;
				}
				else
				{
					item2.transform.Find("Lock/UnLock/Image").GetComponent<Image>().color = Color.white;
				}
			}
		}
	}

	public void OnButtonRenameClick()
	{
		if (!isRenaming)
		{
			if (m_InputField.gameObject.gameObject.activeInHierarchy)
			{
				isRenaming = true;
				CommonFunc.CheckSensitiveWords(m_InputField.text, OnCheckSensitiveWordsCompleted);
			}
			else
			{
				m_InputField.gameObject.SetActive(value: true);
				EventSystem.current.SetSelectedGameObject(m_InputField.gameObject);
				base.transform.Find("Panel/ReName/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_OK");
			}
		}
	}

	private void OnCheckSensitiveWordsCompleted(bool result)
	{
		isRenaming = false;
		if (!result)
		{
			m_InputField.gameObject.SetActive(value: false);
			base.transform.Find("Panel/Name/Text").GetComponent<Text>().text = m_InputField.text;
			base.transform.Find("Panel/ReName/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Rename");
		}
		else
		{
			m_InputField.text = base.transform.Find("Panel/Name/Text").GetComponent<Text>().text;
		}
	}

	private IEnumerator TestBatchRoll()
	{
		while (true)
		{
			Roll();
			yield return new WaitForSeconds(0.001f);
		}
	}

	private void SetCharacterData()
	{
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		List<IronMan> list = null;
		bool activeInHierarchy = base.transform.Find("Panel/Roll").gameObject.activeInHierarchy;
		list = ((!activeInHierarchy) ? IronMenSpecify : IronMenRoll);
		foreach (IronMan item in list)
		{
			charaData.Indexs_Name[item.name].rollValue = item.atomData.rollValue + ((!activeInHierarchy) ? charaData.Indexs_Name[item.name].talentValue : 0f);
			charaData.Indexs_Name[item.name].talentValue = 0f;
			charaData.Indexs_Name[item.name].traitValue = 0f;
			charaData.Indexs_Name[item.name].bornValue = charaData.Indexs_Name[item.name].rollValue;
			if (item.name == "HP")
			{
				charaData.m_Hp = item.atomData.rollValue;
			}
			else if (item.name == "MP")
			{
				charaData.m_Mp = item.atomData.rollValue;
			}
			else
			{
				_ = item.name == "TALENT";
			}
		}
		charaData.m_TraitList.Clear();
		if (base.transform.Find("Panel/Roll").gameObject.activeInHierarchy)
		{
			foreach (SpiderMan item2 in SpiderMenRoll)
			{
				if (item2.traitValue.Length > 0)
				{
					charaData.AddTraits(item2.traitValue);
					GameDataManager.Instance().AddUnlockAtlasList(item2.traitValue, "b06");
				}
			}
			return;
		}
		foreach (KeyValuePair<string, string> item3 in customTraitNineGirdController.TraitDict)
		{
			if (item3.Value != "")
			{
				charaData.AddTraits(item3.Value);
				GameDataManager.Instance().AddUnlockAtlasList(item3.Value, "b06");
			}
		}
	}

	public void UnlockAtlas()
	{
		if (SharedData.Instance().UnlockAtlasInfoList.Count == 0)
		{
			return;
		}
		foreach (KeyValuePair<string, Sprite> unlockAtlasInfo in SharedData.Instance().UnlockAtlasInfoList)
		{
			if (SharedData.Instance().UnlockAtlasInfoAlreadyShow.Contains(unlockAtlasInfo.Key))
			{
				continue;
			}
			foreach (Transform atlasInfo in AtlasInfoList)
			{
				if (!atlasInfo.GetComponent<Animation>().isPlaying)
				{
					atlasInfo.Find("Text").GetComponent<Text>().text = CommonFunc.ShortLangSel("解锁图鉴", "UnLock Atlas") + "[" + unlockAtlasInfo.Key + "]";
					atlasInfo.Find("Image").GetComponent<Image>().sprite = unlockAtlasInfo.Value;
					atlasInfo.GetComponent<Animation>()["Achievements" + atlasInfo.gameObject.name[atlasInfo.gameObject.name.Length - 1]].speed = 1f;
					atlasInfo.GetComponent<Animation>().Play();
					SharedData.Instance().UnlockAtlasInfoAlreadyShow.Add(unlockAtlasInfo.Key);
					break;
				}
			}
		}
	}
}
