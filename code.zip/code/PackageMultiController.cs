using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PackageMultiController : MonoBehaviour
{
	private GameObject DetailBox;

	private GameObject SelectedBtn;

	private List<string> SelectedList = new List<string>();

	private GameObject ReturnBtn;

	private GameObject UseBtn;

	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	public Button[] buttons;

	private List<GameObject> btnobjs = new List<GameObject>();

	private Dropdown sortDropDown;

	private Text topBannerText;

	private string topBannerTextTemplet = "";

	private Transform hoverItem;

	private Transform hoverWuGong;

	private string selectedName = "Selected";

	private void Awake()
	{
		NormalSprite = Resources.Load("images/01-border/0508-icon-item-02", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/0508-icon-item-01", typeof(Sprite)) as Sprite;
	}

	private void Start()
	{
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		ReturnBtn = base.transform.Find("Panel/Return").gameObject;
		EventTriggerListener.Get(ReturnBtn).onClick = OnButtonClick;
		ReturnBtn.SetActive(value: false);
		DetailBox = base.transform.Find("Panel/DetailBox").gameObject;
		UseBtn = DetailBox.transform.Find("Use").gameObject;
		EventTriggerListener.Get(UseBtn).onClick = OnButtonClick;
		UseBtn.transform.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Inherit");
		hoverItem = base.transform.Find("Panel/HoverItem");
		hoverWuGong = base.transform.Find("Panel/HoverWuGong");
		string language = GameDataManager.Instance().configdata.language;
		if (!(language == "English"))
		{
			if (language == "ChineseTraditional")
			{
				sortDropDown = base.transform.Find("Panel/SortDropDownTW").GetComponent<Dropdown>();
				base.transform.Find("Panel/SortDropDownEN").gameObject.SetActive(value: false);
				base.transform.Find("Panel/SortDropDown").gameObject.SetActive(value: false);
				topBannerText = base.transform.Find("Panel/TopBanner/LangObj_Traditional").GetComponent<Text>();
				selectedName = "SelectedTW";
			}
			else
			{
				sortDropDown = base.transform.Find("Panel/SortDropDown").GetComponent<Dropdown>();
				base.transform.Find("Panel/SortDropDownEN").gameObject.SetActive(value: false);
				base.transform.Find("Panel/SortDropDownTW").gameObject.SetActive(value: false);
				topBannerText = base.transform.Find("Panel/TopBanner/LangObj").GetComponent<Text>();
				selectedName = "Selected";
			}
		}
		else
		{
			sortDropDown = base.transform.Find("Panel/SortDropDownEN").GetComponent<Dropdown>();
			base.transform.Find("Panel/SortDropDownTW").gameObject.SetActive(value: false);
			base.transform.Find("Panel/SortDropDown").gameObject.SetActive(value: false);
			topBannerText = base.transform.Find("Panel/TopBanner/LangObj_English").GetComponent<Text>();
			selectedName = "SelectedEN";
		}
		sortDropDown.gameObject.SetActive(value: true);
		SharedData.Instance().m_SortType = "1111111111";
		sortDropDown.value = 0;
		sortDropDown.onValueChanged.AddListener(ChangeSortType);
		topBannerTextTemplet = topBannerText.text;
		string text = topBannerTextTemplet.Replace("*#NUM#", (SharedData.Instance().m_InheritItemCount - SelectedList.Count).ToString());
		topBannerText.text = text;
		RefreshUIList(0);
	}

	private void ChangeSortType(int _index)
	{
		RefreshUIList(_index);
	}

	private void RefreshUIList(int _sortType)
	{
		foreach (GameObject btnobj in btnobjs)
		{
			Object.Destroy(btnobj);
		}
		btnobjs.Clear();
		GameObject gameObject = base.transform.Find("Panel/ScrollView/Viewport/Content").gameObject;
		GameObject original = (GameObject)Resources.Load("Prefabs/Field/ItemBtn");
		GameObject gameObject2 = null;
		Dictionary<string, int> dictionary = new Dictionary<string, int>();
		foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(item.Key);
			if (row != null)
			{
				if (row.Use[7] == '1')
				{
					continue;
				}
				if ("999".Equals(item.Key))
				{
					dictionary.Add(item.Key, SharedData.Instance().m_Money);
				}
				else
				{
					if (item.Value <= 0)
					{
						continue;
					}
					switch (_sortType)
					{
					case 0:
						dictionary.Add(item.Key, item.Value);
						continue;
					case 1:
						if (row.Use[0] == '1')
						{
							dictionary.Add(item.Key, item.Value);
							continue;
						}
						break;
					}
					if (_sortType == 2 && row.Use[2] == '1')
					{
						dictionary.Add(item.Key, item.Value);
					}
					else if (_sortType == 3 && row.Use[3] == '1')
					{
						dictionary.Add(item.Key, item.Value);
					}
					else if (_sortType == 4 && row.Use[4] == '1')
					{
						dictionary.Add(item.Key, item.Value);
					}
					else if (_sortType == 5 && row.Use[8] == '1')
					{
						dictionary.Add(item.Key, item.Value);
					}
					else if (_sortType == 6 && row.Use[1] == '1')
					{
						dictionary.Add(item.Key, item.Value);
					}
				}
			}
			else
			{
				Debug.LogWarning("[3] !!! Can NOT found item.Key = " + item.Key);
			}
		}
		for (int i = 0; i < dictionary.Count; i++)
		{
			gameObject2 = Object.Instantiate(original, gameObject.transform);
			EventTriggerListener.Get(gameObject2).onClick = OnButtonClick;
			btnobjs.Add(gameObject2);
		}
		RectTransform component = gameObject.GetComponent<RectTransform>();
		Vector2 sizeDelta = component.sizeDelta;
		GridLayoutGroup component2 = gameObject.GetComponent<GridLayoutGroup>();
		int num = (int)((gameObject.GetComponent<RectTransform>().rect.width - (float)component2.padding.left - (float)component2.padding.right) / (component2.cellSize.x + component2.spacing.x));
		int num2 = dictionary.Count / num;
		num2 = ((num2 >= 5) ? num2 : 5);
		sizeDelta.y = 245f + (component2.cellSize.y + component2.spacing.y) * (float)num2;
		component.sizeDelta = sizeDelta;
		int num3 = num2 * num;
		for (int j = dictionary.Count; j < num3; j++)
		{
			gameObject2 = Object.Instantiate(original, gameObject.transform);
			EventTriggerListener.Get(gameObject2).onClick = OnButtonClick;
			btnobjs.Add(gameObject2);
		}
		SharedData.Instance().m_SubSelectedItem = "";
		int num4 = 0;
		foreach (KeyValuePair<string, int> item2 in SharedData.Instance().PlayerPackage)
		{
			if (!dictionary.ContainsKey(item2.Key))
			{
				continue;
			}
			InitPackageItem(btnobjs[num4], item2.Key, dictionary[item2.Key]);
			if ("".Equals(SharedData.Instance().m_SubSelectedItem))
			{
				SharedData.Instance().m_SubSelectedItem = item2.Key;
				SelectedBtn = btnobjs[num4];
				HoverWGController component3 = SelectedBtn.GetComponent<HoverWGController>();
				if (component3 != null)
				{
					component3.selected = true;
				}
				SelectedBtn.GetComponent<Image>().sprite = NormalSprite;
				UpdatePackageItemDetail(item2.Key);
			}
			else if (item2.Key.Equals(SharedData.Instance().m_SubSelectedItem))
			{
				SelectedBtn = btnobjs[num4];
				HoverWGController component4 = SelectedBtn.GetComponent<HoverWGController>();
				if (component4 != null)
				{
					component4.selected = true;
				}
				SelectedBtn.GetComponent<Image>().sprite = NormalSprite;
				UpdatePackageItemDetail(item2.Key);
			}
			num4++;
		}
		if (num4 == 0)
		{
			DetailBox.SetActive(value: false);
		}
	}

	private void InitPackageItem(GameObject _btn_obj, string _item_id, int _number)
	{
		_btn_obj.name = "Item|" + _item_id;
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_item_id);
		Button component = _btn_obj.GetComponent<Button>();
		component.interactable = true;
		component.transform.Find("Entity").gameObject.SetActive(value: true);
		component.transform.Find("Entity/Icon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(row.BookIcon);
		component.transform.Find("Entity/Num").GetComponent<Text>().text = _number.ToString() ?? "";
		if (SelectedList.Contains(_item_id))
		{
			_btn_obj.transform.Find(selectedName).gameObject.SetActive(value: true);
		}
		else
		{
			_btn_obj.transform.Find(selectedName).gameObject.SetActive(value: false);
		}
		if (row.Use[2] == '1' || row.Use[3] == '1' || row.Use[4] == '1' || row.Use[8] == '1')
		{
			_btn_obj.AddComponent<HoverWGController>();
		}
		if (row.Use[8] == '1')
		{
			gang_b03Table.Row row2 = CommonResourcesData.b03.Find_ID(row.Relateid);
			component.transform.Find("KFType").gameObject.SetActive(value: true);
			if (GameDataManager.Instance().configdata.language == "English")
			{
				component.transform.Find("KFType").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + row2.Style + "-item-EN", typeof(Sprite)) as Sprite;
				component.transform.Find("KFType/KFStar").GetComponent<Image>().sprite = Resources.Load("images/07-icon-equipInfo/" + row2.Star + "-star-item-EN", typeof(Sprite)) as Sprite;
			}
			else
			{
				component.transform.Find("KFType").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + row2.Style + "-item", typeof(Sprite)) as Sprite;
				component.transform.Find("KFType/KFStar").GetComponent<Image>().sprite = Resources.Load("images/07-icon-equipInfo/" + row2.Star + "-star-item", typeof(Sprite)) as Sprite;
			}
		}
	}

	private void UpdatePackageItemDetail(string _item_id)
	{
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_item_id);
		DetailBox.transform.Find("BG/Icon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(row.BookIcon);
		DetailBox.transform.Find("Name").GetComponent<Text>().text = row.Name_Trans;
		DetailBox.transform.Find("Description").GetComponent<Text>().text = row.note_Trans;
		if (SelectedList.Contains(_item_id))
		{
			UseBtn.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_CancelInherit");
			UseBtn.GetComponent<Button>().interactable = true;
		}
		else
		{
			UseBtn.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Inherit");
			UseBtn.GetComponent<Button>().interactable = SelectedList.Count < SharedData.Instance().m_InheritItemCount;
		}
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MonoBehaviour.print("[PackageMulti] Click button: " + go.name);
		string[] array = go.name.Split('|');
		if (array[0] == "Return")
		{
			ExitScene();
		}
		else if (array[0] == "Item")
		{
			if (SelectedBtn != null)
			{
				SelectedBtn.GetComponent<Image>().sprite = SelectedSprite;
			}
			HoverWGController component = SelectedBtn.GetComponent<HoverWGController>();
			if (component != null)
			{
				component.HoverDeselect(SelectedBtn);
			}
			SelectedBtn = go;
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(SelectedBtn));
			SelectedBtn.GetComponent<Image>().sprite = NormalSprite;
			UpdatePackageItemDetail(array[1]);
		}
		else if (array[0] == "Use")
		{
			string[] array2 = SelectedBtn.name.Split('|');
			if (SelectedList.Contains(array2[1]))
			{
				SelectedBtn.transform.Find(selectedName).gameObject.SetActive(value: false);
				SelectedList.Remove(array2[1]);
				UseBtn.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Inherit");
			}
			else
			{
				SelectedBtn.transform.Find(selectedName).gameObject.SetActive(value: true);
				SelectedList.Add(array2[1]);
				UseBtn.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_CancelInherit");
			}
			string text = topBannerTextTemplet.Replace("*#NUM#", (SharedData.Instance().m_InheritItemCount - SelectedList.Count).ToString());
			topBannerText.text = text;
			ReturnBtn.SetActive(SelectedList.Count > 0);
		}
		else if (array[0] == "Detail")
		{
			string[] array3 = SelectedBtn.name.Split('|');
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(array3[1]);
			if (row.Use[2] == '1' || row.Use[3] == '1' || row.Use[4] == '1')
			{
				SharedData.Instance().m_OpenDetail = row.ID + "|" + row.Relateid;
				SceneManager.LoadScene("Item", LoadSceneMode.Additive);
			}
			else if (row.Use[8] == '1')
			{
				SharedData.Instance().m_OpenDetail = row.Relateid;
				SceneManager.LoadScene("kongfu", LoadSceneMode.Additive);
			}
		}
	}

	private void ExitScene()
	{
		if (SelectedList.Count > 0)
		{
			GameDataManager.Instance().configdata.inheritItems = "";
			foreach (string selected in SelectedList)
			{
				if (GameDataManager.Instance().configdata.inheritItems.Length > 0)
				{
					GameDataManager.Instance().configdata.inheritItems += "&";
				}
				if ("999".Equals(selected))
				{
					ConfigData configdata = GameDataManager.Instance().configdata;
					configdata.inheritItems = configdata.inheritItems + selected + "|" + SharedData.Instance().m_Money;
				}
				else
				{
					ConfigData configdata2 = GameDataManager.Instance().configdata;
					configdata2.inheritItems = configdata2.inheritItems + selected + "|" + SharedData.Instance().PlayerPackage[selected];
				}
			}
			Debug.Log("GameDataManager.Instance().configdata.inheritItems = [" + GameDataManager.Instance().configdata.inheritItems + "]");
			GameDataManager.Instance().SaveConfig();
		}
		SharedData.Instance().LoadedSceneStack.Clear();
		SceneManager.UnloadSceneAsync("PackageMulti");
	}
}
