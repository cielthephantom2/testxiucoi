public enum BattleMenuState
{
	None,
	AutoBattleShow,
	CancelAutoBattleShow,
	WugongListShow
}
