using UnityEngine;

public static class ThroughoutSkillManage
{
	public static void ThroughoutSkill(BattleObject _origin, Vector3 _targetPos)
	{
		if (_origin.m_SkillRow.kf.Attckstyle.StartsWith("A|07"))
		{
			_origin.AdjustAnimationSpeed(0.1f, Color.white);
			_origin.transform.position = _targetPos;
		}
	}
}
