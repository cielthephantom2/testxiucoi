using UnityEngine;

public static class ImpactSkiiManage
{
	public static bool isAlreadImpact;

	public static void ImpactSkill(BattleObject _attacker, Vector3 _targetPos)
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(_targetPos.x / CommonVariables.MovementBlockSize);
		zero.y = Mathf.FloorToInt(Mathf.Abs(_targetPos.y) / CommonVariables.MovementBlockSize);
		if (!isAlreadImpact && KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "Impact") && SharedData.Instance().m_BattleController.obstacle.Contains(zero))
		{
			_attacker.transform.position = _targetPos;
		}
	}

	public static void ImpactSkill(BattleObject _attacker, BattleObject _defender, float injury)
	{
		Vector3Int gridPosition = _attacker.GetGridPosition();
		Vector3Int gridPosition2 = _defender.GetGridPosition();
		if (_defender.m_RealFendBackNumber >= 1)
		{
			int num = Mathf.Abs((gridPosition - gridPosition2).x) + Mathf.Abs((gridPosition - gridPosition2).y);
			int num2 = (int)(injury * 0.1f * (float)num);
			_defender.AddDamageInfo(((num2 < 1) ? 1 : num2).ToString(), "Impact");
			Vector3 position = new Vector3(25 + gridPosition2.x * 50, -25 - gridPosition2.y * 50, _attacker.gameObject.transform.position.z);
			_attacker.gameObject.transform.position = position;
			if (_attacker.charadata.GetBattleValueByName("TouTianHuanRi") > 0f)
			{
				SkillKeyWordManage.StealGainBuff(_attacker, _defender);
				SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Mad");
				SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Hurt");
				SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Poison");
				SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Bleed");
				SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Burn");
			}
		}
		else
		{
			Vector3 vector = Vector3.Normalize(gridPosition - gridPosition2);
			Vector3Int vector3Int = new Vector3Int((int)vector.x, (int)vector.y, 0);
			Vector3Int vector3Int2 = gridPosition2 + vector3Int;
			Vector3 position2 = new Vector3(25 + vector3Int2.x * 50, -25 - vector3Int2.y * 50, 0f);
			_attacker.gameObject.transform.position = position2;
			if (_defender.m_TotalFendBackNumber == 0)
			{
				int num3 = (int)(injury * 0.1f);
				_defender.AddDamageInfo(((num3 < 1) ? 1 : num3).ToString(), "DAMAGE|1");
				_attacker.BattleObjectBeHit();
			}
		}
	}
}
