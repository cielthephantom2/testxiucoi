internal enum CreatStage
{
	stage1,
	stage2,
	stage3
}
