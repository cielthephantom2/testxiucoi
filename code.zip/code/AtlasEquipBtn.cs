using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class AtlasEquipBtn : MonoBehaviour
{
	public AtlasEquipData atlasEquipData = new AtlasEquipData();

	public void Init(AtlasEquipData atlasEquip)
	{
		atlasEquipData = atlasEquip;
		EventTriggerListener.Get(base.gameObject).onClick = OnHoverButtonClick;
		base.transform.Find("Lable/LockIcon").GetComponent<Image>().color = (atlasEquipData.isUnlock ? Color.white : Color.black);
		base.transform.Find("Name/Text").GetComponent<Text>().text = (atlasEquipData.isUnlock ? atlasEquipData.b07Row.Name_Trans : "???");
		base.transform.Find("Lable/LockIcon").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(atlasEquipData.b07Row.BookIcon);
		string level = "";
		string level2 = "";
		List<string> list = CommonResourcesData.b10.Find_ID("10001").Members.Split("|").ToList();
		switch (atlasEquipData.b02Row.Style)
		{
		case "1":
			switch (atlasEquipData.b02Row.atlasType)
			{
			case "1":
				level = "Sword";
				break;
			case "2":
				level = "Knife";
				break;
			case "3":
				level = "Stick";
				break;
			case "4":
				level = "Hand";
				break;
			case "5":
				level = "OtherWeapon";
				break;
			}
			break;
		case "2":
			level = "Gear";
			break;
		case "3":
			level = "Accessory";
			break;
		}
		if (list.Contains(atlasEquipData.b02Row.ID))
		{
			level = "Top10";
		}
		string name_Trans = atlasEquipData.b07Row.Name_Trans;
		atlasEquipData.level1 = level;
		atlasEquipData.level2 = level2;
		atlasEquipData.level3 = name_Trans;
		base.gameObject.name = "Equip|" + atlasEquipData.b07Row.ID;
	}

	private void OnHoverButtonClick(GameObject go)
	{
		if (atlasEquipData.isUnlock && !CommonFunc.IsHoverOpen())
		{
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(go, showEquip: false, useCharaData: false));
		}
	}
}
