public enum TerrainType
{
	Hell,
	Water,
	FireLv1,
	PoisonLv1,
	FireLv2,
	PoisonLv2,
	FirePersistent,
	PoisonPersistent,
	TrapSeal,
	TrapBlast,
	UNKNOWN
}
