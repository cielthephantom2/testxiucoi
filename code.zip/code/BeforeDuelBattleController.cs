using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BeforeDuelBattleController : MonoBehaviour
{
	private const int MaxCount = 10;

	private Sprite AllyMaskSprit;

	private Sprite EnemyMaskSprit;

	private Transform DuelPanel;

	private Transform SelectPanel;

	private GameObject NormalReturn;

	private GameObject DuelPanelChooseOK;

	private GameObject SelectPanelChooseOK;

	private GameObject SelectAlliesBtn;

	private GameObject SelectEnemiesBtn;

	private Transform IconListAllies;

	private Transform IconListEnemies;

	private Text AlliesNumText;

	private Text EnemiesNumText;

	private Text SelectPanelInfoText;

	private List<string> AlliesList = new List<string>();

	private List<string> EnemiesList = new List<string>();

	private List<Button> buttonsTeamMate = new List<Button>();

	private List<Button> buttonsPokemon = new List<Button>();

	private bool isSelectAlly;

	private void Start()
	{
		AllyMaskSprit = Resources.Load("images/01-border/boder-20240326-01-mate", typeof(Sprite)) as Sprite;
		EnemyMaskSprit = Resources.Load("images/01-border/boder-20240326-01-Follower-OUT", typeof(Sprite)) as Sprite;
		DuelPanel = base.transform.Find("DuelPanel");
		SelectPanel = base.transform.Find("SelectPanel");
		NormalReturn = base.transform.Find("DuelPanel/Title/NormalReturn").gameObject;
		DuelPanelChooseOK = base.transform.Find("DuelPanel/DuelPanelChooseOK").gameObject;
		SelectPanelChooseOK = base.transform.Find("SelectPanel/SelectPanelChooseOK").gameObject;
		SelectAlliesBtn = base.transform.Find("DuelPanel/SelectAlliesBtn").gameObject;
		SelectEnemiesBtn = base.transform.Find("DuelPanel/SelectEnemiesBtn").gameObject;
		IconListAllies = base.transform.Find("DuelPanel/IconListAllies");
		IconListEnemies = base.transform.Find("DuelPanel/IconListEnemies");
		AlliesNumText = base.transform.Find("DuelPanel/AlliesInfo/Num").GetComponent<Text>();
		EnemiesNumText = base.transform.Find("DuelPanel/EnemiesInfo/Num").GetComponent<Text>();
		SelectPanelInfoText = SelectPanel.Find("Title/Text").GetComponent<Text>();
		Button[] componentsInChildren = GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		buttonsTeamMate = SelectPanel.GetComponentsInChildren<Button>().ToList().FindAll((Button x) => x.name.StartsWith("SelcetTeammate_"));
		buttonsPokemon = SelectPanel.GetComponentsInChildren<Button>().ToList().FindAll((Button x) => x.name.StartsWith("SelcetPokemon_"));
		InitSelectPanelCharacterArea();
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.ConfirmBattle.WasReleasedThisFrame())
		{
			if (DuelPanelChooseOK.activeInHierarchy)
			{
				ExecuteEvents.Execute(DuelPanelChooseOK, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
			else if (SelectPanelChooseOK.activeInHierarchy)
			{
				ExecuteEvents.Execute(SelectPanelChooseOK, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(NormalReturn, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.SelectDuelAlly.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(SelectAlliesBtn, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.SelectDuelEnemy.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(SelectEnemiesBtn, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		if (go.name == "NormalReturn")
		{
			SharedData.Instance().LoadedSceneStack.Remove("BeforeDuelBattle");
			SceneManager.UnloadSceneAsync("BeforeDuelBattle");
		}
		else if (go.name == "DuelPanelChooseOK")
		{
			if (AlliesList.Count == 0 || EnemiesList.Count == 0)
			{
				return;
			}
			SharedData.Instance().PlayerSetting.Clear();
			SharedData.Instance().EnemySetting.Clear();
			int num = 1;
			foreach (string allies in AlliesList)
			{
				SharedData.Instance().PlayerSetting.Add("Player" + num, allies);
				num++;
			}
			num = 1;
			foreach (string enemies in EnemiesList)
			{
				SharedData.Instance().EnemySetting.Add("Enemy" + num, enemies);
				num++;
			}
			SharedData.Instance().LoadedSceneStack.Clear();
			SharedData.Instance().ASyncLoadScene(SharedData.Instance().BattleGround);
		}
		else if (go.name == "SelectPanelChooseOK")
		{
			ChangePanel();
		}
		else if (go.name == "SelectAlliesBtn")
		{
			isSelectAlly = true;
			ChangePanel();
		}
		else if (go.name == "SelectEnemiesBtn")
		{
			isSelectAlly = false;
			ChangePanel();
		}
		else
		{
			if (!go.name.StartsWith("SelcetTeammate_") && !go.name.StartsWith("SelcetPokemon_"))
			{
				return;
			}
			string[] array = go.name.Split('|');
			if (array.Length < 4)
			{
				return;
			}
			if (isSelectAlly)
			{
				if (array[3] == "none" || array[3] == "enemy")
				{
					if (AlliesList.Count >= 10)
					{
						return;
					}
					go.name = array[0] + "|" + array[1] + "|" + array[2] + "|ally";
					go.transform.Find("AllyOrEnemy").gameObject.SetActive(value: true);
					go.transform.Find("AllyOrEnemy").GetComponent<Image>().sprite = AllyMaskSprit;
					AlliesList.Add(array[1]);
					EnemiesList.Remove(array[1]);
				}
				else
				{
					go.name = array[0] + "|" + array[1] + "|" + array[2] + "|none";
					go.transform.Find("AllyOrEnemy").gameObject.SetActive(value: false);
					AlliesList.Remove(array[1]);
				}
			}
			else if (array[3] == "none" || array[3] == "ally")
			{
				if (EnemiesList.Count >= 10)
				{
					return;
				}
				go.name = array[0] + "|" + array[1] + "|" + array[2] + "|enemy";
				go.transform.Find("AllyOrEnemy").gameObject.SetActive(value: true);
				go.transform.Find("AllyOrEnemy").GetComponent<Image>().sprite = EnemyMaskSprit;
				EnemiesList.Add(array[1]);
				AlliesList.Remove(array[1]);
			}
			else
			{
				go.name = array[0] + "|" + array[1] + "|" + array[2] + "|none";
				go.transform.Find("AllyOrEnemy").gameObject.SetActive(value: false);
				EnemiesList.Remove(array[1]);
			}
			if (isSelectAlly)
			{
				SelectPanelInfoText.text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Duel_Select_Ally_Info"), AlliesList.Count, 10);
			}
			else
			{
				SelectPanelInfoText.text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Duel_Select_Enemy_Info"), EnemiesList.Count, 10);
			}
		}
	}

	private void ChangePanel()
	{
		bool flag = !DuelPanel.gameObject.activeInHierarchy;
		if (flag)
		{
			InitDuelPanelIconList();
			EventSystem.current.SetSelectedGameObject(null);
		}
		else
		{
			RefreshSelectPanelCharacterArea();
			EventSystem.current.SetSelectedGameObject(SelectPanel.Find("CharacterArea/Viewport/Content").GetChild(0).gameObject);
		}
		DuelPanel.gameObject.SetActive(flag);
		DuelPanel.GetComponent<CanvasGroup>().interactable = flag;
		SelectPanel.gameObject.SetActive(!flag);
		SelectPanel.GetComponent<CanvasGroup>().interactable = !flag;
	}

	private void InitDuelPanelIconList()
	{
		for (int i = 1; i < 10; i++)
		{
			IconListAllies.Find($"Icon{i}BG/Icon").gameObject.SetActive(value: false);
			IconListEnemies.Find($"Icon{i}BG/Icon").gameObject.SetActive(value: false);
		}
		int num = 0;
		foreach (string allies in AlliesList)
		{
			num++;
			IconListAllies.Find($"Icon{num}BG/Icon").gameObject.SetActive(value: true);
			IconListAllies.Find($"Icon{num}BG/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(allies);
		}
		num = 0;
		foreach (string enemies in EnemiesList)
		{
			num++;
			IconListEnemies.Find($"Icon{num}BG/Icon").gameObject.SetActive(value: true);
			IconListEnemies.Find($"Icon{num}BG/Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(enemies);
		}
		AlliesNumText.text = AlliesList.Count + " / " + 10;
		EnemiesNumText.text = EnemiesList.Count + " / " + 10;
	}

	private void InitSelectPanelCharacterArea()
	{
		List<string> list = new List<string> { SharedData.Instance().playerid };
		gang_b10Table.Row row = CommonResourcesData.b10.Find_ID(SharedData.Instance().DuelBattleGuild);
		if (row != null)
		{
			list.AddRange(row.Members.Split("|").ToList());
		}
		foreach (string item in SharedData.Instance().FullTeam)
		{
			if (!list.Contains(item))
			{
				list.Add(item);
			}
		}
		int teammateCounts = 0;
		int pokemonCounts = 0;
		foreach (string item2 in list)
		{
			Button button = null;
			if (!item2.Contains('_'))
			{
				teammateCounts++;
				if (teammateCounts > 54)
				{
					continue;
				}
				button = buttonsTeamMate.Find((Button x) => x.name == "SelcetTeammate_" + teammateCounts);
			}
			else
			{
				pokemonCounts++;
				if (pokemonCounts > 18)
				{
					continue;
				}
				button = buttonsPokemon.Find((Button x) => x.name == "SelcetPokemon_" + pokemonCounts);
			}
			button.transform.Find("IconMask/IconBG").gameObject.SetActive(value: true);
			CharaData charaData = SharedData.Instance().GetCharaData(item2);
			Sprite tachieHead = CommonResourcesData.GetTachieHead(charaData.m_BattleIcon);
			if (tachieHead == null)
			{
				button.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: false);
				button.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
				button.transform.Find("IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charaData);
			}
			else
			{
				button.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: true);
				button.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
				button.transform.Find("IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
			}
			button.transform.Find("Name").gameObject.SetActive(value: true);
			button.transform.Find("Name").GetComponent<Text>().text = charaData.Indexs_Name["Name"].stringValue;
			button.transform.Find("Level").gameObject.SetActive(value: true);
			button.transform.Find("Level/Text").GetComponent<Text>().text = "LV." + charaData.m_Level;
			button.name = button.name + "|" + item2 + "|0|none";
		}
	}

	private void RefreshSelectPanelCharacterArea()
	{
		foreach (Button item in buttonsTeamMate)
		{
			item.transform.Find("AllyOrEnemy").gameObject.SetActive(value: false);
		}
		foreach (Button item2 in buttonsPokemon)
		{
			item2.transform.Find("AllyOrEnemy").gameObject.SetActive(value: false);
		}
		foreach (string id in AlliesList)
		{
			Button button = buttonsTeamMate.Find((Button x) => x.name.Split("|").Contains(id));
			if (button == null)
			{
				button = buttonsPokemon.Find((Button x) => x.name.Split("|").Contains(id));
			}
			if (button != null)
			{
				button.transform.Find("AllyOrEnemy").gameObject.SetActive(value: true);
				button.transform.Find("AllyOrEnemy").GetComponent<Image>().sprite = AllyMaskSprit;
			}
		}
		foreach (string id in EnemiesList)
		{
			Button button2 = buttonsTeamMate.Find((Button x) => x.name.Split("|").Contains(id));
			if (button2 == null)
			{
				button2 = buttonsPokemon.Find((Button x) => x.name.Split("|").Contains(id));
			}
			if (button2 != null)
			{
				button2.transform.Find("AllyOrEnemy").gameObject.SetActive(value: true);
				button2.transform.Find("AllyOrEnemy").GetComponent<Image>().sprite = EnemyMaskSprit;
			}
		}
		if (isSelectAlly)
		{
			SelectPanelInfoText.text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Duel_Select_Ally_Info"), AlliesList.Count, 10);
		}
		else
		{
			SelectPanelInfoText.text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Duel_Select_Enemy_Info"), EnemiesList.Count, 10);
		}
	}
}
