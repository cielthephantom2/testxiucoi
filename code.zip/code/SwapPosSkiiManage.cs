using System.Collections.Generic;
using UnityEngine;

public static class SwapPosSkiiManage
{
	private static bool isAlreadSwap;

	public static void SwapPosSkill(BattleObject _origin, BattleObject _target)
	{
		isAlreadSwap = true;
		if (Random.Range(0f, 1f) < GetSwapPosRate(_origin, _target) || _origin.race == _target.race)
		{
			Vector3 position = _origin.transform.position;
			Vector3 position2 = _target.transform.position;
			_origin.transform.position = position2;
			_target.transform.position = position;
		}
	}

	public static void SwapPosSkill(BattleObject _origin, Vector3 _targetPos)
	{
		if (!isAlreadSwap && KongFuCommomFunc.CheckWugongHaveEffect(_origin.m_SkillRow.kf, "SwapPos"))
		{
			_origin.transform.position = _targetPos;
		}
		isAlreadSwap = false;
	}

	public static float GetSwapPosRate(BattleObject _attacker, BattleObject _defender)
	{
		if (SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race != _attacker.race).Contains(_defender))
		{
			return 1f;
		}
		foreach (KeyValuePair<string, string> item in _defender.charadata.m_EquipTraitDict)
		{
			if (!(item.Value == ""))
			{
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.Value);
				if ("Fendresist" == row.add1 || "Fendresist" == row.add2 || "Fendresist" == row.add3 || "Fendresist" == row.add4)
				{
					return 0f;
				}
			}
		}
		if (_defender.charadata.m_currentTitleID != "")
		{
			gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(_defender.charadata.m_currentTitleID);
			if ("Fendresist" == row2.add1 || "Fendresist" == row2.add2 || "Fendresist" == row2.add3 || "Fendresist" == row2.add4)
			{
				return 0f;
			}
		}
		SkillInfo skillInfo = new SkillInfo();
		skillInfo.Init(_attacker.m_SkillRow, _attacker);
		int num = (int)_defender.charadata.GetBattleValueByName("Fend");
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			if (skillInfo.sName[i].Equals("SwapPos") && skillInfo.sValueNum[i] >= (float)num)
			{
				return skillInfo.sValueNum[i] * skillInfo.sValueNum[i] / 6f / (float)(num * num) + 1f / 3f;
			}
		}
		return 0f;
	}
}
