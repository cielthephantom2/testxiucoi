using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GuideController : MonoBehaviour
{
	public Text m_TitleText;

	public Image m_GuideImage;

	public Text m_GuideText;

	public GameObject m_Spot2;

	public GameObject m_Spot3;

	public GameObject m_Spot5;

	public Sprite m_SpotOn;

	public Sprite m_SpotOff;

	public GameObject m_ExitButton;

	private Image[] Spots;

	private int pageno;

	private bool readonce;

	private List<Sprite> guideImages = new List<Sprite>();

	private List<string> guideTexts = new List<string>();

	private MapController mapcontroller;

	private bool isInitOK;

	private void Start()
	{
		Init();
		isInitOK = true;
	}

	private void OnEnable()
	{
		if (!isInitOK)
		{
			return;
		}
		pageno = 0;
		readonce = false;
		guideImages.Clear();
		guideTexts.Clear();
		Init();
		for (int i = 0; i < Spots.Length; i++)
		{
			if (pageno == i)
			{
				Spots[i].sprite = m_SpotOn;
			}
			else
			{
				Spots[i].sprite = m_SpotOff;
			}
		}
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			if (readonce)
			{
				OnTrueExit();
			}
		}
		else if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			OnBackClick();
		}
	}

	private void Init()
	{
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
		m_ExitButton.SetActive(value: false);
		InputSystemCustom.Instance().UI.Enable();
		switch (SharedData.Instance().Guide_Page_Lic)
		{
		case "EQUIP":
			m_Spot2.SetActive(value: false);
			m_Spot3.SetActive(value: true);
			Spots = m_Spot3.transform.GetComponentsInChildren<Image>();
			m_Spot5.SetActive(value: false);
			m_TitleText.text = CommonFunc.I18nGetLocalizedValue("I18N_Guide_Howto_Equip");
			guideImages.Add(Resources.Load("images/96-Guide/Guide-01-zhuangbei-01", typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-01-zhuangbei-02" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-01-zhuangbei-03" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			m_GuideImage.sprite = guideImages[pageno];
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Equip_Step1"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Equip_Step2"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Equip_Step3"));
			m_GuideText.text = guideTexts[pageno];
			break;
		case "LEARN":
			m_Spot2.SetActive(value: false);
			m_Spot3.SetActive(value: false);
			m_Spot5.SetActive(value: true);
			Spots = m_Spot5.transform.GetComponentsInChildren<Image>();
			m_TitleText.text = CommonFunc.I18nGetLocalizedValue("I18N_Guide_Howto_Learn");
			guideImages.Add(Resources.Load("images/96-Guide/Guide-01-zhuangbei-01", typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-02-wugong-01" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-02-wugong-02" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-02-wugong-03" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-02-wugong-04" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			m_GuideImage.sprite = guideImages[pageno];
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Equip_Step1"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Learn_Step2"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Learn_Step3"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Learn_Step4"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Learn_Step5"));
			m_GuideText.text = guideTexts[pageno];
			break;
		case "TALENT":
			m_Spot2.SetActive(value: true);
			Spots = m_Spot2.transform.GetComponentsInChildren<Image>();
			m_Spot3.SetActive(value: false);
			m_Spot5.SetActive(value: false);
			m_TitleText.text = CommonFunc.I18nGetLocalizedValue("I18N_Guide_Howto_Talent");
			guideImages.Add(Resources.Load("images/96-Guide/Guide-01-zhuangbei-01", typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-03-shuxing-01" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			m_GuideImage.sprite = guideImages[pageno];
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Equip_Step1"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Talent_Step2"));
			m_GuideText.text = guideTexts[pageno];
			break;
		case "HEARSAY":
			m_Spot2.SetActive(value: true);
			Spots = m_Spot2.transform.GetComponentsInChildren<Image>();
			m_Spot3.SetActive(value: false);
			m_Spot5.SetActive(value: false);
			m_TitleText.text = CommonFunc.I18nGetLocalizedValue("I18N_Guide_Howto_Hearsay");
			guideImages.Add(Resources.Load("images/96-Guide/Guide-05-chuanwen-01" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-05-chuanwen-02" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			m_GuideImage.sprite = guideImages[pageno];
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Hearsay_Step1"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Hearsay_Step2"));
			m_GuideText.text = guideTexts[pageno];
			break;
		case "MAP":
			m_Spot2.SetActive(value: true);
			Spots = m_Spot2.transform.GetComponentsInChildren<Image>();
			m_Spot3.SetActive(value: false);
			m_Spot5.SetActive(value: false);
			m_TitleText.text = CommonFunc.I18nGetLocalizedValue("I18N_Guide_Howto_Map");
			guideImages.Add(Resources.Load("images/96-Guide/Guide-04-ditu-01" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			guideImages.Add(Resources.Load("images/96-Guide/Guide-04-ditu-02" + CommonFunc.ShortLangSel("", "-en"), typeof(Sprite)) as Sprite);
			m_GuideImage.sprite = guideImages[pageno];
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Map_Step1"));
			guideTexts.Add(CommonFunc.I18nGetLocalizedValue("I18N_Guide_Map_Step2"));
			m_GuideText.text = guideTexts[pageno];
			break;
		}
	}

	public void OnTrueExit()
	{
		mapcontroller.EventComplete(mapcontroller.m_Canvas_Event);
		mapcontroller.m_LastClick = true;
	}

	public void OnBackClick()
	{
		if (++pageno >= Spots.Length)
		{
			pageno = 0;
		}
		if (!readonce && pageno == Spots.Length - 1)
		{
			m_ExitButton.SetActive(value: true);
			readonce = true;
		}
		m_GuideImage.sprite = guideImages[pageno];
		m_GuideText.text = guideTexts[pageno];
		for (int i = 0; i < Spots.Length; i++)
		{
			if (pageno == i)
			{
				Spots[i].sprite = m_SpotOn;
			}
			else
			{
				Spots[i].sprite = m_SpotOff;
			}
		}
	}
}
