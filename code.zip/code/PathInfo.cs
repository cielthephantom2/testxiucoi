using UnityEngine;

public class PathInfo
{
	public string mapID;

	public Vector2 Pos;

	public PathInfo(string _map, Vector2 _pos)
	{
		mapID = _map;
		Pos = _pos;
	}
}
