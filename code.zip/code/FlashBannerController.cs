using System.Collections;
using UnityEngine;

public class FlashBannerController : MonoBehaviour
{
	public float showTime = 1f;

	private void Start()
	{
	}

	public void Show()
	{
		if (!base.gameObject.activeInHierarchy)
		{
			base.gameObject.SetActive(value: true);
		}
		StartCoroutine(Show_Callback(showTime));
	}

	protected IEnumerator Show_Callback(float _time)
	{
		yield return new WaitForSeconds(_time);
		base.gameObject.SetActive(value: false);
	}
}
