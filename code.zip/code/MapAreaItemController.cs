using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class MapAreaItemController : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	private bool isInArea;

	private Color normalColor = new Color(14f / 51f, 0.21960784f, 0.17254902f, 1f);

	private Color selectedColor = new Color(1f, 0.8862745f, 0.64705884f, 1f);

	private Text text;

	public Transform MapIcon;

	private void Start()
	{
		text = base.transform.Find("Text").GetComponent<Text>();
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		OnEnter();
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		OnExit();
	}

	public void OnEnter(bool isCallBySelf = true)
	{
		if (!Input.GetMouseButton(0))
		{
			isInArea = true;
			GetComponent<Image>().enabled = true;
			if (isCallBySelf)
			{
				SharedData.Instance().m_MapViewController.MapImage.transform.DOLocalMove(-MapIcon.localPosition, 1f);
			}
			text.color = selectedColor;
			base.transform.Find("Icon").gameObject.SetActive(value: true);
		}
	}

	public void OnExit(bool isCallBySelf = true)
	{
		if (isInArea)
		{
			isInArea = false;
			GetComponent<Image>().enabled = false;
			text.color = normalColor;
			base.transform.Find("Icon").gameObject.SetActive(value: false);
		}
	}
}
