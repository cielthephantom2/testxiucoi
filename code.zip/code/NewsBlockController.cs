using UnityEngine;

public class NewsBlockController : MonoBehaviour
{
	private void Start()
	{
		EventTriggerListener.Get(base.gameObject).onClick = OnButtonClick;
	}

	private void Update()
	{
	}

	public void OnButtonClick(GameObject go)
	{
	}
}
