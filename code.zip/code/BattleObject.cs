using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using DG.Tweening;
using MessagePack;
using Spine;
using Spine.Unity;
using Spine.Unity.Examples;
using SuperTiled2Unity;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleObject : MonoBehaviour
{
	public int gameObjID;

	private string aniname_attack = "";

	private float m_DisplayDamageMark = float.MinValue;

	private float m_DisplayBuffMark = float.MinValue;

	public GameObject m_orderInfo;

	public GameObject enemy_marker;

	public GameObject player_marker;

	public GameObject m_HeadMarker;

	private SpineGauge hp_gauge;

	[HideInInspector]
	public BattleObjectAudioManager m_BattleObjectAudioManager = new BattleObjectAudioManager();

	[HideInInspector]
	public SkeletonAnimation[] m_Animations;

	[HideInInspector]
	public MeshRenderer[] m_MeshRenderer;

	public Vector3Int handInPos = Vector3Int.zero;

	public Vector3Int curPos = Vector3Int.zero;

	public bool isPerforming;

	private BattleObjectState m_Next_State = BattleObjectState.None;

	private BattleControllerFlow m_Next_battleControllerFlow = BattleControllerFlow.None;

	public int m_FinalAddExp;

	public KongFuData m_SkillRow;

	private List<ItemController> breakItems = new List<ItemController>();

	private int m_BuffCount;

	public Dictionary<Vector3Int, int> unitRange = new Dictionary<Vector3Int, int>();

	public Dictionary<Vector3Int, int> AttackForecastRange = new Dictionary<Vector3Int, int>();

	public Dictionary<Vector3Int, int> standPosList = new Dictionary<Vector3Int, int>();

	public List<Vector3Int> attackRange = new List<Vector3Int>();

	public List<Vector3Int> attackSelectRange = new List<Vector3Int>();

	public Dictionary<Vector3Int, List<Forecast>> AttackForecastDict = new Dictionary<Vector3Int, List<Forecast>>();

	private AutoBattleData m_AutoBattleData = new AutoBattleData();

	public List<string> m_SkillList = new List<string>();

	public bool m_MpBroken;

	public bool m_couldAttack;

	public bool m_couldHealHp;

	public bool m_couldHealNegativeBuff;

	public bool m_couldAddBuff;

	public bool m_couldEscape;

	public bool m_couldSwapPos;

	public string[] m_AttackType;

	public List<BattleObject> attackObjs = new List<BattleObject>();

	[HideInInspector]
	public int m_TotalFendBackNumber;

	[HideInInspector]
	public int m_RealFendBackNumber;

	[HideInInspector]
	public float stealhptotal;

	[HideInInspector]
	public float stealmptotal;

	[HideInInspector]
	public float madselftotal;

	[HideInInspector]
	public Dictionary<BattleObject, string> m_StealSuccess = new Dictionary<BattleObject, string>();

	private Dictionary<KongFuData, float> counterWugongList = new Dictionary<KongFuData, float>();

	public KongFuData counterWugong = new KongFuData();

	[HideInInspector]
	public Vector3Int m_attackPos = Vector3Int.zero;

	[HideInInspector]
	public int AlreadyAttackObjCount;

	private float m_ComboRate;

	public bool InitOK;

	public BattleController m_BattleController;

	public MenuController m_MenuController;

	public string tileName = "";

	public string m_AiType = "2|0|10005";

	public string sex = "0";

	public int m_DefeatExp;

	public string m_LastSelectedAtkBtnName = "";

	public RebellionType rebellionType;

	public int rebellionRoundNumber;

	public bool prevRoundIsHeal;

	[HideInInspector]
	public int ComboCount;

	public bool IsCharaInitShowRangeRunning;

	public bool m_NoZOC;

	public bool BurnResist;

	public bool PoisonResist;

	public bool TrapResist;

	public bool mad;

	public BuffData SpitBuff;

	public bool isSpitObjDead = true;

	public bool isBlind;

	public int beAttackSide;

	private SuperObject superObject;

	public List<gang_c04Table.Row> m_StealableItemsName = new List<gang_c04Table.Row>();

	public List<int> m_StealableItemsNum = new List<int>();

	public List<gang_c04Table.Row> m_mustDropItemsName = new List<gang_c04Table.Row>();

	public List<int> m_mustDropItemsNum = new List<int>();

	public string race = "";

	private bool _isDead;

	public bool isEscape;

	public bool isUnSealNextRound;

	public CharaData charadata;

	public BattleObjectState m_State;

	[HideInInspector]
	public List<BuffData> m_Buffs = new List<BuffData>();

	public int aliveRoundNumber = int.MaxValue;

	public bool isSealFreeze;

	public Direction m_Direction;

	public bool isInvisible;

	public bool isSelectable = true;

	public BattleObject m_Revenge_Target;

	public List<DisplayDamage> m_DamageList = new List<DisplayDamage>();

	public List<DisplayBuff> m_BuffList = new List<DisplayBuff>();

	private Dictionary<string, GameObject> m_EffectOnList = new Dictionary<string, GameObject>();

	public List<Vector3Int> targetGridList = new List<Vector3Int>();

	public Forecast currentForecast;

	public string m_Assist_Skill = "";

	public Vector3Int m_Assist_Pos = Vector3Int.zero;

	public bool isBeEffectInMovingStage;

	[HideInInspector]
	public bool isPokemon;

	public bool isDead
	{
		get
		{
			if (_isDead || isEscape)
			{
				if (GetBuffByName("TurtleBreath") != null)
				{
					return GetBuffByName("TurtleBreath").turn < 1;
				}
				return true;
			}
			return false;
		}
		set
		{
			_isDead = value;
			if (_isDead)
			{
				SkeletonAnimation[] animations = m_Animations;
				for (int i = 0; i < animations.Length; i++)
				{
					animations[i].GetComponent<MeshRenderer>().sortingOrder = m_BattleController.m_DynamicLayer_SortingOrder - 1;
					AdjustAnimationSpeed(1f, Color.gray);
				}
				if (m_BattleController.current.Equals(this) || m_State.Equals(BattleObjectState.Action))
				{
					m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
					m_BattleController.current.SetBattleObjState(BattleObjectState.RoundOff);
				}
			}
		}
	}

	public void InitCharacter(string _race, SuperObject _superObject, CharaData charaData)
	{
		superObject = _superObject;
		gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(charaData.m_Id);
		race = _race;
		sex = row.Sex;
		charadata = charaData;
		charadata.originRace = _race;
		charadata.m_Buffs = m_Buffs;
		tileName = _superObject.m_TiledName;
		base.name = _superObject.m_TiledName + "-" + charaData.m_Prefab;
		if (row.AiType == "0")
		{
			m_AiType = "2|0|10005";
		}
		else
		{
			m_AiType = row.AiType;
		}
		m_DefeatExp = 50;
		charadata.CleanFightValues();
		int direction = 0;
		foreach (CustomProperty property in _superObject.GetComponent<SuperCustomProperties>().m_Properties)
		{
			if (property.m_Name == "direction")
			{
				direction = int.Parse(property.m_Value);
			}
		}
		AdjustFace(direction);
	}

	public void InitCharacter(string _race, SuperObject _superObject, gang_b04Table.Row _b04Row)
	{
		superObject = _superObject;
		if ("0".Equals(_b04Row.SetData))
		{
			charadata = new CharaData();
			charadata.Init(_b04Row);
		}
		else if ("playerdata".Equals(_b04Row.SetData))
		{
			charadata = new CharaData();
			charadata.Init(_b04Row);
			CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
			byte[] array = MessagePackSerializer.Serialize(charaData._CharaDataBasic);
			charadata._CharaDataBasic = MessagePackSerializer.Deserialize<CharaDataBasic>(array);
			foreach (KeyValuePair<string, AtomData> item in charadata._CharaDataBasic.Indexs_Name)
			{
				item.Value._charaData = charadata;
			}
			charadata.m_KongFuList.Clear();
			charadata.m_KongFuList.AddRange(charaData.m_KongFuList);
			charadata.m_KongFuListInBattle.Clear();
			charadata.m_KongFuListInBattle.AddRange(charaData.m_KongFuListInBattle);
			charadata.Indexs_Name.Clear();
			foreach (KeyValuePair<string, AtomData> item2 in charaData.Indexs_Name)
			{
				charadata.Indexs_Name.Add(item2.Key, item2.Value);
			}
		}
		else
		{
			charadata = SharedData.Instance().GetCharaData(_b04Row.SetData);
		}
		race = _race;
		sex = _b04Row.Sex;
		charadata.originRace = _race;
		charadata.m_Buffs = m_Buffs;
		tileName = _superObject.m_TiledName;
		base.name = _superObject.m_TiledName + "-" + charadata.m_Prefab;
		if (_b04Row.AiType == "0")
		{
			m_AiType = "2|0|10005";
		}
		else
		{
			m_AiType = _b04Row.AiType;
		}
		m_DefeatExp = Mathf.CeilToInt(float.Parse(_b04Row.EXP, CultureInfo.InvariantCulture) * SharedData.Instance().m_Enemy_EXP_Rate);
		int direction = 0;
		foreach (CustomProperty property in _superObject.GetComponent<SuperCustomProperties>().m_Properties)
		{
			if (property.m_Name == "direction")
			{
				direction = int.Parse(property.m_Value);
			}
		}
		AdjustFace(direction);
		charadata.GetBattleValueByName("HP");
		charadata.GetBattleValueByName("MP");
		charadata.CleanFightValues();
	}

	public void InitSummonCharacter(string _id, string _race, int _aliveRoundNumber = int.MaxValue)
	{
		string text = (DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, 0)).Ticks.ToString();
		gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(_id);
		CharaData charaData = new CharaData();
		charaData.Init(row);
		charadata = charaData;
		race = _race;
		sex = row.Sex;
		charadata.originRace = _race;
		charadata.m_Buffs = m_Buffs;
		tileName = "";
		base.name = "Summon" + text + "-" + charaData.m_Prefab;
		aliveRoundNumber = _aliveRoundNumber;
		if (row.AiType == "0")
		{
			m_AiType = "2|0|10005";
		}
		else
		{
			m_AiType = row.AiType;
		}
		charadata.CleanFightValues();
		Face(m_BattleController.current.m_Direction, isInit: true);
	}

	protected void Awake()
	{
		m_BattleController = GameObject.Find("Camera").GetComponent<BattleController>();
		m_MenuController = m_BattleController.canvas.GetComponent<MenuController>();
		m_Animations = base.gameObject.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		SkeletonAnimation[] animations = m_Animations;
		for (int i = 0; i < animations.Length; i++)
		{
			animations[i].GetComponent<MeshRenderer>().sortingOrder = m_BattleController.m_DynamicLayer_SortingOrder;
		}
		for (int j = 0; j < 3; j++)
		{
			m_Animations[j].AnimationState.Event += State_Event;
			m_Animations[j].AnimationState.Complete += State_Complete;
		}
		GameObject gameObject = (GameObject)Resources.Load("Prefabs/Character/HeadMarker");
		if (gameObject != null)
		{
			m_HeadMarker = UnityEngine.Object.Instantiate(gameObject, base.transform);
		}
		enemy_marker = UnityEngine.Object.Instantiate(CommonResourcesData.EnemyMarkerPrefab, base.transform);
		player_marker = UnityEngine.Object.Instantiate(CommonResourcesData.PlayerMarkerPrefab, base.transform);
		m_HeadMarker.SetActive(value: false);
		m_MeshRenderer = base.gameObject.GetComponentsInChildren<MeshRenderer>(includeInactive: true);
	}

	private void Start()
	{
		InitCharacterCommon();
		gameObjID = GetInstanceID();
	}

	private void InitCharacterCommon()
	{
		base.transform.Find("hp_" + race).gameObject.SetActive(value: true);
		base.transform.Find("hp_" + race).GetComponent<MeshRenderer>().sortingOrder = m_BattleController.m_DynamicLayer_SortingOrder + 1;
		hp_gauge = base.transform.Find("hp_" + race).GetComponent<SpineGauge>();
		hp_gauge.fillPercent = 1f;
		hp_gauge.gameObject.SetActive(value: false);
		if (superObject != null)
		{
			Vector2 vector = superObject.transform.position;
			vector.x = Mathf.FloorToInt(vector.x / CommonVariables.MovementBlockSize) * (int)CommonVariables.MovementBlockSize + (int)(CommonVariables.MovementBlockSize * 0.5f);
			vector.y = Mathf.FloorToInt(vector.y / CommonVariables.MovementBlockSize) * (int)CommonVariables.MovementBlockSize + (int)(CommonVariables.MovementBlockSize * 0.5f);
			base.gameObject.transform.localPosition = vector;
		}
		if (race == "enemy")
		{
			InitStealable();
			InitMustDropID();
		}
		m_BattleObjectAudioManager.Init(this);
		foreach (string item in charadata.m_KongFuListInBattle)
		{
			foreach (KongFuData kongFu in charadata.m_KongFuList)
			{
				if (kongFu.kf.ID.Equals(item))
				{
					m_SkillList.Add(kongFu.kf.ID + "|" + kongFu.kf.Attckstyle + "|" + kongFu.lv + "|MP-GOOD");
					break;
				}
			}
		}
		enemy_marker.GetComponent<SkeletonAnimation>().GetComponent<MeshRenderer>().sortingOrder = ((m_BattleController.m_underfoot_SortingOrder > 0) ? m_BattleController.m_underfoot_SortingOrder : 0);
		player_marker.GetComponent<SkeletonAnimation>().GetComponent<MeshRenderer>().sortingOrder = ((m_BattleController.m_underfoot_SortingOrder > 0) ? m_BattleController.m_underfoot_SortingOrder : 0);
		enemy_marker.SetActive(value: false);
		player_marker.SetActive(value: false);
		if (race == "player")
		{
			player_marker.SetActive(value: true);
		}
		else
		{
			enemy_marker.SetActive(value: true);
		}
		SkillTraitEquipManager.RunEquipSkill(this, this, 0f, isSelf: true, isInitCharacter: true);
		SkillTraitEquipManager.RunTraitSkill(this, this, 0f, isSelf: true, isInitCharacter: true);
		AddEffectOn();
		PlayAnimation(Aniname.aniname_stand);
		RefreshSomeCalRangeInfo();
		InitOK = true;
	}

	public void RefreshSomeCalRangeInfo()
	{
		m_NoZOC = charadata.GetBattleValueByName("NoZOC") > 0f;
		BurnResist = charadata.GetBattleValueByName("Burnresist") > 0f;
		PoisonResist = charadata.GetBattleValueByName("Poisonresist") > 0f;
		TrapResist = charadata.GetBattleValueByName("Trapresist") > 0f;
		mad = charadata.GetBattleValueByName("Mad") >= 25f;
		SpitBuff = GetBuffByName("Spit");
		isSpitObjDead = true;
		if (SpitBuff != null)
		{
			isSpitObjDead = SharedData.Instance().m_BattleController.allBattleObjs.Find((BattleObject x) => x.name == SpitBuff.source.Split("|")[2]).isDead;
		}
		isBlind = CheckBuffEffectOn("Blind");
	}

	private void State_Event(TrackEntry trackEntry, Spine.Event e)
	{
		string[] array = trackEntry.Animation.Name.Split('-');
		if ("attack".Equals(array[1]) && "behit".Equals(e.Data.Name))
		{
			RangeManager.ClearAllRange();
			if ("ITEM".Equals(m_AttackType[0]) && SharedData.Instance().useItemID != "")
			{
				gang_b07Table.Row b07row = CommonResourcesData.b07.Find_ID(SharedData.Instance().useItemID);
				if (attackObjs.Count > 0)
				{
					PlayAudioClip(AudioClipEnum.heal1Clip);
					foreach (BattleObject attackObj in attackObjs)
					{
						SkillTraitEquipManager.UseItemInBattle(b07row, this, attackObj);
						if (!(m_AttackType[1] == "C") || !(attackObj == this))
						{
							attackObj.AdjustFace(GetGridPosition());
						}
					}
				}
				foreach (Vector3Int item in attackSelectRange)
				{
					TerrainManagerClass.RunCreatTerrainItem(b07row, item);
				}
				SetBattleObjState(BattleObjectState.ActionOver);
			}
			else
			{
				m_BattleController.m_BattleInterBG.DOFade(0.4f, 0.2f);
				StartCoroutine(PlayEffectAll());
			}
		}
		else if ("behit".Equals(array[1]) && "seal".Equals(e.Data.Name) && charadata.GetBattleValueByName("Seal") >= 25f && !isSealFreeze)
		{
			SealFreeze();
			InteruptIn(BattleObjectState.HandOut);
		}
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		if (trackEntry.Animation.Name == "B01-attack-sword")
		{
			PlayAnimation("C01-attackstand-sword");
		}
		else if (trackEntry.Animation.Name == "B02-attack-knife")
		{
			PlayAnimation("C02-attackstand-knife");
		}
		else if (trackEntry.Animation.Name == "B03-attack-stick")
		{
			PlayAnimation("C03-attackstand-stick");
		}
		else if (trackEntry.Animation.Name == "B05-attack-finger")
		{
			PlayAnimation("C05-attackstand-finger");
		}
		else if (trackEntry.Animation.Name == "B06-attack-heart")
		{
			PlayAnimation("C06-attackstand-heart");
		}
		else if (trackEntry.Animation.Name == "B04-attack-hand")
		{
			PlayAnimation("C04-attackstand-hand");
			if ("ITEM".Equals(m_AttackType[0]))
			{
				if (SharedData.Instance().useItemID != "")
				{
					SharedData.Instance().PackageAdd(SharedData.Instance().useItemID, -1);
				}
			}
			else if ("601".Equals(m_SkillRow.kf.Style))
			{
				if (SharedData.Instance().m_MoneyForAttack != 0f && ("13012".Equals(m_SkillRow.kf.ID) || "99036".Equals(m_SkillRow.kf.ID)))
				{
					SharedData.Instance().m_Money -= Mathf.RoundToInt(SharedData.Instance().m_MoneyForAttack);
					if (SharedData.Instance().m_Money < 0)
					{
						SharedData.Instance().m_Money = 0;
					}
				}
				else if (SharedData.Instance().useItemID != "")
				{
					if ("999".Equals(SharedData.Instance().useItemID))
					{
						SharedData.Instance().m_Money--;
						if (SharedData.Instance().m_Money <= 0)
						{
							SharedData.Instance().m_Money = 0;
						}
					}
					else
					{
						SharedData.Instance().PackageAdd(SharedData.Instance().useItemID, -1);
					}
				}
			}
		}
		else if (trackEntry.Animation.Name == Aniname.aniname_behit)
		{
			PlayAnimation(Aniname.aniname_stand, loop: true, compensate: false);
			StartCoroutine(BehitFinal());
		}
		else if (trackEntry.Animation.Name == Aniname.aniname_die)
		{
			isDead = true;
		}
		if (trackEntry.Animation.Name.Contains("-attack-") || trackEntry.Animation.Name == Aniname.aniname_behit || trackEntry.Animation.Name == Aniname.aniname_die)
		{
			isPerforming = false;
		}
	}

	public IEnumerator PlayEffectAll()
	{
		m_BattleController.isPlayEffectFinish = false;
		GameObject prefab = (GameObject)Resources.Load("Prefabs/Effect/Skills/" + m_SkillRow.kf.Effect);
		Vector3Int m_EffectPos = m_attackPos;
		List<Vector3Int> list = new List<Vector3Int>();
		List<float> list2 = new List<float>();
		if (int.Parse(m_SkillRow.kf.DelayedattackType) == 0)
		{
			foreach (Vector3Int item in attackSelectRange)
			{
				list.Add(item);
				list2.Add(0f);
			}
		}
		else
		{
			if (Mathf.Abs(int.Parse(m_SkillRow.kf.DelayedattackType)) == 1)
			{
				m_EffectPos = GetGridPosition();
			}
			else
			{
				Mathf.Abs(int.Parse(m_SkillRow.kf.DelayedattackType));
			}
			foreach (Vector3Int item2 in attackSelectRange)
			{
				float num = Mathf.Abs(item2.x - m_EffectPos.x) + Mathf.Abs(item2.y - m_EffectPos.y);
				if (list2.Count == 0)
				{
					list2.Add(num);
					list.Add(item2);
					continue;
				}
				if (num <= list2[0])
				{
					list2.Insert(0, num);
					list.Insert(0, item2);
					continue;
				}
				if (num >= list2[list2.Count - 1])
				{
					list2.Add(num);
					list.Add(item2);
					continue;
				}
				for (int i = 0; i < list2.Count; i++)
				{
					if (num >= list2[i] && num <= list2[i + 1])
					{
						list2.Insert(i + 1, num);
						list.Insert(i + 1, item2);
						break;
					}
				}
			}
		}
		float attackDis = 0f;
		if (int.Parse(m_SkillRow.kf.DelayedattackType) < 0)
		{
			attackDis = ((list2.Count > 0) ? list2[list2.Count - 1] : 0f);
			list.Reverse();
		}
		else if (int.Parse(m_SkillRow.kf.DelayedattackType) > 0)
		{
			attackDis = ((list2.Count > 0) ? list2[0] : 0f);
		}
		int decreaseLevel = 0;
		int attackObjNum = 0;
		int snakeflag = 1;
		AlreadyAttackObjCount = 0;
		if (charadata.originRace == "player" && race == "player")
		{
			_ = attackObjs.Count;
			if (attackObjs.Count > 0)
			{
				int.Parse(m_SkillRow.kf.Beat);
			}
		}
		foreach (Vector3Int pos in list)
		{
			float num2 = Mathf.Abs(pos.x - m_EffectPos.x) + Mathf.Abs(pos.y - m_EffectPos.y);
			if (num2 != attackDis)
			{
				attackDis = num2;
				decreaseLevel++;
				yield return new WaitForSeconds(float.Parse(m_SkillRow.kf.DelayedattackTime, CultureInfo.InvariantCulture));
			}
			GameObject gameObject = UnityEngine.Object.Instantiate(prefab, m_BattleController.map.transform);
			gameObject.transform.localPosition = new Vector3(25 + pos.x * 50, -25 - pos.y * 50);
			if (m_SkillRow.kf.Site == "1")
			{
				switch (m_Direction)
				{
				case Direction.Up:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
					break;
				case Direction.Down:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, -90f);
					break;
				case Direction.Left:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
					break;
				case Direction.Right:
				{
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
					Vector3 localScale = gameObject.transform.localScale;
					gameObject.transform.localScale = new Vector3(0f - localScale.x, localScale.y, localScale.z);
					break;
				}
				}
			}
			if (m_SkillRow.kf.Attckstyle.StartsWith("A|05") && attackObjNum % 2 == 0)
			{
				switch (m_Direction)
				{
				case Direction.Up:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 90f + 45f * (float)snakeflag);
					snakeflag = -snakeflag;
					break;
				case Direction.Down:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, -90f - 45f * (float)snakeflag);
					snakeflag = -snakeflag;
					break;
				case Direction.Left:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 45f * (float)snakeflag);
					snakeflag = -snakeflag;
					break;
				case Direction.Right:
					gameObject.transform.rotation = Quaternion.Euler(0f, 0f, -45f * (float)snakeflag);
					snakeflag = -snakeflag;
					break;
				}
			}
			if ("601".Equals(m_SkillRow.kf.Style) && SharedData.Instance().useItemID != "")
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(SharedData.Instance().useItemID);
				if (row != null && KongFuCommomFunc.CheckItemSkillHaveEffect(row, "DartsATK"))
				{
					SkillInfo skillInfo = new SkillInfo();
					List<string> skillList = new List<string> { row.Skills1, row.Skills2, row.Skills3, row.Skills4 };
					List<string> skillEcList = new List<string> { "0", "0", "0", "0" };
					skillInfo.InitSkill(skillList, skillEcList);
					for (int j = 0; j <= skillInfo.sid; j++)
					{
						if (skillInfo.sName[j] == "DartsATK")
						{
							m_SkillRow.runtime_style_damage += skillInfo.sValueNum[j] * (1f + charadata.GetBattleValueByName("DartsATKplus"));
							break;
						}
					}
				}
			}
			if ("601".Equals(m_SkillRow.kf.Style) && m_BattleController.isLostControl)
			{
				m_SkillRow.runtime_style_damage += 5f;
			}
			EffectController component = gameObject.GetComponent<EffectController>();
			component.m_BattleObj = this;
			component.m_TargetObj = attackObjs.Find((BattleObject x) => x.GetGridPosition() == pos);
			component.m_combo = int.Parse(m_SkillRow.kf.Beat);
			m_BattleController.m_EffectControllerList.Add(component);
			if (component.m_TargetObj != null)
			{
				BattleObject targetObj = component.m_TargetObj;
				component.m_Injury = InjuryCalManager.CalAttackDamage(this, targetObj);
				targetObj.AdjustFace(GetGridPosition());
				_ = component.m_TargetObj;
			}
			attackObjNum++;
			if (!TerrainManagerClass.RunCreatTerrainSkill(pos) && !TerrainManagerClass.RunCreatTerrainEquip(pos))
			{
				TerrainManagerClass.RunCreatTerrainTrait(pos);
			}
		}
		if (m_BattleController.m_EffectControllerList.Count > 0)
		{
			m_BattleController.m_EffectControllerList[m_BattleController.m_EffectControllerList.Count - 1].m_isFinalEffect = true;
		}
		if ("player".Equals(race))
		{
			m_SkillRow.proficiency++;
			m_SkillRow.proficiency += (int)charadata.GetFieldValueByName("WuGongProficiencyup");
		}
		float num3 = Mathf.Floor(float.Parse(m_SkillRow.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(m_SkillRow.kf.Expendadd, CultureInfo.InvariantCulture) * (float)(m_SkillRow.lv - 1));
		if (!(m_Revenge_Target != null) || (m_BattleController.GetCurrentObjActionType() != ActionType.Formless && m_BattleController.GetCurrentObjActionType() != ActionType.Ambush && m_BattleController.GetCurrentObjActionType() != ActionType.Fantan))
		{
			if (m_SkillRow.kf.ID == GetEffectOnSuperWugongID())
			{
				num3 = 0f - num3;
			}
			SetMp(0f - num3);
		}
		if (m_Revenge_Target == null)
		{
			m_BattleController.m_Revenge_TGT = this;
			m_BattleController.m_Revenge_TGTSkill = m_SkillRow.kf.ID + "|" + m_SkillRow.kf.Attckstyle + "|" + m_SkillRow.lv + "|MP-GOOD|" + 0;
		}
		yield return new WaitForSeconds(0.5f);
		m_BattleController.isPlayEffectFinish = true;
	}

	public void BeHitCal(int _combo, float _injury)
	{
		BattleObject current = m_BattleController.current;
		if (current.race != race)
		{
			_injury = InjuryCalManager.CalBeHitInjurt(m_BattleController.current, this, _injury);
		}
		if (current.race == race && race != charadata.originRace && _injury >= 1f && (rebellionType.Equals(RebellionType.Temptation) || rebellionType.Equals(RebellionType.Bribe) || rebellionType.Equals(RebellionType.ControlMad)))
		{
			AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_ReRebellion"), "Rebellion");
			SharedData.Instance().m_BattleController.Rebellion(this, 0, RebellionType.None, _force: true);
		}
		if (_combo <= 0)
		{
			int knockBackCount = InjuryCalManager.GetKnockBackCount(m_BattleController.current, this, _injury);
			if (knockBackCount != 0 && KnockBack(knockBackCount, _injury))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1020");
				AddBuffInfo("fend");
			}
			SkillTraitEquipManager.RunEquipSkill(current, this, _injury);
			SkillTraitEquipManager.RunTraitSkill(current, this, _injury);
			SkillTraitEquipManager.RunSkill(current, this, _injury);
			SkillTraitEquipManager.RunLastBeHit(current, this, _injury);
			AddEffectOn();
		}
	}

	private void Update()
	{
		if (!InitOK || m_BattleController.IsSaveRoundRecordRunning || m_BattleController.IsLoadRoundRecordRunning || CommonFunc.IsHoverOpen())
		{
			return;
		}
		UpdateBuffList();
		UpdateDamageList();
		if (m_State == BattleObjectState.AStarWaiting)
		{
			AStarAlgorithmBattleField.AStarWaiting(this);
		}
		else if (m_State == BattleObjectState.AStarMoving)
		{
			AStarAlgorithmBattleField.AStarMove(this);
		}
		else
		{
			if (m_BattleController.current != this || m_BattleController.m_Flow == BattleControllerFlow.GameSet || !m_BattleController.isRoundActionFinish())
			{
				return;
			}
			if (race == "player" && SharedData.Instance().m_Inevitable)
			{
				charadata.m_Hp = charadata.GetBattleValueByName("HP");
				charadata.m_Mp = charadata.GetBattleValueByName("MP");
			}
			if (m_State == BattleObjectState.HandIn)
			{
				switch (m_BattleController.GetCurrentObjActionType())
				{
				case ActionType.Formless:
				case ActionType.WugongCounter:
				case ActionType.FormlessSuper:
				case ActionType.Ambush:
				case ActionType.Fantan:
				{
					GameObject gameObject = UnityEngine.Object.Instantiate(CommonResourcesData.Buff_Counter_Prefab, base.transform);
					gameObject.transform.localPosition = new Vector2(gameObject.transform.localPosition.x - UnityEngine.Random.Range(10f, 30f), gameObject.transform.localPosition.y + UnityEngine.Random.Range(10f, 30f));
					break;
				}
				case ActionType.Return:
				{
					GameObject gameObject = UnityEngine.Object.Instantiate(CommonResourcesData.Buff_Return_Prefab, base.transform);
					gameObject.transform.localPosition = new Vector2(gameObject.transform.localPosition.x - UnityEngine.Random.Range(10f, 30f), gameObject.transform.localPosition.y + UnityEngine.Random.Range(10f, 30f));
					break;
				}
				case ActionType.WugongAssist:
				case ActionType.RoleAssist:
				{
					GameObject gameObject = UnityEngine.Object.Instantiate(CommonResourcesData.Buff_Assist_Prefab, base.transform);
					gameObject.transform.localPosition = new Vector2(gameObject.transform.localPosition.x - UnityEngine.Random.Range(10f, 30f), gameObject.transform.localPosition.y + UnityEngine.Random.Range(10f, 30f));
					break;
				}
				}
				if (m_BattleController.GetCurrentObjActionType() != 0 && m_BattleController.GetCurrentObjActionType() != ActionType.RoleAssist && m_BattleController.GetCurrentObjActionType() != ActionType.Runaway && m_BattleController.GetCurrentObjActionType() != ActionType.Multikill)
				{
					SetBattleObjState(BattleObjectState.CounterIn);
					return;
				}
				handInPos = GetGridPosition();
				attackObjs.Clear();
				BuffData buffByName = GetBuffByName("TurtleBreath");
				if (buffByName != null)
				{
					if (buffByName.turn != 1)
					{
						AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_TurtleBreath"), "");
						buffByName.turn--;
						SetBattleObjState(BattleObjectState.HandOut);
						m_BattleController.SetFlowState(BattleControllerFlow.Interlude);
						return;
					}
					AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_TurtleBreathBackAlive"), "");
					RemoveBuff(buffByName);
					BattleObjectBackAlive();
				}
				if (targetGridList.Contains(GetGridPosition()))
				{
					BattleObjectEscape();
					return;
				}
				if (charadata.GetBattleValueByName("Seal") >= 25f)
				{
					AddBuffInfo("seal");
					SealFreeze();
					InteruptIn(BattleObjectState.RoundOff);
					m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
				}
				else if (isUnSealNextRound)
				{
					isUnSealNextRound = false;
					UnSealFreeze();
					InteruptIn(BattleObjectState.HandInPost);
				}
				if (m_State == BattleObjectState.HandIn)
				{
					SetBattleObjState(BattleObjectState.HandInPost);
				}
			}
			else if (m_State == BattleObjectState.HandInPost)
			{
				stealhptotal = 0f;
				stealmptotal = 0f;
				madselftotal = 0f;
				RunBuffEffectBeforMove();
				UpdateMpByHurt();
				if (charadata.GetBattleValueByName("TerrainTrapLevelUp") > 0f)
				{
					foreach (Vector3Int item in m_BattleController.terrain.Keys.ToList())
					{
						switch (m_BattleController.terrain[item].t_type)
						{
						case TerrainType.FireLv1:
							m_BattleController.AddTerrain(item, TerrainType.FireLv2);
							break;
						case TerrainType.FireLv2:
							m_BattleController.AddTerrain(item, TerrainType.FirePersistent);
							break;
						case TerrainType.PoisonLv1:
							m_BattleController.AddTerrain(item, TerrainType.PoisonLv2);
							break;
						case TerrainType.PoisonLv2:
							m_BattleController.AddTerrain(item, TerrainType.PoisonPersistent);
							break;
						}
					}
				}
				KongFuData kongFuData = charadata.GetKongFuByID(GetEffectOnSuperWugongID());
				if (kongFuData != null)
				{
					float num = Mathf.Floor(float.Parse(kongFuData.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(kongFuData.kf.Expendadd, CultureInfo.InvariantCulture) * (float)(kongFuData.lv - 1));
					if (num < charadata.m_Mp)
					{
						AddDamageInfo(num.ToString(), "MP");
					}
					else
					{
						foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
						{
							foreach (BuffData item2 in allBattleObj.m_Buffs.FindAll((BuffData x) => x.source == "Wugong|" + kongFuData.kf.ID + "|" + base.gameObject.name + "|"))
							{
								allBattleObj.RemoveBuff(item2);
							}
						}
					}
				}
				m_TotalFendBackNumber = 0;
				m_RealFendBackNumber = 0;
				m_FinalAddExp = 0;
				m_SkillRow = null;
				SetBattleObjState(BattleObjectState.MoveInit);
			}
			else if (m_State == BattleObjectState.MoveInit)
			{
				foreach (BattleObject allBattleObj2 in m_BattleController.allBattleObjs)
				{
					allBattleObj2.RefreshSomeCalRangeInfo();
					allBattleObj2.isBeEffectInMovingStage = false;
				}
				RangeManager.ClearAllRange();
				if (!RangeManager.isCalShowUnitRange)
				{
					ClearRangeInfo();
					StartCoroutine(RangeManager.ShowUnitRangeCoroutine(this, reCallAStarPathDict: true, BattleControllerFlow.CharacterInit, BattleObjectState.WaitingForInput));
					m_BattleController.SetFlowState(BattleControllerFlow.None);
					SetBattleObjState(BattleObjectState.None);
				}
			}
			else if (m_State == BattleObjectState.ActionInit)
			{
				if (m_BattleController.JudgeWinOrLose())
				{
					return;
				}
				PlayAnimation(Aniname.aniname_stand);
				if (m_BattleController.isLostControl)
				{
					if (currentForecast != null && currentForecast.actionName != null && currentForecast.actionName != "")
					{
						SelectWuGong(currentForecast.actionName);
						SetBattleObjState(BattleObjectState.ActionWait);
					}
					else
					{
						m_AttackType = null;
						SetBattleObjState(BattleObjectState.ActionOver);
					}
				}
				else
				{
					m_MenuController.m_menuState = BattleMenuState.AutoBattleShow;
					SetBattleObjState(BattleObjectState.ActionWait);
				}
				m_BattleController.SetFlowState(BattleControllerFlow.ActionWait);
			}
			else if (m_State == BattleObjectState.ActionOver)
			{
				if (!m_BattleController.isRoundActionFinish())
				{
					return;
				}
				AdjustAnimationSpeed(1f, Color.white);
				if (breakItems.Count > 0)
				{
					ItemController itemController = breakItems[0];
					if (itemController.isItemPerforming == 0)
					{
						itemController.BeHit();
					}
					else if (itemController.isItemPerforming == 2)
					{
						itemController.gameObject.SetActive(value: false);
						GameObject obj = UnityEngine.Object.Instantiate((GameObject)Resources.Load("Prefabs/" + itemController.b5row.Prefab2), itemController.transform.parent);
						obj.transform.localPosition = itemController.transform.localPosition;
						obj.GetComponent<SpriteRenderer>().sortingOrder = itemController.GetComponent<SpriteRenderer>().sortingOrder;
						string[] array = itemController.b5row.ItemID.Split('|');
						gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(array[0]);
						if ("999".Equals(row.ID))
						{
							SharedData.Instance().m_Money += int.Parse(array[1]);
						}
						else
						{
							SharedData.Instance().PackageAdd(row.ID, int.Parse(array[1]));
						}
						m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetItem") + " " + row.Name_Trans + "*" + array[1] + "!");
						InteruptIn(BattleObjectState.ActionOverPost);
						itemController.isItemPerforming = 3;
					}
					else if (itemController.isItemPerforming == 3)
					{
						breakItems.Remove(itemController);
						m_BattleController.items.Remove(itemController);
						UnityEngine.Object.Destroy(itemController.gameObject);
					}
				}
				if (stealhptotal > 0f)
				{
					AddDamageInfo(stealhptotal.ToString(), "HEAL");
					stealhptotal = 0f;
				}
				if (stealmptotal > 0f)
				{
					AddDamageInfo(stealmptotal.ToString(), "HEALMP");
					stealmptotal = 0f;
				}
				if (("b01".Equals(charadata.m_Table) || SharedData.Instance().FollowList.Contains(charadata.m_Id)) && m_AttackType != null)
				{
					int num2 = 0;
					if ("ITEM".Equals(m_AttackType[0]))
					{
						num2 = 10;
					}
					else if ("2".Equals(m_AttackType[3]))
					{
						num2 = 50;
					}
					else if (attackObjs.Count == 0)
					{
						num2 = 20;
					}
					else
					{
						foreach (BattleObject attackObj in attackObjs)
						{
							if (!(attackObj == this))
							{
								num2 = ((!attackObj.isDead) ? (num2 + (attackObj.m_DefeatExp - (charadata.m_Level - attackObj.charadata.m_Level))) : (num2 + (attackObj.m_DefeatExp * 2 - (charadata.m_Level - attackObj.charadata.m_Level) * 5)));
							}
						}
						if (num2 < 20)
						{
							num2 = 20;
						}
					}
					if (num2 > 0)
					{
						m_FinalAddExp += num2;
					}
				}
				bool flag = true;
				foreach (BattleObject attackObj2 in attackObjs)
				{
					if (!(attackObj2 == this) && !attackObj2.isDead)
					{
						flag = false;
						break;
					}
				}
				if (m_StealSuccess.Count > 0)
				{
					bool flag2 = true;
					bool flag3 = true;
					bool flag4 = false;
					foreach (KeyValuePair<BattleObject, string> item3 in m_StealSuccess)
					{
						if (!item3.Value.Equals("FAILED") && !item3.Value.Equals("EMPTY"))
						{
							flag2 = false;
							flag3 = false;
							if (!flag4)
							{
								flag4 = true;
								string[] array2 = item3.Value.Split('|');
								item3.Key.m_StealableItemsNum[int.Parse(array2[2])] = 0;
								gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(array2[0]);
								if (row2 != null)
								{
									int amount = int.Parse(array2[1]);
									SharedData.Instance().PackageAdd(array2[0], amount);
									m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_StalSuccess") + " <color=#f0e352>" + row2.Name_Trans + "</color> * " + array2[1] + "！", row2.BookIcon);
									InteruptIn(BattleObjectState.ActionOverPost);
								}
								else
								{
									m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_StalSuccess_1"));
									InteruptIn(BattleObjectState.ActionOverPost);
								}
							}
						}
						if (item3.Value.Equals("EMPTY"))
						{
							flag2 = false;
						}
						if (item3.Value.Equals("FAILED"))
						{
							flag3 = false;
						}
					}
					if (flag2)
					{
						m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_StalFail"));
						InteruptIn(BattleObjectState.ActionOverPost);
					}
					else if (flag3)
					{
						m_MenuController.OpenInteruptInfo(this, CommonFunc.I18nGetLocalizedValue("I18N_StalFail_NoItem"));
						InteruptIn(BattleObjectState.ActionOverPost);
					}
				}
				m_StealSuccess.Clear();
				if (!flag && ComboCheck())
				{
					return;
				}
				if (!flag && m_SkillRow != null && KongFuCommomFunc.CheckWugongHaveEffect(m_SkillRow.kf, "WugongAssist") && m_BattleController.GetCurrentObjActionType() != ActionType.WugongAssist)
				{
					SkillInfo skillInfo = new SkillInfo();
					skillInfo.Init(m_SkillRow, this);
					float num3 = 0f;
					for (int i = 0; i <= skillInfo.sid; i++)
					{
						if (skillInfo.sName[i] == "WugongAssist")
						{
							num3 = skillInfo.sOddNum[i];
							break;
						}
					}
					foreach (BattleObject allBattleObj3 in SharedData.Instance().m_BattleController.allBattleObjs)
					{
						bool flag5 = false;
						if (allBattleObj3.isDead || allBattleObj3 == this || allBattleObj3.race != race || allBattleObj3.isSealFreeze)
						{
							continue;
						}
						KongFuData kongFuByID = allBattleObj3.charadata.GetKongFuByID(m_SkillRow.kf.ID);
						if (kongFuByID == null)
						{
							continue;
						}
						int num4 = int.MinValue;
						float num5 = Mathf.Floor(float.Parse(kongFuByID.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(kongFuByID.kf.Expendadd, CultureInfo.InvariantCulture) * (float)(kongFuByID.lv - 1));
						if (num5 <= allBattleObj3.charadata.m_Mp)
						{
							string[] type = (kongFuByID.kf.ID + "|" + kongFuByID.kf.Attckstyle + "|" + kongFuByID.lv + "|MP-GOOD").Split('|');
							Dictionary<Vector3Int, int> dictionary = null;
							if (kongFuByID.kf.Attckstyle[0] != 'B')
							{
								dictionary = AttackData.GetRange1ByAttackType(type, allBattleObj3.GetGridPosition(), allBattleObj3);
								foreach (KeyValuePair<Vector3Int, int> item4 in dictionary)
								{
									Dictionary<Vector3Int, int> range2ByAttackType = AttackData.GetRange2ByAttackType(type, item4.Key, item4.Value, allBattleObj3.GetGridPosition());
									int num6 = 0;
									foreach (BattleObject attackObj3 in attackObjs)
									{
										if (!attackObj3.isDead && !(attackObj3.race == race) && range2ByAttackType.ContainsKey(attackObj3.GetGridPosition()))
										{
											num6++;
										}
									}
									if (num6 > 0 && num6 > num4)
									{
										num4 = num6;
										m_attackPos = item4.Key;
										flag5 = true;
									}
								}
							}
							else
							{
								dictionary = AttackData.GetRange2ByAttackType(type, allBattleObj3.GetGridPosition(), 0, allBattleObj3.GetGridPosition());
								int num7 = 0;
								foreach (BattleObject attackObj4 in attackObjs)
								{
									if (!attackObj4.isDead && !(attackObj4.race == race) && dictionary.ContainsKey(attackObj4.GetGridPosition()))
									{
										m_attackPos = attackObj4.GetGridPosition();
										num7++;
									}
								}
								if (num7 > 0 && num7 > num4)
								{
									num4 = num7;
									flag5 = true;
								}
							}
						}
						if (flag5 && UnityEngine.Random.Range(0f, 1f) < num3)
						{
							allBattleObj3.m_Assist_Skill = kongFuByID.kf.ID + "|" + kongFuByID.kf.Attckstyle + "|" + kongFuByID.lv + "|MP-GOOD|" + num5;
							allBattleObj3.m_Assist_Pos = m_attackPos;
							if (SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.counterType == ActionType.WugongAssist) == null)
							{
								SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(allBattleObj3, ActionType.WugongAssist));
							}
						}
					}
				}
				if (m_FinalAddExp > 0 && ("b01".Equals(charadata.m_Table) || SharedData.Instance().FollowList.Contains(charadata.m_Id)))
				{
					m_FinalAddExp += Mathf.CeilToInt((float)m_FinalAddExp * charadata.GetBattleValueByName("EXPup"));
					AddDamageInfo(m_FinalAddExp.ToString(), "EXP");
				}
				SetBattleObjState(BattleObjectState.ActionOverPost);
			}
			else if (m_State == BattleObjectState.ActionOverPost)
			{
				if (m_BattleController.isRoundActionFinish())
				{
					SkillLevelUpCheckProcess();
					if (m_State == BattleObjectState.ActionOverPost)
					{
						SetBattleObjState(BattleObjectState.RoundOff);
						m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
					}
				}
			}
			else if (m_State == BattleObjectState.SkillLevelUpNeetOver)
			{
				if (SharedData.Instance().m_AppendTraitInfos.Length > 0)
				{
					Deal_AppendTraitInfos();
					InteruptIn(BattleObjectState.SkillLevelUpNeetOverDelay);
				}
				else
				{
					SkillLevelUpCheckProcess();
				}
			}
			else if (m_State == BattleObjectState.SkillLevelUpNeetOverDelay)
			{
				SetBattleObjState(BattleObjectState.None);
				StartCoroutine(SkillLevelUpNeetOverDelay(0.5f));
			}
			else if (m_State == BattleObjectState.SkillLevelUpOver)
			{
				if (SharedData.Instance().m_AppendTraitInfos.Length > 0)
				{
					Deal_AppendTraitInfos();
					InteruptIn(BattleObjectState.SkillLevelUpOverDelay);
				}
				else
				{
					SharedData.Instance().m_BattleController.LevelUpCheckProcess();
				}
			}
			else if (m_State == BattleObjectState.SkillLevelUpOverDelay)
			{
				SetBattleObjState(BattleObjectState.None);
				StartCoroutine(SkillLevelUpOverDelay(0.5f));
			}
			else if (m_State == BattleObjectState.LevelUpOver)
			{
				charadata.m_Hp = charadata.GetBattleValueByName("HP");
				float num8 = CommonFunc.saturate(charadata.GetBattleValueByName("Hurt") / 255f);
				float mp = Mathf.Floor(Mathf.Floor(charadata.GetBattleValueByName("MP")) * (1f - num8));
				charadata.m_Mp = mp;
				if (m_BattleController.current == this)
				{
					SetBattleObjState(BattleObjectState.RoundOff);
					m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
				}
			}
			else if (m_State == BattleObjectState.RoundOff)
			{
				FlushBuffs();
				HandOut();
			}
			else if (m_State == BattleObjectState.CounterIn)
			{
				m_FinalAddExp = 0;
				m_SkillRow = null;
				if (charadata.GetBattleValueByName("Seal") >= 25f)
				{
					AddBuffInfo("seal");
					m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SealCanNotAttck"));
					InteruptIn(BattleObjectState.HandOut);
					SetBattleObjState(BattleObjectState.RoundOff);
					m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
				}
				else
				{
					SetBattleObjState(BattleObjectState.CounterAction);
				}
				m_BattleController.SetCameraSmooth(this, isSetCurcor: true);
			}
			else if (m_State == BattleObjectState.CounterAction)
			{
				switch (m_BattleController.GetCurrentObjActionType())
				{
				case ActionType.Formless:
				case ActionType.FormlessSuper:
					LetUsFormless();
					break;
				case ActionType.WugongCounter:
					LetUsWugongCounter();
					break;
				case ActionType.Return:
					LetUsReturn();
					break;
				case ActionType.Ambush:
					LetUsAmbush();
					break;
				case ActionType.Fantan:
					LetUsFanTan();
					break;
				case ActionType.WugongAssist:
					LetUsWugongAssist();
					break;
				}
				if (m_BattleController.GetCurrentObjActionType() == ActionType.Return)
				{
					StatsAndAchievements.Instance().UnlockAchievement("1021");
				}
			}
		}
	}

	protected IEnumerator SkillLevelUpOverDelay(float _delay = 1f)
	{
		yield return new WaitForSeconds(_delay);
		SetBattleObjState(BattleObjectState.SkillLevelUpOver);
	}

	protected IEnumerator SkillLevelUpNeetOverDelay(float _delay = 1f)
	{
		yield return new WaitForSeconds(_delay);
		SetBattleObjState(BattleObjectState.SkillLevelUpNeetOver);
	}

	private void InitStealable()
	{
		List<gang_c04Table.Row> list = CommonResourcesData.c04.FindAll_ID(charadata.m_DropId);
		if (list == null)
		{
			return;
		}
		foreach (gang_c04Table.Row item in list)
		{
			string[] array = item.QTY.Split('|');
			int num = 0;
			num = ((array.Length <= 1) ? int.Parse(array[0]) : UnityEngine.Random.Range(int.Parse(array[0]), int.Parse(array[1]) + 1));
			if (num > 0)
			{
				m_StealableItemsName.Add(item);
			}
			m_StealableItemsNum.Add(num);
		}
	}

	private void InitMustDropID()
	{
		List<gang_c04Table.Row> list = CommonResourcesData.c04.FindAll_ID(charadata.m_mustDropID);
		if (list == null)
		{
			return;
		}
		foreach (gang_c04Table.Row item in list)
		{
			string[] array = item.QTY.Split('|');
			int num = 0;
			num = ((array.Length <= 1) ? int.Parse(array[0]) : UnityEngine.Random.Range(int.Parse(array[0]), int.Parse(array[1]) + 1));
			if (num > 0)
			{
				m_mustDropItemsName.Add(item);
			}
			m_mustDropItemsNum.Add(num);
		}
	}

	private void AddEffectOn()
	{
		if (!m_EffectOnList.ContainsKey("Bleed"))
		{
			float battleValueByName = charadata.GetBattleValueByName("Bleed", isOrigin: true);
			if (battleValueByName >= 25f && battleValueByName < 125f)
			{
				m_EffectOnList.Add("Bleed", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnBleed_Prefab, base.transform));
			}
		}
		if (!m_EffectOnList.ContainsKey("Bleed2") && charadata.GetBattleValueByName("Bleed", isOrigin: true) >= 125f)
		{
			m_EffectOnList.Add("Bleed2", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnBleed2_Prefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Drunk") && charadata.GetBattleValueByName("Drunk", isOrigin: true) >= 25f)
		{
			m_EffectOnList.Add("Drunk", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnDrunk_Prefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Burn"))
		{
			float battleValueByName2 = charadata.GetBattleValueByName("Burn", isOrigin: true);
			if (battleValueByName2 >= 25f && battleValueByName2 < 125f)
			{
				m_EffectOnList.Add("Burn", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnFire_Prefab, base.transform));
			}
		}
		if (!m_EffectOnList.ContainsKey("Burn2") && charadata.GetBattleValueByName("Burn", isOrigin: true) >= 125f)
		{
			m_EffectOnList.Add("Burn2", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnFire2_Prefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Hurt") && CommonFunc.saturate(charadata.GetBattleValueByName("Hurt", isOrigin: true) / 255f) > 0f)
		{
			m_EffectOnList.Add("Hurt", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnHurt_Prefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Mad") && charadata.GetBattleValueByName("Mad", isOrigin: true) >= 25f)
		{
			m_EffectOnList.Add("Mad", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnMad_Prefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Poison"))
		{
			float battleValueByName3 = charadata.GetBattleValueByName("Poison", isOrigin: true);
			if (battleValueByName3 >= 25f && battleValueByName3 < 125f)
			{
				m_EffectOnList.Add("Poison", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnPoison_Prefab, base.transform));
			}
		}
		if (!m_EffectOnList.ContainsKey("Poison2") && charadata.GetBattleValueByName("Poison", isOrigin: true) >= 125f)
		{
			m_EffectOnList.Add("Poison2", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnPoison2_Prefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Spit") && CheckBuffEffectOn("Spit"))
		{
			m_EffectOnList.Add("Spit", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnSpitPrefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Dizzy") && CheckBuffEffectOn("Dizzy"))
		{
			m_EffectOnList.Add("Dizzy", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnDizzyPrefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Fear") && CheckBuffEffectOn("Fear"))
		{
			m_EffectOnList.Add("Fear", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnFearPrefab, base.transform));
		}
		if (!m_EffectOnList.ContainsKey("Blind") && CheckBuffEffectOn("Blind"))
		{
			m_EffectOnList.Add("Blind", UnityEngine.Object.Instantiate(CommonResourcesData.Buff_EffectOnBlindPrefab, base.transform));
		}
	}

	private void RemoveEffectOn()
	{
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, GameObject> effectOn in m_EffectOnList)
		{
			switch (effectOn.Key)
			{
			case "Bleed":
			{
				float battleValueByName = charadata.GetBattleValueByName("Bleed", isOrigin: true);
				if (battleValueByName < 25f || battleValueByName >= 125f)
				{
					list.Add(effectOn.Key);
				}
				break;
			}
			case "Bleed2":
				if (charadata.GetBattleValueByName("Bleed", isOrigin: true) < 125f)
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Drunk":
				if (charadata.GetBattleValueByName("Drunk", isOrigin: true) < 25f)
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Burn":
			{
				float battleValueByName3 = charadata.GetBattleValueByName("Burn", isOrigin: true);
				if (battleValueByName3 < 25f || battleValueByName3 >= 125f)
				{
					list.Add(effectOn.Key);
				}
				break;
			}
			case "Burn2":
				if (charadata.GetBattleValueByName("Burn", isOrigin: true) < 125f)
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Hurt":
				if (charadata.GetBattleValueByName("Hurt", isOrigin: true) / 255f <= 0f)
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Mad":
				if (charadata.GetBattleValueByName("Mad", isOrigin: true) < 25f)
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Poison":
			{
				float battleValueByName2 = charadata.GetBattleValueByName("Poison", isOrigin: true);
				if (battleValueByName2 < 25f || battleValueByName2 >= 125f)
				{
					list.Add(effectOn.Key);
				}
				break;
			}
			case "Poison2":
				if (charadata.GetBattleValueByName("Poison", isOrigin: true) < 125f)
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Spit":
				if (!CheckBuffEffectOn("Spit"))
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Dizzy":
				if (!CheckBuffEffectOn("Dizzy"))
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Fear":
				if (!CheckBuffEffectOn("Fear"))
				{
					list.Add(effectOn.Key);
				}
				break;
			case "Blind":
				if (!CheckBuffEffectOn("Blind"))
				{
					list.Add(effectOn.Key);
				}
				break;
			}
		}
		foreach (string item in list)
		{
			UnityEngine.Object.Destroy(m_EffectOnList[item]);
			m_EffectOnList.Remove(item);
		}
	}

	public void RefreshEffectOn()
	{
		RemoveEffectOn();
		AddEffectOn();
	}

	public void FlushBuffs()
	{
		List<BuffData> list = new List<BuffData>();
		float num = 0f;
		float num2 = 0f;
		charadata.Indexs_Name["Drunk"].fightValue -= 1f;
		for (int i = 0; i < m_Buffs.Count; i++)
		{
			if (m_Buffs[i].turn == 0)
			{
				list.Add(m_Buffs[i]);
				continue;
			}
			switch (m_Buffs[i].name)
			{
			case "HPturn":
				if (num <= 0f && charadata.m_Hp < charadata.GetBattleValueByName("HP"))
				{
					num = Mathf.Ceil(charadata.GetBattleValueByName("HP") * charadata.GetBattleValueByName(m_Buffs[i].name));
				}
				break;
			case "MPturn":
				if (num2 <= 0f)
				{
					float num3 = CommonFunc.saturate(charadata.GetBattleValueByName("Hurt") / 255f);
					float num4 = Mathf.Floor(charadata.GetBattleValueByName("MP"));
					float num5 = Mathf.Floor(num4 * (1f - num3));
					if (charadata.m_Mp < num5)
					{
						num2 += Mathf.Ceil(num4 * charadata.GetBattleValueByName(m_Buffs[i].name));
					}
				}
				break;
			case "SP":
			case "ATK":
			case "DEF":
			case "Combo":
			case "Crit":
			case "Crit1":
				if (m_Buffs[i].drunk && charadata.GetBattleValueByName("Drunk") <= 0f)
				{
					m_Buffs[i].turn = 0;
				}
				break;
			case "PoisonHealHpTurn":
				num *= charadata.GetBattleValueByName("Poison", isOrigin: true);
				break;
			}
			m_Buffs[i].turn--;
			if (m_Buffs[i].turn <= 0)
			{
				list.Add(m_Buffs[i]);
			}
		}
		if (num > 0f)
		{
			AddDamageInfo(num.ToString(), "HEAL");
		}
		if (num2 > 0f)
		{
			AddDamageInfo(num2.ToString(), "HEALMP");
		}
		foreach (BuffData item in list)
		{
			if (item.drunk)
			{
				float drunkbuffValue = charadata.Indexs_Name[item.name].drunkbuffValue;
				drunkbuffValue -= item.value;
				charadata.Indexs_Name[item.name].drunkbuffValue = drunkbuffValue;
			}
			if (item.name == "Goldenbell")
			{
				AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_LostGoldenbell"), "");
			}
			RemoveBuff(item);
		}
	}

	private void HandOut()
	{
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		float num4 = 0f;
		if (!CheckBuffEffectOn("Goldenbell") && m_Revenge_Target == null)
		{
			num = charadata.GetBattleValueByName("Poison");
			num2 = charadata.GetBattleValueByName("Bleed");
			num3 = charadata.GetBattleValueByName("Burn");
		}
		if (handInPos != GetGridPosition() && num >= 25f)
		{
			num4 = ((!(num >= 125f)) ? Mathf.Floor(charadata.GetBattleValueByName("HP") * num / 2000f + num / 2f) : Mathf.Floor(charadata.GetBattleValueByName("HP") * num / 1000f + num / 1.5f));
			AddBuffInfo("poison");
			AddDamageInfo(num4.ToString(), "POISON");
		}
		if (num2 >= 25f)
		{
			num4 = Mathf.Floor(charadata.GetBattleValueByName("HP") * 0.025f + num2 * ((num2 >= 125f) ? 1.25f : 1f));
			AddBuffInfo("bleed");
			AddDamageInfo(num4.ToString(), "BLEED");
			if (num2 >= 125f)
			{
				foreach (BattleObject gridNeighborBattleObject in m_BattleController.GetGridNeighborBattleObjects(GetGridPosition(), _inIncludeDead: false))
				{
					gridNeighborBattleObject.charadata.Indexs_Name["Burn"].fightValue -= 25f;
				}
			}
		}
		if (num3 >= 25f)
		{
			num4 = Mathf.Floor(num3 * ((num3 >= 125f) ? 2f : 1f));
			AddBuffInfo("burn");
			AddDamageInfo(num4.ToString(), "BURN");
			if (num3 >= 125f)
			{
				foreach (BattleObject gridNeighborBattleObject2 in m_BattleController.GetGridNeighborBattleObjects(GetGridPosition(), _inIncludeDead: false))
				{
					gridNeighborBattleObject2.charadata.Indexs_Name["Burn"].fightValue += 5f;
				}
			}
		}
		if (madselftotal > 0f)
		{
			AddBuffInfo("mad");
			AddDamageInfo(madselftotal.ToString(), "DAMAGE");
			madselftotal = 0f;
		}
		if (num4 > 0f)
		{
			PlayAudioClip(AudioClipEnum.damageClip);
		}
		StartCoroutine(HandOut_CallBack());
	}

	private IEnumerator HandOut_CallBack()
	{
		SetBattleObjState(BattleObjectState.None);
		ActionOverStock();
		while (!m_BattleController.isRoundActionFinish())
		{
			yield return null;
		}
		PlayAnimation(Aniname.aniname_stand);
		HandOutOperation();
	}

	public void HandOutOperation()
	{
		if (m_BattleController.current != this)
		{
			return;
		}
		aliveRoundNumber--;
		if (charadata.m_Hp <= 0f || aliveRoundNumber <= 0)
		{
			BattleObjectDead();
			if (aliveRoundNumber <= 0)
			{
				AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Bye"), "");
			}
			m_MenuController.m_menuState = BattleMenuState.None;
		}
		if (!isDead)
		{
			BuffData buffByName = GetBuffByName("Goldenbell");
			if (handInPos != GetGridPosition() && buffByName != null)
			{
				RemoveBuff(buffByName);
			}
			if (race != charadata.originRace)
			{
				rebellionRoundNumber--;
				if (rebellionRoundNumber <= 0)
				{
					m_BattleController.Rebellion(this, 0, RebellionType.None, _force: true);
				}
			}
			m_Revenge_Target = null;
			int num = 0;
			foreach (BattleObject attackObj in attackObjs)
			{
				if (!(attackObj == this) && attackObj.isDead && attackObj.race != race)
				{
					num++;
				}
			}
			if (num > 0 && m_BattleController.GetCurrentObjActionType() == ActionType.None)
			{
				int num2 = CheckIsMultiKillOrRunaway();
				switch (num2)
				{
				case 1:
				{
					if (m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == this && x.counterType == ActionType.Multikill) == null)
					{
						m_BattleController.ExtraActionOrder.Insert(0, new ActionOrderItem(this, ActionType.Multikill));
					}
					GameObject gameObject2 = UnityEngine.Object.Instantiate(CommonResourcesData.Buff_multiKill_Prefab, base.transform);
					gameObject2.transform.localPosition = new Vector2(gameObject2.transform.localPosition.x - UnityEngine.Random.Range(10f, 30f), gameObject2.transform.localPosition.y + UnityEngine.Random.Range(10f, 30f));
					if (charadata.originRace == "player" && !(race == "player"))
					{
					}
					break;
				}
				case 2:
				{
					if (m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == this && x.counterType == ActionType.Runaway) == null)
					{
						m_BattleController.ExtraActionOrder.Insert(0, new ActionOrderItem(this, ActionType.Runaway));
					}
					GameObject gameObject = UnityEngine.Object.Instantiate(CommonResourcesData.Buff_Runaway_Prefab, base.transform);
					gameObject.transform.localPosition = new Vector2(gameObject.transform.localPosition.x - UnityEngine.Random.Range(10f, 30f), gameObject.transform.localPosition.y + UnityEngine.Random.Range(10f, 30f));
					break;
				}
				}
				if (num2 == 1 && race.Equals("player"))
				{
					StatsAndAchievements.Instance().UnlockAchievement("1026");
				}
			}
		}
		RefreshEffectOn();
		SetBattleObjState(BattleObjectState.HandOut);
		m_BattleController.SetFlowState(BattleControllerFlow.Interlude);
	}

	private void ActionOverStock()
	{
		if (m_Revenge_Target != null)
		{
			return;
		}
		charadata.Indexs_Name["Bleed"].fightValue -= 1f;
		float battleValueByName = charadata.GetBattleValueByName("Burn");
		if (battleValueByName >= 25f)
		{
			charadata.Indexs_Name["Burn"].fightValue += ((battleValueByName >= 125f) ? 10f : 5f);
		}
		float battleValueByName2 = charadata.GetBattleValueByName("Seal");
		if (battleValueByName2 >= 25f)
		{
			float num = 1f - CommonFunc.saturate(battleValueByName2 / 255f) * 0.8f;
			if (UnityEngine.Random.Range(0f, 1f) <= num)
			{
				charadata.Indexs_Name["Seal"].fightValue = 0f;
				isUnSealNextRound = true;
			}
		}
		if (charadata.Indexs_Name["Mad"].fightValue > 0f)
		{
			float num2 = CommonFunc.saturate(charadata.GetBattleValueByName("Hurt") / 255f);
			float num3 = Mathf.Floor(Mathf.Floor(charadata.GetBattleValueByName("MP")) * (1f - num2));
			charadata.Indexs_Name["Mad"].fightValue -= Mathf.Ceil(num3 / 100f);
		}
		RemoveEffectOn();
	}

	private void SkillLevelUpCheckProcess()
	{
		if ((charadata.m_Table != "b01" && !SharedData.Instance().FollowList.Contains(charadata.m_Id)) || charadata.originRace != "player")
		{
			return;
		}
		if (m_SkillRow != null && m_SkillRow.lv < int.Parse(m_SkillRow.kf.LV) && (float)m_SkillRow.lv < charadata.GetFieldValueByName("WIL") && m_SkillRow.proficiency >= 100 && m_BattleController.GetCurrentObjActionType() != ActionType.Formless && m_BattleController.GetCurrentObjActionType() != ActionType.FormlessSuper)
		{
			m_SkillRow.proficiency = 0;
			m_SkillRow.newlv = m_SkillRow.lv + 1;
			m_SkillRow.CheckAppendTraits(charadata);
			if (!SharedData.Instance().skillLevelupObjList.Contains(this))
			{
				SharedData.Instance().skillLevelupObjList.Add(this);
			}
			charadata.m_LevelUpSkillId = m_SkillRow.kf.ID;
			m_BattleController.ShowLevelUpSkill();
			SetBattleObjState(BattleObjectState.SkillLevelUpNeet);
		}
		else
		{
			if (m_FinalAddExp <= 0)
			{
				return;
			}
			if (!"".Equals(charadata.m_Training_Id))
			{
				KongFuData kongFuByID = charadata.GetKongFuByID(charadata.m_Training_Id);
				float fieldValueByName = charadata.GetFieldValueByName("LER");
				if (kongFuByID != null)
				{
					kongFuByID.newlv = kongFuByID.lv;
					if (kongFuByID.lv < int.Parse(kongFuByID.kf.LV) && kongFuByID.CheckLevelUp(m_FinalAddExp, charadata.GetFieldValueByName("WIL"), fieldValueByName, charadata))
					{
						if (!SharedData.Instance().skillLevelupObjList.Contains(this))
						{
							SharedData.Instance().skillLevelupObjList.Add(this);
						}
						charadata.m_LevelUpSkillId = charadata.m_Training_Id;
						m_BattleController.ShowLevelUpSkill();
						SetBattleObjState(BattleObjectState.SkillLevelUp);
					}
					else
					{
						SharedData.Instance().m_BattleController.LevelUpCheckProcess();
					}
				}
				else
				{
					SharedData.Instance().m_BattleController.LevelUpCheckProcess();
				}
			}
			else
			{
				SharedData.Instance().m_BattleController.LevelUpCheckProcess();
			}
		}
	}

	public void LevelUpCheckProcess()
	{
		bool flag = false;
		int num = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
		if (charadata.m_Level < num)
		{
			charadata.m_Exp += m_FinalAddExp;
			m_FinalAddExp = 0;
			int num2 = int.Parse(CommonResourcesData.a05.Find_LV(charadata.m_Level.ToString()).EXP);
			if (charadata.m_Exp >= num2)
			{
				flag = true;
				if (charadata.m_Level < num)
				{
					charadata.m_Exp -= num2;
				}
				else
				{
					charadata.m_Exp = 0;
				}
			}
		}
		if (flag)
		{
			if (!SharedData.Instance().levelupObjList.Contains(charadata))
			{
				SharedData.Instance().levelupObjList.Add(charadata);
			}
			if (m_BattleController.current == this)
			{
				SetBattleObjState(BattleObjectState.LevelUp);
			}
			m_BattleController.ShowLevelUp();
		}
		else if (m_BattleController.current == this)
		{
			SetBattleObjState(BattleObjectState.ActionOverPost);
		}
	}

	private void RunBuffEffectBeforMove()
	{
		foreach (BuffData buff in m_Buffs)
		{
			switch (buff.name)
			{
			case "Poisonturn":
			case "Hurtturn":
			case "Bleedturn":
			case "Madturn":
			case "Burnturn":
			case "Drunkturn":
			{
				float value = buff.value;
				string text = buff.name.Replace("turn", "");
				charadata.Indexs_Name[text].fightValue += value;
				string damageinfo = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " " + ((value > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? (value * 100f) : value) + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "") + "</color>";
				AddDamageInfo(damageinfo, text);
				break;
			}
			case "SuperWugongXiBo1":
			{
				float value = buff.value;
				string text = "Poison";
				charadata.Indexs_Name[text].fightValue += value;
				string damageinfo = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " " + ((value > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? (value * 100f) : value) + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "") + "</color>";
				AddDamageInfo(damageinfo, text);
				text = "Hurt";
				charadata.Indexs_Name[text].fightValue += value;
				damageinfo = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " " + ((value > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? (value * 100f) : value) + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "") + "</color>";
				AddDamageInfo(damageinfo, text);
				text = "Bleed";
				charadata.Indexs_Name[text].fightValue += value;
				damageinfo = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " " + ((value > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? (value * 100f) : value) + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "") + "</color>";
				AddDamageInfo(damageinfo, text);
				text = "Mad";
				charadata.Indexs_Name[text].fightValue += value;
				damageinfo = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " " + ((value > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? (value * 100f) : value) + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "") + "</color>";
				AddDamageInfo(damageinfo, text);
				text = "Burn";
				charadata.Indexs_Name[text].fightValue += value;
				damageinfo = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " " + ((value > 0f) ? "<color=#e74722>+" : "<color=#7fd142>") + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? (value * 100f) : value) + (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "") + "</color>";
				AddDamageInfo(damageinfo, text);
				break;
			}
			case "ClearDebuffTurn":
				SkillKeyWordManage.ClearDebuffFunction(this, this, 1f);
				break;
			}
		}
	}

	private void Deal_AppendTraitInfos()
	{
		string[] array = SharedData.Instance().m_AppendTraitInfos.Split('|');
		SharedData.Instance().m_AppendTraitInfos = "";
		for (int i = 1; i < array.Length; i++)
		{
			if (SharedData.Instance().m_AppendTraitInfos.Length > 0)
			{
				SharedData.Instance().m_AppendTraitInfos += "|";
			}
			SharedData.Instance().m_AppendTraitInfos += array[i];
		}
		string[] array2 = array[0].Split('&');
		if (array2.Length > 1)
		{
			m_MenuController.OpenInteruptInfo(this, array2[0], array2[1]);
		}
		else
		{
			m_MenuController.OpenInteruptInfo(this, array2[0]);
		}
	}

	public void LetUsReturn()
	{
		Vector3Int gridPosition = GetGridPosition();
		Vector3Int gridPosition2 = m_Revenge_Target.GetGridPosition();
		string revenge_TGTSkill = m_BattleController.m_Revenge_TGTSkill;
		currentForecast = new Forecast
		{
			actionPos = gridPosition,
			targetPos = gridPosition2,
			actionName = revenge_TGTSkill
		};
		InteruptIn(BattleObjectState.ActionInit);
	}

	public void LetUsAmbush()
	{
		Vector3Int gridPosition = GetGridPosition();
		Vector3Int gridPosition2 = m_Revenge_Target.GetGridPosition();
		List<int> list = new List<int>();
		for (int i = 0; i < m_SkillList.Count; i++)
		{
			string[] array = m_SkillList[i].Split('|');
			KongFuData kongFuByID = charadata.GetKongFuByID(array[0]);
			if (kongFuByID != null && kongFuByID.isAttackSkill && array[3] == "1" && (!(array[1] == "A") || !(array[2] == "06")) && !(array[1] == "B"))
			{
				list.Add(i);
			}
		}
		if (list.Count != 0)
		{
			int index = list[UnityEngine.Random.Range(0, list.Count)];
			string actionName = m_SkillList[index];
			currentForecast = new Forecast
			{
				actionPos = gridPosition,
				targetPos = gridPosition2,
				actionName = actionName
			};
			InteruptIn(BattleObjectState.ActionInit);
		}
		else
		{
			LetUsFanTan();
		}
	}

	public void LetUsFanTan()
	{
		Vector3Int gridPosition = GetGridPosition();
		Vector3Int gridPosition2 = m_Revenge_Target.GetGridPosition();
		currentForecast = new Forecast
		{
			actionPos = gridPosition,
			targetPos = gridPosition2,
			actionName = "NORMALATK|C|01|1|0|MP-GOOD|0"
		};
		InteruptIn(BattleObjectState.ActionInit);
	}

	public void LetUsWugongCounter()
	{
		Vector3Int gridPosition = GetGridPosition();
		Vector3Int gridPosition2 = m_Revenge_Target.GetGridPosition();
		string actionName = counterWugong.kf.ID + "|" + counterWugong.kf.Attckstyle + "|" + counterWugong.lv + "|MP-GOOD|" + 0;
		currentForecast = new Forecast
		{
			actionPos = gridPosition,
			targetPos = gridPosition2,
			actionName = actionName
		};
		InteruptIn(BattleObjectState.ActionInit);
		counterWugong = null;
	}

	public void LetUsFormless()
	{
		Vector3Int gridPosition = GetGridPosition();
		Vector3Int gridPosition2 = m_Revenge_Target.GetGridPosition();
		string revenge_TGTSkill = m_BattleController.m_Revenge_TGTSkill;
		currentForecast = new Forecast
		{
			actionPos = gridPosition,
			targetPos = gridPosition2,
			actionName = revenge_TGTSkill
		};
		InteruptIn(BattleObjectState.ActionInit);
	}

	public void LetUsWugongAssist()
	{
		Vector3Int gridPosition = GetGridPosition();
		currentForecast = new Forecast
		{
			actionPos = gridPosition,
			targetPos = m_Assist_Pos,
			actionName = m_Assist_Skill
		};
		m_Assist_Skill = "";
		InteruptIn(BattleObjectState.ActionInit);
	}

	public void AddDamageInfo(string _damageinfo, string _type, bool _critical = false)
	{
		if (!(_type == ""))
		{
			string[] array = _damageinfo.Split('|');
			string[] array2 = _type.Split('|');
			int beat = 0;
			if (array2.Length > 1)
			{
				beat = int.Parse(array2[1]);
			}
			string[] array3 = array;
			foreach (string damage in array3)
			{
				DisplayDamage displayDamage = new DisplayDamage();
				displayDamage.damage = damage;
				displayDamage.type = array2[0];
				displayDamage.beat = beat;
				displayDamage.damageObj = null;
				displayDamage.critical = _critical;
				m_DamageList.Add(displayDamage);
			}
		}
	}

	public void AddBuffInfo(string _type, string _dmg = "")
	{
		DisplayBuff displayBuff = new DisplayBuff();
		displayBuff.type = _type;
		displayBuff.str = _dmg;
		displayBuff.buffObj = null;
		m_BuffList.Add(displayBuff);
	}

	public void UpdateDamageList()
	{
		if (m_DamageList.Count == 0)
		{
			return;
		}
		List<DisplayDamage> list = new List<DisplayDamage>();
		foreach (DisplayDamage damage in m_DamageList)
		{
			if (damage.type == "DELETE")
			{
				list.Add(damage);
			}
		}
		foreach (DisplayDamage item in list)
		{
			if (item.damageObj != null)
			{
				UnityEngine.Object.Destroy(item.damageObj);
			}
			m_DamageList.Remove(item);
		}
		if (m_DamageList.Count <= 0)
		{
			return;
		}
		float time = Time.time;
		if (time - m_DisplayDamageMark < 0.1f)
		{
			return;
		}
		foreach (DisplayDamage damage2 in m_DamageList)
		{
			if (damage2.damageObj == null)
			{
				StartCoroutine(DisplayDamageInfo(damage2));
				m_DisplayDamageMark = time;
				break;
			}
		}
	}

	private void UpdateBuffList()
	{
		float time = Time.time;
		if (time - m_DisplayBuffMark < 0.5f)
		{
			return;
		}
		DisplayBuff displayBuff = null;
		foreach (DisplayBuff buff in m_BuffList)
		{
			if (buff.buffObj == null)
			{
				displayBuff = buff;
				break;
			}
		}
		if (displayBuff != null)
		{
			DisplayBuffInfo(displayBuff, m_BuffList.Count > 1);
			m_DisplayBuffMark = time;
			m_BuffList.Remove(displayBuff);
		}
	}

	protected IEnumerator DisplayDamageInfo(DisplayDamage _displaydamage)
	{
		yield return null;
		bool isBuffs = false;
		GameObject original;
		switch (_displaydamage.type)
		{
		case "Drunk":
		case "Hurt":
		case "Poison":
		case "Bleed":
		case "Burn":
		case "Seal":
		case "Mad":
		case "Crit":
		case "Crit1":
		case "Combo":
		case "Rebound":
		case "ATK":
		case "DEF":
		case "SP":
		case "ATKdown":
		case "DEFdown":
		case "SPdown":
		case "HPturn":
		case "MPturn":
		case "Medical":
		case "Melody":
		case "Steal":
		case "SCP99ME":
			isBuffs = true;
			original = CommonResourcesData.m_BuffsPrefab;
			break;
		case "MP":
			SetMp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_MpPrefab;
			break;
		case "POISON":
			if (SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture), diehard: true))
			{
				_displaydamage.damage = "0";
			}
			original = CommonResourcesData.m_PoisonPrefab;
			break;
		case "TerrainPOISON":
			SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_PoisonPrefab;
			break;
		case "SCP99YOU":
			if (SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture), diehard: true))
			{
				_displaydamage.damage = "0";
			}
			original = ((!_displaydamage.critical) ? CommonResourcesData.m_DamagePrefab : CommonResourcesData.m_CriticalPrefab);
			break;
		case "BLEED":
			SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_BleedPrefab;
			break;
		case "BURN":
			SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_BurnPrefab;
			break;
		case "TerrainBURN":
			SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_BurnPrefab;
			break;
		case "Blast":
		case "BlastSputter":
			SetHp(0f - float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			if (isInvisible)
			{
				SetInvisible(_Invisible: false);
			}
			original = CommonResourcesData.m_BurnPrefab;
			break;
		case "HEAL":
			SetHp((int)float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_HealPrefab;
			break;
		case "HEALMP":
			SetMp(float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			original = CommonResourcesData.m_MpPrefab;
			break;
		case "SKILL-PLAYER":
			original = CommonResourcesData.m_SkillNamePrefab;
			break;
		case "SKILL-ENEMY":
			original = CommonResourcesData.m_SkillNamePrefab;
			break;
		case "DAMAGE":
			SetHp(-(int)float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture));
			if (isInvisible)
			{
				SetInvisible(_Invisible: false);
			}
			original = ((!_displaydamage.critical) ? CommonResourcesData.m_DamagePrefab : CommonResourcesData.m_CriticalPrefab);
			break;
		case "EXP":
			original = CommonResourcesData.m_ExpPrefab;
			break;
		case "Imapct":
			original = CommonResourcesData.m_DamagePrefab;
			break;
		default:
			original = ((!_displaydamage.critical) ? CommonResourcesData.m_InfoPrefab : CommonResourcesData.m_CriticalPrefab);
			break;
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(original, base.transform);
		_displaydamage.damageObj = gameObject;
		TextMeshPro componentInChildren = gameObject.GetComponentInChildren<TextMeshPro>();
		switch (_displaydamage.type)
		{
		case "Drunk":
		case "Hurt":
		case "Poison":
		case "Bleed":
		case "Burn":
		case "Seal":
		case "Mad":
		case "Crit":
		case "Crit1":
		case "Combo":
		case "Rebound":
		case "ATK":
		case "DEF":
		case "SP":
		case "ATKdown":
		case "DEFdown":
		case "SPdown":
		case "HPturn":
		case "MPturn":
		case "Medical":
		case "Melody":
		case "Steal":
			componentInChildren.text = _displaydamage.damage;
			break;
		case "MP":
			componentInChildren.text = "-" + _displaydamage.damage;
			break;
		case "POISON":
		case "TerrainPOISON":
			componentInChildren.text = "-" + _displaydamage.damage;
			break;
		case "BLEED":
			componentInChildren.text = "-" + _displaydamage.damage;
			break;
		case "BURN":
		case "TerrainBURN":
			componentInChildren.text = "-" + _displaydamage.damage;
			break;
		case "HEAL":
			componentInChildren.text = ((int)float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture)).ToString();
			break;
		case "HEALMP":
			componentInChildren.text = "+" + (int)float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture);
			break;
		case "SKILL-PLAYER":
			componentInChildren.text = _displaydamage.damage;
			break;
		case "SKILL-ENEMY":
			componentInChildren.text = _displaydamage.damage;
			break;
		case "DAMAGE":
			componentInChildren.text = ((int)float.Parse(_displaydamage.damage, CultureInfo.InvariantCulture)).ToString();
			break;
		case "EXP":
			componentInChildren.text = CommonFunc.I18nGetLocalizedValue("I18N_ExpAdd") + _displaydamage.damage;
			break;
		case "Impact":
			componentInChildren.text = CommonFunc.I18nGetLocalizedValue("I18N_ImpactDamage") + _displaydamage.damage;
			break;
		default:
			componentInChildren.text = _displaydamage.damage;
			break;
		}
		Color color = componentInChildren.color;
		color.a = 0f;
		componentInChildren.color = color;
		RectTransform rectTransform = componentInChildren.rectTransform;
		if (isBuffs || _displaydamage.type == "SKILL-PLAYER" || _displaydamage.type == "SKILL-ENEMY" || _displaydamage.type == "EXP")
		{
			rectTransform.localScale = new Vector3(0f, 0f, 1f);
		}
		else
		{
			rectTransform.localScale = new Vector3(9f, 9f, 1f);
		}
		if (_displaydamage.type == "SKILL-PLAYER" || _displaydamage.type == "SKILL-ENEMY")
		{
			rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, rectTransform.anchoredPosition.y + 110f);
		}
		else if (isBuffs)
		{
			rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, rectTransform.anchoredPosition.y + 55f - 20f * (float)m_BuffCount);
			m_BuffCount++;
		}
		else if (_displaydamage.type == "DAMAGE" || _displaydamage.type == "Impact")
		{
			rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x + UnityEngine.Random.Range(-6f * (float)_displaydamage.beat, 6f * (float)_displaydamage.beat), rectTransform.anchoredPosition.y + 80f + UnityEngine.Random.Range(-8f * (float)_displaydamage.beat, 3f * (float)_displaydamage.beat));
		}
		else if (_displaydamage.type == "EXP")
		{
			rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, rectTransform.anchoredPosition.y + 75f);
		}
		else
		{
			rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, rectTransform.anchoredPosition.y + 80f);
		}
		_displaydamage.isShow = true;
		Sequence sequence = DOTween.Sequence();
		if (_displaydamage.type != "EXP")
		{
			Tweener t = rectTransform.DOScale(new Vector3(1.5f, 1.5f, 1f), 0.15f);
			Tweener t2 = rectTransform.DOMoveY(rectTransform.position.y + 10f, 0.15f);
			Tweener t3 = rectTransform.DOMoveY(rectTransform.position.y + 15f, 1f / (float)((_displaydamage.beat <= 0) ? 1 : _displaydamage.beat));
			Tweener t4 = rectTransform.DOMoveY(rectTransform.position.y + 45f, 0.1f);
			Tweener t5 = componentInChildren.DOColor(new Color(color.r, color.g, color.b, 1f), 0.03f);
			Tweener t6 = componentInChildren.DOColor(new Color(color.r, color.g, color.b, 0f), 0.15f);
			sequence.Append(t);
			sequence.Join(t5);
			sequence.Join(t2);
			if (_displaydamage.type == "DAMAGE" && _displaydamage.critical)
			{
				sequence.Join(gameObject.transform.Find("text/crit").GetComponent<SpriteRenderer>().DOFade(0.7f, 0.03f));
			}
			else if (_displaydamage.type == "SKILL-PLAYER" || _displaydamage.type == "SKILL-ENEMY")
			{
				sequence.Join(gameObject.transform.Find("text/crit").GetComponent<SpriteRenderer>().DOFade(1f, 0.03f));
			}
			sequence.Append(t3);
			sequence.Append(t4);
			sequence.Join(t6);
			if (_displaydamage.type == "DAMAGE" && _displaydamage.critical)
			{
				sequence.Join(gameObject.transform.Find("text/crit").GetComponent<SpriteRenderer>().DOFade(0f, 0.15f));
			}
			else if (_displaydamage.type == "SKILL-PLAYER" || _displaydamage.type == "SKILL-ENEMY")
			{
				sequence.Join(gameObject.transform.Find("text/crit").GetComponent<SpriteRenderer>().DOFade(0f, 0.15f));
			}
		}
		else
		{
			sequence.Append(rectTransform.DOScale(new Vector3(1.5f, 1.5f, 1f), 0.15f));
			sequence.Join(componentInChildren.DOColor(new Color(color.r, color.g, color.b, 1f), 0.03f));
			sequence.Append(rectTransform.DOMoveY(rectTransform.position.y + 5f, 1f));
			sequence.Append(componentInChildren.DOColor(new Color(color.r, color.g, color.b, 0f), 0.15f));
		}
		sequence.OnComplete(delegate
		{
			if (isBuffs)
			{
				m_BuffCount--;
			}
			_displaydamage.type = "DELETE";
		});
		StartCoroutine(BehitFinal());
	}

	protected void DisplayBuffInfo(DisplayBuff _displaybuff, bool _diffposition = false)
	{
		GameObject original = null;
		switch (_displaybuff.type)
		{
		case "bleed":
			original = CommonResourcesData.Buff_bleed_Prefab;
			break;
		case "buffATK":
			original = CommonResourcesData.Buff_buffATK_Prefab;
			break;
		case "buffDEF":
			original = CommonResourcesData.Buff_buffDEF_Prefab;
			break;
		case "buffSP":
			original = CommonResourcesData.Buff_buffSP_Prefab;
			break;
		case "burn":
			original = CommonResourcesData.Buff_burn_Prefab;
			break;
		case "combo":
			original = CommonResourcesData.Buff_combo_Prefab;
			break;
		case "counter":
			original = CommonResourcesData.Buff_counter_Prefab;
			break;
		case "crit":
			original = CommonResourcesData.Buff_crit_Prefab;
			break;
		case "debuffATK":
			original = CommonResourcesData.Buff_debuffATK_Prefab;
			break;
		case "debuffDEF":
			original = CommonResourcesData.Buff_debuffDEF_Prefab;
			break;
		case "debuffSP":
			original = CommonResourcesData.Buff_debuffSP_Prefab;
			break;
		case "drunk":
			original = CommonResourcesData.Buff_drunk_Prefab;
			break;
		case "fend":
			original = CommonResourcesData.Buff_fendicon_Prefab;
			break;
		case "hpsteal":
			original = CommonResourcesData.Buff_hpstealicon_Prefab;
			break;
		case "hurt":
			original = CommonResourcesData.Buff_hurt_Prefab;
			break;
		case "mad":
			original = CommonResourcesData.Buff_mad_Prefab;
			break;
		case "MPburn":
			SetMp(0f - float.Parse(_displaybuff.str, CultureInfo.InvariantCulture));
			original = CommonResourcesData.Buff_mpburnicon_Prefab;
			break;
		case "mpsteal":
			SetMp(0f - float.Parse(_displaybuff.str, CultureInfo.InvariantCulture));
			original = CommonResourcesData.Buff_mpstealicon_Prefab;
			break;
		case "HPstealresist":
			original = CommonResourcesData.Buff_hpstealicon_Prefab;
			break;
		case "MPstealresist":
			original = CommonResourcesData.Buff_mpstealicon_Prefab;
			break;
		case "poison":
			original = CommonResourcesData.Buff_poison_Prefab;
			break;
		case "rebound":
			original = CommonResourcesData.Buff_reboundicon_Prefab;
			break;
		case "seal":
			original = CommonResourcesData.Buff_seal_Prefab;
			break;
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(original, base.transform);
		if (_diffposition)
		{
			gameObject.transform.localPosition = new Vector2(gameObject.transform.localPosition.x + UnityEngine.Random.Range(-10f, 10f), gameObject.transform.localPosition.y + UnityEngine.Random.Range(-15f, 15f));
		}
		switch (_displaybuff.type)
		{
		case "hpsteal":
		case "mpsteal":
		case "MPburn":
			gameObject.GetComponentInChildren<TextMeshPro>().text = "-" + _displaybuff.str;
			break;
		case "hpstealresist":
		case "mpstealresist":
			gameObject.GetComponentInChildren<TextMeshPro>().text = " " + _displaybuff.str;
			break;
		}
		_displaybuff.buffObj = gameObject;
	}

	public void ShowHpGauge()
	{
		hp_gauge.gameObject.SetActive(value: true);
		hp_gauge.fillPercent = charadata.m_Hp / charadata.GetBattleValueByName("HP");
	}

	protected IEnumerator HideHpGuage()
	{
		yield return new WaitForSeconds(2f);
		hp_gauge.gameObject.SetActive(value: false);
	}

	public void HideHpGuageImmediate()
	{
		hp_gauge.gameObject.SetActive(value: false);
	}

	public void ShowActionOrder(int order = 0)
	{
		if (m_orderInfo == null)
		{
			m_orderInfo = UnityEngine.Object.Instantiate(CommonResourcesData.m_NextOrderInfoPrefab, base.transform);
		}
		m_orderInfo.SetActive(value: true);
		m_orderInfo.transform.Find("NextIcon").gameObject.SetActive(value: false);
		if (order != 0)
		{
			m_orderInfo.transform.Find("Order").gameObject.SetActive(value: true);
			m_orderInfo.transform.Find("Order/Value").GetComponent<Text>().text = order.ToString();
		}
	}

	public void ShowIsPokemon()
	{
		if (m_orderInfo == null)
		{
			m_orderInfo = UnityEngine.Object.Instantiate(CommonResourcesData.m_NextOrderInfoPrefab, base.transform);
		}
		m_orderInfo.SetActive(value: true);
		m_orderInfo.transform.Find("NextIcon").gameObject.SetActive(value: false);
		m_orderInfo.transform.Find("IsPokemon").gameObject.SetActive(isPokemon);
	}

	public void CloseIsPokemon()
	{
		if (!(m_orderInfo == null))
		{
			m_orderInfo.transform.Find("IsPokemon").gameObject.SetActive(value: false);
		}
	}

	public void CloseActionOrder()
	{
		m_orderInfo?.transform.Find("Order").gameObject.SetActive(value: false);
	}

	public void ShowNextActionIcon()
	{
		if (m_orderInfo == null)
		{
			m_orderInfo = UnityEngine.Object.Instantiate(CommonResourcesData.m_NextOrderInfoPrefab, base.transform);
		}
		m_orderInfo.transform.Find("Order").gameObject.SetActive(value: false);
		m_orderInfo.transform.Find("NextIcon").gameObject.SetActive(value: true);
	}

	public void HideNextActionIcon()
	{
		if (m_orderInfo != null)
		{
			m_orderInfo.transform.Find("Order").gameObject.SetActive(value: false);
			m_orderInfo.transform.Find("NextIcon").gameObject.SetActive(value: false);
		}
	}

	private void KnockBackPass(int Fend1, Vector3Int pos, float _injury)
	{
		BattleObject battleObjectInPos = m_BattleController.GetBattleObjectInPos(pos, this);
		if (battleObjectInPos != null)
		{
			if (battleObjectInPos.isSealFreeze && _injury > 0f)
			{
				battleObjectInPos.UnSealFreeze();
				battleObjectInPos.InteruptIn(BattleObjectState.HandOut);
			}
			battleObjectInPos.AdjustFace(m_BattleController.current.GetGridPosition());
			_injury *= 1f + m_BattleController.current.charadata.GetBattleValueByName("AccidentalInjury");
			battleObjectInPos.AddDamageInfo(((int)(_injury * 0.3f)).ToString(), "DAMAGE|1");
			battleObjectInPos.AddBuffInfo("fend");
			battleObjectInPos.PlayAnimation(Aniname.aniname_behit, loop: true, compensate: true, forcerepeat: true);
			battleObjectInPos.PlayAudioClip(AudioClipEnum.damageClip);
			battleObjectInPos.KnockBack(Fend1, _injury);
		}
	}

	public bool KnockBack(int Fend1, float _injury)
	{
		BuffData buffByName = GetBuffByName("Goldenbell");
		if (buffByName != null)
		{
			RemoveBuff(buffByName);
			AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_LostGoldenbell"), "");
		}
		bool result = false;
		foreach (KeyValuePair<string, string> item in charadata.m_EquipTraitDict)
		{
			if (!(item.Value == ""))
			{
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.Value);
				if ("Fendresist" == row.add1 || "Fendresist" == row.add2 || "Fendresist" == row.add3 || "Fendresist" == row.add4)
				{
					return result;
				}
			}
		}
		if (charadata.m_currentTitleID != "")
		{
			gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(charadata.m_currentTitleID);
			if ("Fendresist" == row2.add1 || "Fendresist" == row2.add2 || "Fendresist" == row2.add3 || "Fendresist" == row2.add4)
			{
				return result;
			}
		}
		if (Fend1 <= 0)
		{
			return Gargantua(Mathf.Abs(Fend1), _injury);
		}
		Vector3Int vector3Int = GetGridPosition();
		Vector3Int vector3Int2 = m_BattleController.current.GetGridPosition() - vector3Int;
		Direction direction = Direction.Down;
		if (vector3Int2.x > 0 && vector3Int2.x >= vector3Int2.y)
		{
			direction = Direction.Left;
		}
		else if (vector3Int2.x < 0 && Mathf.Abs(vector3Int2.x) >= vector3Int2.y)
		{
			direction = Direction.Right;
		}
		else if (vector3Int2.y > 0)
		{
			direction = Direction.Up;
		}
		else if (vector3Int2.y < 0)
		{
			direction = Direction.Down;
		}
		if (SharedData.Instance().m_BattleController.GetCurrentObjActionType() == ActionType.Ambush || SharedData.Instance().m_BattleController.GetCurrentObjActionType() == ActionType.Fantan)
		{
			direction = m_Direction;
			switch (m_Direction)
			{
			case Direction.Up:
				direction = Direction.Down;
				break;
			case Direction.Down:
				direction = Direction.Up;
				break;
			case Direction.Right:
			case Direction.Left:
				direction = m_Direction;
				break;
			}
		}
		Vector3Int vector3Int3 = Vector3Int.zero;
		int i = 0;
		Vector3Int nextPos = Vector3Int.zero;
		for (; i < Fend1; i++)
		{
			switch (direction)
			{
			case Direction.Up:
				vector3Int3 = vector3Int - Vector3Int.up;
				break;
			case Direction.Down:
				vector3Int3 = vector3Int + Vector3Int.up;
				break;
			case Direction.Left:
				vector3Int3 = vector3Int - Vector3Int.right;
				break;
			case Direction.Right:
				vector3Int3 = vector3Int + Vector3Int.right;
				break;
			}
			nextPos = vector3Int3;
			if (m_BattleController.IsBlock(vector3Int3))
			{
				break;
			}
			vector3Int = vector3Int3;
		}
		if (i >= 0)
		{
			if (UnityEngine.Random.Range(0f, 1f) < m_BattleController.current.charadata.GetBattleValueByName("ImpactAttackDizzy"))
			{
				AddBuff("Dizzy", "Skill", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_QuickMove"));
			}
			StartCoroutine(KnockBackMove(Fend1, GetGridPosition(), vector3Int, nextPos, Fend1 - i, _injury));
			result = true;
		}
		m_TotalFendBackNumber = Fend1;
		m_RealFendBackNumber = i;
		return result;
	}

	public bool Gargantua(int Gend1, float _injury)
	{
		bool result = false;
		if (Gend1 <= 0)
		{
			return result;
		}
		Vector3Int vector3Int = GetGridPosition();
		Vector3Int vector3Int2 = Vector3Int.zero;
		int i = 0;
		Vector3Int zero = Vector3Int.zero;
		for (; i < Gend1; i++)
		{
			switch (m_Direction)
			{
			case Direction.Up:
				vector3Int2 = vector3Int - Vector3Int.up;
				break;
			case Direction.Down:
				vector3Int2 = vector3Int + Vector3Int.up;
				break;
			case Direction.Left:
				vector3Int2 = vector3Int + Vector3Int.right;
				break;
			case Direction.Right:
				vector3Int2 = vector3Int - Vector3Int.right;
				break;
			}
			if (m_BattleController.IsBlock(vector3Int2))
			{
				break;
			}
			vector3Int = vector3Int2;
		}
		if (i > 0)
		{
			StartCoroutine(KnockBackMove(Gend1, GetGridPosition(), vector3Int, zero, Gend1 - i, _injury));
			result = true;
		}
		return result;
	}

	private IEnumerator KnockBackMove(int TotalFend, Vector3Int _StartPos, Vector3Int _TargetPos, Vector3Int NextPos, int fend, float _injury)
	{
		SkeletonAnimation dustSkeletonAnimation = null;
		if (_StartPos != _TargetPos)
		{
			Vector3Int vector3Int = _StartPos - _TargetPos;
			Vector3Int prevGrid = _StartPos;
			Vector3Int currentGrid = _StartPos;
			Vector3Int tmpGrid = Vector3Int.zero;
			Vector3 tmpPos = Vector3.zero;
			int moveBlockLength = Mathf.Abs(vector3Int.x) + Mathf.Abs(vector3Int.y);
			AdjustAnimationSpeed(0.1f, Color.white);
			Vector3 _startPos = new Vector3(25f + (float)_StartPos.x * 50f, -25f - (float)_StartPos.y * 50f, 0f);
			Vector3 _targetPos = new Vector3(25f + (float)_TargetPos.x * 50f, -25f - (float)_TargetPos.y * 50f, 0f);
			float m_KnockBackMoveTimer = 0f;
			float ratio = m_KnockBackMoveTimer / (CommonVariables.TimeToMoveOneBlock * (float)moveBlockLength);
			float t = Mathf.Pow(ratio, 0.5f);
			Vector2 pos = Vector2.Lerp(_startPos, _targetPos, t);
			GameObject gameObject = UnityEngine.Object.Instantiate(CommonResourcesData.m_DustPrefab, base.gameObject.transform);
			Vector3Int vector3Int2 = _TargetPos - _StartPos;
			if (vector3Int2.x != 0)
			{
				if (vector3Int2.x > 0)
				{
					gameObject.transform.localPosition = new Vector3(-15f, -10f, 0f);
					gameObject.transform.localScale = new Vector3(30f, 30f, 1f);
				}
				else
				{
					gameObject.transform.localPosition = new Vector3(15f, -10f, 0f);
					gameObject.transform.localScale = new Vector3(-30f, 30f, 1f);
				}
			}
			else if (vector3Int2.y != 0)
			{
				if (vector3Int2.y > 0)
				{
					Quaternion localRotation = Quaternion.Euler(0f, 0f, -90f);
					gameObject.transform.localPosition = new Vector3(0f, 50f, 0f);
					gameObject.transform.localRotation = localRotation;
					gameObject.transform.localScale = new Vector3(30f, 30f, 1f);
				}
				else
				{
					Quaternion localRotation2 = Quaternion.Euler(0f, 0f, 90f);
					gameObject.transform.localPosition = new Vector3(0f, -30f, 0f);
					gameObject.transform.localRotation = localRotation2;
					gameObject.transform.localScale = new Vector3(30f, 30f, 1f);
				}
			}
			dustSkeletonAnimation = gameObject.GetComponent<SkeletonAnimation>();
			TrackEntry trackEntry = dustSkeletonAnimation.AnimationState.SetAnimation(0, "animation", loop: true);
			trackEntry.AnimationStart = 0f;
			trackEntry.AnimationEnd = 0.2f;
			while (ratio < 1f)
			{
				prevGrid.x = Mathf.FloorToInt(pos.x / CommonVariables.MovementBlockSize);
				prevGrid.y = Mathf.FloorToInt(Mathf.Abs(pos.y) / CommonVariables.MovementBlockSize);
				m_KnockBackMoveTimer += Time.deltaTime * 1.5f;
				ratio = m_KnockBackMoveTimer / (CommonVariables.TimeToMoveOneBlock * (float)moveBlockLength);
				t = Mathf.Pow(ratio, 0.5f);
				pos = Vector2.Lerp(_startPos, _targetPos, t);
				currentGrid.x = Mathf.FloorToInt(pos.x / CommonVariables.MovementBlockSize);
				currentGrid.y = Mathf.FloorToInt(Mathf.Abs(pos.y) / CommonVariables.MovementBlockSize);
				if (prevGrid != currentGrid)
				{
					if (prevGrid.x != currentGrid.x)
					{
						int num = prevGrid.x - currentGrid.x;
						for (int i = 0; i < Mathf.Abs(num); i++)
						{
							tmpGrid.x = prevGrid.x + ((num < 0) ? i : (-i));
							tmpGrid.y = currentGrid.y;
							tmpPos.x = 25f + (float)tmpGrid.x * 50f;
							tmpPos.y = -25f - (float)tmpGrid.y * 50f;
							if (!m_BattleController.terrain.ContainsKey(tmpGrid) || (charadata.GetBattleValueByName("TrapImmune") > 0f && (SharedData.Instance().m_BattleController.terrain[tmpGrid].t_type == TerrainType.TrapBlast || SharedData.Instance().m_BattleController.terrain[tmpGrid].t_type == TerrainType.TrapSeal)))
							{
								continue;
							}
							TerrainType t_type = m_BattleController.terrain[tmpGrid].t_type;
							m_BattleController.terrain[tmpGrid].TerrainEffectOn();
							switch (t_type)
							{
							case TerrainType.Hell:
							case TerrainType.Water:
								break;
							case TerrainType.TrapSeal:
								if (charadata.GetBattleValueByName("Seal") >= 25f)
								{
									isPerforming = false;
								}
								continue;
							default:
								continue;
							}
							ratio = 1f;
							base.gameObject.transform.position = tmpPos;
							break;
						}
					}
					else
					{
						int num = prevGrid.y - currentGrid.y;
						for (int j = 0; j < Mathf.Abs(num); j++)
						{
							tmpGrid.x = currentGrid.x;
							tmpGrid.y = prevGrid.y + ((num < 0) ? j : (-j));
							tmpPos.x = 25f + (float)tmpGrid.x * 50f;
							tmpPos.y = -25f - (float)tmpGrid.y * 50f;
							if (!m_BattleController.terrain.ContainsKey(tmpGrid) || (charadata.GetBattleValueByName("TrapImmune") > 0f && (SharedData.Instance().m_BattleController.terrain[tmpGrid].t_type == TerrainType.TrapBlast || SharedData.Instance().m_BattleController.terrain[tmpGrid].t_type == TerrainType.TrapSeal)))
							{
								continue;
							}
							TerrainType t_type2 = m_BattleController.terrain[tmpGrid].t_type;
							m_BattleController.terrain[tmpGrid].TerrainEffectOn();
							switch (t_type2)
							{
							case TerrainType.Hell:
							case TerrainType.Water:
								break;
							case TerrainType.TrapSeal:
								if (charadata.GetBattleValueByName("Seal") >= 25f)
								{
									isPerforming = false;
								}
								continue;
							default:
								continue;
							}
							ratio = 1f;
							base.gameObject.transform.position = tmpPos;
							break;
						}
					}
					prevGrid = currentGrid;
				}
				base.gameObject.transform.position = pos;
				yield return null;
			}
			if (!isDead && m_BattleController.terrain.ContainsKey(_TargetPos) && (!(charadata.GetBattleValueByName("TrapImmune") > 0f) || (SharedData.Instance().m_BattleController.terrain[tmpGrid].t_type != TerrainType.TrapBlast && SharedData.Instance().m_BattleController.terrain[tmpGrid].t_type != TerrainType.TrapSeal)))
			{
				m_BattleController.terrain[_TargetPos].TerrainEffectOn();
			}
			Mathf.Repeat(m_KnockBackMoveTimer, CommonVariables.TimeToMoveOneBlock * (float)moveBlockLength);
		}
		if (charadata.m_Hp > 0f)
		{
			if (charadata.GetBattleValueByName("Seal") < 25f)
			{
				AdjustAnimationSpeed(1f, Color.white);
			}
		}
		else if (!m_BattleController.terrain.ContainsKey(GetGridPosition()) || m_BattleController.terrain[GetGridPosition()].t_type == TerrainType.Hell || m_BattleController.terrain[GetGridPosition()].t_type == TerrainType.Water)
		{
			AdjustAnimationSpeed(1f, Color.white);
		}
		if (dustSkeletonAnimation != null)
		{
			TrackEntry trackEntry2 = dustSkeletonAnimation.AnimationState.SetAnimation(0, "animation", loop: false);
			trackEntry2.AnimationStart = 0f;
			trackEntry2.AnimationEnd = 1f;
		}
		if (GetGridPosition() == _TargetPos)
		{
			if (fend > 0)
			{
				KnockBackPass(fend, NextPos, _injury);
			}
			else if (m_BattleController.GetBattleObjectInPos(_TargetPos, this) != null)
			{
				KnockBackPass(1, NextPos, _injury);
			}
		}
	}

	public IEnumerator GatherMove(Vector3 _pos)
	{
		AdjustFace(m_BattleController.current.GetGridPosition());
		PlayAnimation(Aniname.aniname_walk);
		_ = Vector3.zero;
		isPerforming = true;
		Vector3 startPos = base.transform.position;
		float timer = 0f;
		while (timer < 1f)
		{
			timer += Time.deltaTime;
			base.transform.position = Vector3.Lerp(startPos, _pos, timer);
			yield return new WaitForSeconds(Time.deltaTime);
		}
		PlayAnimation(Aniname.aniname_stand);
		isPerforming = false;
	}

	public string GetEffectOnSuperWugongID()
	{
		foreach (string item in charadata.m_KongFuListInBattle)
		{
			foreach (KongFuData k in charadata.m_KongFuList)
			{
				if (k.kf.ID.Equals(item) && k.kf.Style == "9601" && m_Buffs.Find((BuffData x) => x.source.StartsWith("Wugong|" + k.kf.ID + "|" + base.gameObject.name + "|")) != null)
				{
					return k.kf.ID;
				}
			}
		}
		return "";
	}

	public string GetEffectOnFormationWugongID()
	{
		foreach (string item in charadata.m_KongFuListInBattle)
		{
			foreach (KongFuData k in charadata.m_KongFuList)
			{
				if (k.kf.ID.Equals(item) && k.kf.Style == "9101" && m_Buffs.Find((BuffData x) => x.source.StartsWith("Wugong|" + k.kf.ID + "|" + base.gameObject.name + "|")) != null)
				{
					return k.kf.ID;
				}
			}
		}
		return "";
	}

	public bool CheckBuffEffectOn(string buffName)
	{
		return m_Buffs.Find((BuffData x) => x.name == buffName) != null;
	}

	public BuffData GetBuffByName(string buffName)
	{
		return m_Buffs.Find((BuffData x) => x.name == buffName);
	}

	private bool CheckIsGoldenbellEffect()
	{
		if (handInPos == GetGridPosition())
		{
			return CheckBuffEffectOn("Goldenbell");
		}
		return false;
	}

	public bool CheckIsWugongWasBan(gang_b03Table.Row _kf)
	{
		string text = "";
		BuffData buffData = null;
		switch (_kf.Style)
		{
		case "101":
			text = "Sword";
			break;
		case "201":
			text = "Knife";
			break;
		case "301":
			text = "Stick";
			break;
		case "401":
			text = "Hand";
			break;
		case "501":
			text = "Finger";
			break;
		case "601":
			text = "Darts";
			break;
		case "701":
			text = "Melody";
			break;
		case "801":
			text = "Wineart";
			break;
		case "901":
			text = "";
			break;
		case "1001":
			text = "Special";
			break;
		case "9101":
			text = "";
			break;
		case "9301":
			text = "";
			break;
		case "9401":
			text = "";
			break;
		case "9501":
			text = "";
			break;
		case "9601":
			text = "";
			break;
		}
		text = "Ban" + text + "Wugong";
		buffData = GetBuffByName(text);
		if (buffData != null && buffData.turn > 0)
		{
			return true;
		}
		if ((_kf.Style.Equals("101") || _kf.Style.Equals("201") || _kf.Style.Equals("301")) && CheckBuffEffectOn("BanWeaponWugong"))
		{
			return true;
		}
		switch (_kf.Origin)
		{
		case "1":
			text = "BuddhismWugong";
			break;
		case "2":
			text = "TaoistWugong";
			break;
		case "3":
			text = "ConfucianistWugong";
			break;
		case "4":
			text = "HeresyWugong";
			break;
		case "5":
			text = "ZaxueWugong";
			break;
		}
		text = "Ban" + text;
		buffData = GetBuffByName(text);
		if (buffData != null && buffData.turn > 0)
		{
			return true;
		}
		return false;
	}

	private bool ComboCheck()
	{
		bool result = false;
		if (m_Revenge_Target != null || isDead || m_BattleController.m_Flow == BattleControllerFlow.GameSet)
		{
			return result;
		}
		if (m_SkillRow != null && m_ComboRate > 0f)
		{
			float comboRate = m_ComboRate;
			bool flag = false;
			foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
			{
				if (allBattleObj.race != race && !allBattleObj.isDead && attackSelectRange.Contains(allBattleObj.GetGridPosition()))
				{
					flag = true;
				}
			}
			if (UnityEngine.Random.Range(0f, 1f) <= comboRate && flag)
			{
				Attack(Vector3Int.zero, firstHit: false);
				m_ComboRate = comboRate * CommonVariable.ComboReduce[ComboCount++];
				result = true;
				if (ComboCount >= 2 && race.Equals("player"))
				{
					StatsAndAchievements.Instance().UnlockAchievement("1023");
				}
				if (charadata.originRace == "player" && !(race == "player"))
				{
				}
			}
			else
			{
				m_ComboRate = 0f;
			}
		}
		return result;
	}

	private int CheckIsMultiKillOrRunaway()
	{
		float battleValueByName = charadata.GetBattleValueByName("Multikill");
		if (UnityEngine.Random.Range(0f, 1f) < battleValueByName)
		{
			return 1;
		}
		float battleValueByName2 = charadata.GetBattleValueByName("Runaway");
		if (UnityEngine.Random.Range(0f, 1f) < battleValueByName2)
		{
			return 2;
		}
		return -1;
	}

	public bool CheckCouldCounter()
	{
		if (CheckBuffEffectOn("Dizzy") || CheckBuffEffectOn("Fear") || CheckBuffEffectOn("Blind") || charadata.GetBattleValueByName("Mad") >= 255f)
		{
			return false;
		}
		return true;
	}

	public bool CheckHasCounterWugong()
	{
		counterWugongList.Clear();
		float num = 0f;
		foreach (string skill in m_SkillList)
		{
			num = 0f;
			string[] array = skill.Split('|');
			KongFuData kongFuByID = charadata.GetKongFuByID(array[0]);
			if (Mathf.Floor(float.Parse(kongFuByID.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(kongFuByID.kf.Expendadd, CultureInfo.InvariantCulture) * ((float)kongFuByID.lv - 1f)) > charadata.m_Mp)
			{
				continue;
			}
			SkillInfo skillInfo = new SkillInfo();
			skillInfo.Init(kongFuByID, this);
			for (int i = 0; i <= skillInfo.sid; i++)
			{
				if (skillInfo.sName[i] == "Counter")
				{
					num = skillInfo.sOddNum[i];
					break;
				}
			}
			if (num > 0f)
			{
				counterWugongList.Add(kongFuByID, num);
			}
		}
		if (counterWugongList.Count > 0)
		{
			foreach (KeyValuePair<KongFuData, float> counterWugong in counterWugongList)
			{
				if (UnityEngine.Random.Range(0f, 1f) < counterWugong.Value)
				{
					this.counterWugong = counterWugong.Key;
					return true;
				}
			}
		}
		return false;
	}

	public void SelectWuGong(string _type, bool _byhand = false)
	{
		m_AttackType = _type.Split('|');
		RangeManager.ShowAttackRange(this, _type);
		string text = "hand";
		string animation = "";
		if ("NORMALATK".Equals(m_AttackType[0]) || "ITEM".Equals(m_AttackType[0]))
		{
			m_SkillRow = null;
			if ("NORMALATK".Equals(m_AttackType[0]))
			{
				m_SkillRow = new KongFuData();
				m_SkillRow.kf = CommonResourcesData.b03.Find_ID("NORMALATK");
				m_SkillRow.lv = 1;
			}
			text = "hand";
			aniname_attack = "B04-attack-" + text;
			animation = "C04-attackstand-" + text;
			m_BattleObjectAudioManager.attackStandClip = (AudioClip)Resources.Load("Music/Skill/baquan", typeof(AudioClip));
			m_BattleObjectAudioManager.missClip = (AudioClip)Resources.Load("Music/Skill/punch0", typeof(AudioClip));
			m_BattleObjectAudioManager.hitClip = (AudioClip)Resources.Load("Music/Skill/punch1", typeof(AudioClip));
		}
		else
		{
			if (m_Revenge_Target != null && (m_BattleController.GetCurrentObjActionType() == ActionType.Formless || m_BattleController.GetCurrentObjActionType() == ActionType.FormlessSuper))
			{
				m_SkillRow = m_Revenge_Target.charadata.GetKongFuByID(m_AttackType[0]);
			}
			else
			{
				m_SkillRow = charadata.GetKongFuByID(m_AttackType[0]);
			}
			m_ComboRate = 0f;
			m_SkillRow.runtime_style_damage = 0f;
			m_BattleObjectAudioManager.attackStandClip = (AudioClip)Resources.Load("Music/Skill/" + m_SkillRow.kf.Sound + "/stand", typeof(AudioClip));
			m_BattleObjectAudioManager.missClip = (AudioClip)Resources.Load("Music/Skill/" + m_SkillRow.kf.Sound + "/atk-off", typeof(AudioClip));
			m_BattleObjectAudioManager.hitClip = (AudioClip)Resources.Load("Music/Skill/" + m_SkillRow.kf.Sound + "/atk-on", typeof(AudioClip));
			switch (m_SkillRow.kf.Style)
			{
			case "101":
				text = "sword";
				aniname_attack = "B01-attack-" + text;
				animation = "C01-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("SwordATK");
				break;
			case "201":
				text = "knife";
				aniname_attack = "B02-attack-" + text;
				animation = "C02-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("KnifeATK");
				break;
			case "301":
				text = "stick";
				aniname_attack = "B03-attack-" + text;
				animation = "C03-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("StickATK");
				break;
			case "401":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("HandATK");
				break;
			case "501":
				text = "finger";
				aniname_attack = "B05-attack-" + text;
				animation = "C05-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("FingerATK");
				break;
			case "601":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("DartsATK");
				break;
			case "701":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("MelodyATK");
				break;
			case "801":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("WineartATK");
				break;
			case "901":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				break;
			case "1001":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				m_SkillRow.runtime_style_damage = charadata.GetBattleValueByName("SpecialATK");
				break;
			case "9001":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				break;
			case "9101":
			case "9301":
			case "9401":
			case "9501":
			case "9601":
				text = "hand";
				aniname_attack = "B04-attack-" + text;
				animation = "C04-attackstand-" + text;
				break;
			}
			if (_byhand)
			{
				m_MenuController.DisplayWuGongInfo(m_SkillRow);
			}
		}
		PlayAnimation(animation);
		PlayAudioClip(AudioClipEnum.attackStandClip, _force_refresh: true);
	}

	public void UseItem()
	{
		SetBattleObjState(BattleObjectState.Action);
		m_BattleController.SetCameraSmooth(this, isSetCurcor: true);
		attackObjs.Clear();
		foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
		{
			if (!allBattleObj.isDead && !allBattleObj.CheckBuffEffectOn("TurtleBreath") && attackSelectRange.Contains(allBattleObj.GetGridPosition()))
			{
				attackObjs.Add(allBattleObj);
			}
		}
		PlayAudioClip(AudioClipEnum.attack1Clip);
		PlayAnimation(aniname_attack, loop: false, compensate: false);
		if (attackObjs.Count > 0 && m_AttackType[1] != "B")
		{
			m_BattleController.SetCameraSmooth(attackObjs[0]);
		}
	}

	public void Attack(Vector3Int pointer, bool firstHit = true)
	{
		m_attackPos = pointer;
		SetBattleObjState(BattleObjectState.Action);
		if (firstHit)
		{
			m_ComboRate = charadata.GetBattleValueByName("Combo") + float.Parse(m_SkillRow.kf.Combo, CultureInfo.InvariantCulture) + float.Parse(m_SkillRow.kf.Comboadd, CultureInfo.InvariantCulture) * (float)(m_SkillRow.lv - 1);
			ComboCount = 0;
			m_BattleController.SetCameraSmooth(this, isSetCurcor: true);
		}
		if (!(m_Revenge_Target != null) || (m_BattleController.GetCurrentObjActionType() != ActionType.Formless && m_BattleController.GetCurrentObjActionType() != ActionType.FormlessSuper && m_BattleController.GetCurrentObjActionType() != ActionType.Ambush && m_BattleController.GetCurrentObjActionType() != ActionType.Fantan))
		{
			float num = Mathf.Floor(float.Parse(m_SkillRow.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(m_SkillRow.kf.Expendadd, CultureInfo.InvariantCulture) * (float)(m_SkillRow.lv - 1));
			if (charadata.m_Mp < num)
			{
				SetBattleObjState(BattleObjectState.ActionOver);
				return;
			}
		}
		string type = ((race == "player") ? "SKILL-PLAYER" : "SKILL-ENEMY");
		if (!firstHit)
		{
			AddBuffInfo("combo");
		}
		AddDamageInfo("【" + m_SkillRow.kf.Name_Trans + "】" + CommonFunc.I18nGetLocalizedValue("I18N_Lv") + m_AttackType[4], type);
		attackObjs.Clear();
		List<BattleObject> list = null;
		if (charadata.GetBattleValueByName("Mad") > 25f)
		{
			list = m_BattleController.allBattleObjs;
		}
		else if (m_AttackType[3] == "2")
		{
			list = m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == race);
		}
		else if (m_AttackType[3] == "1")
		{
			list = m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && (x.race != race || (rebellionType.Equals(RebellionType.None) && (x.rebellionType.Equals(RebellionType.Temptation) || x.rebellionType.Equals(RebellionType.Bribe) || x.rebellionType.Equals(RebellionType.ControlMad)))));
		}
		else if (m_AttackType[3] == "0")
		{
			list = m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead);
		}
		foreach (BattleObject item in list)
		{
			if (!item.isDead && !item.CheckBuffEffectOn("TurtleBreath") && attackSelectRange.Contains(item.GetGridPosition()))
			{
				attackObjs.Add(item);
			}
		}
		if (pointer != Vector3.zero)
		{
			AdjustFace(pointer);
		}
		else if (attackObjs.Count > 0)
		{
			AdjustFace(attackObjs[0].GetGridPosition());
		}
		if (m_AttackType[3] == "2")
		{
			foreach (ItemController item2 in m_BattleController.items)
			{
				if (attackSelectRange.Contains(item2.GetGridPosition()))
				{
					breakItems.Add(item2);
				}
			}
		}
		if (m_AttackType[3] == "2")
		{
			PlayAudioClip(AudioClipEnum.attack1Clip);
		}
		else if (m_AttackType[1] == "B")
		{
			PlayAudioClip(AudioClipEnum.attack2Clip);
		}
		else
		{
			PlayAudioClip(AudioClipEnum.attack1Clip);
		}
		PlayAnimation(aniname_attack, loop: false, compensate: false);
		if (attackObjs.Count > 0 && m_AttackType[1] != "B")
		{
			m_BattleController.SetCameraSmooth(attackObjs[0]);
		}
	}

	public void AddBuff(string _name, string _source = "Skill", float _value = 0f, int _turn = 0, string _DamageInfo = "", bool _durnk = false)
	{
		BuffData buffData = new BuffData();
		buffData.source = _source;
		buffData.name = _name;
		buffData.value = _value;
		buffData.turn = _turn;
		buffData.drunk = _durnk;
		m_Buffs.Add(buffData);
		if (_DamageInfo != "")
		{
			AddDamageInfo(_DamageInfo, "");
		}
	}

	public bool RemoveBuff(BuffData buffData)
	{
		if (buffData != null && m_Buffs.Contains(buffData))
		{
			m_Buffs.Remove(buffData);
			return true;
		}
		return false;
	}

	public void BattleObjectDead(bool _isActive = false)
	{
		if (isDead)
		{
			return;
		}
		isDead = true;
		if (m_BattleController.current == this)
		{
			HandOutOperation();
		}
		if (CommonResourcesData.b10.Find_ID("1004").Members.Split("|").Contains(charadata.m_Id))
		{
			foreach (BattleObject item in m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.charadata.GetBattleValueByName("ZhangMenZhiZhi") > 0f && x != this))
			{
				BuffData buffData = item.m_Buffs.Find((BuffData x) => x.source == "ZhangMenZhiZhi");
				if (buffData != null)
				{
					if (buffData.value < item.charadata.GetBattleValueByName("ZhangMenZhiZhi") * 5f)
					{
						buffData.value += item.charadata.GetBattleValueByName("ZhangMenZhiZhi");
					}
					else
					{
						item.AddBuff("FinalInjuryPlus", "ZhangMenZhiZhi", item.charadata.GetBattleValueByName("ZhangMenZhiZhi"), int.MaxValue);
					}
				}
			}
		}
		if (m_BattleController.current != this && m_BattleController.current.race != race && m_BattleController.current.charadata.GetBattleValueByName("KillAddCrazyBuff") > 0f)
		{
			BuffData buffByName = m_BattleController.current.GetBuffByName("KillAddCrazyBuff");
			if (buffByName != null)
			{
				if (buffByName.value < 5f)
				{
					buffByName.value += 1f;
				}
			}
			else
			{
				m_BattleController.current.AddBuff("KillAddCrazyBuff", "", 1f, int.MaxValue);
			}
		}
		if (charadata.originRace == "enemy")
		{
			m_BattleController.SeparateExp(charadata.Indexs_Name["Name"].stringValue, m_DefeatExp);
		}
		AdjustAnimationSpeed(1f, Color.white);
		PlayAnimation(Aniname.aniname_die, loop: false);
		PlayAudioClip(AudioClipEnum.deathClip);
		if (!SharedData.Instance().m_BattleController.current.attackObjs.Contains(this))
		{
			SharedData.Instance().m_BattleController.current.attackObjs.Add(this);
		}
		hp_gauge.gameObject.SetActive(value: false);
		m_orderInfo?.SetActive(value: false);
		charadata.Indexs_Name["Mad"].fightValue = 0f;
		charadata.Indexs_Name["Seal"].fightValue = 0f;
		charadata.Indexs_Name["Hurt"].fightValue = 0f;
		charadata.Indexs_Name["Poison"].fightValue = 0f;
		charadata.Indexs_Name["Bleed"].fightValue = 0f;
		charadata.Indexs_Name["Burn"].fightValue = 0f;
		charadata.Indexs_Name["Drunk"].fightValue = 0f;
		m_Revenge_Target = null;
		RemoveEffectOn();
		if (!_isActive && UnityEngine.Random.Range(0f, 1f) < charadata.GetBattleValueByName("TurtleBreath"))
		{
			AddBuff("TurtleBreath", "Traits", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_TurtleBreath"));
		}
	}

	public void BattleObjectBackAlive()
	{
		isDead = false;
		AdjustAnimationSpeed(1f, Color.white);
		hp_gauge.gameObject.SetActive(value: false);
		PlayAnimation(Aniname.aniname_stand);
		int num = (int)(charadata.GetBattleValueByName("HP") * 0.1f);
		int num2 = (int)(charadata.GetBattleValueByName("MP") * 0.1f);
		charadata.m_Hp = ((num <= 1) ? 1 : num);
		charadata.m_Mp = ((num2 <= 1) ? 1 : num2);
	}

	public void BattleObjectBeHit()
	{
		AdjustAnimationSpeed(1f, Color.white);
		PlayAnimation(Aniname.aniname_behit, loop: true, compensate: true, forcerepeat: true);
		PlayAudioClip(AudioClipEnum.damageClip);
	}

	public void BattleObjectEscape()
	{
		AdjustAnimationSpeed(1f, Color.white);
		PlayAnimation(Aniname.aniname_walk, loop: false);
		SkeletonAnimation[] animations = m_Animations;
		for (int i = 0; i < animations.Length; i++)
		{
			animations[i].transform.DOScale(new Vector3(0f, 0f, 1f), 0.25f);
		}
		isEscape = true;
		hp_gauge.gameObject.SetActive(value: false);
		m_orderInfo?.SetActive(value: false);
		charadata.Indexs_Name["Mad"].fightValue = 0f;
		charadata.Indexs_Name["Seal"].fightValue = 0f;
		charadata.Indexs_Name["Hurt"].fightValue = 0f;
		charadata.Indexs_Name["Poison"].fightValue = 0f;
		charadata.Indexs_Name["Bleed"].fightValue = 0f;
		charadata.Indexs_Name["Burn"].fightValue = 0f;
		charadata.Indexs_Name["Drunk"].fightValue = 0f;
		m_Revenge_Target = null;
		RemoveEffectOn();
		SetBattleObjState(BattleObjectState.HandOut);
		m_BattleController.SetFlowState(BattleControllerFlow.Interlude);
	}

	public void SealFreeze()
	{
		m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SealCanNotMove"));
		if (!isSealFreeze)
		{
			isSealFreeze = true;
			AdjustAnimationSpeed(0f, Color.gray);
			if (m_BattleController.current != this)
			{
				StartCoroutine(BehitFinal());
			}
			isPerforming = false;
		}
	}

	public void UnSealFreeze()
	{
		charadata.Indexs_Name["Seal"].fightValue = 0f;
		m_MenuController.OpenInteruptInfo(this, charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_UnSeal"));
		isUnSealNextRound = false;
		if (isSealFreeze)
		{
			isSealFreeze = false;
			PlayAnimation(Aniname.aniname_stand);
			AdjustAnimationSpeed(1f, Color.white);
		}
	}

	public void SetInvisible(bool _Invisible = true, bool isActive = false)
	{
		isInvisible = _Invisible;
		_ = Color.white;
		Color white = Color.white;
		white.a = 0.5f;
		Color white2 = Color.white;
		white2.a = 0f;
		if (m_MeshRenderer != null && race == "enemy")
		{
			MeshRenderer[] meshRenderer = m_MeshRenderer;
			for (int i = 0; i < meshRenderer.Length; i++)
			{
				meshRenderer[i].enabled = !isInvisible;
			}
		}
		if (m_Animations != null && isInvisible)
		{
			if (race == "player")
			{
				m_Animations[0].skeleton.SetColor(white);
				m_Animations[1].skeleton.SetColor(white);
				m_Animations[2].skeleton.SetColor(white);
			}
			else
			{
				m_Animations[0].skeleton.SetColor(white2);
				m_Animations[1].skeleton.SetColor(white2);
				m_Animations[2].skeleton.SetColor(white2);
			}
		}
		if (isInvisible && m_BattleController.m_Flow == BattleControllerFlow.Interlude)
		{
			if (m_BattleController.current.race == race)
			{
				isSelectable = true;
			}
			else
			{
				isSelectable = false;
			}
		}
		else
		{
			isSelectable = true;
		}
		if (isInvisible || m_BattleController.m_Flow == BattleControllerFlow.Interlude)
		{
			return;
		}
		BuffData buffData = m_Buffs.Find((BuffData x) => x.name == "Invisible");
		if (buffData != null)
		{
			RemoveBuff(buffData);
			if (!isActive)
			{
				AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_UnInvisible"), "");
			}
			else
			{
				AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Sneak"), "");
			}
		}
	}

	protected IEnumerator BehitFinal()
	{
		yield return new WaitForSeconds(0.5f);
		if ((!(race == "player") || !SharedData.Instance().m_Inevitable) && charadata.m_Hp <= 0f)
		{
			BattleObjectDead();
		}
	}

	private void UpdateMpByHurt()
	{
		float num = CommonFunc.saturate(charadata.GetBattleValueByName("Hurt") / 255f);
		float num2 = Mathf.Floor(Mathf.Floor(charadata.GetBattleValueByName("MP")) * (1f - num));
		if (charadata.m_Mp > num2)
		{
			charadata.m_Mp = num2;
		}
	}

	public bool SetHp(float modifier, bool diehard = false)
	{
		if (CheckIsGoldenbellEffect() && modifier < 0f)
		{
			return true;
		}
		bool result = false;
		bool flag = false;
		if (charadata.m_Hp == 1f)
		{
			flag = true;
		}
		charadata.m_Hp += modifier;
		if (modifier < 0f && charadata.GetBattleValueByName("BeHitTeamHealHp") > 0f)
		{
			foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
			{
				if (!(allBattleObj == this) && !allBattleObj.isDead && !(allBattleObj.race != race))
				{
					allBattleObj.AddDamageInfo((charadata.GetBattleValueByName("BeHitTeamHealHp") * allBattleObj.charadata.GetBattleValueByName("HP")).ToString(), "HEAL");
				}
			}
		}
		if ((double)charadata.m_Hp < (double)charadata.GetBattleValueByName("HP") * 0.3 && charadata.GetBattleValueByName("MingXinJianXing") > 0f)
		{
			AddDamageInfo(SharedData.Instance().m_A01NameRowDirec["MingXinJianXing"].NameUI_Trans, "");
			SkillKeyWordManage.ClearDebuffFunction(this, this);
			AddBuff("FinalInjuryPlus", "", 2f, int.MaxValue);
		}
		if (modifier < 0f && (double)(0f - modifier) > (double)charadata.GetBattleValueByName("HP") * 0.25 && charadata.GetBattleValueByName("YunDuoGuiXu") > 0f)
		{
			charadata.m_Hp += 0f - modifier;
			SetMp(9999f);
			AddDamageInfo(SharedData.Instance().m_A01NameRowDirec["YunDuoGuiXu"].NameUI_Trans, "");
		}
		if ((double)charadata.m_Hp < (double)charadata.GetBattleValueByName("HP") * 0.2 && charadata.GetBattleValueByName("XuanBiZhiLi") > 0f)
		{
			AddDamageInfo(SharedData.Instance().m_A01NameRowDirec["XuanBiZhiLi"].NameUI_Trans, "");
			charadata.m_Hp = charadata.GetBattleValueByName("HP");
			charadata.Indexs_Name["XuanBiZhiLi"].fightValue = float.MinValue;
		}
		if (charadata.m_Hp <= 0f)
		{
			charadata.m_Hp = (diehard ? 1f : 0f);
			result = diehard && flag;
		}
		else if (charadata.m_Hp > charadata.GetBattleValueByName("HP") && modifier > 0f)
		{
			charadata.m_Hp = charadata.GetBattleValueByName("HP");
		}
		ShowHpGauge();
		if (m_State != 0)
		{
			m_MenuController.RefreshBattleInfo();
		}
		StartCoroutine(HideHpGuage());
		return result;
	}

	public void SetMp(float modifier)
	{
		if (CheckIsGoldenbellEffect() && modifier < 0f)
		{
			return;
		}
		float num = CommonFunc.saturate(charadata.GetBattleValueByName("Hurt") / 255f);
		float num2 = Mathf.Floor(Mathf.Floor(charadata.GetBattleValueByName("MP")) * (1f - num));
		if (!(modifier > 0f) || !(charadata.m_Mp > num2))
		{
			charadata.m_Mp += modifier;
			if ((double)charadata.m_Mp < (double)charadata.GetBattleValueByName("MP") * 0.2 && charadata.GetBattleValueByName("DangQiDiChen") > 0f)
			{
				AddDamageInfo(SharedData.Instance().m_A01NameRowDirec["DangQiDiChen"].NameUI_Trans, "");
				charadata.m_Mp = charadata.GetBattleValueByName("MP");
				charadata.Indexs_Name["DangQiDiChen"].fightValue = float.MinValue;
			}
			if (charadata.m_Mp < 0f)
			{
				charadata.m_Mp = 0f;
			}
			else if (charadata.m_Mp > num2 && modifier > 0f)
			{
				charadata.m_Mp = num2;
			}
			if (m_State != 0)
			{
				m_MenuController.RefreshBattleInfo();
			}
		}
	}

	public void DeleteRebellionInfo()
	{
		foreach (DisplayDamage damage in m_DamageList)
		{
			if (damage.type == "Rebellion")
			{
				m_DamageList.Remove(damage);
				break;
			}
		}
	}

	public void ClearRangeInfo()
	{
		unitRange.Clear();
		AttackForecastRange.Clear();
		standPosList.Clear();
		attackRange.Clear();
		attackSelectRange.Clear();
		AttackForecastDict.Clear();
	}

	public void LoadRecordPost(bool _clearRange = false)
	{
		m_Buffs = charadata.m_Buffs;
		RefreshEffectOn();
		if (_clearRange)
		{
			ClearRangeInfo();
		}
		Face(m_Direction, isInit: true);
		PlayAnimation(Aniname.aniname_stand);
	}

	public void InteruptIn(BattleObjectState _next, BattleControllerFlow battleControllerFlow = BattleControllerFlow.None)
	{
		SetBattleObjState(BattleObjectState.InteruptIn);
		m_Next_State = _next;
		m_Next_battleControllerFlow = battleControllerFlow;
		if (m_BattleController.AutoBattle || m_BattleController.isLostControl)
		{
			StartCoroutine(InteruptOutDelay());
		}
	}

	private IEnumerator InteruptOutDelay()
	{
		yield return new WaitForSeconds(1f);
		InteruptOut();
	}

	public void InteruptOut()
	{
		StopCoroutine(InteruptOutDelay());
		m_MenuController.m_InteruptInfo.SetActive(value: false);
		if (m_Next_State != BattleObjectState.None)
		{
			SetBattleObjState(m_Next_State);
			m_Next_State = BattleObjectState.None;
		}
		if (m_Next_battleControllerFlow != BattleControllerFlow.None)
		{
			m_BattleController.SetFlowState(m_Next_battleControllerFlow);
			m_Next_battleControllerFlow = BattleControllerFlow.None;
		}
	}

	public void PlayAudioClip(AudioClipEnum clipname, bool _force_refresh = false)
	{
		m_BattleObjectAudioManager.PlayAudioClip(clipname, _force_refresh);
		StartCoroutine(m_BattleObjectAudioManager.PlayAudioClipDelay());
	}

	public void PlayAnimation(string animation, bool loop = true, bool compensate = true, bool forcerepeat = false)
	{
		if ((isDead && animation != Aniname.aniname_die) || (CheckBuffEffectOn("TurtleBreath") && animation != Aniname.aniname_die))
		{
			return;
		}
		if (animation.Contains("-attack-") || animation == Aniname.aniname_behit || animation == Aniname.aniname_die)
		{
			isPerforming = true;
		}
		else
		{
			isPerforming = false;
		}
		if (!isSealFreeze && animation != Aniname.aniname_stand)
		{
			AdjustAnimationSpeed(1f, Color.white);
		}
		if (forcerepeat)
		{
			if (m_Animations[0].gameObject.activeSelf)
			{
				if (!compensate)
				{
					m_Animations[0].skeleton.SetToSetupPose();
					m_Animations[0].AnimationState.ClearTracks();
				}
				m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
			}
			if (m_Animations[1].gameObject.activeSelf)
			{
				if (!compensate)
				{
					m_Animations[1].skeleton.SetToSetupPose();
					m_Animations[1].AnimationState.ClearTracks();
				}
				m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
			}
			if (m_Animations[2].gameObject.activeSelf)
			{
				if (!compensate)
				{
					m_Animations[2].skeleton.SetToSetupPose();
					m_Animations[2].AnimationState.ClearTracks();
				}
				m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
			}
			return;
		}
		if (m_Animations[0].AnimationName != animation)
		{
			if (!compensate)
			{
				m_Animations[0].skeleton.SetToSetupPose();
				m_Animations[0].AnimationState.ClearTracks();
			}
			m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[1].AnimationName != animation)
		{
			if (!compensate)
			{
				m_Animations[1].skeleton.SetToSetupPose();
				m_Animations[1].AnimationState.ClearTracks();
			}
			m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[2].AnimationName != animation)
		{
			if (!compensate)
			{
				m_Animations[2].skeleton.SetToSetupPose();
				m_Animations[2].AnimationState.ClearTracks();
			}
			m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}

	public void AdjustAnimationSpeed(float _speed, Color _color)
	{
		SkeletonAnimation[] animations = m_Animations;
		foreach (SkeletonAnimation obj in animations)
		{
			obj.AnimationState.TimeScale = _speed;
			obj.skeleton.SetColor(_color);
		}
	}

	public void AdjustFace(Vector3Int _targetPos)
	{
		Vector3Int gridPosition = GetGridPosition();
		if (!(gridPosition != _targetPos))
		{
			return;
		}
		Vector3Int vector3Int = _targetPos - gridPosition;
		if (Mathf.Abs(vector3Int.x) >= Mathf.Abs(vector3Int.y))
		{
			if (vector3Int.x > 0)
			{
				AdjustFace(1);
			}
			else
			{
				AdjustFace(3);
			}
		}
		else if (vector3Int.y < 0)
		{
			AdjustFace(2);
		}
		else
		{
			AdjustFace(0);
		}
	}

	private void AdjustFace(int _direction)
	{
		switch (_direction)
		{
		case 0:
			Face(Direction.Down, isInit: true);
			break;
		case 1:
			Face(Direction.Left, isInit: true);
			break;
		case 2:
			Face(Direction.Up, isInit: true);
			break;
		case 3:
			Face(Direction.Right, isInit: true);
			break;
		}
	}

	public void Face(Direction direction, bool isInit = false)
	{
		if (isInit || direction != m_Direction)
		{
			m_Direction = direction;
			switch (direction)
			{
			case Direction.Left:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = 1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			case Direction.Up:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: true);
				break;
			case Direction.Right:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = -1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			default:
				m_Animations[0].gameObject.SetActive(value: true);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			}
		}
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / CommonVariables.MovementBlockSize);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / CommonVariables.MovementBlockSize);
		curPos = zero;
		return zero;
	}

	public void SetBattleObjState(BattleObjectState _in)
	{
		if (_in != m_State)
		{
			m_State = _in;
		}
	}
}
