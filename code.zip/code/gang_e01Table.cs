using System.Collections.Generic;
using UnityEngine;

public class gang_e01Table
{
	public class Row
	{
		public string eventid;

		public string flag;

		public string trigger;

		public string display;

		public string direction;

		public string action;

		public string elseaction;

		public string throughaction;

		public string nextflag;

		public string output;

		public string elsefollow;

		public string menu;

		public string online;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				eventid = list[i][num++],
				flag = list[i][num++],
				trigger = list[i][num++],
				display = list[i][num++],
				direction = list[i][num++],
				action = list[i][num++],
				elseaction = list[i][num++],
				throughaction = list[i][num++],
				nextflag = list[i][num++],
				output = list[i][num++],
				elsefollow = list[i][num++],
				menu = list[i][num++],
				online = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_eventid(string find)
	{
		return rowList.Find((Row x) => x.eventid == find);
	}

	public List<Row> FindAll_eventid(string find)
	{
		return rowList.FindAll((Row x) => x.eventid == find);
	}

	public Row Find_flag(string find)
	{
		return rowList.Find((Row x) => x.flag == find);
	}

	public List<Row> FindAll_flag(string find)
	{
		return rowList.FindAll((Row x) => x.flag == find);
	}

	public Row Find_trigger(string find)
	{
		return rowList.Find((Row x) => x.trigger == find);
	}

	public List<Row> FindAll_trigger(string find)
	{
		return rowList.FindAll((Row x) => x.trigger == find);
	}

	public Row Find_display(string find)
	{
		return rowList.Find((Row x) => x.display == find);
	}

	public List<Row> FindAll_display(string find)
	{
		return rowList.FindAll((Row x) => x.display == find);
	}

	public Row Find_direction(string find)
	{
		return rowList.Find((Row x) => x.direction == find);
	}

	public List<Row> FindAll_direction(string find)
	{
		return rowList.FindAll((Row x) => x.direction == find);
	}

	public Row Find_action(string find)
	{
		return rowList.Find((Row x) => x.action == find);
	}

	public List<Row> FindAll_action(string find)
	{
		return rowList.FindAll((Row x) => x.action == find);
	}

	public Row Find_elseaction(string find)
	{
		return rowList.Find((Row x) => x.elseaction == find);
	}

	public List<Row> FindAll_elseaction(string find)
	{
		return rowList.FindAll((Row x) => x.elseaction == find);
	}

	public Row Find_throughaction(string find)
	{
		return rowList.Find((Row x) => x.throughaction == find);
	}

	public List<Row> FindAll_throughaction(string find)
	{
		return rowList.FindAll((Row x) => x.throughaction == find);
	}

	public Row Find_nextflag(string find)
	{
		return rowList.Find((Row x) => x.nextflag == find);
	}

	public List<Row> FindAll_nextflag(string find)
	{
		return rowList.FindAll((Row x) => x.nextflag == find);
	}

	public Row Find_output(string find)
	{
		return rowList.Find((Row x) => x.output == find);
	}

	public List<Row> FindAll_output(string find)
	{
		return rowList.FindAll((Row x) => x.output == find);
	}

	public Row Find_elsefollow(string find)
	{
		return rowList.Find((Row x) => x.elsefollow == find);
	}

	public List<Row> FindAll_elsefollow(string find)
	{
		return rowList.FindAll((Row x) => x.elsefollow == find);
	}

	public Row Find_menu(string find)
	{
		return rowList.Find((Row x) => x.menu == find);
	}

	public List<Row> FindAll_menu(string find)
	{
		return rowList.FindAll((Row x) => x.menu == find);
	}

	public Row Find_online(string find)
	{
		return rowList.Find((Row x) => x.online == find);
	}

	public List<Row> FindAll_online(string find)
	{
		return rowList.FindAll((Row x) => x.online == find);
	}
}
