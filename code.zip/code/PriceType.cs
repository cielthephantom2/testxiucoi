public enum PriceType
{
	none,
	money,
	oldcoin,
	bone
}
