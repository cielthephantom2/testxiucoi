using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class StatusSub2 : MonoBehaviour
{
	private void Awake()
	{
		SharedData.Instance().m_StatusSub2 = this;
	}

	private void OnEnable()
	{
		if (!(SharedData.Instance().CurrentChara == ""))
		{
			CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
			if (currentCharaData != null)
			{
				base.transform.Find("Panel/Area1/Name").GetComponent<Text>().text = currentCharaData.Indexs_Name["Name"].stringValue;
				base.transform.Find("Panel/Area1/LV/Num").GetComponent<Text>().text = currentCharaData.m_Level.ToString() ?? "";
				gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(currentCharaData.m_Level.ToString() ?? "");
				base.transform.Find("Panel/Area1/Exp/Num").GetComponent<Text>().text = currentCharaData.m_Exp + "/" + row.EXP;
				base.transform.Find("Panel/Area1/ExpBar").GetComponent<Slider>().value = (float)currentCharaData.m_Exp / float.Parse(row.EXP, CultureInfo.InvariantCulture);
				SetInfo(currentCharaData, "Sword");
				SetInfo(currentCharaData, "Knife");
				SetInfo(currentCharaData, "Stick");
				SetInfo(currentCharaData, "Hand");
				SetInfo(currentCharaData, "Finger");
				SetInfo(currentCharaData, "Special");
				SetInfo(currentCharaData, "YinYang");
				SetInfo(currentCharaData, "Melody");
				SetInfo(currentCharaData, "Medical");
				SetInfo(currentCharaData, "Wineart");
				SetInfo(currentCharaData, "Darts");
				SetInfo(currentCharaData, "Steal");
				SetInfo(currentCharaData, "Forge");
				SetInfo(currentCharaData, "Percept");
			}
		}
	}

	private void SetInfo(CharaData _curdata, string _name)
	{
		IronMan component = base.transform.Find("Panel/Status/SkillAttr/" + _name).GetComponent<IronMan>();
		component.atomData = _curdata.Indexs_Name[_name];
		component.Init(_curdata.Indexs_Name[_name], _curdata);
		base.transform.Find("Panel/Status/SkillAttr/" + _name + "/NameText").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[_name].NameScene_Trans;
		base.transform.Find("Panel/Status/SkillAttr/" + _name + "/Text").GetComponent<Text>().text = _curdata.GetFieldValueByName(_name).ToString();
		base.transform.Find("Panel/Status/SkillAttr/" + _name + "/Hover/Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[_name].Note_Trans;
	}
}
