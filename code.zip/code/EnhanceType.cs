public enum EnhanceType
{
	Enhance,
	Reset
}
