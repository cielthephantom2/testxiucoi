using System.Collections.Generic;
using UnityEngine;

public class gang_c03Table
{
	public class Row
	{
		public string ID;

		public string Wanted;

		public string WantedNPC;

		public string WantedNPC_EN;

		public string WantedItem;

		public string WantedBonus;

		public string WantedReword;

		public string WantedNPC_Trans => CommonFunc.ShortLangSel(WantedNPC, WantedNPC_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Wanted = list[i][num++],
				WantedNPC = list[i][num++],
				WantedItem = list[i][num++],
				WantedBonus = list[i][num++],
				WantedReword = list[i][num++]
			};
			row.WantedNPC = I18nData.Instance().tableI18N.Find_ID("gang_c03_" + row.ID + "_WantedNPC")?.zh_CH;
			row.WantedNPC_EN = I18nData.Instance().tableI18N.Find_ID("gang_c03_" + row.ID + "_WantedNPC")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Wanted(string find)
	{
		return rowList.Find((Row x) => x.Wanted == find);
	}

	public List<Row> FindAll_Wanted(string find)
	{
		return rowList.FindAll((Row x) => x.Wanted == find);
	}

	public Row Find_WantedNPC(string find)
	{
		return rowList.Find((Row x) => x.WantedNPC == find);
	}

	public List<Row> FindAll_WantedNPC(string find)
	{
		return rowList.FindAll((Row x) => x.WantedNPC == find);
	}

	public Row Find_WantedNPC_EN(string find)
	{
		return rowList.Find((Row x) => x.WantedNPC_EN == find);
	}

	public List<Row> FindAll_WantedNPC_EN(string find)
	{
		return rowList.FindAll((Row x) => x.WantedNPC_EN == find);
	}

	public Row Find_WantedItem(string find)
	{
		return rowList.Find((Row x) => x.WantedItem == find);
	}

	public List<Row> FindAll_WantedItem(string find)
	{
		return rowList.FindAll((Row x) => x.WantedItem == find);
	}

	public Row Find_WantedBonus(string find)
	{
		return rowList.Find((Row x) => x.WantedBonus == find);
	}

	public List<Row> FindAll_WantedBonus(string find)
	{
		return rowList.FindAll((Row x) => x.WantedBonus == find);
	}
}
