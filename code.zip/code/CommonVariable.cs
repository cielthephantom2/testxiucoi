public static class CommonVariable
{
	public static float[] ComboReduce = new float[4] { 0.2f, 0.1f, 0.01f, 0f };

	public const int MAX_TEAMMATE_COUNT = 54;

	public const int MAX_POKEMON_COUNT = 18;
}
