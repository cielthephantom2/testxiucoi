using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Starter1Controller : MonoBehaviour
{
	private Color btn_txt_down = new Color(1f, 1f, 0.925f, 0.3f);

	private Color btn_txt_common = new Color(1f, 1f, 0.925f, 1f);

	private Color btn_txt_down1 = new Color(0.412f, 0.376f, 0.325f, 0.3f);

	private Color btn_txt_common1 = new Color(0.412f, 0.376f, 0.325f, 1f);

	private Sprite male_img_0;

	private Sprite male_img_1;

	private Sprite female_img_0;

	private Sprite female_img_1;

	private Sprite male1_img_0;

	private Sprite male1_img_1;

	private Sprite male1_img_2;

	private Sprite female1_img_0;

	private Sprite female1_img_1;

	private Sprite female1_img_2;

	private Sprite male2_img_0;

	private Sprite male2_img_1;

	private Sprite male2_img_2;

	private Sprite female2_img_0;

	private Sprite female2_img_1;

	private Sprite female2_img_2;

	private Sprite male3_img_0;

	private Sprite male3_img_1;

	private Sprite male3_img_2;

	private Sprite female3_img_0;

	private Sprite female3_img_1;

	private Sprite female3_img_2;

	private Transform male_btn;

	private Transform female_btn;

	private Transform male1_btn;

	private Transform female1_btn;

	private Transform male2_btn;

	private Transform female2_btn;

	private Transform male3_btn;

	private Transform female3_btn;

	private Transform next_btn;

	private List<string> chara_info1 = new List<string>();

	private List<string> chara_info2 = new List<string>();

	private Text chara_info1_text;

	private Text chara_info2_text;

	private string oldId = "";

	private void Start()
	{
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		male_img_0 = Resources.Load("images/14-createCharacter/role-01-male-2", typeof(Sprite)) as Sprite;
		male_img_1 = Resources.Load("images/14-createCharacter/role-01-male-1", typeof(Sprite)) as Sprite;
		female_img_0 = Resources.Load("images/14-createCharacter/role-01-female-2", typeof(Sprite)) as Sprite;
		female_img_1 = Resources.Load("images/14-createCharacter/role-01-female-1", typeof(Sprite)) as Sprite;
		male1_img_0 = Resources.Load("images/14-createCharacter/role-02-male-2", typeof(Sprite)) as Sprite;
		male1_img_1 = Resources.Load("images/14-createCharacter/role-02-male-1", typeof(Sprite)) as Sprite;
		male1_img_2 = Resources.Load("images/14-createCharacter/role-02-male-3", typeof(Sprite)) as Sprite;
		female1_img_0 = Resources.Load("images/14-createCharacter/role-02-female-2", typeof(Sprite)) as Sprite;
		female1_img_1 = Resources.Load("images/14-createCharacter/role-02-female-1", typeof(Sprite)) as Sprite;
		female1_img_2 = Resources.Load("images/14-createCharacter/role-02-female-3", typeof(Sprite)) as Sprite;
		male2_img_0 = Resources.Load("images/14-createCharacter/role-03-male-2", typeof(Sprite)) as Sprite;
		male2_img_1 = Resources.Load("images/14-createCharacter/role-03-male-1", typeof(Sprite)) as Sprite;
		male2_img_2 = Resources.Load("images/14-createCharacter/role-03-male-3", typeof(Sprite)) as Sprite;
		female2_img_0 = Resources.Load("images/14-createCharacter/role-03-female-2", typeof(Sprite)) as Sprite;
		female2_img_1 = Resources.Load("images/14-createCharacter/role-03-female-1", typeof(Sprite)) as Sprite;
		female2_img_2 = Resources.Load("images/14-createCharacter/role-03-female-3", typeof(Sprite)) as Sprite;
		male3_img_0 = Resources.Load("images/14-createCharacter/role-04-male-2", typeof(Sprite)) as Sprite;
		male3_img_1 = Resources.Load("images/14-createCharacter/role-04-male-1", typeof(Sprite)) as Sprite;
		male3_img_2 = Resources.Load("images/14-createCharacter/role-04-male-3", typeof(Sprite)) as Sprite;
		female3_img_0 = Resources.Load("images/14-createCharacter/role-04-female-2", typeof(Sprite)) as Sprite;
		female3_img_1 = Resources.Load("images/14-createCharacter/role-04-female-1", typeof(Sprite)) as Sprite;
		female3_img_2 = Resources.Load("images/14-createCharacter/role-04-female-3", typeof(Sprite)) as Sprite;
		male_btn = base.transform.Find("Panel/Male");
		female_btn = base.transform.Find("Panel/Female");
		male1_btn = base.transform.Find("Panel/Male1");
		female1_btn = base.transform.Find("Panel/Female1");
		male2_btn = base.transform.Find("Panel/Male2");
		female2_btn = base.transform.Find("Panel/Female2");
		male3_btn = base.transform.Find("Panel/Male3");
		female3_btn = base.transform.Find("Panel/Female3");
		next_btn = base.transform.Find("Panel/Next");
		chara_info1.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info1_1"));
		chara_info1.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info1_2"));
		chara_info1.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info1_3"));
		chara_info1.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info1_4"));
		chara_info1.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info1_5"));
		chara_info1.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info1_6"));
		chara_info2.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info2_0"));
		chara_info2.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info2_0"));
		chara_info2.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info2_1"));
		chara_info2.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info2_1"));
		chara_info2.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info2_2"));
		chara_info2.Add(CommonFunc.I18nGetLocalizedValue("I18N_chara_info2_2"));
		chara_info1_text = base.transform.Find("Panel/CharaInfo1").GetComponent<Text>();
		chara_info2_text = base.transform.Find("Panel/CharaInfo2").GetComponent<Text>();
		oldId = SharedData.Instance().playerid;
		GameObject gameObject = male_btn.gameObject;
		if (SharedData.Instance().playerid == "9001")
		{
			gameObject = base.transform.Find("Panel/Male").gameObject;
		}
		else if (SharedData.Instance().playerid == "9002")
		{
			gameObject = base.transform.Find("Panel/Female").gameObject;
		}
		else if (SharedData.Instance().playerid == "9003")
		{
			gameObject = base.transform.Find("Panel/Male1").gameObject;
		}
		else if (SharedData.Instance().playerid == "9004")
		{
			gameObject = base.transform.Find("Panel/Female1").gameObject;
		}
		OnButtonClick(gameObject);
		EventSystem.current.SetSelectedGameObject(gameObject);
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(next_btn.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Return").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		if (go.name != "Next" && go.name != "Return")
		{
			next_btn.gameObject.SetActive(value: true);
		}
		if (go.name == "Male")
		{
			male_btn.GetComponent<Image>().sprite = male_img_1;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			SharedData.Instance().playerid = "9001";
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
			}
			chara_info1_text.text = chara_info1[0];
			chara_info2_text.text = chara_info2[0];
			base.transform.Find("Panel/PortraitMale").GetComponent<Image>().color = Color.white;
			base.transform.Find("Panel/PortraitFemale").GetComponent<Image>().color = new Color(0f, 0f, 0f, 0f);
		}
		else if (go.name == "Male1")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			SharedData.Instance().playerid = "9003";
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_1;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			else
			{
				next_btn.gameObject.SetActive(value: false);
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
			}
			chara_info1_text.text = chara_info1[2];
			chara_info2_text.text = chara_info2[2];
		}
		else if (go.name == "Male2")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_1;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
				SharedData.Instance().playerid = "9001";
			}
			else
			{
				next_btn.gameObject.SetActive(value: false);
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
			}
			chara_info1_text.text = chara_info1[4];
			chara_info2_text.text = chara_info2[4];
		}
		else if (go.name == "Male3")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_1;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
				SharedData.Instance().playerid = "9001";
			}
			else
			{
				next_btn.gameObject.SetActive(value: false);
			}
			chara_info1_text.text = chara_info1[6];
			chara_info2_text.text = chara_info2[6];
		}
		else if (go.name == "Female")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_1;
			SharedData.Instance().playerid = "9002";
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
			}
			chara_info1_text.text = chara_info1[1];
			chara_info2_text.text = chara_info2[1];
			base.transform.Find("Panel/PortraitMale").GetComponent<Image>().color = new Color(0f, 0f, 0f, 0f);
			base.transform.Find("Panel/PortraitFemale").GetComponent<Image>().color = Color.white;
		}
		else if (go.name == "Female1")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			SharedData.Instance().playerid = "9004";
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_1;
			}
			else
			{
				next_btn.gameObject.SetActive(value: false);
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
			}
			chara_info1_text.text = chara_info1[3];
			chara_info2_text.text = chara_info2[3];
		}
		else if (go.name == "Female2")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_1;
				SharedData.Instance().playerid = "9002";
			}
			else
			{
				next_btn.gameObject.SetActive(value: false);
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_0;
			}
			chara_info1_text.text = chara_info1[5];
			chara_info2_text.text = chara_info2[5];
		}
		else if (go.name == "Female3")
		{
			male_btn.GetComponent<Image>().sprite = male_img_0;
			female_btn.GetComponent<Image>().sprite = female_img_0;
			if (GameDataManager.Instance().configdata.playRound > 0)
			{
				male1_btn.GetComponent<Image>().sprite = male1_img_0;
				female1_btn.GetComponent<Image>().sprite = female1_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male2_btn.GetComponent<Image>().sprite = male2_img_0;
				female2_btn.GetComponent<Image>().sprite = female2_img_0;
			}
			if (GameDataManager.Instance().configdata.playRound >= int.MaxValue)
			{
				male3_btn.GetComponent<Image>().sprite = male3_img_0;
				female3_btn.GetComponent<Image>().sprite = female3_img_1;
				SharedData.Instance().playerid = "9002";
			}
			else
			{
				next_btn.gameObject.SetActive(value: false);
			}
			chara_info1_text.text = chara_info1[7];
			chara_info2_text.text = chara_info2[7];
		}
		else if (go.name == "Next")
		{
			if (oldId != SharedData.Instance().playerid)
			{
				SharedData.Instance().isLoadedStart1_1 = false;
			}
			go.transform.Find("Text").GetComponent<Text>().color = btn_txt_down;
			go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common;
			SharedData.Instance().ASyncLoadScene("Starter1_1");
		}
		else if (go.name == "Return")
		{
			go.transform.Find("Text").GetComponent<Text>().color = btn_txt_down1;
			go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common1;
			SharedData.Instance().ASyncLoadScene("Title");
		}
	}
}
