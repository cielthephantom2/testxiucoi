using System;
using UnityEngine;

public static class EAGameDataManager
{
	public static (bool, int) LoadOldConfigDataPlayRound()
	{
		XmlSaver xmlSaver = new XmlSaver();
		Debug.Log("EDITOR Platform");
		string text = "TheWorldOfKongFu";
		string text2 = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\" + text;
		string text3 = "";
		string fileName = text2 + "\\configdata.dat";
		if (xmlSaver.hasFile(fileName))
		{
			text3 = xmlSaver.LoadXML(fileName);
		}
		else
		{
			Debug.LogWarning("Not found [configdata.dat], try [configdata] instead.");
			fileName = text2 + "\\configdata";
			if (xmlSaver.hasFile(fileName))
			{
				text3 = xmlSaver.LoadXML(fileName);
			}
		}
		if (!text3.Equals(""))
		{
			text3 = xmlSaver.Decrypt(text3, isEA: true);
			ConfigDataEA configDataEA = xmlSaver.DeserializeObject(text3, typeof(ConfigDataEA), isEA: true) as ConfigDataEA;
			return (true, configDataEA.playRound);
		}
		return (false, 0);
	}
}
