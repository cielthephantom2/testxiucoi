using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Spine;
using Spine.Unity;
using SuperTiled2Unity;
using UnityEngine;
using UnityEngine.Tilemaps;

public class EventController : MonoBehaviour
{
	public float MovingSpeedRate = 1f;

	private const float MovementBlockSize = 50f;

	public State m_State;

	public Direction m_Direction;

	public SkeletonAnimation[] m_Animations;

	public string tileName = "";

	private Vector2 m_SpawnPoint = Vector2.zero;

	private SpriteRenderer[] m_SpriteRenderers;

	private Camera m_camera;

	public bool camera_control;

	private MapController mapcontroller;

	private Vector3Int startPos = Vector3Int.zero;

	private Vector3Int endPos = Vector3Int.zero;

	private Dictionary<Vector3Int, int> search = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, int> cost = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, Vector3Int> pathSave = new Dictionary<Vector3Int, Vector3Int>();

	private List<Vector3Int> hadSearch = new List<Vector3Int>();

	private GameObject PathPrefab;

	private GameObject Path;

	private List<GameObject> pathObject = new List<GameObject>();

	private SpriteRenderer m_Renderer;

	private int m_SortingOrder;

	private int m_MoveProcess;

	private Vector2 m_MovingFrom;

	private Vector2 m_MovingTo;

	private string aniname_stand = "A01-stand";

	private string aniname_walk = "A02-walk";

	private string aniname_behit = "D01-behit";

	private string aniname_die = "D02-die";

	private List<SceneMove> m_SceneMoves = new List<SceneMove>();

	public int m_ScenePlay;

	public MapController.Event m_MultiEvent;

	public int m_MovieCutID;

	public MapController.Event m_MovieEvent;

	public string trigger = "";

	public string display = "";

	public bool BackFromOtherScene;

	private string pre_name = "";

	private bool m_KeepDirection;

	public bool m_KeepAnimation;

	private bool m_Init;

	private AudioSource audioSource;

	private AudioClip walkClip;

	private string m_ClipPlaying = "";

	private float m_SEDefVolume;

	public float unitRange = 32f;

	public float moveSpeed = 7.5f;

	private float finalSpeed;

	public Transform movePoint;

	public string m_AiType = "Still";

	public float MinMoveGap = 0.3f;

	public float MaxMoveGap = 2f;

	public int movement = 1;

	public float DefMovingSpeedRate = 1f;

	private bool m_WanderThread;

	public bool m_IsLoop;

	private bool m_TgtMov;

	private Direction m_DefaultDirection = Direction.Down;

	private Vector3Int movetov3 = Vector3Int.zero;

	private List<Vector3Int> m_neighbors = new List<Vector3Int>();

	public int m_face_towards;

	private Vector3Int playerPos = Vector3Int.zero;

	private Vector3Int thisPos = Vector3Int.zero;

	private Vector3Int LastHoverPos = Vector3Int.zero;

	private void Awake()
	{
		int sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
		m_SortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "underfoot").sortingOrder;
		SkeletonAnimation[] componentsInChildren = base.gameObject.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		List<SkeletonAnimation> list = new List<SkeletonAnimation>();
		SkeletonAnimation[] array = componentsInChildren;
		foreach (SkeletonAnimation skeletonAnimation in array)
		{
			if (!"Ani".Equals(skeletonAnimation.name))
			{
				list.Add(skeletonAnimation);
				skeletonAnimation.gameObject.GetComponent<MeshRenderer>().sortingOrder = sortingOrder;
			}
		}
		m_Animations = list.ToArray();
		m_SpriteRenderers = base.gameObject.GetComponentsInChildren<SpriteRenderer>(includeInactive: true);
		SpriteRenderer[] spriteRenderers = m_SpriteRenderers;
		foreach (SpriteRenderer spriteRenderer in spriteRenderers)
		{
			if ("underfoot".Equals(spriteRenderer.name))
			{
				spriteRenderer.sortingOrder = m_SortingOrder;
			}
			else
			{
				spriteRenderer.sortingOrder = sortingOrder;
			}
		}
		if (m_Animations.Length >= 3)
		{
			for (int j = 0; j < 3; j++)
			{
				m_Animations[j].AnimationState.Complete += State_Complete;
			}
			PlayAnimation(aniname_stand);
		}
		m_camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
		Transform transform = base.transform.Find("head_icon/talk/Ani");
		if (transform != null)
		{
			transform.GetComponent<MeshRenderer>().sortingOrder = sortingOrder + 999;
		}
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
		if (transform != null)
		{
			audioSource = base.transform.Find("head_icon").GetComponent<AudioSource>();
			m_SEDefVolume = audioSource.volume;
		}
	}

	public void Init(string _direction)
	{
		Init();
		switch (_direction)
		{
		case "FREE":
		case "DOWN":
			Face(Direction.Down, isInit: true);
			break;
		case "RIGHT":
			Face(Direction.Left, isInit: true);
			break;
		case "UP":
			Face(Direction.Up, isInit: true);
			break;
		case "LEFT":
			Face(Direction.Right, isInit: true);
			break;
		default:
			Face(Direction.Down, isInit: true);
			break;
		}
		string[] array = display.Split('|');
		if (array.Length > 1)
		{
			PlayAnimationEnd(array[1]);
		}
		m_DefaultDirection = m_Direction;
	}

	public void ResetDirection(string _trigger)
	{
		if (_trigger.Equals(trigger))
		{
			Face(m_DefaultDirection);
		}
	}

	public void Init()
	{
		PathPrefab = CommonResourcesData.PathPrefab;
		walkClip = CommonResourcesData.EventAudioclip;
		if (BackFromOtherScene && trigger != "FOOTON")
		{
			m_SpawnPoint = new Vector2(25f + (float)SharedData.Instance().MapUnitsBefore[base.gameObject.name].x * 50f, -25f - (float)SharedData.Instance().MapUnitsBefore[base.gameObject.name].y * 50f);
			Face(SharedData.Instance().EventsRecord[base.name].objdirection, isInit: true);
			string[] array = display.Split('|');
			if (array.Length > 1)
			{
				PlayAnimationEnd(array[1]);
			}
			m_DefaultDirection = m_Direction;
			BackFromOtherScene = false;
		}
		else
		{
			SuperObject superObject = null;
			SuperObject[] byName = mapcontroller.getByName(tileName);
			if (byName.Length != 0)
			{
				superObject = byName[0];
			}
			if (superObject != null)
			{
				m_SpawnPoint = superObject.transform.position;
			}
			else
			{
				string[] array2 = tileName.Split('_');
				if ("EOF".Equals(array2[0]))
				{
					m_SpawnPoint = mapcontroller.player.transform.position;
				}
			}
		}
		if ("FOOTON".Equals(trigger))
		{
			SpriteRenderer[] spriteRenderers = m_SpriteRenderers;
			foreach (SpriteRenderer spriteRenderer in spriteRenderers)
			{
				Debug.Log(base.name + "'s Sprite part: " + spriteRenderer.name + " is [FOOTON] event, use m_SortingOrder[" + m_SortingOrder + "].");
				spriteRenderer.sortingOrder = m_SortingOrder;
			}
		}
		m_SpawnPoint.x = RoundToGrid(m_SpawnPoint.x);
		m_SpawnPoint.y = RoundToGrid(m_SpawnPoint.y);
		base.gameObject.transform.localPosition = m_SpawnPoint;
		finalSpeed = moveSpeed * unitRange;
		movePoint = base.transform.Find("movepoint");
		if (movePoint != null)
		{
			movePoint.parent = null;
		}
		else
		{
			movePoint = base.transform;
		}
		m_State = State.MoveInit;
		string[] array3 = base.name.Split('|');
		pre_name = array3[0];
		if (!trigger.Equals("HOVER") && !trigger.Equals("FOOTON") && !pre_name.Equals("CAMERA"))
		{
			mapcontroller.ReportPosition(base.gameObject.name, GetGridPosition());
		}
		if (trigger.Equals("HOVER"))
		{
			LastHoverPos = GetGridPosition();
			mapcontroller.obstacle.Add(LastHoverPos);
		}
		string[] array4 = base.name.Split('|');
		if (array4.Length > 3)
		{
			m_face_towards = int.Parse(array4[3]);
			if (m_face_towards == 0)
			{
				movement = int.Parse(array4[4]);
				MovingSpeedRate = float.Parse(array4[5], CultureInfo.InvariantCulture);
				string[] array5 = array4[6].Split('-');
				MinMoveGap = float.Parse(array5[0], CultureInfo.InvariantCulture);
				MaxMoveGap = float.Parse(array5[1], CultureInfo.InvariantCulture);
				m_AiType = "Wander";
			}
		}
		m_Init = true;
	}

	public void WarpTo(Vector3 _pos)
	{
		if (camera_control)
		{
			mapcontroller.m_CameraTarget.x = _pos.x;
			mapcontroller.m_CameraTarget.y = _pos.y;
			mapcontroller.m_CameraTarget.z = -10f;
		}
		base.transform.position = _pos;
		movePoint.position = _pos;
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
	}

	public void PlayAudioClip(string clipname)
	{
		if (pre_name.Equals("CAMERA") || pre_name.Equals("FootOn") || audioSource == null)
		{
			return;
		}
		float delay = 0f;
		if (!clipname.Equals(m_ClipPlaying))
		{
			AudioClip audioClip = null;
			audioSource.pitch = 1f;
			if (clipname == "walkClip")
			{
				audioClip = walkClip;
			}
			if (audioClip == null)
			{
				return;
			}
			audioSource.clip = audioClip;
			m_ClipPlaying = clipname;
		}
		StartCoroutine(PlayAudioClipDelay(delay));
	}

	protected IEnumerator PlayAudioClipDelay(float _delay)
	{
		yield return new WaitForSeconds(_delay);
		audioSource.Play();
	}

	public void PlaySceneMove(string _moves, MapController.Event _event = null)
	{
		string[] array = _moves.Split('&');
		foreach (string text in array)
		{
			if ("NEXTTOPLAYER".Equals(text))
			{
				string text2 = mapcontroller.player.SpaceNext2Me();
				if (!"".Equals(text2))
				{
					string[] array2 = text2.Split('|');
					m_SceneMoves.Add(new SceneMove
					{
						direction = array2[0],
						step = 1
					});
					m_SceneMoves.Add(new SceneMove
					{
						direction = "FACE",
						step = int.Parse(array2[1])
					});
				}
			}
			else
			{
				string[] array3 = text.Split('*');
				m_SceneMoves.Add(new SceneMove
				{
					direction = array3[0],
					step = int.Parse(array3[1])
				});
			}
		}
		m_MultiEvent = _event;
	}

	private void DoSceneMove()
	{
		m_TgtMov = false;
		if (m_SceneMoves[0].direction == "FORWARD")
		{
			Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
			setStartPos(vector3Int.x, -vector3Int.y, 0);
			switch (m_Direction)
			{
			case Direction.Up:
				setEndPos(vector3Int.x, -vector3Int.y - m_SceneMoves[0].step, 0);
				break;
			case Direction.Down:
				setEndPos(vector3Int.x, -vector3Int.y + m_SceneMoves[0].step, 0);
				break;
			case Direction.Right:
				setEndPos(vector3Int.x - m_SceneMoves[0].step, -vector3Int.y, 0);
				break;
			case Direction.Left:
				setEndPos(vector3Int.x + m_SceneMoves[0].step, -vector3Int.y, 0);
				break;
			}
			m_SceneMoves.RemoveAt(0);
			m_State = State.AStarInit;
			AStarSearchPath();
			return;
		}
		if (m_SceneMoves[0].direction == "FACE")
		{
			switch (m_SceneMoves[0].step)
			{
			case 0:
				Face(Direction.Down);
				break;
			case 1:
				Face(Direction.Right);
				break;
			case 2:
				Face(Direction.Up);
				break;
			case 3:
				Face(Direction.Left);
				break;
			}
			m_SceneMoves.RemoveAt(0);
			return;
		}
		if (m_SceneMoves[0].direction == "TARGET")
		{
			string text = "MV_TGT_" + m_SceneMoves[0].step;
			m_SceneMoves.RemoveAt(0);
			SuperObject superObject = null;
			SuperObject[] byName = mapcontroller.getByName(text);
			if (byName.Length != 0)
			{
				superObject = byName[0];
			}
			if (superObject != null)
			{
				Vector3Int vector3Int2 = mapcontroller.tilemap.WorldToCell(movePoint.position);
				setStartPos(vector3Int2.x, -vector3Int2.y, 0);
				vector3Int2 = mapcontroller.tilemap.WorldToCell(superObject.transform.position);
				setEndPos(vector3Int2.x, -vector3Int2.y, 0);
				if (!startPos.Equals(endPos))
				{
					m_TgtMov = true;
					m_State = State.AStarInit;
					AStarSearchPath();
				}
			}
			return;
		}
		Vector3Int vector3Int3 = mapcontroller.tilemap.WorldToCell(movePoint.position);
		setStartPos(vector3Int3.x, -vector3Int3.y, 0);
		string[] array = m_SceneMoves[0].direction.Split('-');
		switch (array[0])
		{
		case "UP":
			setEndPos(vector3Int3.x, -vector3Int3.y - m_SceneMoves[0].step, 0);
			break;
		case "DOWN":
			setEndPos(vector3Int3.x, -vector3Int3.y + m_SceneMoves[0].step, 0);
			break;
		case "LEFT":
			setEndPos(vector3Int3.x - m_SceneMoves[0].step, -vector3Int3.y, 0);
			break;
		case "RIGHT":
			setEndPos(vector3Int3.x + m_SceneMoves[0].step, -vector3Int3.y, 0);
			break;
		}
		m_KeepDirection = array.Length > 1 && array[1].Equals("KEEP");
		m_KeepAnimation = array.Length > 2 && array[2].Equals("KEEPANI");
		m_SceneMoves.RemoveAt(0);
		m_State = State.AStarInit;
		AStarSearchPath();
	}

	private void setStartPos(int _x, int _y, int _z)
	{
		startPos.x = _x;
		startPos.y = _y;
		startPos.z = _z;
	}

	private void setEndPos(int _x, int _y, int _z)
	{
		endPos.x = _x;
		endPos.y = _y;
		endPos.z = _z;
	}

	private IEnumerator AIWander()
	{
		float seconds = Random.Range(MinMoveGap, MaxMoveGap);
		int num = Random.Range(0, movement + 1);
		int num2 = movement - num;
		int num3 = ((!(Random.value < 0.5f)) ? 1 : (-1));
		int num4 = ((!(Random.value < 0.5f)) ? 1 : (-1));
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		setStartPos(vector3Int.x, -vector3Int.y, 0);
		vector3Int = mapcontroller.tilemap.WorldToCell(m_SpawnPoint);
		setEndPos(vector3Int.x + num3 * num, -vector3Int.y + num4 * num2, 0);
		if (startPos.Equals(endPos))
		{
			yield return new WaitForSeconds(seconds);
			m_WanderThread = false;
			m_State = State.MoveInit;
		}
		else
		{
			yield return new WaitForSeconds(seconds);
			AStarSearchPath();
		}
	}

	private void Tick()
	{
		if (m_State == State.MoveInit)
		{
			m_State = State.WaitingForInput;
		}
		else if (m_State == State.WaitingForInput)
		{
			if (m_ScenePlay == 1)
			{
				if (m_SceneMoves.Count > 0)
				{
					DoSceneMove();
					return;
				}
				MovingSpeedRate = DefMovingSpeedRate;
				m_ScenePlay = 2;
			}
			else
			{
				if (m_ScenePlay == 3)
				{
					return;
				}
				if (m_SceneMoves.Count > 0)
				{
					DoSceneMove();
				}
				else if (m_MultiEvent != null)
				{
					MovingSpeedRate = DefMovingSpeedRate;
					mapcontroller.EventComplete(m_MultiEvent);
					m_MultiEvent = null;
				}
				else
				{
					if (trigger.Equals("HOVER") || trigger.Equals("FOOTON") || pre_name.Equals("CAMERA"))
					{
						return;
					}
					if (m_AiType == "Wander")
					{
						if (!m_WanderThread)
						{
							m_WanderThread = true;
							m_State = State.AStarInit;
							StartCoroutine(AIWander());
						}
					}
					else if (m_face_towards > 0)
					{
						FaceToPlayer();
					}
				}
			}
		}
		else if (m_State == State.AStarWaiting)
		{
			AStarStepUpdate();
		}
		else if (m_State == State.AStarMoving)
		{
			AStarMove();
		}
	}

	public void FaceToPlayer(bool _event = false)
	{
		playerPos = mapcontroller.player.GetGridPosition();
		thisPos = GetGridPosition();
		int num = playerPos.x - thisPos.x;
		int num2 = playerPos.y - thisPos.y;
		int num3 = Mathf.Abs(num);
		int num4 = Mathf.Abs(num2);
		if (num4 > num3)
		{
			if (_event || num4 <= m_face_towards)
			{
				if (num2 > 0)
				{
					Face(Direction.Down);
				}
				else
				{
					Face(Direction.Up);
				}
			}
		}
		else if (_event || num3 <= m_face_towards)
		{
			if (num > 0)
			{
				Face(Direction.Left);
			}
			else
			{
				Face(Direction.Right);
			}
		}
	}

	private void AStarStepUpdate()
	{
		if (m_MoveProcess < 0)
		{
			m_WanderThread = false;
			AStarClean();
			m_State = State.MoveInit;
			PlayAnimation(aniname_stand);
			m_KeepDirection = false;
			if (trigger.Equals("HOVER"))
			{
				if (mapcontroller.obstacle.Contains(LastHoverPos))
				{
					mapcontroller.obstacle.Remove(LastHoverPos);
				}
				LastHoverPos = GetGridPosition();
				mapcontroller.obstacle.Add(LastHoverPos);
			}
			return;
		}
		if (m_MoveProcess < pathObject.Count - 1)
		{
			Object.Destroy(pathObject[m_MoveProcess + 1]);
		}
		if (!m_KeepDirection)
		{
			Vector2 vector = pathObject[m_MoveProcess].transform.localPosition;
			float num = vector.x - base.transform.localPosition.x;
			float num2 = vector.y - base.transform.localPosition.y;
			if (Mathf.Abs(num) > Mathf.Abs(num2))
			{
				if (num > 0f)
				{
					Face(Direction.Left);
				}
				else
				{
					Face(Direction.Right);
				}
			}
			else if (num2 > 0f)
			{
				Face(Direction.Up);
			}
			else
			{
				Face(Direction.Down);
			}
		}
		PlayAnimation(aniname_walk);
		PlayAudioClip("walkClip");
		AStarSeek(new Vector2(pathObject[m_MoveProcess].transform.localPosition.x, pathObject[m_MoveProcess].transform.localPosition.y));
		m_MoveProcess--;
	}

	private void AStarClean()
	{
		foreach (GameObject item in pathObject)
		{
			Object.Destroy(item);
		}
		pathObject.Clear();
		search.Clear();
		cost.Clear();
		pathSave.Clear();
		hadSearch.Clear();
	}

	private void Update()
	{
		if (m_Init && !mapcontroller.IsChating() && !mapcontroller.m_Menu2.IsOpen() && SharedData.Instance().LoadedSceneStack.Count <= 0)
		{
			Tick();
		}
	}

	public void Idle(string _sec)
	{
		m_ScenePlay = 3;
		StartCoroutine(Humiliate(_sec));
	}

	private IEnumerator Humiliate(string _sec)
	{
		yield return new WaitForSeconds(float.Parse(_sec, CultureInfo.InvariantCulture));
		m_ScenePlay = 2;
	}

	public void AStarSeek(Vector2 target)
	{
		m_MovingFrom = movePoint.position;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(target);
		movetov3.x = vector3Int.x;
		movetov3.y = -vector3Int.y;
		movetov3.z = 0;
		m_State = State.AStarMoving;
		m_MovingTo = target;
		movePoint.position = m_MovingTo;
		PlayAnimation(aniname_walk);
		PlayAudioClip("walkClip");
	}

	public void AStarMove()
	{
		base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, MovingSpeedRate * finalSpeed * Time.deltaTime);
		float num = 1f;
		if (camera_control)
		{
			mapcontroller.m_CameraTarget.x = base.transform.position.x;
			mapcontroller.m_CameraTarget.y = base.transform.position.y;
			mapcontroller.m_CameraTarget.z = -10f;
		}
		else
		{
			float num2 = Vector3.Distance(base.transform.position, mapcontroller.m_CameraTarget) - 50f;
			if (num2 < 0f)
			{
				num2 = 0f;
			}
			else if (num2 > 450f)
			{
				num2 = 450f;
			}
			num = (450f - num2) / 450f;
		}
		if (audioSource != null)
		{
			audioSource.volume = m_SEDefVolume * num;
		}
		if (Vector3.Distance(base.transform.position, movePoint.position) <= 1f)
		{
			if (!trigger.Equals("HOVER") && !trigger.Equals("FOOTON") && !pre_name.Equals("CAMERA"))
			{
				mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
			}
			AStarStepUpdate();
		}
	}

	public Vector3Int GetGridPositionMP()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(movePoint.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(movePoint.position.y) / 50f);
		return zero;
	}

	public void ChangeSkin()
	{
		if (m_SpriteRenderers.Length == 2)
		{
			m_SpriteRenderers[0].gameObject.SetActive(value: false);
			m_SpriteRenderers[1].gameObject.SetActive(value: true);
		}
	}

	public void TakeCamera(bool _init = false)
	{
		if (!camera_control)
		{
			camera_control = true;
			if (_init)
			{
				m_camera.transform.position = new Vector3(base.transform.position.x, base.transform.position.y, -10f);
				mapcontroller.m_CameraTarget = m_camera.transform.position;
			}
			else
			{
				mapcontroller.m_CameraTarget = new Vector3(base.transform.position.x, base.transform.position.y, -10f);
			}
		}
	}

	public void Show()
	{
		Face(m_Direction, isInit: true);
	}

	public void Hide()
	{
		if (m_Animations.Length != 0)
		{
			if (m_Animations.Length == 1)
			{
				m_Animations[0].gameObject.SetActive(value: false);
			}
			if (m_Animations.Length == 2)
			{
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
			}
			else if (m_Animations.Length == 3)
			{
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
			}
		}
		else if (m_SpriteRenderers.Length != 0 && m_SpriteRenderers.Length == 2)
		{
			m_SpriteRenderers[0].gameObject.SetActive(value: false);
			m_SpriteRenderers[1].gameObject.SetActive(value: false);
		}
	}

	public void Face(Direction direction, bool isInit = false)
	{
		if (m_Animations.Length >= 3 && (isInit || direction != m_Direction))
		{
			m_Direction = direction;
			switch (direction)
			{
			case Direction.Left:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = 1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			case Direction.Up:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: true);
				break;
			case Direction.Right:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = -1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			default:
				m_Animations[0].gameObject.SetActive(value: true);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			}
		}
	}

	public void PlayAnimationEnd(string animation, float timescale = 1f)
	{
		if (m_Animations.Length >= 3 && !m_KeepAnimation)
		{
			if (m_Animations[0].AnimationName != animation)
			{
				m_Animations[0].timeScale = 0f;
				TrackEntry trackEntry = m_Animations[0].AnimationState.SetAnimation(0, animation, loop: false);
				trackEntry.AnimationStart = trackEntry.AnimationEnd;
				m_Animations[0].timeScale = timescale;
			}
			if (m_Animations[1].AnimationName != animation)
			{
				m_Animations[1].timeScale = 0f;
				TrackEntry trackEntry2 = m_Animations[1].AnimationState.SetAnimation(0, animation, loop: false);
				trackEntry2.AnimationStart = trackEntry2.AnimationEnd;
				m_Animations[1].timeScale = timescale;
			}
			if (m_Animations[2].AnimationName != animation)
			{
				m_Animations[2].timeScale = 0f;
				TrackEntry trackEntry3 = m_Animations[2].AnimationState.SetAnimation(0, animation, loop: false);
				trackEntry3.AnimationStart = trackEntry3.AnimationEnd;
				m_Animations[2].timeScale = timescale;
			}
		}
	}

	public void PlayAnimation(string animation, bool loop = true, bool compensate = true, float timescale = 1f)
	{
		if (m_Animations.Length < 3 || m_KeepAnimation)
		{
			return;
		}
		if (loop && (animation.Equals(aniname_die) || animation.Equals(aniname_behit)))
		{
			loop = false;
		}
		if (m_Animations[0].AnimationName != animation)
		{
			m_Animations[0].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[0].skeleton.SetToSetupPose();
				m_Animations[0].AnimationState.ClearTracks();
			}
			m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[1].AnimationName != animation)
		{
			m_Animations[1].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[1].skeleton.SetToSetupPose();
				m_Animations[1].AnimationState.ClearTracks();
			}
			m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[2].AnimationName != animation)
		{
			m_Animations[2].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[2].skeleton.SetToSetupPose();
				m_Animations[2].AnimationState.ClearTracks();
			}
			m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}

	private void ShowOrHideWeapon(string animation)
	{
		if (animation.Contains("sword"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("knife"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("stick"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
		}
		else if (animation.Contains("hand"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("finger"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("heart"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		return zero;
	}

	private int RoundToGrid(float value)
	{
		if (value < 0f)
		{
			return Mathf.CeilToInt(value / 50f) * 50 - 25;
		}
		return Mathf.FloorToInt(value / 50f) * 50 + 25;
	}

	public int IsNextToMe(Vector3Int target)
	{
		int result = 0;
		if (m_State != State.AStarMoving)
		{
			Vector3Int gridPosition = GetGridPosition();
			Vector3Int other = gridPosition + Vector3Int.up;
			if (target.Equals(other))
			{
				return 1;
			}
			Vector3Int other2 = gridPosition + Vector3Int.right;
			if (target.Equals(other2))
			{
				return 2;
			}
			Vector3Int other3 = gridPosition - Vector3Int.right;
			if (target.Equals(other3))
			{
				return 4;
			}
			Vector3Int other4 = gridPosition - Vector3Int.up;
			if (target.Equals(other4))
			{
				return 3;
			}
		}
		return result;
	}

	public Vector3Int GetClosePosition(Vector3Int target)
	{
		Vector3Int result = Vector3Int.zero;
		Vector3Int vector3Int = mapcontroller.mapUnits[base.gameObject.name];
		Vector3Int vector3Int2 = vector3Int + Vector3Int.up;
		Vector3Int vector3Int3 = vector3Int + Vector3Int.right;
		Vector3Int vector3Int4 = vector3Int - Vector3Int.right;
		Vector3Int vector3Int5 = vector3Int - Vector3Int.up;
		int num = int.MaxValue;
		if (vector3Int2.y < mapcontroller.mapSize.y && mapcontroller.obstacle.Contains(vector3Int2) && !mapcontroller.mapUnits.Values.Contains(vector3Int2))
		{
			int heuristic = GetHeuristic(target, vector3Int2);
			if (heuristic < num)
			{
				num = heuristic;
				result = vector3Int2;
			}
		}
		if (vector3Int3.x < mapcontroller.mapSize.x && mapcontroller.obstacle.Contains(vector3Int3) && !mapcontroller.mapUnits.Values.Contains(vector3Int3))
		{
			int heuristic2 = GetHeuristic(target, vector3Int3);
			if (heuristic2 < num)
			{
				num = heuristic2;
				result = vector3Int3;
			}
		}
		if (vector3Int4.x >= 0 && mapcontroller.obstacle.Contains(vector3Int4) && !mapcontroller.mapUnits.Values.Contains(vector3Int4))
		{
			int heuristic3 = GetHeuristic(target, vector3Int4);
			if (heuristic3 < num)
			{
				num = heuristic3;
				result = vector3Int4;
			}
		}
		if (vector3Int5.y >= 0 && mapcontroller.obstacle.Contains(vector3Int5) && !mapcontroller.mapUnits.Values.Contains(vector3Int5))
		{
			int heuristic4 = GetHeuristic(target, vector3Int5);
			if (heuristic4 < num)
			{
				num = heuristic4;
				result = vector3Int5;
			}
		}
		return result;
	}

	public void AStarSearchPath()
	{
		search.Add(startPos, GetHeuristic(startPos, endPos));
		cost.Add(startPos, 0);
		hadSearch.Add(startPos);
		pathSave.Add(startPos, startPos);
		Vector3Int vector3Int = startPos;
		int num = int.MaxValue;
		while (search.Count > 0)
		{
			Vector3Int shortestPos = GetShortestPos();
			if (shortestPos.Equals(endPos))
			{
				break;
			}
			GetNeighbors(shortestPos);
			foreach (Vector3Int neighbor in m_neighbors)
			{
				if (!hadSearch.Contains(neighbor))
				{
					cost.Add(neighbor, cost[shortestPos] + 1);
					int heuristic = GetHeuristic(neighbor, endPos);
					search.Add(neighbor, cost[neighbor] + heuristic);
					pathSave.Add(neighbor, shortestPos);
					if (heuristic < num)
					{
						num = heuristic;
						vector3Int = neighbor;
					}
					hadSearch.Add(neighbor);
				}
			}
		}
		if (pathSave.ContainsKey(endPos))
		{
			ShowPath();
			return;
		}
		endPos = vector3Int;
		ShowPath();
	}

	private List<Vector3Int> GetNeighbors(Vector3Int target)
	{
		m_neighbors.Clear();
		Vector3Int item = target + Vector3Int.up;
		Vector3Int item2 = target + Vector3Int.right;
		Vector3Int item3 = target - Vector3Int.right;
		Vector3Int item4 = target - Vector3Int.up;
		if (!m_TgtMov && (trigger.Equals("HOVER") || trigger.Equals("FOOTON") || pre_name.Equals("CAMERA") || m_KeepDirection || m_ScenePlay > 0))
		{
			m_neighbors.Add(item);
			m_neighbors.Add(item2);
			m_neighbors.Add(item3);
			m_neighbors.Add(item4);
		}
		else
		{
			if (item.y < mapcontroller.mapSize.y && mapcontroller.obstacle.Contains(item))
			{
				m_neighbors.Add(item);
			}
			if (item2.x < mapcontroller.mapSize.x && mapcontroller.obstacle.Contains(item2))
			{
				m_neighbors.Add(item2);
			}
			if (item3.x >= 0 && mapcontroller.obstacle.Contains(item3))
			{
				m_neighbors.Add(item3);
			}
			if (item4.y >= 0 && mapcontroller.obstacle.Contains(item4))
			{
				m_neighbors.Add(item4);
			}
		}
		return m_neighbors;
	}

	private int GetHeuristic(Vector3Int posA, Vector3Int posB)
	{
		return Mathf.Abs(posA.x - posB.x) + Mathf.Abs(posA.y - posB.y);
	}

	private Vector3Int GetShortestPos()
	{
		KeyValuePair<Vector3Int, int> keyValuePair = new KeyValuePair<Vector3Int, int>(Vector3Int.zero, int.MaxValue);
		foreach (KeyValuePair<Vector3Int, int> item in search)
		{
			if (item.Value < keyValuePair.Value)
			{
				keyValuePair = item;
			}
		}
		search.Remove(keyValuePair.Key);
		return keyValuePair.Key;
	}

	private void ShowPath()
	{
		Vector3Int key = endPos;
		while (!key.Equals(startPos))
		{
			Vector3Int vector3Int = pathSave[key];
			Path = Object.Instantiate(PathPrefab, mapcontroller.map.transform);
			Path.transform.localPosition = new Vector3(25 + key.x * 50, -25 - key.y * 50);
			pathObject.Add(Path);
			m_Renderer = Path.GetComponentInChildren<SpriteRenderer>();
			m_Renderer.sortingOrder = ((m_SortingOrder > 0) ? m_SortingOrder : 0);
			key = vector3Int;
		}
		m_MoveProcess = pathObject.Count - 1;
		m_State = State.AStarWaiting;
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		if (!m_IsLoop)
		{
			if (trackEntry.Animation.Name == "B01-attack-sword")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B02-attack-knife")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B03-attack-stick")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B04-attack-hand")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B05-attack-finger")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "B06-attack-heart")
			{
				PlayAnimation("A01-stand");
			}
			else if (trackEntry.Animation.Name == "D01-behit")
			{
				PlayAnimation("A01-stand");
			}
			else
			{
				_ = trackEntry.Animation.Name == "D02-die";
			}
		}
	}

	public int GetMonoDirection()
	{
		return m_Direction switch
		{
			Direction.Down => 0, 
			Direction.Left => 1, 
			Direction.Up => 2, 
			Direction.Right => 3, 
			_ => 0, 
		};
	}
}
