public class ActionOrderItem
{
	public BattleObject battleObject;

	public ActionType counterType;

	public ActionOrderItem(BattleObject _battleObject, ActionType _counterType)
	{
		battleObject = _battleObject;
		counterType = _counterType;
	}
}
