public class EventRecord
{
	public gang_e01Table.Row originevdata;

	public gang_e01Table.Row evdata;

	public string display = "";

	public int flow = -1;

	public bool elseroute;

	public Direction objdirection = Direction.Down;

	public bool objcamarectrl;
}
