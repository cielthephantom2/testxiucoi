using MessagePack;

[MessagePackObject(false)]
public class BuffData
{
	[Key(0)]
	public string source = "";

	[Key(1)]
	public string name = "";

	[Key(2)]
	public float value;

	[Key(3)]
	public int turn;

	[Key(4)]
	public bool drunk;

	public string Print()
	{
		gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(name);
		return "【" + row.NameUI + ((value > 0f) ? "+" : "") + value + "】" + CommonFunc.ShortLangSel("剩余", "last") + " " + turn + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round");
	}

	public string PrintSimple()
	{
		gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(name);
		return "【" + row.NameUI + ((value > 0f) ? "+" : "") + value + "】";
	}

	public string PrintValue()
	{
		CommonResourcesData.a01.Find_Name(name);
		return ((value > 0f) ? "+" : "") + value;
	}
}
