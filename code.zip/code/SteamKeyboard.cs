public enum SteamKeyboard
{
	FloatingKeyboard,
	BigPictureKeyboard
}
