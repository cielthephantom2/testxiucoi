using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;

public class BattleJoyController : MonoBehaviour
{
	private bool isAttackCurcorMoving;

	private Vector2 m_MovingFrom;

	private Vector2 m_MovingTo;

	protected float m_MoveTimer;

	public static GameObject currentSelectWugong;

	private void Start()
	{
	}

	private void Update()
	{
		if (SharedData.Instance().m_BattleController == null || SharedData.Instance().m_MenuController == null || SharedData.Instance().m_BattleController.m_Flow == BattleControllerFlow.GameSet || (SharedData.Instance().m_BattleController.isLostControl && !SharedData.Instance().m_BattleController.AutoBattle) || SharedData.Instance().m_MenuController.m_PauseMenu.activeInHierarchy || CommonFunc.IsHoverOpen() || SharedData.Instance().m_MenuController.m_InteruptInfo.activeInHierarchy || SharedData.Instance().m_MenuController.m_FlowStatus.activeInHierarchy || SceneManager.sceneCount > 1)
		{
			return;
		}
		if (isAttackCurcorMoving)
		{
			AttackCurcorMovingProcess();
			return;
		}
		BattleController battleController = SharedData.Instance().m_BattleController;
		MenuController menuController = SharedData.Instance().m_MenuController;
		if ((menuController.m_menuState == BattleMenuState.AutoBattleShow || battleController.m_Flow == BattleControllerFlow.MoveWait || battleController.m_Flow == BattleControllerFlow.ActionWait) && menuController.m_menuState != BattleMenuState.WugongListShow)
		{
			CurcorMove();
			if (InputSystemCustom.Instance().Player.ShowCharacterInfo.WasReleasedThisFrame())
			{
				BattleObject battleObject = null;
				for (int i = 0; i < SharedData.Instance().m_BattleController.actionOrder.Count; i++)
				{
					if (SharedData.Instance().m_BattleController.actionOrder[i].battleObject.transform.position == SharedData.Instance().m_BattleController.m_curcor.transform.position)
					{
						battleObject = SharedData.Instance().m_BattleController.actionOrder[i].battleObject;
						break;
					}
				}
				if (battleObject == null)
				{
					return;
				}
				if (!SharedData.Instance().m_MenuController.m_FlowStatus.activeInHierarchy)
				{
					SharedData.Instance().m_MenuController.SetFlowStatus(battleObject);
				}
				else
				{
					SharedData.Instance().m_MenuController.CloseFlowStatus();
				}
			}
			if (InputSystemCustom.Instance().Player.Confirm.WasReleasedThisFrame())
			{
				Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position);
				SharedData.Instance().m_BattleController.m_curcor.CurcorPosition(new Vector3Int(vector3Int.x, -vector3Int.y, 0));
			}
			if (InputSystemCustom.Instance().Player.SelectCharacterNext.WasReleasedThisFrame())
			{
				BattleObject battleObject2 = null;
				for (int j = 0; j < battleController.actionOrder.Count; j++)
				{
					if (!(battleController.actionOrder[j].battleObject.transform.position == SharedData.Instance().m_BattleController.m_curcor.transform.position))
					{
						continue;
					}
					for (int k = 1; k < battleController.actionOrder.Count; k++)
					{
						int index = (j + k) % battleController.actionOrder.Count;
						if (!battleController.actionOrder[index].battleObject.isDead)
						{
							battleObject2 = battleController.actionOrder[index].battleObject;
							break;
						}
					}
					break;
				}
				if (battleObject2 != null)
				{
					Vector3Int vector3Int2 = battleController.tilemap.WorldToCell(battleObject2.transform.position);
					SharedData.Instance().m_BattleController.m_curcor.CurcorPosition(new Vector3Int(vector3Int2.x, -vector3Int2.y, 0));
					battleController.SetCameraSmooth(battleObject2, isSetCurcor: true);
				}
			}
			else if (InputSystemCustom.Instance().Player.SelectCharacterPrev.WasReleasedThisFrame())
			{
				BattleObject battleObject3 = null;
				for (int l = 0; l < battleController.actionOrder.Count; l++)
				{
					if (!(battleController.actionOrder[l].battleObject.transform.position == SharedData.Instance().m_BattleController.m_curcor.transform.position))
					{
						continue;
					}
					for (int m = 1; m < battleController.actionOrder.Count; m++)
					{
						int index2 = (l - m + battleController.actionOrder.Count) % battleController.actionOrder.Count;
						if (!battleController.actionOrder[index2].battleObject.isDead)
						{
							battleObject3 = battleController.actionOrder[index2].battleObject;
							break;
						}
					}
					break;
				}
				if (battleObject3 != null)
				{
					Vector3Int vector3Int3 = battleController.tilemap.WorldToCell(battleObject3.transform.position);
					SharedData.Instance().m_BattleController.m_curcor.CurcorPosition(new Vector3Int(vector3Int3.x, -vector3Int3.y, 0));
					battleController.SetCameraSmooth(battleObject3, isSetCurcor: true);
				}
			}
		}
		if (menuController.m_menuState == BattleMenuState.WugongListShow && !EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").enabled)
		{
			CurcorMove();
			if (InputSystemCustom.Instance().Player.Confirm.WasReleasedThisFrame())
			{
				Vector3Int vector3Int4 = SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position);
				if (SharedData.Instance().m_BattleController.current.attackSelectRange.Contains(new Vector3Int(vector3Int4.x, -vector3Int4.y, 0)))
				{
					EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").Enable();
				}
				SharedData.Instance().m_BattleController.m_curcor.CurcorPosition(new Vector3Int(vector3Int4.x, -vector3Int4.y, 0));
			}
		}
		if (InputSystemCustom.Instance().Player.AutoBattle.WasReleasedThisFrame())
		{
			SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/CancelAuto").GetComponent<EventTriggerListener>().onClick(SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/CancelAuto").gameObject);
			SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Auto").GetComponent<EventTriggerListener>().onClick(SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Auto").gameObject);
		}
		else if (InputSystemCustom.Instance().Player.AttackShortCut.WasReleasedThisFrame())
		{
			SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Attack").GetComponent<EventTriggerListener>().onClick(SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Attack").gameObject);
		}
		else if (InputSystemCustom.Instance().Player.OpenPackageShortCut.WasReleasedThisFrame())
		{
			SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Item").GetComponent<EventTriggerListener>().onClick(SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Item").gameObject);
		}
		else if (InputSystemCustom.Instance().Player.RestShortCut.WasReleasedThisFrame())
		{
			SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Cancel").GetComponent<EventTriggerListener>().onClick(SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Cancel").gameObject);
		}
		else if (InputSystemCustom.Instance().Player.EscapeShortCut.WasReleasedThisFrame())
		{
			SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Escape").GetComponent<EventTriggerListener>().onClick(SharedData.Instance().m_BattleController.m_MenuController.transform.Find("ActionMenu/Escape").gameObject);
		}
	}

	private void CurcorMove()
	{
		Vector2 vector = InputSystemCustom.Instance().Player.BattleCurcorMove.ReadValue<Vector2>();
		if (!(vector == Vector2.zero))
		{
			AttackCurcorMove(vector);
		}
	}

	public int AttackCurcorMove(Vector2 curcorMoveInput)
	{
		if (Mathf.Abs(curcorMoveInput.x) > Mathf.Abs(curcorMoveInput.y))
		{
			curcorMoveInput.y = 0f;
		}
		else
		{
			curcorMoveInput.x = 0f;
		}
		Vector2 zero = Vector2.zero;
		int result = 0;
		if (curcorMoveInput.x != 0f)
		{
			zero.x = curcorMoveInput.x;
			zero.y = 0f;
			if (curcorMoveInput.x > 0f)
			{
				SharedData.Instance().m_BattleController.current.Face(Direction.Left);
				result = 4;
			}
			else
			{
				SharedData.Instance().m_BattleController.current.Face(Direction.Right);
				result = 2;
			}
		}
		else if (curcorMoveInput.y != 0f)
		{
			zero.x = 0f;
			zero.y = curcorMoveInput.y;
			if (curcorMoveInput.y > 0f)
			{
				SharedData.Instance().m_BattleController.current.Face(Direction.Up);
				result = 3;
			}
			else
			{
				SharedData.Instance().m_BattleController.current.Face(Direction.Down);
				result = 1;
			}
		}
		zero.Normalize();
		if (curcorMoveInput.SqrMagnitude() > 0f)
		{
			SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position);
			Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position + (Vector3)zero * CommonVariables.MovementBlockSize);
			new Vector3Int(vector3Int.x, -vector3Int.y, 0);
			isAttackCurcorMoving = true;
			m_MovingFrom = SharedData.Instance().m_BattleController.m_curcor.transform.position;
			m_MovingTo = (Vector2)SharedData.Instance().m_BattleController.m_curcor.transform.position + zero * CommonVariables.MovementBlockSize;
		}
		return result;
	}

	private void AttackCurcorMovingProcess()
	{
		m_MoveTimer += Time.deltaTime;
		float num = m_MoveTimer / CommonVariables.TimeToMoveOneBlock;
		Vector2 vector = Vector2.Lerp(m_MovingFrom, m_MovingTo, num);
		SharedData.Instance().m_BattleController.SetCameraSmooth(vector);
		SharedData.Instance().m_BattleController.m_curcor.transform.position = vector;
		if (num >= 1f)
		{
			Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(SharedData.Instance().m_BattleController.m_curcor.transform.position);
			Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
			if (SharedData.Instance().m_BattleController.m_Flow == BattleControllerFlow.ActionWaitAttack)
			{
				SharedData.Instance().m_BattleController.m_curcor.CurcorPosition(pos, pressing: true);
				SharedData.Instance().m_BattleController.ShowHpGaugeInAttackRange();
			}
			isAttackCurcorMoving = false;
			m_MoveTimer = Mathf.Repeat(m_MoveTimer, CommonVariables.TimeToMoveOneBlock);
		}
	}
}
