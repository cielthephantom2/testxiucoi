internal enum PackageFilterType
{
	Use,
	Style
}
