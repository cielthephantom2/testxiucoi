using UnityEngine;

public class JoyIconNavigate : MonoBehaviour
{
	private string gamepad = "None";

	private void Start()
	{
	}

	private void Update()
	{
		if (InputDeviceDetector.instance.gamePadType != gamepad && GameDataManager.Instance().configdata.gameIconType.Equals(GameIconType.Auto))
		{
			if (InputDeviceDetector.instance.gamePadType == "Mouse" || InputDeviceDetector.instance.gamePadType == "Keyboard" || InputDeviceDetector.instance.gamePadType == "")
			{
				base.transform.Find("KeyBoard").gameObject.SetActive(value: true);
				base.transform.Find("GamePad").gameObject.SetActive(value: false);
			}
			else
			{
				base.transform.Find("KeyBoard").gameObject.SetActive(value: false);
				base.transform.Find("GamePad").gameObject.SetActive(value: true);
			}
			gamepad = InputDeviceDetector.instance.gamePadType;
		}
		if (!GameDataManager.Instance().configdata.gameIconType.Equals(GameIconType.Auto))
		{
			if (GameDataManager.Instance().configdata.gameIconType.Equals(GameIconType.KeyBoard) && !base.transform.Find("KeyBoard").gameObject.activeInHierarchy)
			{
				base.transform.Find("KeyBoard").gameObject.SetActive(value: true);
				base.transform.Find("GamePad").gameObject.SetActive(value: false);
			}
			else if (!GameDataManager.Instance().configdata.gameIconType.Equals(GameIconType.KeyBoard) && !base.transform.Find("GamePad").gameObject.activeInHierarchy)
			{
				base.transform.Find("KeyBoard").gameObject.SetActive(value: false);
				base.transform.Find("GamePad").gameObject.SetActive(value: true);
			}
		}
	}
}
