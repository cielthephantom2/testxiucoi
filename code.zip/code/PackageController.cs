using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using SuperScrollView;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PackageController : MonoBehaviour
{
	public bool isInheritance;

	public LoopGridView packageLoopGrid;

	private int colCount = 7;

	private List<PackageItemData> mPackageDataSourceMgr_Filter = new List<PackageItemData>();

	private const int EnmptyBlankCount = 40;

	public PackagerFunction packagerFunction;

	private GameObject SelectedBtn;

	private PackageItemData SelectedPackageItem;

	private List<Button> AllInteractiveButtons;

	private int bannercount;

	private string packageTopFilter = "11111111111";

	private string packageSubFilter = "";

	private string tmpTopFilter = "11111111111";

	private string tmpSubFilter = "";

	private string[] packageStyleFilters = new string[0];

	private PackageFilterType packageFilterType;

	private PackageSortType packageSortType;

	public static string skillLevekUpCharaID = "";

	private Dictionary<string, int> InheritanceDict = new Dictionary<string, int>();

	[HideInInspector]
	public Dictionary<string, int> AppreciationIdValueDict = new Dictionary<string, int>();

	private GameObject NormalPackageRetBtn;

	private GameObject ComfirmInheritBtn;

	private GameObject TopRetBtn;

	private GameObject DetailBtn;

	private GameObject UseBtn;

	private GameObject CancelUseBtn;

	private GameObject EquipBtn;

	private GameObject UnEquipBtn;

	private GameObject ShopBtn;

	private GameObject BulkBtn;

	private GameObject LoanBtn;

	private GameObject RedeemBtn;

	private GameObject AppreciationBtn;

	private GameObject InheritanceBtn;

	private GameObject FilterBtn;

	private bool isButtonClicking;

	private bool isFreshingPackage;

	public GameObject SelectPanel;

	private GameObject InfoPanel;

	private GameObject DetailPanel;

	private ScrollRect PackagePanel;

	private GameObject ShopPanel;

	[HideInInspector]
	public Transform ShopHoverItem;

	[HideInInspector]
	public Transform ShopHoverWuGong;

	private AudioSource m_AudioSource;

	private PackageFilterPanelType packageFilterPanelType;

	[SerializeField]
	private BulkWallet bulkWalletPanel;

	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	private Sprite InheritanceSprite;

	public AudioClip m_ShopPay;

	public AudioClip m_ShopError;

	public bool isOpen => base.transform.Find("Panel").gameObject.activeInHierarchy;

	public bool isShop => ShopPanel.gameObject.activeInHierarchy;

	public int currencyValue
	{
		get
		{
			if (SelectedPackageItem.priceType.Equals(PriceType.oldcoin))
			{
				int result = 0;
				if (SharedData.Instance().PlayerPackage.ContainsKey("998"))
				{
					result = SharedData.Instance().PlayerPackage["998"];
				}
				return result;
			}
			if (SelectedPackageItem.priceType.Equals(PriceType.bone))
			{
				int result2 = 0;
				if (SharedData.Instance().PlayerPackage.ContainsKey("997"))
				{
					result2 = SharedData.Instance().PlayerPackage["997"];
				}
				return result2;
			}
			return SharedData.Instance().m_Money;
		}
		set
		{
			if (SelectedPackageItem.priceType.Equals(PriceType.oldcoin))
			{
				if (SharedData.Instance().PlayerPackage.ContainsKey("998"))
				{
					SharedData.Instance().PlayerPackage["998"] = value;
				}
			}
			else if (SelectedPackageItem.priceType.Equals(PriceType.bone))
			{
				if (SharedData.Instance().PlayerPackage.ContainsKey("997"))
				{
					SharedData.Instance().PlayerPackage["997"] = value;
				}
			}
			else if (SelectedPackageItem.priceType.Equals(PriceType.money))
			{
				SharedData.Instance().m_Money = value;
			}
		}
	}

	private void Start()
	{
		base.transform.Find("Panel").gameObject.SetActive(value: false);
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		NormalSprite = CommonResourcesData.NormalPackageIconSprite;
		SelectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		InheritanceSprite = CommonResourcesData.InheritanceSprite;
		m_ShopPay = (AudioClip)Resources.Load("Music/SE/Got_Money");
		m_ShopError = (AudioClip)Resources.Load("Music/SE/Error");
		if (isInheritance)
		{
			SelectPanel = base.transform.Find("Panel/SelectInheritance").gameObject;
		}
		else
		{
			SelectPanel = base.transform.Find("Panel/Select").gameObject;
		}
		InfoPanel = base.transform.Find("Panel/Info").gameObject;
		DetailPanel = base.transform.Find("Panel/DetailBox").gameObject;
		PackagePanel = base.transform.Find("Panel/Package").GetComponent<ScrollRect>();
		ShopPanel = base.transform.Find("Panel/Shop").gameObject;
		ShopHoverItem = ShopPanel.transform.Find("HoverItem");
		ShopHoverWuGong = ShopPanel.transform.Find("HoverWuGong");
		m_AudioSource = GetComponent<AudioSource>();
		NormalPackageRetBtn = base.transform.Find("Panel/Title/Btns/NormalReturn").gameObject;
		ComfirmInheritBtn = base.transform.Find("Panel/Title/Btns/ComfirmInherit").gameObject;
		TopRetBtn = ShopPanel.transform.Find("TopBanner/TopReturn").gameObject;
		DetailBtn = DetailPanel.transform.Find("Btns/OpenDetail").gameObject;
		UseBtn = DetailPanel.transform.Find("Btns/Use").gameObject;
		CancelUseBtn = DetailPanel.transform.Find("Btns/CancelUse").gameObject;
		EquipBtn = DetailPanel.transform.Find("Btns/Equip").gameObject;
		UnEquipBtn = DetailPanel.transform.Find("Btns/UnEquip").gameObject;
		ShopBtn = DetailPanel.transform.Find("Btns/Shop").gameObject;
		BulkBtn = DetailPanel.transform.Find("Btns/BulkShop").gameObject;
		LoanBtn = DetailPanel.transform.Find("Btns/Loan").gameObject;
		RedeemBtn = DetailPanel.transform.Find("Btns/Redeem").gameObject;
		AppreciationBtn = DetailPanel.transform.Find("Btns/Appreciation").gameObject;
		InheritanceBtn = DetailPanel.transform.Find("Btns/Inheritance").gameObject;
		FilterBtn = base.transform.Find("Panel/Title/Btns/FilterPanel").gameObject;
		AllInteractiveButtons = base.transform.GetComponentsInChildren<Button>(includeInactive: true).ToList();
		foreach (Button allInteractiveButton in AllInteractiveButtons)
		{
			EventTriggerListener.Get(allInteractiveButton.gameObject).onClick = OnButtonClick;
		}
		for (int i = 1; i <= 4; i++)
		{
			InfoPanel.transform.Find("Banner" + i).gameObject.SetActive(value: false);
		}
		bannercount = 0;
		InfoPanel.SetActive(value: false);
		packageLoopGrid.InitGridView(mPackageDataSourceMgr_Filter.Count, OnGetPackageItemByRowColumn);
		InitLoopGridViewColumnCount();
		if (isInheritance)
		{
			GameDataManager.Instance().configdata.InheritItemCount = SharedData.Instance().m_PlayRound + (SharedData.Instance().player.charadata.m_TraitList.Contains("50002") ? 1 : 0);
			if (GameDataManager.Instance().configdata.InheritItemCount > 5)
			{
				GameDataManager.Instance().configdata.InheritItemCount = 5;
			}
			OpenPackage(refresh: true, PackagerFunction.Inheritance);
			if (GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count > 0)
			{
				base.transform.Find("Panel/Title/InheritanceText").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Inheritance_Title"), "green", GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count);
			}
			else
			{
				base.transform.Find("Panel/Title/InheritanceText").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Inheritance_Title"), "red", GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count);
			}
		}
	}

	private void Update()
	{
		if (CommonFunc.IsHoverOpen() || (bool)SharedData.Instance().levelUpController || isFreshingPackage || (SharedData.Instance().LoadedSceneStack.Count > 0 && SharedData.Instance().LoadedSceneStack[SharedData.Instance().LoadedSceneStack.Count - 1].Equals("LevelUpSkill")) || !base.transform.Find("Panel").gameObject.activeSelf)
		{
			return;
		}
		if (InfoPanel.activeSelf)
		{
			if (Input.GetMouseButtonDown(0) || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
			{
				for (int i = 1; i <= 4; i++)
				{
					InfoPanel.transform.Find("Banner" + i).gameObject.SetActive(value: false);
				}
				bannercount = 0;
				InfoPanel.SetActive(value: false);
				SharedData.Instance().m_OpenDetail = "";
			}
			return;
		}
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputDeviceDetector.isMouse1Up)
		{
			if (SelectPanel.activeInHierarchy)
			{
				OnButtonClick(FilterBtn);
			}
			else if (NormalPackageRetBtn.activeInHierarchy)
			{
				OnButtonClick(NormalPackageRetBtn);
			}
			else if (TopRetBtn.activeInHierarchy)
			{
				OnButtonClick(TopRetBtn);
			}
			else if (ComfirmInheritBtn.activeInHierarchy)
			{
				OnButtonClick(ComfirmInheritBtn);
			}
		}
		else if (InputSystemCustom.Instance().UI.PackageUse.WasReleasedThisFrame())
		{
			if (UseBtn.activeInHierarchy)
			{
				OnButtonClick(UseBtn);
			}
			else if (CancelUseBtn.activeInHierarchy)
			{
				OnButtonClick(CancelUseBtn);
			}
			else if (EquipBtn.activeInHierarchy)
			{
				OnButtonClick(EquipBtn);
			}
			else if (UnEquipBtn.activeInHierarchy)
			{
				OnButtonClick(UnEquipBtn);
			}
			else if (ShopBtn.activeInHierarchy)
			{
				OnButtonClick(ShopBtn);
			}
			else if (LoanBtn.activeInHierarchy)
			{
				OnButtonClick(LoanBtn);
			}
			else if (RedeemBtn.activeInHierarchy)
			{
				OnButtonClick(RedeemBtn);
			}
			else if (AppreciationBtn.activeInHierarchy)
			{
				OnButtonClick(AppreciationBtn);
			}
			else if (InheritanceBtn.activeInHierarchy)
			{
				OnButtonClick(InheritanceBtn);
			}
		}
		else if (InputSystemCustom.Instance().UI.PackageBulkShop.WasReleasedThisFrame())
		{
			if (BulkBtn.activeInHierarchy)
			{
				OnButtonClick(BulkBtn);
			}
		}
		else if (InputSystemCustom.Instance().UI.PackageFilter.WasReleasedThisFrame())
		{
			OnButtonClick(FilterBtn);
		}
		else if (InputSystemCustom.Instance().UI.ShowFullName.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Title/Btns/FullNameArea/FullName").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.ShouHoverItem.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(DetailBtn, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		if (EventSystem.current.currentSelectedGameObject != null && SelectedBtn != EventSystem.current.currentSelectedGameObject && EventSystem.current.currentSelectedGameObject.name.StartsWith("ItemBtn") && !InputDeviceDetector.instance.isMouseInput)
		{
			OnButtonClick(EventSystem.current.currentSelectedGameObject);
		}
	}

	private void InitLoopGridViewColumnCount()
	{
		colCount = Mathf.FloorToInt((packageLoopGrid.transform.Find("Viewport").GetComponent<RectTransform>().rect.width - (float)packageLoopGrid.Padding.left) / (packageLoopGrid.ItemSize.x + packageLoopGrid.ItemPadding.x));
		packageLoopGrid.SetGridFixedGroupCount(GridFixedType.ColumnCountFixed, colCount);
		packageLoopGrid.UpdateColumnRowCount();
	}

	private LoopGridViewItem OnGetPackageItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		PackageItemData packageItemData = mPackageDataSourceMgr_Filter[index];
		if (packageItemData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("PackageIcon");
		PackageIconController component = loopGridViewItem.GetComponent<PackageIconController>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		string key = "ItemBtn|" + packageItemData.ID + "|" + ((packageItemData.b07Row != null) ? packageItemData.b07Row.Use : "") + "|" + ((packageItemData.userData != null) ? packageItemData.userData.m_Id : "null");
		component.InitPackageIcon(packageItemData, isShowHeadIcoN: false, InheritanceDict.ContainsKey(packageItemData.ID), AppreciationIdValueDict.ContainsKey(key));
		EventTriggerListener.Get(loopGridViewItem.gameObject).onClick = OnButtonClick;
		return loopGridViewItem;
	}

	public void ClosePackage()
	{
		SharedData.Instance().LoadSceneStackRemove("Package");
		base.transform.Find("Panel").gameObject.SetActive(value: false);
		for (int i = 1; i <= 4; i++)
		{
			InfoPanel.transform.Find("Banner" + i).gameObject.SetActive(value: false);
		}
		bannercount = 0;
		InfoPanel.SetActive(value: false);
		SharedData.Instance().m_OpenDetail = "";
		SharedData.Instance().OpenPackagerFunction = PackagerFunction.None;
		SharedData.Instance().m_StatusMain.GetComponent<CanvasGroup>().interactable = true;
		SharedData.Instance().m_StatusSub3.GetComponent<CanvasGroup>().interactable = true;
		SharedData.Instance().m_StatusSub4.GetComponent<CanvasGroup>().interactable = true;
		SharedData.Instance().m_StatusSub5.GetComponent<CanvasGroup>().interactable = true;
		if (SharedData.Instance().m_MenuController != null)
		{
			SharedData.Instance().m_MenuController.GetComponent<CanvasGroup>().interactable = true;
		}
		if ((bool)SharedData.Instance().m_EvolutionEqNewController)
		{
			SharedData.Instance().m_EvolutionEqNewController.GetComponent<CanvasGroup>().interactable = true;
		}
		PackagePanel.content.GetComponentsInChildren<PackageIconController>().ToList().ForEach(delegate(PackageIconController t)
		{
			t.GetComponent<Image>().sprite = NormalSprite;
		});
	}

	public void OpenPackage(bool refresh = true, PackagerFunction _packagerFunction = PackagerFunction.None, string _topFilter = "11111111111", string _subFilter = "")
	{
		if (refresh)
		{
			packageFilterType = PackageFilterType.Use;
			packageTopFilter = "11111111111";
			packageSubFilter = "";
			tmpTopFilter = "11111111111";
			tmpSubFilter = "";
			FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter");
			base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllItem");
		}
		base.transform.Find("Panel/Title/Btns/Sorter|Forward|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Forward) ? SelectedSprite : NormalSprite);
		base.transform.Find("Panel/Title/Btns/Sorter|Reverse|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Reverse) ? SelectedSprite : NormalSprite);
		base.transform.Find("Panel/Title/Btns/Sorter|Resort|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Resort) ? SelectedSprite : NormalSprite);
		if (_packagerFunction.Equals(PackagerFunction.Equip) || _packagerFunction.Equals(PackagerFunction.Wugong) || _packagerFunction.Equals(PackagerFunction.EvolutionEQ))
		{
			base.transform.Find("Panel").GetComponent<Image>().enabled = true;
		}
		else
		{
			base.transform.Find("Panel").GetComponent<Image>().enabled = false;
		}
		PackagePanel.GetComponent<CanvasGroup>().interactable = true;
		base.transform.Find("Panel").gameObject.SetActive(value: true);
		SharedData.Instance().LoadSceneStackAdd("Package");
		base.transform.Find("Panel/Title/Btns/FullNameArea/FullName/Checkmark").gameObject.SetActive(SharedData.Instance().isShowFullName);
		packagerFunction = _packagerFunction;
		SharedData.Instance().OpenPackagerFunction = packagerFunction;
		tmpTopFilter = _topFilter;
		tmpSubFilter = _subFilter;
		if (packagerFunction != PackagerFunction.PlayerPackage)
		{
			SharedData.Instance().m_StatusMain.GetComponent<CanvasGroup>().interactable = false;
			SharedData.Instance().m_StatusSub3.GetComponent<CanvasGroup>().interactable = false;
			SharedData.Instance().m_StatusSub4.GetComponent<CanvasGroup>().interactable = false;
			SharedData.Instance().m_StatusSub5.GetComponent<CanvasGroup>().interactable = false;
			if ((bool)SharedData.Instance().m_EvolutionEqNewController)
			{
				SharedData.Instance().m_EvolutionEqNewController.GetComponent<CanvasGroup>().interactable = false;
			}
		}
		if (packagerFunction == PackagerFunction.BattleField)
		{
			SharedData.Instance().m_MenuController.GetComponent<CanvasGroup>().interactable = false;
		}
		InitUI();
		SelectedBtn = null;
		SelectedPackageItem = null;
		RefreshPackageUIList(packageFilterType);
	}

	private void RefreshPackageUIList(PackageFilterType _PackageFilterType = PackageFilterType.Use, PackageSortType _packageSortType = PackageSortType.Forward)
	{
		isFreshingPackage = true;
		packageFilterType = _PackageFilterType;
		int num = mPackageDataSourceMgr_Filter.IndexOf(SelectedPackageItem);
		List<PackageItemData> list = null;
		list = ((_packageSortType == PackageSortType.Forward) ? GetPackageList(packagerFunction, packageSortType) : GetPackageList(packagerFunction, _packageSortType));
		if (_PackageFilterType.Equals(PackageFilterType.Use))
		{
			list.RemoveAll((PackageItemData t) => !CouldPassUseFilter(t.b07Row, tmpTopFilter, tmpSubFilter, FilterBtn.activeInHierarchy, packageTopFilter, packageSubFilter));
		}
		else
		{
			list.RemoveAll((PackageItemData t) => !CouldPassStyleFilter(t.b07Row, packageStyleFilters));
		}
		mPackageDataSourceMgr_Filter = list;
		if (isInheritance)
		{
			colCount = 13;
		}
		int num2 = colCount - mPackageDataSourceMgr_Filter.Count % colCount;
		if (num2 == 0)
		{
			num2 = colCount;
		}
		while (--num2 >= 0)
		{
			mPackageDataSourceMgr_Filter.Add(new PackageItemData
			{
				ID = num2.ToString()
			});
		}
		packageLoopGrid.SetListItemCount(mPackageDataSourceMgr_Filter.Count, resetPos: false);
		packageLoopGrid.RefreshAllShownItem();
		InputDeviceDetector.instance.SetJoyCurseParent(null);
		EventSystem.current.SetSelectedGameObject(null);
		int num3 = -1;
		if (SelectedPackageItem != null)
		{
			PackageItemData item = mPackageDataSourceMgr_Filter.Find((PackageItemData x) => x.b07Row == SelectedPackageItem.b07Row && x.ID == SelectedPackageItem.ID);
			num3 = mPackageDataSourceMgr_Filter.IndexOf(item);
		}
		if (num3 == -1)
		{
			num3 = num;
		}
		if (num3 == -1)
		{
			num3 = 0;
		}
		num3 = Mathf.Clamp(num3, 0, mPackageDataSourceMgr_Filter.Count - 1);
		SelectedPackageItem = mPackageDataSourceMgr_Filter[num3];
		LoopGridViewItem shownItemByItemIndex = packageLoopGrid.GetShownItemByItemIndex(num3);
		if (num3 != num || shownItemByItemIndex == null)
		{
			packageLoopGrid.MovePanelToItemByIndex(num3);
		}
		StartCoroutine(DelayClickSelectedItem(num3, num));
		RefreshShopCash();
	}

	private IEnumerator DelayClickSelectedItem(int newSelectedIndex, int oldSelectedIndex)
	{
		yield return null;
		LoopGridViewItem shownItemByItemIndex = packageLoopGrid.GetShownItemByItemIndex(newSelectedIndex);
		UpdatePackageItemDetail(shownItemByItemIndex?.gameObject);
		SelectedBtn = shownItemByItemIndex?.gameObject;
		if (SelectedBtn != null && (object)SelectedBtn.GetComponent<HoverWGController>() != null && (packagerFunction == PackagerFunction.Shop || packagerFunction == PackagerFunction.Redeem || packagerFunction == PackagerFunction.Loan))
		{
			StartCoroutine(CommonFunc.DelayedOpenHoverOperation(SelectedBtn, showEquip: false));
		}
		if (oldSelectedIndex == newSelectedIndex)
		{
			InputDeviceDetector.instance.SetJoyCurseParent(shownItemByItemIndex.transform);
			EventSystem.current.SetSelectedGameObject(shownItemByItemIndex?.gameObject);
		}
		isFreshingPackage = false;
	}

	public static bool CouldPassUseFilter(gang_b07Table.Row b07Row, string _tmpTopFilter, string _tmpSubFilter, bool isFilterBtnActive, string _packageTopFilter, string _packageSubFilter)
	{
		if (b07Row == null)
		{
			return true;
		}
		string text = "";
		string text2 = "";
		if (isFilterBtnActive)
		{
			text = _packageTopFilter;
			text2 = _packageSubFilter;
		}
		else
		{
			text = _tmpTopFilter;
			text2 = _tmpSubFilter;
		}
		bool flag = false;
		for (int i = 0; i < b07Row.Use.Length && i < text.Length; i++)
		{
			if (b07Row.Use[i] == '1' && text[i] == '1')
			{
				flag = true;
				break;
			}
		}
		if (flag && text2 != "")
		{
			flag = false;
			if (text == "0000000010")
			{
				if (CommonResourcesData.b03.Find_ID(b07Row.Relateid).Style == text2)
				{
					flag = true;
				}
			}
			else if (text == "0010000000")
			{
				gang_b02Table.Row row = CommonResourcesData.b02.Find_ID(b07Row.Relateid);
				if (text2.Equals(row.atlasType))
				{
					flag = true;
				}
			}
		}
		return flag;
	}

	public static bool CouldPassStyleFilter(gang_b07Table.Row b07Row, string[] _Styles)
	{
		if (b07Row == null)
		{
			return true;
		}
		if (_Styles.Contains(b07Row.Style))
		{
			return true;
		}
		return false;
	}

	private void InitUI()
	{
		ShopPanel.SetActive(value: false);
		SelectPanel.SetActive(value: false);
		ShopHoverItem.gameObject.SetActive(value: false);
		ShopHoverWuGong.gameObject.SetActive(value: false);
		CommonFunc.CloseHover();
		if (packagerFunction == PackagerFunction.Shop || packagerFunction == PackagerFunction.Loan || packagerFunction == PackagerFunction.Redeem || packagerFunction == PackagerFunction.Appreciation)
		{
			if (packagerFunction == PackagerFunction.Shop || packagerFunction == PackagerFunction.Loan || packagerFunction == PackagerFunction.Redeem)
			{
				FilterBtn.SetActive(value: true);
				InitFilterPanel(PackageFilterPanelType.All);
			}
			else if (packagerFunction == PackagerFunction.Appreciation)
			{
				FilterBtn.SetActive(value: false);
			}
			NormalPackageRetBtn.gameObject.SetActive(value: false);
			InitShopLoanRedeemAppreciationPanel();
			base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllItem");
		}
		else if (packagerFunction == PackagerFunction.BattleField || packagerFunction == PackagerFunction.Equip || packagerFunction == PackagerFunction.EvolutionEQ || packagerFunction == PackagerFunction.Wugong)
		{
			NormalPackageRetBtn.gameObject.SetActive(value: true);
			if (packagerFunction == PackagerFunction.BattleField)
			{
				base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllBattleItems");
				FilterBtn.SetActive(value: false);
			}
			else if (packagerFunction == PackagerFunction.Equip)
			{
				if (tmpTopFilter == "00100000000")
				{
					base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllWeapon");
				}
				else if (tmpTopFilter == "00010000000")
				{
					base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllGear");
				}
				else if (tmpTopFilter == "00001000000")
				{
					base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllAccessory");
				}
				FilterBtn.SetActive(value: false);
			}
			else if (packagerFunction == PackagerFunction.EvolutionEQ)
			{
				FilterBtn.SetActive(value: false);
				base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllForge");
			}
			else if (packagerFunction == PackagerFunction.Wugong)
			{
				packageTopFilter = "0000000010";
				FilterBtn.SetActive(value: true);
				InitFilterPanel(PackageFilterPanelType.Wugong);
				base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_AllWugong");
			}
		}
		else if (packagerFunction == PackagerFunction.PlayerPackage)
		{
			NormalPackageRetBtn.gameObject.SetActive(value: false);
			FilterBtn.SetActive(value: true);
			InitFilterPanel(PackageFilterPanelType.All);
		}
	}

	private void InitFilterPanel(PackageFilterPanelType _PackageFilterPanelType)
	{
		packageFilterPanelType = _PackageFilterPanelType;
		Transform content = SelectPanel.GetComponent<ScrollRect>().content;
		int childCount = content.childCount;
		content.Find("Filter|Use|1111111111||Fix").GetComponent<Button>().interactable = !_PackageFilterPanelType.Equals(PackageFilterPanelType.Wugong);
		if (_PackageFilterPanelType.Equals(PackageFilterPanelType.All))
		{
			for (int i = 0; i < childCount; i++)
			{
				content.GetChild(i).gameObject.SetActive(value: true);
			}
		}
		else if (_PackageFilterPanelType.Equals(PackageFilterPanelType.Consum))
		{
			for (int j = 0; j < childCount; j++)
			{
				GameObject gameObject = content.GetChild(j).gameObject;
				if (!gameObject.name.Contains("|Fix"))
				{
					gameObject.SetActive(gameObject.name.Contains("Consum"));
				}
			}
		}
		else if (_PackageFilterPanelType.Equals(PackageFilterPanelType.Wugong))
		{
			for (int k = 0; k < childCount; k++)
			{
				GameObject gameObject2 = content.GetChild(k).gameObject;
				if (!gameObject2.name.Contains("|Fix"))
				{
					gameObject2.SetActive(gameObject2.name.Contains("Wugong"));
				}
			}
		}
		else
		{
			if (!_PackageFilterPanelType.Equals(PackageFilterPanelType.Equip))
			{
				return;
			}
			for (int l = 0; l < childCount; l++)
			{
				GameObject gameObject3 = content.GetChild(l).gameObject;
				if (!gameObject3.name.Contains("|Fix"))
				{
					gameObject3.SetActive(gameObject3.name.Contains("Equip"));
				}
			}
		}
	}

	private void InitShopLoanRedeemAppreciationPanel()
	{
		SharedData.Instance().OpenPackageFor = "";
		ShopPanel.SetActive(value: true);
		gang_b09Table.Row row = CommonResourcesData.b09.Find_ID(SharedData.Instance().OpenShopID);
		if (CommonResourcesData.b10.Find_ID("30001").Members.Split('|').Contains(row.ID))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1056");
		}
		ShopPanel.transform.Find("TopBanner/Text").GetComponent<Text>().text = row.Name_Trans;
		gang_b01Table.Row row2 = CommonResourcesData.b01.Find_BattleIcon(row.BattleIcon);
		if (row2 != null)
		{
			ShopPanel.transform.Find("Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(row2.ID);
		}
		ShopPanel.transform.Find("Tachie").gameObject.SetActive(value: false);
		if (row.BattleIcon != "")
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(row.BattleIcon);
			if (tachieFull != null)
			{
				ShopPanel.transform.Find("Tachie").gameObject.SetActive(value: true);
				ShopPanel.transform.Find("Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
			}
		}
	}

	public static List<PackageItemData> GetPackageList(PackagerFunction _packagerFunction, PackageSortType _packageSortType = PackageSortType.Forward)
	{
		List<PackageItemData> list = new List<PackageItemData>();
		List<PackageItemData> packageItemDatas = new List<PackageItemData>();
		List<PackageItemData> packageItemDatas2 = new List<PackageItemData>();
		List<PackageItemData> packageItemDatas3 = new List<PackageItemData>();
		List<PackageItemData> packageItemDatas4 = new List<PackageItemData>();
		if (_packagerFunction != PackagerFunction.Shop && _packagerFunction != PackagerFunction.Redeem)
		{
			if (!SharedData.Instance().OpenPackageFor.Contains("DartWugong"))
			{
				Dictionary<string, List<PackageItemData>> packageNormalList = GetPackageNormalList(_packagerFunction);
				if (_packageSortType.Equals(PackageSortType.Forward))
				{
					packageItemDatas = packageNormalList["couldUse"];
					packageItemDatas2 = packageNormalList["couldNotUse"];
				}
				else
				{
					packageItemDatas3 = packageNormalList["All"];
				}
				packageItemDatas4 = GetEquipItemInfo(_packagerFunction);
			}
			else
			{
				packageItemDatas3 = GetDartWugongItemsInfo();
			}
		}
		else
		{
			switch (_packagerFunction)
			{
			case PackagerFunction.Shop:
				packageItemDatas3 = GetShopItemsInfo();
				break;
			case PackagerFunction.Redeem:
				packageItemDatas3 = GetRedeemItemsInfo();
				break;
			}
		}
		list.AddRange(ResortPackageItemDatas(packageItemDatas, _packageSortType));
		list.AddRange(ResortPackageItemDatas(packageItemDatas2, _packageSortType));
		list.AddRange(ResortPackageItemDatas(packageItemDatas3, _packageSortType));
		list.AddRange(ResortPackageItemDatas(packageItemDatas4, _packageSortType));
		int num = 0;
		PackageItemData packageItemData = list.Find((PackageItemData x) => x.b07Row.ID.Equals("999"));
		if (packageItemData != null)
		{
			list.Remove(packageItemData);
			list.Insert(num++, packageItemData);
		}
		PackageItemData packageItemData2 = list.Find((PackageItemData x) => x.b07Row.ID.Equals("998"));
		if (packageItemData2 != null)
		{
			list.Remove(packageItemData2);
			list.Insert(num++, packageItemData2);
		}
		PackageItemData packageItemData3 = list.Find((PackageItemData x) => x.b07Row.ID.Equals("997"));
		if (packageItemData3 != null)
		{
			list.Remove(packageItemData3);
			list.Insert(num++, packageItemData3);
		}
		if (!_packagerFunction.Equals(PackagerFunction.Shop) && !_packagerFunction.Equals(PackagerFunction.Redeem))
		{
			foreach (PackageItemData item in list)
			{
				item.isNew = SharedData.Instance().m_NewItemList.Contains(item.ID);
			}
		}
		return list;
	}

	private static List<PackageItemData> ResortPackageItemDatas(List<PackageItemData> packageItemDatas, PackageSortType _packageSortType = PackageSortType.Forward)
	{
		switch (_packageSortType)
		{
		case PackageSortType.Resort:
		{
			List<PackageItemData> list = new List<PackageItemData>();
			List<PackageItemData> list2 = new List<PackageItemData>();
			List<PackageItemData> list3 = new List<PackageItemData>();
			List<PackageItemData> list4 = new List<PackageItemData>();
			List<PackageItemData> list5 = new List<PackageItemData>();
			List<PackageItemData> list6 = new List<PackageItemData>();
			List<PackageItemData> list7 = new List<PackageItemData>();
			List<PackageItemData> list8 = new List<PackageItemData>();
			List<PackageItemData> list9 = new List<PackageItemData>();
			List<PackageItemData> list10 = new List<PackageItemData>();
			List<PackageItemData> list11 = new List<PackageItemData>();
			List<PackageItemData> list12 = new List<PackageItemData>();
			List<PackageItemData> list13 = new List<PackageItemData>();
			List<PackageItemData> list14 = new List<PackageItemData>();
			List<PackageItemData> list15 = new List<PackageItemData>();
			List<PackageItemData> list16 = new List<PackageItemData>();
			List<PackageItemData> list17 = new List<PackageItemData>();
			List<PackageItemData> list18 = new List<PackageItemData>();
			List<PackageItemData> list19 = new List<PackageItemData>();
			List<PackageItemData> list20 = new List<PackageItemData>();
			List<PackageItemData> list21 = new List<PackageItemData>();
			List<PackageItemData> list22 = new List<PackageItemData>();
			List<PackageItemData> list23 = new List<PackageItemData>();
			List<PackageItemData> list24 = new List<PackageItemData>();
			List<PackageItemData> list25 = new List<PackageItemData>();
			List<PackageItemData> list26 = new List<PackageItemData>();
			List<PackageItemData> list27 = new List<PackageItemData>();
			List<PackageItemData> list28 = new List<PackageItemData>();
			List<PackageItemData> list29 = new List<PackageItemData>();
			List<PackageItemData> list30 = new List<PackageItemData>();
			List<PackageItemData> list31 = new List<PackageItemData>();
			foreach (PackageItemData packageItemData in packageItemDatas)
			{
				if (!packageItemData.b07Row.Use[8].Equals('1') && !packageItemData.b07Row.Use[2].Equals('1') && !packageItemData.b07Row.Use[3].Equals('1') && !packageItemData.b07Row.Use[4].Equals('1'))
				{
					bool flag = false;
					switch (packageItemData.b07Row.Style)
					{
					case "301":
						list.Add(packageItemData);
						flag = true;
						break;
					case "401":
						list2.Add(packageItemData);
						flag = true;
						break;
					case "501":
						list3.Add(packageItemData);
						flag = true;
						break;
					case "701":
					case "702":
					case "703":
						list4.Add(packageItemData);
						flag = true;
						break;
					case "802":
						list5.Add(packageItemData);
						flag = true;
						break;
					case "901":
						list6.Add(packageItemData);
						flag = true;
						break;
					case "1301":
						list7.Add(packageItemData);
						flag = true;
						break;
					case "1201":
						list8.Add(packageItemData);
						flag = true;
						break;
					}
					if (!flag && !list31.Contains(packageItemData))
					{
						list31.Add(packageItemData);
					}
				}
				else if (packageItemData.b07Row.Use[8].Equals('1'))
				{
					bool flag2 = false;
					switch (packageItemData.b07Row.Style)
					{
					case "101":
						list9.Add(packageItemData);
						flag2 = true;
						break;
					case "201":
						list10.Add(packageItemData);
						flag2 = true;
						break;
					case "301":
						list11.Add(packageItemData);
						flag2 = true;
						break;
					case "401":
						list12.Add(packageItemData);
						flag2 = true;
						break;
					case "501":
						list13.Add(packageItemData);
						flag2 = true;
						break;
					case "601":
						list14.Add(packageItemData);
						flag2 = true;
						break;
					case "701":
						list15.Add(packageItemData);
						flag2 = true;
						break;
					case "801":
						list16.Add(packageItemData);
						flag2 = true;
						break;
					case "901":
						list17.Add(packageItemData);
						flag2 = true;
						break;
					case "1001":
						list18.Add(packageItemData);
						flag2 = true;
						break;
					case "9101":
						list19.Add(packageItemData);
						flag2 = true;
						break;
					case "9301":
						list20.Add(packageItemData);
						flag2 = true;
						break;
					case "9401":
						list21.Add(packageItemData);
						flag2 = true;
						break;
					case "9501":
						list22.Add(packageItemData);
						flag2 = true;
						break;
					case "9601":
						list23.Add(packageItemData);
						flag2 = true;
						break;
					}
					if (!flag2 && !list31.Contains(packageItemData))
					{
						list31.Add(packageItemData);
					}
				}
				else
				{
					if (!packageItemData.b07Row.Use[2].Equals('1') && !packageItemData.b07Row.Use[3].Equals('1') && !packageItemData.b07Row.Use[4].Equals('1'))
					{
						continue;
					}
					bool flag3 = false;
					gang_b02Table.Row row = CommonResourcesData.b02.Find_ID(packageItemData.b07Row.Relateid);
					if (row == null)
					{
						Debug.LogWarning("Can not Find B02Row, b07id = " + packageItemData.b07Row.ID);
						continue;
					}
					if (packageItemData.b07Row.Style.Equals("201"))
					{
						switch (row.atlasType)
						{
						case "1":
							list24.Add(packageItemData);
							flag3 = true;
							break;
						case "2":
							list25.Add(packageItemData);
							flag3 = true;
							break;
						case "3":
							list26.Add(packageItemData);
							flag3 = true;
							break;
						case "4":
							list27.Add(packageItemData);
							flag3 = true;
							break;
						case "5":
							list28.Add(packageItemData);
							flag3 = true;
							break;
						default:
							list28.Add(packageItemData);
							flag3 = true;
							break;
						}
					}
					if (!flag3)
					{
						switch (packageItemData.b07Row.Style)
						{
						case "201":
							list28.Add(packageItemData);
							flag3 = true;
							break;
						case "202":
							list29.Add(packageItemData);
							flag3 = true;
							break;
						case "203":
							list30.Add(packageItemData);
							flag3 = true;
							break;
						}
					}
					if (!flag3 && !list31.Contains(packageItemData))
					{
						list31.Add(packageItemData);
					}
				}
			}
			List<PackageItemData> list32 = new List<PackageItemData>();
			list32.AddRange(list);
			list32.AddRange(list2);
			list32.AddRange(list3);
			list32.AddRange(list4);
			list32.AddRange(list5);
			list32.AddRange(list6);
			list32.AddRange(list7);
			list32.AddRange(list8);
			list32.AddRange(list9);
			list32.AddRange(list10);
			list32.AddRange(list11);
			list32.AddRange(list12);
			list32.AddRange(list13);
			list32.AddRange(list14);
			list32.AddRange(list15);
			list32.AddRange(list16);
			list32.AddRange(list17);
			list32.AddRange(list18);
			list32.AddRange(list19);
			list32.AddRange(list20);
			list32.AddRange(list21);
			list32.AddRange(list22);
			list32.AddRange(list23);
			list32.AddRange(list24);
			list32.AddRange(list25);
			list32.AddRange(list26);
			list32.AddRange(list27);
			list32.AddRange(list28);
			list32.AddRange(list29);
			list32.AddRange(list30);
			list32.AddRange(list31);
			return list32;
		}
		case PackageSortType.Forward:
			return packageItemDatas;
		case PackageSortType.Reverse:
			packageItemDatas.Reverse();
			return packageItemDatas;
		default:
			return packageItemDatas;
		}
	}

	public static List<PackageItemData> GetEquipItemInfo(PackagerFunction _packagerFunction)
	{
		List<PackageItemData> list = new List<PackageItemData>();
		List<string> list2 = new List<string>();
		list2.Add(SharedData.Instance().playerid);
		list2.AddRange(SharedData.Instance().FullTeam);
		foreach (string item in list2)
		{
			CharaData charaData = SharedData.Instance().GetCharaData(item);
			if (charaData.m_Training_Id != "0")
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_Relate_Wugong_id(charaData.m_Training_Id);
				if (_packagerFunction != PackagerFunction.Loan || !row.Value.Equals("0"))
				{
					PackageItemData packageItemData = new PackageItemData();
					packageItemData.ID = row.ID;
					packageItemData.b07Row = row;
					packageItemData.userData = charaData;
					packageItemData.number = 1;
					packageItemData.originPrice = int.Parse(row.Value);
					packageItemData.effectPrice = int.Parse(row.Value);
					list.Add(packageItemData);
				}
			}
			foreach (string item2 in charaData.m_EquipSlot)
			{
				if (item2 != "0")
				{
					gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(item2);
					if (_packagerFunction != PackagerFunction.Loan || !row2.Value.Equals("0"))
					{
						PackageItemData packageItemData2 = new PackageItemData();
						packageItemData2.ID = row2.ID;
						packageItemData2.b07Row = row2;
						packageItemData2.userData = charaData;
						packageItemData2.number = 1;
						packageItemData2.originPrice = int.Parse(row2.Value);
						packageItemData2.effectPrice = int.Parse(row2.Value);
						list.Add(packageItemData2);
					}
				}
			}
		}
		return list;
	}

	public static Dictionary<string, List<PackageItemData>> GetPackageNormalList(PackagerFunction _packagerFunction)
	{
		Dictionary<string, List<PackageItemData>> dictionary = new Dictionary<string, List<PackageItemData>>();
		dictionary.Add("couldUse", new List<PackageItemData>());
		dictionary.Add("couldNotUse", new List<PackageItemData>());
		dictionary.Add("All", new List<PackageItemData>());
		foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(item.Key);
			if (row != null)
			{
				if (_packagerFunction == PackagerFunction.Loan && (row.Value.Equals("0") || "999".Equals(item.Key)))
				{
					continue;
				}
				int number = item.Value;
				if ("999".Equals(item.Key))
				{
					number = SharedData.Instance().m_Money;
				}
				PackageItemData packageItemData = new PackageItemData();
				packageItemData.ID = item.Key;
				packageItemData.b07Row = row;
				packageItemData.userData = null;
				packageItemData.number = number;
				packageItemData.originPrice = int.Parse(row.Value);
				packageItemData.effectPrice = int.Parse(row.Value);
				bool flag = true;
				if (row.Use[8] == '1')
				{
					gang_b03Table.Row row2 = CommonResourcesData.b03.Find_ID(row.Relateid);
					if (row2 != null)
					{
						flag = PackageIconController.CheckKFBook(row2);
					}
				}
				else if (row.Use[2] == '1' || row.Use[3] == '1' || row.Use[4] == '1')
				{
					gang_b02Table.Row row3 = CommonResourcesData.b02.Find_ID(row.Relateid);
					if (row3 != null)
					{
						flag = PackageIconController.CheckEquipment(row3);
					}
				}
				if (flag)
				{
					dictionary["couldUse"].Add(packageItemData);
				}
				else
				{
					dictionary["couldNotUse"].Add(packageItemData);
				}
				dictionary["All"].Add(packageItemData);
			}
			else
			{
				Debug.LogWarning("[3] !!! Can NOT found item.Key = " + item.Key);
			}
		}
		return dictionary;
	}

	public static List<PackageItemData> GetShopItemsInfo()
	{
		List<PackageItemData> list = new List<PackageItemData>();
		foreach (gang_b08Table.Row item in CommonResourcesData.b08.FindAll_ShopID(SharedData.Instance().OpenShopID))
		{
			if (SharedData.Instance().m_ShopGoods[item.ID] < int.Parse(item.Pack))
			{
				gang_b08Table.Row row = CommonResourcesData.b08.Find_ID(item.ID);
				gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(row.GoodID);
				if (row.GoodID.Contains("Traitscroll"))
				{
					row2 = CommonResourcesData.b07.Find_ID(row.GoodID.Split('&')[0]);
				}
				if (row2 == null)
				{
					Debug.LogWarning("GetShopItemsInfo can not find b08row.GoodID = " + row.GoodID);
					continue;
				}
				PackageItemData packageItemData = new PackageItemData();
				packageItemData.ID = row.GoodID;
				packageItemData.b07Row = row2;
				packageItemData.userData = null;
				packageItemData.number = int.Parse(row.Pack) - SharedData.Instance().m_ShopGoods[row.ID];
				packageItemData.originPrice = int.Parse(row.Price);
				packageItemData.effectPrice = int.Parse(row.Price);
				packageItemData.priceType = row.PriceType;
				list.Add(packageItemData);
			}
		}
		return list;
	}

	public static List<PackageItemData> GetRedeemItemsInfo()
	{
		List<PackageItemData> list = new List<PackageItemData>();
		foreach (KeyValuePair<string, int> loanedItem in SharedData.Instance().m_LoanedItems)
		{
			if (loanedItem.Value > 0)
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(loanedItem.Key);
				if (row != null)
				{
					PackageItemData packageItemData = new PackageItemData();
					packageItemData.ID = loanedItem.Key;
					packageItemData.b07Row = row;
					packageItemData.userData = null;
					packageItemData.number = loanedItem.Value;
					packageItemData.originPrice = int.Parse(row.Value);
					packageItemData.effectPrice = int.Parse(row.Value);
					list.Add(packageItemData);
				}
			}
		}
		return list;
	}

	public static List<PackageItemData> GetDartWugongItemsInfo()
	{
		List<PackageItemData> list = new List<PackageItemData>();
		foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(item.Key);
			if (row != null)
			{
				int number = item.Value;
				if ("999".Equals(item.Key))
				{
					number = SharedData.Instance().m_Money;
				}
				bool flag = false;
				if ("999".Equals(item.Key))
				{
					flag = true;
				}
				else if ("DartsATK".Equals(row.Skills1.Split('&')[0]))
				{
					string[] array = row.Relateid.Split('|');
					string text = SharedData.Instance().OpenPackageFor.Split('|')[1];
					string text2 = text;
					if (text.StartsWith("MB03"))
					{
						text2 = text.Split('_')[1];
					}
					string[] array2 = array;
					for (int i = 0; i < array2.Length; i++)
					{
						if (array2[i] == text2)
						{
							if (item.Value > 0)
							{
								flag = true;
							}
							break;
						}
					}
				}
				if (flag)
				{
					PackageItemData packageItemData = new PackageItemData();
					packageItemData.ID = row.ID;
					packageItemData.b07Row = row;
					packageItemData.userData = null;
					packageItemData.number = number;
					packageItemData.originPrice = int.Parse(row.Value);
					packageItemData.effectPrice = int.Parse(row.Value);
					list.Add(packageItemData);
				}
			}
			else
			{
				Debug.LogWarning("[3] !!! Can NOT found item.Key = " + item.Key);
			}
		}
		return list;
	}

	private void UpdatePackageItemDetail(GameObject btn)
	{
		bool activeInHierarchy = DetailPanel.gameObject.activeInHierarchy;
		List<PackageIconController> list = PackagePanel.content.GetComponentsInChildren<PackageIconController>().ToList();
		SelectedBtn = btn;
		PackageIconController component = SelectedBtn.GetComponent<PackageIconController>();
		component.HideNewInfo();
		if (packagerFunction.Equals(PackagerFunction.Inheritance))
		{
			list.ForEach(delegate(PackageIconController t)
			{
				if (!InheritanceDict.ContainsKey(t.itemData.ID))
				{
					if (!t.itemData.isNew)
					{
						t.GetComponent<Image>().sprite = NormalSprite;
					}
				}
				else
				{
					t.GetComponent<Image>().sprite = InheritanceSprite;
				}
			});
		}
		else if (packagerFunction.Equals(PackagerFunction.Appreciation))
		{
			Debug.LogWarning("PackagerFunction.Appreciation Refresh");
			if (AppreciationIdValueDict.ContainsKey(component.gameObject.name))
			{
				AppreciationIdValueDict.Remove(component.gameObject.name);
			}
			else if (component.itemData.b07Row != null)
			{
				AppreciationIdValueDict.Add(component.gameObject.name, component.effectPrice);
			}
			list.ForEach(delegate(PackageIconController t)
			{
				if (!AppreciationIdValueDict.ContainsKey(t.gameObject.name))
				{
					if (!t.itemData.isNew)
					{
						t.GetComponent<Image>().sprite = NormalSprite;
					}
				}
				else
				{
					t.GetComponent<Image>().sprite = SelectedSprite;
				}
			});
		}
		else
		{
			list.ForEach(delegate(PackageIconController t)
			{
				if (!InheritanceDict.ContainsKey(t.itemData.ID) && !t.itemData.isNew)
				{
					t.GetComponent<Image>().sprite = NormalSprite;
				}
			});
		}
		if (!InheritanceDict.ContainsKey(component.itemData.ID) && !packagerFunction.Equals(PackagerFunction.Appreciation))
		{
			SelectedBtn.GetComponent<Image>().sprite = SelectedSprite;
		}
		EventSystem.current.SetSelectedGameObject(SelectedBtn.gameObject);
		SelectedPackageItem = component.itemData;
		ShopHoverItem.gameObject.SetActive(value: false);
		ShopHoverWuGong.gameObject.SetActive(value: false);
		CommonFunc.CloseHover();
		DetailPanel.SetActive(value: false);
		gang_b07Table.Row b07Row = component.b07Row;
		if (b07Row == null)
		{
			PackagePanel.viewport.GetComponent<RectTransform>().offsetMin = Vector2.zero;
			return;
		}
		DetailPanel.SetActive(value: true);
		Vector2 offsetMin = PackagePanel.viewport.GetComponent<RectTransform>().offsetMin;
		offsetMin.y = DetailPanel.GetComponent<RectTransform>().rect.height;
		PackagePanel.viewport.GetComponent<RectTransform>().offsetMin = offsetMin;
		Vector3 vector = PackagePanel.content.GetComponent<RectTransform>().anchoredPosition;
		if (!activeInHierarchy && PackagePanel.content.GetComponent<RectTransform>().rect.height > PackagePanel.viewport.GetComponent<RectTransform>().rect.height)
		{
			vector.y += offsetMin.y;
			PackagePanel.content.GetComponent<RectTransform>().anchoredPosition = vector;
		}
		DetailPanel.transform.Find("Icon/HeadIcon").gameObject.SetActive(value: false);
		DetailPanel.transform.Find("Icon/Used").gameObject.SetActive(value: false);
		UseBtn.SetActive(value: false);
		CancelUseBtn.SetActive(value: false);
		DetailBtn.SetActive(value: false);
		EquipBtn.SetActive(value: false);
		UnEquipBtn.SetActive(value: false);
		ShopBtn.SetActive(value: false);
		BulkBtn.SetActive(value: false);
		LoanBtn.SetActive(value: false);
		RedeemBtn.SetActive(value: false);
		AppreciationBtn.SetActive(value: false);
		InheritanceBtn.SetActive(value: false);
		DetailPanel.transform.Find("Icon/Image").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(b07Row.BookIcon);
		DetailPanel.transform.Find("Name").GetComponent<Text>().text = b07Row.Name_Trans;
		if (component.itemData.ID.Contains("Traitscroll"))
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(component.itemData.ID.Split('&')[1]);
			DetailPanel.transform.Find("Info/Add1").GetComponent<Text>().text = string.Format(b07Row.note_Trans.Replace("\\n", "\n"), row.name_Trans, row.note_Trans, row.comment_Trans);
		}
		else
		{
			DetailPanel.transform.Find("Info/Add1").GetComponent<Text>().text = b07Row.note_Trans;
		}
		if (component.userData != null)
		{
			UnEquipBtn.gameObject.SetActive(packagerFunction != PackagerFunction.Inheritance);
			DetailPanel.transform.Find("Icon/HeadIcon").gameObject.SetActive(value: true);
			DetailPanel.transform.Find("Icon/Used").gameObject.SetActive(value: true);
			DetailPanel.transform.Find("Icon/Used/Value").GetComponent<Text>().text = component.userData.Indexs_Name["Name"].stringValue;
			Sprite tachieHead = CommonResourcesData.GetTachieHead(component.userData.m_BattleIcon);
			if (tachieHead == null)
			{
				DetailPanel.transform.Find("Icon/HeadIcon/Image").gameObject.SetActive(value: false);
				DetailPanel.transform.Find("Icon/HeadIcon/IconPixel").gameObject.SetActive(value: true);
				DetailPanel.transform.Find("Icon/HeadIcon/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(component.userData);
			}
			else
			{
				DetailPanel.transform.Find("Icon/HeadIcon/Image").gameObject.SetActive(value: true);
				DetailPanel.transform.Find("Icon/HeadIcon/IconPixel").gameObject.SetActive(value: false);
				DetailPanel.transform.Find("Icon/HeadIcon/Image").GetComponent<Image>().sprite = tachieHead;
			}
			if (b07Row.Use[8] != '1' && b07Row.Use[2] != '1' && b07Row.Use[3] != '1')
			{
				_ = b07Row.Use[4];
				_ = 49;
			}
		}
		if (b07Row.Use[2] == '1' || b07Row.Use[3] == '1' || b07Row.Use[4] == '1' || b07Row.Use[8] == '1')
		{
			DetailBtn.SetActive(value: true);
		}
		if (packagerFunction == PackagerFunction.PlayerPackage)
		{
			if (b07Row.Use[0] == '1' && !btn.transform.Find("FullInfo/Check").gameObject.activeSelf)
			{
				UseBtn.SetActive(value: true);
			}
			if (b07Row.Use[2] == '1' || b07Row.Use[3] == '1' || b07Row.Use[4] == '1')
			{
				if (component.userData != null)
				{
					UnEquipBtn.SetActive(packagerFunction != PackagerFunction.Inheritance);
				}
				else if (!btn.transform.Find("FullInfo/Check").gameObject.activeSelf)
				{
					EquipBtn.SetActive(value: true);
				}
			}
		}
		else if (packagerFunction == PackagerFunction.Equip)
		{
			if (component.userData != null)
			{
				UnEquipBtn.SetActive(packagerFunction != PackagerFunction.Inheritance);
			}
			else if (!btn.transform.Find("FullInfo/Check").gameObject.activeSelf)
			{
				EquipBtn.SetActive(value: true);
			}
		}
		else if (packagerFunction == PackagerFunction.Wugong)
		{
			if (component.userData != null)
			{
				UnEquipBtn.SetActive(packagerFunction != PackagerFunction.Inheritance);
			}
			else if (!btn.transform.Find("FullInfo/Check").gameObject.activeSelf)
			{
				EquipBtn.SetActive(value: true);
			}
		}
		else if (packagerFunction == PackagerFunction.BattleField)
		{
			if (b07Row.Use[0] == '1' || (b07Row.Use[1] == '1' && !btn.transform.Find("FullInfo/Check").gameObject.activeSelf))
			{
				UseBtn.SetActive(value: true);
			}
		}
		else if (packagerFunction == PackagerFunction.EvolutionEQ)
		{
			if (SharedData.Instance().OpenPackageFor.StartsWith("EvolutionEQ|"))
			{
				int num = int.Parse(SharedData.Instance().OpenPackageFor.Split('|')[1]);
				if (SharedData.Instance().m_EvolutionEqNewController.materials[num - 1] == b07Row.ID)
				{
					CancelUseBtn.SetActive(value: true);
				}
				else
				{
					UseBtn.SetActive(!btn.transform.Find("FullInfo/Check").gameObject.activeSelf);
				}
			}
		}
		else if (packagerFunction == PackagerFunction.Shop)
		{
			ShopBtn.SetActive(component.CouldShopBtnActive());
			BulkBtn.SetActive(component.CouldShopBtnActive() && component.number > 1);
			BulkBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Package_Bulk_Buy");
			DetailBtn.SetActive(value: false);
		}
		else if (packagerFunction == PackagerFunction.Redeem)
		{
			RedeemBtn.SetActive(component.CouldShopBtnActive());
			BulkBtn.SetActive(component.CouldShopBtnActive() && component.number > 1);
			BulkBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Package_Bulk_Redeem");
			DetailBtn.SetActive(value: false);
		}
		else if (packagerFunction == PackagerFunction.Loan)
		{
			if (component.userData != null)
			{
				UnEquipBtn.SetActive(packagerFunction != PackagerFunction.Inheritance);
			}
			else
			{
				LoanBtn.SetActive(value: true);
				BulkBtn.SetActive(component.CouldShopBtnActive() && component.number > 1);
				BulkBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Package_Bulk_Loan");
			}
			DetailBtn.SetActive(value: false);
		}
		else if (packagerFunction == PackagerFunction.Appreciation)
		{
			AppreciationBtn.SetActive(value: true);
			int num2 = 0;
			foreach (KeyValuePair<string, int> item in AppreciationIdValueDict)
			{
				num2 += item.Value;
			}
			AppreciationBtn.GetComponent<Button>().interactable = num2 <= currencyValue && AppreciationIdValueDict.Count > 0;
			DetailBtn.SetActive(value: false);
		}
		else if (packagerFunction == PackagerFunction.Inheritance)
		{
			if (InheritanceDict.ContainsKey(SelectedPackageItem.ID))
			{
				CancelUseBtn.SetActive(value: true);
			}
			else if (InheritanceDict.Count < GameDataManager.Instance().configdata.InheritItemCount)
			{
				InheritanceBtn.SetActive(value: true);
			}
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || isButtonClicking || isFreshingPackage)
		{
			return;
		}
		isButtonClicking = true;
		string[] array = go.name.Split('|');
		if (array[0] == "ItemBtn")
		{
			SharedData.Instance().m_SubSelectedItem = go.name;
			UpdatePackageItemDetail(go);
			if (packagerFunction == PackagerFunction.Shop || packagerFunction == PackagerFunction.Redeem || packagerFunction == PackagerFunction.Loan)
			{
				StartCoroutine(CommonFunc.DelayedOpenHoverOperation(SelectedBtn, showEquip: false));
			}
		}
		else if (go.name.StartsWith("FullName"))
		{
			SharedData.Instance().isShowFullName = !SharedData.Instance().isShowFullName;
			if (SharedData.Instance().isShowFullName)
			{
				base.transform.Find("Panel/Title/Btns/FullNameArea/FullName/Checkmark").gameObject.SetActive(value: true);
			}
			else
			{
				base.transform.Find("Panel/Title/Btns/FullNameArea/FullName/Checkmark").gameObject.SetActive(value: false);
			}
			foreach (PackageIconController item in PackagePanel.content.GetComponentsInChildren<PackageIconController>().ToList())
			{
				item.transform.Find("FullName").gameObject.SetActive(SharedData.Instance().isShowFullName);
				item.transform.Find("FullInfo").gameObject.SetActive(!SharedData.Instance().isShowFullName);
			}
		}
		else if (go.name == "FilterPanel")
		{
			SelectPanel.gameObject.SetActive(!SelectPanel.gameObject.activeSelf);
			PackagePanel.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
			if (SelectPanel.gameObject.activeSelf)
			{
				CommonResourcesData.inputDeviceDetector.PushJoyStack();
				if (packageFilterPanelType.Equals(PackageFilterPanelType.All) || packageFilterPanelType.Equals(PackageFilterPanelType.Consum))
				{
					EventSystem.current.SetSelectedGameObject(SelectPanel.transform.Find("Viewport/Content/Filter|Use|1111111111||Fix").gameObject);
				}
				else if (packageFilterPanelType.Equals(PackageFilterPanelType.Wugong))
				{
					EventSystem.current.SetSelectedGameObject(SelectPanel.transform.Find("Viewport/Content/Filter|Use|0000000010||Wugong").gameObject);
				}
				else if (packageFilterPanelType.Equals(PackageFilterPanelType.Equip))
				{
					EventSystem.current.SetSelectedGameObject(SelectPanel.transform.Find("Viewport/Content/Filter|Use|0011100000||Equip").gameObject);
				}
			}
			else
			{
				CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
			}
		}
		else if (array[0] == "Filter")
		{
			if (array[1].Equals("Use"))
			{
				packageTopFilter = array[2];
				packageSubFilter = "";
				if (array.Length >= 4)
				{
					packageSubFilter = array[3];
				}
			}
			else if (array[1].Equals("Style"))
			{
				packageStyleFilters = array[2].Split('&');
			}
			base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = go.transform.Find("Text").GetComponent<Text>().text;
			if (go.name == "Filter|Use|1111111111||Fix")
			{
				FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter");
			}
			else
			{
				FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter") + " : " + go.transform.Find("Text").GetComponent<Text>().text;
			}
			SelectedBtn = null;
			SelectedPackageItem = null;
			if (array[1].Equals("Use"))
			{
				RefreshPackageUIList();
			}
			else
			{
				RefreshPackageUIList(PackageFilterType.Style);
			}
			SelectPanel.gameObject.SetActive(value: false);
			PackagePanel.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
		}
		else if (array[0] == "Sorter")
		{
			switch (array[1])
			{
			case "Forward":
				packageSortType = PackageSortType.Forward;
				break;
			case "Reverse":
				packageSortType = PackageSortType.Reverse;
				break;
			case "Resort":
				packageSortType = PackageSortType.Resort;
				break;
			}
			SelectedBtn = null;
			SelectedPackageItem = null;
			RefreshPackageUIList(packageFilterType);
			SelectPanel.gameObject.SetActive(value: false);
			PackagePanel.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
			SelectPanel.transform.Find("Viewport/Content/Sorter|Forward|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Forward) ? SelectedSprite : NormalSprite);
			SelectPanel.transform.Find("Viewport/Content/Sorter|Reverse|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Reverse) ? SelectedSprite : NormalSprite);
			SelectPanel.transform.Find("Viewport/Content/Sorter|Resort|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Resort) ? SelectedSprite : NormalSprite);
			base.transform.Find("Panel/Title/Btns/Sorter|Forward|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Forward) ? SelectedSprite : NormalSprite);
			base.transform.Find("Panel/Title/Btns/Sorter|Reverse|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Reverse) ? SelectedSprite : NormalSprite);
			base.transform.Find("Panel/Title/Btns/Sorter|Resort|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Resort) ? SelectedSprite : NormalSprite);
		}
		else if (array[0] == "NormalReturn" || array[0] == "TopReturn")
		{
			AppreciationIdValueDict.Clear();
			if (SharedData.Instance().OpenPackageFor.Contains("DartWugong"))
			{
				SharedData.Instance().m_BattlePackageStatus = 99;
			}
			else
			{
				SharedData.Instance().m_BattlePackageStatus = 9;
			}
			ExitScene();
		}
		else
		{
			if (array[0] == "ComfirmInherit")
			{
				if (InheritanceDict.Count > 0)
				{
					GameDataManager.Instance().configdata.inheritItems = "";
					foreach (KeyValuePair<string, int> item2 in InheritanceDict)
					{
						if (GameDataManager.Instance().configdata.inheritItems.Length > 0)
						{
							GameDataManager.Instance().configdata.inheritItems += "&";
						}
						ConfigData configdata = GameDataManager.Instance().configdata;
						configdata.inheritItems = configdata.inheritItems + item2.Key + "|" + item2.Value;
					}
					Debug.Log("GameDataManager.Instance().configdata.inheritItems = [" + GameDataManager.Instance().configdata.inheritItems + "]");
					GameDataManager.Instance().SaveConfig(refreshInheritance: true);
				}
				ExitScene();
				SharedData.Instance().LoadedSceneStack.Clear();
				SceneManager.UnloadSceneAsync("Inheritance");
				return;
			}
			if (array[0] == "OpenDetail")
			{
				if (!CommonFunc.IsHoverOpen())
				{
					StartCoroutine(DelayResetPos());
				}
			}
			else if (array[0] == "Use")
			{
				if (packagerFunction == PackagerFunction.PlayerPackage || packagerFunction == PackagerFunction.BattleField)
				{
					UseSelectedItem(SharedData.Instance().CurrentChara);
				}
				else if (packagerFunction == PackagerFunction.EvolutionEQ)
				{
					int num = int.Parse(SharedData.Instance().OpenPackageFor.Split('|')[1]);
					SharedData.Instance().m_EvolutionEqNewController.materials[num - 1] = SelectedPackageItem.b07Row.ID;
					SharedData.Instance().m_EvolutionEqNewController.RefreshMaterialSection();
					ExitScene();
				}
			}
			else if (array[0] == "CancelUse")
			{
				if (packagerFunction == PackagerFunction.EvolutionEQ)
				{
					int num2 = int.Parse(SharedData.Instance().OpenPackageFor.Split('|')[1]);
					SharedData.Instance().m_EvolutionEqNewController.materials[num2 - 1] = "";
					SharedData.Instance().m_EvolutionEqNewController.RefreshMaterialSection();
					ExitScene();
				}
				else if (packagerFunction == PackagerFunction.Inheritance)
				{
					InheritanceDict.Remove(SelectedPackageItem.ID);
					SelectedBtn.GetComponent<Image>().sprite = SelectedSprite;
					string key = "ItemBtn|" + SelectedPackageItem.ID + "|" + ((SelectedPackageItem.b07Row != null) ? SelectedPackageItem.b07Row.Use : "") + "|" + ((SelectedPackageItem.userData != null) ? SelectedPackageItem.userData.m_Id : "null");
					SelectedBtn.GetComponent<PackageIconController>().InitPackageIcon(SelectedPackageItem, isShowHeadIcoN: false, InheritanceDict.ContainsKey(SelectedPackageItem.ID), AppreciationIdValueDict.ContainsKey(key));
					UpdatePackageItemDetail(SelectedBtn);
					if (GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count > 0)
					{
						base.transform.Find("Panel/Title/InheritanceText").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Inheritance_Title"), "green", GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count);
					}
					else
					{
						base.transform.Find("Panel/Title/InheritanceText").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Inheritance_Title"), "red", GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count);
					}
				}
			}
			else if (array[0] == "Equip")
			{
				OnButtonEquipClick();
			}
			else if (array[0] == "UnEquip")
			{
				OnButtonUnEquipClick();
			}
			else if (array[0] == "Shop")
			{
				OnButtonShopClick();
			}
			else if (array[0] == "BulkShop")
			{
				OnButtonBulkShopClick();
			}
			else if (array[0] == "Loan")
			{
				OnButtonLoanClick();
			}
			else if (array[0] == "Redeem")
			{
				OnButtonRedeemClick();
			}
			else if (array[0] == "Appreciation")
			{
				OnButtonAppreciationClick();
			}
			else if (array[0] == "Inheritance")
			{
				OnButtonInheritanceClick();
			}
		}
		isButtonClicking = false;
	}

	private IEnumerator DelayResetPos()
	{
		yield return null;
		int newSelectedIndex = -1;
		if (SelectedPackageItem != null)
		{
			PackageItemData item = mPackageDataSourceMgr_Filter.Find((PackageItemData x) => x.b07Row == SelectedPackageItem.b07Row && x.ID == SelectedPackageItem.ID);
			newSelectedIndex = mPackageDataSourceMgr_Filter.IndexOf(item);
		}
		if (packageLoopGrid.GetShownItemByItemIndex(newSelectedIndex) == null)
		{
			packageLoopGrid.MovePanelToItemByIndex(newSelectedIndex);
			yield return null;
		}
		LoopGridViewItem shownItemByItemIndex = packageLoopGrid.GetShownItemByItemIndex(newSelectedIndex);
		UpdatePackageItemDetail(shownItemByItemIndex?.gameObject);
		SelectedBtn = shownItemByItemIndex?.gameObject;
		InputDeviceDetector.instance.SetJoyCurseParent(shownItemByItemIndex.transform);
		EventSystem.current.SetSelectedGameObject(shownItemByItemIndex?.gameObject);
		yield return null;
		StartCoroutine(CommonFunc.DelayedOpenHoverOperation(SelectedBtn));
	}

	private void OnButtonEquipClick()
	{
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		string stringValue = currentCharaData.Indexs_Name["Name"].stringValue;
		gang_b07Table.Row b07Row = SelectedPackageItem.b07Row;
		string text = "";
		gang_b07Table.Row row = null;
		if (b07Row.Use[8] == '1')
		{
			if (currentCharaData.GetKongFuByID(b07Row.Relateid) == null)
			{
				StatsAndAchievements.Instance().UnlockAchievement("1029");
				MonoBehaviour.print("[Package]: OnButtonEquipClick(): " + stringValue + " 学习 " + b07Row.Name);
				KongFuData kongFuData = new KongFuData();
				kongFuData.kf = CommonResourcesData.b03.Find_ID(b07Row.Relateid);
				kongFuData.lv = 1;
				kongFuData.exp = 0f;
				currentCharaData.KongFuListAdd(kongFuData);
				SharedData.Instance().m_Transfer_Info = stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetWugong") + " 【" + b07Row.Name_Trans + "】";
			}
			else
			{
				SharedData.Instance().m_Transfer_Info = "";
			}
			if (!currentCharaData.m_Training_Id.Equals("0"))
			{
				row = CommonResourcesData.b07.Find_Relate_Wugong_id(currentCharaData.m_Training_Id);
				text = row.ID;
				_ = "ItemBtn|" + row.ID + "|" + row.Use + "|" + currentCharaData.m_Id;
			}
			currentCharaData.m_Training_Id = b07Row.Relateid;
		}
		else if (b07Row.Use[2] == '1')
		{
			if (!currentCharaData.m_EquipSlot[0].Equals("0"))
			{
				text = currentCharaData.m_EquipSlot[0];
				row = CommonResourcesData.b07.Find_ID(text);
				_ = "ItemBtn|" + row.ID + "|" + row.Use + "|" + currentCharaData.m_Id;
			}
			currentCharaData.m_EquipSlot[0] = b07Row.ID;
		}
		else if (b07Row.Use[3] == '1')
		{
			if (!currentCharaData.m_EquipSlot[1].Equals("0"))
			{
				text = currentCharaData.m_EquipSlot[1];
				row = CommonResourcesData.b07.Find_ID(text);
				_ = "ItemBtn|" + row.ID + "|" + row.Use + "|" + currentCharaData.m_Id;
			}
			currentCharaData.m_EquipSlot[1] = b07Row.ID;
		}
		else if (b07Row.Use[4] == '1')
		{
			if (!currentCharaData.m_EquipSlot[2].Equals("0"))
			{
				text = currentCharaData.m_EquipSlot[2];
				row = CommonResourcesData.b07.Find_ID(text);
				_ = "ItemBtn|" + row.ID + "|" + row.Use + "|" + currentCharaData.m_Id;
			}
			currentCharaData.m_EquipSlot[2] = b07Row.ID;
			SharedData.Instance().SetFieldMoveSpeedRate();
		}
		SharedData.Instance().PackageAdd(SelectedPackageItem.b07Row.ID, -1);
		SharedData.Instance().PackageAdd(text, 1);
		if (packagerFunction == PackagerFunction.Equip || packagerFunction == PackagerFunction.Wugong)
		{
			ExitScene();
		}
		else
		{
			RefreshPackageUIList(packageFilterType);
		}
		SharedData.Instance().m_StatusMain.UpdateCurrentSlot();
		SharedData.Instance().m_StatusMain.UpdateCharaInfo();
	}

	private void OnButtonUnEquipClick()
	{
		_ = SelectedPackageItem.userData;
		gang_b07Table.Row b07Row = SelectedPackageItem.b07Row;
		if (b07Row.Use[8] == '1')
		{
			SelectedPackageItem.userData.m_Training_Id = "0";
		}
		else if (b07Row.Use[2] == '1')
		{
			SelectedPackageItem.userData.m_EquipSlot[0] = "0";
		}
		else if (b07Row.Use[3] == '1')
		{
			SelectedPackageItem.userData.m_EquipSlot[1] = "0";
		}
		else if (b07Row.Use[4] == '1')
		{
			SelectedPackageItem.userData.m_EquipSlot[2] = "0";
		}
		SharedData.Instance().PackageAdd(b07Row.ID, 1);
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		if ((packagerFunction == PackagerFunction.Equip || packagerFunction == PackagerFunction.Wugong) && SelectedPackageItem.userData == currentCharaData)
		{
			ExitScene();
		}
		else
		{
			RefreshPackageUIList(packageFilterType);
		}
		if (SharedData.Instance().m_StatusMain.gameObject.activeInHierarchy)
		{
			SharedData.Instance().m_StatusMain.UpdateCurrentSlot();
			SharedData.Instance().m_StatusMain.UpdateCharaInfo();
		}
	}

	private void OnButtonShopClick()
	{
		ShopBuySomething(BulkType.Shop, SharedData.Instance().OpenShopID, SelectedPackageItem.ID, SelectedPackageItem.effectPrice, 1);
	}

	public void ShopBuySomething(BulkType bulkType, string _shopID, string _itemID, int _price, int _count)
	{
		if (bulkType.Equals(BulkType.Shop))
		{
			gang_b08Table.Row row = CommonResourcesData.b08.FindAll_ShopID(_shopID).Find((gang_b08Table.Row x) => x.GoodID == _itemID);
			if (SharedData.Instance().m_ShopGoods.ContainsKey(row.ID))
			{
				SharedData.Instance().m_ShopGoods[row.ID] += _count;
			}
			else
			{
				SharedData.Instance().m_ShopGoods.Add(row.ID, _count);
			}
			SharedData.Instance().PackageAdd(row.GoodID, _count);
			currencyValue -= _price * _count;
		}
		else if (bulkType.Equals(BulkType.Loan))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1011");
			if (SharedData.Instance().m_LoanedItems.ContainsKey(_itemID))
			{
				SharedData.Instance().m_LoanedItems[_itemID] += _count;
			}
			else
			{
				SharedData.Instance().m_LoanedItems.Add(_itemID, _count);
			}
			SharedData.Instance().PackageAdd(_itemID, -_count);
			currencyValue += _price * _count;
		}
		else if (bulkType.Equals(BulkType.Redeem))
		{
			if (SharedData.Instance().m_LoanedItems.ContainsKey(_itemID))
			{
				SharedData.Instance().m_LoanedItems[_itemID] -= _count;
			}
			else
			{
				SharedData.Instance().m_LoanedItems.Add(_itemID, -_count);
			}
			SharedData.Instance().PackageAdd(_itemID, _count);
			_ = SelectedPackageItem.effectPrice;
			currencyValue -= _price * _count;
		}
		m_AudioSource.clip = m_ShopPay;
		m_AudioSource.Play();
		RefreshPackageUIList(packageFilterType);
	}

	private void OnButtonBulkShopClick()
	{
		if (packagerFunction.Equals(PackagerFunction.Shop))
		{
			BulkWallet.bulkType = BulkType.Shop;
		}
		else if (packagerFunction.Equals(PackagerFunction.Loan))
		{
			BulkWallet.bulkType = BulkType.Loan;
		}
		else if (packagerFunction.Equals(PackagerFunction.Redeem))
		{
			BulkWallet.bulkType = BulkType.Redeem;
		}
		bulkWalletPanel.Show(SelectedPackageItem);
	}

	private void OnButtonLoanClick()
	{
		ShopBuySomething(BulkType.Loan, "", SelectedPackageItem.ID, SelectedPackageItem.effectPrice, 1);
	}

	private void OnButtonRedeemClick()
	{
		ShopBuySomething(BulkType.Redeem, "", SelectedPackageItem.ID, SelectedPackageItem.effectPrice, 1);
	}

	private void OnButtonAppreciationClick()
	{
		int num = 0;
		foreach (KeyValuePair<string, int> item in AppreciationIdValueDict)
		{
			num += item.Value;
		}
		if (currencyValue < num)
		{
			return;
		}
		currencyValue -= num;
		if (currencyValue < 0)
		{
			currencyValue = 0;
		}
		SharedData.Instance().m_TempParas["UnknownMine"] = "";
		foreach (KeyValuePair<string, int> item2 in AppreciationIdValueDict)
		{
			string find = item2.Key.Split('|')[1].Split('&')[1];
			if (item2.Key.Split('|')[1].Equals("Mine13011&13008"))
			{
				find = "T1051";
			}
			string name_Trans = CommonResourcesData.b07.Find_ID(find).Name_Trans;
			Dictionary<string, string> tempParas = SharedData.Instance().m_TempParas;
			tempParas["UnknownMine"] = tempParas["UnknownMine"] + name_Trans + ", ";
		}
		SharedData.Instance().m_TempParas["UnknownMine"] = SharedData.Instance().m_TempParas["UnknownMine"].Substring(0, SharedData.Instance().m_TempParas["UnknownMine"].Length - 2);
		ExitScene();
		SharedData.Instance().m_MapController.AfterAppreciation();
	}

	private void OnButtonInheritanceClick()
	{
		SelectedBtn.GetComponent<Image>().sprite = InheritanceSprite;
		SelectedBtn.transform.Find("Enhence").gameObject.SetActive(value: false);
		int num = 0;
		foreach (PackageItemData item in mPackageDataSourceMgr_Filter)
		{
			if (item.ID.Equals(SelectedPackageItem.ID))
			{
				num += item.number;
			}
		}
		InheritanceDict.Add(SelectedPackageItem.ID, num);
		if (GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count > 0)
		{
			base.transform.Find("Panel/Title/InheritanceText").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Inheritance_Title"), "green", GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count);
		}
		else
		{
			base.transform.Find("Panel/Title/InheritanceText").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Inheritance_Title"), "red", GameDataManager.Instance().configdata.InheritItemCount - InheritanceDict.Count);
		}
		UpdatePackageItemDetail(SelectedBtn);
	}

	private void UseSelectedItem(string _useforcharaid)
	{
		bool flag = false;
		CharaData charaData = SharedData.Instance().GetCharaData(_useforcharaid);
		gang_b07Table.Row b07Row = SelectedPackageItem.b07Row;
		_ = charaData?.Indexs_Name["Name"].stringValue;
		if (SharedData.Instance().m_BattlePackageStatus == 1)
		{
			MonoBehaviour.print("[Package]: UseSelectedItem(): 准备使用 " + b07Row.Name + "[" + b07Row.ID + "] in battle.");
			SharedData.Instance().useItemID = b07Row.ID;
		}
		else
		{
			MonoBehaviour.print("[Package]: UseSelectedItem(): 准备使用 " + b07Row.Name + "[" + b07Row.ID + "] in field.");
			flag = UseSelectedItemOnField();
		}
		if (flag)
		{
			RefreshPackageUIList(packageFilterType);
		}
		if (packagerFunction == PackagerFunction.BattleField)
		{
			ExitScene();
		}
	}

	private bool UseSelectedItemOnField()
	{
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		gang_b07Table.Row b07Row = SelectedPackageItem.b07Row;
		string stringValue = currentCharaData.Indexs_Name["Name"].stringValue;
		SkillInfo skillInfo = new SkillInfo();
		List<string> list = new List<string> { b07Row.Skills1, b07Row.Skills2, b07Row.Skills3, b07Row.Skills4 };
		List<string> skillEcList = new List<string> { "0", "0", "0", "0" };
		for (int i = 0; i < 4; i++)
		{
			if (list[i].Contains("Traitscroll"))
			{
				string text = SelectedPackageItem.ID.Split('&')[1];
				list[i] = "Traitscroll&" + text + "|0&1|0&0|0&0";
			}
		}
		skillInfo.InitSkill(list, skillEcList);
		bannercount = 0;
		bool flag = false;
		for (int j = 0; j < 4; j++)
		{
			bool flag2 = false;
			flag2 = (skillInfo.sName[j].Equals("Traitscroll") ? RunItemSkillOnField(skillInfo.sName[j], skillInfo.sValue[j].ToString(), currentCharaData) : RunItemSkillOnField(skillInfo.sName[j], skillInfo.sValueNum[j].ToString(), currentCharaData));
			if (flag2)
			{
				flag = flag2;
			}
		}
		bool flag3 = false;
		if (flag)
		{
			MonoBehaviour.print("[Package]: UseSelectedItem(): Use " + b07Row.Name + " to " + stringValue);
			SharedData.Instance().m_StatusMain.UpdateCurrentSlot();
			SharedData.Instance().m_StatusMain.UpdateCharaInfo();
			SharedData.Instance().PackageAdd(SelectedPackageItem.ID, -1);
			if (SharedData.Instance().PlayerPackage.ContainsKey(SelectedPackageItem.ID))
			{
				_ = SharedData.Instance().PlayerPackage[SelectedPackageItem.ID];
			}
			flag3 = true;
		}
		else
		{
			EnabelBanner(currentCharaData.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_NoNeedUse"));
			flag3 = false;
		}
		if (InfoPanel.activeSelf)
		{
			SharedData.Instance().m_OpenDetail = "InfoPanel";
		}
		return flag3;
	}

	private bool RunItemSkillOnField(string _id, string _value, CharaData _charadata)
	{
		bool result = false;
		if ("0".Equals(_id))
		{
			return result;
		}
		gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(_id);
		switch (_id)
		{
		case "HP":
		{
			float battleValueByName = _charadata.GetBattleValueByName("HP");
			if (_charadata.m_Hp < battleValueByName)
			{
				float num5 = float.Parse(_value, CultureInfo.InvariantCulture);
				_charadata.m_Hp += num5;
				if (_charadata.m_Hp > battleValueByName)
				{
					num5 -= _charadata.m_Hp - battleValueByName;
					_charadata.m_Hp = battleValueByName;
				}
				result = true;
				EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + ((num5 > 0f) ? CommonFunc.I18nGetLocalizedValue("I18N_Recover") : CommonFunc.I18nGetLocalizedValue("I18N_Reduce")) + " " + num5);
			}
			break;
		}
		case "MP":
		{
			float num7 = _charadata.GetBattleValueByName("Hurt") / 255f;
			if (num7 < 0f)
			{
				num7 = 0f;
			}
			else if (num7 > 1f)
			{
				num7 = 1f;
			}
			float num8 = Mathf.Floor(_charadata.GetFieldValueByName("MP") * (1f - num7));
			if (_charadata.m_Mp < num8)
			{
				float num9 = float.Parse(_value, CultureInfo.InvariantCulture);
				_charadata.m_Mp += num9;
				if (_charadata.m_Mp > num8)
				{
					num9 -= _charadata.m_Mp - num8;
					_charadata.m_Mp = num8;
				}
				if (num9 > 0f)
				{
					result = true;
					EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + ((num9 > 0f) ? CommonFunc.I18nGetLocalizedValue("I18N_Recover") : CommonFunc.I18nGetLocalizedValue("I18N_Reduce")) + " " + num9);
				}
			}
			break;
		}
		case "HPlimit":
			_charadata.Indexs_Name["HP"].alterValue += int.Parse(_value);
			result = true;
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " " + _value);
			break;
		case "MPlimit":
			_charadata.Indexs_Name["MP"].alterValue += int.Parse(_value);
			result = true;
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " " + _value);
			break;
		case "SP":
		case "ATK":
		case "DEF":
		case "STR":
		case "AGI":
		case "BON":
		case "WIL":
		case "LER":
		case "Sword":
		case "Knife":
		case "Stick":
		case "Hand":
		case "Finger":
		case "Special":
		case "YinYang":
		case "Melody":
		case "Medical":
		case "Darts":
		case "Wineart":
		case "Steal":
		case "Crit":
		case "Crit1":
		case "Combo":
		case "Forge":
		{
			float num2 = float.Parse(_value, CultureInfo.InvariantCulture);
			float num3 = _charadata.Indexs_Name[_id].alterValue + num2;
			if (num3 < 0f)
			{
				num3 = 0f;
			}
			_charadata.Indexs_Name[_id].alterValue = num3;
			result = true;
			string text = Mathf.Abs(num2).ToString() ?? "";
			if ("2".Equals(row.Type))
			{
				text = Mathf.Abs(num2) * 100f + "%";
			}
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + ((num2 > 0f) ? (CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " ") : CommonFunc.I18nGetLocalizedValue("I18N_Decrease")) + " " + text);
			break;
		}
		case "Drunk":
		case "Hurt":
		case "Poison":
		case "Bleed":
		case "Burn":
		case "Seal":
		case "Mad":
		{
			if (_charadata.GetFieldValueByName(_id + "resist") > 0f)
			{
				EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist") + " " + row.NameUI_Trans);
				break;
			}
			float num10 = float.Parse(_value, CultureInfo.InvariantCulture);
			float num11 = _charadata.Indexs_Name[_id].fightValue + num10;
			if (num11 < 0f)
			{
				num11 = 0f;
			}
			_charadata.Indexs_Name[_id].fightValue = num11;
			result = true;
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + ((num10 > 0f) ? (CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " ") : CommonFunc.I18nGetLocalizedValue("I18N_Decrease")) + " " + Mathf.Abs(num10));
			break;
		}
		case "AvoidRandomBattleSetps":
		{
			float num = float.Parse(SharedData.Instance().m_A01NameRowDirec[_id].Limit, CultureInfo.InvariantCulture);
			float num2 = float.Parse(_value, CultureInfo.InvariantCulture);
			float num3 = SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue + num2;
			if (num3 < num)
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num3;
			}
			else
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num;
			}
			SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue = 0f;
			result = true;
			EnabelBanner(string.Format(row.NameUI_Trans, num2));
			break;
		}
		case "MeetRandomBattleSetps":
		{
			float num = float.Parse(SharedData.Instance().m_A01NameRowDirec[_id].Limit, CultureInfo.InvariantCulture);
			float num3 = float.Parse(_value, CultureInfo.InvariantCulture);
			if (num3 < num)
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num3;
			}
			else
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num;
			}
			SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue = 0f;
			SharedData.Instance().m_WalkSteps = 0;
			result = true;
			EnabelBanner(string.Format(row.NameUI_Trans, num3));
			break;
		}
		case "AvoidRandomBattleTime":
		{
			float num = float.Parse(SharedData.Instance().m_A01NameRowDirec[_id].Limit, CultureInfo.InvariantCulture);
			float num3 = float.Parse(_value, CultureInfo.InvariantCulture) + SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue;
			if (num3 < num)
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num3;
			}
			else
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num;
			}
			SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue = 0f;
			SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue = 0f;
			SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue = 0f;
			result = true;
			EnabelBanner(string.Format(row.NameUI_Trans, (int)SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue));
			break;
		}
		case "MeetRandomBattleTime":
		{
			float num = float.Parse(SharedData.Instance().m_A01NameRowDirec[_id].Limit, CultureInfo.InvariantCulture);
			float num3 = float.Parse(_value, CultureInfo.InvariantCulture) + SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue;
			if (num3 < num)
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num3;
			}
			else
			{
				SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue = num;
			}
			SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue = 0f;
			SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue = 0f;
			SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue = 0f;
			result = true;
			EnabelBanner(string.Format(row.NameUI_Trans, (int)SharedData.Instance().player.charadata.Indexs_Name[_id].alterValue));
			break;
		}
		case "Percept":
		{
			float num2 = float.Parse(_value, CultureInfo.InvariantCulture);
			float num3 = _charadata.Indexs_Name[_id].alterValue + num2;
			_charadata.Indexs_Name[_id].alterValue = num3;
			result = true;
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + ((num2 > 0f) ? (CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " ") : CommonFunc.I18nGetLocalizedValue("I18N_Decrease")) + " " + num2);
			break;
		}
		case "TALENT":
			_charadata.m_Talent += int.Parse(_value);
			result = true;
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + (((float)int.Parse(_value) > 0f) ? (CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " ") : CommonFunc.I18nGetLocalizedValue("I18N_Decrease")) + " " + int.Parse(_value));
			break;
		case "LV":
		{
			int num4 = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
			if (_charadata.m_Level < num4)
			{
				result = true;
				SharedData.Instance().levelupObjList.Clear();
				SharedData.Instance().levelupObjList.Add(_charadata);
				SharedData.Instance().m_MapController.LoadSceneAdditive("LevelUp");
			}
			break;
		}
		case "LvWugong":
		{
			if ("".Equals(_charadata.m_Training_Id))
			{
				break;
			}
			KongFuData kongFuByID = _charadata.GetKongFuByID(_charadata.m_Training_Id);
			float fieldValueByName = _charadata.GetFieldValueByName("LER");
			if (kongFuByID != null)
			{
				kongFuByID.newlv = kongFuByID.lv;
				float num6 = (float)Mathf.RoundToInt(float.Parse(kongFuByID.kf.EXP, CultureInfo.InvariantCulture) + (float)(kongFuByID.newlv - 1) * float.Parse(kongFuByID.kf.EXPadd, CultureInfo.InvariantCulture) * Mathf.Abs(3f - fieldValueByName / 10f)) - kongFuByID.exp;
				if (num6 < 0f)
				{
					num6 = 0f;
				}
				if (kongFuByID.lv < int.Parse(kongFuByID.kf.LV) && kongFuByID.CheckLevelUp(num6, _charadata.GetFieldValueByName("WIL"), fieldValueByName, _charadata))
				{
					_charadata.m_LevelUpSkillId = _charadata.m_Training_Id;
					skillLevekUpCharaID = _charadata.m_Id;
					SharedData.Instance().m_MapController.LoadSceneAdditive("LevelUpSkill");
					result = true;
				}
			}
			break;
		}
		case "MOR":
		{
			float num2 = float.Parse(_value, CultureInfo.InvariantCulture);
			float num3 = _charadata.Indexs_Name[_id].alterValue + num2;
			_charadata.Indexs_Name[_id].alterValue = num3;
			result = true;
			string text = Mathf.Abs(num2).ToString() ?? "";
			EnabelBanner(_charadata.Indexs_Name["Name"].stringValue + " " + row.NameUI_Trans + " " + ((num2 > 0f) ? (CommonFunc.I18nGetLocalizedValue("I18N_LimitAdd") + " ") : CommonFunc.I18nGetLocalizedValue("I18N_Decrease")) + " " + text);
			break;
		}
		case "Traitscroll":
			if (!_charadata.m_TraitList.Contains(_value))
			{
				_charadata.AddTraits(_value);
				gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(_value);
				if ("1".Equals(row2.isLockTrait))
				{
					_charadata.m_EquipTraitDict[row2.traitEquipIndex] = row2.id;
				}
				GameDataManager.Instance().AddUnlockAtlasList(_value, "b06");
				result = true;
				EnabelBanner(string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Package_Use_TraitScroll"), _charadata.Indexs_Name["Name"].stringValue, row2.name_Trans));
			}
			break;
		}
		return result;
	}

	public void EnabelBanner(string info)
	{
		bannercount++;
		InfoPanel.transform.Find("Banner" + bannercount + "/Text").GetComponent<Text>().text = info;
		InfoPanel.SetActive(value: true);
		InfoPanel.transform.Find("Banner" + bannercount).gameObject.SetActive(value: true);
	}

	private void ExitScene()
	{
		if (SharedData.Instance().m_BattlePackageStatus == 1)
		{
			if (SharedData.Instance().OpenPackageFor.StartsWith("DartWugong"))
			{
				SharedData.Instance().m_BattlePackageStatus = 4;
			}
			else
			{
				SharedData.Instance().m_BattlePackageStatus = 2;
			}
		}
		SharedData.Instance().m_OpenDetail = "";
		if (SharedData.Instance().CurrentStatusSubName != null && SharedData.Instance().CurrentStatusSubName != SharedData.Instance().m_PackageController)
		{
			SharedData.Instance().CurrentStatusSubName.gameObject.SetActive(value: false);
			SharedData.Instance().CurrentStatusSubName.gameObject.SetActive(value: true);
		}
		if (SharedData.Instance().m_StatusMain.gameObject.activeInHierarchy)
		{
			SharedData.Instance().m_StatusMain.UpdateCharaInfo();
		}
		if (SharedData.Instance().m_StatusSub5.gameObject.activeInHierarchy)
		{
			CommonResourcesData.inputDeviceDetector.PushJoyStack(SharedData.Instance().m_StatusSub5.learnBtn.transform);
		}
		CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
		ClosePackage();
	}

	public int GetCurrencyValue(PriceType priceType = PriceType.money)
	{
		if (priceType.Equals(PriceType.oldcoin))
		{
			int result = 0;
			if (SharedData.Instance().PlayerPackage.ContainsKey("998"))
			{
				result = SharedData.Instance().PlayerPackage["998"];
			}
			return result;
		}
		if (priceType.Equals(PriceType.bone))
		{
			int result2 = 0;
			if (SharedData.Instance().PlayerPackage.ContainsKey("997"))
			{
				result2 = SharedData.Instance().PlayerPackage["997"];
			}
			return result2;
		}
		return SharedData.Instance().m_Money;
	}

	private void RefreshShopCash()
	{
		if (!isShop)
		{
			return;
		}
		bool flag = false;
		bool flag2 = false;
		bool flag3 = false;
		foreach (PackageItemData item in mPackageDataSourceMgr_Filter)
		{
			if (!flag && item.b07Row != null && item.priceType.Equals(PriceType.money))
			{
				flag = true;
			}
			if (!flag2 && item.b07Row != null && item.priceType.Equals(PriceType.oldcoin))
			{
				flag2 = true;
			}
			if (!flag3 && item.b07Row != null && item.priceType.Equals(PriceType.bone))
			{
				flag3 = true;
			}
		}
		ShopPanel.transform.Find("TopBanner/TopBannerCash").gameObject.SetActive(flag);
		ShopPanel.transform.Find("TopBanner/TopBannerOldCoin").gameObject.SetActive(flag2);
		ShopPanel.transform.Find("TopBanner/TopBannerBone").gameObject.SetActive(flag3);
		ShopPanel.transform.Find("TopBanner/TopBannerCash/Cash").GetComponent<Text>().text = SharedData.Instance().m_Money.ToString() ?? "";
		int num = 0;
		if (SharedData.Instance().PlayerPackage.ContainsKey("998"))
		{
			num = SharedData.Instance().PlayerPackage["998"];
		}
		ShopPanel.transform.Find("TopBanner/TopBannerOldCoin/Cash").GetComponent<Text>().text = num.ToString() ?? "";
		int num2 = 0;
		if (SharedData.Instance().PlayerPackage.ContainsKey("997"))
		{
			num2 = SharedData.Instance().PlayerPackage["997"];
		}
		ShopPanel.transform.Find("TopBanner/TopBannerBone/Cash").GetComponent<Text>().text = num2.ToString() ?? "";
	}
}
