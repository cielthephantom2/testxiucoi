public class SkillEffectData
{
	public string Beat = "";

	public string Sound = "";

	public string Site = "";
}
