using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu2Controller : MonoBehaviour
{
	private MapController.Event currentevent;

	[SerializeField]
	private GameObject m_Bottom;

	private GameObject CampFireObj;

	private GameObject CampPotObj;

	private GameObject CharaObj;

	private GameObject SpecBtnObj;

	private void Awake()
	{
		Button[] componentsInChildren = base.gameObject.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		CampFireObj = base.transform.Find("CampFire").gameObject;
		CampPotObj = base.transform.Find("CampPot").gameObject;
		CharaObj = base.transform.Find("Chara").gameObject;
		SpecBtnObj = CharaObj.transform.Find("Special").gameObject;
	}

	private void Start()
	{
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MapController mapController = SharedData.Instance().m_MapController;
		string[] array = go.name.Split('|');
		string[] array2 = currentevent.evdata.menu.Split('|');
		if (array[0] == "Talk")
		{
			if (currentevent != null)
			{
				mapController.MenuActiveEvent(currentevent);
			}
		}
		else if (!(array[0] == "Item"))
		{
			if (array[0] == "Status")
			{
				SharedData.Instance().CurrentChara = array2[1];
				SharedData.Instance().LoadSceneStackAdd("Status1");
				SharedData.Instance().StatusEditable = false;
				SceneManager.LoadScene("Status1", LoadSceneMode.Additive);
			}
			else if (array[0] == "Fight")
			{
				if (array2.Length > 1)
				{
					mapController.SaveMapSnapShot();
					SharedData.Instance().BattleEnemyGroupId = "solo-" + array2[1];
					SharedData.Instance().b04BattleID = array2[1];
					SharedData.Instance().PlayerSetting.Clear();
					SharedData.Instance().EnemySetting.Clear();
					SharedData.Instance().PlayerSetting.Add("Player1", SharedData.Instance().playerid);
					SharedData.Instance().AfterBattleWin = "";
					SharedData.Instance().AfterBattleLose = "";
					SharedData.Instance().BackFromOtherScene = false;
					SharedData.Instance().BattleGround = array2[2];
					SharedData.Instance().ASyncLoadScene(array2[2]);
				}
			}
			else if (array[0] == "Special")
			{
				string[] array3 = array[1].Split('@');
				if (array3[0] == "SHOP")
				{
					SharedData.Instance().OpenShopID = array3[1];
					SharedData.Instance().CurrentChara = array2[1];
					SharedData.Instance().LoadSceneStackAdd("Shop");
					SceneManager.LoadScene("Shop", LoadSceneMode.Additive);
				}
				else
				{
					Debug.Log("Can NOT deal [" + array[1] + "]");
				}
			}
		}
		Close();
	}

	public void Open(MapController.Event _event)
	{
		string text = "???";
		SpecBtnObj.SetActive(value: false);
		CampFireObj.SetActive(value: false);
		CampPotObj.SetActive(value: false);
		CharaObj.SetActive(value: false);
		string[] array = _event.evdata.menu.Split('|');
		if (array.Length > 1)
		{
			if (array[1] == "CampFire")
			{
				CampFireObj.SetActive(value: true);
				text = "好暖和的<color=orange>篝火</color>，烤点什么好呢？";
			}
			else if (array[1] == "CampPot")
			{
				CampPotObj.SetActive(value: true);
				text = "好奇妙的<color=orange>火锅</color>，涮点什么好呢？";
			}
			else
			{
				CharaObj.SetActive(value: true);
				gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(array[1]);
				text = "你想对 <color=orange>" + row.Name_Trans + "</color> 做点什么？";
				if (array.Length > 3)
				{
					SpecBtnObj.name = "Special|" + array[3];
					if (array[3].Split('@')[0] == "SHOP")
					{
						SpecBtnObj.SetActive(value: true);
						SpecBtnObj.transform.Find("Text").GetComponent<Text>().text = "商店";
					}
					else
					{
						Debug.Log("Can NOT deal [" + array[3] + "]");
					}
				}
			}
		}
		else
		{
			text = "你想做点什么？";
		}
		m_Bottom.SetActive(value: true);
		m_Bottom.GetComponentInChildren<Text>().text = text;
		base.gameObject.SetActive(value: true);
		currentevent = _event;
	}

	public void Close()
	{
		SpecBtnObj.name = "Special";
		m_Bottom.SetActive(value: false);
		base.gameObject.SetActive(value: false);
		currentevent = null;
	}

	public bool IsOpen()
	{
		return base.gameObject.activeInHierarchy;
	}
}
