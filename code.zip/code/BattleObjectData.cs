using System.Collections.Generic;
using UnityEngine;

public class BattleObjectData
{
	public int gameObjID;

	public Vector3 pos = Vector3.zero;

	public List<int> m_StealableItemsNum;

	public string race = "";

	public bool isDead;

	public bool isEscape;

	public bool isUnSealNextRound;

	public CharaDataBasic charaDataBasic;

	public BattleObjectState m_State;

	public int aliveRoundNumber = int.MaxValue;

	public bool isSealFreeze;

	public Direction m_Direction;

	public bool isInvisible;

	public bool isSelectable = true;
}
