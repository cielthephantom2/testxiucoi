using UnityEngine;

public class BattleObjectControllerJoy : MonoBehaviour
{
	private BattleController battlecontroller;

	private BattleObject battleObject;

	private const float MovementBlockSize = 50f;

	protected float m_MoveTimer;

	protected const float MovingSpeedPPS = 250f;

	protected float m_cameraOffset = 50f;

	protected const float TimeToMoveOneBlock = 0.2f;

	private Vector2 m_MovingFrom;

	private Vector2 m_MovingTo;

	private CurcorController m_curcor;

	private string aniname_walk = "A02-walk";

	private void Awake()
	{
	}

	private void Start()
	{
		battlecontroller = GameObject.Find("Camera").GetComponent<BattleController>();
		battleObject = base.gameObject.GetComponent<BattleObject>();
		m_curcor = GameObject.Find("Curcor").GetComponent<CurcorController>();
	}

	private void Update()
	{
		if (battleObject.m_State == BattleObjectState.Moving)
		{
			PlayerMovingProcess();
		}
	}

	public int PlayerJoyMove(Vector2 playerMoveInput)
	{
		if (Mathf.Abs(playerMoveInput.x) > Mathf.Abs(playerMoveInput.y))
		{
			playerMoveInput.y = 0f;
		}
		else
		{
			playerMoveInput.x = 0f;
		}
		Vector2 zero = Vector2.zero;
		int result = 0;
		if (playerMoveInput.x != 0f)
		{
			zero.x = playerMoveInput.x;
			zero.y = 0f;
			if (playerMoveInput.x > 0f)
			{
				battleObject.Face(Direction.Left);
				result = 4;
			}
			else
			{
				battleObject.Face(Direction.Right);
				result = 2;
			}
		}
		else if (playerMoveInput.y != 0f)
		{
			zero.x = 0f;
			zero.y = playerMoveInput.y;
			if (playerMoveInput.y > 0f)
			{
				battleObject.Face(Direction.Up);
				result = 3;
			}
			else
			{
				battleObject.Face(Direction.Down);
				result = 1;
			}
		}
		zero.Normalize();
		if (playerMoveInput.SqrMagnitude() > 0f)
		{
			battlecontroller.tilemap.WorldToCell(battleObject.transform.position);
			Vector3Int vector3Int = battlecontroller.tilemap.WorldToCell(battleObject.transform.position + (Vector3)zero * 50f);
			Vector3Int vector3Int2 = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
			if (!battlecontroller.CheckIsBattleObjectOnGrid(vector3Int2) && !battlecontroller.CheckIsItemOnGrid(vector3Int2) && battlecontroller.current.unitRange.ContainsKey(vector3Int2))
			{
				m_MovingFrom = battleObject.transform.position;
				m_MovingTo = (Vector2)battleObject.transform.position + zero * 50f;
				battleObject.SetBattleObjState(BattleObjectState.Moving);
				battleObject.PlayAnimation(aniname_walk);
				battleObject.PlayAudioClip(AudioClipEnum.walkClip);
				AStarAlgorithmBattleField.startPos = vector3Int2;
			}
		}
		return result;
	}

	private void PlayerMovingProcess()
	{
		m_MoveTimer += Time.deltaTime;
		float num = m_MoveTimer / 0.2f;
		Vector2 vector = Vector2.Lerp(m_MovingFrom, m_MovingTo, num);
		base.gameObject.transform.position = vector;
		battlecontroller.SetCameraTrans(battleObject, isSetCurcor: true);
		if (num >= 1f)
		{
			battleObject.SetBattleObjState(BattleObjectState.WaitingForInput);
			m_MoveTimer = Mathf.Repeat(m_MoveTimer, 0.2f);
		}
	}
}
