using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using UnityEngine;

public class CheckSkillFormat : MonoBehaviour
{
	private void Start()
	{
		SkillB03CheckFormat();
		SkillB02CheckFormat();
		SkillB06CheckFormat();
		SkillB07CheckFormat();
		CheckB02B06AddB03Paraplus();
		checkSkillShowInSceneInfo();
		GetAllSaveDataKeyWord();
	}

	private void checkSkillShowInSceneInfo()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		foreach (gang_b03Table.Row row in CommonResourcesData.b03.GetRowList())
		{
			List<string> skillList = new List<string> { row.Skill1, row.Skill2, row.Skill3, row.Skill4, row.Skill5 };
			List<string> skillEcList = new List<string> { row.Skill1EC, row.Skill2EC, row.Skill3EC, row.Skill4EC, row.Skill5EC };
			SkillInfo skillInfo = new SkillInfo();
			skillInfo.InitSkill(skillList, skillEcList, int.Parse(row.LV) / 2);
			List<string> list = new List<string>();
			for (int i = 0; i <= skillInfo.sid; i++)
			{
				string text = skillInfo.sName[i];
				float num = skillInfo.sValueNum[i];
				int num2 = skillInfo.sTurnNum[i];
				_ = " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist");
				string text2 = SharedData.Instance().m_A01NameRowDirec[text].NameScene_Trans + " ";
				string text3 = "";
				string text4 = "";
				string text5 = " ";
				if (num != 0f)
				{
					List<string> list2 = new List<string>
					{
						"Fend", "Draw", "Steal", "StealATK", "Bleed", "Poison", "Drunk", "Hurt", "Seal", "Burn",
						"Mad", "Spit", "MPburn", "HPsteal", "MPsteal", "Impact", "Swap", "AllWugongDownExceptMelody", "Poisonturn", "Hurtturn",
						"Bleedturn", "Madturn", "Burnturn", "Summon"
					};
					text3 = ((!text.EndsWith("down") && !text.EndsWith("minus") && !list2.Contains(text)) ? ((num > 0f) ? "<绿>" : "<红>") : ((num > 0f) ? "<红>" : "<绿>"));
					float num3 = (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? 100f : 1f);
					string text6 = (SharedData.Instance().m_A01NameRowDirec[text].Type.Equals("2") ? "%" : "");
					text4 = ((num > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num3 * num)) + text6;
					text5 = " ";
				}
				string text7 = ((num2 != 0) ? (" " + num2 + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round")) : "");
				string item = text2 + text3 + text4 + text5 + text7;
				list.Add(item);
			}
			if (list.Count > 0)
			{
				dictionary.Add(row.ID + "|" + row.Name, list);
			}
		}
		foreach (gang_b02Table.Row row2 in CommonResourcesData.b02.GetRowList())
		{
			List<string> skillList2 = new List<string> { row2.Skills1 };
			List<string> skillEcList2 = new List<string> { row2.Skills1Ec };
			SkillInfo skillInfo2 = new SkillInfo();
			skillInfo2.InitSkill(skillList2, skillEcList2, 1);
			List<string> list3 = new List<string>();
			for (int j = 0; j <= skillInfo2.sid; j++)
			{
				string text8 = skillInfo2.sName[j];
				float num4 = skillInfo2.sValueNum[j];
				int num5 = skillInfo2.sTurnNum[j];
				_ = " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist");
				string text9 = SharedData.Instance().m_A01NameRowDirec[text8].NameScene_Trans + " ";
				string text10 = "";
				string text11 = "";
				string text12 = "";
				if (num4 != 0f)
				{
					List<string> list4 = new List<string>
					{
						"Fend", "Draw", "Steal", "StealATK", "Bleed", "Poison", "Drunk", "Hurt", "Seal", "Burn",
						"Mad", "Spit", "MPburn", "HPsteal", "MPsteal", "Impact", "Swap", "AllWugongDownExceptMelody", "Poisonturn", "Hurtturn",
						"Bleedturn", "Madturn", "Burnturn", "Summon"
					};
					text10 = ((!text8.EndsWith("down") && !text8.EndsWith("minus") && !list4.Contains(text8)) ? ((num4 > 0f) ? "<绿>" : "<红>") : ((num4 > 0f) ? "<红>" : "<绿>"));
					float num6 = (SharedData.Instance().m_A01NameRowDirec[text8].Type.Equals("2") ? 100f : 1f);
					string text13 = (SharedData.Instance().m_A01NameRowDirec[text8].Type.Equals("2") ? "%" : "");
					text11 = ((num4 > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num6 * num4)) + text13;
					text12 = " ";
				}
				string text14 = ((num5 != 0) ? (" " + num5 + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round")) : "");
				string item2 = text9 + text10 + text11 + text12 + text14;
				list3.Add(item2);
			}
			if (list3.Count > 0)
			{
				dictionary.Add(row2.ID + "|" + row2.Name, list3);
			}
		}
		foreach (gang_b07Table.Row row3 in CommonResourcesData.b07.GetRowList())
		{
			List<string> skillList3 = new List<string> { row3.Skills1, row3.Skills2, row3.Skills3, row3.Skills4 };
			List<string> skillEcList3 = new List<string> { row3.Skills1Ec, row3.Skills2Ec, row3.Skills3Ec, row3.Skills4Ec };
			SkillInfo skillInfo3 = new SkillInfo();
			skillInfo3.InitSkill(skillList3, skillEcList3, 1);
			List<string> list5 = new List<string>();
			for (int k = 0; k <= skillInfo3.sid; k++)
			{
				string text15 = skillInfo3.sName[k];
				float num7 = skillInfo3.sValueNum[k];
				int num8 = skillInfo3.sTurnNum[k];
				_ = " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist");
				string text16 = SharedData.Instance().m_A01NameRowDirec[text15].NameScene_Trans + " ";
				string text17 = "";
				string text18 = "";
				string text19 = "";
				if (num7 != 0f)
				{
					List<string> list6 = new List<string>
					{
						"Fend", "Draw", "Steal", "StealATK", "Bleed", "Poison", "Drunk", "Hurt", "Seal", "Burn",
						"Mad", "Spit", "MPburn", "HPsteal", "MPsteal", "Impact", "Swap", "AllWugongDownExceptMelody", "Poisonturn", "Hurtturn",
						"Bleedturn", "Madturn", "Burnturn", "Summon"
					};
					text17 = ((!text15.EndsWith("down") && !text15.EndsWith("minus") && !list6.Contains(text15)) ? ((num7 > 0f) ? "<绿>" : "<红>") : ((num7 > 0f) ? "<红>" : "<绿>"));
					float num9 = (SharedData.Instance().m_A01NameRowDirec[text15].Type.Equals("2") ? 100f : 1f);
					string text20 = (SharedData.Instance().m_A01NameRowDirec[text15].Type.Equals("2") ? "%" : "");
					text18 = ((num7 > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num9 * num7)) + text20;
					text19 = " ";
				}
				string text21 = ((num8 != 0) ? (" " + num8 + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round")) : "");
				string item3 = text16 + text17 + text18 + text19 + text21;
				list5.Add(item3);
			}
			if (list5.Count > 0)
			{
				dictionary.Add(row3.ID + "|" + row3.Name, list5);
			}
		}
		foreach (gang_b06Table.Row row4 in CommonResourcesData.b06.GetRowList())
		{
			List<string> skillList4 = new List<string> { row4.Skills1, row4.Skills2, row4.Skills3 };
			List<string> skillEcList4 = new List<string> { row4.Skills1Ec, row4.Skills2Ec, row4.Skills3Ec };
			SkillInfo skillInfo4 = new SkillInfo();
			skillInfo4.InitSkill(skillList4, skillEcList4, 1);
			List<string> list7 = new List<string>();
			for (int l = 0; l <= skillInfo4.sid; l++)
			{
				string text22 = skillInfo4.sName[l];
				float num10 = skillInfo4.sValueNum[l];
				int num11 = skillInfo4.sTurnNum[l];
				_ = " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist");
				string text23 = SharedData.Instance().m_A01NameRowDirec[text22].NameScene_Trans + " ";
				string text24 = "";
				string text25 = "";
				string text26 = "";
				if (num10 != 0f)
				{
					List<string> list8 = new List<string>
					{
						"Fend", "Draw", "Steal", "StealATK", "Bleed", "Poison", "Drunk", "Hurt", "Seal", "Burn",
						"Mad", "Spit", "MPburn", "HPsteal", "MPsteal", "Impact", "Swap", "AllWugongDownExceptMelody", "Poisonturn", "Hurtturn",
						"Bleedturn", "Madturn", "Burnturn", "Summon"
					};
					text24 = ((!text22.EndsWith("down") && !text22.EndsWith("minus") && !list8.Contains(text22)) ? ((num10 > 0f) ? "<绿>" : "<红>") : ((num10 > 0f) ? "<红>" : "<绿>"));
					float num12 = (SharedData.Instance().m_A01NameRowDirec[text22].Type.Equals("2") ? 100f : 1f);
					string text27 = (SharedData.Instance().m_A01NameRowDirec[text22].Type.Equals("2") ? "%" : "");
					text25 = ((num10 > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num12 * num10)) + text27;
					text26 = " ";
				}
				string text28 = ((num11 != 0) ? (" " + num11 + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round")) : "");
				string item4 = text23 + text24 + text25 + text26 + text28;
				list7.Add(item4);
			}
			if (list7.Count > 0)
			{
				dictionary.Add(row4.id + "|" + row4.name, list7);
			}
		}
		string contents = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/SkillEffectInfoList.json", contents);
	}

	private List<string> CheckB02B06AddB03Paraplus()
	{
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		foreach (gang_b02Table.Row row in CommonResourcesData.b02.GetRowList())
		{
			List<string> list3 = new List<string> { row.add1, row.add2, row.add3, row.add4, row.add5 };
			new List<string> { row.Attribute1, row.Attribute2, row.Attribute3, row.Attribute4, row.Attribute5 };
			for (int i = 0; i < list3.Count; i++)
			{
				string text = list3[i];
				if (!(text == "0") && !SharedData.Instance().m_A01NameRowDirec.ContainsKey(text))
				{
					list2.Add("B02:id = " + row.ID + "; keyword [" + text + "] not exit");
				}
			}
		}
		List<string> list4 = new List<string>();
		foreach (gang_b06Table.Row row2 in CommonResourcesData.b06.GetRowList())
		{
			List<string> list5 = new List<string> { row2.add1, row2.add2, row2.add3, row2.add4 };
			new List<string> { row2.attribute1, row2.attribute2, row2.attribute3, row2.attribute4 };
			for (int j = 0; j < list5.Count; j++)
			{
				string text2 = list5[j];
				if (!(text2 == "0") && !SharedData.Instance().m_A01NameRowDirec.ContainsKey(text2))
				{
					list4.Add("B06:id = " + row2.id + "; keyword [" + text2 + "] not exit");
				}
			}
		}
		List<string> list6 = new List<string>();
		foreach (gang_b03Table.Row row3 in CommonResourcesData.b03.GetRowList())
		{
			List<string> obj = new List<string> { row3.Paraplus1, row3.Paraplus2, row3.Paraplus3, row3.Paraplus4 };
			List<string> list7 = new List<string>();
			List<string> list8 = new List<string>();
			foreach (string item in obj)
			{
				if (!(item == "0"))
				{
					if (item.Split("|").Length != 2)
					{
						list6.Add("B03:id = " + row3.ID + "; Paraplus format [" + item + "] error");
					}
					else
					{
						list7.Add(item.Split("|")[0]);
						list8.Add(item.Split("|")[1]);
					}
				}
			}
			for (int k = 0; k < list7.Count; k++)
			{
				string text3 = list7[k];
				if (!SharedData.Instance().m_A01NameRowDirec.ContainsKey(text3))
				{
					list6.Add("B03:id = " + row3.ID + "; keyword [" + text3 + "] not exit");
				}
			}
		}
		list.AddRange(list2);
		list.AddRange(list4);
		list.AddRange(list6);
		string contents = JsonConvert.SerializeObject(list, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/AddCheckList.json", contents);
		return list;
	}

	private Dictionary<string, List<string>> SkillB03CheckFormat()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		new List<string>();
		foreach (gang_b03Table.Row row in CommonResourcesData.b03.GetRowList())
		{
			KongFuData obj = new KongFuData
			{
				kf = row
			};
			List<string> list = new List<string>();
			new List<SkillShowInfoItem>();
			obj.lv = int.Parse(row.LV) / 2;
			foreach (SkillShowInfoItem item in SkillHoverShowInfo.GetSkillShowInfo(obj))
			{
				if (!item.info.StartsWith("暴击率") && !item.info.StartsWith("暴击伤害") && !item.info.StartsWith("连击率"))
				{
					list.Add(item.info);
				}
			}
			if (list.Count > 0)
			{
				dictionary.Add(row.ID + "|" + row.Name, list);
			}
		}
		List<string> list2 = new List<string>();
		foreach (KeyValuePair<string, List<string>> item2 in dictionary)
		{
			if (item2.Value.Count <= 0)
			{
				continue;
			}
			foreach (string item3 in item2.Value)
			{
				list2.Add(item3 + "|" + item2.Key);
			}
		}
		list2.Sort();
		string contents = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/B03SkillItemShowInItemBox.json", contents);
		return dictionary;
	}

	private Dictionary<string, string> SkillB02CheckFormat()
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (gang_b02Table.Row row in CommonResourcesData.b02.GetRowList())
		{
			if (row.Skills1 != "0")
			{
				SkillShowInfoItem skillShowInfoItem = SkillHoverShowInfo.SkillUI(row.Skills1, row.Enhance, "1", row.Skills1Ec);
				dictionary.Add(row.ID + "|" + row.Name, skillShowInfoItem.info);
			}
		}
		string contents = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/B02SkillItemShowInItemBox.json", contents);
		return dictionary;
	}

	private Dictionary<string, List<string>> SkillB06CheckFormat()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		foreach (gang_b06Table.Row row in CommonResourcesData.b06.GetRowList())
		{
			List<string> list = new List<string> { row.Skills1, row.Skills2, row.Skills3 };
			List<string> list2 = new List<string> { row.Skills1Ec, row.Skills2Ec, row.Skills3Ec };
			List<string> list3 = new List<string>();
			for (int i = 0; i < list.Count; i++)
			{
				if (!(list[i] == "0"))
				{
					SkillShowInfoItem skillShowInfoItem = SkillHoverShowInfo.SkillUI(list[i], 1, "1", list2[i]);
					list3.Add(skillShowInfoItem.info);
				}
			}
			if (list3.Count > 0)
			{
				dictionary.Add(row.id + "|" + row.name, list3);
			}
		}
		string contents = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/B06SkillItemShowInItemBox.json", contents);
		return dictionary;
	}

	private Dictionary<string, List<string>> SkillB07CheckFormat()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		foreach (gang_b07Table.Row row in CommonResourcesData.b07.GetRowList())
		{
			if (row.Use[0] == '0')
			{
				continue;
			}
			List<string> list = new List<string> { row.Skills1, row.Skills2, row.Skills3, row.Skills4 };
			List<string> list2 = new List<string> { row.Skills1Ec, row.Skills2Ec, row.Skills3Ec, row.Skills4Ec };
			List<string> list3 = new List<string>();
			for (int i = 0; i < list.Count; i++)
			{
				if (!(list[i] == "0"))
				{
					SkillShowInfoItem skillShowInfoItem = SkillHoverShowInfo.SkillUI(list[i], 1, "1", list2[i]);
					list3.Add(skillShowInfoItem.info);
				}
			}
			if (list3.Count > 0)
			{
				dictionary.Add(row.ID + "|" + row.Name, list3);
			}
		}
		string contents = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/B07FieldSkillItemShowInItemBox.json", contents);
		Dictionary<string, List<string>> dictionary2 = new Dictionary<string, List<string>>();
		foreach (gang_b07Table.Row row2 in CommonResourcesData.b07.GetRowList())
		{
			if (row2.Use[1] == '0')
			{
				continue;
			}
			List<string> list4 = new List<string> { row2.Skills1, row2.Skills2, row2.Skills3, row2.Skills4 };
			List<string> list5 = new List<string> { row2.Skills1Ec, row2.Skills2Ec, row2.Skills3Ec, row2.Skills4Ec };
			List<string> list6 = new List<string>();
			for (int j = 0; j < list4.Count; j++)
			{
				if (!(list4[j] == "0"))
				{
					SkillShowInfoItem skillShowInfoItem2 = SkillHoverShowInfo.SkillUI(list4[j], 1, "1", list5[j]);
					list6.Add(skillShowInfoItem2.info);
				}
			}
			if (list6.Count > 0)
			{
				dictionary2.Add(row2.ID + "|" + row2.Name, list6);
			}
		}
		contents = JsonConvert.SerializeObject(dictionary2, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/B07BattleSkillItemShowInItemBox.json", contents);
		return dictionary;
	}

	private void GetAllSaveDataKeyWord()
	{
		List<string> list = new List<string>();
		foreach (gang_b03Table.Row row in CommonResourcesData.b03.GetRowList())
		{
			foreach (string item in new List<string> { row.Paraplus1, row.Paraplus2, row.Paraplus3, row.Paraplus4 })
			{
				if (!item.Equals("0") && !list.Contains(item.Split("|")[0]))
				{
					list.Add(item.Split("|")[0]);
				}
			}
		}
		foreach (gang_b07Table.Row row2 in CommonResourcesData.b07.GetRowList())
		{
			if (row2.Use[0] != '1')
			{
				continue;
			}
			foreach (string item2 in new List<string> { row2.Skills1, row2.Skills2, row2.Skills3, row2.Skills4 })
			{
				if (!item2.Equals("0") && !list.Contains(item2.Split("&")[0]))
				{
					list.Add(item2.Split("&")[0]);
				}
			}
		}
		foreach (gang_e01Table.Row row3 in CommonResourcesData.e01.GetRowList())
		{
			if (row3.action.Contains("GET|ATTR|") && !list.Contains(row3.action.Split("|")[2]))
			{
				list.Add(row3.action.Split("|")[2]);
			}
		}
		string contents = JsonConvert.SerializeObject(list, Formatting.Indented);
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/saveDataKeyWordList.json", contents);
	}

	private void Update()
	{
	}
}
