using System.Collections.Generic;
using System.Globalization;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public static class EquipOrItemHoverShowInfo
{
	public static void ShowEquipItemHover(CharaData CurCharadata, CharaData ItemCharadata, Transform hoverItem, bool useCharaData = true)
	{
		hoverItem.gameObject.SetActive(value: true);
		string[] array = SharedData.Instance().m_OpenDetail.Split('|');
		string value = ItemHoverSub("Select/", array[0], array[1], CurCharadata, ItemCharadata, hoverItem);
		hoverItem.Find("Select").gameObject.SetActive(value: true);
		if (CurCharadata == ItemCharadata && CurCharadata != null)
		{
			hoverItem.Find("Select").gameObject.SetActive(value: false);
		}
		hoverItem.Find("Equiped").gameObject.SetActive(value: false);
		if (CurCharadata != null && useCharaData)
		{
			if ("1".Equals(value) && !CurCharadata.m_EquipSlot[0].Equals("0"))
			{
				hoverItem.Find("Equiped").gameObject.SetActive(value: true);
				gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(CurCharadata.m_EquipSlot[0]);
				ItemHoverSub("Equiped/", row.ID, row.Relateid, CurCharadata, ItemCharadata, hoverItem);
			}
			else if ("2".Equals(value) && !CurCharadata.m_EquipSlot[1].Equals("0"))
			{
				hoverItem.Find("Equiped").gameObject.SetActive(value: true);
				gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(CurCharadata.m_EquipSlot[1]);
				ItemHoverSub("Equiped/", row2.ID, row2.Relateid, CurCharadata, ItemCharadata, hoverItem);
			}
			else if ("3".Equals(value) && !CurCharadata.m_EquipSlot[2].Equals("0"))
			{
				hoverItem.Find("Equiped").gameObject.SetActive(value: true);
				gang_b07Table.Row row3 = CommonResourcesData.b07.Find_ID(CurCharadata.m_EquipSlot[2]);
				ItemHoverSub("Equiped/", row3.ID, row3.Relateid, CurCharadata, ItemCharadata, hoverItem);
			}
		}
	}

	public static string ItemHoverSub(string _prefix, string _ids0, string _ids1, CharaData CurCharadata, CharaData ItemCharadata, Transform hoverItem, gang_b02Table.Row _originB02Row = null)
	{
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_ids0);
		gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(_ids1);
		gang_b02Table.Row row3 = row2;
		if (_ids1.Contains("MB02_"))
		{
			row3 = CommonResourcesData.b02.Find_ID(_ids1.Split("_")[1]);
		}
		if (_prefix.Equals("Select/") || _prefix.Equals("Equiped/"))
		{
			hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG").gameObject.SetActive(value: true);
			if (_prefix.Equals("Select/"))
			{
				hoverItem.Find(_prefix + "SelcetTeammate").gameObject.SetActive(value: false);
				if (ItemCharadata != null)
				{
					hoverItem.Find(_prefix + "SelcetTeammate").gameObject.SetActive(value: true);
					Sprite tachieHead = CommonResourcesData.GetTachieHead(ItemCharadata.m_BattleIcon);
					if (tachieHead == null)
					{
						hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: false);
						hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
						hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(ItemCharadata);
					}
					else
					{
						hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: true);
						hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
						hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
					}
				}
			}
			else if (_prefix.Equals("Equiped/"))
			{
				hoverItem.Find(_prefix + "SelcetTeammate").gameObject.SetActive(value: true);
				Sprite tachieHead2 = CommonResourcesData.GetTachieHead(CurCharadata.m_BattleIcon);
				if (tachieHead2 == null)
				{
					hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: false);
					hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
					hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(ItemCharadata);
				}
				else
				{
					hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: true);
					hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
					hoverItem.Find(_prefix + "SelcetTeammate/IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead2;
				}
			}
		}
		hoverItem.Find(_prefix + "icon/Image").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(row.BookIcon);
		hoverItem.Find(_prefix + "icon/Name").GetComponent<Text>().text = row2.Name_Trans;
		hoverItem.Find(_prefix).GetComponent<Image>().sprite = Resources.Load("images/01-border/boder-20231228-06", typeof(Sprite)) as Sprite;
		if (row2.Enhance > 0)
		{
			hoverItem.Find(_prefix + "icon/Name/Text").GetComponent<Text>().text = "+" + row2.Enhance;
			if (row2.Enhance.Equals(10))
			{
				hoverItem.Find(_prefix).GetComponent<Image>().sprite = Resources.Load("images/01-border/boder-20231228-equipplus-01", typeof(Sprite)) as Sprite;
			}
		}
		else
		{
			hoverItem.Find(_prefix + "icon/Name/Text").GetComponent<Text>().text = "";
		}
		for (int i = 1; i <= 10; i++)
		{
			hoverItem.Find(_prefix + "Stars/Stars" + i).gameObject.SetActive(value: false);
		}
		for (int j = 1; j <= row2.Enhance; j++)
		{
			if (_originB02Row != null && j > _originB02Row.Enhance)
			{
				hoverItem.Find(_prefix + "Stars/Stars" + j).GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
				hoverItem.Find(_prefix + "Stars/Stars" + j).gameObject.SetActive(value: true);
			}
			else
			{
				hoverItem.Find(_prefix + "Stars/Stars" + j).gameObject.SetActive(value: true);
			}
		}
		switch (row2.Style)
		{
		case "1":
			if (_prefix == "Equiped/")
			{
				hoverItem.Find(_prefix + "EquipType").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EquipedWeapon");
			}
			else
			{
				hoverItem.Find(_prefix + "EquipType").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EquipmentWeapon");
			}
			break;
		case "2":
			if (_prefix == "Equiped/")
			{
				hoverItem.Find(_prefix + "EquipType").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EquipedArmor");
			}
			else
			{
				hoverItem.Find(_prefix + "EquipType").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EquipmentArmor");
			}
			break;
		case "3":
			if (_prefix == "Equiped/")
			{
				hoverItem.Find(_prefix + "EquipType").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EquipedAccessory");
			}
			else
			{
				hoverItem.Find(_prefix + "EquipType").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EquipmentAccessory");
			}
			break;
		}
		gang_a01Table.Row row4 = CommonResourcesData.a01.Find_Name(row2.Limit1);
		hoverItem.Find(_prefix + "icon/Status").GetComponent<Text>().text = row4.NameScene_Trans;
		bool flag = false;
		if (CurCharadata != null)
		{
			float fieldValueByName = CurCharadata.GetFieldValueByName(row2.Limit1);
			float num = float.Parse(row2.Limitvalue, CultureInfo.InvariantCulture);
			flag = ((row2.Logic == "1") ? (fieldValueByName < num) : ((!(row2.Logic == "2")) ? (fieldValueByName != num) : (fieldValueByName > num)));
		}
		string logic = row2.Logic;
		if (!(logic == "1"))
		{
			if (logic == "2")
			{
				hoverItem.Find(_prefix + "icon/Status/Text").GetComponent<Text>().text = (flag ? "<color=red>" : "") + CommonFunc.I18nGetLocalizedValue("I18N_NoGreater") + " " + row2.Limitvalue + (flag ? "</color>" : "");
			}
			else
			{
				hoverItem.Find(_prefix + "icon/Status/Text").GetComponent<Text>().text = (flag ? "<color=red>" : "") + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + " " + row2.Limitvalue + (flag ? "</color>" : "");
			}
		}
		else
		{
			hoverItem.Find(_prefix + "icon/Status/Text").GetComponent<Text>().text = (flag ? "<color=red>" : "") + row2.Limitvalue + (flag ? "</color>" : "");
		}
		SetStatus(1, row2.add1, row2.Attribute1, _prefix, hoverItem, row3.add1, row3.Attribute1, (_originB02Row != null) ? _originB02Row.add1 : row2.add1, (_originB02Row != null) ? _originB02Row.Attribute1 : row2.Attribute1);
		SetStatus(2, row2.add2, row2.Attribute2, _prefix, hoverItem, row3.add2, row3.Attribute2, (_originB02Row != null) ? _originB02Row.add2 : row2.add2, (_originB02Row != null) ? _originB02Row.Attribute2 : row2.Attribute2);
		SetStatus(3, row2.add3, row2.Attribute3, _prefix, hoverItem, row3.add3, row3.Attribute3, (_originB02Row != null) ? _originB02Row.add3 : row2.add3, (_originB02Row != null) ? _originB02Row.Attribute3 : row2.Attribute3);
		SetStatus(4, row2.add4, row2.Attribute4, _prefix, hoverItem, row3.add4, row3.Attribute4, (_originB02Row != null) ? _originB02Row.add4 : row2.add4, (_originB02Row != null) ? _originB02Row.Attribute4 : row2.Attribute4);
		SetStatus(5, row2.add5, row2.Attribute5, _prefix, hoverItem, row3.add5, row3.Attribute5, (_originB02Row != null) ? _originB02Row.add5 : row2.add5, (_originB02Row != null) ? _originB02Row.Attribute5 : row2.Attribute5);
		hoverItem.Find(_prefix + "Add/Skill-add/Text").GetComponent<Text>().text = "";
		if (row2.Skills1 != "0")
		{
			SkillShowInfoItem skillShowInfoItem = SkillHoverShowInfo.SkillUI(row2.Skills1, row2.Enhance, "1", row2.Skills1Ec);
			hoverItem.Find(_prefix + "Add/Skill-add/Text").GetComponent<Text>().text = skillShowInfoItem.info;
		}
		Transform transform = hoverItem.Find(_prefix + "Set");
		if (transform != null)
		{
			transform.gameObject.SetActive(value: false);
		}
		string text = row.ID;
		if (text.Contains('_'))
		{
			text = text.Split('_')[1];
		}
		if (CommonResourcesData.b02SetDict.ContainsKey(text) && transform != null)
		{
			gang_b02SetTable.Row row5 = CommonResourcesData.b02Set.Find_ID(CommonResourcesData.b02SetDict[text][0]);
			transform.gameObject.SetActive(value: true);
			for (int k = 1; k <= 3; k++)
			{
				transform.Find("Set" + k).gameObject.SetActive(value: false);
			}
			string[] array = row5.Set.Split('|');
			int num2 = 0;
			for (int l = 0; l < array.Length; l++)
			{
				string text2 = array[l];
				string value = "_" + array[l] + "_";
				transform.Find("Set" + (l + 1)).gameObject.SetActive(value: true);
				transform.Find("Set" + (l + 1)).GetComponentInChildren<Text>().text = CommonResourcesData.b07.Find_ID(text2).Name_Trans;
				int num3 = 0;
				if (SharedData.Instance().m_MapController != null)
				{
					foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
					{
						if (item.Key.Contains(value) || item.Key.Equals(text2))
						{
							num3 += item.Value;
						}
					}
					List<string> list = new List<string>();
					list.Add(SharedData.Instance().playerid);
					list.AddRange(SharedData.Instance().FullTeam);
					foreach (string item2 in list)
					{
						CharaData charaData = SharedData.Instance().GetCharaData(item2);
						if (charaData.m_Training_Id != "0")
						{
							gang_b07Table.Row row6 = CommonResourcesData.b07.Find_Relate_Wugong_id(charaData.m_Training_Id);
							if (!row6.Value.Equals("0") && (row6.ID.Contains(value) || row6.ID.Equals(text2)))
							{
								num3++;
							}
						}
						foreach (string item3 in charaData.m_EquipSlot)
						{
							if (item3 != "0")
							{
								gang_b07Table.Row row7 = CommonResourcesData.b07.Find_ID(item3);
								if (row7.ID.Contains(value) || row7.ID.Equals(text2))
								{
									num3++;
								}
							}
						}
					}
				}
				else
				{
					num3 = 1;
				}
				if (num3 > 0)
				{
					transform.Find("Set" + (l + 1)).GetComponentInChildren<Text>().text = "<color=#FF9E0D>" + transform.Find("Set" + (l + 1)).GetComponentInChildren<Text>().text + "</color>";
					num2++;
				}
				else
				{
					transform.Find("Set" + (l + 1)).GetComponentInChildren<Text>().text = "<color=#918574>" + transform.Find("Set" + (l + 1)).GetComponentInChildren<Text>().text + "</color>";
				}
			}
			transform.Find("Name/Text").GetComponent<Text>().text = "(" + num2 + "/" + array.Length + ")";
		}
		return row2.Style;
	}

	private static void SetStatus(int _id, string _add, string _Attribute, string _prefix, Transform hoverItem, string _addOrigin, string _AttributeOrigin, string _addBefore = "", string _AttributeBefore = "")
	{
		if (_add != "0" && SharedData.Instance().m_A01NameRowDirec.ContainsKey(_add))
		{
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(_add);
			string text = "";
			text = ((!(row.Type == "2")) ? _Attribute : ((Mathf.Round(100f * float.Parse(_Attribute, CultureInfo.InvariantCulture) * 100f) / 100f).ToString("0.##") + "%"));
			string valueStr = "";
			if ("Drunk".Equals(_add) || "Hurt".Equals(_add) || "Poison".Equals(_add) || "Bleed".Equals(_add) || "Burn".Equals(_add) || "Seal".Equals(_add) || "Mad".Equals(_add))
			{
				if (text[0] == '-')
				{
					valueStr = "·" + row.NameScene_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist_2") + " <color=green>+" + text.Substring(1) + "</color>";
				}
				else
				{
					valueStr = "·" + row.NameScene_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist_2") + " <color=red>-" + text + "</color>";
				}
			}
			else if (text[0] == '-')
			{
				valueStr = "·" + row.NameScene_Trans + " <color=red>" + text + "</color>";
			}
			else
			{
				valueStr = "·" + row.NameScene_Trans + " <color=green>+" + text + "</color>";
			}
			float delay = 0f;
			if (!_AttributeBefore.Equals(_Attribute) || !_addBefore.Equals(_add))
			{
				delay = 0.5f;
				hoverItem.Find(_prefix + "Add/Status-add" + _id).GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
			DOVirtual.DelayedCall(delay, delegate
			{
				if (_Attribute != _AttributeOrigin)
				{
					valueStr = valueStr.Replace("<color=green>", "<color=#d4ea90>");
				}
				if (_add != "0" && _addOrigin == "0")
				{
					hoverItem.Find(_prefix + "Add/Status-add" + _id).GetComponent<Image>().sprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
				}
				else
				{
					hoverItem.Find(_prefix + "Add/Status-add" + _id).GetComponent<Image>().sprite = Resources.Load("images/01-border/boder-20231228-button-03", typeof(Sprite)) as Sprite;
				}
				hoverItem.Find(_prefix + "Add/Status-add" + _id + "/Text").GetComponent<Text>().text = valueStr;
			});
		}
		else
		{
			hoverItem.Find(_prefix + "Add/Status-add" + _id).GetComponent<Image>().sprite = Resources.Load("images/01-border/boder-20231228-button-03", typeof(Sprite)) as Sprite;
			hoverItem.Find(_prefix + "Add/Status-add" + _id + "/Text").GetComponent<Text>().text = "";
		}
	}
}
