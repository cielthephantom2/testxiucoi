using UnityEngine;

public class DisplayBuff
{
	public string type;

	public bool isShow;

	public string str;

	public GameObject buffObj;
}
