public class TraitItemData : ItemDataBase
{
	public string showIndex = "";

	public gang_b06Table.Row b06Row;

	public override bool IsFilterMatched(string filterStr)
	{
		return true;
	}
}
