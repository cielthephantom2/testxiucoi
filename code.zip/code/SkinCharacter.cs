using System.Collections.Generic;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.U2D;

public static class SkinCharacter
{
	private static bool isInit = false;

	public static Dictionary<string, string> skinData = null;

	public static Dictionary<string, Texture2D> skinTexture2DDict = new Dictionary<string, Texture2D>();

	public static Dictionary<string, SkeletonAnimation> skinSkeletonAnimationDict = new Dictionary<string, SkeletonAnimation>();

	public static List<SkeletonGraphic> initSkeletonGraphicList = new List<SkeletonGraphic>();

	private static SpriteAtlas CommonSpriteAtlas;

	private static SpriteAtlas TopSpriteAtlas;

	private static SpriteAtlas LeftSpriteAtlas;

	private static SpriteAtlas BackSpriteAtlas;

	private static GameObject CharacterBase;

	public static void Init()
	{
		CommonSpriteAtlas = Resources.Load("SkinCharacter/02-SpriteAtlas/00-CommonSpriteAtlas") as SpriteAtlas;
		TopSpriteAtlas = Resources.Load("SkinCharacter/02-SpriteAtlas/00-TopSpriteAtlas") as SpriteAtlas;
		LeftSpriteAtlas = Resources.Load("SkinCharacter/02-SpriteAtlas/00-LeftSpriteAtlas") as SpriteAtlas;
		BackSpriteAtlas = Resources.Load("SkinCharacter/02-SpriteAtlas/00-BackSpriteAtlas") as SpriteAtlas;
		CharacterBase = Resources.Load("Prefabs/CharacterBase") as GameObject;
		isInit = true;
	}

	public static GameObject InitSkinCharacter(string prefabID)
	{
		gang_b01SkinTable.Row row = CommonResourcesData.b01Skin.Find_ID(prefabID);
		if (row == null)
		{
			row = CommonResourcesData.b01Skin.Find_ID("TestCharacter");
		}
		return InitSkinCharacter(row);
	}

	public static GameObject InitSkinCharacter(CharaData charaData)
	{
		if (charaData.b01SkinRow != null)
		{
			return InitSkinCharacter(charaData.b01SkinRow);
		}
		GameObject gameObject = CommonResourcesData.LoadCharacter(charaData.m_Prefab);
		if (gameObject == null)
		{
			return InitSkinCharacter(CommonResourcesData.b01Skin.Find_ID("TestCharacter"));
		}
		return Object.Instantiate(gameObject);
	}

	public static GameObject InitSkinCharacter(gang_b01SkinTable.Row b01SkinRow)
	{
		if (b01SkinRow == null)
		{
			b01SkinRow = CommonResourcesData.b01Skin.Find_ID("TestCharacter");
		}
		Debug.Log("InitSkinCharacter:" + b01SkinRow.Name);
		if (!isInit)
		{
			Init();
		}
		GameObject gameObject = Object.Instantiate(CharacterBase);
		gameObject.name = b01SkinRow.Name;
		skinData = SpineBonesSlots.InitSkinDict(b01SkinRow);
		SkinDependence skinDependence = CharacterSpawn.GetSkinDependence(b01SkinRow.model);
		foreach (string item in new List<string> { "body_top", "body_left", "body_back" })
		{
			Texture2D textureTemplate = skinDependence.texture_top;
			TextAsset skeletonJson = skinDependence.skeletonJson_top;
			TextAsset atlasText = skinDependence.atlasText_top;
			switch (item)
			{
			case "body_top":
				textureTemplate = skinDependence.texture_top;
				skeletonJson = skinDependence.skeletonJson_top;
				atlasText = skinDependence.atlasText_top;
				break;
			case "body_left":
				textureTemplate = skinDependence.texture_left;
				skeletonJson = skinDependence.skeletonJson_left;
				atlasText = skinDependence.atlasText_left;
				break;
			case "body_back":
				textureTemplate = skinDependence.texture_back;
				skeletonJson = skinDependence.skeletonJson_back;
				atlasText = skinDependence.atlasText_back;
				break;
			}
			GameObject gameObject2 = new GameObject(item);
			SkeletonAnimation skeletonAnimation = gameObject2.AddComponent<SkeletonAnimation>();
			gameObject2.transform.localPosition = new Vector3(0f, -10f, 0f);
			gameObject2.transform.localScale = new Vector3(90f, 90f, 1f);
			skeletonAnimation.skeletonDataAsset = null;
			Texture2D texture2D = CreateSkeletonTexture(textureTemplate);
			skeletonAnimation.skeletonDataAsset = CreateSkeletonDataAsset(skeletonJson, texture2D, atlasText);
			skeletonAnimation.initialSkinName = "_default";
			skeletonAnimation.Initialize(overwrite: false);
			skeletonAnimation.name = item;
			Dictionary<string, string> dictionary = SpineBonesSlots.InitSkinDict(b01SkinRow);
			foreach (KeyValuePair<string, string> item2 in dictionary)
			{
				string text = item2.Value;
				Slot slot = skeletonAnimation.skeleton.FindSlot(item2.Key);
				if (slot != null)
				{
					if (text == "")
					{
						slot.A = 0f;
						(slot.Attachment as RegionAttachment)?.SetColor(new Color(0f, 0f, 0f, 0f));
						continue;
					}
					slot.A = 1f;
					(slot.Attachment as RegionAttachment)?.SetColor(new Color(1f, 1f, 1f, 1f));
				}
				if (item == "body_left" && (item2.Key == "leg-right" || item2.Key == "leg-left"))
				{
					text = dictionary["leg-right"];
					textureTemplate = skinDependence.texture_left;
					skeletonJson = skinDependence.skeletonJson_left;
					atlasText = skinDependence.atlasText_left;
				}
				if (item == "body_back")
				{
					if (item2.Key == "leg-right")
					{
						text = dictionary["leg-left"];
					}
					else if (item2.Key == "leg-left")
					{
						text = dictionary["leg-right"];
					}
				}
				ModifyTextureImage(texture2D, skeletonAnimation, item2.Key, text);
			}
			gameObject2.transform.SetParent(gameObject.transform);
			int siblingIndex = 0;
			switch (item)
			{
			case "body_top":
				siblingIndex = 0;
				break;
			case "body_left":
				siblingIndex = 1;
				break;
			case "body_back":
				siblingIndex = 2;
				break;
			}
			gameObject2.transform.SetSiblingIndex(siblingIndex);
		}
		return gameObject;
	}

	public static void InitSkinCharacterUI(SkeletonGraphic _skeletonGraphic, gang_b01SkinTable.Row b01SkinRow)
	{
		if (!isInit)
		{
			Init();
		}
		Dictionary<string, string> dictionary = SpineBonesSlots.InitSkinDict(b01SkinRow);
		SkinDependence skinDependence = CharacterSpawn.GetSkinDependence(b01SkinRow.model);
		Texture2D textureTemplate = skinDependence.texture_top;
		TextAsset skeletonJson = skinDependence.skeletonJson_top;
		TextAsset atlasText = skinDependence.atlasText_top;
		if (_skeletonGraphic.name == "IconSkin" || _skeletonGraphic.name.Equals("body_top"))
		{
			textureTemplate = skinDependence.texture_top;
			skeletonJson = skinDependence.skeletonJson_top;
			atlasText = skinDependence.atlasText_top;
		}
		else if (_skeletonGraphic.name == "body_left")
		{
			textureTemplate = skinDependence.texture_left;
			skeletonJson = skinDependence.skeletonJson_left;
			atlasText = skinDependence.atlasText_left;
		}
		else if (_skeletonGraphic.name == "body_back")
		{
			textureTemplate = skinDependence.texture_back;
			skeletonJson = skinDependence.skeletonJson_back;
			atlasText = skinDependence.atlasText_back;
		}
		UnloadSkeletonGraphicTexture(_skeletonGraphic);
		Texture2D texture2D = CreateSkeletonTexture(textureTemplate);
		_skeletonGraphic.skeletonDataAsset = null;
		_skeletonGraphic.skeletonDataAsset = CreateSkeletonDataAsset(skeletonJson, texture2D, atlasText);
		_skeletonGraphic.initialSkinName = "_default";
		_skeletonGraphic.Initialize(overwrite: true);
		foreach (KeyValuePair<string, string> item in dictionary)
		{
			string text = item.Value;
			Slot slot = _skeletonGraphic.Skeleton.FindSlot(item.Key);
			if (slot != null)
			{
				if (text == "")
				{
					slot.A = 0f;
					(slot.Attachment as RegionAttachment)?.SetColor(new Color(0f, 0f, 0f, 0f));
					continue;
				}
				slot.A = 1f;
				(slot.Attachment as RegionAttachment)?.SetColor(new Color(1f, 1f, 1f, 1f));
			}
			if (_skeletonGraphic.name == "body_left" && (item.Key == "leg-right" || item.Key == "leg-left"))
			{
				text = dictionary["leg-right"];
			}
			if (_skeletonGraphic.name == "body_back")
			{
				if (item.Key == "leg-right")
				{
					text = dictionary["leg-left"];
				}
				else if (item.Key == "leg-left")
				{
					text = dictionary["leg-right"];
				}
			}
			ModifyTextureImage(texture2D, _skeletonGraphic, item.Key, text);
		}
	}

	private static void UnloadSkeletonGraphicTexture(SkeletonGraphic skeletonGraphic)
	{
		if (!(skeletonGraphic != null))
		{
			return;
		}
		if (!initSkeletonGraphicList.Contains(skeletonGraphic))
		{
			initSkeletonGraphicList.Add(skeletonGraphic);
			return;
		}
		SkeletonDataAsset skeletonDataAsset = skeletonGraphic.SkeletonDataAsset;
		if (!(skeletonDataAsset != null))
		{
			return;
		}
		AtlasAssetBase[] atlasAssets = skeletonDataAsset.atlasAssets;
		for (int i = 0; i < atlasAssets.Length; i++)
		{
			if (!(atlasAssets[i] is SpineAtlasAsset { materials: var materials }))
			{
				continue;
			}
			foreach (Material material in materials)
			{
				if (material != null && material.mainTexture != null)
				{
					Texture2D texture2D = material.mainTexture as Texture2D;
					if (texture2D != null)
					{
						Object.Destroy(texture2D);
						Debug.Log("Destroyed SkeletonGraphic Texture: " + texture2D.name);
					}
				}
			}
		}
	}

	public static void ModifyTextureImage(Texture2D textureA, SkeletonAnimation skeletonAnimation, string slotNameToReplace, string newSpriteName)
	{
		Slot slot = skeletonAnimation.Skeleton.FindSlot(slotNameToReplace);
		if (slot == null)
		{
			return;
		}
		Sprite sprite = CommonSpriteAtlas.GetSprite(newSpriteName);
		if (sprite == null)
		{
			if (skeletonAnimation.name == "body_top")
			{
				sprite = TopSpriteAtlas.GetSprite(newSpriteName);
			}
			else if (skeletonAnimation.name == "body_left")
			{
				sprite = LeftSpriteAtlas.GetSprite(newSpriteName);
			}
			else if (skeletonAnimation.name == "body_back")
			{
				sprite = BackSpriteAtlas.GetSprite(newSpriteName);
			}
		}
		if (sprite == null)
		{
			sprite = TopSpriteAtlas.GetSprite(newSpriteName);
		}
		if (sprite == null)
		{
			sprite = LeftSpriteAtlas.GetSprite(newSpriteName);
		}
		if (sprite == null)
		{
			sprite = BackSpriteAtlas.GetSprite(newSpriteName);
		}
		if (!(slot.Attachment is RegionAttachment regionAttachment))
		{
			return;
		}
		AtlasRegion atlasRegion = regionAttachment.RendererObject as AtlasRegion;
		Rect rectA = default(Rect);
		rectA.x = atlasRegion.x;
		rectA.y = atlasRegion.page.height - atlasRegion.y - atlasRegion.height;
		rectA.width = atlasRegion.width;
		rectA.height = atlasRegion.height;
		if (sprite != null)
		{
			if (sprite.packed)
			{
				ReplaceTextureRegion(textureA, rectA, sprite.texture, sprite.textureRect);
			}
			else
			{
				ReplaceTextureRegion(textureA, rectA, sprite.texture, sprite.rect);
			}
		}
		else
		{
			regionAttachment.SetColor(new Color(0f, 0f, 0f, 0f));
			Debug.LogWarning("not found spriteB : " + newSpriteName);
		}
		skeletonAnimation.gameObject.GetComponent<MeshRenderer>().material.mainTexture = textureA;
		slot.A = 1f;
		skinData[slotNameToReplace] = newSpriteName;
	}

	private static void ModifyTextureImage(Texture2D textureA, SkeletonGraphic skeletonGraphic, string slotNameToReplace, string newSpriteName)
	{
		Slot slot = skeletonGraphic.Skeleton.FindSlot(slotNameToReplace);
		if (slot == null)
		{
			return;
		}
		Sprite sprite = CommonSpriteAtlas.GetSprite(newSpriteName);
		if (sprite == null)
		{
			if (skeletonGraphic.name == "IconSkin" || skeletonGraphic.name.Equals("body_top"))
			{
				sprite = TopSpriteAtlas.GetSprite(newSpriteName);
			}
			else if (skeletonGraphic.name == "body_left")
			{
				sprite = LeftSpriteAtlas.GetSprite(newSpriteName);
			}
			else if (skeletonGraphic.name == "body_back")
			{
				sprite = BackSpriteAtlas.GetSprite(newSpriteName);
			}
		}
		if (!(slot.Attachment is RegionAttachment regionAttachment))
		{
			return;
		}
		AtlasRegion atlasRegion = regionAttachment.RendererObject as AtlasRegion;
		Rect rectA = default(Rect);
		rectA.x = atlasRegion.x;
		rectA.y = atlasRegion.page.height - atlasRegion.y - atlasRegion.height;
		rectA.width = atlasRegion.width;
		rectA.height = atlasRegion.height;
		if (sprite == null)
		{
			sprite = TopSpriteAtlas.GetSprite(newSpriteName);
		}
		if (sprite == null)
		{
			sprite = LeftSpriteAtlas.GetSprite(newSpriteName);
		}
		if (sprite == null)
		{
			sprite = BackSpriteAtlas.GetSprite(newSpriteName);
		}
		if (sprite != null)
		{
			if (sprite.packed)
			{
				ReplaceTextureRegion(textureA, rectA, sprite.texture, sprite.textureRect);
			}
			else
			{
				ReplaceTextureRegion(textureA, rectA, sprite.texture, sprite.rect);
			}
		}
		else
		{
			regionAttachment.SetColor(new Color(0f, 0f, 0f, 0f));
			Debug.LogWarning("not found spriteB : " + newSpriteName);
		}
		Material materialForRendering = skeletonGraphic.materialForRendering;
		materialForRendering.mainTexture = textureA;
		skeletonGraphic.canvasRenderer.SetMaterial(materialForRendering, textureA);
		slot.A = 1f;
	}

	private static Texture2D CreateSkeletonTexture(Texture2D textureTemplate)
	{
		byte[] rawTextureData = textureTemplate.GetRawTextureData();
		Texture2D texture2D = new Texture2D(textureTemplate.width, textureTemplate.height, textureTemplate.format, textureTemplate.mipmapCount > 1);
		texture2D.name = textureTemplate.name;
		texture2D.LoadRawTextureData(rawTextureData);
		texture2D.filterMode = FilterMode.Point;
		texture2D.Apply(updateMipmaps: false);
		return texture2D;
	}

	private static SkeletonDataAsset CreateSkeletonDataAsset(TextAsset skeletonJson, Texture2D texture2D, TextAsset atlasText)
	{
		SpineAtlasAsset spineAtlasAsset = ScriptableObject.CreateInstance<SpineAtlasAsset>();
		spineAtlasAsset.atlasFile = atlasText;
		Material material = new Material(Shader.Find("Sprites/Default"));
		material.mainTexture = texture2D;
		spineAtlasAsset.materials = new Material[1] { material };
		return SkeletonDataAsset.CreateRuntimeInstance(skeletonJson, spineAtlasAsset, initialize: false);
	}

	private static void ReplaceTextureRegion(Texture2D textureA, Rect rectA, Texture2D textureB, Rect rectB)
	{
		Color[] colors = new Color[(int)(rectA.width * rectA.height)];
		textureA.SetPixels((int)rectA.x, (int)rectA.y, (int)rectA.width, (int)rectA.height, colors);
		Color[] pixels = textureB.GetPixels((int)rectB.x, (int)rectB.y, (int)rectB.width, (int)rectB.height);
		textureA.SetPixels((int)rectA.x, (int)rectA.y, (int)rectB.width, (int)rectB.height, pixels);
		textureA.Apply(updateMipmaps: false);
	}

	public static void ModifySkin(GameObject obj, string slotName, string skinName)
	{
		if (!isInit)
		{
			Init();
		}
		Dictionary<string, SkeletonAnimation> dictionary = new Dictionary<string, SkeletonAnimation>();
		Dictionary<string, Texture2D> dictionary2 = new Dictionary<string, Texture2D>();
		dictionary.Add("body_top", obj.transform.Find("body_top").GetComponent<SkeletonAnimation>());
		dictionary.Add("body_left", obj.transform.Find("body_left").GetComponent<SkeletonAnimation>());
		dictionary.Add("body_back", obj.transform.Find("body_back").GetComponent<SkeletonAnimation>());
		dictionary2.Add("body_top", dictionary["body_top"].GetComponent<MeshRenderer>().materials[0].mainTexture as Texture2D);
		dictionary2.Add("body_left", dictionary["body_left"].GetComponent<MeshRenderer>().materials[0].mainTexture as Texture2D);
		dictionary2.Add("body_back", dictionary["body_back"].GetComponent<MeshRenderer>().materials[0].mainTexture as Texture2D);
		foreach (KeyValuePair<string, SkeletonAnimation> item in dictionary)
		{
			Slot slot = item.Value.skeleton.FindSlot(slotName);
			if (slot != null)
			{
				slot.A = 1f;
				(slot.Attachment as RegionAttachment).SetColor(new Color(1f, 1f, 1f, 1f));
			}
		}
		foreach (KeyValuePair<string, Texture2D> item2 in dictionary2)
		{
			ModifyTextureImage(item2.Value, dictionary[item2.Key], slotName, skinName);
		}
	}
}
