using System.Collections.Generic;
using MessagePack;

[MessagePackObject(false)]
public class StatsAchievementAtlas
{
	[Key(0)]
	public List<StatsAndAchievementsData> statsAndAchievementsDataList = new List<StatsAndAchievementsData>();

	[Key(1)]
	public List<UnlockAtlasItem> UnlockAtlasList = new List<UnlockAtlasItem>();
}
