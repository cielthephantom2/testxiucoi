using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

[DisallowMultipleComponent]
public class BiliSDKManager : MonoBehaviour
{
	[Serializable]
	public struct Message
	{
		public string message;

		public string msgdetails;

		public string access_key;

		public string game_id;

		public int uid;

		public string uname;
	}

	public struct SzData
	{
		public int code;

		public Message data;
	}

	public delegate void LoginCallBack(string buf, int buflen);

	public delegate void AntiAddictionCallBack(string buf, int buflen);

	public delegate bool WNDENUMPROC(IntPtr hwnd, uint lParam);

	protected static BiliSDKManager s_instance;

	protected bool m_bInitialized;

	protected int m_SDKState = -1;

	private static LoginCallBack loginCallBack;

	private static AntiAddictionCallBack antiAddictionCallBack;

	protected static BiliSDKManager Instance
	{
		get
		{
			if (s_instance == null)
			{
				return new GameObject("BiliSDKManager").AddComponent<BiliSDKManager>();
			}
			return s_instance;
		}
	}

	public static bool Initialized => Instance.m_bInitialized;

	public static int SDKState => Instance.m_SDKState;

	private void Awake()
	{
		Application.targetFrameRate = 60;
		if (s_instance != null)
		{
			UnityEngine.Object.Destroy(base.gameObject);
			return;
		}
		s_instance = this;
		UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
	}

	protected virtual void OnEnable()
	{
		if (s_instance == null)
		{
			s_instance = this;
		}
	}

	protected virtual void OnDestroy()
	{
		if (!(s_instance != this))
		{
			s_instance = null;
			_ = m_bInitialized;
		}
	}

	public void LoginSuccessCallback(string buf, int buflen)
	{
		UnityEngine.Debug.LogWarning("LoginSuccessCallback(): buf(" + buflen + ") = " + buf);
		SzData szData = JsonUtility.FromJson<SzData>(DefaultString(buf));
		if (szData.code == 0 || szData.code == 1)
		{
			antiAddictionCallBack = AntiAddictionResultCallBack;
			string input = "{\"server_id\":\"5265\",\"channel_id\":\"1\",\"ver\":\"10\"}";
			UnityEngine.Debug.LogWarning("Call SDKOpenAntiAddiction().");
			SDKOpenAntiAddiction(UTF8String(input), antiAddictionCallBack);
			m_SDKState = 0;
			m_bInitialized = true;
		}
		else if (szData.code == -2)
		{
			m_SDKState = 99;
		}
	}

	public void AntiAddictionResultCallBack(string buf, int buflen)
	{
		UnityEngine.Debug.LogWarning("AntiAddictionResultCallBack(): buf(" + buflen + ") = " + buf);
		if (JsonUtility.FromJson<SzData>(DefaultString(buf)).code == 1)
		{
			m_SDKState = 99;
		}
	}

	protected virtual void Start()
	{
		loginCallBack = LoginSuccessCallback;
		m_bInitialized = true;
		m_SDKState = 0;
	}

	protected virtual void Update()
	{
		if (m_SDKState == 99)
		{
			m_SDKState = 100;
			Application.Quit();
		}
		else if (m_bInitialized && m_SDKState == 0)
		{
			m_SDKState = 1;
			SceneManager.LoadSceneAsync("BiliLogo");
		}
	}

	[DllImport("PCGameSDK", CallingConvention = CallingConvention.Cdecl)]
	public static extern int SDKInit(string gameID, IntPtr hwndParent);

	[DllImport("PCGameSDK", CallingConvention = CallingConvention.Cdecl)]
	public static extern int SDKShowLoginPanel(string appKey, bool backToLogin, LoginCallBack callBack);

	[DllImport("PCGameSDK", CallingConvention = CallingConvention.Cdecl)]
	public static extern int SDKOpenAntiAddiction(string info, AntiAddictionCallBack callBack);

	[DllImport("PCGameSDK", CallingConvention = CallingConvention.Cdecl)]
	public static extern int SDKLogout();

	[DllImport("user32.dll", SetLastError = true)]
	public static extern bool EnumWindows(WNDENUMPROC lpEnumFunc, uint lParam);

	[DllImport("user32.dll", SetLastError = true)]
	public static extern IntPtr GetParent(IntPtr hWnd);

	[DllImport("user32.dll")]
	public static extern uint GetWindowThreadProcessId(IntPtr hWnd, ref uint lpdwProcessId);

	[DllImport("kernel32.dll")]
	public static extern void SetLastError(uint dwErrCode);

	public static IntPtr GetProcessWnd()
	{
		IntPtr ptrWnd = IntPtr.Zero;
		uint id = (uint)Process.GetCurrentProcess().Id;
		if (EnumWindows(delegate(IntPtr hwnd, uint lParam)
		{
			uint lpdwProcessId = 0u;
			if (GetParent(hwnd) == IntPtr.Zero)
			{
				GetWindowThreadProcessId(hwnd, ref lpdwProcessId);
				if (lpdwProcessId == lParam)
				{
					ptrWnd = hwnd;
					SetLastError(0u);
					return false;
				}
			}
			return true;
		}, id) || Marshal.GetLastWin32Error() != 0)
		{
			return IntPtr.Zero;
		}
		return ptrWnd;
	}

	private string UTF8String(string input)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(input);
		return Encoding.UTF8.GetString(bytes);
	}

	private string DefaultString(string input)
	{
		byte[] bytes = Encoding.Default.GetBytes(input);
		return Encoding.Default.GetString(bytes);
	}
}
