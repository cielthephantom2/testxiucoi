public enum OpenPackageFilter
{
	None = -1,
	Item = 1,
	EquipWeapon = 2,
	EquipArmor = 3,
	EquipAccessory = 4,
	Social = 6,
	EvolutionWG = 8,
	EvolutionEQ = 9
}
