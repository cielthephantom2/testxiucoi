using System.Collections;
using System.Collections.Generic;
using System.Linq;
using SuperScrollView;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class AtlasManagerNewController : MonoBehaviour
{
	public LoopGridView wugongLoopGrid;

	private float wugongItemWidth = 160f;

	public LoopGridView equipLoopGrid;

	private int equipItemColCount = 5;

	public LoopGridView charaLoopGrid;

	private int charaItemColCount = 6;

	private DataSourceMgr<AtlasWugongData> mAtlasWugongDataSourceMgr = new DataSourceMgr<AtlasWugongData>(0);

	private DataSourceMgr<AtlasEquipData> mAtlasEquipDataSourceMgr = new DataSourceMgr<AtlasEquipData>(0);

	private DataSourceMgr<AtlasCharaData> mAtlasCharaDataSourceMgr = new DataSourceMgr<AtlasCharaData>(0);

	private List<AtlasWugongData> mAtlasWugongDataSourceMgr_Filter = new List<AtlasWugongData>();

	private List<AtlasEquipData> mAtlasEquipDataSourceMgr_Filter = new List<AtlasEquipData>();

	private List<AtlasCharaData> mAtlasCharaDataSourceMgr_Filter = new List<AtlasCharaData>();

	private bool exiting;

	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	private GameObject WugongSelBtn;

	private GameObject EquipSelBtn;

	private GameObject CharacterSelBtn;

	[HideInInspector]
	public TMP_InputField SearchArea;

	private Transform WugongAtlas;

	private Transform EquipAtlas;

	private Transform CharatcerAtlas;

	private List<GameObject> m_WugongList = new List<GameObject>();

	private List<GameObject> m_EquipList = new List<GameObject>();

	private List<GameObject> m_CharacterList = new List<GameObject>();

	private List<string> WugongBtnsName = new List<string> { "Sword", "Knife", "Stick", "Hand", "Finger", "Special", "Melody", "Darts", "Skill", "Ultimate" };

	private List<string> EquipBtnsName = new List<string> { "Top10", "Sword", "Knife", "Stick", "Hand", "OtherWeapon", "Gear", "Accessory" };

	private List<string> CharaBtnsName = new List<string> { "20001", "20002", "20003", "20004", "20005", "20006", "20007", "20008", "20009", "20010" };

	private List<GameObject> wugongFilterList = new List<GameObject>();

	private List<GameObject> equipFilterList = new List<GameObject>();

	private List<GameObject> charaFilterList = new List<GameObject>();

	private string wugongFilter = "Wugong||";

	private string equipFilter = "Equip||";

	private string characterFilter = "Chara||";

	public GameObject currentSelectObj;

	private Transform DoingPanel;

	private bool isSearchAreaSelected;

	private bool isOpen;

	private void Start()
	{
		base.transform.Find("Panel").gameObject.SetActive(value: false);
		DoingPanel = base.transform.Find("Panel/DataDoing");
		DoingPanel.gameObject.SetActive(value: true);
		NormalSprite = Resources.Load("images/01-border/boder-20231228-button-02", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		Button[] componentsInChildren = base.transform.Find("Panel/BG").GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		SearchArea = base.transform.Find("Panel/BG/Search").GetComponent<TMP_InputField>();
		WugongAtlas = base.transform.Find("Panel/BG/Wugong");
		EquipAtlas = base.transform.Find("Panel/BG/Equip");
		CharatcerAtlas = base.transform.Find("Panel/BG/Charatcer");
		WugongSelBtn = WugongAtlas.Find("Selecter/WugongAll").gameObject;
		EquipSelBtn = EquipAtlas.Find("Selecter/EquipAll").gameObject;
		CharacterSelBtn = CharatcerAtlas.Find("Selecter/CharatcerAll").gameObject;
		SearchArea.onValueChanged.AddListener(SearchItem);
		SearchArea.onSelect.AddListener(OnInputFieldSelect);
		InitWugongAtlas();
		InitEquipAtlas();
		InitCharaAtlas();
		InitLoopGridViewColumnCount();
		RefreshUnlockCount();
		WugongAtlas.gameObject.SetActive(value: true);
		EquipAtlas.gameObject.SetActive(value: false);
		CharatcerAtlas.gameObject.SetActive(value: false);
	}

	private void InitLoopGridViewColumnCount()
	{
		equipItemColCount = Mathf.FloorToInt((equipLoopGrid.transform.Find("Viewport").GetComponent<RectTransform>().rect.width - (float)equipLoopGrid.Padding.left) / (equipLoopGrid.ItemSize.x + equipLoopGrid.ItemPadding.x));
		equipLoopGrid.SetGridFixedGroupCount(GridFixedType.ColumnCountFixed, equipItemColCount);
		equipLoopGrid.UpdateColumnRowCount();
		charaItemColCount = Mathf.FloorToInt((charaLoopGrid.transform.Find("Viewport").GetComponent<RectTransform>().rect.width - (float)charaLoopGrid.Padding.left) / (charaLoopGrid.ItemSize.x + charaLoopGrid.ItemPadding.x));
		charaLoopGrid.SetGridFixedGroupCount(GridFixedType.ColumnCountFixed, charaItemColCount);
		charaLoopGrid.UpdateColumnRowCount();
	}

	private void RefreshUnlockCount()
	{
		int num = 0;
		foreach (AtlasWugongData item in mAtlasWugongDataSourceMgr_Filter)
		{
			if (item.isUnlock)
			{
				num++;
			}
		}
		WugongAtlas.Find("Info/Count/Text").GetComponent<Text>().text = num + "/" + mAtlasWugongDataSourceMgr_Filter.Count;
		if (mAtlasWugongDataSourceMgr_Filter.Count != 0)
		{
			WugongAtlas.Find("Info/Count").GetComponent<Slider>().value = (float)num / (float)mAtlasWugongDataSourceMgr_Filter.Count;
		}
		else
		{
			WugongAtlas.Find("Info/Count").GetComponent<Slider>().value = 1f;
		}
		num = 0;
		foreach (AtlasEquipData item2 in mAtlasEquipDataSourceMgr_Filter)
		{
			if (item2.isUnlock)
			{
				num++;
			}
		}
		EquipAtlas.Find("Info/Count/Text").GetComponent<Text>().text = num + "/" + mAtlasEquipDataSourceMgr_Filter.Count;
		if (mAtlasEquipDataSourceMgr_Filter.Count != 0)
		{
			EquipAtlas.Find("Info/Count").GetComponent<Slider>().value = (float)num / (float)mAtlasEquipDataSourceMgr_Filter.Count;
		}
		else
		{
			EquipAtlas.Find("Info/Count").GetComponent<Slider>().value = 1f;
		}
		num = 0;
		foreach (AtlasCharaData item3 in mAtlasCharaDataSourceMgr_Filter)
		{
			if (item3.isUnlock)
			{
				num++;
			}
		}
		CharatcerAtlas.Find("Info/Count/Text").GetComponent<Text>().text = num + "/" + mAtlasCharaDataSourceMgr_Filter.Count;
		if (mAtlasCharaDataSourceMgr_Filter.Count != 0)
		{
			CharatcerAtlas.Find("Info/Count").GetComponent<Slider>().value = (float)num / (float)mAtlasCharaDataSourceMgr_Filter.Count;
		}
		else
		{
			CharatcerAtlas.Find("Info/Count").GetComponent<Slider>().value = 1f;
		}
	}

	private void InitWugongAtlas()
	{
		mAtlasWugongDataSourceMgr = new DataSourceMgr<AtlasWugongData>(0);
		for (int i = 1; i <= 10; i++)
		{
			foreach (gang_b03Table.Row row in CommonResourcesData.b03.GetRowList())
			{
				if (row.Star != i.ToString() || row.isAtlas == "0")
				{
					continue;
				}
				List<gang_b07Table.Row> list = CommonResourcesData.b07.FindAll_Relateid(row.ID);
				gang_b07Table.Row b07Row = null;
				foreach (gang_b07Table.Row item in list)
				{
					if (item.Use[8] == '1')
					{
						b07Row = item;
						break;
					}
				}
				if (b07Row == null)
				{
					continue;
				}
				AtlasWugongData atlasWugongData = new AtlasWugongData();
				atlasWugongData.b07Row = b07Row;
				atlasWugongData.b03Row = row;
				atlasWugongData.isUnlock = GameDataManager.Instance().UnlockAtlasList.Find((UnlockAtlasItem x) => x.tableName == "b07" && x.ID == b07Row.ID) != null;
				string level = "";
				string level2 = "";
				switch (row.Style)
				{
				case "101":
				case "201":
				case "301":
				case "401":
				case "501":
				case "601":
				case "701":
				case "801":
				case "1001":
					if (!row.atlasType.Contains('_'))
					{
						continue;
					}
					level = row.atlasType.Split('_')[0];
					level2 = row.atlasType.Split('_')[1];
					break;
				case "901":
				case "9101":
				case "9301":
				case "9401":
				case "9501":
					level = "Skill";
					if (row.Style == "901")
					{
						level2 = "Inner";
					}
					else if (row.Style == "9501")
					{
						level2 = "Lightness";
					}
					else if (row.Style == "9101")
					{
						level2 = "Formation";
					}
					else if (row.Style == "9301")
					{
						level2 = "Assist";
					}
					else if (row.Style == "9401")
					{
						level2 = "Recipe";
					}
					break;
				case "9601":
					level = "Ultimate";
					break;
				}
				string name_Trans = row.Name_Trans;
				atlasWugongData.level1 = level;
				atlasWugongData.level2 = level2;
				atlasWugongData.level3 = name_Trans;
				mAtlasWugongDataSourceMgr.AppendData(atlasWugongData);
			}
		}
		mAtlasWugongDataSourceMgr_Filter = mAtlasWugongDataSourceMgr.GetFilteredItemList("");
		wugongItemWidth = wugongLoopGrid.transform.Find("Viewport").GetComponent<RectTransform>().rect.width - (float)wugongLoopGrid.Padding.left - (float)wugongLoopGrid.Padding.right;
		wugongLoopGrid.InitGridView(mAtlasWugongDataSourceMgr_Filter.Count, OnGetWugongItemByRowColumn);
	}

	private void InitEquipAtlas()
	{
		mAtlasEquipDataSourceMgr = new DataSourceMgr<AtlasEquipData>(0);
		List<string> list = CommonResourcesData.b10.Find_ID("10001").Members.Split("|").ToList();
		foreach (gang_b02Table.Row row in CommonResourcesData.b02.GetRowList())
		{
			if (row.isAtlas == "0")
			{
				continue;
			}
			List<gang_b07Table.Row> list2 = CommonResourcesData.b07.FindAll_Relateid(row.ID);
			gang_b07Table.Row b07Row = null;
			foreach (gang_b07Table.Row item in list2)
			{
				if (item.Use[2] == '1' || item.Use[3] == '1' || item.Use[4] == '1')
				{
					b07Row = item;
					break;
				}
			}
			if (b07Row == null)
			{
				continue;
			}
			AtlasEquipData atlasEquipData = new AtlasEquipData();
			atlasEquipData.isUnlock = GameDataManager.Instance().UnlockAtlasList.Find((UnlockAtlasItem x) => x.tableName == "b07" && x.ID == b07Row.ID) != null;
			atlasEquipData.b07Row = b07Row;
			atlasEquipData.b02Row = row;
			string level = "";
			string level2 = "";
			switch (row.Style)
			{
			case "1":
				switch (row.atlasType)
				{
				case "1":
					level = "Sword";
					break;
				case "2":
					level = "Knife";
					break;
				case "3":
					level = "Stick";
					break;
				case "4":
					level = "Hand";
					break;
				case "5":
					level = "OtherWeapon";
					break;
				}
				break;
			case "2":
				level = "Gear";
				break;
			case "3":
				level = "Accessory";
				break;
			}
			if (list.Contains(row.ID))
			{
				level = "Top10";
			}
			string name_Trans = b07Row.Name_Trans;
			atlasEquipData.level1 = level;
			atlasEquipData.level2 = level2;
			atlasEquipData.level3 = name_Trans;
			mAtlasEquipDataSourceMgr.AppendData(atlasEquipData);
		}
		mAtlasEquipDataSourceMgr_Filter = mAtlasEquipDataSourceMgr.GetFilteredItemList("");
		equipLoopGrid.InitGridView(mAtlasEquipDataSourceMgr_Filter.Count, OnGetEquipItemByRowColumn);
	}

	private void InitCharaAtlas()
	{
		mAtlasCharaDataSourceMgr = new DataSourceMgr<AtlasCharaData>(0);
		List<gang_b10Table.Row> list = new List<gang_b10Table.Row>();
		for (int i = 20001; i <= 20010; i++)
		{
			list.Add(CommonResourcesData.b10.Find_ID(i.ToString()));
		}
		foreach (gang_b01Table.Row b01Row in CommonResourcesData.b01.GetRowList())
		{
			if (b01Row.isAtlas == "0" || list.Find((gang_b10Table.Row x) => x.Members.Split("|").ToList().Contains(b01Row.ID)) == null)
			{
				continue;
			}
			AtlasCharaData atlasCharaData = new AtlasCharaData();
			atlasCharaData.isUnlock = GameDataManager.Instance().UnlockAtlasList.Find((UnlockAtlasItem x) => x.tableName == "b01" && x.ID == b01Row.ID) != null;
			atlasCharaData.b01Row = b01Row;
			string iD = b01Row.ID;
			string text = "";
			string name_Trans = b01Row.Name_Trans;
			foreach (gang_b10Table.Row item in list)
			{
				if (item.Members.Split("|").ToList().Contains(b01Row.ID))
				{
					text = text + item.ID + "&";
				}
			}
			atlasCharaData.level1 = iD;
			atlasCharaData.level2 = text;
			atlasCharaData.level3 = name_Trans;
			mAtlasCharaDataSourceMgr.AppendData(atlasCharaData);
		}
		mAtlasCharaDataSourceMgr_Filter = mAtlasCharaDataSourceMgr.GetFilteredItemList("");
		charaLoopGrid.InitGridView(mAtlasCharaDataSourceMgr_Filter.Count, OnGetCharaItemByRowColumn);
	}

	private LoopGridViewItem OnGetWugongItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		AtlasWugongData atlasWugongData = mAtlasWugongDataSourceMgr_Filter[index];
		if (atlasWugongData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("AtlasWuGongBtn");
		loopGridViewItem.GetComponent<RectTransform>().sizeDelta = new Vector2(wugongItemWidth, wugongLoopGrid.ItemSize.y);
		AtlasWuGongBtn component = loopGridViewItem.GetComponent<AtlasWuGongBtn>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		component.Init(atlasWugongData);
		return loopGridViewItem;
	}

	private LoopGridViewItem OnGetEquipItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		AtlasEquipData atlasEquipData = mAtlasEquipDataSourceMgr_Filter[index];
		if (atlasEquipData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("AtlasEquipBtn");
		AtlasEquipBtn component = loopGridViewItem.GetComponent<AtlasEquipBtn>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		component.Init(atlasEquipData);
		return loopGridViewItem;
	}

	private LoopGridViewItem OnGetCharaItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		AtlasCharaData atlasCharaData = mAtlasCharaDataSourceMgr_Filter[index];
		if (atlasCharaData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("AtlasCharaBtn");
		AtlasCharaBtn component = loopGridViewItem.GetComponent<AtlasCharaBtn>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		component.Init(atlasCharaData);
		return loopGridViewItem;
	}

	public void OpenAtlas()
	{
		SharedData.Instance().IsViewOpen = true;
		StartCoroutine(OpenAtlasIE());
	}

	private IEnumerator OpenAtlasIE()
	{
		base.transform.Find("Panel").gameObject.SetActive(value: true);
		DoingPanel.gameObject.SetActive(value: true);
		RefreshUnLockInfo();
		Filter();
		DoingPanel.gameObject.SetActive(value: false);
		if (currentSelectObj != null)
		{
			EventSystem.current.SetSelectedGameObject(currentSelectObj);
		}
		else
		{
			EventSystem.current.SetSelectedGameObject(WugongSelBtn);
		}
		isOpen = true;
		RefreshUnlockCount();
		SharedData.Instance().LoadSceneStackAdd("Atlas");
		yield return null;
	}

	private void RefreshUnLockInfo()
	{
		foreach (AtlasWugongData wugongItem in mAtlasWugongDataSourceMgr.ItemDataList)
		{
			if (!wugongItem.isUnlock)
			{
				wugongItem.isUnlock = GameDataManager.Instance().UnlockAtlasList.Find((UnlockAtlasItem x) => x.tableName == "b07" && x.ID == wugongItem.b07Row.ID) != null;
			}
		}
		foreach (AtlasEquipData equipItem in mAtlasEquipDataSourceMgr.ItemDataList)
		{
			if (!equipItem.isUnlock)
			{
				equipItem.isUnlock = GameDataManager.Instance().UnlockAtlasList.Find((UnlockAtlasItem x) => x.tableName == "b07" && x.ID == equipItem.b07Row.ID) != null;
			}
		}
		foreach (AtlasCharaData charaItem in mAtlasCharaDataSourceMgr.ItemDataList)
		{
			if (!charaItem.isUnlock)
			{
				charaItem.isUnlock = GameDataManager.Instance().UnlockAtlasList.Find((UnlockAtlasItem x) => x.tableName == "b01" && x.ID == charaItem.b01Row.ID) != null;
			}
		}
	}

	public void CloseAtlas()
	{
		base.transform.Find("Panel").gameObject.SetActive(value: false);
		CommonFunc.CloseHover();
		DoingPanel.gameObject.SetActive(value: true);
		SharedData.Instance().IsViewOpen = false;
		isOpen = false;
		SharedData.Instance().LoadSceneStackRemove("Atlas");
	}

	private void LateUpdate()
	{
		if (!isOpen || CommonFunc.IsHoverOpen())
		{
			return;
		}
		if (!SearchArea.isFocused && InputSystemCustom.Instance().UI.AtlasNext.WasReleasedThisFrame())
		{
			PointerEventData eventData = new PointerEventData(EventSystem.current);
			if (WugongAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/EquipPanel").gameObject, eventData, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/EquipPanel").gameObject);
			}
			else if (EquipAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/CharacterPanel").gameObject, eventData, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/CharacterPanel").gameObject);
			}
			else if (CharatcerAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/WugongPanel").gameObject, eventData, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/WugongPanel").gameObject);
			}
		}
		else if (!SearchArea.isFocused && InputSystemCustom.Instance().UI.AtlasPrev.WasReleasedThisFrame())
		{
			PointerEventData eventData2 = new PointerEventData(EventSystem.current);
			if (WugongAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/CharacterPanel").gameObject, eventData2, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/CharacterPanel").gameObject);
			}
			else if (EquipAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/WugongPanel").gameObject, eventData2, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/WugongPanel").gameObject);
			}
			else if (CharatcerAtlas.gameObject.activeInHierarchy)
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Title/EquipPanel").gameObject, eventData2, ExecuteEvents.pointerClickHandler);
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/BG/Title/EquipPanel").gameObject);
			}
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			if (isSearchAreaSelected)
			{
				SearchArea.DeactivateInputField();
				isSearchAreaSelected = false;
			}
			else
			{
				PointerEventData eventData3 = new PointerEventData(EventSystem.current);
				ExecuteEvents.Execute(base.transform.Find("Panel/BG/Return").gameObject, eventData3, ExecuteEvents.pointerClickHandler);
			}
		}
	}

	private void OnButtonClick(GameObject go)
	{
		if (exiting || go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || CommonFunc.IsHoverOpen())
		{
			return;
		}
		if (go.name.Equals("Return") && !exiting)
		{
			exiting = true;
			CloseAtlas();
			if (SharedData.Instance().m_titleController != null)
			{
				SharedData.Instance().m_titleController.GetComponent<CanvasGroup>().interactable = true;
				CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
			}
			exiting = false;
			return;
		}
		if (go.name.Equals("WugongPanel"))
		{
			WugongAtlas.gameObject.SetActive(value: true);
			EquipAtlas.gameObject.SetActive(value: false);
			CharatcerAtlas.gameObject.SetActive(value: false);
			Filter();
		}
		else if (go.name.Equals("EquipPanel"))
		{
			WugongAtlas.gameObject.SetActive(value: false);
			EquipAtlas.gameObject.SetActive(value: true);
			CharatcerAtlas.gameObject.SetActive(value: false);
			Filter();
		}
		else if (go.name.Equals("CharacterPanel"))
		{
			WugongAtlas.gameObject.SetActive(value: false);
			EquipAtlas.gameObject.SetActive(value: false);
			CharatcerAtlas.gameObject.SetActive(value: true);
			Filter();
		}
		else if (go.name.Equals("WugongAll"))
		{
			wugongFilter = "Wugong||";
			WugongSelBtn.GetComponent<Image>().sprite = NormalSprite;
			go.GetComponent<Image>().sprite = SelectedSprite;
			WugongSelBtn = go;
			Filter();
		}
		else if (go.name.Equals("EquipAll"))
		{
			equipFilter = "Equip||";
			EquipSelBtn.GetComponent<Image>().sprite = NormalSprite;
			go.GetComponent<Image>().sprite = SelectedSprite;
			EquipSelBtn = go;
			Filter();
		}
		else if (go.name.Equals("CharatcerAll"))
		{
			characterFilter = "Chara||";
			CharacterSelBtn.GetComponent<Image>().sprite = NormalSprite;
			go.GetComponent<Image>().sprite = SelectedSprite;
			CharacterSelBtn = go;
			Filter();
		}
		else if (WugongAtlas.gameObject.activeInHierarchy)
		{
			string[] array = go.name.Split("_");
			if (WugongBtnsName.Contains(array[0]))
			{
				string text = "";
				if (array.Length == 1)
				{
					Transform transform = go.transform.parent.Find(array[0] + "Body");
					transform.gameObject.SetActive(!transform.gameObject.activeInHierarchy);
				}
				else
				{
					text = array[1];
				}
				wugongFilter = "Wugong|" + array[0] + "|" + text;
				WugongSelBtn.GetComponent<Image>().sprite = NormalSprite;
				go.GetComponent<Image>().sprite = SelectedSprite;
				WugongSelBtn = go;
			}
			Filter();
		}
		else if (EquipAtlas.gameObject.activeInHierarchy)
		{
			if (EquipBtnsName.Contains(go.name))
			{
				equipFilter = "Equip|" + go.name + "|";
			}
			EquipSelBtn.GetComponent<Image>().sprite = NormalSprite;
			go.GetComponent<Image>().sprite = SelectedSprite;
			EquipSelBtn = go;
			Filter();
		}
		else if (CharatcerAtlas.gameObject.activeInHierarchy)
		{
			if (CharaBtnsName.Contains(go.name))
			{
				characterFilter = "Chara|" + go.name + "|";
			}
			CharacterSelBtn.GetComponent<Image>().sprite = NormalSprite;
			go.GetComponent<Image>().sprite = SelectedSprite;
			CharacterSelBtn = go;
			Filter();
		}
		if (!go.name.Equals("Return"))
		{
			currentSelectObj = go;
		}
	}

	private void SearchItem(string _input)
	{
		Filter();
	}

	public void SetSearchText(string text)
	{
		SearchArea.text = text;
	}

	private void OnInputFieldSelect(string value)
	{
		isSearchAreaSelected = true;
	}

	private void Filter()
	{
		string text = SearchArea.text;
		if (WugongAtlas.gameObject.activeInHierarchy)
		{
			string filterStr = wugongFilter + "|" + text;
			mAtlasWugongDataSourceMgr_Filter = mAtlasWugongDataSourceMgr.GetFilteredItemList(filterStr);
			wugongLoopGrid.SetListItemCount(mAtlasWugongDataSourceMgr_Filter.Count, resetPos: false);
			wugongLoopGrid.RefreshAllShownItem();
		}
		else if (EquipAtlas.gameObject.activeInHierarchy)
		{
			string filterStr2 = equipFilter + "|" + text;
			mAtlasEquipDataSourceMgr_Filter = mAtlasEquipDataSourceMgr.GetFilteredItemList(filterStr2);
			equipLoopGrid.SetListItemCount(mAtlasEquipDataSourceMgr_Filter.Count, resetPos: false);
			equipLoopGrid.RefreshAllShownItem();
		}
		else if (CharatcerAtlas.gameObject.activeInHierarchy)
		{
			string filterStr3 = characterFilter + "|" + text;
			mAtlasCharaDataSourceMgr_Filter = mAtlasCharaDataSourceMgr.GetFilteredItemList(filterStr3);
			charaLoopGrid.SetListItemCount(mAtlasCharaDataSourceMgr_Filter.Count, resetPos: false);
			charaLoopGrid.RefreshAllShownItem();
		}
	}
}
