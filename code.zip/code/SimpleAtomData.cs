using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class SimpleAtomData
{
	[Key(0)]
	public string id = "";

	[Key(1)]
	public string stringValue = "";

	[Key(2)]
	public float bornValue;

	[Key(3)]
	public float alterValue;

	[Key(4)]
	public float equipValue;

	[Key(5)]
	public float wugongValue;

	[Key(6)]
	public float skillValue;

	[Key(7)]
	public float fightValue;

	[Key(8)]
	public float rollValue;

	[Key(9)]
	public float juqingValue;

	[Key(10)]
	public float levelupValue;

	[Key(11)]
	public float talentValue;
}
