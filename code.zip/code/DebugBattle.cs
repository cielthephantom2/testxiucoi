using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DebugBattle : MonoBehaviour
{
	private bool isInit;

	public GameObject DebugPanel;

	public TMP_Dropdown m_characterDropDown;

	public TMP_InputField m_HpLower;

	public TMP_InputField m_HpUper;

	public TMP_InputField m_MpLower;

	public TMP_InputField m_MpUper;

	public TMP_InputField m_AtkLower;

	public TMP_InputField m_AtkUper;

	public TMP_InputField m_DefLower;

	public TMP_InputField m_DefUper;

	public TMP_Text m_characterAtkValue;

	public TMP_Text m_characteDefValue;

	public TMP_Text m_characterMpDefValue;

	public TMP_Text m_characterTotalDefValue;

	public Button m_Save;

	public Button m_Reset;

	public Button m_AddWuGong;

	public Transform m_WuGongListContent;

	private int m_HpLowerValue;

	private int m_HpUperValue;

	private int m_MpLowerValue;

	private int m_MpUperValue;

	private int m_AtkLowerValue;

	private int m_AtkUperValue;

	private int m_DefLowerValue;

	private int m_DefUperValue;

	private int currentIndex;

	private float characterAtkValue;

	private float characteDefValue;

	private float characterMpDefValue;

	private float characterTotalDefValue;

	private List<string> wugongIdList = new List<string>();

	private List<int> wugongLevelList = new List<int>();

	private GameObject m_WugongItemPrefab;

	private List<WuGongItemInit> wugonglist = new List<WuGongItemInit>();

	private void Start()
	{
		m_WugongItemPrefab = (GameObject)Resources.Load("Prefabs/DebugBattle/WugongItem");
		m_characterDropDown.onValueChanged.AddListener(delegate
		{
			OnChangeCharacter(m_characterDropDown);
		});
	}

	private void OnChangeCharacter(TMP_Dropdown _dropDown)
	{
		if (_dropDown.name == "CharacterList")
		{
			currentIndex = _dropDown.value;
			Debug.Log("New CharacterList Value : " + _dropDown.value);
			SharedData.Instance().m_BattleController.m_curcor.transform.position = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].transform.position;
			InitUIInfo();
		}
		UpDateCalInfo();
	}

	private void Update()
	{
		if (isInit)
		{
			GetUIInfo();
			UpDateCalInfo();
		}
	}

	public void OnClickDebug()
	{
		SharedData.Instance().debugBattle = this;
		DebugPanel.SetActive(!DebugPanel.activeInHierarchy);
		if (DebugPanel.activeInHierarchy)
		{
			Time.timeScale = 0f;
			InitDebugBattle();
			return;
		}
		Time.timeScale = 1f;
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			if (allBattleObj.race == "enemy")
			{
				allBattleObj.isDead = true;
			}
		}
	}

	public void OnClickSave()
	{
		Debug.Log("Todo:修改角色数据");
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.Indexs_Name["HP"].bornValue = int.Parse(m_HpLower.text);
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.m_Hp = int.Parse(m_HpLower.text);
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.Indexs_Name["MP"].bornValue = int.Parse(m_MpLower.text);
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.m_Mp = int.Parse(m_MpLower.text);
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.Indexs_Name["ATK"].bornValue = int.Parse(m_AtkLower.text);
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.Indexs_Name["DEF"].bornValue = int.Parse(m_DefLower.text);
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].m_SkillList.Clear();
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.m_KongFuList.Clear();
		SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.m_KongFuListInBattle.Clear();
		wugonglist = m_WuGongListContent.GetComponentsInChildren<WuGongItemInit>().ToList();
		foreach (WuGongItemInit item in wugonglist)
		{
			gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(item.ID);
			SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].m_SkillList.Add(row.ID + "|" + row.Attckstyle + "|" + item.LV + "|MP-GOOD");
			KongFuData kongFuData = new KongFuData();
			kongFuData.kf = row;
			kongFuData.lv = item.LV;
			kongFuData.exp = 0f;
			kongFuData.proficiency = 0;
			SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.KongFuListAdd(kongFuData);
		}
	}

	public void OnClickReset()
	{
		InitUIInfo();
		UpDateCalInfo();
	}

	public void OnClickAddWuGong()
	{
		wugonglist = m_WuGongListContent.GetComponentsInChildren<WuGongItemInit>().ToList();
		if (!(SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.originRace == "enemy") || wugonglist.Count <= 5)
		{
			WuGongItemInit component = Object.Instantiate(m_WugongItemPrefab, m_WuGongListContent.transform).GetComponent<WuGongItemInit>();
			component.ID = "";
			component.LV = 0;
			component.Init();
			wugonglist.Add(component);
		}
	}

	public void InitDebugBattle()
	{
		if (isInit)
		{
			return;
		}
		m_characterDropDown.ClearOptions();
		List<string> list = new List<string>();
		foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
		{
			list.Add(allBattleObj.name);
		}
		m_characterDropDown.AddOptions(list);
		OnChangeCharacter(m_characterDropDown);
		isInit = true;
	}

	public void GetUIInfo()
	{
		if (m_HpLower.text != "")
		{
			m_HpLowerValue = int.Parse(m_HpLower.text);
		}
		if (m_HpUper.text != "")
		{
			m_HpUperValue = int.Parse(m_HpUper.text);
		}
		if (m_MpLower.text != "")
		{
			m_MpLowerValue = int.Parse(m_MpLower.text);
		}
		if (m_MpUper.text != "")
		{
			m_MpUperValue = int.Parse(m_MpUper.text);
		}
		if (m_AtkLower.text != "")
		{
			m_AtkLowerValue = int.Parse(m_AtkLower.text);
		}
		if (m_AtkUper.text != "")
		{
			m_AtkUperValue = int.Parse(m_AtkUper.text);
		}
		if (m_DefLower.text != "")
		{
			m_DefLowerValue = int.Parse(m_DefLower.text);
		}
		if (m_DefUper.text != "")
		{
			m_DefUperValue = int.Parse(m_DefUper.text);
		}
	}

	public void InitUIInfo()
	{
		m_HpLower.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("HP").ToString();
		m_HpUper.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("HP").ToString();
		m_MpLower.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("MP").ToString();
		m_MpUper.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("MP").ToString();
		m_AtkLower.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("ATK").ToString();
		m_AtkUper.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("ATK").ToString();
		m_DefLower.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("DEF").ToString();
		m_DefUper.text = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.GetBattleValueByName("DEF").ToString();
		wugongIdList.Clear();
		wugongLevelList.Clear();
		while (wugonglist.Count > 0)
		{
			if (wugonglist[0] != null && wugonglist[0].gameObject != null)
			{
				Object.Destroy(wugonglist[0].gameObject);
			}
			wugonglist.RemoveAt(0);
		}
		foreach (string skill in SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].m_SkillList)
		{
			string[] array = skill.Split('|');
			wugongIdList.Add(array[0]);
			wugongLevelList.Add(int.Parse(array[4]));
		}
		for (int i = 0; i < wugongIdList.Count; i++)
		{
			WuGongItemInit component = Object.Instantiate(m_WugongItemPrefab, m_WuGongListContent.transform).GetComponent<WuGongItemInit>();
			component.ID = wugongIdList[i];
			component.LV = wugongLevelList[i];
			component.Init();
			wugonglist.Add(component);
		}
		GetUIInfo();
		bool interactable = SharedData.Instance().m_BattleController.allBattleObjs[currentIndex].charadata.originRace != "player";
		m_HpLower.interactable = interactable;
		m_HpUper.interactable = interactable;
		m_MpLower.interactable = interactable;
		m_MpUper.interactable = interactable;
		m_AtkLower.interactable = interactable;
		m_AtkUper.interactable = interactable;
		m_DefLower.interactable = interactable;
		m_DefUper.interactable = interactable;
		foreach (WuGongItemInit item in wugonglist)
		{
			item.m_wugongDropdow.interactable = interactable;
			item.m_wugongLV.interactable = interactable;
			item.m_MinusWuGong.interactable = interactable;
		}
		m_Save.interactable = interactable;
		m_Reset.interactable = interactable;
		m_AddWuGong.interactable = interactable;
	}

	public void UpDateCalInfo()
	{
		characterAtkValue = (float)m_AtkLowerValue + (float)m_MpLowerValue / 10f;
		characteDefValue = (float)m_DefLowerValue / 12.5f;
		characterMpDefValue = (float)m_MpLowerValue / 65f;
		characterTotalDefValue = 1f + (characteDefValue + characterMpDefValue) / 10f;
		m_characterAtkValue.text = characterAtkValue.ToString();
		m_characteDefValue.text = characteDefValue.ToString();
		m_characterMpDefValue.text = characterMpDefValue.ToString();
		m_characterTotalDefValue.text = characterTotalDefValue.ToString();
	}
}
