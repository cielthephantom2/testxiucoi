using UnityEngine;

public class InitLoading : MonoBehaviour
{
}
