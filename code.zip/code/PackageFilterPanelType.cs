internal enum PackageFilterPanelType
{
	All,
	Consum,
	Wugong,
	Equip
}
