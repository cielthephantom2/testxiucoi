using System.Collections.Generic;
using MessagePack;
using UnityEngine;

public class gang_b01SkinTable
{
	[MessagePackObject(false)]
	public class Row
	{
		[Key(0)]
		public string ID = "";

		[Key(1)]
		public string Name = "";

		[Key(2)]
		public string Name_Id = "";

		[Key(3)]
		public string model = "";

		[Key(4)]
		public string Clothes = "";

		[Key(5)]
		public string Head = "";

		[Key(6)]
		public string HeadOther = "";

		[Key(7)]
		public string Eyes = "";

		[Key(8)]
		public string HandLeft = "";

		[Key(9)]
		public string HandRight = "";

		[Key(10)]
		public string SleeveLeft = "";

		[Key(11)]
		public string SleeveRight = "";

		[Key(12)]
		public string LegLeft = "";

		[Key(13)]
		public string LegRight = "";

		[Key(14)]
		public string CloakBack = "";

		[Key(15)]
		public string CloakFront = "";

		[Key(16)]
		public string EyesBeHit = "";

		[Key(17)]
		public string HairBack = "";

		[Key(18)]
		public string HairFront = "";

		[Key(19)]
		public string Hat = "";

		[Key(20)]
		public string HandLeftItem = "";

		[Key(21)]
		public string HandLeftWeapon = "";

		[Key(22)]
		public string HandRightItem = "";

		[Key(23)]
		public string HandRightWeapon = "";

		[Key(24)]
		public string WeaponBack = "";

		[Key(25)]
		public string WeaponBack2 = "";

		[Key(26)]
		public string BackPack = "";

		[Key(27)]
		public string weapon_sword = "";

		[Key(28)]
		public string weapon_knife = "";

		[Key(29)]
		public string weapon_stick = "";

		[Key(30)]
		public string FaceMask = "";

		[Key(31)]
		public string Bread = "";
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Name = list[i][num++],
				Name_Id = list[i][num++],
				model = list[i][num++],
				Clothes = list[i][num++],
				Head = list[i][num++],
				FaceMask = list[i][num++],
				Bread = list[i][num++],
				HeadOther = list[i][num++],
				Eyes = list[i][num++],
				HandLeft = list[i][num++],
				HandRight = list[i][num++],
				SleeveLeft = list[i][num++],
				SleeveRight = list[i][num++],
				LegLeft = list[i][num++],
				LegRight = list[i][num++],
				CloakBack = list[i][num++],
				CloakFront = list[i][num++],
				EyesBeHit = list[i][num++],
				HairBack = list[i][num++],
				HairFront = list[i][num++],
				Hat = list[i][num++],
				HandLeftItem = list[i][num++],
				HandLeftWeapon = list[i][num++],
				HandRightItem = list[i][num++],
				HandRightWeapon = list[i][num++],
				WeaponBack = list[i][num++],
				WeaponBack2 = list[i][num++],
				BackPack = list[i][num++],
				weapon_sword = list[i][num++],
				weapon_knife = list[i][num++],
				weapon_stick = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}
}
