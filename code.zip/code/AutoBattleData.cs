public class AutoBattleData
{
}
