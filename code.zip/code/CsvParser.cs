using System.Collections.Generic;
using System.IO;
using System.Text;

public class CsvParser
{
	private abstract class ParserState
	{
		public static readonly LineStartState LineStartState = new LineStartState();

		public static readonly ValueStartState ValueStartState = new ValueStartState();

		public static readonly ValueState ValueState = new ValueState();

		public static readonly QuotedValueState QuotedValueState = new QuotedValueState();

		public static readonly QuoteState QuoteState = new QuoteState();

		public abstract ParserState AnyChar(char ch, ParserContext context);

		public abstract ParserState Comma(ParserContext context);

		public abstract ParserState Quote(ParserContext context);

		public abstract ParserState EndOfLine(ParserContext context);
	}

	private class LineStartState : ParserState
	{
		public override ParserState AnyChar(char ch, ParserContext context)
		{
			context.AddChar(ch);
			return ParserState.ValueState;
		}

		public override ParserState Comma(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher = 0;
			context.AddValue();
			return ParserState.ValueStartState;
		}

		public override ParserState Quote(ParserContext context)
		{
			return ParserState.QuotedValueState;
		}

		public override ParserState EndOfLine(ParserContext context)
		{
			context.AddLine();
			return ParserState.LineStartState;
		}
	}

	private class ValueStartState : LineStartState
	{
		public override ParserState EndOfLine(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher = 0;
			context.AddValue();
			context.AddLine();
			return ParserState.LineStartState;
		}
	}

	private class ValueState : ParserState
	{
		public override ParserState AnyChar(char ch, ParserContext context)
		{
			context.AddChar(ch);
			return ParserState.ValueState;
		}

		public override ParserState Comma(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher = 0;
			context.AddValue();
			return ParserState.ValueStartState;
		}

		public override ParserState Quote(ParserContext context)
		{
			context.AddChar('"');
			return ParserState.ValueState;
		}

		public override ParserState EndOfLine(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher = 0;
			context.AddValue();
			context.AddLine();
			return ParserState.LineStartState;
		}
	}

	private class QuotedValueState : ParserState
	{
		public override ParserState AnyChar(char ch, ParserContext context)
		{
			context.AddChar(ch);
			return ParserState.QuotedValueState;
		}

		public override ParserState Comma(ParserContext context)
		{
			if (ParserState.QuoteState.quoteSwitcher > 0 && ParserState.QuoteState.quoteSwitcher % 2 == 1)
			{
				if (context.CheckDoubleQuote())
				{
					ParserState.QuoteState.quoteSwitcher = 0;
					context.QuoteValueEnd();
					return ParserState.ValueStartState;
				}
				context.AddChar(',');
				return ParserState.QuotedValueState;
			}
			context.AddChar(',');
			return ParserState.QuotedValueState;
		}

		public override ParserState Quote(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher++;
			context.AddChar('"');
			return ParserState.QuoteState;
		}

		public override ParserState EndOfLine(ParserContext context)
		{
			context.AddChar('\r');
			context.AddChar('\n');
			return ParserState.QuotedValueState;
		}
	}

	private class QuoteState : ParserState
	{
		public int quoteSwitcher;

		public override ParserState AnyChar(char ch, ParserContext context)
		{
			context.AddChar(ch);
			return ParserState.QuotedValueState;
		}

		public override ParserState Comma(ParserContext context)
		{
			if (ParserState.QuoteState.quoteSwitcher % 2 == 1)
			{
				ParserState.QuoteState.quoteSwitcher = 0;
				context.QuoteValueEnd();
				return ParserState.ValueStartState;
			}
			context.AddChar(',');
			return ParserState.QuotedValueState;
		}

		public override ParserState Quote(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher++;
			context.AddChar('"');
			return ParserState.QuotedValueState;
		}

		public override ParserState EndOfLine(ParserContext context)
		{
			ParserState.QuoteState.quoteSwitcher = 0;
			context.QuoteValueEnd();
			context.AddLine();
			return ParserState.LineStartState;
		}
	}

	private class ParserContext
	{
		private readonly StringBuilder _currentValue = new StringBuilder();

		private readonly List<string[]> _lines = new List<string[]>();

		private readonly List<string> _currentLine = new List<string>();

		public void AddChar(char ch)
		{
			_currentValue.Append(ch);
		}

		public void AddValue()
		{
			_currentLine.Add(_currentValue.ToString());
			_currentValue.Remove(0, _currentValue.Length);
		}

		public void AddLine()
		{
			_lines.Add(_currentLine.ToArray());
			_currentLine.Clear();
		}

		public List<string[]> GetAllLines()
		{
			if (_currentValue.Length > 0)
			{
				AddValue();
			}
			if (_currentLine.Count > 0)
			{
				AddLine();
			}
			return _lines;
		}

		public bool CheckDoubleQuote()
		{
			if (_currentValue.Length > 1)
			{
				if (_currentValue[_currentValue.Length - 1] == '"')
				{
					return _currentValue[_currentValue.Length - 2] == '"';
				}
				return false;
			}
			return false;
		}

		public void QuoteValueEnd()
		{
			_currentValue.Remove(_currentValue.Length - 1, 1);
			AddValue();
		}
	}

	private const char CommaCharacter = ',';

	private const char QuoteCharacter = '"';

	public List<string[]> Parse(TextReader reader)
	{
		ParserContext parserContext = new ParserContext();
		ParserState parserState = ParserState.LineStartState;
		string text;
		while ((text = reader.ReadLine()) != null)
		{
			string text2 = text;
			foreach (char c in text2)
			{
				parserState = c switch
				{
					',' => parserState.Comma(parserContext), 
					'"' => parserState.Quote(parserContext), 
					_ => parserState.AnyChar(c, parserContext), 
				};
			}
			parserState = parserState.EndOfLine(parserContext);
		}
		return parserContext.GetAllLines();
	}

	public static List<string[]> Parse(string input)
	{
		CsvParser csvParser = new CsvParser();
		using StringReader reader = new StringReader(input);
		return csvParser.Parse(reader);
	}
}
