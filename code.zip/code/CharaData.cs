using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using UnityEngine;

public class CharaData
{
	[JsonProperty]
	public CharaDataBasic _CharaDataBasic = new CharaDataBasic();

	public string m_Table = "";

	public string m_Id = "";

	public string m_B01Id = "";

	public string m_Prefab = "";

	public string m_BattleIcon = "";

	public string m_DefaultPrefab = "";

	public string m_DefaultBattleIcon = "";

	public string m_Sound = "";

	public List<string> m_KongFuListInBattle = new List<string>();

	public string m_Training_Id = "0";

	public string m_LevelUpSkillId = "";

	public int m_Ranking = 999;

	public List<string> m_EquipSlot = new List<string>();

	public List<string> m_NicknameList = new List<string>();

	public int m_Relationship;

	public int m_KeyPos;

	public string m_DropId = "";

	public string m_mustDropID = "";

	public string originRace = "";

	public string m_duty = "";

	public string m_currentTitleID = "";

	public string m_NickName = "";

	public string m_Guild = "";

	public SkinData m_SkinData = new SkinData();

	public gang_b01SkinTable.Row b01SkinRow;

	public Dictionary<string, string> m_EquipTraitDict = new Dictionary<string, string>
	{
		{ "1", "" },
		{ "2", "" },
		{ "3", "" },
		{ "4", "" },
		{ "5", "" },
		{ "6", "" },
		{ "7", "" },
		{ "8", "" },
		{ "9", "" }
	};

	public Dictionary<string, int> m_titleExpDict = new Dictionary<string, int>();

	public int separateexp;

	public int totalTalentCost;

	public float m_Hp
	{
		get
		{
			return _CharaDataBasic.m_Hp;
		}
		set
		{
			_CharaDataBasic.m_Hp = value;
		}
	}

	public float m_Mp
	{
		get
		{
			return _CharaDataBasic.m_Mp;
		}
		set
		{
			_CharaDataBasic.m_Mp = value;
		}
	}

	public List<KongFuData> m_KongFuList
	{
		get
		{
			return _CharaDataBasic.m_KongFuList;
		}
		set
		{
			_CharaDataBasic.m_KongFuList = value;
		}
	}

	public List<KongFuData> m_AbolishedKongFuList
	{
		get
		{
			return _CharaDataBasic.m_AbolishedKongFuList;
		}
		set
		{
			_CharaDataBasic.m_AbolishedKongFuList = value;
		}
	}

	public int m_Level
	{
		get
		{
			return _CharaDataBasic.m_Level;
		}
		set
		{
			_CharaDataBasic.m_Level = value;
		}
	}

	public int m_Exp
	{
		get
		{
			return _CharaDataBasic.m_Exp;
		}
		set
		{
			_CharaDataBasic.m_Exp = value;
		}
	}

	public int m_Money
	{
		get
		{
			return _CharaDataBasic.m_Money;
		}
		set
		{
			_CharaDataBasic.m_Money = value;
		}
	}

	public int m_Talent
	{
		get
		{
			return _CharaDataBasic.m_Talent;
		}
		set
		{
			_CharaDataBasic.m_Talent = value;
		}
	}

	public List<string> m_TraitList
	{
		get
		{
			return _CharaDataBasic.m_TraitList;
		}
		set
		{
			_CharaDataBasic.m_TraitList = value;
		}
	}

	public Dictionary<string, AtomData> Indexs_Name
	{
		get
		{
			return _CharaDataBasic.Indexs_Name;
		}
		set
		{
			_CharaDataBasic.Indexs_Name = value;
		}
	}

	public List<BuffData> m_Buffs
	{
		get
		{
			return _CharaDataBasic.m_Buffs;
		}
		set
		{
			_CharaDataBasic.m_Buffs = value;
		}
	}

	public void Init()
	{
		foreach (gang_a01Table.Row row in CommonResourcesData.a01.GetRowList())
		{
			AtomData value = new AtomData
			{
				_charaData = this,
				a01ID = row.ID,
				a01Name = row.Name,
				stringValue = "",
				bornValue = float.Parse(row.Default, CultureInfo.InvariantCulture),
				rollValue = float.Parse(row.Default, CultureInfo.InvariantCulture),
				alterValue = 0f,
				fightValue = 0f,
				drunkbuffValue = 0f
			};
			Indexs_Name.Add(row.Name, value);
		}
	}

	public void Init(gang_b01Table.Row _data)
	{
		Init();
		if (_data.ID == "9001" || _data.ID == "9002")
		{
			GameDataManager.Instance().AddUnlockAtlasList(_data.ID, "b01");
		}
		m_Table = "b01";
		m_Id = _data.ID;
		m_B01Id = "0";
		m_Prefab = _data.Prefab;
		m_BattleIcon = _data.BattleIcon;
		m_Sound = _data.Sound;
		m_Hp = float.Parse(_data.HP, CultureInfo.InvariantCulture);
		m_Mp = float.Parse(_data.MP, CultureInfo.InvariantCulture);
		m_Level = int.Parse(_data.LV);
		m_Relationship = int.Parse(_data.Relationship);
		m_Talent = 0;
		m_DropId = "";
		m_mustDropID = "";
		m_duty = _data.Duty_Trans;
		b01SkinRow = CommonResourcesData.b01Skin.Find_ID(_data.Prefab);
		Type type = _data.GetType();
		string text = "";
		FieldInfo[] fields = type.GetFields();
		foreach (FieldInfo fieldInfo in fields)
		{
			if (Indexs_Name.ContainsKey(fieldInfo.Name))
			{
				if (SharedData.Instance().m_A01NameRowDirec[fieldInfo.Name].Type == "0")
				{
					if (fieldInfo.Name == "Name")
					{
						Indexs_Name[fieldInfo.Name].stringValue = _data.Name_Trans;
					}
					else
					{
						Indexs_Name[fieldInfo.Name].stringValue = fieldInfo.GetValue(_data).ToString();
					}
					Indexs_Name[fieldInfo.Name].bornValue = 0f;
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
				else
				{
					Indexs_Name[fieldInfo.Name].bornValue = float.Parse(fieldInfo.GetValue(_data).ToString(), CultureInfo.InvariantCulture);
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
			}
			else
			{
				text = text + ((text == "") ? "" : ",") + fieldInfo.Name;
			}
		}
		if (_data.Nickname_Trans != "0")
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(_data.Nickname_Trans);
			if (row != null)
			{
				m_currentTitleID = row.id;
			}
			else
			{
				m_NickName = _data.Nickname_Trans;
			}
		}
		else
		{
			m_NickName = CommonFunc.I18nGetLocalizedValue("I18N_Null");
		}
		KongFuData kongFuData = null;
		gang_b03Table.Row row2 = null;
		if (_data.kongfu1 != "0")
		{
			row2 = CommonResourcesData.b03.Find_ID(_data.kongfu1);
			if (row2 == null)
			{
				Debug.Log("m_Id[" + m_Id + "] _data.kongfu1[" + _data.kongfu1 + "] NOT found.");
			}
			else
			{
				kongFuData = new KongFuData();
				kongFuData.kf = row2;
				kongFuData.lv = int.Parse(_data.KFLV1);
				kongFuData.exp = 0f;
				kongFuData.proficiency = 0;
				KongFuListAdd(kongFuData);
			}
		}
		if (_data.kongfu2 != "0")
		{
			row2 = CommonResourcesData.b03.Find_ID(_data.kongfu2);
			if (row2 == null)
			{
				Debug.Log("m_Id[" + m_Id + "] _data.kongfu2[" + _data.kongfu2 + "] NOT found.");
			}
			else
			{
				kongFuData = new KongFuData();
				kongFuData.kf = row2;
				kongFuData.lv = int.Parse(_data.KFLV2);
				kongFuData.exp = 0f;
				kongFuData.proficiency = 0;
				KongFuListAdd(kongFuData);
			}
		}
		if (_data.kongfu3 != "0")
		{
			row2 = CommonResourcesData.b03.Find_ID(_data.kongfu3);
			if (row2 == null)
			{
				Debug.Log("m_Id[" + m_Id + "] _data.kongfu3[" + _data.kongfu3 + "] NOT found.");
			}
			else
			{
				kongFuData = new KongFuData();
				kongFuData.kf = row2;
				kongFuData.lv = int.Parse(_data.KFLV3);
				kongFuData.exp = 0f;
				kongFuData.proficiency = 0;
				KongFuListAdd(kongFuData);
			}
		}
		if (_data.kongfu4 != "0")
		{
			row2 = CommonResourcesData.b03.Find_ID(_data.kongfu4);
			if (row2 == null)
			{
				Debug.Log("m_Id[" + m_Id + "] _data.kongfu4[" + _data.kongfu4 + "] NOT found.");
			}
			else
			{
				kongFuData = new KongFuData();
				kongFuData.kf = row2;
				kongFuData.lv = int.Parse(_data.KFLV4);
				kongFuData.exp = 0f;
				kongFuData.proficiency = 0;
				KongFuListAdd(kongFuData);
			}
		}
		if (_data.kongfu5 != "0")
		{
			row2 = CommonResourcesData.b03.Find_ID(_data.kongfu5);
			if (row2 == null)
			{
				Debug.Log("m_Id[" + m_Id + "] _data.kongfu5[" + _data.kongfu5 + "] NOT found.");
			}
			else
			{
				kongFuData = new KongFuData();
				kongFuData.kf = row2;
				kongFuData.lv = int.Parse(_data.KFLV5);
				kongFuData.exp = 0f;
				kongFuData.proficiency = 0;
				KongFuListAdd(kongFuData);
			}
		}
		if (!_data.Traits.Equals("0"))
		{
			string[] array = _data.Traits.Split('|');
			foreach (string text2 in array)
			{
				if (!text2.Equals("0"))
				{
					AddTraits(text2);
					GameDataManager.Instance().AddUnlockAtlasList(text2, "b06");
				}
			}
		}
		for (int j = 0; j < 3; j++)
		{
			m_EquipSlot.Add("0");
		}
		m_Hp = GetBattleValueByName("HP");
		m_Mp = GetBattleValueByName("MP");
	}

	public void Init(gang_b04Table.Row _data)
	{
		Init();
		CommonResourcesData.b01.Find_ID(_data.B01ID);
		m_Table = "b04";
		separateexp = int.Parse(_data.separateexp);
		int num = 0;
		foreach (string item in SharedData.Instance().FullTeam)
		{
			if (item.StartsWith(_data.B01ID + "_"))
			{
				int num2 = int.Parse(item.Split("_")[1], CultureInfo.InvariantCulture);
				if (num2 > num)
				{
					num = num2;
				}
			}
		}
		if (SharedData.Instance().m_BattleController != null)
		{
			foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
			{
				if (allBattleObj.charadata.m_Id.StartsWith(_data.B01ID + "_"))
				{
					int num3 = int.Parse(allBattleObj.charadata.m_Id.Split("_")[1], CultureInfo.InvariantCulture);
					if (num3 > num)
					{
						num = num3;
					}
				}
			}
		}
		m_Id = _data.B01ID + "_" + (num + 1);
		m_B01Id = _data.B01ID;
		m_Prefab = _data.Prefab;
		m_BattleIcon = _data.BattleIcon;
		m_Sound = _data.Sound;
		m_Hp = UnityEngine.Random.Range(int.Parse(_data.HP, CultureInfo.InvariantCulture), int.Parse(_data.HP1, CultureInfo.InvariantCulture) + 1);
		m_Mp = UnityEngine.Random.Range(int.Parse(_data.MP, CultureInfo.InvariantCulture), int.Parse(_data.MP1, CultureInfo.InvariantCulture) + 1);
		m_Level = int.Parse(_data.LV);
		m_KeyPos = int.Parse(_data.KeyPos);
		m_DropId = _data.DropID;
		m_mustDropID = _data.mustDropID;
		m_duty = _data.Duty_Trans;
		b01SkinRow = CommonResourcesData.b01Skin.Find_ID(_data.Prefab);
		Type type = _data.GetType();
		string text = "";
		FieldInfo[] fields = type.GetFields();
		foreach (FieldInfo fieldInfo in fields)
		{
			if (Indexs_Name.ContainsKey(fieldInfo.Name))
			{
				if (SharedData.Instance().m_A01NameRowDirec[fieldInfo.Name].Type == "0")
				{
					if (fieldInfo.Name == "Name")
					{
						Indexs_Name[fieldInfo.Name].stringValue = _data.Name_Trans;
					}
					else
					{
						Indexs_Name[fieldInfo.Name].stringValue = fieldInfo.GetValue(_data).ToString();
					}
					Indexs_Name[fieldInfo.Name].bornValue = 0f;
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
				else if (fieldInfo.Name == "ATK" || fieldInfo.Name == "DEF" || fieldInfo.Name == "SP" || fieldInfo.Name == "STR" || fieldInfo.Name == "AGI" || fieldInfo.Name == "BON" || fieldInfo.Name == "WIL" || fieldInfo.Name == "LER" || fieldInfo.Name == "MOR" || fieldInfo.Name == "Sword" || fieldInfo.Name == "Knife" || fieldInfo.Name == "Stick" || fieldInfo.Name == "Hand" || fieldInfo.Name == "Finger" || fieldInfo.Name == "Special" || fieldInfo.Name == "YinYang" || fieldInfo.Name == "Melody" || fieldInfo.Name == "Making" || fieldInfo.Name == "Darts" || fieldInfo.Name == "Wineart" || fieldInfo.Name == "Steal" || fieldInfo.Name == "Forge" || fieldInfo.Name == "Percept")
				{
					_ = fieldInfo.Name;
					string name = fieldInfo.Name + "1";
					FieldInfo field = type.GetField(name);
					int minInclusive = int.Parse(fieldInfo.GetValue(_data).ToString());
					int num4 = int.Parse(field.GetValue(_data).ToString());
					Indexs_Name[fieldInfo.Name].bornValue = UnityEngine.Random.Range(minInclusive, num4 + 1);
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
				else if (fieldInfo.Name == "HP")
				{
					Indexs_Name[fieldInfo.Name].bornValue = m_Hp;
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
				else if (fieldInfo.Name == "MP")
				{
					Indexs_Name[fieldInfo.Name].bornValue = m_Mp;
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
				else
				{
					Indexs_Name[fieldInfo.Name].bornValue = float.Parse(fieldInfo.GetValue(_data).ToString(), CultureInfo.InvariantCulture);
					Indexs_Name[fieldInfo.Name].rollValue = Indexs_Name[fieldInfo.Name].bornValue;
					Indexs_Name[fieldInfo.Name].alterValue = 0f;
					Indexs_Name[fieldInfo.Name].fightValue = 0f;
					Indexs_Name[fieldInfo.Name].drunkbuffValue = 0f;
				}
			}
			else
			{
				text = text + ((text == "") ? "" : ",") + fieldInfo.Name;
			}
		}
		if (_data.kongfu1 != "0")
		{
			B04_KFData2List(_data.kongfu1, _data.KFLV1);
		}
		if (_data.kongfu2 != "0")
		{
			B04_KFData2List(_data.kongfu2, _data.KFLV2);
		}
		if (_data.kongfu3 != "0")
		{
			B04_KFData2List(_data.kongfu3, _data.KFLV3);
		}
		if (_data.kongfu4 != "0")
		{
			B04_KFData2List(_data.kongfu4, _data.KFLV4);
		}
		if (_data.kongfu5 != "0")
		{
			B04_KFData2List(_data.kongfu5, _data.KFLV5);
		}
		foreach (KongFuData kongFu in m_KongFuList)
		{
			if (kongFu.lv < 1)
			{
				kongFu.lv = 1;
			}
		}
		if (!_data.Traits.Equals("0"))
		{
			string[] array = _data.Traits.Split('|');
			if (CommonResourcesData.b01.Find_ID(_data.B01ID) != null)
			{
				string[] array2 = array;
				foreach (string text2 in array2)
				{
					if (!text2.Equals("0"))
					{
						AddTraits(text2);
						GameDataManager.Instance().AddUnlockAtlasList(text2, "b06");
					}
				}
			}
			else
			{
				int num5 = 100;
				string[] array2 = array;
				foreach (string text3 in array2)
				{
					if (!text3.Equals("0"))
					{
						m_EquipTraitDict.TryAdd(num5++.ToString(), text3);
						m_TraitList.Add(text3);
						GameDataManager.Instance().AddUnlockAtlasList(text3, "b06");
					}
				}
			}
		}
		for (int j = 0; j < 3; j++)
		{
			m_EquipSlot.Add("0");
		}
		m_Hp = GetBattleValueByName("HP");
		m_Mp = GetBattleValueByName("MP");
	}

	private void B04_KFData2List(string _data_id, string _data_lv)
	{
		KongFuData kongFuData = new KongFuData
		{
			kf = CommonResourcesData.b03.Find_ID(_data_id),
			lv = int.Parse(_data_lv) + SharedData.Instance().m_Enemy_Skill_Lv_Diff,
			exp = 0f
		};
		if (kongFuData.kf == null)
		{
			Debug.LogWarning("Data2List(): Can NOT find b03 data by ID = " + _data_id);
		}
		else
		{
			KongFuListAdd(kongFuData);
		}
	}

	public void UpdateData(CharaData _cd)
	{
		m_Hp = _cd.m_Hp;
		m_Mp = _cd.m_Mp;
		m_Training_Id = _cd.m_Training_Id;
		m_LevelUpSkillId = _cd.m_LevelUpSkillId;
		m_Level = _cd.m_Level;
		m_Exp = _cd.m_Exp;
		m_Ranking = _cd.m_Ranking;
		m_Talent = _cd.m_Talent;
		m_Relationship = _cd.m_Relationship;
		m_TraitList.Clear();
		foreach (string trait in _cd.m_TraitList)
		{
			AddTraits(trait);
			GameDataManager.Instance().AddUnlockAtlasList(trait, "b06");
		}
		m_EquipSlot.Clear();
		foreach (string item in _cd.m_EquipSlot)
		{
			m_EquipSlot.Add(item);
		}
		m_KongFuList.Clear();
		m_KongFuListInBattle.Clear();
		foreach (KongFuData kongFu in _cd.m_KongFuList)
		{
			KongFuListAdd(kongFu);
		}
		foreach (KeyValuePair<string, AtomData> item2 in _cd.Indexs_Name)
		{
			if (!"Sex".Equals(item2.Key))
			{
				Indexs_Name[item2.Key] = item2.Value;
			}
		}
	}

	public void CleanFightValues()
	{
		m_Buffs.Clear();
		foreach (AtomData value in Indexs_Name.Values)
		{
			value.drunkbuffValue = 0f;
			if (!"Hurt".Equals(value.a01Name) && !"Poison".Equals(value.a01Name) && !"Bleed".Equals(value.a01Name) && !"Burn".Equals(value.a01Name) && !"Seal".Equals(value.a01Name))
			{
				value.fightValue = 0f;
			}
		}
	}

	public KongFuData GetKongFuByID(string _id)
	{
		KongFuData result = null;
		foreach (KongFuData kongFu in m_KongFuList)
		{
			if (kongFu.kf.ID == _id)
			{
				result = kongFu;
				break;
			}
		}
		return result;
	}

	public void KongFuListAdd(KongFuData newkongfu)
	{
		string value = newkongfu.kf.ID;
		if (newkongfu.kf.ID.Contains("MB03"))
		{
			value = newkongfu.kf.ID.Split('_')[1];
		}
		KongFuData kongFuData = null;
		foreach (KongFuData item in m_KongFuList.Concat(m_AbolishedKongFuList).ToList())
		{
			string text = item.kf.ID;
			if (text.Contains("MB03"))
			{
				text = text.Split('_')[1];
			}
			if (text.Equals(value))
			{
				kongFuData = item;
				break;
			}
		}
		if (kongFuData != null)
		{
			if (m_AbolishedKongFuList.Contains(kongFuData))
			{
				m_AbolishedKongFuList.Remove(kongFuData);
				m_KongFuList.Add(kongFuData);
			}
			kongFuData.isAbolished = false;
			int num = m_KongFuListInBattle.IndexOf(kongFuData.kf.ID);
			if (num >= 0)
			{
				m_KongFuListInBattle[num] = newkongfu.kf.ID;
			}
			else
			{
				m_KongFuListInBattle.Add(newkongfu.kf.ID);
			}
			kongFuData.kf = newkongfu.kf;
		}
		else
		{
			m_KongFuList.Add(newkongfu);
			if (!m_KongFuListInBattle.Contains(newkongfu.kf.ID))
			{
				m_KongFuListInBattle.Add(newkongfu.kf.ID);
			}
		}
		gang_b07Table.Row row = CommonResourcesData.b07.Find_Relate_Wugong_id(newkongfu.kf.ID);
		if (row != null)
		{
			GameDataManager.Instance().AddUnlockAtlasList(row.ID, "b07");
		}
	}

	public void KongFuListRemove(KongFuData kongfu)
	{
		kongfu.isAbolished = true;
		m_KongFuList.Remove(kongfu);
		m_AbolishedKongFuList.Add(kongfu);
		if (m_KongFuListInBattle.Contains(kongfu.kf.ID))
		{
			m_KongFuListInBattle.Remove(kongfu.kf.ID);
			List<string> list = new List<string>();
			list.AddRange(m_KongFuListInBattle);
			m_KongFuListInBattle = list;
			if (m_KongFuListInBattle.Count <= 0 && m_KongFuList.Count > 0)
			{
				m_KongFuListInBattle.Add(m_KongFuList[0].kf.ID);
			}
		}
	}

	public void AddTraits(string traitID)
	{
		if (m_TraitList.Contains(traitID))
		{
			return;
		}
		bool flag = false;
		foreach (string trait in m_TraitList)
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(trait);
			if (row != null && row.isTitle == "1")
			{
				flag = true;
				break;
			}
		}
		gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(traitID);
		if (row2 == null)
		{
			return;
		}
		if (row2.isTitle.Equals("1"))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1014");
		}
		if (!flag && row2 != null && row2.isTitle == "1" && m_currentTitleID == "")
		{
			m_currentTitleID = row2.id;
		}
		if (row2.isTitle == "1" && row2.titleLeveUp != "0")
		{
			m_titleExpDict.Add(row2.id, 0);
		}
		if (m_Table != "b04" || m_B01Id != "")
		{
			if (row2.isTitle == "1" && m_currentTitleID == "")
			{
				m_currentTitleID = row2.id;
			}
			if (row2.isTitle == "0")
			{
				foreach (string item in row2.traitEquipIndex.Split("&").ToList())
				{
					if (m_EquipTraitDict.ContainsKey(item) && m_EquipTraitDict[item] == "" && (SharedData.Instance().m_BattleController == null || m_Table == "b01"))
					{
						m_EquipTraitDict[item] = traitID;
						break;
					}
				}
			}
		}
		m_TraitList.Add(traitID);
		CalAdditionalTrait();
	}

	public void RemoveTrait(string traitID)
	{
		if (!m_TraitList.Contains(traitID))
		{
			return;
		}
		m_TraitList.Remove(traitID);
		gang_b06Table.Row row = CommonResourcesData.b06.Find_id(traitID);
		if (row != null)
		{
			string text = "";
			foreach (KeyValuePair<string, string> item in m_EquipTraitDict)
			{
				if (item.Value == row.id)
				{
					text = item.Key;
					m_EquipTraitDict[text] = "";
					break;
				}
			}
		}
		CalAdditionalTrait();
	}

	public List<string> CalAdditionalTrait()
	{
		List<string> list = new List<string>();
		foreach (string item in m_EquipTraitDict.Keys.ToList())
		{
			if (int.Parse(item) > 9 || int.Parse(item) < 1)
			{
				m_EquipTraitDict.Remove(item);
			}
		}
		foreach (gang_b06ChainTable.Row row in CommonResourcesData.b06Chain.GetRowList())
		{
			bool flag = true;
			List<string> list2 = new List<string>();
			for (int i = 1; i < 10; i++)
			{
				string text = row.nineGridDict[i.ToString()];
				if (text.Equals("0"))
				{
					continue;
				}
				string text2 = m_EquipTraitDict[i.ToString()];
				bool flag2 = false;
				switch (text)
				{
				case "Any":
					if (text2.Equals(""))
					{
						flag = false;
					}
					else
					{
						flag2 = true;
					}
					break;
				case "NAN":
					if (!text2.Equals(""))
					{
						flag = false;
					}
					else
					{
						flag2 = true;
					}
					break;
				default:
					if (!text.Split('|').Contains(text2))
					{
						flag = false;
					}
					else
					{
						flag2 = true;
					}
					break;
				case "0":
					break;
				}
				if (flag2)
				{
					list2.Add(i.ToString());
				}
				if (!flag)
				{
					break;
				}
			}
			if (flag)
			{
				list.AddRange(list2);
				m_EquipTraitDict.Add((m_EquipTraitDict.Count + 1).ToString(), row.id);
				break;
			}
		}
		return list;
	}

	public float GetFieldValueByName(string _name)
	{
		return GetBattleValueByName(_name, isOrigin: true, ignoreBuff: true);
	}

	public float GetBattleValueByName(string _name, bool isOrigin = false, bool ignoreBuff = false)
	{
		if (!Indexs_Name.ContainsKey(_name))
		{
			return 0f;
		}
		if (!isOrigin)
		{
			switch (_name)
			{
			case "STR":
			case "AGI":
			case "BON":
			case "WIL":
			case "LER":
				if (m_Buffs.Find((BuffData x) => x.name == "Yijinjing") != null)
				{
					return GetBattleValue("Yijinjing", ignoreBuff);
				}
				if (m_Buffs.Find((BuffData x) => x.name == "Xisuijing") != null)
				{
					return GetBattleValue("Xisuijing", ignoreBuff);
				}
				break;
			}
			switch (_name)
			{
			case "Poison":
			case "Burn":
			case "Bleed":
			case "Hurt":
			case "Seal":
			case "Mad":
				if ((!_name.Equals("Mad") && GetBattleValue("DebuffImmune", ignoreBuff) > 0f) || GetBattleValue(_name + "Immune", ignoreBuff) > 0f)
				{
					return 0f;
				}
				break;
			}
		}
		float num = 0f;
		float num2 = 1f;
		float num3 = 0f;
		float num4 = 0f;
		float num5 = 0f;
		float battleValue = GetBattleValue(_name, ignoreBuff);
		string name = _name + "plus";
		string name2 = _name + "minus";
		string text = _name + "down";
		switch (_name)
		{
		case "HP":
		case "MP":
		case "ATK":
		case "DEF":
		case "SP":
			num3 = GetBattleValue(name, ignoreBuff);
			num4 = GetBattleValue(name2, ignoreBuff);
			if (Indexs_Name.ContainsKey(text))
			{
				num5 = GetBattleValue(text, ignoreBuff);
			}
			if (originRace == "enemy" && SharedData.Instance().DuelBattleGuild == "")
			{
				switch (_name)
				{
				case "HP":
					num2 = SharedData.Instance().m_Enemy_HP_Rate;
					break;
				case "MP":
					num2 = SharedData.Instance().m_Enemy_MP_Rate;
					break;
				case "ATK":
					num2 = SharedData.Instance().m_Enemy_ATK_Rate;
					break;
				case "DEF":
					num2 = SharedData.Instance().m_Enemy_DEF_Rate;
					break;
				case "SP":
					num2 = SharedData.Instance().m_Enemy_SP_Rate;
					break;
				}
			}
			break;
		case "STR":
		case "AGI":
		case "BON":
		case "WIL":
		case "LER":
		case "MOR":
			if (Indexs_Name.ContainsKey(text))
			{
				num5 = GetBattleValue(text, ignoreBuff);
			}
			break;
		}
		num = num2 * battleValue * (1f + num3 - num4) - num5;
		switch (_name)
		{
		case "HP":
		case "MP":
		case "ATK":
		case "DEF":
		case "SP":
			num = Mathf.Ceil(num);
			break;
		}
		if (_name == "HP" || _name == "MP")
		{
			if (num <= 0f)
			{
				num = 1f;
			}
			if (_name == "HP")
			{
				if (m_Hp > num)
				{
					m_Hp = num;
				}
			}
			else if (_name == "MP" && m_Mp > num)
			{
				m_Mp = num;
			}
		}
		return Mathf.Clamp(num, float.Parse(SharedData.Instance().m_A01NameRowDirec[_name].LowerLimit, CultureInfo.InvariantCulture), float.Parse(SharedData.Instance().m_A01NameRowDirec[_name].Limit, CultureInfo.InvariantCulture));
	}

	private float GetBattleValue(string _name, bool ignoreBuff = false)
	{
		bool flag = Indexs_Name["Drunk"].totalValue + Indexs_Name[_name].fightValue > 0f;
		return Indexs_Name[_name].totalValue + ((!ignoreBuff) ? Indexs_Name[_name].fightValue : 0f) + GetBuffValue(_name, ignoreBuff) + ((flag && !ignoreBuff) ? Indexs_Name[_name].drunkbuffValue : 0f);
	}

	private float GetBuffValue(string _name, bool ignoreBuff = false)
	{
		if (m_Buffs.Equals(null) || m_Buffs.Count.Equals(0) || ignoreBuff)
		{
			return 0f;
		}
		float num = 0f;
		float num2 = 0f;
		foreach (BuffData buff in m_Buffs)
		{
			gang_b15Table.Row row = CommonResourcesData.b15.Find_Name(buff.name);
			if (row == null)
			{
				if (buff.name == _name)
				{
					num2 += buff.value;
				}
				continue;
			}
			float num3 = 1f;
			if (buff.source.StartsWith("Wugong"))
			{
				num3 = float.Parse(buff.source.Split("|")[3], CultureInfo.InvariantCulture);
			}
			float num4 = float.Parse(row.Skill1.Split("&")[1].Split("|")[0], CultureInfo.InvariantCulture);
			float num5 = float.Parse(row.Skill1.Split("&")[1].Split("|")[1], CultureInfo.InvariantCulture);
			if (buff.name.Equals("StealHpMpAddCrazyBuff") || buff.name.Equals("KillAddCrazyBuff") || buff.name.Equals("FoMoZhiJian"))
			{
				num3 = buff.value;
			}
			foreach (string item in new List<string> { row.Skill1, row.Skill2, row.Skill3, row.Skill4, row.Skill5, row.Skill6, row.Skill7, row.Skill8 })
			{
				if (item.Contains(_name))
				{
					num += num4 + num5 * num3;
				}
			}
		}
		return num + num2;
	}
}
