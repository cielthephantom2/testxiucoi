using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class TraitNineGirdController : MonoBehaviour
{
	public Dictionary<string, string> TraitDict = new Dictionary<string, string>
	{
		{ "1", "" },
		{ "2", "" },
		{ "3", "" },
		{ "4", "" },
		{ "5", "" },
		{ "6", "" },
		{ "7", "" },
		{ "8", "" },
		{ "9", "" }
	};

	public Starter3Controller starter3Controller;

	public StatusSub3 statusSub3;

	public CreateWGController createWgController;

	private Button[] bottom_btns;

	private void Awake()
	{
		bottom_btns = GetComponentsInChildren<Button>(includeInactive: true);
		Button[] array = bottom_btns;
		foreach (Button button in array)
		{
			if (button.interactable)
			{
				EventTriggerListener.Get(button.gameObject).onClick = OnButtonClick;
			}
		}
	}

	private void OnEnable()
	{
		if (SharedData.Instance().m_TraitPackageController != null)
		{
			SharedData.Instance().m_TraitPackageController.customTraitNineGirdController = this;
		}
	}

	private void OnDisable()
	{
		if (SharedData.Instance().m_TraitPackageController != null)
		{
			SharedData.Instance().m_TraitPackageController.CloseTraitPackage();
		}
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MonoBehaviour.print("OnButtonClick -> " + go.transform.parent.name);
		if (!go.transform.parent.name.StartsWith("Trait|"))
		{
			return;
		}
		string text = go.transform.parent.name.Split('|')[1];
		if (statusSub3 != null)
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(statusSub3.curdata.m_EquipTraitDict[text]);
			if (row != null && row.isLockTrait == "1")
			{
				Debug.Log("isLockTrait cant be replaced");
				return;
			}
		}
		if (base.gameObject.scene.name == "Starter3")
		{
			SharedData.Instance().m_TraitPackageController.transform.Find("Panel/TraitPackage/TraitInfo/Btns/Choose/TraitCost").gameObject.SetActive(value: true);
		}
		else
		{
			SharedData.Instance().m_TraitPackageController.transform.Find("Panel/TraitPackage/TraitInfo/Btns/Choose/TraitCost").gameObject.SetActive(value: false);
		}
		CommonResourcesData.inputDeviceDetector.PushJoyStack(go.transform);
		if (starter3Controller != null)
		{
			List<string> traitIdList = CommonResourcesData.a02.Find_ID(SharedData.Instance().BornID).Features.Split('|').ToList();
			SharedData.Instance().m_TraitPackageController.OpenTraitPackage(TraitPackageType.IndexTraits, traitIdList, text, TraitDict.Values.ToList(), TraitDict[text]);
		}
		else if (statusSub3 != null)
		{
			SharedData.Instance().m_TraitPackageController.OpenTraitPackage(TraitPackageType.IndexTraits, statusSub3.curdata.m_TraitList, text, statusSub3.curdata.m_EquipTraitDict.Values.ToList(), statusSub3.curdata.m_EquipTraitDict[text]);
		}
		else if (createWgController != null)
		{
			SharedData.Instance().m_TraitPackageController.OpenTraitPackage(TraitPackageType.IndexTraits, createWgController.charaData.m_TraitList, text, TraitDict.Values.ToList(), TraitDict[text]);
		}
	}

	public void RefreshTraitIcon(List<string> chainIndexList)
	{
		bottom_btns = GetComponentsInChildren<Button>(includeInactive: true);
		Button[] array = bottom_btns;
		foreach (Button obj in array)
		{
			string text = obj.transform.parent.name.Split("|")[1];
			obj.transform.parent.GetComponent<TraitIconController>().InitTraitIcon(TraitDict[text], text, chainIndexList.Contains(text));
		}
	}
}
