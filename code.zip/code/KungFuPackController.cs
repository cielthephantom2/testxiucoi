using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class KungFuPackController : MonoBehaviour
{
	private Sprite NormalSprite;

	private Sprite SelectedSprite;

	private Vector3 PointDown = Vector3.zero;

	private bool isExiting;

	private void Start()
	{
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		NormalSprite = Resources.Load("images/01-border/KONGFU-bg-1219", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/BUTTON-03-1219", typeof(Sprite)) as Sprite;
		GameObject original = (GameObject)Resources.Load("Prefabs/Field/WuGongBtn");
		GameObject gameObject = null;
		GameObject gameObject2 = base.transform.Find("Panel/WuGong/ScrollView/Viewport/Content").gameObject;
		RectTransform component = gameObject2.GetComponent<RectTransform>();
		Vector2 sizeDelta = component.sizeDelta;
		sizeDelta.y = 4f + 108f * (float)currentCharaData.m_KongFuList.Count;
		component.sizeDelta = sizeDelta;
		int num = 0;
		Vector2 zero = Vector2.zero;
		GameObject gameObject3 = null;
		foreach (KongFuData kongFu in currentCharaData.m_KongFuList)
		{
			gameObject = Object.Instantiate(original, gameObject2.transform);
			EventTriggerListener.Get(gameObject).onClick = OnButtonClick;
			EventTriggerListener.Get(gameObject).onDown = OnButtonDown;
			gameObject.transform.Find("Select").gameObject.SetActive(value: false);
			RectTransform component2 = gameObject.GetComponent<RectTransform>();
			zero.y = -4f + (8f + component2.rect.height) * (float)num * -1f;
			component2.anchoredPosition = zero;
			gameObject.name = "WuGong|" + kongFu.kf.ID;
			string[] array = kongFu.kf.Attckstyle.Split('|');
			string text = array[0] + array[1];
			int num2 = int.Parse(kongFu.kf.Range);
			if ("C01".Equals(text) && num2 > 1)
			{
				text += "-1";
			}
			gameObject.transform.Find("Range").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + text, typeof(Sprite)) as Sprite;
			gameObject.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + kongFu.kf.Icon, typeof(Sprite)) as Sprite;
			gameObject.transform.Find("Name").GetComponent<Text>().text = kongFu.kf.Name_Trans;
			gameObject.transform.Find("Level").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + kongFu.lv + "<size=22><color=#85796A>/" + kongFu.kf.LV + "</color></size>";
			if (gameObject3 == null)
			{
				gameObject3 = gameObject;
			}
			num++;
		}
	}

	private void OnButtonDown(GameObject go)
	{
		PointDown = Input.mousePosition;
	}

	private void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			MonoBehaviour.print("[KungFuPack] Click button: " + go.name);
			string[] array = go.name.Split('|');
			if (array[0] == "WuGong" && !((Input.mousePosition - PointDown).magnitude > 20f))
			{
				SharedData.Instance().m_Transfer_Info = "BREAKTHROUGH|" + array[1];
				ExitScene();
			}
		}
	}

	private void ExitScene()
	{
		if (isExiting)
		{
			return;
		}
		isExiting = true;
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			int index = SharedData.Instance().LoadedSceneStack.Count - 1;
			SharedData.Instance().LoadedSceneStack.RemoveAt(index);
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				index = SharedData.Instance().LoadedSceneStack.Count - 1;
				SceneManager.LoadScene(SharedData.Instance().LoadedSceneStack[index], LoadSceneMode.Additive);
			}
		}
		SceneManager.UnloadSceneAsync("KungFuPack");
	}
}
