using System.Collections.Generic;
using System.Linq;
using Spine.Unity;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Tilemaps;

public class FollowController : MonoBehaviour
{
	private const float MovementBlockSize = 50f;

	private const float MovingSpeedPPS = 200f;

	private const float TimeToMoveOneBlock = 0.25f;

	public State m_State;

	public Direction m_Direction;

	public SkeletonAnimation[] m_Animations;

	private MapController mapcontroller;

	private Vector3Int startPos = Vector3Int.zero;

	private Vector3Int endPos = Vector3Int.zero;

	private Dictionary<Vector3Int, int> search = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, int> cost = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, Vector3Int> pathSave = new Dictionary<Vector3Int, Vector3Int>();

	private List<Vector3Int> hadSearch = new List<Vector3Int>();

	private GameObject PathPrefab;

	private GameObject Path;

	private List<GameObject> pathObject = new List<GameObject>();

	private SpriteRenderer m_Renderer;

	private int m_SortingOrder;

	private int m_MoveProcess;

	private float m_MoveTimer;

	private Vector2 m_MovingFrom;

	private Vector2 m_MovingTo;

	private string aniname_stand = "A01-stand";

	private string aniname_walk = "A02-walk";

	private string aniname_die = "D02-die";

	public FollowController m_Next;

	public List<Vector3> m_FollowList = new List<Vector3>();

	public OhPlayerController player;

	public bool IsHide;

	public float unitRange = 32f;

	public float moveSpeed = 7.5f;

	private float finalSpeed;

	public Transform movePoint;

	private bool sliderotate = true;

	private Direction rotatedir = Direction.Down;

	private void Awake()
	{
		int sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
		m_Animations = base.gameObject.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		SkeletonAnimation[] animations = m_Animations;
		foreach (SkeletonAnimation obj in animations)
		{
			obj.gameObject.GetComponent<MeshRenderer>().sortingOrder = sortingOrder;
			obj.gameObject.AddComponent<SortingGroup>().sortingOrder = sortingOrder;
		}
		m_SortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "underfoot").sortingOrder;
		PathPrefab = CommonResourcesData.PathPrefab;
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
	}

	private void Start()
	{
		base.transform.localPosition = player.transform.localPosition;
		finalSpeed = moveSpeed * unitRange;
		movePoint = base.transform.Find("movepoint");
		movePoint.parent = null;
		m_State = State.AStarWaiting;
		switch (player.m_Direction)
		{
		case Direction.Up:
			Face(Direction.Up, isInit: true);
			break;
		case Direction.Down:
			Face(Direction.Down, isInit: true);
			break;
		case Direction.Left:
			Face(Direction.Left, isInit: true);
			break;
		case Direction.Right:
			Face(Direction.Right, isInit: true);
			break;
		case (Direction)3:
		case (Direction)5:
		case (Direction)7:
			break;
		}
	}

	public void AddFollowPos(Vector3 _pos)
	{
		m_FollowList.Add(_pos);
		if (m_State == State.BlockWait || m_State == State.AStarWaiting)
		{
			DoFollowMove();
		}
	}

	private void DoFollowMove()
	{
		if (m_FollowList.Count <= 0)
		{
			return;
		}
		m_MovingFrom = movePoint.position;
		m_MovingTo = m_FollowList[0];
		m_FollowList.RemoveAt(0);
		if (!m_MovingFrom.Equals(m_MovingTo))
		{
			float num = m_MovingTo.x - m_MovingFrom.x;
			float num2 = m_MovingTo.y - m_MovingFrom.y;
			if (Mathf.Abs(num) > Mathf.Abs(num2))
			{
				if (num > 0f)
				{
					Face(Direction.Left);
				}
				else
				{
					Face(Direction.Right);
				}
			}
			else if (num2 > 0f)
			{
				Face(Direction.Up);
			}
			else
			{
				Face(Direction.Down);
			}
			movePoint.position = m_MovingTo;
			m_State = State.AStarMoving;
			PlayAnimation(aniname_walk);
			if (m_Next != null && !player.m_FootOnInterrupt && player.m_ScenePlay == 0 && player.m_MultiEvent == null)
			{
				m_Next.AddFollowPos(m_MovingFrom);
			}
		}
		else
		{
			m_State = State.BlockWait;
		}
	}

	public void Tick(float _deltaTime)
	{
		if (mapcontroller.IsChating() || mapcontroller.m_Menu2.IsOpen() || SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			PlayAnimation(aniname_stand);
		}
		else if (m_State == State.AStarWaiting)
		{
			if (m_FollowList.Count <= 0)
			{
				if (player.m_State == State.WaitingForInput)
				{
					PlayAnimation(aniname_stand);
				}
			}
			else
			{
				DoFollowMove();
			}
		}
		else if (m_State == State.BlockWait)
		{
			DoFollowMove();
		}
		else if (m_State == State.AStarMoving)
		{
			AStarMove();
		}
		else if (m_State == State.OnSliding)
		{
			SlideUpdate();
		}
	}

	private Vector2 GetFacing()
	{
		Vector2 zero = Vector2.zero;
		switch (m_Direction)
		{
		case Direction.Up:
			zero.y = 1f;
			break;
		case Direction.Down:
			zero.y = -1f;
			break;
		case Direction.Left:
			zero.x = 1f;
			break;
		case Direction.Right:
			zero.x = -1f;
			break;
		}
		return zero;
	}

	private void AStarClean()
	{
		foreach (GameObject item in pathObject)
		{
			Object.Destroy(item);
		}
		pathObject.Clear();
		search.Clear();
		cost.Clear();
		pathSave.Clear();
		hadSearch.Clear();
	}

	public void Rotate()
	{
		Direction direction = (Direction)(((int)rotatedir / 2 % 4 + 1) * 2);
		rotatedir = direction;
		switch (rotatedir)
		{
		case Direction.Left:
			m_Animations[0].gameObject.SetActive(value: false);
			m_Animations[1].gameObject.SetActive(value: true);
			m_Animations[1].skeleton.ScaleX = 1f;
			m_Animations[2].gameObject.SetActive(value: false);
			break;
		case Direction.Up:
			m_Animations[0].gameObject.SetActive(value: false);
			m_Animations[1].gameObject.SetActive(value: false);
			m_Animations[2].gameObject.SetActive(value: true);
			break;
		case Direction.Right:
			m_Animations[0].gameObject.SetActive(value: false);
			m_Animations[1].gameObject.SetActive(value: true);
			m_Animations[1].skeleton.ScaleX = -1f;
			m_Animations[2].gameObject.SetActive(value: false);
			break;
		default:
			m_Animations[0].gameObject.SetActive(value: true);
			m_Animations[1].gameObject.SetActive(value: false);
			m_Animations[2].gameObject.SetActive(value: false);
			break;
		}
	}

	private bool SlideCheck()
	{
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanSlide(pos))
		{
			m_FollowList.Clear();
			sliderotate = Random.value < 0.5f;
			if (sliderotate)
			{
				PlayAnimation(aniname_stand);
				PlayAnimation(aniname_walk, loop: true, compensate: true, 3f);
				rotatedir = m_Direction;
			}
			else
			{
				PlayAnimation(aniname_die);
			}
			AStarClean();
			m_State = State.OnSliding;
			m_MovingFrom = movePoint.position;
			m_MovingTo = m_MovingFrom + GetFacing() * 50f;
			movePoint.position = m_MovingTo;
			m_Next?.AddFollowPos(m_MovingFrom);
			return true;
		}
		return false;
	}

	private void SlideUpdate()
	{
		base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, 1.5f * finalSpeed * Time.deltaTime);
		if (!(Vector3.Distance(base.transform.position, movePoint.position) <= 1f))
		{
			return;
		}
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
		m_MovingFrom = movePoint.position;
		Vector2 vector = m_MovingFrom + GetFacing() * 50f;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(vector);
		Vector3Int pos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (mapcontroller.CanSlide(pos))
		{
			m_MovingTo = vector;
			movePoint.position = m_MovingTo;
			if (sliderotate)
			{
				Rotate();
			}
			return;
		}
		AStarClean();
		if (sliderotate)
		{
			PlayAnimation(aniname_stand);
			PlayAnimation(aniname_walk);
			m_Direction = rotatedir;
		}
		PlayAnimation(aniname_stand);
		m_State = State.SlidingOver;
	}

	private void AStarMove()
	{
		base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, SharedData.Instance().m_FieldMoveSpeedRate * finalSpeed * Time.deltaTime);
		if (Vector3.Distance(base.transform.position, movePoint.position) <= 1f)
		{
			if (player.GetGridPositionMP().Equals(GetGridPositionMP()))
			{
				Hide();
			}
			if (!SlideCheck())
			{
				m_State = State.AStarWaiting;
				DoFollowMove();
			}
		}
	}

	public void Hide()
	{
		if (!IsHide)
		{
			IsHide = true;
			if (m_Animations.Length != 0)
			{
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
			}
		}
	}

	public void Show()
	{
		if (IsHide)
		{
			IsHide = false;
			Face(m_Direction, isInit: true);
		}
	}

	public void Face(Direction direction, bool isInit = false)
	{
		if (m_Animations.Length == 0 || (!isInit && direction == m_Direction))
		{
			return;
		}
		m_Direction = direction;
		if (!IsHide)
		{
			switch (direction)
			{
			case Direction.Left:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = 1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			case Direction.Up:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: true);
				break;
			case Direction.Right:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = -1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			default:
				m_Animations[0].gameObject.SetActive(value: true);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			}
		}
	}

	private void PlayAnimation(string animation, bool loop = true, bool compensate = true, float timescale = 1f)
	{
		if (IsHide)
		{
			return;
		}
		if (loop && animation.Equals(aniname_die))
		{
			loop = false;
		}
		if (m_Animations[0].AnimationName != animation)
		{
			m_Animations[0].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[0].skeleton.SetToSetupPose();
				m_Animations[0].AnimationState.ClearTracks();
			}
			m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[1].AnimationName != animation)
		{
			m_Animations[1].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[1].skeleton.SetToSetupPose();
				m_Animations[1].AnimationState.ClearTracks();
			}
			m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[2].AnimationName != animation)
		{
			m_Animations[2].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[2].skeleton.SetToSetupPose();
				m_Animations[2].AnimationState.ClearTracks();
			}
			m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}

	private void ShowOrHideWeapon(string animation)
	{
		if (animation.Contains("sword"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("knife"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("stick"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
		}
		else if (animation.Contains("hand"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("finger"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("heart"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		return zero;
	}

	public Vector3Int GetGridPositionMP()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(movePoint.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(movePoint.position.y) / 50f);
		return zero;
	}

	private int RoundToGrid(float value)
	{
		if (value < 0f)
		{
			return Mathf.CeilToInt(value / 50f) * 50 - 25;
		}
		return Mathf.FloorToInt(value / 50f) * 50 + 25;
	}

	public bool IsNextToMe(Vector3Int target)
	{
		Vector3Int gridPosition = GetGridPosition();
		Vector3Int other = gridPosition + Vector3Int.up;
		if (target.Equals(other))
		{
			return true;
		}
		Vector3Int other2 = gridPosition + Vector3Int.right;
		if (target.Equals(other2))
		{
			return true;
		}
		Vector3Int other3 = gridPosition - Vector3Int.right;
		if (target.Equals(other3))
		{
			return true;
		}
		Vector3Int other4 = gridPosition - Vector3Int.up;
		if (target.Equals(other4))
		{
			return true;
		}
		return false;
	}

	public void AStarSearchPath()
	{
		search.Add(startPos, GetHeuristic(startPos, endPos));
		cost.Add(startPos, 0);
		hadSearch.Add(startPos);
		pathSave.Add(startPos, startPos);
		while (search.Count > 0)
		{
			Vector3Int shortestPos = GetShortestPos();
			if (shortestPos.Equals(endPos))
			{
				break;
			}
			foreach (Vector3Int neighbor in GetNeighbors(shortestPos))
			{
				if (!hadSearch.Contains(neighbor))
				{
					cost.Add(neighbor, cost[shortestPos] + 1);
					search.Add(neighbor, cost[neighbor] + GetHeuristic(neighbor, endPos));
					pathSave.Add(neighbor, shortestPos);
					hadSearch.Add(neighbor);
				}
			}
		}
		if (pathSave.ContainsKey(endPos))
		{
			ShowPath();
			return;
		}
		m_State = State.AStarWaiting;
		PlayAnimation(aniname_stand);
		pathObject.Clear();
		search.Clear();
		cost.Clear();
		pathSave.Clear();
		hadSearch.Clear();
	}

	private List<Vector3Int> GetNeighbors(Vector3Int target)
	{
		List<Vector3Int> list = new List<Vector3Int>();
		Vector3Int item = target + Vector3Int.up;
		Vector3Int item2 = target + Vector3Int.right;
		Vector3Int item3 = target - Vector3Int.right;
		Vector3Int item4 = target - Vector3Int.up;
		if (item.y < mapcontroller.mapSize.y && mapcontroller.obstacle.Contains(item) && mapcontroller.sliding.Contains(item))
		{
			list.Add(item);
		}
		if (item2.x < mapcontroller.mapSize.x && mapcontroller.obstacle.Contains(item2) && mapcontroller.sliding.Contains(item2))
		{
			list.Add(item2);
		}
		if (item3.x >= 0 && mapcontroller.obstacle.Contains(item3) && mapcontroller.sliding.Contains(item3))
		{
			list.Add(item3);
		}
		if (item4.y >= 0 && mapcontroller.obstacle.Contains(item4) && mapcontroller.sliding.Contains(item4))
		{
			list.Add(item4);
		}
		return list;
	}

	private int GetHeuristic(Vector3Int posA, Vector3Int posB)
	{
		return Mathf.Abs(posA.x - posB.x) + Mathf.Abs(posA.y - posB.y);
	}

	private Vector3Int GetShortestPos()
	{
		KeyValuePair<Vector3Int, int> keyValuePair = new KeyValuePair<Vector3Int, int>(Vector3Int.zero, int.MaxValue);
		foreach (KeyValuePair<Vector3Int, int> item in search)
		{
			if (item.Value < keyValuePair.Value)
			{
				keyValuePair = item;
			}
		}
		search.Remove(keyValuePair.Key);
		return keyValuePair.Key;
	}

	private void ShowPath()
	{
		Vector3Int key = endPos;
		while (!key.Equals(startPos))
		{
			Vector3Int vector3Int = pathSave[key];
			Path = Object.Instantiate(PathPrefab, mapcontroller.map.transform);
			Path.transform.localPosition = new Vector3(25 + key.x * 50, -25 - key.y * 50);
			pathObject.Add(Path);
			m_Renderer = Path.GetComponentInChildren<SpriteRenderer>();
			m_Renderer.sortingOrder = ((m_SortingOrder > 0) ? m_SortingOrder : 0);
			key = vector3Int;
		}
		m_MoveProcess = pathObject.Count - 1;
		m_State = State.AStarWaiting;
	}
}
