public class PackageItemData : ItemDataBase
{
	public bool isNew;

	public string ID = "";

	public gang_b07Table.Row b07Row;

	public CharaData userData;

	public int number;

	public int originPrice;

	public int effectPrice;

	public PriceType _priceType;

	public PriceType priceType
	{
		get
		{
			if (b07Row != null && _priceType == PriceType.none)
			{
				return b07Row.PriceType;
			}
			return _priceType;
		}
		set
		{
			_priceType = value;
		}
	}

	public override bool IsFilterMatched(string filterStr)
	{
		return true;
	}
}
