using System.Collections.Generic;

public class RoundRecord
{
	public List<BattleObjectData> m_BattleObjectDataList = new List<BattleObjectData>();

	public BattleControllerData m_BattleControllerData;

	public Dictionary<string, int> m_Package = new Dictionary<string, int>();

	public int m_Money;

	public int roundNum;
}
