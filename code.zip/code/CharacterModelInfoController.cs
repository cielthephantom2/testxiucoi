using UnityEngine;
using UnityEngine.UI;

public class CharacterModelInfoController : MonoBehaviour
{
	public CharacterModelInfo characterModelInfo;

	private void Start()
	{
		Toggle[] componentsInChildren = GetComponentsInChildren<Toggle>(includeInactive: true);
		foreach (Toggle item in componentsInChildren)
		{
			item.onValueChanged.AddListener(delegate(bool isOn)
			{
				OnToggleValueChange(item, isOn);
			});
		}
	}

	public void OnToggleValueChange(Toggle toggle, bool isOn)
	{
		switch (toggle.gameObject.name)
		{
		case "skin":
			characterModelInfo.isSkinFalse = isOn;
			break;
		case "notSkin":
			characterModelInfo.isNotSkinFalse = isOn;
			break;
		case "Tachie":
			characterModelInfo.isTachieFalse = isOn;
			break;
		case "headTachie":
			characterModelInfo.isHeadTachieFalse = isOn;
			break;
		case "battleIcon":
			characterModelInfo.isBattleIconFalse = isOn;
			break;
		}
	}
}
