public class ActionOrderRecord
{
	public int objID;

	public ActionType actionType;

	public ActionOrderRecord(int _id = 0, ActionType _actionType = ActionType.None)
	{
		objID = _id;
		actionType = _actionType;
	}
}
