using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CharacterChangeForm : MonoBehaviour
{
	public int currentViewShow;

	public Skeleton m_skeleton;

	private SkinData skinData = new SkinData();

	public HSLColorControl skinColorControl;

	public HSLColorControl eyeColorControl;

	public HSLColorControl clothesColorControl;

	public HSLColorControl HandColorControl;

	public SkeletonGraphic TopSkeletonGraphic;

	public SkeletonGraphic LeftSkeletonGraphic;

	public SkeletonGraphic BackSkeletonGraphic;

	private SkeletonGraphic skeletonGraphic;

	private SkeletonDataAsset _skeletonDataAsset;

	private CharaData curchara;

	private Skin characterSkin;

	private float scaleX;

	private void InitParam()
	{
		SharedData.Instance().CurrentChara = "9001";
		curchara = SharedData.Instance().CurrentCharaData;
		if (curchara != null)
		{
			_skeletonDataAsset = Resources.Load("SkeletonData/" + curchara.m_BattleIcon) as SkeletonDataAsset;
			if (_skeletonDataAsset != null)
			{
				TopSkeletonGraphic.skeletonDataAsset = _skeletonDataAsset;
				LeftSkeletonGraphic.skeletonDataAsset = Resources.Load("SkeletonData/" + curchara.m_BattleIcon + "_Left") as SkeletonDataAsset;
				BackSkeletonGraphic.skeletonDataAsset = Resources.Load("SkeletonData/" + curchara.m_BattleIcon + "_Back") as SkeletonDataAsset;
				TopSkeletonGraphic.Initialize(overwrite: true);
				LeftSkeletonGraphic.Initialize(overwrite: true);
				BackSkeletonGraphic.Initialize(overwrite: true);
				skinData = curchara.m_SkinData;
				skinColorControl.hueSlider.value = skinData.skinHSL.hueValue;
				skinColorControl.saturationSlider.value = skinData.skinHSL.saturationValue;
				skinColorControl.lightnessSlider.value = skinData.skinHSL.lightnessValue;
				HandColorControl.hueSlider.value = skinData.handHSL.hueValue;
				HandColorControl.saturationSlider.value = skinData.handHSL.saturationValue;
				HandColorControl.lightnessSlider.value = skinData.handHSL.lightnessValue;
				eyeColorControl.hueSlider.value = skinData.eyeHSL.hueValue;
				eyeColorControl.saturationSlider.value = skinData.eyeHSL.saturationValue;
				eyeColorControl.lightnessSlider.value = skinData.eyeHSL.lightnessValue;
				clothesColorControl.hueSlider.value = skinData.clothesHSL.hueValue;
				clothesColorControl.saturationSlider.value = skinData.clothesHSL.saturationValue;
				clothesColorControl.lightnessSlider.value = skinData.clothesHSL.lightnessValue;
			}
		}
	}

	private void Start()
	{
		Button[] componentsInChildren = GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		InitParam();
		if (_skeletonDataAsset == null)
		{
			TopSkeletonGraphic.gameObject.SetActive(value: false);
			LeftSkeletonGraphic.gameObject.SetActive(value: false);
			BackSkeletonGraphic.gameObject.SetActive(value: false);
			return;
		}
		scaleX = LeftSkeletonGraphic.Skeleton.ScaleX;
		skinColorControl.OnValueChanged += UpdateUICharacterSkinColor;
		eyeColorControl.OnValueChanged += UpdateUICharacterSkinColor;
		clothesColorControl.OnValueChanged += UpdateUICharacterSkinColor;
		HandColorControl.OnValueChanged += UpdateUICharacterSkinColor;
		UpdateUICharacterSkin();
	}

	private void UpdateUICharacterSkin()
	{
		if (!(_skeletonDataAsset == null))
		{
			switch (currentViewShow)
			{
			case 0:
				skeletonGraphic = TopSkeletonGraphic;
				break;
			case 1:
				skeletonGraphic = LeftSkeletonGraphic;
				LeftSkeletonGraphic.Skeleton.ScaleX = scaleX;
				break;
			case 2:
				skeletonGraphic = BackSkeletonGraphic;
				break;
			case 3:
				skeletonGraphic = LeftSkeletonGraphic;
				LeftSkeletonGraphic.Skeleton.ScaleX = 0f - scaleX;
				break;
			}
			TopSkeletonGraphic.gameObject.SetActive(value: false);
			LeftSkeletonGraphic.gameObject.SetActive(value: false);
			BackSkeletonGraphic.gameObject.SetActive(value: false);
			skeletonGraphic.gameObject.SetActive(value: true);
			skinData.skinHSL.hueValue = skinColorControl.hueSlider.value;
			skinData.skinHSL.saturationValue = skinColorControl.saturationSlider.value;
			skinData.skinHSL.lightnessValue = skinColorControl.lightnessSlider.value;
			skinData.eyeHSL.hueValue = eyeColorControl.hueSlider.value;
			skinData.eyeHSL.saturationValue = eyeColorControl.saturationSlider.value;
			skinData.eyeHSL.lightnessValue = eyeColorControl.lightnessSlider.value;
			skinData.clothesHSL.hueValue = clothesColorControl.hueSlider.value;
			skinData.clothesHSL.saturationValue = clothesColorControl.saturationSlider.value;
			skinData.clothesHSL.lightnessValue = clothesColorControl.lightnessSlider.value;
			skinData.handHSL.hueValue = HandColorControl.hueSlider.value;
			skinData.handHSL.saturationValue = HandColorControl.saturationSlider.value;
			skinData.handHSL.lightnessValue = HandColorControl.lightnessSlider.value;
			SkinManager.Instance().UpdateMenuCharacterSkin(skeletonGraphic, skinData);
		}
	}

	private void UpdateUICharacterSkinColor(Color _color)
	{
		skinData.skinHSL.hueValue = skinColorControl.hueSlider.value;
		skinData.skinHSL.saturationValue = skinColorControl.saturationSlider.value;
		skinData.skinHSL.lightnessValue = skinColorControl.lightnessSlider.value;
		skinData.eyeHSL.hueValue = eyeColorControl.hueSlider.value;
		skinData.eyeHSL.saturationValue = eyeColorControl.saturationSlider.value;
		skinData.eyeHSL.lightnessValue = eyeColorControl.lightnessSlider.value;
		skinData.clothesHSL.hueValue = clothesColorControl.hueSlider.value;
		skinData.clothesHSL.saturationValue = clothesColorControl.saturationSlider.value;
		skinData.clothesHSL.lightnessValue = clothesColorControl.lightnessSlider.value;
		skinData.handHSL.hueValue = HandColorControl.hueSlider.value;
		skinData.handHSL.saturationValue = HandColorControl.saturationSlider.value;
		skinData.handHSL.lightnessValue = HandColorControl.lightnessSlider.value;
		m_skeleton.Slots.Find((Slot x) => x.Data.Name == "head")?.SetColor(skinColorControl.CurrentColor);
		m_skeleton.Slots.Find((Slot x) => x.Data.Name == "eyes")?.SetColor(eyeColorControl.CurrentColor);
		m_skeleton.Slots.Find((Slot x) => x.Data.Name == "clothes")?.SetColor(clothesColorControl.CurrentColor);
		m_skeleton.Slots.Find((Slot x) => x.Data.Name == "hand-2")?.SetColor(HandColorControl.CurrentColor);
		m_skeleton.Slots.Find((Slot x) => x.Data.Name == "hand-1")?.SetColor(HandColorControl.CurrentColor);
		m_skeleton.SetSlotAttachmentsToSetupPose();
		TopSkeletonGraphic.Update(0f);
		LeftSkeletonGraphic.Update(0f);
		BackSkeletonGraphic.Update(0f);
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		if (go.name == "Return")
		{
			ExitScene();
		}
		else if (go.name == "Character")
		{
			OnClickChangeCharacter();
		}
		else if (go.transform.parent.name == "ChangeView")
		{
			if (go.name == "Next")
			{
				currentViewShow = (currentViewShow + 1) % 4;
			}
			else if (go.name == "Prev")
			{
				currentViewShow = (currentViewShow + 4 - 1) % 4;
			}
		}
		else if (go.transform.parent.name == "Face")
		{
			if (go.name == "Next")
			{
				skinData.activeEyesIndex = (skinData.activeEyesIndex + 1) % SkinManager.Instance().eyesSkinsCount;
			}
			else if (go.name == "Prev")
			{
				skinData.activeEyesIndex = (skinData.activeEyesIndex + SkinManager.Instance().eyesSkinsCount - 1) % SkinManager.Instance().eyesSkinsCount;
			}
		}
		else if (go.transform.parent.name == "Clothes")
		{
			if (go.name == "Next")
			{
				skinData.activeClothesIndex = (skinData.activeClothesIndex + 1) % SkinManager.Instance().clothesSkinsCount;
			}
			else if (go.name == "Prev")
			{
				skinData.activeClothesIndex = (skinData.activeClothesIndex + SkinManager.Instance().clothesSkinsCount - 1) % SkinManager.Instance().clothesSkinsCount;
			}
		}
		else if (go.transform.parent.name == "Hand")
		{
			if (go.name == "Next")
			{
				skinData.activeHandIndex = (skinData.activeHandIndex + 1) % SkinManager.Instance().handSkinsCount;
			}
			else if (go.name == "Prev")
			{
				skinData.activeHandIndex = (skinData.activeHandIndex + SkinManager.Instance().handSkinsCount - 1) % SkinManager.Instance().handSkinsCount;
			}
		}
		else if (go.transform.parent.name == "Weapon")
		{
			if (go.name == "Next")
			{
				skinData.activeWeaponIndex = (skinData.activeWeaponIndex + 1) % SkinManager.Instance().handSkinsCount;
			}
			else if (go.name == "Prev")
			{
				skinData.activeWeaponIndex = (skinData.activeWeaponIndex + SkinManager.Instance().handSkinsCount - 1) % SkinManager.Instance().handSkinsCount;
			}
		}
		UpdateUICharacterSkin();
	}

	private void OnClickChangeCharacter()
	{
		if (!(SharedData.Instance().player == null))
		{
			if (SharedData.Instance().player.charadata.m_Id == SharedData.Instance().CurrentChara)
			{
				skinData.isInit = true;
				SharedData.Instance().player.charadata.m_SkinData = skinData;
				SkinManager.Instance().UpdateFieldCharacterSkin(SharedData.Instance().player.gameObject, skinData);
			}
			else
			{
				int index = SharedData.Instance().FollowList.IndexOf(SharedData.Instance().CurrentChara);
				skinData.isInit = true;
				SharedData.Instance().CurrentCharaData.m_SkinData = skinData;
				SkinManager.Instance().UpdateFieldCharacterSkin(SharedData.Instance().player.m_Follows[index].gameObject, skinData);
			}
			SharedData.Instance().LoadSceneStackAdd("BeforeCraft");
			SceneManager.LoadScene("BeforeCraft", LoadSceneMode.Additive);
			SceneManager.UnloadSceneAsync("ChangeForm");
		}
	}

	private void ExitScene()
	{
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			int index = SharedData.Instance().LoadedSceneStack.Count - 1;
			SharedData.Instance().LoadedSceneStack.RemoveAt(index);
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				index = SharedData.Instance().LoadedSceneStack.Count - 1;
				SceneManager.LoadScene(SharedData.Instance().LoadedSceneStack[index], LoadSceneMode.Additive);
			}
		}
		if (SharedData.Instance().player != null)
		{
			if (SharedData.Instance().player.charadata.m_Id == SharedData.Instance().CurrentChara)
			{
				skinData.isInit = true;
				SharedData.Instance().player.charadata.m_SkinData = skinData;
				SkinManager.Instance().UpdateFieldCharacterSkin(SharedData.Instance().player.gameObject, skinData);
			}
			else
			{
				int index2 = SharedData.Instance().FollowList.IndexOf(SharedData.Instance().CurrentChara);
				skinData.isInit = true;
				SharedData.Instance().CurrentCharaData.m_SkinData = skinData;
				SkinManager.Instance().UpdateFieldCharacterSkin(SharedData.Instance().player.m_Follows[index2].gameObject, skinData);
			}
		}
		SceneManager.UnloadSceneAsync("ChangeForm");
	}
}
