using System.Collections.Generic;
using UnityEngine;

public class gang_a02Table
{
	public class Row
	{
		public string ID;

		public string Scenario;

		public string Scenario_EN;

		public string Round;

		public string Role;

		public string Note;

		public string Note_EN;

		public string Name;

		public string Name_EN;

		public string Duty;

		public string Duty_EN;

		public string Kungfu;

		public string Kungfu_EN;

		public string Birthplace;

		public string Birthplace_EN;

		public string Birthdate;

		public string Birthdate_EN;

		public string Age;

		public string Lifecode;

		public string Lifecode_EN;

		public string Position;

		public string Position_EN;

		public string Story;

		public string Story_EN;

		public string Nickname;

		public string Nickname_EN;

		public string Guild;

		public string Guild_EN;

		public string Money;

		public string Kongfu;

		public string GoodAt;

		public string GoodAt_EN;

		public string Features;

		public string LV;

		public string HP;

		public string HP1;

		public string MP;

		public string MP1;

		public string ATK;

		public string ATK1;

		public string DEF;

		public string DEF1;

		public string SP;

		public string SP1;

		public string STR;

		public string STR1;

		public string AGI;

		public string AGI1;

		public string BON;

		public string BON1;

		public string WIL;

		public string WIL1;

		public string LER;

		public string LER1;

		public string MOR;

		public string MOR1;

		public string Sword;

		public string Sword1;

		public string Knife;

		public string Knife1;

		public string Stick;

		public string Stick1;

		public string Hand;

		public string Hand1;

		public string Finger;

		public string Finger1;

		public string Special;

		public string Special1;

		public string YinYang;

		public string YinYang1;

		public string Melody;

		public string Melody1;

		public string Medical;

		public string Medical1;

		public string Darts;

		public string Darts1;

		public string Wineart;

		public string Wineart1;

		public string Steal;

		public string Steal1;

		public string Forge;

		public string Forge1;

		public string Percept;

		public string Percept1;

		public string Scenario_Trans => CommonFunc.ShortLangSel(Scenario, Scenario_EN);

		public string Note_Trans => CommonFunc.ShortLangSel(Note, Note_EN);

		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);

		public string Duty_Trans => CommonFunc.ShortLangSel(Duty, Duty_EN);

		public string Kungfu_Trans => CommonFunc.ShortLangSel(Kungfu, Kungfu_EN);

		public string Birthplace_Trans => CommonFunc.ShortLangSel(Birthplace, Birthplace_EN);

		public string Birthdate_Trans => CommonFunc.ShortLangSel(Birthdate, Birthdate_EN);

		public string Lifecode_Trans => CommonFunc.ShortLangSel(Lifecode, Lifecode_EN);

		public string Position_Trans => CommonFunc.ShortLangSel(Position, Position_EN);

		public string Story_Trans => CommonFunc.ShortLangSel(Story, Story_EN);

		public string Nickname_Trans => CommonFunc.ShortLangSel(Nickname, Nickname_EN);

		public string Guild_Trans => CommonFunc.ShortLangSel(Guild, Guild_EN);

		public string GoodAt_Trans => CommonFunc.ShortLangSel(GoodAt, GoodAt_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Scenario = list[i][num++],
				Round = list[i][num++],
				Role = list[i][num++],
				Note = list[i][num++],
				Name = list[i][num++],
				Duty = list[i][num++],
				Kungfu = list[i][num++],
				Birthplace = list[i][num++],
				Birthdate = list[i][num++],
				Age = list[i][num++],
				Lifecode = list[i][num++],
				Position = list[i][num++],
				Story = list[i][num++],
				Nickname = list[i][num++],
				Guild = list[i][num++],
				Money = list[i][num++],
				Kongfu = list[i][num++],
				GoodAt = list[i][num++],
				Features = list[i][num++],
				LV = list[i][num++],
				HP = list[i][num++],
				HP1 = list[i][num++],
				MP = list[i][num++],
				MP1 = list[i][num++],
				ATK = list[i][num++],
				ATK1 = list[i][num++],
				DEF = list[i][num++],
				DEF1 = list[i][num++],
				SP = list[i][num++],
				SP1 = list[i][num++],
				STR = list[i][num++],
				STR1 = list[i][num++],
				AGI = list[i][num++],
				AGI1 = list[i][num++],
				BON = list[i][num++],
				BON1 = list[i][num++],
				WIL = list[i][num++],
				WIL1 = list[i][num++],
				LER = list[i][num++],
				LER1 = list[i][num++],
				MOR = list[i][num++],
				MOR1 = list[i][num++],
				Sword = list[i][num++],
				Sword1 = list[i][num++],
				Knife = list[i][num++],
				Knife1 = list[i][num++],
				Stick = list[i][num++],
				Stick1 = list[i][num++],
				Hand = list[i][num++],
				Hand1 = list[i][num++],
				Finger = list[i][num++],
				Finger1 = list[i][num++],
				Special = list[i][num++],
				Special1 = list[i][num++],
				YinYang = list[i][num++],
				YinYang1 = list[i][num++],
				Melody = list[i][num++],
				Melody1 = list[i][num++],
				Medical = list[i][num++],
				Medical1 = list[i][num++],
				Darts = list[i][num++],
				Darts1 = list[i][num++],
				Wineart = list[i][num++],
				Wineart1 = list[i][num++],
				Steal = list[i][num++],
				Steal1 = list[i][num++],
				Forge = list[i][num++],
				Forge1 = list[i][num++],
				Percept = list[i][num++],
				Percept1 = list[i][num++]
			};
			row.Scenario = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Scenario")?.zh_CH;
			row.Scenario_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Scenario")?.en_US;
			row.Note = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Note")?.zh_CH;
			row.Note_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Note")?.en_US;
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Name")?.en_US;
			row.Duty = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Duty")?.zh_CH;
			row.Duty_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Duty")?.en_US;
			row.Kungfu = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Kungfu")?.zh_CH;
			row.Kungfu_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Kungfu")?.en_US;
			row.Birthplace = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Birthplace")?.zh_CH;
			row.Birthplace_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Birthplace")?.en_US;
			row.Birthdate = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Birthdate")?.zh_CH;
			row.Birthdate_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Birthdate")?.en_US;
			row.Lifecode = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Lifecode")?.zh_CH;
			row.Lifecode_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Lifecode")?.en_US;
			row.Position = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Position")?.zh_CH;
			row.Position_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Position")?.en_US;
			row.Story = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Story")?.zh_CH;
			row.Story_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Story")?.en_US;
			row.Nickname = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Nickname")?.zh_CH;
			row.Nickname_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Nickname")?.en_US;
			row.Guild = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Guild")?.zh_CH;
			row.Guild_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_Guild")?.en_US;
			row.GoodAt = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_GoodAt")?.zh_CH;
			row.GoodAt_EN = I18nData.Instance().tableI18N.Find_ID("gang_a02_" + row.ID + "_GoodAt")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Scenario(string find)
	{
		return rowList.Find((Row x) => x.Scenario == find);
	}

	public List<Row> FindAll_Scenario(string find)
	{
		return rowList.FindAll((Row x) => x.Scenario == find);
	}

	public Row Find_Round(string find)
	{
		return rowList.Find((Row x) => x.Round == find);
	}

	public List<Row> FindAll_Round(string find)
	{
		return rowList.FindAll((Row x) => x.Round == find);
	}

	public Row Find_Role(string find)
	{
		return rowList.Find((Row x) => x.Role == find);
	}

	public List<Row> FindAll_Role(string find)
	{
		return rowList.FindAll((Row x) => x.Role == find);
	}

	public Row Find_Note(string find)
	{
		return rowList.Find((Row x) => x.Note == find);
	}

	public List<Row> FindAll_Note(string find)
	{
		return rowList.FindAll((Row x) => x.Note == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Duty(string find)
	{
		return rowList.Find((Row x) => x.Duty == find);
	}

	public List<Row> FindAll_Duty(string find)
	{
		return rowList.FindAll((Row x) => x.Duty == find);
	}

	public Row Find_Kungfu(string find)
	{
		return rowList.Find((Row x) => x.Kungfu == find);
	}

	public List<Row> FindAll_Kungfu(string find)
	{
		return rowList.FindAll((Row x) => x.Kungfu == find);
	}

	public Row Find_Birthplace(string find)
	{
		return rowList.Find((Row x) => x.Birthplace == find);
	}

	public List<Row> FindAll_Birthplace(string find)
	{
		return rowList.FindAll((Row x) => x.Birthplace == find);
	}

	public Row Find_Birthdate(string find)
	{
		return rowList.Find((Row x) => x.Birthdate == find);
	}

	public List<Row> FindAll_Birthdate(string find)
	{
		return rowList.FindAll((Row x) => x.Birthdate == find);
	}

	public Row Find_Age(string find)
	{
		return rowList.Find((Row x) => x.Age == find);
	}

	public List<Row> FindAll_Age(string find)
	{
		return rowList.FindAll((Row x) => x.Age == find);
	}

	public Row Find_Lifecode(string find)
	{
		return rowList.Find((Row x) => x.Lifecode == find);
	}

	public List<Row> FindAll_Lifecode(string find)
	{
		return rowList.FindAll((Row x) => x.Lifecode == find);
	}

	public Row Find_Position(string find)
	{
		return rowList.Find((Row x) => x.Position == find);
	}

	public List<Row> FindAll_Position(string find)
	{
		return rowList.FindAll((Row x) => x.Position == find);
	}

	public Row Find_Story(string find)
	{
		return rowList.Find((Row x) => x.Story == find);
	}

	public List<Row> FindAll_Story(string find)
	{
		return rowList.FindAll((Row x) => x.Story == find);
	}

	public Row Find_Nickname(string find)
	{
		return rowList.Find((Row x) => x.Nickname == find);
	}

	public List<Row> FindAll_Nickname(string find)
	{
		return rowList.FindAll((Row x) => x.Nickname == find);
	}

	public Row Find_Guild(string find)
	{
		return rowList.Find((Row x) => x.Guild == find);
	}

	public List<Row> FindAll_Guild(string find)
	{
		return rowList.FindAll((Row x) => x.Guild == find);
	}

	public Row Find_Money(string find)
	{
		return rowList.Find((Row x) => x.Money == find);
	}

	public List<Row> FindAll_Money(string find)
	{
		return rowList.FindAll((Row x) => x.Money == find);
	}

	public Row Find_Kongfu(string find)
	{
		return rowList.Find((Row x) => x.Kongfu == find);
	}

	public List<Row> FindAll_Kongfu(string find)
	{
		return rowList.FindAll((Row x) => x.Kongfu == find);
	}

	public Row Find_GoodAt(string find)
	{
		return rowList.Find((Row x) => x.GoodAt == find);
	}

	public List<Row> FindAll_GoodAt(string find)
	{
		return rowList.FindAll((Row x) => x.GoodAt == find);
	}

	public Row Find_Features(string find)
	{
		return rowList.Find((Row x) => x.Features == find);
	}

	public List<Row> FindAll_Features(string find)
	{
		return rowList.FindAll((Row x) => x.Features == find);
	}

	public Row Find_LV(string find)
	{
		return rowList.Find((Row x) => x.LV == find);
	}

	public List<Row> FindAll_LV(string find)
	{
		return rowList.FindAll((Row x) => x.LV == find);
	}

	public Row Find_HP(string find)
	{
		return rowList.Find((Row x) => x.HP == find);
	}

	public List<Row> FindAll_HP(string find)
	{
		return rowList.FindAll((Row x) => x.HP == find);
	}

	public Row Find_HP1(string find)
	{
		return rowList.Find((Row x) => x.HP1 == find);
	}

	public List<Row> FindAll_HP1(string find)
	{
		return rowList.FindAll((Row x) => x.HP1 == find);
	}

	public Row Find_MP(string find)
	{
		return rowList.Find((Row x) => x.MP == find);
	}

	public List<Row> FindAll_MP(string find)
	{
		return rowList.FindAll((Row x) => x.MP == find);
	}

	public Row Find_MP1(string find)
	{
		return rowList.Find((Row x) => x.MP1 == find);
	}

	public List<Row> FindAll_MP1(string find)
	{
		return rowList.FindAll((Row x) => x.MP1 == find);
	}

	public Row Find_ATK(string find)
	{
		return rowList.Find((Row x) => x.ATK == find);
	}

	public List<Row> FindAll_ATK(string find)
	{
		return rowList.FindAll((Row x) => x.ATK == find);
	}

	public Row Find_ATK1(string find)
	{
		return rowList.Find((Row x) => x.ATK1 == find);
	}

	public List<Row> FindAll_ATK1(string find)
	{
		return rowList.FindAll((Row x) => x.ATK1 == find);
	}

	public Row Find_DEF(string find)
	{
		return rowList.Find((Row x) => x.DEF == find);
	}

	public List<Row> FindAll_DEF(string find)
	{
		return rowList.FindAll((Row x) => x.DEF == find);
	}

	public Row Find_DEF1(string find)
	{
		return rowList.Find((Row x) => x.DEF1 == find);
	}

	public List<Row> FindAll_DEF1(string find)
	{
		return rowList.FindAll((Row x) => x.DEF1 == find);
	}

	public Row Find_SP(string find)
	{
		return rowList.Find((Row x) => x.SP == find);
	}

	public List<Row> FindAll_SP(string find)
	{
		return rowList.FindAll((Row x) => x.SP == find);
	}

	public Row Find_SP1(string find)
	{
		return rowList.Find((Row x) => x.SP1 == find);
	}

	public List<Row> FindAll_SP1(string find)
	{
		return rowList.FindAll((Row x) => x.SP1 == find);
	}

	public Row Find_STR(string find)
	{
		return rowList.Find((Row x) => x.STR == find);
	}

	public List<Row> FindAll_STR(string find)
	{
		return rowList.FindAll((Row x) => x.STR == find);
	}

	public Row Find_STR1(string find)
	{
		return rowList.Find((Row x) => x.STR1 == find);
	}

	public List<Row> FindAll_STR1(string find)
	{
		return rowList.FindAll((Row x) => x.STR1 == find);
	}

	public Row Find_AGI(string find)
	{
		return rowList.Find((Row x) => x.AGI == find);
	}

	public List<Row> FindAll_AGI(string find)
	{
		return rowList.FindAll((Row x) => x.AGI == find);
	}

	public Row Find_AGI1(string find)
	{
		return rowList.Find((Row x) => x.AGI1 == find);
	}

	public List<Row> FindAll_AGI1(string find)
	{
		return rowList.FindAll((Row x) => x.AGI1 == find);
	}

	public Row Find_BON(string find)
	{
		return rowList.Find((Row x) => x.BON == find);
	}

	public List<Row> FindAll_BON(string find)
	{
		return rowList.FindAll((Row x) => x.BON == find);
	}

	public Row Find_BON1(string find)
	{
		return rowList.Find((Row x) => x.BON1 == find);
	}

	public List<Row> FindAll_BON1(string find)
	{
		return rowList.FindAll((Row x) => x.BON1 == find);
	}

	public Row Find_WIL(string find)
	{
		return rowList.Find((Row x) => x.WIL == find);
	}

	public List<Row> FindAll_WIL(string find)
	{
		return rowList.FindAll((Row x) => x.WIL == find);
	}

	public Row Find_WIL1(string find)
	{
		return rowList.Find((Row x) => x.WIL1 == find);
	}

	public List<Row> FindAll_WIL1(string find)
	{
		return rowList.FindAll((Row x) => x.WIL1 == find);
	}

	public Row Find_LER(string find)
	{
		return rowList.Find((Row x) => x.LER == find);
	}

	public List<Row> FindAll_LER(string find)
	{
		return rowList.FindAll((Row x) => x.LER == find);
	}

	public Row Find_LER1(string find)
	{
		return rowList.Find((Row x) => x.LER1 == find);
	}

	public List<Row> FindAll_LER1(string find)
	{
		return rowList.FindAll((Row x) => x.LER1 == find);
	}

	public Row Find_MOR(string find)
	{
		return rowList.Find((Row x) => x.MOR == find);
	}

	public List<Row> FindAll_MOR(string find)
	{
		return rowList.FindAll((Row x) => x.MOR == find);
	}

	public Row Find_MOR1(string find)
	{
		return rowList.Find((Row x) => x.MOR1 == find);
	}

	public List<Row> FindAll_MOR1(string find)
	{
		return rowList.FindAll((Row x) => x.MOR1 == find);
	}

	public Row Find_Sword(string find)
	{
		return rowList.Find((Row x) => x.Sword == find);
	}

	public List<Row> FindAll_Sword(string find)
	{
		return rowList.FindAll((Row x) => x.Sword == find);
	}

	public Row Find_Sword1(string find)
	{
		return rowList.Find((Row x) => x.Sword1 == find);
	}

	public List<Row> FindAll_Sword1(string find)
	{
		return rowList.FindAll((Row x) => x.Sword1 == find);
	}

	public Row Find_Knife(string find)
	{
		return rowList.Find((Row x) => x.Knife == find);
	}

	public List<Row> FindAll_Knife(string find)
	{
		return rowList.FindAll((Row x) => x.Knife == find);
	}

	public Row Find_Knife1(string find)
	{
		return rowList.Find((Row x) => x.Knife1 == find);
	}

	public List<Row> FindAll_Knife1(string find)
	{
		return rowList.FindAll((Row x) => x.Knife1 == find);
	}

	public Row Find_Stick(string find)
	{
		return rowList.Find((Row x) => x.Stick == find);
	}

	public List<Row> FindAll_Stick(string find)
	{
		return rowList.FindAll((Row x) => x.Stick == find);
	}

	public Row Find_Stick1(string find)
	{
		return rowList.Find((Row x) => x.Stick1 == find);
	}

	public List<Row> FindAll_Stick1(string find)
	{
		return rowList.FindAll((Row x) => x.Stick1 == find);
	}

	public Row Find_Hand(string find)
	{
		return rowList.Find((Row x) => x.Hand == find);
	}

	public List<Row> FindAll_Hand(string find)
	{
		return rowList.FindAll((Row x) => x.Hand == find);
	}

	public Row Find_Hand1(string find)
	{
		return rowList.Find((Row x) => x.Hand1 == find);
	}

	public List<Row> FindAll_Hand1(string find)
	{
		return rowList.FindAll((Row x) => x.Hand1 == find);
	}

	public Row Find_Finger(string find)
	{
		return rowList.Find((Row x) => x.Finger == find);
	}

	public List<Row> FindAll_Finger(string find)
	{
		return rowList.FindAll((Row x) => x.Finger == find);
	}

	public Row Find_Finger1(string find)
	{
		return rowList.Find((Row x) => x.Finger1 == find);
	}

	public List<Row> FindAll_Finger1(string find)
	{
		return rowList.FindAll((Row x) => x.Finger1 == find);
	}

	public Row Find_Special(string find)
	{
		return rowList.Find((Row x) => x.Special == find);
	}

	public List<Row> FindAll_Special(string find)
	{
		return rowList.FindAll((Row x) => x.Special == find);
	}

	public Row Find_Special1(string find)
	{
		return rowList.Find((Row x) => x.Special1 == find);
	}

	public List<Row> FindAll_Special1(string find)
	{
		return rowList.FindAll((Row x) => x.Special1 == find);
	}

	public Row Find_YinYang(string find)
	{
		return rowList.Find((Row x) => x.YinYang == find);
	}

	public List<Row> FindAll_YinYang(string find)
	{
		return rowList.FindAll((Row x) => x.YinYang == find);
	}

	public Row Find_YinYang1(string find)
	{
		return rowList.Find((Row x) => x.YinYang1 == find);
	}

	public List<Row> FindAll_YinYang1(string find)
	{
		return rowList.FindAll((Row x) => x.YinYang1 == find);
	}

	public Row Find_Melody(string find)
	{
		return rowList.Find((Row x) => x.Melody == find);
	}

	public List<Row> FindAll_Melody(string find)
	{
		return rowList.FindAll((Row x) => x.Melody == find);
	}

	public Row Find_Melody1(string find)
	{
		return rowList.Find((Row x) => x.Melody1 == find);
	}

	public List<Row> FindAll_Melody1(string find)
	{
		return rowList.FindAll((Row x) => x.Melody1 == find);
	}

	public Row Find_Medical(string find)
	{
		return rowList.Find((Row x) => x.Medical == find);
	}

	public List<Row> FindAll_Medical(string find)
	{
		return rowList.FindAll((Row x) => x.Medical == find);
	}

	public Row Find_Medical1(string find)
	{
		return rowList.Find((Row x) => x.Medical1 == find);
	}

	public List<Row> FindAll_Medical1(string find)
	{
		return rowList.FindAll((Row x) => x.Medical1 == find);
	}

	public Row Find_Darts(string find)
	{
		return rowList.Find((Row x) => x.Darts == find);
	}

	public List<Row> FindAll_Darts(string find)
	{
		return rowList.FindAll((Row x) => x.Darts == find);
	}

	public Row Find_Darts1(string find)
	{
		return rowList.Find((Row x) => x.Darts1 == find);
	}

	public List<Row> FindAll_Darts1(string find)
	{
		return rowList.FindAll((Row x) => x.Darts1 == find);
	}

	public Row Find_Wineart(string find)
	{
		return rowList.Find((Row x) => x.Wineart == find);
	}

	public List<Row> FindAll_Wineart(string find)
	{
		return rowList.FindAll((Row x) => x.Wineart == find);
	}

	public Row Find_Wineart1(string find)
	{
		return rowList.Find((Row x) => x.Wineart1 == find);
	}

	public List<Row> FindAll_Wineart1(string find)
	{
		return rowList.FindAll((Row x) => x.Wineart1 == find);
	}

	public Row Find_Steal(string find)
	{
		return rowList.Find((Row x) => x.Steal == find);
	}

	public List<Row> FindAll_Steal(string find)
	{
		return rowList.FindAll((Row x) => x.Steal == find);
	}

	public Row Find_Steal1(string find)
	{
		return rowList.Find((Row x) => x.Steal1 == find);
	}

	public List<Row> FindAll_Steal1(string find)
	{
		return rowList.FindAll((Row x) => x.Steal1 == find);
	}
}
