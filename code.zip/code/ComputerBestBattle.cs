using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ComputerBestBattle : MonoBehaviour
{
	public CharaData m_enemyCharacterData = new CharaData();

	public CharaData m_playerCharacterData = new CharaData();

	public Dictionary<string, int> getLOOTDict = new Dictionary<string, int>();

	public Dictionary<string, int> getATTRDict = new Dictionary<string, int>();

	public Dictionary<string, int> getTRAITDict = new Dictionary<string, int>();

	public Dictionary<string, int> getITEMDict = new Dictionary<string, int>();

	public Dictionary<string, int> getWUGONGDict = new Dictionary<string, int>();

	public Dictionary<string, int> getEquipDict = new Dictionary<string, int>();

	public List<string> exceptionGetActionList = new List<string>();

	private void Start()
	{
		m_enemyCharacterData.Init(CommonResourcesData.b01.Find_ID("9006"));
		m_playerCharacterData.Init(CommonResourcesData.b01.Find_ID("9006"));
		SharedData.Instance(init: true);
		CalGetItemDict();
		InitPlayerByBornID("1001");
		CalRandomCharacterDataByLevel(99);
	}

	private void Update()
	{
	}

	public void OnButtonClick()
	{
	}

	private void CalGetItemDict()
	{
		foreach (gang_e01Table.Row row3 in CommonResourcesData.e01.GetRowList())
		{
			string[] array = row3.action.Split('|');
			if (array[0] == "GET")
			{
				_ = array[1] == "LOOT";
			}
			if (!(array[0] == "GET"))
			{
				continue;
			}
			Debug.Log(row3.action);
			if (array[1] == "LOOT")
			{
				if (getLOOTDict.ContainsKey(array[2]))
				{
					getLOOTDict[array[2]]++;
				}
				else
				{
					getLOOTDict.Add(array[2], 1);
				}
				foreach (gang_c01Table.Row item in CommonResourcesData.c01.FindAll_ID(array[2]))
				{
					int num = 0;
					string[] array2 = item.QTY.Split('|');
					if (array2.Length > 1)
					{
						int.Parse(array2[0]);
						num = int.Parse(array2[1]) + 1;
					}
					else
					{
						num = int.Parse(array2[0]);
					}
					GetItem(item.Item, num);
				}
			}
			else if (array[1] == "ATTR")
			{
				if (getATTRDict.ContainsKey(array[2]))
				{
					getATTRDict[array[2]] += int.Parse(array[3]);
				}
				else
				{
					getATTRDict.Add(array[2], int.Parse(array[3]));
				}
			}
			else if (array[1] == "TRAIT" && array[2] == "PLAYER")
			{
				string text = "";
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(array[3]);
				if (row == null)
				{
					exceptionGetActionList.Add(row3.action);
					continue;
				}
				text = row.name;
				if (getTRAITDict.ContainsKey(text))
				{
					if (array[4] == "+")
					{
						getTRAITDict[text]++;
					}
					else if (array[4] == "-")
					{
						getTRAITDict[text]--;
					}
				}
				else if (array[4] == "+")
				{
					getTRAITDict.Add(text, 1);
				}
				else if (array[4] == "-")
				{
					getTRAITDict.Add(text, -1);
				}
			}
			else if (array[1] == "ITEM")
			{
				if (array.Length >= 4 && !(array[2] == "ARENA"))
				{
					GetItem(array[2], int.Parse(array[3]));
				}
			}
			else
			{
				if (!(array[1] == "WUGONG"))
				{
					continue;
				}
				string text2 = "";
				gang_b03Table.Row row2 = CommonResourcesData.b03.Find_ID(array[3]);
				if (row2 == null)
				{
					exceptionGetActionList.Add(row3.action);
					continue;
				}
				text2 = row2.Name_Trans;
				if (getWUGONGDict.ContainsKey(text2))
				{
					if (array[4] == "+")
					{
						getWUGONGDict[text2]++;
					}
					else if (array[4] == "-")
					{
						getWUGONGDict[text2]--;
					}
				}
				else if (array[4] == "+")
				{
					getWUGONGDict.Add(text2, 1);
				}
				else if (array[4] == "-")
				{
					getWUGONGDict.Add(text2, -1);
				}
			}
		}
	}

	private void GetItem(string _id, int _num)
	{
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_id);
		if (row == null)
		{
			return;
		}
		string text = "";
		text = row.Name;
		bool flag = false;
		if (row.Relateid != "0")
		{
			gang_b03Table.Row row2 = CommonResourcesData.b03.Find_ID(row.Relateid);
			gang_b02Table.Row row3 = CommonResourcesData.b02.Find_ID(row.Relateid);
			if (row2 != null)
			{
				if (getWUGONGDict.ContainsKey(row2.Name_Trans))
				{
					getWUGONGDict[row2.Name_Trans] += _num;
				}
				else
				{
					getWUGONGDict.Add(row2.Name_Trans, _num);
				}
				flag = true;
			}
			else if (row3 != null)
			{
				if (getEquipDict.ContainsKey(row3.Name))
				{
					getEquipDict[row3.Name] += _num;
				}
				else
				{
					getEquipDict.Add(row3.Name, _num);
				}
				flag = true;
			}
		}
		if (!flag)
		{
			if (getITEMDict.ContainsKey(text))
			{
				getITEMDict[text] += _num;
			}
			else
			{
				getITEMDict.Add(text, _num);
			}
		}
	}

	private void CalBestComb()
	{
	}

	private void InitPlayerByBornID(string _id)
	{
		gang_a02Table.Row row = CommonResourcesData.a02.Find_ID(_id);
		m_playerCharacterData.Indexs_Name["HP"].bornValue = (int.Parse(row.HP) + int.Parse(row.HP1)) / 2;
		m_playerCharacterData.Indexs_Name["MP"].bornValue = (int.Parse(row.MP) + int.Parse(row.MP)) / 2;
		m_playerCharacterData.Indexs_Name["ATK"].bornValue = (int.Parse(row.ATK) + int.Parse(row.ATK1)) / 2;
		m_playerCharacterData.Indexs_Name["DEF"].bornValue = (int.Parse(row.DEF) + int.Parse(row.DEF1)) / 2;
		m_playerCharacterData.Indexs_Name["SP"].bornValue = (int.Parse(row.SP) + int.Parse(row.SP1)) / 2;
		m_playerCharacterData.Indexs_Name["STR"].bornValue = (int.Parse(row.STR) + int.Parse(row.STR1)) / 2;
		m_playerCharacterData.Indexs_Name["AGI"].bornValue = (int.Parse(row.AGI) + int.Parse(row.AGI1)) / 2;
		m_playerCharacterData.Indexs_Name["BON"].bornValue = (int.Parse(row.BON) + int.Parse(row.BON1)) / 2;
		m_playerCharacterData.Indexs_Name["WIL"].bornValue = (int.Parse(row.WIL) + int.Parse(row.WIL1)) / 2;
		m_playerCharacterData.Indexs_Name["LER"].bornValue = (int.Parse(row.LER) + int.Parse(row.LER1)) / 2;
		m_playerCharacterData.Indexs_Name["Sword"].bornValue = (int.Parse(row.Sword) + int.Parse(row.Sword1)) / 2;
		m_playerCharacterData.Indexs_Name["Knife"].bornValue = (int.Parse(row.Knife) + int.Parse(row.Knife1)) / 2;
		m_playerCharacterData.Indexs_Name["Stick"].bornValue = (int.Parse(row.Stick) + int.Parse(row.Stick1)) / 2;
		m_playerCharacterData.Indexs_Name["Hand"].bornValue = (int.Parse(row.Hand) + int.Parse(row.Hand1)) / 2;
		m_playerCharacterData.Indexs_Name["Finger"].bornValue = (int.Parse(row.Finger) + int.Parse(row.Finger1)) / 2;
		m_playerCharacterData.Indexs_Name["Special"].bornValue = (int.Parse(row.Special) + int.Parse(row.Special1)) / 2;
		m_playerCharacterData.Indexs_Name["YinYang"].bornValue = (int.Parse(row.YinYang) + int.Parse(row.YinYang1)) / 2;
		m_playerCharacterData.Indexs_Name["Melody"].bornValue = (int.Parse(row.Melody) + int.Parse(row.Melody1)) / 2;
		m_playerCharacterData.Indexs_Name["Medical"].bornValue = (int.Parse(row.Medical) + int.Parse(row.Medical1)) / 2;
		m_playerCharacterData.Indexs_Name["Darts"].bornValue = (int.Parse(row.Darts) + int.Parse(row.Darts1)) / 2;
		m_playerCharacterData.Indexs_Name["Wineart"].bornValue = (int.Parse(row.Wineart) + int.Parse(row.Wineart1)) / 2;
		m_playerCharacterData.Indexs_Name["Steal"].bornValue = (int.Parse(row.Steal) + int.Parse(row.Steal1)) / 2;
		KongFuData kongFuData = new KongFuData();
		kongFuData.kf = CommonResourcesData.b03.Find_ID(row.Kongfu);
		kongFuData.lv = int.Parse(kongFuData.kf.LV);
		m_playerCharacterData.KongFuListAdd(kongFuData);
		List<string> list = row.Features.Split("|").ToList();
		List<int> list2 = new List<int>();
		while (list2.Count != 3)
		{
			int item = UnityEngine.Random.Range(0, list.Count);
			if (!list2.Contains(item))
			{
				list2.Add(item);
			}
		}
		foreach (int item2 in list2)
		{
			m_playerCharacterData.AddTraits(list[item2]);
		}
	}

	private void CalRandomCharacterDataByLevel(int _lv)
	{
		float num = 0.2f;
		float num2 = (float)((_lv + 1) / 5) * 0.2f + 1.96f * MathF.Sqrt((float)((_lv + 1) / 5) * num * (1f - num));
		_ = (_lv + 1) / 5;
		MathF.Sqrt((float)((_lv + 1) / 5) * num * (1f - num));
		float num3 = (float)_lv * 0.2f + 1.96f * MathF.Sqrt((float)_lv * num * (1f - num));
		MathF.Sqrt((float)_lv * num * (1f - num));
		float num4 = num2;
		float num5 = num3;
		m_playerCharacterData.Indexs_Name["HP"].bornValue += 20 * _lv;
		m_playerCharacterData.Indexs_Name["MP"].bornValue += 20 * _lv;
		m_playerCharacterData.Indexs_Name["ATK"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["DEF"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["SP"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["STR"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["AGI"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["BON"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["WIL"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["LER"].bornValue += num4;
		m_playerCharacterData.Indexs_Name["Sword"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Knife"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Stick"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Hand"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Finger"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Special"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["YinYang"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Melody"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Medical"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Darts"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Wineart"].bornValue += num5;
		m_playerCharacterData.Indexs_Name["Steal"].bornValue += num5;
	}
}
