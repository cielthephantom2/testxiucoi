public enum SkillInfoType
{
	Basic,
	Skill
}
