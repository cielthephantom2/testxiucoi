using System.Collections;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ForcePlayToNext : MonoBehaviour
{
	private string m_NextScene = "Caution";

	private SkeletonAnimation m_Animations;

	private bool isExiting;

	private bool isAnimationEnd;

	private void Start()
	{
		m_Animations = GetComponentInChildren<SkeletonAnimation>(includeInactive: true);
		if (m_Animations != null)
		{
			m_Animations.AnimationState.Complete += State_Complete;
		}
		StartCoroutine(LoadAllResource());
	}

	private void Update()
	{
		if (!isExiting && CommonResourcesData.isLoadAllResources && isAnimationEnd)
		{
			isExiting = true;
			SceneManager.LoadSceneAsync(m_NextScene);
		}
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		isAnimationEnd = true;
	}

	private IEnumerator AsyncLoading()
	{
		isExiting = true;
		m_Animations.gameObject.SetActive(value: false);
		yield return new WaitForSeconds(0.1f);
		SceneManager.LoadSceneAsync(m_NextScene);
	}

	private IEnumerator LoadAllResource()
	{
		yield return new WaitForSeconds(1f);
		SharedData.Instance(init: true);
	}
}
