using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class IronMan : MonoBehaviour
{
	public AtomData atomData = new AtomData();

	public int rndValue;

	public int addValue;

	public int talentValue;

	private Transform Hover;

	public void Init(AtomData _atomData = null, CharaData _charaData = null)
	{
		if (Hover == null)
		{
			Hover = base.transform.Find("Hover");
		}
		if (_atomData != null)
		{
			atomData = _atomData;
		}
		if (atomData != null && !atomData.a01Name.Equals("") && Hover != null)
		{
			string text = "";
			string text2 = "";
			string text3 = "";
			float num = atomData.totalValue;
			if (_charaData != null)
			{
				num = _charaData.GetFieldValueByName(atomData.a01Name);
			}
			float num2 = float.Parse(SharedData.Instance().m_A01NameRowDirec[atomData.a01Name].Limit, CultureInfo.InvariantCulture);
			Hover.Find("Name/Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[atomData.a01Name].NameScene_Trans + ":" + num + "/" + num2;
			if (atomData.talentValue == 0f)
			{
				Hover.Find("TextArea/Basic").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Basic_Attr_1"), atomData.basicValue);
			}
			else
			{
				Hover.Find("TextArea/Basic").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Basic_Attr_2"), atomData.basicValue, atomData.rollValue + atomData.levelupValue, atomData.talentValue);
			}
			Hover.Find("TextArea/Additional").gameObject.SetActive(atomData.alterValue != 0f || atomData.juqingValue != 0f);
			float num3 = atomData.basicValue + atomData.wupinAndJuqingValue - num2;
			if (num3 > 0f && atomData.wupinAndJuqingValue > 0f)
			{
				text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Overflow_Attr"), num3);
			}
			Hover.Find("TextArea/Additional").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Item_Story_Attr"), atomData.wupinAndJuqingValue, atomData.alterValue, atomData.juqingValue) + " " + text;
			float equipValue = atomData.equipValue;
			float num4 = atomData.equipTraitValue;
			if (_charaData == null)
			{
				num4 = atomData.traitValue;
			}
			Hover.Find("TextArea/EquipAndTrait").gameObject.SetActive(equipValue != 0f || num4 != 0f);
			float num5 = atomData.basicValue + atomData.wupinAndJuqingValue + equipValue + num4 - num2;
			if (num5 > 0f && equipValue + num4 > 0f)
			{
				text2 = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Overflow_Attr"), num5);
			}
			Hover.Find("TextArea/EquipAndTrait").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Equip_Trait_Attr"), equipValue + num4, equipValue, num4) + " " + text2;
			float wugongValue = atomData.wugongValue;
			Hover.Find("TextArea/Wugong").gameObject.SetActive(wugongValue != 0f);
			float num6 = atomData.basicValue + atomData.wupinAndJuqingValue + equipValue + num4 + wugongValue - num2;
			if (num6 > 0f && equipValue + num4 > 0f)
			{
				text3 = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Overflow_Attr"), num6);
			}
			Hover.Find("TextArea/Wugong").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_Wugong_Attr"), wugongValue) + " " + text3;
			Hover.Find("Text").GetComponent<Text>().text = SharedData.Instance().m_A01NameRowDirec[atomData.a01Name].Note_Trans;
		}
	}
}
