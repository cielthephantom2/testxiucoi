using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

public class SelectorController : MonoBehaviour
{
	private MapController mapcontroller;

	private Button[] btnobjs;

	private GameObject nameobj;

	private GameObject askobj;

	private int enableBtnCount;

	private RectTransform rectTransform;

	private float _delayTime;

	private float delayTime;

	private bool drySelector;

	private void Awake()
	{
		rectTransform = GetComponent<RectTransform>();
		enableBtnCount = 0;
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
		nameobj = base.transform.Find("Name").gameObject;
		askobj = base.transform.Find("Ask").gameObject;
		btnobjs = base.gameObject.GetComponentsInChildren<Button>(includeInactive: true);
		Button[] array = btnobjs;
		for (int i = 0; i < array.Length; i++)
		{
			EventTriggerListener.Get(array[i].gameObject).onClick = OnButtonClick;
		}
	}

	private void Update()
	{
		_delayTime += Time.deltaTime;
		if (!InputDeviceDetector.instance.isMouseInput && EventSystem.current.GetComponent<InputSystemUIInputModule>().actionsAsset.FindAction("UI/Navigate").IsPressed() && EventSystem.current.currentSelectedGameObject == null)
		{
			EventSystem.current.SetSelectedGameObject(btnobjs[0].gameObject);
		}
		if (InputDeviceDetector.instance.isMouseInput)
		{
			EventSystem.current.SetSelectedGameObject(null);
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || (_delayTime < delayTime && !InputDeviceDetector.instance.isMouseInput))
		{
			return;
		}
		if (drySelector)
		{
			string[] array = go.name.Split("#");
			if (array.Length > 1)
			{
				SharedData.Instance().CurrentChara = array[1];
				SharedData.Instance().FlagList[array[0] + "_OPERATOR"] = 1;
				Close();
				Button[] array2 = btnobjs;
				for (int i = 0; i < array2.Length; i++)
				{
					array2[i].gameObject.SetActive(value: false);
				}
			}
		}
		else if (SharedData.Instance().FlagList.ContainsKey(go.name))
		{
			mapcontroller.ChatLog("<color=#c7471a>【" + CommonFunc.I18nGetLocalizedValue("I18N_Select") + "】：" + go.GetComponentInChildren<Text>().text + "</color>");
			SharedData.Instance().FlagList[go.name] = 1;
			Close();
			Button[] array2 = btnobjs;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].gameObject.SetActive(value: false);
			}
		}
		else
		{
			Debug.LogWarning("NOT found selected flagid: " + go.name);
		}
	}

	public void Open(string _name, string _ask, string _flag, string _buttons, int _dry_btn = 0)
	{
		base.gameObject.SetActive(value: true);
		Vector2 sizeDelta = rectTransform.sizeDelta;
		rectTransform.sizeDelta = new Vector2(sizeDelta.x, 280f);
		drySelector = _dry_btn > 0;
		Button[] array = btnobjs;
		foreach (Button obj in array)
		{
			obj.name = "Choice";
			obj.GetComponentInChildren<Text>().text = "";
			obj.GetComponent<Button>().interactable = false;
		}
		nameobj.GetComponentInChildren<Text>().text = _name;
		string text = CommonResourcesData.e02.Find_chatid("DEFAULE_SELECTOR").chating_Trans;
		if (!_ask.Equals("null"))
		{
			gang_e02Table.Row row = CommonResourcesData.e02.Find_chatid(_ask);
			if (row != null)
			{
				string chating_Trans = row.chating_Trans;
				if (!"0".Equals(chating_Trans))
				{
					text = chating_Trans;
				}
			}
		}
		MonoBehaviour.print("_ask: " + _ask + ", ask_str: " + text);
		askobj.GetComponentInChildren<Text>().text = mapcontroller.FormatDynamicText(text);
		string[] array2 = _buttons.Split('&');
		int num = 0;
		string[] array3 = array2;
		foreach (string text2 in array3)
		{
			switch (_dry_btn)
			{
			case 1:
			{
				CharaData charaData2 = SharedData.Instance().GetCharaData(text2);
				if (charaData2 != null)
				{
					int num2 = (int)charaData2.GetFieldValueByName("Forge");
					int num3 = (int)Mathf.Clamp((float)num2 / 30f, 1f, 10f);
					btnobjs[num].GetComponentInChildren<Text>(includeInactive: true).text = charaData2.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_Forge") + " " + num2 + " " + CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_Limit_Level") + " " + num3;
					btnobjs[num].name = _flag + "#" + text2;
					btnobjs[num].GetComponent<Button>().interactable = true;
					btnobjs[num].gameObject.SetActive(value: true);
					if (num >= 3)
					{
						sizeDelta = rectTransform.sizeDelta;
						rectTransform.sizeDelta = new Vector2(sizeDelta.x, sizeDelta.y + 60f);
					}
					num++;
				}
				continue;
			}
			case 2:
			{
				CharaData charaData3 = SharedData.Instance().GetCharaData(text2);
				if (charaData3 != null)
				{
					int num4 = (int)charaData3.GetFieldValueByName("Percept");
					int num5 = 3 + num4 / 100;
					btnobjs[num].GetComponentInChildren<Text>(includeInactive: true).text = charaData3.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_Percept") + " " + num4 + " " + CommonFunc.I18nGetLocalizedValue("I18N_StarLimit") + " " + num5;
					btnobjs[num].name = _flag + "#" + text2;
					btnobjs[num].GetComponent<Button>().interactable = true;
					btnobjs[num].gameObject.SetActive(value: true);
					if (num >= 3)
					{
						sizeDelta = rectTransform.sizeDelta;
						rectTransform.sizeDelta = new Vector2(sizeDelta.x, sizeDelta.y + 60f);
					}
					num++;
				}
				continue;
			}
			case 3:
			{
				CharaData charaData = SharedData.Instance().GetCharaData(text2);
				if (charaData != null)
				{
					btnobjs[num].GetComponentInChildren<Text>(includeInactive: true).text = charaData.Indexs_Name["Name"].stringValue;
					btnobjs[num].name = _flag + "#" + text2;
					btnobjs[num].GetComponent<Button>().interactable = true;
					btnobjs[num].gameObject.SetActive(value: true);
					if (num >= 3)
					{
						sizeDelta = rectTransform.sizeDelta;
						rectTransform.sizeDelta = new Vector2(sizeDelta.x, sizeDelta.y + 60f);
					}
					num++;
				}
				continue;
			}
			}
			gang_e02Table.Row row2 = CommonResourcesData.e02.Find_chatid(text2);
			if (row2 != null)
			{
				btnobjs[num].GetComponentInChildren<Text>(includeInactive: true).text = mapcontroller.FormatDynamicText(row2.chating_Trans);
				btnobjs[num].name = _flag + "_" + (num + 1);
				btnobjs[num].GetComponent<Button>().interactable = true;
				btnobjs[num].gameObject.SetActive(value: true);
				if (num >= 3)
				{
					sizeDelta = rectTransform.sizeDelta;
					rectTransform.sizeDelta = new Vector2(sizeDelta.x, sizeDelta.y + 60f);
				}
				num++;
			}
		}
		if (num <= 2)
		{
			btnobjs[2].gameObject.SetActive(value: true);
		}
		enableBtnCount = num;
		if (!InputDeviceDetector.instance.isMouseInput)
		{
			Object.DestroyImmediate(InputDeviceDetector.instance.JoyCursor?.gameObject);
			EventSystem.current.SetSelectedGameObject(null);
		}
		else
		{
			EventSystem.current.SetSelectedGameObject(btnobjs[0].gameObject);
		}
		_delayTime = 0f;
	}

	public void Close()
	{
		base.gameObject.SetActive(value: false);
		mapcontroller.CloseTachie();
	}
}
