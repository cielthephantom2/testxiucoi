using UnityEngine;
using UnityEngine.UI;

public class JoyTouchController : MonoBehaviour
{
	private int isHaveEvent;

	private Sprite m_JoyTouch_Normal;

	private Sprite m_JoyTouch_Notice;

	private Sprite m_JoyTouch_Talk;

	private Sprite m_JoyTouch_Want;

	private Sprite m_JoyTouch_Item;

	private Image image;

	private MapController mapcontroller;

	private Vector3Int playerPositon;

	private Vector3Int playerFacePositon;

	private void Start()
	{
		isHaveEvent = 0;
		m_JoyTouch_Normal = Resources.Load("images/09-VirtualJoyStick/Mobile-Click-off-20220105", typeof(Sprite)) as Sprite;
		m_JoyTouch_Notice = Resources.Load("images/09-VirtualJoyStick/Mobile-Click-on-20220105", typeof(Sprite)) as Sprite;
		m_JoyTouch_Talk = Resources.Load("images/09-VirtualJoyStick/Mobile-Click-talk-20220105", typeof(Sprite)) as Sprite;
		m_JoyTouch_Want = Resources.Load("images/09-VirtualJoyStick/Mobile-Click-wanted-20220105", typeof(Sprite)) as Sprite;
		m_JoyTouch_Item = Resources.Load("images/09-VirtualJoyStick/Mobile-Click-item-20220105", typeof(Sprite)) as Sprite;
		image = base.gameObject.GetComponent<Image>();
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
	}

	private void OnDisable()
	{
		if (image != null)
		{
			image.sprite = m_JoyTouch_Normal;
		}
	}

	private void Update()
	{
		playerPositon = SharedData.Instance().player.GetGridPosition();
		switch (SharedData.Instance().player.m_Direction)
		{
		case Direction.Left:
			playerFacePositon = playerPositon + Vector3Int.right;
			break;
		case Direction.Up:
			playerFacePositon = playerPositon + Vector3Int.down;
			break;
		case Direction.Right:
			playerFacePositon = playerPositon + Vector3Int.left;
			break;
		case Direction.Down:
			playerFacePositon = playerPositon + Vector3Int.up;
			break;
		}
		isHaveEvent = mapcontroller.isPositionHaveEvent(playerFacePositon);
		switch (isHaveEvent)
		{
		case 1:
			image.sprite = m_JoyTouch_Item;
			break;
		case 2:
			image.sprite = m_JoyTouch_Talk;
			break;
		case 3:
			image.sprite = m_JoyTouch_Want;
			break;
		case 4:
			image.sprite = m_JoyTouch_Notice;
			break;
		default:
			image.sprite = m_JoyTouch_Normal;
			break;
		}
	}

	public void OnButtonClick()
	{
		if (isHaveEvent != 0)
		{
			mapcontroller.ClickPosition(playerFacePositon, _isKey: true);
		}
	}
}
