using UnityEngine;
using UnityEngine.UI;

public class TraitIconController : MonoBehaviour
{
	public TraitItemData traitItemData = new TraitItemData();

	private bool isPackage;

	private void OnEnable()
	{
		base.transform.Find("FullName").gameObject.SetActive(SharedData.Instance().isShowFullName);
	}

	private void OnDisable()
	{
		if (isPackage)
		{
			base.gameObject.name = "Trait|null|null";
		}
	}

	public void InitTraitIcon(string _id, string _showIndex = "", bool isChain = false)
	{
		gang_b06Table.Row b06Row = CommonResourcesData.b06.Find_id(_id);
		TraitItemData traitItemData = new TraitItemData
		{
			b06Row = b06Row,
			showIndex = _showIndex
		};
		InitTraitIcon(traitItemData, isChain);
	}

	public void InitTraitIcon(TraitItemData _traitItemData, bool isChain = false, bool checkused = false, bool reName = false)
	{
		if (checkused)
		{
			isPackage = true;
		}
		base.transform.Find("Num").gameObject.SetActive(value: true);
		base.transform.Find("BGNormal").gameObject.SetActive(value: false);
		base.transform.Find("BGChain").gameObject.SetActive(value: false);
		base.transform.Find("BGLock").gameObject.SetActive(value: false);
		base.transform.Find("Index").gameObject.SetActive(value: false);
		base.transform.Find("Lock").gameObject.SetActive(value: false);
		base.transform.Find("Used").gameObject.SetActive(value: false);
		base.transform.Find("FullName").gameObject.SetActive(SharedData.Instance().isShowFullName);
		traitItemData.b06Row = _traitItemData.b06Row;
		traitItemData.showIndex = _traitItemData.showIndex;
		string text = "";
		string text2 = "";
		string text3 = traitItemData.showIndex;
		if (traitItemData.b06Row != null)
		{
			text = traitItemData.b06Row.name_Trans;
			base.transform.Find("BGNormal").gameObject.SetActive(value: true);
			text2 = traitItemData.b06Row.name[0].ToString();
			text3 = traitItemData.b06Row.traitEquipIndex;
			if (traitItemData.b06Row.isLockTrait == "1")
			{
				base.transform.Find("BGLock").gameObject.SetActive(value: true);
				base.transform.Find("Lock").gameObject.SetActive(value: true);
			}
			if (checkused)
			{
				base.transform.Find("Used").gameObject.SetActive(SharedData.Instance().m_TraitPackageController.usedTraitIDList.Contains(traitItemData.b06Row.id));
			}
		}
		base.transform.Find("Text").GetComponent<Text>().text = text2;
		base.transform.Find("Index/Text").GetComponent<Text>().text = text3;
		base.transform.Find("FullName/Text").GetComponent<Text>().text = text;
		if (isChain)
		{
			base.transform.Find("BGChain").gameObject.SetActive(value: true);
		}
		if (traitItemData.showIndex != "" && (traitItemData.b06Row != null || isChain))
		{
			string text4 = "";
			text4 = ((!traitItemData.showIndex.Equals("1&2&3&4&5&6&7&8&9")) ? CommonFunc.ConvertToChineseNumber(int.Parse(traitItemData.showIndex.Split("&")[0])) : CommonFunc.ConvertToChineseNumber(0));
			base.transform.Find("Index/Text").GetComponent<Text>().text = text4;
			base.transform.Find("Index").gameObject.SetActive(value: true);
		}
		if (reName)
		{
			base.gameObject.name = "Trait|" + ((traitItemData.b06Row != null) ? (traitItemData.b06Row.traitEquipIndex + "|" + traitItemData.b06Row.id) : "null|null");
		}
	}
}
