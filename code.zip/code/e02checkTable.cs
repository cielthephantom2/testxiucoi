using System.Collections.Generic;
using UnityEngine;

public class e02checkTable
{
	public class Row
	{
		public string ChineseSimplified1;

		public string English1;

		public string ChineseSimplified2;

		public string English2;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			Row row = new Row();
			row.ChineseSimplified1 = list[i][0];
			row.English1 = list[i][1];
			row.ChineseSimplified2 = list[i][2];
			row.English2 = list[i][3];
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ChineseSimplified1(string find)
	{
		return rowList.Find((Row x) => x.ChineseSimplified1 == find);
	}

	public List<Row> FindAll_ChineseSimplified1(string find)
	{
		return rowList.FindAll((Row x) => x.ChineseSimplified1 == find);
	}

	public Row Find_English1(string find)
	{
		return rowList.Find((Row x) => x.English1 == find);
	}

	public List<Row> FindAll_English1(string find)
	{
		return rowList.FindAll((Row x) => x.English1 == find);
	}

	public Row Find_ChineseSimplified2(string find)
	{
		return rowList.Find((Row x) => x.ChineseSimplified2 == find);
	}

	public List<Row> FindAll_ChineseSimplified2(string find)
	{
		return rowList.FindAll((Row x) => x.ChineseSimplified2 == find);
	}

	public Row Find_English2(string find)
	{
		return rowList.Find((Row x) => x.English2 == find);
	}

	public List<Row> FindAll_English2(string find)
	{
		return rowList.FindAll((Row x) => x.English2 == find);
	}
}
