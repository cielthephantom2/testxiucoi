using System.Collections;
using UnityEngine;

public class CurcorController : MonoBehaviour
{
	public BattleObject selected;

	private BattleController m_BattleController;

	private MenuController m_MenuController;

	private Vector3Int m_gridPos = Vector3Int.zero;

	private Vector3 m_DownPos = Vector3.zero;

	private float timemark;

	private Vector3 posmark = Vector3.zero;

	private bool m_MouseDown;

	private bool m_MouseDownAttackRange;

	private bool m_MouseDownMoveMap;

	public Vector3Int? m_RemoteFirstClickPos;

	public void SetSortingOrder(int _sortingorder)
	{
		base.gameObject.GetComponentInChildren<SpriteRenderer>().sortingOrder = _sortingorder;
	}

	private void Update()
	{
		if (SharedData.Instance().m_BattleController == null || SharedData.Instance().m_MenuController == null)
		{
			return;
		}
		m_BattleController = SharedData.Instance().m_BattleController;
		m_MenuController = m_BattleController.m_MenuController;
		if (m_BattleController.IsSaveRoundRecordRunning || m_BattleController.IsLoadRoundRecordRunning || m_BattleController.isLostControl || m_BattleController.AutoBattle || CommonFunc.IsHoverOpen() || SharedData.Instance().CheckGuiRaycastObjects())
		{
			return;
		}
		if (InputSystemCustom.Instance().Player.ShowHp.IsPressed())
		{
			m_BattleController.ShowAllHpGuage(isShowActionOrder: true);
		}
		else if (InputSystemCustom.Instance().Player.ShowHp.WasReleasedThisFrame())
		{
			m_BattleController.HideAllHpGuage();
		}
		if (m_BattleController.m_Flow == BattleControllerFlow.MoveWait || m_BattleController.m_Flow == BattleControllerFlow.ActionWait || m_BattleController.m_Flow == BattleControllerFlow.PlayerMenuClick)
		{
			m_MenuController.FlowStatusHoverCheck();
		}
		if (!InputDeviceDetector.instance.isMouseInput)
		{
			return;
		}
		if (m_BattleController.m_Flow == BattleControllerFlow.MoveWait || m_BattleController.m_Flow == BattleControllerFlow.ActionWait)
		{
			if (Input.GetMouseButtonDown(0))
			{
				m_DownPos = Input.mousePosition;
				timemark = 0f;
				posmark = m_DownPos;
				m_BattleController.ShowAllHpGuage();
				m_MouseDown = true;
			}
			else
			{
				if (!m_MouseDown)
				{
					return;
				}
				if (Input.GetMouseButton(0) && Input.touchCount != 2)
				{
					Vector3 mousePosition = Input.mousePosition;
					float num = Camera.main.orthographicSize * 16f / 9f;
					float orthographicSize = Camera.main.orthographicSize;
					float num2 = m_BattleController.map.m_Width * m_BattleController.map.m_TileWidth;
					float num3 = -m_BattleController.map.m_Height * m_BattleController.map.m_TileHeight;
					Vector3 cameraTrans = Camera.main.transform.position + (m_DownPos - mousePosition) * 0.55f;
					if (cameraTrans.x - num <= 0f)
					{
						cameraTrans.x = num;
					}
					else if (cameraTrans.x + num >= num2)
					{
						cameraTrans.x = num2 - num;
					}
					if (cameraTrans.y + orthographicSize >= 0f)
					{
						cameraTrans.y = 0f - orthographicSize;
					}
					else if (cameraTrans.y - orthographicSize <= num3)
					{
						cameraTrans.y = num3 + orthographicSize;
					}
					m_BattleController.SetCameraTrans(cameraTrans);
					m_DownPos = mousePosition;
					timemark += Time.deltaTime;
				}
				else if (Input.GetMouseButtonUp(0))
				{
					float magnitude = (m_DownPos - posmark).magnitude;
					if (timemark < 0.3f && (magnitude < 10f || m_BattleController.m_Flow == BattleControllerFlow.MoveWait))
					{
						Vector3Int vector3Int = m_BattleController.tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
						base.transform.position = new Vector3(25 + vector3Int.x * 50, -25 + vector3Int.y * 50);
						CurcorPosition(new Vector3Int(vector3Int.x, -vector3Int.y, 0));
					}
					m_BattleController.HideAllHpGuage();
					m_MouseDown = false;
				}
			}
		}
		else
		{
			if (m_BattleController.m_Flow != BattleControllerFlow.ActionWaitAttack)
			{
				return;
			}
			Vector3Int vector3Int2 = m_BattleController.tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
			base.transform.position = new Vector3(25 + vector3Int2.x * 50, -25 + vector3Int2.y * 50);
			Vector3Int pos = new Vector3Int(vector3Int2.x, -vector3Int2.y, 0);
			if (!m_gridPos.Equals(vector3Int2))
			{
				m_gridPos = vector3Int2;
				CurcorPosition(pos, pressing: true);
				m_BattleController.ShowHpGaugeInAttackRange();
				m_MouseDownAttackRange = true;
			}
			if (Input.GetMouseButtonDown(0))
			{
				m_DownPos = Input.mousePosition;
				timemark = 0f;
				posmark = m_DownPos;
				m_BattleController.ShowAllHpGuage();
				m_MouseDown = true;
				return;
			}
			if (m_MouseDown && Input.GetMouseButton(0))
			{
				Vector3 mousePosition2 = Input.mousePosition;
				float magnitude2 = (mousePosition2 - posmark).magnitude;
				if (!(timemark < 0.1f) || !(magnitude2 < 1f))
				{
					m_MouseDownMoveMap = true;
					float num4 = Camera.main.orthographicSize * 16f / 9f;
					float orthographicSize2 = Camera.main.orthographicSize;
					float num5 = m_BattleController.map.m_Width * m_BattleController.map.m_TileWidth;
					float num6 = -m_BattleController.map.m_Height * m_BattleController.map.m_TileHeight;
					Vector3 cameraTrans2 = Camera.main.transform.position + (m_DownPos - mousePosition2) * 0.55f;
					if (cameraTrans2.x - num4 <= 0f)
					{
						cameraTrans2.x = num4;
					}
					else if (cameraTrans2.x + num4 >= num5)
					{
						cameraTrans2.x = num5 - num4;
					}
					if (cameraTrans2.y + orthographicSize2 >= 0f)
					{
						cameraTrans2.y = 0f - orthographicSize2;
					}
					else if (cameraTrans2.y - orthographicSize2 <= num6)
					{
						cameraTrans2.y = num6 + orthographicSize2;
					}
					m_BattleController.SetCameraTrans(cameraTrans2);
					m_DownPos = mousePosition2;
					posmark = m_DownPos;
				}
				timemark += Time.deltaTime;
			}
			if (Input.GetMouseButtonUp(0))
			{
				m_MouseDown = false;
				m_BattleController.HideAllHpGuage();
				vector3Int2 = m_BattleController.tilemap.WorldToCell(Camera.main.ScreenToWorldPoint(Input.mousePosition));
				pos = new Vector3Int(vector3Int2.x, -vector3Int2.y, 0);
				if (m_MouseDownAttackRange && (m_BattleController.current.attackRange.Contains(pos) || m_BattleController.current.attackSelectRange.Contains(pos)))
				{
					m_gridPos = Vector3Int.zero;
					CurcorPosition(pos);
					m_MouseDownAttackRange = false;
				}
				m_MouseDownMoveMap = false;
			}
		}
	}

	public void CurcorPosition(Vector3Int pos, bool pressing = false)
	{
		string text = "grid";
		BattleObject current = m_BattleController.current;
		if (m_BattleController.m_Flow == BattleControllerFlow.MoveWait)
		{
			foreach (BattleObject allBattleObj in m_BattleController.allBattleObjs)
			{
				if (!allBattleObj.isDead && pos.Equals(allBattleObj.GetGridPosition()) && allBattleObj.isSelectable)
				{
					text = SwitchCurcorSelected(allBattleObj);
					break;
				}
			}
			if (!(text == "grid"))
			{
				return;
			}
			if (!m_BattleController.CheckIsBattleObjectOnGrid(pos) && (selected != current || !current.standPosList.ContainsKey(pos)))
			{
				m_BattleController.RoundReSet();
				m_MenuController.m_menuState = BattleMenuState.None;
				StartCoroutine(DelayMove(current, pos));
			}
			else if (selected != null && selected == current)
			{
				if (!m_BattleController.CheckIsBattleObjectOnGrid(pos) && !m_BattleController.CheckIsItemOnGrid(pos))
				{
					m_BattleController.RoundReSet();
					m_MenuController.m_menuState = BattleMenuState.None;
					StartCoroutine(DelayMove(current, pos));
				}
				else if (pos.Equals(current.GetGridPosition()))
				{
					m_MenuController.m_menuState = BattleMenuState.AutoBattleShow;
				}
			}
		}
		else if (m_BattleController.m_Flow == BattleControllerFlow.ActionWait)
		{
			if (!m_BattleController.CheckIsBattleObjectOnGrid(pos) && !m_BattleController.CheckIsItemOnGrid(pos))
			{
				m_BattleController.RoundReSet();
				m_MenuController.m_menuState = BattleMenuState.None;
				StartCoroutine(DelayMove(current, pos));
			}
			else if (m_BattleController.CheckIsBattleObjectOnGrid(pos))
			{
				BattleObject battleObjectInPos = m_BattleController.GetBattleObjectInPos(pos);
				if (battleObjectInPos == m_BattleController.current && m_BattleController.current.handInPos == pos)
				{
					m_BattleController.RoundReSet();
				}
				else
				{
					m_MenuController.UpdateCharacterInfo(battleObjectInPos);
				}
			}
		}
		else
		{
			if (m_BattleController.m_Flow != BattleControllerFlow.ActionWaitAttack)
			{
				return;
			}
			if (current.m_AttackType[1] == "B")
			{
				if (!pressing && current.attackSelectRange.Contains(pos))
				{
					m_MenuController.m_menuState = BattleMenuState.None;
					current.Attack(pos);
					m_BattleController.SetFlowState(BattleControllerFlow.Action);
					m_BattleController.HideAllHpGuage();
				}
				return;
			}
			if (pressing)
			{
				if (current.attackRange.Contains(pos))
				{
					RangeManager.ShowAttackSelectRange(current, pos);
					return;
				}
				RangeManager.ClearAttackSelectRange();
				current.attackSelectRange.Clear();
				return;
			}
			if (current.attackSelectRange.Contains(pos) || (current.m_SkillRow != null && current.m_SkillRow.kf.Attckstyle.StartsWith("A|06") && current.attackRange.Contains(pos)))
			{
				m_MenuController.m_menuState = BattleMenuState.None;
				m_BattleController.SetFlowState(BattleControllerFlow.Action);
				if ("ITEM".Equals(current.m_AttackType[0]))
				{
					current.UseItem();
				}
				else if ("601".Equals(current.m_SkillRow.kf.Style) && !m_BattleController.isLostControl)
				{
					if ("13012".Equals(current.m_SkillRow.kf.ID) || "99036".Equals(current.m_SkillRow.kf.ID))
					{
						m_BattleController.OpenDartWallet(current.m_AttackType[0]);
					}
					else
					{
						m_BattleController.OpenDartPackage(current.m_AttackType[0]);
					}
				}
				else
				{
					current.Attack(pos);
				}
			}
			else
			{
				RangeManager.ClearAttackSelectRange();
				current.attackSelectRange.Clear();
			}
			m_BattleController.HideAllHpGuage();
		}
	}

	private IEnumerator DelayMove(BattleObject current, Vector3Int pos)
	{
		yield return null;
		AStarAlgorithmBattleField.Move(current, pos);
		m_BattleController.SetFlowState(BattleControllerFlow.Move);
	}

	public string SwitchCurcorSelected(BattleObject p)
	{
		string result = "grid";
		if (p != selected)
		{
			selected = p;
			SharedData.Instance().CurrentChara = selected.charadata.m_Id;
			RangeManager.ClearAllRange();
			StartCoroutine(RangeManager.ShowUnitRangeCoroutine(selected, reCallAStarPathDict: false));
			result = p.race;
			if (selected == m_BattleController.current)
			{
				m_MenuController.m_menuState = BattleMenuState.AutoBattleShow;
			}
			else
			{
				m_MenuController.m_menuState = BattleMenuState.None;
			}
			m_MenuController.UpdateCharacterInfo(selected);
		}
		return result;
	}

	public void ResetCurcorPosition()
	{
		SetPosition(m_BattleController.current.transform.position);
	}

	public void SetPosition(Vector3 _pos)
	{
		base.transform.position = _pos;
	}

	public void SetPosition(Vector3Int _pos)
	{
		base.transform.position = new Vector3(25 + _pos.x * 50, -25 - _pos.y * 50);
	}

	public void SetPosition(BattleObject _obj)
	{
		base.transform.position = new Vector3(_obj.transform.position.x, _obj.transform.position.y, 0f);
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / CommonVariables.MovementBlockSize);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / CommonVariables.MovementBlockSize);
		return zero;
	}
}
