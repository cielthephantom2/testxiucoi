using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class GDragEventDispatcher : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IDragHandler, IEndDragHandler, IScrollHandler
{
	private ScrollRect anotherScrollRect;

	private Image thisRaycast;

	private void Start()
	{
		FindScrollRect(base.gameObject);
		if ((bool)anotherScrollRect)
		{
			thisRaycast = base.gameObject.GetComponent<Image>();
		}
	}

	private void FindScrollRect(GameObject obj)
	{
		GameObject gameObject = obj.transform.parent?.gameObject;
		if (!(gameObject == null))
		{
			anotherScrollRect = gameObject.GetComponent<ScrollRect>();
			if (!anotherScrollRect)
			{
				FindScrollRect(gameObject);
			}
		}
	}

	public void OnScroll(PointerEventData eventData)
	{
		if ((bool)anotherScrollRect)
		{
			anotherScrollRect.OnScroll(eventData);
		}
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		if ((bool)anotherScrollRect)
		{
			anotherScrollRect.OnBeginDrag(eventData);
		}
		if ((bool)thisRaycast)
		{
			thisRaycast.raycastTarget = false;
		}
	}

	public void OnDrag(PointerEventData eventData)
	{
		if ((bool)anotherScrollRect)
		{
			anotherScrollRect.OnDrag(eventData);
		}
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		if ((bool)anotherScrollRect)
		{
			anotherScrollRect.OnEndDrag(eventData);
		}
		if ((bool)thisRaycast)
		{
			thisRaycast.raycastTarget = true;
		}
	}
}
