using Spine;
using Spine.Unity;
using UnityEngine;

public class SkinManager
{
	private static SkinManager _instance;

	public Skeleton m_skeleton;

	private SkinData m_skinData;

	private Skin characterSkin;

	public string baseSkinName = "_default";

	public int eyesSkinsCount = 6;

	public string eyesSkinsPrefix = "Eyes/Eye";

	public int clothesSkinsCount = 6;

	public string clothesSkinsPrefix = "Clothes/Clothes";

	public int handSkinsCount = 6;

	public string handSkinsPrefix = "Hand/Hand";

	public int weaponSkinsCount = 6;

	public string weaponSkinsPrefix = "Weapon/weapon";

	public static SkinManager Instance(bool init = false)
	{
		if (init || _instance == null)
		{
			_instance = null;
			_instance = new SkinManager();
		}
		return _instance;
	}

	public Color HSLToRGB(float hue, float saturation, float lightness)
	{
		if (saturation == 0f)
		{
			return new Color(lightness, lightness, lightness);
		}
		float num = ((lightness < 0.5f) ? (lightness * (1f + saturation)) : (lightness + saturation - lightness * saturation));
		float p = 2f * lightness - num;
		float num2 = hue / 360f;
		float r = HueToRGB(p, num, num2 + 1f / 3f);
		float g = HueToRGB(p, num, num2);
		float b = HueToRGB(p, num, num2 - 1f / 3f);
		return new Color(r, g, b);
	}

	private float HueToRGB(float p, float q, float t)
	{
		if (t < 0f)
		{
			t += 1f;
		}
		if (t > 1f)
		{
			t -= 1f;
		}
		if (t < 1f / 6f)
		{
			return p + (q - p) * 6f * t;
		}
		if (t < 0.5f)
		{
			return q;
		}
		if (t < 2f / 3f)
		{
			return p + (q - p) * (2f / 3f - t) * 6f;
		}
		return p;
	}

	public void UpdateMenuCharacterSkin(SkeletonGraphic _skeletonGraphic = null, SkinData _skinData = null)
	{
	}

	public void UpdateFieldCharacterSkin(GameObject _obj = null, SkinData _skinData = null)
	{
	}

	public void UpdateFieldCharacterSkin(SkeletonAnimation _skeletonAnimation = null, SkinData _skinData = null)
	{
	}

	private void UpdateCharacterSkin()
	{
	}

	private void UpdateCharacterSkinColor()
	{
	}

	private void UpdateCharacterWeapon()
	{
	}

	private void HideWeapon()
	{
	}
}
