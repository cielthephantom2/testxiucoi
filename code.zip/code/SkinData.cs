public class SkinData
{
	public string id = "";

	public bool isInit;

	public int activeEyesIndex;

	public int activeClothesIndex;

	public int activeHandIndex;

	public int activeWeaponIndex;

	public string equipWeaponId = "";

	public HSLData skinHSL = new HSLData();

	public HSLData eyeHSL = new HSLData();

	public HSLData clothesHSL = new HSLData();

	public HSLData handHSL = new HSLData();
}
