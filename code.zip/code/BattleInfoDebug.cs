using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class BattleInfoDebug : MonoBehaviour
{
	private BattleObject currentShow;

	private List<GameObject> infoPanelList = new List<GameObject>();

	private GameObject infoPanel;

	private void Start()
	{
		infoPanel = base.gameObject;
	}

	private void Update()
	{
		if (SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.m_curcor != null && SharedData.Instance().m_BattleController.m_curcor.selected != null && SharedData.Instance().m_BattleController.m_curcor.selected != currentShow)
		{
			currentShow = SharedData.Instance().m_BattleController.m_curcor.selected;
			ShowInfoPanel();
		}
	}

	private void ShowInfoPanel()
	{
		infoPanel.transform.Find("Name").GetComponent<TMP_Text>().text = currentShow.name;
		string text = "";
		foreach (BuffData buff in currentShow.m_Buffs)
		{
			text = text + "name = " + buff.name + "; source = " + buff.source + "; value = " + buff.value + "; turn = " + buff.turn + "\n";
		}
		string text2 = "";
		foreach (KeyValuePair<string, AtomData> item in currentShow.charadata.Indexs_Name)
		{
			if (item.Value.fightValue != 0f)
			{
				text2 = text2 + "name = " + item.Key + "; fightValue = " + item.Value.fightValue + "\n";
			}
		}
		infoPanel.transform.Find("BuffList").GetComponent<TMP_Text>().text = text;
		infoPanel.transform.Find("AtomList").GetComponent<TMP_Text>().text = text2;
	}
}
