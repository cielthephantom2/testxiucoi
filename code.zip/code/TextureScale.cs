using UnityEngine;

public static class TextureScale
{
	public static void Bilinear(Texture2D source, Texture2D target)
	{
		Color[] pixels = source.GetPixels();
		Color[] array = new Color[target.width * target.height];
		float num = (float)(source.width - 1) / (float)target.width;
		float num2 = (float)(source.height - 1) / (float)target.height;
		for (int i = 0; i < target.height; i++)
		{
			float f = num2 * (float)i;
			int num3 = Mathf.FloorToInt(f);
			Mathf.CeilToInt(f);
			for (int j = 0; j < target.width; j++)
			{
				float f2 = num * (float)j;
				int num4 = Mathf.FloorToInt(f2);
				Mathf.CeilToInt(f2);
				Color color = pixels[num3 * source.width + num4];
				Color color2 = color;
				array[i * target.width + j] = color2;
			}
		}
		target.SetPixels(array);
		target.Apply();
	}
}
