public enum State
{
	MoveInit,
	WaitingForInput,
	Moving,
	AStarInit,
	AStarMoving,
	AStarWaiting,
	InputMoving,
	InputMoveWaiting,
	OnSliding,
	SlidingOver,
	BlockWait,
	WaitFollowerStopSlide,
	Drowning
}
