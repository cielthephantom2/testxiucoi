using System.Collections.Generic;
using UnityEngine;

public class gang_f02Table
{
	public class Row
	{
		public string Id;

		public string SubId;

		public string Title;

		public string Title_EN;

		public string Bgm;

		public string BackGround;

		public string Middle;

		public string Front;

		public string Tachie;

		public string Line;

		public string Line_EN;

		public string Type;

		public string Title_Trans => CommonFunc.ShortLangSel(Title, Title_EN);

		public string Line_Trans => CommonFunc.ShortLangSel(Line, Line_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			Row row = new Row();
			row.Id = list[i][0];
			row.SubId = list[i][1];
			row.Title = list[i][2];
			row.Title_EN = list[i][3];
			row.Bgm = list[i][4];
			row.BackGround = list[i][5];
			row.Middle = list[i][6];
			row.Front = list[i][7];
			row.Tachie = list[i][8];
			row.Line = list[i][9];
			row.Line_EN = list[i][10];
			row.Type = list[i][11];
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_Id(string find)
	{
		return rowList.Find((Row x) => x.Id == find);
	}

	public List<Row> FindAll_Id(string find)
	{
		return rowList.FindAll((Row x) => x.Id == find);
	}

	public Row Find_SubId(string find)
	{
		return rowList.Find((Row x) => x.SubId == find);
	}

	public List<Row> FindAll_SubId(string find)
	{
		return rowList.FindAll((Row x) => x.SubId == find);
	}

	public Row Find_Title(string find)
	{
		return rowList.Find((Row x) => x.Title == find);
	}

	public List<Row> FindAll_Title(string find)
	{
		return rowList.FindAll((Row x) => x.Title == find);
	}

	public Row Find_Title_EN(string find)
	{
		return rowList.Find((Row x) => x.Title_EN == find);
	}

	public List<Row> FindAll_Title_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Title_EN == find);
	}

	public Row Find_Bgm(string find)
	{
		return rowList.Find((Row x) => x.Bgm == find);
	}

	public List<Row> FindAll_Bgm(string find)
	{
		return rowList.FindAll((Row x) => x.Bgm == find);
	}

	public Row Find_BackGround(string find)
	{
		return rowList.Find((Row x) => x.BackGround == find);
	}

	public List<Row> FindAll_BackGround(string find)
	{
		return rowList.FindAll((Row x) => x.BackGround == find);
	}

	public Row Find_Middle(string find)
	{
		return rowList.Find((Row x) => x.Middle == find);
	}

	public List<Row> FindAll_Middle(string find)
	{
		return rowList.FindAll((Row x) => x.Middle == find);
	}

	public Row Find_Front(string find)
	{
		return rowList.Find((Row x) => x.Front == find);
	}

	public List<Row> FindAll_Front(string find)
	{
		return rowList.FindAll((Row x) => x.Front == find);
	}

	public Row Find_Tachie(string find)
	{
		return rowList.Find((Row x) => x.Tachie == find);
	}

	public List<Row> FindAll_Tachie(string find)
	{
		return rowList.FindAll((Row x) => x.Tachie == find);
	}

	public Row Find_Line(string find)
	{
		return rowList.Find((Row x) => x.Line == find);
	}

	public List<Row> FindAll_Line(string find)
	{
		return rowList.FindAll((Row x) => x.Line == find);
	}

	public Row Find_Line_EN(string find)
	{
		return rowList.Find((Row x) => x.Line_EN == find);
	}

	public List<Row> FindAll_Line_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Line_EN == find);
	}

	public Row Find_Type(string find)
	{
		return rowList.Find((Row x) => x.Type == find);
	}

	public List<Row> FindAll_Type(string find)
	{
		return rowList.FindAll((Row x) => x.Type == find);
	}
}
