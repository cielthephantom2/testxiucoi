using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class SimpleFlagData
{
	[Key(0)]
	public string flag = "";

	[Key(1)]
	public int value;
}
