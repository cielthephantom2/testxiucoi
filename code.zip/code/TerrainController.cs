using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine;
using Spine.Unity;
using UnityEngine;

public class TerrainController : MonoBehaviour
{
	public TerrainData _TerrainData = new TerrainData();

	protected SkeletonAnimation m_Animation;

	protected MeshRenderer m_MeshRenderer;

	protected SpriteRenderer m_SpriteRenderer;

	public Coroutine TerrainKillDelayCoroutine;

	public Coroutine BlastTrapEffectCoroutine;

	protected const float MovementBlockSize = 50f;

	public bool alreadyBlasted;

	public int terrainKeepTime
	{
		get
		{
			return _TerrainData.terrainKeepTime;
		}
		set
		{
			_TerrainData.terrainKeepTime = value;
		}
	}

	public bool isPersistent
	{
		get
		{
			return _TerrainData.isPersistent;
		}
		set
		{
			_TerrainData.isPersistent = value;
		}
	}

	public bool loopRun
	{
		get
		{
			return _TerrainData.loopRun;
		}
		set
		{
			_TerrainData.loopRun = value;
		}
	}

	public TerrainType t_type
	{
		get
		{
			return _TerrainData.t_type;
		}
		set
		{
			_TerrainData.t_type = value;
		}
	}

	public float damageValue
	{
		get
		{
			return _TerrainData.damageValue;
		}
		set
		{
			_TerrainData.damageValue = value;
		}
	}

	public bool isBlasting
	{
		get
		{
			return _TerrainData.isBlasting;
		}
		set
		{
			_TerrainData.isBlasting = value;
		}
	}

	public float m_BlastSputterATKup
	{
		get
		{
			return _TerrainData.m_BlastSputterATKup;
		}
		set
		{
			_TerrainData.m_BlastSputterATKup = value;
		}
	}

	public float m_BlastAttackDizzy
	{
		get
		{
			return _TerrainData.m_BlastAttackDizzy;
		}
		set
		{
			_TerrainData.m_BlastAttackDizzy = value;
		}
	}

	public float m_BlastSputterAttackDizzy
	{
		get
		{
			return _TerrainData.m_BlastSputterAttackDizzy;
		}
		set
		{
			_TerrainData.m_BlastSputterAttackDizzy = value;
		}
	}

	public Vector3Int m_pos
	{
		get
		{
			return _TerrainData.m_pos;
		}
		set
		{
			_TerrainData.m_pos = value;
		}
	}

	private void Start()
	{
		m_SpriteRenderer = GetComponent<SpriteRenderer>();
		m_MeshRenderer = GetComponent<MeshRenderer>();
		if (m_MeshRenderer != null)
		{
			m_MeshRenderer.sortingOrder = SharedData.Instance().m_BattleController.m_Effect_SortingOrder;
		}
		m_Animation = GetComponent<SkeletonAnimation>();
		if (m_Animation != null)
		{
			m_Animation.AnimationState.SetAnimation(0, m_Animation.skeleton.Data.Animations.Items[0], loopRun);
		}
		if (!loopRun && m_Animation != null)
		{
			m_Animation.AnimationState.Complete += State_Complete;
		}
		CalDamageRateAndType();
	}

	private void OnEnable()
	{
		if (m_Animation != null)
		{
			m_Animation.AnimationState.SetAnimation(0, m_Animation.skeleton.Data.Animations.Items[0], loopRun);
		}
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		base.gameObject.SetActive(value: false);
	}

	private void CalDamageRateAndType()
	{
		if (damageValue == 0f)
		{
			switch (t_type)
			{
			case TerrainType.Hell:
				damageValue = 1f;
				break;
			case TerrainType.Water:
				damageValue = 1f;
				break;
			case TerrainType.FireLv1:
				damageValue = SharedData.Instance().terrainFireLv1DamageRate;
				break;
			case TerrainType.FireLv2:
				damageValue = SharedData.Instance().terrainFireLv2DamageRate;
				break;
			case TerrainType.FirePersistent:
				damageValue = SharedData.Instance().terrainFirePersistentDamageRate;
				break;
			case TerrainType.PoisonLv1:
				damageValue = SharedData.Instance().terrainPoisonLv1DamageRate;
				break;
			case TerrainType.PoisonLv2:
				damageValue = SharedData.Instance().terrainPoisonLv2DamageRate;
				break;
			case TerrainType.PoisonPersistent:
				damageValue = SharedData.Instance().terrainPoisonPersistentDamageRate;
				break;
			case TerrainType.TrapSeal:
				damageValue = SharedData.Instance().terrainTrapSealValue;
				break;
			case TerrainType.TrapBlast:
				damageValue = SharedData.Instance().terrainTrapBlastDamageValue;
				break;
			}
		}
	}

	public void TerrainEffectOn()
	{
		BattleObject battleObjectInPos = SharedData.Instance().m_BattleController.GetBattleObjectInPos(GetGridPosition());
		if (battleObjectInPos == null)
		{
			return;
		}
		battleObjectInPos.isBeEffectInMovingStage = true;
		if (t_type.ToString().Contains("Fire") || t_type.ToString().Contains("Poison"))
		{
			if ((t_type.ToString().Contains("Fire") && battleObjectInPos.charadata.GetBattleValueByName("Burnresist") > 0f) || (t_type.ToString().Contains("Poison") && battleObjectInPos.charadata.GetBattleValueByName("Poisonresist") > 0f) || battleObjectInPos.CheckBuffEffectOn("Goldenbell"))
			{
				return;
			}
			bool flag = false;
			bool flag2 = false;
			if (t_type.ToString().Contains("Lv2") || t_type.ToString().Contains("Persistent"))
			{
				flag = true;
				flag2 = true;
			}
			int num = (int)Mathf.Floor(battleObjectInPos.charadata.GetBattleValueByName("HP") * damageValue);
			if (flag2)
			{
				if (t_type.ToString().Contains("Fire"))
				{
					battleObjectInPos.AddBuffInfo("burn");
				}
				else
				{
					battleObjectInPos.AddBuffInfo("poison");
				}
			}
			if (flag)
			{
				if (t_type.ToString().Contains("Fire"))
				{
					battleObjectInPos.charadata.Indexs_Name["Burn"].fightValue += 5f;
				}
				else
				{
					battleObjectInPos.charadata.Indexs_Name["Poison"].fightValue += 5f;
				}
			}
			if (t_type.ToString().Contains("Poison") && battleObjectInPos.charadata.m_Hp - (float)num <= 0f)
			{
				num = (int)(battleObjectInPos.charadata.m_Hp - 1f);
			}
			battleObjectInPos.AddDamageInfo(num.ToString(), t_type.ToString().Contains("Fire") ? "TerrainBURN" : "TerrainPOISON");
		}
		else if (t_type == TerrainType.Water || t_type == TerrainType.Hell)
		{
			if (!SharedData.Instance().m_BattleController.current.attackObjs.Contains(battleObjectInPos))
			{
				SharedData.Instance().m_BattleController.current.attackObjs.Add(battleObjectInPos);
			}
			battleObjectInPos.charadata.m_Hp = 0f;
			base.gameObject.SetActive(value: true);
			TerrainKillDelayCoroutine = StartCoroutine(TerrainKillDelay(battleObjectInPos));
			if (t_type == TerrainType.Water)
			{
				StatsAndAchievements.Instance().UnlockAchievement("1018");
			}
			else if (t_type == TerrainType.Hell)
			{
				StatsAndAchievements.Instance().UnlockAchievement("1019");
			}
		}
		else if (t_type == TerrainType.TrapSeal)
		{
			bool flag3 = false;
			if (battleObjectInPos.charadata.GetBattleValueByName("Trapresist") > 0f && battleObjectInPos.CheckBuffEffectOn("Goldenbell") && battleObjectInPos.charadata.GetBattleValueByName("Sealresist") > 0f)
			{
				flag3 = true;
			}
			if (!flag3)
			{
				battleObjectInPos.charadata.Indexs_Name["Seal"].fightValue += (int)damageValue;
				battleObjectInPos.AddDamageInfo(((int)damageValue).ToString(), "Seal");
				if (battleObjectInPos.charadata.GetBattleValueByName("Seal") >= 25f)
				{
					battleObjectInPos.AddBuffInfo("seal");
					battleObjectInPos.AdjustAnimationSpeed(0f, Color.gray);
					battleObjectInPos.isSealFreeze = true;
					if (SharedData.Instance().m_BattleController.current == battleObjectInPos)
					{
						SharedData.Instance().m_MenuController.OpenInteruptInfo(battleObjectInPos, battleObjectInPos.charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SealCanNotMove"));
						battleObjectInPos.InteruptIn(BattleObjectState.RoundOff);
					}
				}
			}
			SharedData.Instance().m_BattleController.DestoryTerrain(GetGridPosition());
			if (SharedData.Instance().m_BattleController.current.race.Equals("player"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1024");
			}
		}
		else if (t_type == TerrainType.TrapBlast)
		{
			TriggerBlast();
			if (SharedData.Instance().m_BattleController.current.race.Equals("player"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1024");
			}
		}
	}

	private IEnumerator TerrainKillDelay(BattleObject battleObject)
	{
		if (t_type == TerrainType.Water || t_type == TerrainType.Hell)
		{
			yield return new WaitForSeconds(0.5f);
			switch (t_type)
			{
			case TerrainType.Hell:
			{
				SkeletonAnimation[] animations = battleObject.m_Animations;
				for (int i = 0; i < animations.Length; i++)
				{
					animations[i].transform.DOScale(new Vector3(0f, 0f, 1f), 0.25f);
				}
				break;
			}
			case TerrainType.Water:
			{
				SkeletonAnimation[] animations = battleObject.m_Animations;
				for (int i = 0; i < animations.Length; i++)
				{
					animations[i].transform.DOScale(new Vector3(0f, 0f, 1f), 0.25f);
				}
				break;
			}
			}
			battleObject.isDead = true;
			battleObject.BattleObjectDead();
			yield return new WaitForSeconds(0.1f);
			base.gameObject.GetComponent<SkeletonAnimation>().enabled = true;
			if (t_type == TerrainType.Water)
			{
				battleObject.PlayAudioClip(AudioClipEnum.Water);
			}
			else
			{
				battleObject.PlayAudioClip(AudioClipEnum.Hell);
			}
		}
		while (!SharedData.Instance().m_BattleController.isRoundActionFinish())
		{
			yield return null;
		}
		if (SharedData.Instance().m_BattleController.current == battleObject)
		{
			battleObject.SetBattleObjState(BattleObjectState.RoundOff);
		}
		yield return null;
	}

	public void TriggerBlast()
	{
		if (t_type == TerrainType.TrapBlast && !alreadyBlasted)
		{
			alreadyBlasted = true;
			List<TerrainController> neighborBlastTrap = BlastTrapEffectOn();
			BlastTrapEffectCoroutine = StartCoroutine(BlastTrapEffectChain(1f, neighborBlastTrap));
		}
	}

	private List<TerrainController> BlastTrapEffectOn()
	{
		if (m_MeshRenderer != null)
		{
			m_MeshRenderer.enabled = false;
		}
		if (m_SpriteRenderer != null)
		{
			m_SpriteRenderer.enabled = false;
		}
		LoadBlastEffect();
		BattleObject battleObjectInPos = SharedData.Instance().m_BattleController.GetBattleObjectInPos(GetGridPosition());
		if (battleObjectInPos != null && !battleObjectInPos.CheckBuffEffectOn("Goldenbell") && !(battleObjectInPos.charadata.GetBattleValueByName("Trapresist") > 0f))
		{
			battleObjectInPos.AddDamageInfo(((int)(SharedData.Instance().m_BattleController.terrain[GetGridPosition()].damageValue * (1f + SharedData.Instance().m_BattleController.terrain[GetGridPosition()].m_BlastSputterATKup))).ToString(), "Blast");
			battleObjectInPos.BattleObjectBeHit();
			if (Random.Range(0f, 1f) < m_BlastAttackDizzy && battleObjectInPos.charadata.GetBattleValueByName("Dizzyresist") <= 0f)
			{
				battleObjectInPos.AddBuff("Dizzy", "Trap", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_Dizzy"));
				if (battleObjectInPos == SharedData.Instance().m_BattleController.current)
				{
					AStarAlgorithmBattleField.m_MoveProcess = -1;
				}
			}
		}
		List<Vector3Int> gridNeighbors = SharedData.Instance().m_BattleController.GetGridNeighbors(GetGridPosition());
		List<TerrainController> list = new List<TerrainController>();
		foreach (Vector3Int item in gridNeighbors)
		{
			battleObjectInPos = SharedData.Instance().m_BattleController.GetBattleObjectInPos(item);
			if (battleObjectInPos != null && !battleObjectInPos.CheckBuffEffectOn("Goldenbell") && !(battleObjectInPos.charadata.GetBattleValueByName("Trapresist") > 0f))
			{
				int num = (int)(SharedData.Instance().m_BattleController.terrain[GetGridPosition()].damageValue * (1f + SharedData.Instance().m_BattleController.terrain[GetGridPosition()].m_BlastSputterATKup));
				num = (int)((float)num * (1f + SharedData.Instance().m_BattleController.current.charadata.GetBattleValueByName("AccidentalInjury")));
				battleObjectInPos.AddDamageInfo(((int)((float)num * 0.25f)).ToString(), "BlastSputter");
				battleObjectInPos.BattleObjectBeHit();
				if (Random.Range(0f, 1f) < m_BlastSputterAttackDizzy && battleObjectInPos.charadata.GetBattleValueByName("Dizzyresist") <= 0f)
				{
					battleObjectInPos.AddBuff("Dizzy", "Trap", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_Dizzy"));
					if (battleObjectInPos == SharedData.Instance().m_BattleController.current)
					{
						AStarAlgorithmBattleField.m_MoveProcess = -1;
					}
				}
			}
			if (SharedData.Instance().m_BattleController.terrain.ContainsKey(item) && SharedData.Instance().m_BattleController.terrain[item].t_type == TerrainType.TrapBlast)
			{
				list.Add(SharedData.Instance().m_BattleController.terrain[item]);
				SharedData.Instance().m_BattleController.terrain[item].isBlasting = true;
			}
		}
		return list;
	}

	private IEnumerator BlastTrapEffectChain(float timer = 1f, List<TerrainController> neighborBlastTrap = null)
	{
		if (neighborBlastTrap == null)
		{
			yield break;
		}
		isBlasting = true;
		yield return new WaitForSeconds(timer);
		if (neighborBlastTrap.Count > 0)
		{
			foreach (TerrainController item in neighborBlastTrap)
			{
				item.TriggerBlast();
			}
		}
		SharedData.Instance().m_BattleController.DestoryTerrain(GetGridPosition());
		isBlasting = false;
	}

	private void LoadBlastEffect()
	{
		GameObject obj = Object.Instantiate((GameObject)Resources.Load("Prefabs/Effect/Terrain/effect-TrapBlast"), SharedData.Instance().m_BattleController.map.transform);
		EffectController component = obj.GetComponent<EffectController>();
		component.m_BattleObj = null;
		component.m_TargetObj = null;
		component.m_combo = 1;
		SharedData.Instance().m_BattleController.m_EffectControllerList.Add(component);
		obj.transform.localPosition = new Vector3(25 + GetGridPosition().x * 50, -25 - GetGridPosition().y * 50);
	}

	public void StopBlastChain()
	{
		if (BlastTrapEffectCoroutine != null && isBlasting)
		{
			StopCoroutine(BlastTrapEffectCoroutine);
		}
		if (TerrainKillDelayCoroutine != null && isBlasting)
		{
			StopCoroutine(TerrainKillDelayCoroutine);
		}
		isBlasting = false;
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		m_pos = zero;
		return zero;
	}
}
