using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MapViewController : MonoBehaviour
{
	public float ScaleLevel1 = 0.33f;

	public float ScaleLevel2 = 0.66f;

	public float ScaleLevel3 = 0.99f;

	[HideInInspector]
	public Transform MapImage;

	private bool exiting;

	private Vector3 nowVector3 = Vector3.zero;

	public int stepValue = 1;

	private Vector3 m_DownPos = Vector3.zero;

	private bool m_MouseDown;

	private GameObject confirmObj;

	private GameObject confirmCantObj;

	private gang_e07Table.Row telePortRow;

	private List<Button> IconList = new List<Button>();

	private Transform IconInfo;

	private bool isShowName = true;

	private List<string> CityNameList = new List<string> { "City|XiangYang", "City|JingZhaoFu", "City|BianLiang", "City|YanJing", "City|ChengDu", "City|HengYang", "City|LinAn" };

	private List<Transform> CityIconList = new List<Transform>();

	private Dictionary<string, List<gang_e07Table.Row>> AreaDict = new Dictionary<string, List<gang_e07Table.Row>>();

	private GameObject MapAreaItemPrefab;

	private ScrollRect AreaMenu;

	private Transform currentAreaMenu;

	private Dictionary<string, bool> isUnlockAnyMap = new Dictionary<string, bool>();

	private RectTransform m_Pointer;

	private List<MapIconController> mapIconControllers = new List<MapIconController>();

	private MapIconController lastAdsorptionMapIcon;

	private void Start()
	{
		IconInfo = base.transform.Find("Panel/Map/IconInfo");
		MapImage = base.transform.Find("Panel/Map");
		IconList = base.transform.Find("Panel/Map/Icon").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		m_Pointer = base.transform.Find("Panel/Pointer").GetComponent<RectTransform>();
		foreach (Button icon in IconList)
		{
			EventTriggerListener.Get(icon.gameObject).onClick = OnButtonClick;
		}
		EventTriggerListener.Get(base.transform.Find("Panel/Return").GetComponent<Button>().gameObject).onClick = OnButtonClick;
		Button[] componentsInChildren = base.transform.Find("Panel/Confirm").GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		componentsInChildren = base.transform.Find("Panel/CantTeleport").GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		confirmObj = base.transform.Find("Panel/Confirm").gameObject;
		confirmCantObj = base.transform.Find("Panel/CantTeleport").gameObject;
		MapAreaItemPrefab = Resources.Load("Prefabs/NewUI/MapIcon/MapAreaItem") as GameObject;
		AreaMenu = base.transform.Find("Panel/AreaMenu").GetComponent<ScrollRect>();
		foreach (string cityName in CityNameList)
		{
			AreaDict.Add(cityName, new List<gang_e07Table.Row>());
			CityIconList.Add(MapImage.Find("Icon/" + cityName));
		}
		int num = 0;
		while (num < CommonResourcesData.e07.NumRows())
		{
			gang_e07Table.Row row = CommonResourcesData.e07.GetRowList()[num];
			if (!AreaDict.ContainsKey(row.id))
			{
				continue;
			}
			string id = row.id;
			AreaDict[id].Add(row);
			while (++num < CommonResourcesData.e07.NumRows())
			{
				row = CommonResourcesData.e07.GetRowList()[num];
				if (AreaDict.ContainsKey(row.id))
				{
					break;
				}
				AreaDict[id].Add(row);
			}
		}
		foreach (string cityName2 in CityNameList)
		{
			foreach (gang_e07Table.Row tmp in AreaDict[cityName2])
			{
				GameObject gameObject = Object.Instantiate(MapAreaItemPrefab, AreaMenu.content);
				gameObject.GetComponent<MapAreaItemController>().MapIcon = MapImage.Find("Icon/" + tmp.id);
				gameObject.name = cityName2 + "&" + tmp.id;
				gameObject.transform.Find("Text").GetComponent<Text>().text = tmp.name_Trans;
				gameObject.SetActive(value: false);
				GameObject gameObject2 = IconList.Find((Button x) => x.name == tmp.id).gameObject;
				if (gameObject2 != null)
				{
					gameObject2.GetComponent<MapIconController>().MapAreaItem = gameObject.transform;
				}
			}
		}
		AreaMenu.gameObject.SetActive(value: false);
		foreach (Transform cityIcon in CityIconList)
		{
			bool value = false;
			foreach (Transform item in AreaMenu.content.transform)
			{
				if (item.gameObject.name.StartsWith(cityIcon.name) && SharedData.Instance().m_UnLockMapIconList.Contains(item.gameObject.name.Split("&")[1]))
				{
					value = true;
					break;
				}
			}
			isUnlockAnyMap.Add(cityIcon.name, value);
		}
		gang_e04Table.Row row2 = CommonResourcesData.e04.Find_id(SharedData.Instance().CurrentMapID);
		if (row2 != null && row2.maplocation.Length > 0 && !row2.maplocation.Equals("0"))
		{
			string[] array = row2.maplocation.Split('|');
			if (array.Length == 2)
			{
				MapImage.Find("Marker").gameObject.SetActive(value: true);
				MapImage.GetComponent<RectTransform>().localScale = Vector3.one;
				MapImage.Find("Marker").localPosition = MapImage.Find("Icon/" + row2.maplocation).GetComponent<RectTransform>().localPosition;
				m_Pointer.localPosition = Vector3.zero;
				MapImage.localPosition = -1f * MapImage.Find("Marker").localPosition * MapImage.localScale.x;
			}
			else if (array.Length == 5)
			{
				float num2 = float.Parse(array[0], CultureInfo.InvariantCulture);
				float num3 = float.Parse(array[1], CultureInfo.InvariantCulture);
				float num4 = float.Parse(array[4], CultureInfo.InvariantCulture);
				float num5 = (SharedData.Instance().CurrentPlayerPos.x - num2) * num4;
				float num6 = (SharedData.Instance().CurrentPlayerPos.y - num3) * num4;
				Transform obj = MapImage.Find("Icon/" + array[2] + "|" + array[3]);
				float x2 = obj.localPosition.x;
				float y = obj.localPosition.y;
				Vector3 localPosition = new Vector3(x2 + num5, y + num6, 0f);
				MapImage.Find("Marker").gameObject.SetActive(value: true);
				MapImage.GetComponent<RectTransform>().localScale = Vector3.one;
				MapImage.Find("Marker").localPosition = localPosition;
				m_Pointer.localPosition = Vector3.zero;
				MapImage.localPosition = -1f * MapImage.Find("Marker").localPosition * MapImage.localScale.x;
				BorderCheck(Vector3.zero);
			}
			else
			{
				MapImage.Find("Marker").gameObject.SetActive(value: false);
			}
			if (MapImage.Find("Marker").gameObject.activeInHierarchy)
			{
				foreach (Button icon2 in IconList)
				{
					icon2.transform.Find("Name").gameObject.SetActive(isShowName);
				}
				SetAreaMenu();
			}
		}
		mapIconControllers = base.transform.Find("Panel/Map/Icon").GetComponentsInChildren<MapIconController>().ToList();
		SharedData.Instance().m_MapViewController = this;
	}

	private void Update()
	{
		if (exiting)
		{
			return;
		}
		if (InputDeviceDetector.isMouse1Up || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputSystemCustom.Instance().UI.OpenMapView.WasReleasedThisFrame())
		{
			if (!confirmObj.activeInHierarchy && !confirmCantObj.activeInHierarchy)
			{
				ExitScene();
				return;
			}
			confirmObj.SetActive(value: false);
			confirmCantObj.SetActive(value: false);
		}
		if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			if (confirmObj.activeInHierarchy)
			{
				ExecuteEvents.Execute(confirmObj.transform.Find("Yes").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
			else if (confirmCantObj.activeInHierarchy)
			{
				ExecuteEvents.Execute(confirmCantObj.transform.Find("No").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
			else if (lastAdsorptionMapIcon != null)
			{
				ExecuteEvents.Execute(lastAdsorptionMapIcon.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
		if (!confirmObj.activeInHierarchy && !confirmCantObj.activeInHierarchy)
		{
			if (CommonResourcesData.inputDeviceDetector.isMouseInput)
			{
				if (Input.GetMouseButtonDown(0))
				{
					m_DownPos = Input.mousePosition;
					m_MouseDown = true;
				}
				else if (m_MouseDown)
				{
					if (Input.GetMouseButton(0))
					{
						Vector3 mousePosition = Input.mousePosition;
						if (!mousePosition.Equals(m_DownPos) && Input.touchCount != 2)
						{
							BorderCheck((mousePosition - m_DownPos) * 1f);
							m_DownPos = mousePosition;
						}
					}
					else if (Input.GetMouseButtonUp(0))
					{
						m_MouseDown = false;
					}
				}
			}
			if (InputSystemCustom.Instance().UI.MoveMap.ReadValue<Vector2>() != Vector2.zero)
			{
				BorderCheck(InputSystemCustom.Instance().UI.MoveMap.ReadValue<Vector2>() * -1f);
				CheckPointerAdsorption(resetMapPos: true);
			}
			else if (InputSystemCustom.Instance().UI.MoveMapCursor.ReadValue<Vector2>() != Vector2.zero)
			{
				MovePointer(InputSystemCustom.Instance().UI.MoveMapCursor.ReadValue<Vector2>());
				CheckPointerAdsorption();
			}
		}
		if (GetOverUI() == MapImage.gameObject)
		{
			SetImageSize(MapImage);
		}
		SetAreaMenu();
	}

	private void CheckPointerAdsorption(bool resetMapPos = false)
	{
		Vector2 a = RectTransformUtility.WorldToScreenPoint(Camera.main, m_Pointer.position);
		float num = float.MaxValue;
		MapIconController mapIconController = null;
		if (lastAdsorptionMapIcon == null)
		{
			foreach (MapIconController mapIconController2 in mapIconControllers)
			{
				if (mapIconController2.gameObject.activeInHierarchy)
				{
					Vector2 b = RectTransformUtility.WorldToScreenPoint(Camera.main, mapIconController2.GetComponent<RectTransform>().position);
					float num2 = Vector2.Distance(a, b);
					if (num2 < num && lastAdsorptionMapIcon != mapIconController2)
					{
						mapIconController = mapIconController2;
						num = num2;
					}
				}
			}
		}
		else
		{
			Vector2 b2 = RectTransformUtility.WorldToScreenPoint(Camera.main, lastAdsorptionMapIcon.GetComponent<RectTransform>().position);
			num = Vector2.Distance(a, b2);
		}
		if (num > (float)Screen.height * 0.1f && lastAdsorptionMapIcon != null)
		{
			Debug.Log("CheckPointerAdsorption Leave");
			if (lastAdsorptionMapIcon != null)
			{
				ExecuteEvents.Execute(lastAdsorptionMapIcon.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerExitHandler);
			}
			lastAdsorptionMapIcon = null;
		}
		else if (num < (float)Screen.height * 0.1f && mapIconController != null && lastAdsorptionMapIcon != mapIconController)
		{
			Debug.Log("CheckPointerAdsorption Enter");
			if (lastAdsorptionMapIcon != null)
			{
				ExecuteEvents.Execute(lastAdsorptionMapIcon.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerExitHandler);
			}
			lastAdsorptionMapIcon = mapIconController;
			ExecuteEvents.Execute(lastAdsorptionMapIcon.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerEnterHandler);
		}
	}

	public GameObject GetOverUI()
	{
		return MapImage.gameObject;
	}

	private void SetAreaMenu()
	{
		if (isShowName)
		{
			Transform transform = null;
			float num = float.MaxValue;
			foreach (Transform cityIcon in CityIconList)
			{
				float num2 = Vector3.Distance(cityIcon.localPosition, -MapImage.localPosition);
				if (num2 < num && isUnlockAnyMap[cityIcon.name])
				{
					num = num2;
					transform = cityIcon;
				}
			}
			if (currentAreaMenu != transform)
			{
				currentAreaMenu = transform;
				foreach (Transform item in AreaMenu.content.transform)
				{
					item.gameObject.SetActive(item.gameObject.name.StartsWith(transform.name) && SharedData.Instance().m_UnLockMapIconList.Contains(item.gameObject.name.Split("&")[1]));
				}
				gang_e07Table.Row row = CommonResourcesData.e07.Find_id(transform.name);
				if (row != null)
				{
					base.transform.Find("Panel/TopBanner/Text").GetComponent<Text>().text = row.name_Trans;
				}
			}
			if (!AreaMenu.gameObject.activeInHierarchy)
			{
				AreaMenu.gameObject.SetActive(value: true);
			}
		}
		if (!isShowName && AreaMenu.gameObject.activeInHierarchy)
		{
			AreaMenu.gameObject.SetActive(value: false);
			base.transform.Find("Panel/TopBanner/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_JiangHuMap");
		}
	}

	private void SetImageSize(Transform _transform)
	{
		float num = 0f;
		num = InputSystemCustom.Instance().UI.ZoomMap.ReadValue<float>();
		if (num != 0f)
		{
			SetMouseChangeForImage(_transform, (num > 0f) ? stepValue : (-stepValue));
		}
	}

	private void SetMouseChangeForImage(Transform _transform, int _value)
	{
		float num = (float)Screen.currentResolution.width / 2f + _transform.localPosition.x;
		float num2 = (float)Screen.currentResolution.height / 2f + _transform.localPosition.y;
		if (CommonResourcesData.inputDeviceDetector.isMouseInput)
		{
			Vector2 zero = Vector2.zero;
			zero.x = Input.mousePosition.x;
			zero.y = Input.mousePosition.y;
			num = zero.x - num;
			num2 = zero.y - num2;
		}
		float num3 = num / _transform.GetComponent<RectTransform>().localScale.x;
		float num4 = num2 / _transform.GetComponent<RectTransform>().localScale.y;
		_transform.GetComponent<RectTransform>().localScale += Vector3.one * 0.01f * _value;
		m_Pointer.localPosition = Vector3.zero;
		if (lastAdsorptionMapIcon != null)
		{
			ExecuteEvents.Execute(lastAdsorptionMapIcon.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerExitHandler);
			lastAdsorptionMapIcon = null;
		}
		nowVector3 = _transform.GetComponent<RectTransform>().localScale;
		if (nowVector3.x < 0.33f)
		{
			_transform.GetComponent<RectTransform>().localScale = Vector3.one * 0.33f;
		}
		if (nowVector3.x > 1f)
		{
			_transform.GetComponent<RectTransform>().localScale = Vector3.one * 1f;
		}
		if ((double)nowVector3.x > 0.4 && !isShowName)
		{
			isShowName = true;
			foreach (Button icon in IconList)
			{
				icon.transform.Find("Name").gameObject.SetActive(isShowName);
			}
		}
		else if ((double)nowVector3.x < 0.4 && isShowName)
		{
			isShowName = false;
			foreach (Button icon2 in IconList)
			{
				icon2.transform.Find("Name").gameObject.SetActive(isShowName);
			}
		}
		float num5 = num3 * _transform.GetComponent<RectTransform>().localScale.x;
		float num6 = num4 * _transform.GetComponent<RectTransform>().localScale.y;
		float x = num - num5;
		float y = num2 - num6;
		_transform.localPosition += new Vector3(x, y, 0f);
		BorderCheck(Vector3.zero);
	}

	private void MovePointer(Vector3 _delta)
	{
		if (!(GetOverUI() != MapImage.gameObject))
		{
			float num = (float)Screen.width / 2f;
			float num2 = (float)Screen.height / 2f;
			Vector3 localPosition = m_Pointer.localPosition + _delta;
			localPosition.x = Mathf.Clamp(localPosition.x, 0f - num, num);
			localPosition.y = Mathf.Clamp(localPosition.y, 0f - num2, num2);
			m_Pointer.localPosition = localPosition;
		}
	}

	private void BorderCheck(Vector3 _delta)
	{
		if (!(GetOverUI() != MapImage.gameObject))
		{
			float num = MapImage.GetComponent<RectTransform>().rect.width * MapImage.localScale.x;
			float num2 = MapImage.GetComponent<RectTransform>().rect.height * MapImage.localScale.y;
			float num3 = (num - (float)Screen.width) / 2f;
			float num4 = (num2 - (float)Screen.height) / 2f;
			Vector3 localPosition = MapImage.localPosition + _delta;
			localPosition.x = Mathf.Clamp(localPosition.x, 0f - num3, num3);
			localPosition.y = Mathf.Clamp(localPosition.y, 0f - num4, num4);
			MapImage.localPosition = localPosition;
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		if (go.name.Equals("Yes"))
		{
			Teleport();
		}
		else if (go.name.Equals("No"))
		{
			confirmObj.SetActive(value: false);
			confirmCantObj.SetActive(value: false);
			telePortRow = null;
		}
		else if (go.name.Equals("Return"))
		{
			ExitScene();
		}
		else
		{
			if (!go.name.StartsWith("City") && !go.name.StartsWith("Stage") && !go.name.StartsWith("WuLin") && !go.name.StartsWith("Cave"))
			{
				return;
			}
			gang_e04Table.Row row = CommonResourcesData.e04.Find_id(SharedData.Instance().m_MapController.sceneName);
			if (row.savedata == "0" || row.teleport == "0")
			{
				confirmCantObj.SetActive(value: true);
				return;
			}
			telePortRow = go.GetComponent<MapIconController>().e07Row;
			if (telePortRow != null && telePortRow.MapName != "")
			{
				confirmObj.transform.Find("Image/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_QuickMove") + telePortRow.name_Trans + "</color>?";
				confirmObj.SetActive(value: true);
			}
		}
	}

	private void Teleport()
	{
		SharedData.Instance().IsViewOpen = false;
		SharedData.Instance().SpawnPoint = telePortRow.SpawnName;
		SharedData.Instance().SpawnStatus = "Normal";
		SharedData.Instance().m_MapController.LoadScene(telePortRow.MapName);
		telePortRow = null;
	}

	public void ExitScene()
	{
		if (!exiting)
		{
			exiting = true;
			SharedData.Instance().IsViewOpen = false;
			SharedData.Instance().m_MapController.PlayMapViewBgm(isShowMapView: false);
			SceneManager.UnloadSceneAsync("MapView");
		}
	}

	public void ShowIconInfo(MapIconController mapIconController)
	{
		IconInfo.transform.Find("Text").GetComponent<Text>().text = mapIconController.e07Row.name_Trans;
		IconInfo.localPosition = mapIconController.transform.localPosition + Vector3.down * 60f;
		IconInfo.gameObject.SetActive(value: true);
	}

	public void HideIconInfo()
	{
		IconInfo.gameObject.SetActive(value: false);
	}
}
