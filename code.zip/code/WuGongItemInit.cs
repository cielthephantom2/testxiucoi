using System.Collections.Generic;
using System.Globalization;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WuGongItemInit : MonoBehaviour
{
	public string ID = "";

	public int LV = 1;

	public float wugongAtkValue;

	public TMP_Dropdown m_wugongDropdow;

	public TMP_InputField m_wugongLV;

	public TMP_Text m_wugongAtkValue;

	public Button m_MinusWuGong;

	private void Awake()
	{
		m_wugongDropdow.ClearOptions();
		CommonResourcesData.b03.GetRowList();
		List<string> list = new List<string>();
		foreach (gang_b03Table.Row row in CommonResourcesData.b03.GetRowList())
		{
			list.Add(row.Name_Trans);
		}
		list.Add("None");
		m_wugongDropdow.AddOptions(list);
	}

	private void Update()
	{
		if (m_wugongDropdow.value != m_wugongDropdow.options.Count - 1 && m_wugongLV.text != "")
		{
			ID = CommonResourcesData.b03.GetRowList()[m_wugongDropdow.value].ID;
			LV = int.Parse(m_wugongLV.text, CultureInfo.InvariantCulture);
			gang_b03Table.Row row = CommonResourcesData.b03.Find_ID(ID);
			float num = float.Parse(row.Damage, CultureInfo.InvariantCulture) + (float)(LV - 1) * float.Parse(row.Damageadd, CultureInfo.InvariantCulture);
			m_wugongAtkValue.text = (num * num / 100f).ToString();
		}
	}

	public void Init()
	{
		if (ID != "")
		{
			m_wugongDropdow.value = CommonResourcesData.b03.GetRowList().IndexOf(CommonResourcesData.b03.Find_ID(ID));
			m_wugongLV.text = LV.ToString();
		}
		else
		{
			m_wugongDropdow.value = m_wugongDropdow.options.Count - 1;
			m_wugongLV.text = "0";
		}
	}

	public void OnMinusClick()
	{
		Object.Destroy(base.gameObject);
	}
}
