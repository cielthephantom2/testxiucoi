using Spine;
using Spine.Unity;
using UnityEngine;

public class BuffController : MonoBehaviour
{
	public bool loopRun;

	protected SkeletonAnimation m_Animation;

	private void Start()
	{
		GetComponent<MeshRenderer>().sortingOrder = SharedData.Instance().m_BattleController.m_Effect_SortingOrder;
		m_Animation = GetComponent<SkeletonAnimation>();
		m_Animation.AnimationState.SetAnimation(0, m_Animation.skeleton.Data.Animations.Items[0], loopRun);
		if (!loopRun)
		{
			m_Animation.AnimationState.Complete += State_Complete;
		}
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		Object.Destroy(base.gameObject);
	}
}
