using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class HoverController : MonoBehaviour
{
	[HideInInspector]
	public static bool isOpen;

	[HideInInspector]
	public static HoverController currentHover;

	private void Start()
	{
		isOpen = false;
		EventTriggerListener.Get(base.gameObject).onEnter = OnHoverMouseEnter;
		EventTriggerListener.Get(base.gameObject).onExit = OnHoverMouseExit;
	}

	private void OnHoverMouseEnter(GameObject go)
	{
		if (Cursor.visible)
		{
			HoverEnter(go);
		}
	}

	private void OnHoverMouseExit(GameObject go)
	{
		if (Cursor.visible)
		{
			HoverExit(go);
		}
	}

	public void HoverEnter(GameObject go)
	{
		Transform transform = base.transform.Find("Hover/Text");
		Text text = null;
		if (transform != null)
		{
			text = transform.GetComponent<Text>();
		}
		if (text != null && text.text != "")
		{
			base.transform.Find("Hover").gameObject.SetActive(value: true);
			float preferredHeight = text.preferredHeight;
			RectTransform component = base.transform.Find("Hover").GetComponent<RectTransform>();
			component.sizeDelta = new Vector2(component.sizeDelta.x, preferredHeight + 40f);
			currentHover = this;
			isOpen = true;
		}
	}

	private void HoverExit(GameObject go)
	{
		if (base.transform.Find("Hover") != null)
		{
			base.transform.Find("Hover").gameObject.SetActive(value: false);
			isOpen = false;
		}
	}

	private void SetOpenDetailName()
	{
		if (base.gameObject.scene.name == "StatusMain")
		{
			SharedData.Instance().m_OpenDetail = "StatusMainbuff" + base.gameObject.name;
		}
		else if (base.gameObject.scene.name == "StatusSub1")
		{
			if (base.transform.name == "Talent")
			{
				SharedData.Instance().m_OpenDetail = "StatusSub1" + base.transform.name;
			}
			else
			{
				SharedData.Instance().m_OpenDetail = "StatusSub1" + base.transform.name;
			}
		}
		else if (base.gameObject.scene.name == "StatusSub3")
		{
			SharedData.Instance().m_OpenDetail = "StatusSub3" + base.gameObject.name;
		}
		else if (base.gameObject.scene.name == "Starter3")
		{
			if (base.transform.parent.name == "Status")
			{
				SharedData.Instance().m_OpenDetail = "Starter3Status" + base.gameObject.name;
			}
			else if (base.transform.parent.name == "Traits")
			{
				SharedData.Instance().m_OpenDetail = "Starter3Traits" + base.gameObject.name;
			}
		}
	}

	private void HoverClick(GameObject go)
	{
		StartCoroutine(DelayOpenHover(go));
	}

	private IEnumerator DelayOpenHover(GameObject go)
	{
		yield return null;
		HoverEnter(go);
	}

	public void HoverDeselect()
	{
		base.transform.Find("Hover").gameObject.SetActive(value: false);
		isOpen = false;
	}

	public void HoverShow()
	{
		base.transform.Find("Hover").gameObject.SetActive(value: true);
		currentHover = this;
		isOpen = true;
	}

	private void OnDisable()
	{
		HoverExit(base.gameObject);
	}
}
