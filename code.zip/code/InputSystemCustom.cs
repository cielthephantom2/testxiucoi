public class InputSystemCustom
{
	private static InputSystemCustom instance;

	public JoyInputSystemManager joyInputSystemManager;

	public JoyInputSystemManager.UIActions UI;

	public JoyInputSystemManager.PlayerActions Player;

	public JoyControlMessenger JoyControlMessenger;

	public static InputSystemCustom Instance(bool init = false)
	{
		if (init || instance == null)
		{
			instance = new InputSystemCustom();
			instance.Init();
		}
		return instance;
	}

	private void Init()
	{
		joyInputSystemManager = new JoyInputSystemManager();
		joyInputSystemManager.Enable();
		UI = joyInputSystemManager.UI;
		Player = joyInputSystemManager.Player;
		UI.Enable();
		Player.Enable();
		JoyControlMessenger = new JoyControlMessenger();
	}
}
