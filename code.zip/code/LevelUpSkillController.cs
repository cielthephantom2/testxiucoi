using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelUpSkillController : MonoBehaviour
{
	private IronMan[] IronMen;

	private CharaData charadata;

	private KongFuData kfdata;

	private bool unloaded;

	private AudioSource m_AudioSource;

	private void Start()
	{
		InitLevelUpUI();
	}

	public void InitLevelUpUI()
	{
		if (SharedData.Instance().m_skillLevelUpIndex < SharedData.Instance().skillLevelupObjList.Count)
		{
			SharedData.Instance().skilllevelupObj = SharedData.Instance().skillLevelupObjList[SharedData.Instance().m_skillLevelUpIndex++];
		}
		string text = "";
		text = ((!(SharedData.Instance().skilllevelupObj == null)) ? SharedData.Instance().skilllevelupObj.charadata.m_Id : SharedData.Instance().playerid);
		if (!PackageController.skillLevekUpCharaID.Equals(""))
		{
			text = PackageController.skillLevekUpCharaID;
			PackageController.skillLevekUpCharaID = "";
		}
		CommonResourcesData.b01.Find_ID(text);
		charadata = SharedData.Instance().GetCharaData(text);
		kfdata = charadata.GetKongFuByID(charadata.m_LevelUpSkillId);
		if (kfdata == null)
		{
			Debug.LogWarning("Can NOT find charadata.m_LevelUpSkillId = " + charadata.m_LevelUpSkillId);
			Debug.LogWarning("Can NOT find charadata.m_Training_Id = " + charadata.m_Training_Id);
		}
		base.transform.Find("Panel/Icon/Image").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(kfdata.kf.BookIcon);
		base.transform.Find("Panel/LevelUp/Text").GetComponent<Text>().text = CommonFunc.ShortLangSel("《", "\"", "《") + kfdata.kf.Name_Trans + CommonFunc.ShortLangSel("》", "\"", "》") + " " + CommonFunc.I18nGetLocalizedValue("I18N_LevelUP") + " " + kfdata.newlv + " ！";
		if (kfdata.newlv.Equals(int.Parse(kfdata.kf.LV)))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1030");
			if (kfdata.kf.ID.Equals("10001"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1059");
			}
		}
		IronMen = base.transform.Find("Panel/Status").GetComponentsInChildren<IronMan>();
		IronMan[] ironMen = IronMen;
		foreach (IronMan ironMan in ironMen)
		{
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(ironMan.name);
			ironMan.GetComponent<Text>().text = row.NameScene_Trans;
		}
		Roll();
		m_AudioSource = GetComponent<AudioSource>();
		m_AudioSource.Play();
		if (SharedData.Instance().m_BattleController != null && SharedData.Instance().m_BattleController.AutoBattle)
		{
			StartCoroutine(ExitSceneDelay());
		}
	}

	private void LateUpdate()
	{
		if ((SharedData.Instance().m_BattleController != null && SharedData.Instance().skilllevelupObj == null) || unloaded || (!Input.GetMouseButtonUp(0) && !InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame() && !InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && !InputSystemCustom.Instance().UI.PackageUse.WasReleasedThisFrame()))
		{
			return;
		}
		if (SharedData.Instance().m_skillLevelUpIndex < SharedData.Instance().skillLevelupObjList.Count)
		{
			InitLevelUpUI();
			return;
		}
		if (SharedData.Instance().m_BattleController != null && SharedData.Instance().skilllevelupObj == SharedData.Instance().m_BattleController.current)
		{
			if (SharedData.Instance().skilllevelupObj.m_State == BattleObjectState.SkillLevelUp)
			{
				SharedData.Instance().skilllevelupObj.SetBattleObjState(BattleObjectState.SkillLevelUpOver);
			}
			else if (SharedData.Instance().skilllevelupObj.m_State == BattleObjectState.SkillLevelUpNeet)
			{
				SharedData.Instance().skilllevelupObj.SetBattleObjState(BattleObjectState.SkillLevelUpNeetOver);
			}
		}
		unloaded = true;
		SharedData.Instance().skillLevelupObjList?.Clear();
		SharedData.Instance().m_skillLevelUpIndex = 0;
		if (SharedData.Instance().m_MapController != null)
		{
			SharedData.Instance().LoadedSceneStack.RemoveAt(SharedData.Instance().LoadedSceneStack.Count - 1);
			if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_AppendTraitInfos.Length > 0)
			{
				string[] array = SharedData.Instance().m_AppendTraitInfos.Split('|');
				SharedData.Instance().m_AppendTraitInfos = "";
				string[] array2 = array;
				foreach (string info in array2)
				{
					SharedData.Instance().m_PackageController.EnabelBanner(info);
				}
			}
		}
		SceneManager.UnloadSceneAsync("LevelUpSkill");
	}

	private IEnumerator ExitSceneDelay()
	{
		yield return new WaitForSeconds(1f);
		if (SharedData.Instance().m_skillLevelUpIndex < SharedData.Instance().skillLevelupObjList.Count)
		{
			InitLevelUpUI();
			yield return null;
		}
		else
		{
			if (!(SharedData.Instance().m_BattleController != null) || (SharedData.Instance().skilllevelupObj.m_State != BattleObjectState.SkillLevelUp && SharedData.Instance().skilllevelupObj.m_State != BattleObjectState.SkillLevelUpNeet))
			{
				yield break;
			}
			if (SharedData.Instance().skilllevelupObj.m_State == BattleObjectState.SkillLevelUp)
			{
				SharedData.Instance().skilllevelupObj.SetBattleObjState(BattleObjectState.SkillLevelUpOver);
			}
			else if (SharedData.Instance().skilllevelupObj.m_State == BattleObjectState.SkillLevelUpNeet)
			{
				SharedData.Instance().skilllevelupObj.SetBattleObjState(BattleObjectState.SkillLevelUpNeetOver);
			}
			SharedData.Instance().skillLevelupObjList.Clear();
			SharedData.Instance().m_skillLevelUpIndex = 0;
			if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_AppendTraitInfos.Length > 0)
			{
				string[] array = SharedData.Instance().m_AppendTraitInfos.Split('|');
				foreach (string info in array)
				{
					SharedData.Instance().m_PackageController.EnabelBanner(info);
				}
			}
			SceneManager.UnloadSceneAsync("LevelUpSkill");
		}
	}

	private void Roll()
	{
		Dictionary<string, float> dictionary = new Dictionary<string, float>();
		if (kfdata.kf.Paraplus1 != "0")
		{
			string[] array = kfdata.kf.Paraplus1.Split('|');
			dictionary.Add(array[0], float.Parse(array[1], CultureInfo.InvariantCulture));
		}
		if (kfdata.kf.Paraplus2 != "0")
		{
			string[] array2 = kfdata.kf.Paraplus2.Split('|');
			dictionary.Add(array2[0], float.Parse(array2[1], CultureInfo.InvariantCulture));
		}
		if (kfdata.kf.Paraplus3 != "0")
		{
			string[] array3 = kfdata.kf.Paraplus3.Split('|');
			dictionary.Add(array3[0], float.Parse(array3[1], CultureInfo.InvariantCulture));
		}
		if (kfdata.kf.Paraplus4 != "0")
		{
			string[] array4 = kfdata.kf.Paraplus4.Split('|');
			dictionary.Add(array4[0], float.Parse(array4[1], CultureInfo.InvariantCulture));
		}
		if (dictionary.ContainsKey("Percept"))
		{
			dictionary["Percept"]++;
		}
		else
		{
			dictionary.Add("Percept", 1f);
		}
		IronMan[] ironMen = IronMen;
		foreach (IronMan ironMan in ironMen)
		{
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(ironMan.name);
			ironMan.transform.Find("Add").GetComponent<Text>().text = "";
			float fieldValueByName = charadata.GetFieldValueByName(ironMan.name);
			if (row.Type.Equals("2"))
			{
				ironMan.transform.Find("Text").GetComponent<Text>().text = Mathf.RoundToInt(fieldValueByName * 100f) + "%";
			}
			else
			{
				ironMan.transform.Find("Text").GetComponent<Text>().text = fieldValueByName.ToString() ?? "";
			}
			if (!dictionary.ContainsKey(ironMan.name))
			{
				continue;
			}
			float num = 0f;
			int j = kfdata.lv;
			for (int newlv = kfdata.newlv; j < newlv; j++)
			{
				num += dictionary[ironMan.name];
				if (ironMan.name.Equals("Percept"))
				{
					charadata.Indexs_Name[ironMan.name].levelupValue += dictionary[ironMan.name];
				}
			}
			if (num != 0f)
			{
				if (row.Type.Equals("2"))
				{
					num *= 100f;
				}
				Text component = ironMan.transform.Find("Add").GetComponent<Text>();
				component.text = component.text + " <color=#E1A532>" + ((num >= 0f) ? "+" : "") + num;
				if (row.Type.Equals("2"))
				{
					ironMan.transform.Find("Add").GetComponent<Text>().text += "%</color>";
				}
				else
				{
					ironMan.transform.Find("Add").GetComponent<Text>().text += "</color>";
				}
			}
		}
		kfdata.lv = kfdata.newlv;
		if (kfdata.lv >= int.Parse(kfdata.kf.LV))
		{
			kfdata.lv = int.Parse(kfdata.kf.LV);
			kfdata.exp = 0f;
		}
	}
}
