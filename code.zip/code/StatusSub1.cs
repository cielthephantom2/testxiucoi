using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class StatusSub1 : MonoBehaviour
{
	private Color unInteractableColor = new Color(40f / 51f, 40f / 51f, 40f / 51f, 0.5019608f);

	private Color stat_txt_common = new Color(0.62f, 0.56f, 0.49f, 1f);

	private Color stat_txt_highlight = new Color(0.93f, 0.89f, 0.8f, 1f);

	private Color stat_txt_darklight = new Color(0.23f, 0.22f, 0.18f, 1f);

	private Color stat_txt_good_2 = new Color(1f, 1f, 0.5f, 1f);

	private Color stat_txt_good_3 = new Color(1f, 0.49f, 0.15f, 1f);

	private Color stat_txt_reduce = Color.white;

	private Color stat_txt_add = Color.white;

	private string stat_txt_common_color = "#9a8b76";

	private string stat_txt_highlight_color = "#e3d1ad";

	private string stat_txt_reduce_color = "#cd451b";

	private string stat_txt_add_color = "#ebac34";

	private HoverController talentHover;

	private HoverController[] hovers;

	private List<IronMan> ironMen;

	private int totalCost;

	private Button confirmBtn;

	private CharaData curdata;

	private Dictionary<string, int> modifyAttr = new Dictionary<string, int>();

	private void Awake()
	{
		foreach (string item in new List<string> { "STR", "AGI", "BON", "WIL", "MOR", "LER" })
		{
			modifyAttr.Add(item, 0);
		}
		talentHover = base.transform.Find("Panel/Area2/Bg2/Talent").GetComponent<HoverController>();
		hovers = base.transform.Find("Panel/Area2").GetComponentsInChildren<HoverController>();
		ironMen = base.transform.Find("Panel/Area2").GetComponentsInChildren<IronMan>(includeInactive: true).ToList();
		confirmBtn = base.transform.Find("Panel/Area2/Confirm").GetComponent<Button>();
		Button[] componentsInChildren = base.transform.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		ColorUtility.TryParseHtmlString(stat_txt_common_color, out stat_txt_common);
		ColorUtility.TryParseHtmlString(stat_txt_highlight_color, out stat_txt_highlight);
		ColorUtility.TryParseHtmlString(stat_txt_add_color, out stat_txt_add);
		ColorUtility.TryParseHtmlString(stat_txt_reduce_color, out stat_txt_reduce);
		SharedData.Instance().m_StatusSub1 = this;
	}

	private void OnEnable()
	{
		if (!(SharedData.Instance().CurrentChara == ""))
		{
			curdata = SharedData.Instance().CurrentCharaData;
			if (curdata != null)
			{
				base.transform.Find("Panel/Area1/Name").GetComponent<Text>().text = curdata.Indexs_Name["Name"].stringValue;
				base.transform.Find("Panel/Area1/LV/Num").GetComponent<Text>().text = curdata.m_Level.ToString() ?? "";
				gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(curdata.m_Level.ToString() ?? "");
				base.transform.Find("Panel/Area1/Exp/Num").GetComponent<Text>().text = curdata.m_Exp + "/" + row.EXP;
				base.transform.Find("Panel/Area1/ExpBar").GetComponent<Slider>().value = (float)curdata.m_Exp / float.Parse(row.EXP, CultureInfo.InvariantCulture);
				UpdateUI(curdata);
			}
		}
	}

	private void OnDisable()
	{
		if (confirmBtn.GetComponent<Image>().color == Color.white && curdata != null)
		{
			foreach (IronMan ironMan in ironMen)
			{
				curdata.Indexs_Name[ironMan.name].talentValue -= ironMan.addValue;
				switch (ironMan.name)
				{
				case "STR":
					curdata.Indexs_Name["ATK"].bornValue -= 5f * (float)ironMan.addValue;
					curdata.Indexs_Name["DEF"].bornValue -= 5f * (float)ironMan.addValue;
					curdata.Indexs_Name["ATK"].rollValue = curdata.Indexs_Name["ATK"].bornValue;
					curdata.Indexs_Name["DEF"].rollValue = curdata.Indexs_Name["DEF"].bornValue;
					break;
				case "AGI":
					curdata.Indexs_Name["SP"].bornValue -= 5f * (float)ironMan.addValue;
					curdata.Indexs_Name["SP"].rollValue = curdata.Indexs_Name["SP"].bornValue;
					break;
				case "BON":
				{
					curdata.Indexs_Name["HP"].bornValue -= 25f * (float)ironMan.addValue;
					curdata.Indexs_Name["HP"].rollValue = curdata.Indexs_Name["HP"].bornValue;
					curdata.m_Hp -= 25f * (float)ironMan.addValue;
					float fieldValueByName2 = curdata.GetFieldValueByName("HP");
					if (curdata.m_Hp > fieldValueByName2)
					{
						curdata.m_Hp = fieldValueByName2;
					}
					break;
				}
				case "WIL":
				{
					curdata.Indexs_Name["MP"].bornValue -= 25f * (float)ironMan.addValue;
					curdata.Indexs_Name["MP"].rollValue = curdata.Indexs_Name["MP"].bornValue;
					curdata.m_Mp -= 25f * (float)ironMan.addValue;
					float fieldValueByName = curdata.GetFieldValueByName("MP");
					if (curdata.m_Mp > fieldValueByName)
					{
						curdata.m_Mp = fieldValueByName;
					}
					break;
				}
				}
				ironMan.addValue = 0;
				modifyAttr[ironMan.name] = 0;
			}
		}
		totalCost = 0;
	}

	private void UpdateUI(CharaData _curdata)
	{
		base.transform.Find("Panel/Area3/Status/HP/Num").GetComponent<Text>().text = _curdata.m_Hp + "/" + _curdata.GetFieldValueByName("HP");
		base.transform.Find("Panel/Area3/Status/MP/Num").GetComponent<Text>().text = _curdata.m_Mp + "/" + _curdata.GetFieldValueByName("MP");
		base.transform.Find("Panel/Area3/Status/Line1/ATK/Num").GetComponent<Text>().text = _curdata.GetFieldValueByName("ATK").ToString() ?? "";
		base.transform.Find("Panel/Area3/Status/Line2/DEF/Num").GetComponent<Text>().text = _curdata.GetFieldValueByName("DEF").ToString() ?? "";
		base.transform.Find("Panel/Area3/Status/Line3/SP/Num").GetComponent<Text>().text = _curdata.GetFieldValueByName("SP").ToString() ?? "";
		base.transform.Find("Panel/Area3/Status/Line1/Crit/Num").GetComponent<Text>().text = Mathf.RoundToInt(_curdata.GetFieldValueByName("Crit") * 100f) + "%";
		base.transform.Find("Panel/Area3/Status/Line2/Crit1/Num").GetComponent<Text>().text = Mathf.RoundToInt(_curdata.GetFieldValueByName("Crit1") * 100f) + "%";
		base.transform.Find("Panel/Area3/Status/Line3/Combo/Num").GetComponent<Text>().text = Mathf.RoundToInt(_curdata.GetFieldValueByName("Combo") * 100f) + "%";
		base.transform.Find("Panel/Area2/Bg2/Talent/Num").GetComponent<Text>().text = (_curdata.m_Talent - totalCost).ToString();
		SetInfo(_curdata, "STR");
		SetInfo(_curdata, "AGI");
		SetInfo(_curdata, "BON");
		SetInfo(_curdata, "WIL");
		SetInfo(_curdata, "LER");
		SetInfo(_curdata, "MOR", _plus: false);
		if (ironMen.Find((IronMan x) => x.addValue > 0) != null)
		{
			confirmBtn.GetComponent<Image>().color = Color.white;
		}
		else
		{
			confirmBtn.GetComponent<Image>().color = unInteractableColor;
		}
	}

	private void SetInfo(CharaData _curdata, string _name, bool _plus = true)
	{
		gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(_name);
		Transform transform = base.transform.Find("Panel/Area2/Status1/" + _name);
		transform.Find("Title/Text").GetComponent<Text>().text = row.NameUI_Trans;
		IronMan componentInChildren = transform.GetComponentInChildren<IronMan>();
		transform.Find("Num").GetComponent<Text>().text = _curdata.GetFieldValueByName(_name).ToString();
		componentInChildren.Init(_curdata.Indexs_Name[_name], _curdata);
		transform.Find("Num").GetComponent<Text>().color = stat_txt_common;
		if (_plus)
		{
			Button component = transform.Find("Specify/plus").GetComponent<Button>();
			Button component2 = transform.Find("Specify/reduce").GetComponent<Button>();
			int num = (int)_curdata.Indexs_Name[_name].basicValue;
			int num2 = int.MaxValue;
			if (num >= 0 && num <= 9)
			{
				num2 = 1;
			}
			else if (num >= 10 && num <= 19)
			{
				num2 = 2;
			}
			else if (num >= 20 && num <= 29)
			{
				num2 = 3;
			}
			if (transform.GetComponent<IronMan>().addValue > 0)
			{
				component2.GetComponent<Image>().color = Color.white;
			}
			else
			{
				component2.GetComponent<Image>().color = unInteractableColor;
			}
			if (num2 > 0 && _curdata.m_Talent - totalCost >= num2 && num < 30)
			{
				component.GetComponent<Image>().color = Color.white;
			}
			else
			{
				component.GetComponent<Image>().color = unInteractableColor;
			}
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable() || go.GetComponent<Image>()?.color == unInteractableColor)
		{
			return;
		}
		curdata = SharedData.Instance().CurrentCharaData;
		if (go.name == "plus" || go.name == "reduce")
		{
			string paraname = go.transform.parent.parent.name;
			IronMan ironMan = ironMen.Find((IronMan x) => x.name == paraname);
			int num = int.MaxValue;
			int num2 = Mathf.RoundToInt(curdata.Indexs_Name[paraname].basicValue) + ((!(go.name == "plus")) ? (-1) : 0);
			if (num2 >= 0 && num2 <= 9)
			{
				num = 1;
			}
			else if (num2 <= 19)
			{
				num = 2;
			}
			else if (num2 <= 29)
			{
				num = 3;
			}
			if (go.name == "plus")
			{
				ironMan.addValue++;
				ironMan.atomData.talentValue += 1f;
				totalCost += num;
			}
			else if (go.name == "reduce")
			{
				ironMan.addValue--;
				ironMan.atomData.talentValue -= 1f;
				totalCost -= num;
			}
			AddAttrCost(paraname, (go.name == "plus") ? num : (-num));
			switch (paraname)
			{
			case "STR":
				curdata.Indexs_Name["ATK"].bornValue += ((go.name == "plus") ? 5f : (-5f));
				curdata.Indexs_Name["DEF"].bornValue += ((go.name == "plus") ? 5f : (-5f));
				curdata.Indexs_Name["ATK"].rollValue = curdata.Indexs_Name["ATK"].bornValue;
				curdata.Indexs_Name["DEF"].rollValue = curdata.Indexs_Name["DEF"].bornValue;
				break;
			case "AGI":
				curdata.Indexs_Name["SP"].bornValue += ((go.name == "plus") ? 5f : (-5f));
				curdata.Indexs_Name["SP"].rollValue = curdata.Indexs_Name["SP"].bornValue;
				break;
			case "BON":
			{
				curdata.Indexs_Name["HP"].bornValue += ((go.name == "plus") ? 25f : (-25f));
				curdata.Indexs_Name["HP"].rollValue = curdata.Indexs_Name["HP"].bornValue;
				curdata.m_Hp += ((go.name == "plus") ? 25f : (-25f));
				float fieldValueByName2 = curdata.GetFieldValueByName("HP");
				if (curdata.m_Hp > fieldValueByName2)
				{
					curdata.m_Hp = fieldValueByName2;
				}
				SharedData.Instance().m_StatusMain.UpdateCurrentSlot();
				break;
			}
			case "WIL":
			{
				curdata.Indexs_Name["MP"].bornValue += ((go.name == "plus") ? 25f : (-25f));
				curdata.Indexs_Name["MP"].rollValue = curdata.Indexs_Name["MP"].bornValue;
				curdata.m_Mp += ((go.name == "plus") ? 25f : (-25f));
				float fieldValueByName = curdata.GetFieldValueByName("MP");
				if (curdata.m_Mp > fieldValueByName)
				{
					curdata.m_Mp = fieldValueByName;
				}
				SharedData.Instance().m_StatusMain.UpdateCurrentSlot();
				break;
			}
			}
		}
		else if (go.name == "Confirm")
		{
			curdata.m_Talent -= totalCost;
			totalCost = 0;
			foreach (IronMan ironMan2 in ironMen)
			{
				curdata.totalTalentCost += modifyAttr[ironMan2.name];
				ironMan2.addValue = 0;
				modifyAttr[ironMan2.name] = 0;
			}
		}
		UpdateUI(curdata);
	}

	private void AddAttrCost(string key, int value)
	{
		if (modifyAttr.ContainsKey(key))
		{
			modifyAttr[key] += value;
		}
		else
		{
			modifyAttr.Add(key, value);
		}
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.ConfirmAddTalent.WasReleasedThisFrame() && base.transform.Find("Panel/Area2/Confirm").GetComponent<Image>().color != unInteractableColor)
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Area2/Confirm").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/Area2/Confirm").gameObject);
		}
	}
}
