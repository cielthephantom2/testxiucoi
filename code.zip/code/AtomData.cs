using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using MessagePack;

[MessagePackObject(false)]
public class AtomData
{
	[IgnoreMember]
	public CharaData _charaData;

	[IgnoreMember]
	private float _equipValue;

	[IgnoreMember]
	private List<string> _equipList = new List<string>();

	[IgnoreMember]
	private float _equipTraitValue;

	[IgnoreMember]
	private string _equipTitleValue = "";

	[IgnoreMember]
	private Dictionary<string, string> _traitDict = new Dictionary<string, string>();

	[IgnoreMember]
	private float _wugongValue;

	[IgnoreMember]
	private Dictionary<string, int> _wugongDict = new Dictionary<string, int>();

	[IgnoreMember]
	public float traitValue;

	[Key(0)]
	public string a01Name = "";

	[Key(1)]
	public string a01ID = "";

	[Key(2)]
	public string stringValue = "";

	[Key(3)]
	public float bornValue;

	[Key(4)]
	public float alterValue;

	[Key(5)]
	private float _fightValue;

	[Key(7)]
	public float drunkbuffValue;

	[Key(8)]
	public float rollValue;

	[Key(9)]
	public float juqingValue;

	[Key(10)]
	public float levelupValue;

	[Key(11)]
	public float talentValue;

	[IgnoreMember]
	public float equipValue
	{
		get
		{
			if (_charaData != null && !_equipList.SequenceEqual(_charaData.m_EquipSlot))
			{
				_equipValue = GetEquipValue(_charaData);
				_equipList = _charaData.m_EquipSlot.ToList();
			}
			return _equipValue;
		}
	}

	[IgnoreMember]
	public float equipTraitValue
	{
		get
		{
			if (_charaData != null && (!AreDictionariesEqual(_traitDict, _charaData.m_EquipTraitDict) || !(_equipTitleValue == _charaData.m_currentTitleID)))
			{
				_equipTraitValue = GetTraitTitleValue(_charaData);
				_traitDict = _charaData.m_EquipTraitDict.ToDictionary((KeyValuePair<string, string> x) => x.Key, (KeyValuePair<string, string> x) => x.Value);
				_equipTitleValue = _charaData.m_currentTitleID;
			}
			return _equipTraitValue;
		}
	}

	[IgnoreMember]
	public float wugongValue
	{
		get
		{
			if (_charaData != null && !CompareKungfuDict(_charaData.m_KongFuList, _wugongDict))
			{
				_wugongValue = GetWugongValue(_charaData);
				_wugongDict.Clear();
				foreach (KongFuData kongFu in _charaData.m_KongFuList)
				{
					_wugongDict.Add(kongFu.kf.ID, kongFu.lv);
				}
			}
			return _wugongValue;
		}
	}

	[IgnoreMember]
	public float totalValue => rollValue + levelupValue + talentValue + alterValue + juqingValue + equipValue + equipTraitValue + wugongValue + traitValue;

	[IgnoreMember]
	public float basicValue => rollValue + levelupValue + talentValue;

	[IgnoreMember]
	public float wupinAndJuqingValue => alterValue + juqingValue;

	[Key(6)]
	public float fightValue
	{
		get
		{
			return _fightValue;
		}
		set
		{
			_fightValue = value;
		}
	}

	public static bool AreDictionariesEqual<TKey, TValue>(Dictionary<TKey, TValue> dict1, Dictionary<TKey, TValue> dict2)
	{
		if (dict1.Count != dict2.Count)
		{
			return false;
		}
		foreach (KeyValuePair<TKey, TValue> item in dict1)
		{
			if (!dict2.TryGetValue(item.Key, out var value))
			{
				return false;
			}
			if (!EqualityComparer<TValue>.Default.Equals(item.Value, value))
			{
				return false;
			}
		}
		return true;
	}

	public static bool CompareKungfuDict(List<KongFuData> kungfuList, Dictionary<string, int> saveKungfuDict)
	{
		if (kungfuList.Count != saveKungfuDict.Count)
		{
			return false;
		}
		foreach (KongFuData kungfu in kungfuList)
		{
			if (!saveKungfuDict.ContainsKey(kungfu.kf.ID))
			{
				return false;
			}
			if (saveKungfuDict[kungfu.kf.ID] != kungfu.lv)
			{
				return false;
			}
		}
		return true;
	}

	public void ResetValue()
	{
		bornValue = 0f;
		alterValue = 0f;
		rollValue = 0f;
		juqingValue = 0f;
		levelupValue = 0f;
		talentValue = 0f;
		traitValue = 0f;
	}

	public float GetEquipValue(CharaData _charadata)
	{
		if (_charadata == null)
		{
			return 0f;
		}
		float num = 0f;
		for (int i = 0; i < 3; i++)
		{
			if (!(_charadata.m_EquipSlot[i] == "0"))
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(_charadata.m_EquipSlot[i]);
				gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(row.Relateid);
				if (a01Name == row2.add1)
				{
					num += float.Parse(row2.Attribute1, CultureInfo.InvariantCulture);
				}
				if (a01Name == row2.add2)
				{
					num += float.Parse(row2.Attribute2, CultureInfo.InvariantCulture);
				}
				if (a01Name == row2.add3)
				{
					num += float.Parse(row2.Attribute3, CultureInfo.InvariantCulture);
				}
				if (a01Name == row2.add4)
				{
					num += float.Parse(row2.Attribute4, CultureInfo.InvariantCulture);
				}
				if (a01Name == row2.add5)
				{
					num += float.Parse(row2.Attribute5, CultureInfo.InvariantCulture);
				}
			}
		}
		string find = _charadata.m_EquipSlot[0] + "|" + _charadata.m_EquipSlot[1] + "|" + _charadata.m_EquipSlot[2];
		gang_b02SetTable.Row row3 = CommonResourcesData.b02Set.Find_Set(find);
		if (row3 != null)
		{
			if (a01Name == row3.add1)
			{
				num += float.Parse(row3.Attribute1, CultureInfo.InvariantCulture);
			}
			if (a01Name == row3.add2)
			{
				num += float.Parse(row3.Attribute2, CultureInfo.InvariantCulture);
			}
			if (a01Name == row3.add3)
			{
				num += float.Parse(row3.Attribute3, CultureInfo.InvariantCulture);
			}
			if (a01Name == row3.add4)
			{
				num += float.Parse(row3.Attribute4, CultureInfo.InvariantCulture);
			}
			if (a01Name == row3.add5)
			{
				num += float.Parse(row3.Attribute5, CultureInfo.InvariantCulture);
			}
		}
		return num;
	}

	public float GetTraitTitleValue(CharaData _charadata)
	{
		if (_charadata == null)
		{
			return 0f;
		}
		float num = 0f;
		foreach (KeyValuePair<string, string> item in _charadata.m_EquipTraitDict)
		{
			if (!(item.Value == ""))
			{
				gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.Value);
				if (a01Name == row.add1)
				{
					num += float.Parse(row.attribute1, CultureInfo.InvariantCulture);
				}
				if (a01Name == row.add2)
				{
					num += float.Parse(row.attribute2, CultureInfo.InvariantCulture);
				}
				if (a01Name == row.add3)
				{
					num += float.Parse(row.attribute3, CultureInfo.InvariantCulture);
				}
				if (a01Name == row.add4)
				{
					num += float.Parse(row.attribute4, CultureInfo.InvariantCulture);
				}
			}
		}
		float num2 = 0f;
		if (_charadata.m_currentTitleID != "")
		{
			gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(_charadata.m_currentTitleID);
			if (a01Name == row2.add1)
			{
				num2 += float.Parse(row2.attribute1, CultureInfo.InvariantCulture);
			}
			if (a01Name == row2.add2)
			{
				num2 += float.Parse(row2.attribute2, CultureInfo.InvariantCulture);
			}
			if (a01Name == row2.add3)
			{
				num2 += float.Parse(row2.attribute3, CultureInfo.InvariantCulture);
			}
			if (a01Name == row2.add4)
			{
				num2 += float.Parse(row2.attribute4, CultureInfo.InvariantCulture);
			}
		}
		return num + num2;
	}

	public float GetWugongValue(CharaData _charadata)
	{
		if (_charadata == null || _charadata.m_Table.Equals("b04"))
		{
			return 0f;
		}
		float num = 0f;
		foreach (KongFuData kongFu in _charadata.m_KongFuList)
		{
			foreach (string item in new List<string>
			{
				kongFu.kf.Paraplus1,
				kongFu.kf.Paraplus2,
				kongFu.kf.Paraplus3,
				kongFu.kf.Paraplus4
			})
			{
				if (!item.Equals("0") && !item.Equals(""))
				{
					string[] array = item.Split('|');
					if (array[0].Equals(a01Name))
					{
						num += (float)(kongFu.lv - 1) * float.Parse(array[1], CultureInfo.InvariantCulture);
					}
				}
			}
		}
		return num;
	}
}
