using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using DG.Tweening;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class AVGEngine : MonoBehaviour
{
	public Image m_BackGround;

	public GameObject m_Middle;

	public Image m_Front;

	public Image m_Tachie;

	public GameObject m_Dialog;

	public Text m_Dialog_Text;

	public Image m_Dialog_Next;

	public Text m_Title_Text;

	public AudioSource m_BGM;

	public AudioSource m_EffectSound;

	public GameObject m_Poser1;

	public GameObject m_Poser4;

	private int m_chat_process;

	private string m_chat_content = "";

	private string m_chating = "";

	private List<gang_f02Table.Row> m_f02rows = new List<gang_f02Table.Row>();

	private string m_LineType = "NR";

	private bool isExiting;

	private bool m_first_click;

	private bool m_pause;

	private string pre_Front = "0";

	private string pre_Tachie = "0";

	private string pre_BGM = "0";

	private SkeletonAnimation m_animation;

	private GameObject m_movie_play;

	private GameObject player;

	private void Start()
	{
		if (SharedData.Instance().player.charadata.m_TraitList.Contains("50002"))
		{
			StatsAndAchievements.Instance().UnlockAchievement("1063");
		}
		if ("CHECKFIFO".Equals(SharedData.Instance().PlayCGName))
		{
			foreach (string item in SharedData.Instance().m_EndAVGFIFO)
			{
				m_f02rows.AddRange(CommonResourcesData.f02.FindAll_Id(item));
			}
			SharedData.Instance().m_EndAVGFIFO.Clear();
		}
		else
		{
			m_f02rows = CommonResourcesData.f02.FindAll_Id(SharedData.Instance().PlayCGName);
		}
		if (m_f02rows.Count > 0)
		{
			Refresh(m_f02rows[0]);
			m_first_click = true;
			Click();
		}
	}

	private void FadeInFront(string _Front)
	{
		pre_Front = _Front;
		if ("13-?".Equals(_Front))
		{
			if (SharedData.Instance().FlagList["GLOBAL_FLAGS_Save_LuShiRu"] == 1)
			{
				m_Front.sprite = Resources.Load("images/95-AVG/Front/13-1", typeof(Sprite)) as Sprite;
			}
			else
			{
				m_Front.sprite = Resources.Load("images/95-AVG/Front/13-2", typeof(Sprite)) as Sprite;
			}
		}
		else if ("A04-?".Equals(_Front))
		{
			if (SharedData.Instance().FlagList["GLOBAL_FLAGS_Save_LuShiRu"] == 1)
			{
				m_Front.sprite = Resources.Load("images/95-AVG/Front/A04-2", typeof(Sprite)) as Sprite;
			}
			else
			{
				m_Front.sprite = Resources.Load("images/95-AVG/Front/A04-1", typeof(Sprite)) as Sprite;
			}
		}
		else if ("A05-?".Equals(_Front))
		{
			if (SharedData.Instance().FlagList["GLOBAL_FLAGS_Save_LuShiRu"] == 1)
			{
				m_Front.sprite = Resources.Load("images/95-AVG/Front/A05-1", typeof(Sprite)) as Sprite;
			}
			else
			{
				m_Front.sprite = Resources.Load("images/95-AVG/Front/A05-2", typeof(Sprite)) as Sprite;
			}
		}
		else
		{
			m_Front.sprite = Resources.Load("images/95-AVG/Front/" + _Front, typeof(Sprite)) as Sprite;
		}
		if ("Trans".Equals(_Front))
		{
			m_Front.color = new Color(1f, 1f, 1f, 1f);
			m_pause = false;
		}
		else
		{
			m_Front.DOFade(1f, 1.5f).OnComplete(delegate
			{
				m_pause = false;
			});
		}
	}

	private void FadeInTachie(string _Tachie)
	{
		pre_Tachie = _Tachie;
		if ("Player".Equals(_Tachie))
		{
			CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
			m_Tachie.sprite = CommonResourcesData.GetTachieFull(charaData.m_BattleIcon);
		}
		else
		{
			CharaData charaData2 = SharedData.Instance().GetCharaData(_Tachie);
			m_Tachie.sprite = CommonResourcesData.GetTachieFull(charaData2.m_BattleIcon);
		}
		m_Tachie.DOFade(1f, 1.5f).OnComplete(delegate
		{
			m_pause = false;
		});
	}

	private void State_Event(TrackEntry trackEntry, Spine.Event e)
	{
		if ("click".Equals(e.Data.Name))
		{
			m_animation.AnimationState.TimeScale = 0f;
		}
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		if (player != null)
		{
			player.SetActive(value: false);
			player = null;
		}
		if (m_f02rows.Count > 0)
		{
			m_movie_play.SetActive(value: false);
			m_movie_play = null;
			Refresh(m_f02rows[0]);
			Click();
		}
		else
		{
			ExitScene();
		}
	}

	private void Refresh(gang_f02Table.Row _row)
	{
		Debug.LogWarning("Refresh(): " + _row.SubId);
		if (!"0".Equals(_row.Title_Trans))
		{
			m_Title_Text.text = _row.Title_Trans;
		}
		if (!"0".Equals(_row.Bgm) && !pre_BGM.Equals(_row.Bgm))
		{
			m_BGM.clip = Resources.Load("Music/Bgm/" + _row.Bgm, typeof(AudioClip)) as AudioClip;
			m_BGM.Play();
			pre_BGM = _row.Bgm;
		}
		if (!"0".Equals(_row.BackGround))
		{
			m_BackGround.sprite = Resources.Load("images/95-AVG/BackGround/" + _row.BackGround, typeof(Sprite)) as Sprite;
		}
		if (!"0".Equals(_row.Middle))
		{
			m_movie_play = m_Middle.transform.Find(_row.Middle + CommonFunc.ShortLangSel("", "_EN", "_TW")).gameObject;
			if (m_movie_play != null)
			{
				m_movie_play.SetActive(value: true);
				m_animation = m_movie_play.GetComponent<SkeletonAnimation>();
				m_animation.AnimationState.Event += State_Event;
				m_animation.AnimationState.Complete += State_Complete;
			}
			if (_row.Middle == "SPINE-END-01" || _row.Middle == "SPINE-END-04")
			{
				CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
				player = SkinCharacter.InitSkinCharacter(charaData);
				SkeletonAnimation[] componentsInChildren = player.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
				SkeletonAnimation[] array = componentsInChildren;
				foreach (SkeletonAnimation obj in array)
				{
					obj.gameObject.GetComponent<MeshRenderer>().sortingOrder = 1;
					obj.gameObject.AddComponent<SortingGroup>().sortingOrder = 1;
				}
				componentsInChildren[0].gameObject.SetActive(value: false);
				componentsInChildren[1].gameObject.SetActive(value: false);
				componentsInChildren[2].gameObject.SetActive(value: true);
				componentsInChildren[2].AnimationState.SetAnimation(0, "A01-stand", loop: true);
				string middle = _row.Middle;
				if (!(middle == "SPINE-END-01"))
				{
					if (middle == "SPINE-END-04")
					{
						player.transform.SetParent(m_Poser4.transform);
					}
				}
				else
				{
					player.transform.SetParent(m_Poser1.transform);
				}
				player.transform.localPosition = Vector3.zero;
				player.transform.localScale = new Vector3(3f, 3f, 1f);
			}
		}
		if (!"0".Equals(_row.Front) && !pre_Front.Equals(_row.Front))
		{
			m_pause = true;
			if ("0".Equals(pre_Front) || "Trans".Equals(pre_Front))
			{
				m_Front.color = new Color(1f, 1f, 1f, 0f);
				FadeInFront(_row.Front);
			}
			else
			{
				m_Front.DOFade(0f, 1f).OnComplete(delegate
				{
					FadeInFront(_row.Front);
				});
			}
		}
		if (!"0".Equals(_row.Tachie) && !pre_Tachie.Equals(_row.Tachie))
		{
			m_pause = true;
			if ("0".Equals(pre_Tachie))
			{
				m_Tachie.color = new Color(1f, 1f, 1f, 0f);
				FadeInTachie(_row.Tachie);
			}
			else
			{
				m_Tachie.DOFade(0f, 1f).OnComplete(delegate
				{
					FadeInTachie(_row.Tachie);
				});
			}
		}
		else if ("0".Equals(_row.Tachie) && !"0".Equals(pre_Tachie))
		{
			pre_Tachie = "0";
			m_pause = true;
			m_Tachie.DOFade(0f, 1f).OnComplete(delegate
			{
				m_pause = false;
			});
		}
		if (!"0".Equals(_row.Line_Trans))
		{
			m_chating = _row.Line_Trans;
		}
		m_LineType = _row.Type;
		m_f02rows.Remove(_row);
	}

	private void Click()
	{
		if (m_Dialog_Next.gameObject.activeInHierarchy)
		{
			m_Dialog_Next.gameObject.SetActive(value: false);
			m_Dialog.SetActive(value: false);
			m_Dialog_Text.text = "";
			m_chat_process = 0;
		}
		if (m_chat_process == 0 && m_chating.Length > 0)
		{
			m_Dialog.SetActive(value: true);
			m_chat_content = m_chating.Replace("\\n", "\n");
			m_chating = "";
			m_chat_process = 1;
		}
	}

	private void Update()
	{
		if (isExiting || m_pause)
		{
			return;
		}
		if (m_movie_play != null)
		{
			if ((InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame() || Input.GetMouseButtonUp(0)) && m_animation.AnimationState.TimeScale == 0f)
			{
				m_animation.AnimationState.TimeScale = 1f;
			}
			return;
		}
		if (m_chat_process == 1)
		{
			StartCoroutine(TrendsText(m_chat_content));
			m_chat_process = 4;
		}
		else if (m_chat_process == 2)
		{
			if (!m_Dialog_Next.gameObject.activeInHierarchy)
			{
				m_Dialog_Next.gameObject.SetActive(value: true);
			}
		}
		else if (m_chat_process == 3)
		{
			Refresh(m_f02rows[0]);
			m_chat_content = m_chating.Replace("\\n", "\n");
			m_chating = "";
			m_chat_process = 1;
		}
		if (!InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame() && !Input.GetMouseButtonUp(0))
		{
			return;
		}
		if (!m_first_click)
		{
			Click();
			m_first_click = true;
		}
		else if (m_Dialog_Next.gameObject.activeInHierarchy)
		{
			if (m_f02rows.Count > 0)
			{
				Refresh(m_f02rows[0]);
				Click();
			}
			else
			{
				ExitScene();
			}
		}
	}

	private IEnumerator TrendsText(string _chat_content)
	{
		char[] chat_content = _chat_content.ToCharArray();
		int idx = 0;
		string richright = "";
		string tmp_chat_text = m_Dialog_Text.text;
		while (idx < chat_content.Length)
		{
			if (chat_content[idx] == '<')
			{
				int num = idx;
				if (chat_content[num + 1] == '/')
				{
					tmp_chat_text += chat_content[num++];
					tmp_chat_text += chat_content[num++];
					while (chat_content[num] != '>')
					{
						tmp_chat_text += chat_content[num++];
					}
					tmp_chat_text += chat_content[num++];
					richright = "";
					idx = num;
					continue;
				}
				tmp_chat_text += chat_content[num++];
				richright = "</";
				while (chat_content[num] != '=')
				{
					richright += chat_content[num];
					tmp_chat_text += chat_content[num++];
				}
				richright += ">";
				while (chat_content[num] != '>')
				{
					tmp_chat_text += chat_content[num++];
				}
				tmp_chat_text += chat_content[num++];
				idx = num;
			}
			else
			{
				PlaySoundEffect("Talk", "0", null);
				tmp_chat_text += chat_content[idx++];
				m_Dialog_Text.text = tmp_chat_text + richright;
				yield return new WaitForSeconds(0.15f);
			}
		}
		string lineType = m_LineType;
		if (!(lineType == "BR"))
		{
			if (lineType == "NR")
			{
				m_chat_process = 2;
			}
		}
		else
		{
			m_chat_process = 3;
		}
	}

	private void PlaySoundEffect(string _url, string _delay, UnityEngine.Event _event)
	{
		float delay = float.Parse(_delay, CultureInfo.InvariantCulture);
		if (m_EffectSound != null)
		{
			if (_event != null)
			{
				StartCoroutine(PlaySoundEffectDelay(_url, delay, _event));
				return;
			}
			m_EffectSound.clip = Resources.Load("Music/SE/" + _url, typeof(AudioClip)) as AudioClip;
			m_EffectSound.Play();
		}
	}

	protected IEnumerator PlaySoundEffectDelay(string _url, float _delay, UnityEngine.Event _event)
	{
		m_EffectSound.clip = Resources.Load("Music/SE/" + _url, typeof(AudioClip)) as AudioClip;
		m_EffectSound.Play();
		yield return new WaitForSeconds(_delay);
	}

	private void ExitScene()
	{
		isExiting = true;
		if (SharedData.Instance().AfterCGPlayComplete.Length > 0)
		{
			SharedData.Instance().FlagList[SharedData.Instance().AfterCGPlayComplete] = 1;
		}
		if (SharedData.Instance().SceneBefore.Length > 0)
		{
			SharedData.Instance().BackFromOtherScene = true;
			SharedData.Instance().ASyncLoadScene(SharedData.Instance().SceneBefore);
		}
	}
}
