using System.Globalization;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class AchievementController : MonoBehaviour
{
	private bool exiting;

	private GameObject AchievementPrefab;

	private ScrollRect m_ScrollRect;

	private Transform m_ScrollRectContents;

	private RectTransform rectTrans;

	private void Start()
	{
		AchievementPrefab = (GameObject)Resources.Load("Prefabs/Achievements/Achievement");
		m_ScrollRect = base.transform.Find("Panel/ScrollView").GetComponent<ScrollRect>();
		m_ScrollRectContents = m_ScrollRect.transform.Find("Viewport/Content");
		rectTrans = m_ScrollRectContents.GetComponent<RectTransform>();
		EventTriggerListener.Get(GameObject.Find("Panel/Return")).onClick = OnButtonClick;
		InitAchievement();
	}

	public void InitAchievement()
	{
		foreach (StatsAndAchievementsData statsAndAchievementsData in GameDataManager.Instance().statsAndAchievementsDataList)
		{
			if (statsAndAchievementsData.Achieved == "1")
			{
				InitAchieveObj(statsAndAchievementsData.ID);
			}
		}
		foreach (StatsAndAchievementsData statsAndAchievementsData2 in GameDataManager.Instance().statsAndAchievementsDataList)
		{
			if (statsAndAchievementsData2.Achieved == "0" && statsAndAchievementsData2.Hidden == "0")
			{
				InitAchieveObj(statsAndAchievementsData2.ID);
			}
		}
		foreach (StatsAndAchievementsData statsAndAchievementsData3 in GameDataManager.Instance().statsAndAchievementsDataList)
		{
			if (statsAndAchievementsData3.Achieved == "0" && statsAndAchievementsData3.Hidden == "1")
			{
				InitAchieveObj(statsAndAchievementsData3.ID);
			}
		}
	}

	private void InitAchieveObj(string _id)
	{
		StatsAndAchievementsData statsAndAchievementsData = GameDataManager.Instance().statsAndAchievementsDataList.Find((StatsAndAchievementsData x) => x.ID == _id);
		GameObject gameObject = Object.Instantiate(AchievementPrefab, m_ScrollRectContents);
		if (statsAndAchievementsData.Hidden == "0")
		{
			gameObject.transform.Find("Name").GetComponent<Text>().text = statsAndAchievementsData.Name;
			gameObject.transform.Find("Describe").GetComponent<Text>().text = statsAndAchievementsData.Describe;
			if (statsAndAchievementsData.Achieved == "1")
			{
				gameObject.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/300-" + statsAndAchievementsData.AchievedIcon, typeof(Sprite)) as Sprite;
			}
			else
			{
				gameObject.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/300-" + statsAndAchievementsData.UnAchievedIcon, typeof(Sprite)) as Sprite;
			}
		}
		else if (statsAndAchievementsData.Achieved == "1")
		{
			gameObject.transform.Find("Name").GetComponent<Text>().text = statsAndAchievementsData.Name;
			gameObject.transform.Find("Describe").GetComponent<Text>().text = statsAndAchievementsData.Describe;
			gameObject.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/300-" + statsAndAchievementsData.AchievedIcon, typeof(Sprite)) as Sprite;
		}
		else
		{
			gameObject.transform.Find("Name").GetComponent<Text>().text = "************";
			gameObject.transform.Find("Describe").GetComponent<Text>().text = "************";
			gameObject.transform.Find("Icon").GetComponent<Image>().sprite = Resources.Load("images/07-icon/300-" + statsAndAchievementsData.UnAchievedIcon, typeof(Sprite)) as Sprite;
		}
		if (statsAndAchievementsData.Type == "1" && (statsAndAchievementsData.Achieved == "1" || statsAndAchievementsData.Hidden == "0"))
		{
			gameObject.transform.Find("Stats").gameObject.SetActive(value: true);
			gameObject.transform.Find("Stats/CurStats").GetComponent<Image>().fillAmount = float.Parse(statsAndAchievementsData.CurValue, CultureInfo.InvariantCulture) / float.Parse(statsAndAchievementsData.TotalValue, CultureInfo.InvariantCulture);
			gameObject.transform.Find("Stats/Value").GetComponent<Text>().text = float.Parse(statsAndAchievementsData.CurValue, CultureInfo.InvariantCulture) + "/" + float.Parse(statsAndAchievementsData.TotalValue, CultureInfo.InvariantCulture);
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable() && go.name == "Return" && !exiting)
		{
			exiting = true;
			SceneManager.LoadScene("Title");
		}
	}
}
