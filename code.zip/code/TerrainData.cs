using MessagePack;
using UnityEngine;

[MessagePackObject(false)]
public class TerrainData
{
	[Key(0)]
	public int terrainKeepTime = 1;

	[Key(1)]
	public bool isPersistent;

	[Key(2)]
	public bool loopRun;

	[Key(3)]
	public TerrainType t_type = TerrainType.UNKNOWN;

	[Key(4)]
	public float damageValue;

	[Key(5)]
	public bool isBlasting;

	[Key(6)]
	public float m_BlastSputterATKup;

	[Key(7)]
	public float m_BlastAttackDizzy;

	[Key(8)]
	public float m_BlastSputterAttackDizzy;

	[Key(9)]
	public Vector3Int m_pos = Vector3Int.zero;
}
