public enum SaveOrLoad
{
	Save,
	Load
}
