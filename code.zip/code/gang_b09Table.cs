using System.Collections.Generic;
using UnityEngine;

public class gang_b09Table
{
	public class Row
	{
		public string ID;

		public string BattleIcon;

		public string Name;

		public string Name_EN;

		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				BattleIcon = list[i][num++],
				Name = list[i][num++]
			};
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_b09_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_b09_" + row.ID + "_Name")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Name_EN(string find)
	{
		return rowList.Find((Row x) => x.Name_EN == find);
	}

	public List<Row> FindAll_Name_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Name_EN == find);
	}
}
