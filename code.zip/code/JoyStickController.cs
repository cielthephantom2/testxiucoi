using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class JoyStickController : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IDragHandler, IPointerUpHandler
{
	private Sprite m_JoyStick_Normal;

	private Sprite m_JoyStick_Up;

	private Sprite m_JoyStick_Right;

	private Sprite m_JoyStick_Down;

	private Sprite m_JoyStick_Left;

	private Canvas canvas;

	private Image m_FixJoyStick;

	[HideInInspector]
	public Vector2 input = Vector2.zero;

	[SerializeField]
	private float moveThreshold = 1f;

	[SerializeField]
	private float deadZone;

	[SerializeField]
	private RectTransform background;

	[SerializeField]
	private RectTransform handle;

	private Camera cam;

	public float MoveThreshold
	{
		get
		{
			return moveThreshold;
		}
		set
		{
			moveThreshold = Mathf.Abs(value);
		}
	}

	private void Start()
	{
		canvas = GetComponentInParent<Canvas>();
		if (canvas == null)
		{
			Debug.LogError("The Joystick is not placed inside a canvas");
		}
		cam = null;
		if (canvas.renderMode == RenderMode.ScreenSpaceCamera)
		{
			cam = canvas.worldCamera;
		}
		m_FixJoyStick = background.gameObject.GetComponent<Image>();
		m_JoyStick_Normal = Resources.Load("images/09-VirtualJoyStick/Mobile-move-default-20230105", typeof(Sprite)) as Sprite;
		m_JoyStick_Up = Resources.Load("images/09-VirtualJoyStick/Mobile-move-UP-20230105", typeof(Sprite)) as Sprite;
		m_JoyStick_Right = Resources.Load("images/09-VirtualJoyStick/Mobile-move-Right-20230105", typeof(Sprite)) as Sprite;
		m_JoyStick_Down = Resources.Load("images/09-VirtualJoyStick/Mobile-move-DOWN-20230105", typeof(Sprite)) as Sprite;
		m_JoyStick_Left = Resources.Load("images/09-VirtualJoyStick/Mobile-move-LEFT-20230105", typeof(Sprite)) as Sprite;
		m_FixJoyStick.sprite = m_JoyStick_Normal;
		handle.gameObject.SetActive(value: false);
	}

	private void OnDisable()
	{
		if (m_FixJoyStick != null)
		{
			m_FixJoyStick.sprite = m_JoyStick_Normal;
		}
		if (handle != null)
		{
			handle.gameObject.SetActive(value: false);
		}
	}

	public void OnPointerDown(PointerEventData eventData)
	{
		OnDrag(eventData);
	}

	public void OnDrag(PointerEventData eventData)
	{
		Vector2 vector = RectTransformUtility.WorldToScreenPoint(cam, background.position);
		Vector2 vector2 = background.sizeDelta / 2f;
		input = (eventData.position - vector) / (vector2 * canvas.scaleFactor);
		if (input.magnitude < deadZone)
		{
			input = Vector2.zero;
		}
		handle.anchoredPosition = input * vector2;
		if (input != Vector2.zero)
		{
			FormatInput();
			if (!handle.gameObject.activeInHierarchy)
			{
				handle.gameObject.SetActive(value: true);
			}
		}
	}

	public void OnPointerUp(PointerEventData eventData)
	{
		input = Vector2.zero;
		handle.anchoredPosition = Vector2.zero;
		handle.gameObject.SetActive(value: false);
		m_FixJoyStick.sprite = m_JoyStick_Normal;
	}

	private void FormatInput()
	{
		if (Mathf.Abs(input.x) > Mathf.Abs(input.y))
		{
			input.y = 0f;
			if (input.x > 0f)
			{
				m_FixJoyStick.sprite = m_JoyStick_Right;
			}
			else
			{
				m_FixJoyStick.sprite = m_JoyStick_Left;
			}
		}
		else
		{
			input.x = 0f;
			if (input.y > 0f)
			{
				m_FixJoyStick.sprite = m_JoyStick_Up;
			}
			else
			{
				m_FixJoyStick.sprite = m_JoyStick_Down;
			}
		}
		input = input.normalized;
	}
}
