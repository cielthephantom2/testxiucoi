using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine.Tilemaps;

internal class RandomFightInfo
{
	public Tilemap tilemap;

	public bool couldFight = true;

	public int currentStep;

	public string GIDList = "";

	public bool isUnique;

	public int requireStep = 10;

	public float battleRate;

	public int enemyCountMax;

	public int enemyCountMin;

	public List<string> battleFieldList = new List<string>();

	public Dictionary<string, Dictionary<int, List<gang_b04Table.Row>>> GIDGroupDict = new Dictionary<string, Dictionary<int, List<gang_b04Table.Row>>>();

	public RandomFightInfo(Tilemap _tilemap)
	{
		if (_tilemap == null)
		{
			throw new ArgumentException("RandomFightInfo: tilemap in null");
		}
		tilemap = _tilemap;
		string[] array = tilemap.name.Split('|');
		gang_b04RandomFightInfos.Row row = CommonResourcesData.b04RandomFightInfos.Find_ID(array[1]);
		GIDList = row.GID;
		isUnique = row.Unique.Equals("1");
		requireStep = int.Parse(row.RequireStep);
		battleRate = float.Parse(row.BattleRate, CultureInfo.InvariantCulture);
		enemyCountMax = int.Parse(row.MaxEnemy);
		enemyCountMin = int.Parse(row.MinEnemy);
		battleFieldList = row.BattleField.Split('|').ToList();
		string[] array2 = GIDList.Split('&');
		foreach (string text in array2)
		{
			GIDGroupDict.Add(text, new Dictionary<int, List<gang_b04Table.Row>>());
			for (int j = 1; j <= 7; j++)
			{
				GIDGroupDict[text].Add(j, new List<gang_b04Table.Row>());
			}
			foreach (gang_b04Table.Row item in CommonResourcesData.b04_Random.FindAll_GID(text))
			{
				int num = int.Parse(item.LV);
				if (num >= 1 && num <= 5)
				{
					GIDGroupDict[text][1].Add(item);
				}
				if (num >= 5 && num <= 20)
				{
					GIDGroupDict[text][2].Add(item);
				}
				if (num >= 10 && num <= 30)
				{
					GIDGroupDict[text][3].Add(item);
				}
				if (num >= 20 && num <= 40)
				{
					GIDGroupDict[text][4].Add(item);
				}
				if (num >= 40 && num <= 60)
				{
					GIDGroupDict[text][5].Add(item);
				}
				if (num >= 60 && num <= 80)
				{
					GIDGroupDict[text][6].Add(item);
				}
				if (num >= 80 && num <= 100)
				{
					GIDGroupDict[text][7].Add(item);
				}
			}
		}
	}
}
