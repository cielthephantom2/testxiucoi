using System.Collections.Generic;
using UnityEngine;

public class gang_b15Table
{
	public class Row
	{
		public string ID;

		public string Name;

		public string Skill1;

		public string Skill2;

		public string Skill3;

		public string Skill4;

		public string Skill5;

		public string Skill6;

		public string Skill7;

		public string Skill8;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Name = list[i][num++],
				Skill1 = list[i][num++],
				Skill2 = list[i][num++],
				Skill3 = list[i][num++],
				Skill4 = list[i][num++],
				Skill5 = list[i][num++],
				Skill6 = list[i][num++],
				Skill7 = list[i][num++],
				Skill8 = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}
}
