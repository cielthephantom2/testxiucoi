using System.Collections.Generic;
using MessagePack;
using UnityEngine;

public class gang_b02Table
{
	[MessagePackObject(false)]
	public class Row
	{
		[Key(0)]
		public string ID;

		[Key(1)]
		public string Name;

		[Key(2)]
		public string Name_EN;

		[Key(3)]
		public string Style;

		[Key(4)]
		public string Limit1;

		[Key(5)]
		public string Logic;

		[Key(6)]
		public string Limitvalue;

		[Key(7)]
		public string Role;

		[Key(8)]
		public string add1;

		[Key(9)]
		public string Attribute1;

		[Key(10)]
		public string add2;

		[Key(11)]
		public string Attribute2;

		[Key(12)]
		public string add3;

		[Key(13)]
		public string Attribute3;

		[Key(14)]
		public string add4;

		[Key(15)]
		public string Attribute4;

		[Key(16)]
		public string add5;

		[Key(17)]
		public string Attribute5;

		[Key(18)]
		public string Skills1;

		[Key(19)]
		public string Skills1Ec;

		[Key(20)]
		public int Enhance;

		[Key(21)]
		public string isAtlas;

		[Key(23)]
		public string atlasType;

		[Key(22)]
		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				Name = list[i][num++],
				Style = list[i][num++],
				atlasType = list[i][num++],
				Limit1 = list[i][num++],
				Logic = list[i][num++],
				Limitvalue = list[i][num++],
				Role = list[i][num++],
				add1 = list[i][num++],
				Attribute1 = list[i][num++],
				add2 = list[i][num++],
				Attribute2 = list[i][num++],
				add3 = list[i][num++],
				Attribute3 = list[i][num++],
				add4 = list[i][num++],
				Attribute4 = list[i][num++],
				add5 = list[i][num++],
				Attribute5 = list[i][num++],
				Skills1 = list[i][num++],
				Skills1Ec = list[i][num++],
				Enhance = int.Parse(list[i][num++]),
				isAtlas = list[i][num++]
			};
			row.Name = I18nData.Instance().tableI18N.Find_ID("gang_b02_" + row.ID + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID("gang_b02_" + row.ID + "_Name")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Name_EN(string find)
	{
		return rowList.Find((Row x) => x.Name_EN == find);
	}

	public List<Row> FindAll_Name_EN(string find)
	{
		return rowList.FindAll((Row x) => x.Name_EN == find);
	}

	public Row Find_Style(string find)
	{
		return rowList.Find((Row x) => x.Style == find);
	}

	public List<Row> FindAll_Style(string find)
	{
		return rowList.FindAll((Row x) => x.Style == find);
	}

	public Row Find_Limit1(string find)
	{
		return rowList.Find((Row x) => x.Limit1 == find);
	}

	public List<Row> FindAll_Limit1(string find)
	{
		return rowList.FindAll((Row x) => x.Limit1 == find);
	}

	public Row Find_Logic(string find)
	{
		return rowList.Find((Row x) => x.Logic == find);
	}

	public List<Row> FindAll_Logic(string find)
	{
		return rowList.FindAll((Row x) => x.Logic == find);
	}

	public Row Find_Limitvalue(string find)
	{
		return rowList.Find((Row x) => x.Limitvalue == find);
	}

	public List<Row> FindAll_Limitvalue(string find)
	{
		return rowList.FindAll((Row x) => x.Limitvalue == find);
	}

	public Row Find_Role(string find)
	{
		return rowList.Find((Row x) => x.Role == find);
	}

	public List<Row> FindAll_Role(string find)
	{
		return rowList.FindAll((Row x) => x.Role == find);
	}

	public Row Find_add1(string find)
	{
		return rowList.Find((Row x) => x.add1 == find);
	}

	public List<Row> FindAll_add1(string find)
	{
		return rowList.FindAll((Row x) => x.add1 == find);
	}

	public Row Find_Attribute1(string find)
	{
		return rowList.Find((Row x) => x.Attribute1 == find);
	}

	public List<Row> FindAll_Attribute1(string find)
	{
		return rowList.FindAll((Row x) => x.Attribute1 == find);
	}

	public Row Find_add2(string find)
	{
		return rowList.Find((Row x) => x.add2 == find);
	}

	public List<Row> FindAll_add2(string find)
	{
		return rowList.FindAll((Row x) => x.add2 == find);
	}

	public Row Find_Attribute2(string find)
	{
		return rowList.Find((Row x) => x.Attribute2 == find);
	}

	public List<Row> FindAll_Attribute2(string find)
	{
		return rowList.FindAll((Row x) => x.Attribute2 == find);
	}

	public Row Find_add3(string find)
	{
		return rowList.Find((Row x) => x.add3 == find);
	}

	public List<Row> FindAll_add3(string find)
	{
		return rowList.FindAll((Row x) => x.add3 == find);
	}

	public Row Find_Attribute3(string find)
	{
		return rowList.Find((Row x) => x.Attribute3 == find);
	}

	public List<Row> FindAll_Attribute3(string find)
	{
		return rowList.FindAll((Row x) => x.Attribute3 == find);
	}

	public Row Find_add4(string find)
	{
		return rowList.Find((Row x) => x.add4 == find);
	}

	public List<Row> FindAll_add4(string find)
	{
		return rowList.FindAll((Row x) => x.add4 == find);
	}

	public Row Find_Attribute4(string find)
	{
		return rowList.Find((Row x) => x.Attribute4 == find);
	}

	public List<Row> FindAll_Attribute4(string find)
	{
		return rowList.FindAll((Row x) => x.Attribute4 == find);
	}
}
