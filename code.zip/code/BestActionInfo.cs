using UnityEngine;

public class BestActionInfo
{
	public string skill = "";

	public string itemID = "";

	public Vector3Int actionPos = Vector3Int.zero;

	public Vector3Int targetPos = Vector3Int.zero;

	public int skillEffectNumber;

	public int skillEffectValue;

	public int enemiesDisAverage;

	public int alliesDisAverage;

	public float paretoValue;

	public float terrainDamageValue;
}
