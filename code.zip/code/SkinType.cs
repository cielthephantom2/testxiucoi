public enum SkinType
{
	None,
	MaleNormal,
	MaleStrong,
	MaleFat,
	FemaleNormal,
	FemaleSpecial
}
