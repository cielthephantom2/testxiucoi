using System.Collections.Generic;
using UnityEngine;

public class SampleTable
{
	public class Row
	{
		public string Year;

		public string Make;

		public string Model;

		public string Description;

		public string Price;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			Row row = new Row();
			row.Year = list[i][0];
			row.Make = list[i][1];
			row.Model = list[i][2];
			row.Description = list[i][3];
			row.Price = list[i][4];
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_Year(string find)
	{
		return rowList.Find((Row x) => x.Year == find);
	}

	public List<Row> FindAll_Year(string find)
	{
		return rowList.FindAll((Row x) => x.Year == find);
	}

	public Row Find_Make(string find)
	{
		return rowList.Find((Row x) => x.Make == find);
	}

	public List<Row> FindAll_Make(string find)
	{
		return rowList.FindAll((Row x) => x.Make == find);
	}

	public Row Find_Model(string find)
	{
		return rowList.Find((Row x) => x.Model == find);
	}

	public List<Row> FindAll_Model(string find)
	{
		return rowList.FindAll((Row x) => x.Model == find);
	}

	public Row Find_Description(string find)
	{
		return rowList.Find((Row x) => x.Description == find);
	}

	public List<Row> FindAll_Description(string find)
	{
		return rowList.FindAll((Row x) => x.Description == find);
	}

	public Row Find_Price(string find)
	{
		return rowList.Find((Row x) => x.Price == find);
	}

	public List<Row> FindAll_Price(string find)
	{
		return rowList.FindAll((Row x) => x.Price == find);
	}
}
