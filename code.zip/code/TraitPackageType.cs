public enum TraitPackageType
{
	None,
	Title,
	IndexTraits,
	AllTraits
}
