using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadingController : MonoBehaviour
{
	private int frameCount;

	private Text percent;

	private void Awake()
	{
		SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: false);
		MapLoader.instance.AddressablesLoadOneMap(SharedData.Instance().loadMapE04);
		percent = GameObject.Find("Canvas/Panel/Text").GetComponent<Text>();
	}

	private void Update()
	{
		percent.text = CommonFunc.I18nGetLocalizedValue("I18N_Loading") + ": " + frameCount++;
		if (MapLoader.instance.isAddressableLoad)
		{
			SkinCharacter.initSkeletonGraphicList.Clear();
			if (SharedData.Instance().loadMapE04.id.StartsWith("Field_") || SharedData.Instance().loadMapE04.id.StartsWith("Map_") || SharedData.Instance().loadMapE04.id.StartsWith("Scene_"))
			{
				SceneManager.LoadScene("Field_Template");
			}
			else if (SharedData.Instance().loadMapE04.id.StartsWith("BattleField-"))
			{
				SceneManager.LoadScene("Battle_Template");
			}
		}
	}
}
