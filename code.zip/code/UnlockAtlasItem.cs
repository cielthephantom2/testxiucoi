using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class UnlockAtlasItem
{
	[Key(0)]
	public string ID;

	[Key(1)]
	public string tableName;

	[Key(2)]
	public bool isRead;
}
