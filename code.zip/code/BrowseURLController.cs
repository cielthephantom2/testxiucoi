using UnityEngine;
using UnityEngine.UI;

public class BrowseURLController : MonoBehaviour
{
	private MapController mapcontroller;

	private GameObject FakeExitObj;

	private GameObject TrueExitObj;

	private GameObject SteamObj;

	private GameObject SteamENObj;

	private GameObject SteamTWObj;

	private void Awake()
	{
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
		Button[] componentsInChildren = base.gameObject.GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button obj in componentsInChildren)
		{
			EventTriggerListener.Get(obj.gameObject).onEnter = OnButtonEnter;
			EventTriggerListener.Get(obj.gameObject).onClick = OnButtonClick;
		}
		FakeExitObj = base.transform.Find("FAKEEXIT").gameObject;
		FakeExitObj.SetActive(value: true);
		TrueExitObj = base.transform.Find("TRUEEXIT").gameObject;
		TrueExitObj.SetActive(value: false);
		SteamObj = base.transform.Find("BACK/STEAM").gameObject;
		SteamENObj = base.transform.Find("BACK/STEAM_EN").gameObject;
		SteamTWObj = base.transform.Find("BACK/STEAM_TW").gameObject;
		string language = GameDataManager.Instance().configdata.language;
		if (!(language == "ChineseSimplified"))
		{
			if (language == "ChineseTraditional")
			{
				SteamObj.SetActive(value: false);
				SteamENObj.SetActive(value: false);
				SteamTWObj.SetActive(value: true);
			}
			else
			{
				SteamObj.SetActive(value: false);
				SteamENObj.SetActive(value: true);
				SteamTWObj.SetActive(value: false);
			}
		}
		else
		{
			SteamObj.SetActive(value: true);
			SteamENObj.SetActive(value: false);
			SteamTWObj.SetActive(value: false);
		}
	}

	public void OnButtonEnter(GameObject go)
	{
		if (go.Equals(FakeExitObj))
		{
			FakeExitObj.SetActive(value: false);
			TrueExitObj.SetActive(value: true);
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			if (go.Equals(TrueExitObj))
			{
				OnTrueExit();
			}
			else if (go.Equals(SteamObj))
			{
				OnBrowseURL();
			}
			else if (go.Equals(SteamENObj))
			{
				OnBrowseURL();
			}
			else if (go.Equals(SteamTWObj))
			{
				OnBrowseURL();
			}
		}
	}

	public void OnTrueExit()
	{
		FakeExitObj.SetActive(value: true);
		TrueExitObj.SetActive(value: false);
		mapcontroller.EventComplete(mapcontroller.m_Canvas_Event);
		mapcontroller.m_LastClick = true;
	}

	public void OnBrowseURL()
	{
		Application.OpenURL("https://store.steampowered.com/app/1407450");
		OnTrueExit();
	}
}
