using UnityEngine;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
	public AudioMixer audioMixer;

	private void Start()
	{
		audioMixer.SetFloat("MasterVolume", (!GameDataManager.Instance().configdata.isMasterMute) ? GameDataManager.Instance().configdata.masterVolume : (Mathf.Log10(0.001f) * 20f));
		audioMixer.SetFloat("MusicVolume", (!GameDataManager.Instance().configdata.isMusicMute) ? GameDataManager.Instance().configdata.musicVolume : (Mathf.Log10(0.001f) * 20f));
		audioMixer.SetFloat("SoundEffectVolume", (!GameDataManager.Instance().configdata.isSEMute) ? GameDataManager.Instance().configdata.seVolume : (Mathf.Log10(0.001f) * 20f));
	}
}
