using UnityEngine;
using UnityEngine.UI;

public class AddButtonSoundEffects : MonoBehaviour
{
	public AudioSource audioSource;

	private AudioClip clickSound;

	private AudioClip hoverSound;

	public static AddButtonSoundEffects instance;

	private void Awake()
	{
		if (instance == null)
		{
			instance = this;
		}
	}

	private void Start()
	{
		clickSound = Resources.Load("Music/SE/Click", typeof(AudioClip)) as AudioClip;
		hoverSound = Resources.Load("Music/SE/01-wuxue-message", typeof(AudioClip)) as AudioClip;
	}

	public void PlayClickSound(Button button)
	{
		if (button != null && button.interactable)
		{
			audioSource.clip = clickSound;
			audioSource.Play();
		}
		else if (button == null)
		{
			audioSource.clip = clickSound;
			audioSource.Play();
		}
	}

	public void PlayHoverSound(Button button)
	{
	}
}
