using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ResidualShadow2 : MonoBehaviour
{
	private List<DrawMesh> list = new List<DrawMesh>();

	public int frameRate = 30;

	private int frameRatetimer;

	public float fadeSpeed = 1f;

	public Color color = Color.grey;

	private List<MeshFilter> meshFilters;

	private List<MeshRenderer> meshRenderers;

	private Vector3 _pos;

	private bool isEnable;

	private void Start()
	{
		meshFilters = GetComponentsInChildren<MeshFilter>(includeInactive: true).ToList();
		meshRenderers = GetComponentsInChildren<MeshRenderer>(includeInactive: true).ToList();
		for (int i = 0; i < meshFilters.Count; i++)
		{
			if (!meshFilters[i].gameObject.name.StartsWith("body_"))
			{
				meshFilters.RemoveAt(i);
				meshRenderers.RemoveAt(i);
				i--;
			}
		}
		foreach (MeshRenderer meshRenderer in meshRenderers)
		{
			meshRenderer.materials[0].renderQueue = 4000;
		}
		_pos = base.transform.position;
	}

	private void Update()
	{
		if (!isEnable || !(_pos != base.transform.position))
		{
			return;
		}
		_pos = base.transform.position;
		if (frameRatetimer++ <= frameRate)
		{
			return;
		}
		frameRatetimer = 0;
		for (int i = 0; i < meshFilters.Count; i++)
		{
			if (meshFilters[i].gameObject.activeInHierarchy)
			{
				list.Add(new DrawMesh(meshFilters[i].mesh, meshFilters[i].transform.localToWorldMatrix, meshRenderers[i].material, color));
			}
		}
	}

	private void LateUpdate()
	{
		if (!isEnable)
		{
			return;
		}
		for (int i = 0; i < list.Count; i++)
		{
			list[i].material.SetFloat("_Alpha", list[i].material.GetFloat("_Alpha") - Time.deltaTime * fadeSpeed);
			if (list[i].material.GetFloat("_Alpha") <= 0.05f)
			{
				Object.Destroy(list[i].material);
				Object.Destroy(list[i].mesh);
				list.RemoveAt(i);
			}
		}
		for (int j = 0; j < list.Count; j++)
		{
			Graphics.DrawMesh(list[j].mesh, list[j].matrix, list[j].material, base.gameObject.layer);
		}
	}

	public void EnableResidualShadow()
	{
		isEnable = true;
	}

	public void DisableResidualShadow()
	{
		isEnable = false;
		for (int i = 0; i < list.Count; i++)
		{
			Object.Destroy(list[i].material);
			Object.Destroy(list[i].mesh);
			list.RemoveAt(i);
		}
	}
}
