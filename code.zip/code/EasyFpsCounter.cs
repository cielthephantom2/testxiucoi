using UnityEngine;

public static class EasyFpsCounter
{
	public static Object cusPref;

	public static EasyFps EasyFps;
}
