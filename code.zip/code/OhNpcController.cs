using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Spine.Unity;
using SuperTiled2Unity;
using UnityEngine;
using UnityEngine.Tilemaps;

public class OhNpcController : MonoBehaviour
{
	public State m_State;

	public Direction m_Direction;

	public string m_AiType = "Wander";

	public List<MapController.Portal> m_PortalList = new List<MapController.Portal>();

	public SuperObject superObject;

	public string followTarget = "";

	public int followAction;

	public GameObject m_SplashPrefab;

	public float MovingSpeedRate = 1f;

	private const float MovementBlockSize = 50f;

	public float MinMoveGap = 0.3f;

	public float MaxMoveGap = 2f;

	private Vector2 m_Facing = Vector2.down;

	private Vector2 m_MovingFrom;

	private Vector2 m_MovingTo;

	private Vector2 m_SpawnPoint;

	private Camera m_camera;

	public int movement = 2;

	private MapController mapcontroller;

	private Vector3Int startPos;

	private Vector3Int endPos;

	private Vector3Int oldTargetPos;

	private int portalIndex = -1;

	private Dictionary<Vector3Int, int> search = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, int> cost = new Dictionary<Vector3Int, int>();

	private Dictionary<Vector3Int, Vector3Int> pathSave = new Dictionary<Vector3Int, Vector3Int>();

	private List<Vector3Int> hadSearch = new List<Vector3Int>();

	private GameObject PathPrefab;

	private GameObject Path;

	private List<GameObject> pathObject = new List<GameObject>();

	private int m_SortingOrder;

	private int m_MoveProcess;

	private SkeletonAnimation[] m_Animations;

	private Transform target;

	private bool moveInterupt;

	private string aniname_stand = "A01-stand";

	private string aniname_walk = "A02-walk";

	public float unitRange = 32f;

	public float moveSpeed = 7.5f;

	private float finalSpeed;

	public Transform movePoint;

	private void Awake()
	{
		int sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "DynamicLayer").sortingOrder;
		m_Animations = base.gameObject.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		SkeletonAnimation[] animations = m_Animations;
		for (int i = 0; i < animations.Length; i++)
		{
			animations[i].gameObject.GetComponent<MeshRenderer>().sortingOrder = sortingOrder;
		}
		m_SortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "underfoot").sortingOrder;
		PathPrefab = CommonResourcesData.PathPrefab;
		m_camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
	}

	private void Start()
	{
		SuperObject superObject = this.superObject;
		if (superObject != null)
		{
			m_SpawnPoint = superObject.transform.position;
		}
		m_SpawnPoint.x = RoundToGrid(m_SpawnPoint.x);
		m_SpawnPoint.y = RoundToGrid(m_SpawnPoint.y);
		base.gameObject.transform.localPosition = m_SpawnPoint;
		finalSpeed = moveSpeed * unitRange;
		movePoint = base.transform.Find("movepoint");
		movePoint.parent = null;
		m_State = State.MoveInit;
		mapcontroller = GameObject.Find("Camera").GetComponent<MapController>();
		mapcontroller.ReportPosition(base.gameObject.name, GetGridPosition());
	}

	public void Hide()
	{
		m_Animations[0].gameObject.SetActive(value: false);
		m_Animations[1].gameObject.SetActive(value: false);
		m_Animations[2].gameObject.SetActive(value: false);
	}

	public void Face(Direction direction, bool isInit = false)
	{
		if (isInit || direction != m_Direction)
		{
			m_Direction = direction;
			switch (direction)
			{
			case Direction.Left:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = 1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			case Direction.Up:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: true);
				break;
			case Direction.Right:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = -1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			default:
				m_Animations[0].gameObject.SetActive(value: true);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			}
		}
	}

	private void PlayAnimation(string animation, bool loop = true, bool compensate = true)
	{
		if (m_Animations[0].AnimationName != animation)
		{
			if (!compensate)
			{
				m_Animations[0].skeleton.SetToSetupPose();
				m_Animations[0].AnimationState.ClearTracks();
			}
			m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[1].AnimationName != animation)
		{
			if (!compensate)
			{
				m_Animations[1].skeleton.SetToSetupPose();
				m_Animations[1].AnimationState.ClearTracks();
			}
			m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[2].AnimationName != animation)
		{
			if (!compensate)
			{
				m_Animations[2].skeleton.SetToSetupPose();
				m_Animations[2].AnimationState.ClearTracks();
			}
			m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}

	private void ShowOrHideWeapon(string animation)
	{
		if (animation.Contains("sword"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("knife"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("stick"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
		}
		else if (animation.Contains("hand"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("finger"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
		else if (animation.Contains("heart"))
		{
			m_Animations[0].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[0].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[1].Skeleton.FindSlot("weapon-stick").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-knife").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-sword").Attachment = null;
			m_Animations[2].Skeleton.FindSlot("weapon-stick").Attachment = null;
		}
	}

	private void Tick()
	{
		if (m_State == State.MoveInit)
		{
			m_State = State.WaitingForInput;
		}
		else if (m_State == State.WaitingForInput)
		{
			if (m_AiType == "Wander")
			{
				m_State = State.AStarInit;
				StartCoroutine(AIWander());
			}
			else if (m_AiType == "Portal")
			{
				m_State = State.AStarInit;
				portalIndex++;
				if (portalIndex >= m_PortalList.Count)
				{
					portalIndex = 0;
				}
				StartCoroutine(AIPortal());
			}
			else if (m_AiType == "Follow")
			{
				if (target == null)
				{
					target = GameObject.Find(followTarget).transform;
				}
				m_State = State.AStarInit;
				AIFollow();
			}
		}
		else
		{
			if (m_State != State.AStarWaiting)
			{
				return;
			}
			if (m_AiType == "Follow" && moveInterupt)
			{
				moveInterupt = false;
				foreach (GameObject item in pathObject)
				{
					Object.Destroy(item);
				}
				pathObject.Clear();
				search.Clear();
				cost.Clear();
				pathSave.Clear();
				hadSearch.Clear();
				if (target == null)
				{
					target = GameObject.Find(followTarget).transform;
				}
				m_State = State.AStarInit;
				AIFollow();
			}
			else
			{
				AStarStepUpdate();
			}
		}
	}

	private void AIFollow()
	{
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		vector3Int = mapcontroller.tilemap.WorldToCell(target.localPosition);
		endPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if ((endPos - startPos).magnitude > 1.414f)
		{
			OhPlayerController component = target.GetComponent<OhPlayerController>();
			if (component == null)
			{
				int num = Random.Range(0, 2);
				int num2 = 1 - num;
				int num3 = ((!(Random.value < 0.5f)) ? 1 : (-1));
				int num4 = ((!(Random.value < 0.5f)) ? 1 : (-1));
				endPos = new Vector3Int(vector3Int.x + num3 * num, -vector3Int.y + num4 * num2, 0);
			}
			else
			{
				int num5 = 0;
				int num6 = 0;
				int num7 = ((followAction == 0) ? 1 : (-1));
				switch (component.m_Direction)
				{
				case Direction.Up:
					num5 = 0;
					num6 = num7;
					break;
				case Direction.Down:
					num5 = 0;
					num6 = -1 * num7;
					break;
				case Direction.Left:
					num5 = -1 * num7;
					num6 = 0;
					break;
				case Direction.Right:
					num5 = num7;
					num6 = 0;
					break;
				}
				endPos = new Vector3Int(vector3Int.x + num5, -vector3Int.y + num6, 0);
			}
			if (!startPos.Equals(endPos))
			{
				oldTargetPos = vector3Int;
				AStarSearchPath();
			}
			else
			{
				m_State = State.MoveInit;
			}
		}
		else if (startPos.Equals(endPos))
		{
			int num8 = Random.Range(0, 2);
			int num9 = 1 - num8;
			int num10 = ((!(Random.value < 0.5f)) ? 1 : (-1));
			int num11 = ((!(Random.value < 0.5f)) ? 1 : (-1));
			endPos = new Vector3Int(vector3Int.x + num10 * num8, -vector3Int.y + num11 * num9, 0);
			AStarSearchPath();
		}
		else
		{
			m_State = State.MoveInit;
		}
	}

	private IEnumerator AIPortal()
	{
		float maxInclusive = 1f;
		float seconds = Random.Range(0.3f, maxInclusive);
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		endPos = new Vector3Int(m_PortalList[portalIndex].position.x, -m_PortalList[portalIndex].position.y, 0);
		if (startPos.Equals(endPos))
		{
			m_State = State.MoveInit;
			yield break;
		}
		yield return new WaitForSeconds(seconds);
		AStarSearchPath();
	}

	private IEnumerator AIWander()
	{
		float seconds = Random.Range(MinMoveGap, MaxMoveGap);
		int num = Random.Range(0, movement + 1);
		int num2 = movement - num;
		int num3 = ((!(Random.value < 0.5f)) ? 1 : (-1));
		int num4 = ((!(Random.value < 0.5f)) ? 1 : (-1));
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(movePoint.position);
		startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		vector3Int = mapcontroller.tilemap.WorldToCell(m_SpawnPoint);
		endPos = new Vector3Int(vector3Int.x + num3 * num, -vector3Int.y + num4 * num2, 0);
		if (startPos.Equals(endPos))
		{
			yield return new WaitForSeconds(seconds);
			m_State = State.MoveInit;
		}
		else
		{
			yield return new WaitForSeconds(seconds);
			AStarSearchPath();
		}
	}

	private void Update()
	{
		if (SharedData.Instance().m_MapController == null || SharedData.Instance().m_MapController.isEnterBattleAnimPlaying)
		{
			return;
		}
		Tick();
		if (m_State != State.AStarMoving)
		{
			return;
		}
		if (m_AiType == "Follow")
		{
			if ((mapcontroller.tilemap.WorldToCell(target.localPosition) - oldTargetPos).magnitude > 1f)
			{
				moveInterupt = true;
				m_State = State.AStarWaiting;
				mapcontroller.ReportPosition(base.gameObject.name, GetGridPosition());
			}
			else
			{
				AStarMove();
			}
		}
		else
		{
			AStarMove();
		}
	}

	public void AStarSeek(Vector2 target)
	{
		m_MovingFrom = movePoint.position;
		Vector3Int vector3Int = mapcontroller.tilemap.WorldToCell(target);
		new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		m_State = State.AStarMoving;
		m_MovingTo = target;
		movePoint.position = m_MovingTo;
		PlayAnimation(aniname_walk);
	}

	public void AStarMove()
	{
		base.transform.position = Vector3.MoveTowards(base.transform.position, movePoint.position, MovingSpeedRate * finalSpeed * Time.deltaTime);
		if (Vector3.Distance(base.transform.position, movePoint.position) <= 1f)
		{
			mapcontroller.ReportPosition(base.gameObject.name, GetGridPositionMP());
			AStarStepUpdate();
		}
	}

	private void AStarClean()
	{
		foreach (GameObject item in pathObject)
		{
			Object.Destroy(item);
		}
		pathObject.Clear();
		search.Clear();
		cost.Clear();
		pathSave.Clear();
		hadSearch.Clear();
	}

	private void AStarStepUpdate()
	{
		if (m_MoveProcess < 0)
		{
			AStarClean();
			m_State = State.MoveInit;
			PlayAnimation(aniname_stand);
			return;
		}
		if (m_MoveProcess < pathObject.Count - 1)
		{
			Object.Destroy(pathObject[m_MoveProcess + 1]);
		}
		Vector2 vector = pathObject[m_MoveProcess].transform.localPosition;
		float num = vector.x - base.transform.localPosition.x;
		float num2 = vector.y - base.transform.localPosition.y;
		if (Mathf.Abs(num) > Mathf.Abs(num2))
		{
			if (num > 0f)
			{
				Face(Direction.Left);
			}
			else
			{
				Face(Direction.Right);
			}
		}
		else if (num2 > 0f)
		{
			Face(Direction.Up);
		}
		else
		{
			Face(Direction.Down);
		}
		PlayAnimation(aniname_walk);
		AStarSeek(new Vector2(pathObject[m_MoveProcess].transform.localPosition.x, pathObject[m_MoveProcess].transform.localPosition.y));
		m_MoveProcess--;
	}

	public Vector3Int GetGridPositionMP()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(movePoint.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(movePoint.position.y) / 50f);
		return zero;
	}

	public Vector3Int GetGridPosition()
	{
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(base.transform.position.x / 50f);
		zero.y = Mathf.FloorToInt(Mathf.Abs(base.transform.position.y) / 50f);
		return zero;
	}

	private int RoundToGrid(float value)
	{
		if (value < 0f)
		{
			return Mathf.CeilToInt(value / 50f) * 50 - 25;
		}
		return Mathf.FloorToInt(value / 50f) * 50 + 25;
	}

	public void AStarSearchPath()
	{
		search.Add(startPos, GetHeuristic(startPos, endPos));
		cost.Add(startPos, 0);
		hadSearch.Add(startPos);
		pathSave.Add(startPos, startPos);
		Vector3Int vector3Int = startPos;
		int num = int.MaxValue;
		while (search.Count > 0)
		{
			Vector3Int shortestPos = GetShortestPos();
			if (shortestPos.Equals(endPos))
			{
				break;
			}
			foreach (Vector3Int neighbor in GetNeighbors(shortestPos))
			{
				if (!hadSearch.Contains(neighbor))
				{
					cost.Add(neighbor, cost[shortestPos] + 1);
					int heuristic = GetHeuristic(neighbor, endPos);
					search.Add(neighbor, cost[neighbor] + heuristic);
					pathSave.Add(neighbor, shortestPos);
					if (heuristic < num)
					{
						num = heuristic;
						vector3Int = neighbor;
					}
					hadSearch.Add(neighbor);
				}
			}
		}
		if (pathSave.ContainsKey(endPos))
		{
			ShowPath();
			return;
		}
		endPos = vector3Int;
		ShowPath();
	}

	private List<Vector3Int> GetNeighbors(Vector3Int target)
	{
		List<Vector3Int> list = new List<Vector3Int>();
		Vector3Int vector3Int = target + Vector3Int.up;
		Vector3Int vector3Int2 = target + Vector3Int.right;
		Vector3Int vector3Int3 = target - Vector3Int.right;
		Vector3Int vector3Int4 = target - Vector3Int.up;
		if (mapcontroller.CanWalk(vector3Int))
		{
			list.Add(vector3Int);
		}
		if (mapcontroller.CanWalk(vector3Int2))
		{
			list.Add(vector3Int2);
		}
		if (mapcontroller.CanWalk(vector3Int3))
		{
			list.Add(vector3Int3);
		}
		if (mapcontroller.CanWalk(vector3Int4))
		{
			list.Add(vector3Int4);
		}
		return list;
	}

	private int GetHeuristic(Vector3Int posA, Vector3Int posB)
	{
		return Mathf.Abs(posA.x - posB.x) + Mathf.Abs(posA.y - posB.y);
	}

	private Vector3Int GetShortestPos()
	{
		KeyValuePair<Vector3Int, int> keyValuePair = new KeyValuePair<Vector3Int, int>(Vector3Int.zero, int.MaxValue);
		foreach (KeyValuePair<Vector3Int, int> item in search)
		{
			if (item.Value < keyValuePair.Value)
			{
				keyValuePair = item;
			}
		}
		search.Remove(keyValuePair.Key);
		return keyValuePair.Key;
	}

	private void ShowPath()
	{
		Vector3Int key = endPos;
		while (!key.Equals(startPos))
		{
			Vector3Int vector3Int = pathSave[key];
			Path = Object.Instantiate(PathPrefab, mapcontroller.map.transform);
			Path.transform.localPosition = new Vector3(25 + key.x * 50, -25 - key.y * 50);
			pathObject.Add(Path);
			Path.GetComponentInChildren<SpriteRenderer>().sortingOrder = ((m_SortingOrder > 0) ? m_SortingOrder : 0);
			key = vector3Int;
		}
		m_MoveProcess = pathObject.Count - 1;
		m_State = State.AStarWaiting;
	}
}
