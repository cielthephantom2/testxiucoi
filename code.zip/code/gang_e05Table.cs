using System.Collections.Generic;
using UnityEngine;

public class gang_e05Table
{
	public class Row
	{
		public string id;

		public string type;

		public string content;

		public string content_EN;

		public string Level;

		public string TopRumourID;

		public string SubRumourID;

		public string FinishFlag;

		public string content_Trans => CommonFunc.ShortLangSel(content, content_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				id = list[i][num++],
				type = list[i][num++],
				content = list[i][num++],
				content_EN = list[i][num++],
				Level = list[i][num++],
				TopRumourID = list[i][num++],
				SubRumourID = list[i][num++],
				FinishFlag = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		return rowList.Find((Row x) => x.id == find);
	}

	public List<Row> FindAll_id(string find)
	{
		return rowList.FindAll((Row x) => x.id == find);
	}

	public Row Find_type(string find)
	{
		return rowList.Find((Row x) => x.type == find);
	}

	public List<Row> FindAll_type(string find)
	{
		return rowList.FindAll((Row x) => x.type == find);
	}

	public Row Find_content(string find)
	{
		return rowList.Find((Row x) => x.content == find);
	}

	public List<Row> FindAll_content(string find)
	{
		return rowList.FindAll((Row x) => x.content == find);
	}

	public Row Find_content_EN(string find)
	{
		return rowList.Find((Row x) => x.content_EN == find);
	}

	public List<Row> FindAll_content_EN(string find)
	{
		return rowList.FindAll((Row x) => x.content_EN == find);
	}
}
