using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LogViewController : MonoBehaviour
{
	private float ScrollSpeed = 5f;

	private RectTransform _content;

	private RectTransform _scrollRect;

	public Text LogText;

	private bool exiting;

	private void Start()
	{
		LogText.text = "";
		List<string> list = new List<string>();
		list.AddRange(SharedData.Instance().m_ChatLog);
		list.Reverse();
		foreach (string item in list)
		{
			if (LogText.text.Length + item.Length > 16000)
			{
				Debug.LogWarning("LogText.text.Length will > 16000, break.");
				break;
			}
			LogText.text = item + "\n" + LogText.text;
		}
		if (LogText.text.Length <= 0)
		{
			LogText.text = CommonFunc.I18nGetLocalizedValue("I18N_NoNewStory") + "\n";
		}
		LogText.rectTransform.sizeDelta = new Vector2(LogText.rectTransform.sizeDelta.x, Mathf.CeilToInt(LogText.preferredHeight));
		LogText.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(LogText.transform.parent.GetComponent<RectTransform>().sizeDelta.x, (float)Mathf.CeilToInt(LogText.preferredHeight) + 20f);
		_content = base.transform.Find("Panel/ScrollView/Viewport/Content").GetComponent<RectTransform>();
		_scrollRect = base.transform.Find("Panel/ScrollView").GetComponent<RectTransform>();
	}

	private void Update()
	{
		if (exiting)
		{
			return;
		}
		if (InputDeviceDetector.isMouse1Up || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputSystemCustom.Instance().UI.OpenLogView.WasReleasedThisFrame())
		{
			ExitScene();
		}
		else
		{
			if (InputSystemCustom.Instance().UI.ScrollRectRoll.ReadValue<float>() == 0f)
			{
				return;
			}
			if (InputSystemCustom.Instance().UI.ScrollRectRoll.ReadValue<float>() < 0f)
			{
				if (_content.anchoredPosition.y - ScrollSpeed > 0f)
				{
					_content.anchoredPosition = new Vector2(_content.anchoredPosition.x, _content.anchoredPosition.y - ScrollSpeed);
				}
			}
			else if (InputSystemCustom.Instance().UI.ScrollRectRoll.ReadValue<float>() > 0f && _content.anchoredPosition.y - ScrollSpeed < _content.rect.height)
			{
				_content.anchoredPosition = new Vector2(_content.anchoredPosition.x, _content.anchoredPosition.y + ScrollSpeed);
			}
		}
	}

	public void ExitScene()
	{
		if (!exiting)
		{
			exiting = true;
			SharedData.Instance().IsViewOpen = false;
			SceneManager.UnloadSceneAsync("LogView");
		}
	}
}
