using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class StatsAndAchievementsData
{
	[Key(0)]
	public string ID;

	[Key(1)]
	public string Achieved;

	[Key(2)]
	public string Hidden;

	[Key(3)]
	public string GetWay;

	[Key(4)]
	public string UnAchievedIcon;

	[Key(5)]
	public string AchievedIcon;

	[Key(6)]
	public string Type;

	[Key(7)]
	public string TotalValue;

	[Key(8)]
	public string CurValue;

	[Key(9)]
	public string Name;

	[Key(10)]
	public string Name_EN;

	[Key(11)]
	public string Describe;

	[Key(12)]
	public string Describe_EN;
}
