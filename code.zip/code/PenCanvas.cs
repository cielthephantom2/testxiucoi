using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class PenCanvas : MonoBehaviour, IPointerClickHandler, IEventSystemHandler
{
	public Action OnPenCanvasLeftClickEvent;

	public Action OnPenCanvasRightClickEvent;

	public void OnPointerClick(PointerEventData eventData)
	{
		if (eventData.button == PointerEventData.InputButton.Left)
		{
			OnPenCanvasLeftClickEvent?.Invoke();
		}
		else if (eventData.button == PointerEventData.InputButton.Right)
		{
			OnPenCanvasRightClickEvent?.Invoke();
		}
	}
}
