using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SectCanvasController : MonoBehaviour
{
	public GameObject KungfuTitlePrefab;

	public GameObject KungfuItemPreafab;

	public GameObject TraitItemPrefab;

	private Sprite _normalSprite1;

	private Sprite _normalSprite2;

	private Sprite _normalSprite3;

	private Sprite _normalSprite4;

	private string haveColor = "<color=#E6DDBC>{0}</color>";

	private void Start()
	{
		_normalSprite1 = Resources.Load("images/01-border/boder-20240904-button-menpai-01", typeof(Sprite)) as Sprite;
		_normalSprite2 = Resources.Load("images/01-border/boder-20240904-button-menpai-02", typeof(Sprite)) as Sprite;
		_normalSprite3 = Resources.Load("images/01-border/boder-20240904-button-menpai-03", typeof(Sprite)) as Sprite;
		_normalSprite4 = Resources.Load("images/01-border/boder-20240904-button-menpai-04", typeof(Sprite)) as Sprite;
		InitSectCanvas(SharedData.Instance().sectPanelID);
		SharedData.Instance().LoadSceneStackAdd("SectCanvas");
	}

	private void OnDisable()
	{
		SharedData.Instance().LoadSceneStackRemove("SectCanvas");
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			PointerEventData eventData = new PointerEventData(EventSystem.current);
			ExecuteEvents.Execute(base.transform.Find("Panel/TopBanner/Return").gameObject, eventData, ExecuteEvents.pointerClickHandler);
		}
	}

	public void InitSectCanvas(string _sectId = "")
	{
		bool flag = false;
		gang_b16Table.Row row = CommonResourcesData.b16.Find_ID(_sectId);
		if (row == null)
		{
			Debug.LogWarning("InitSectCanvas get b16Row failed, _sectId  = " + _sectId);
			Exit();
		}
		Button[] componentsInChildren = GetComponentsInChildren<Button>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		base.transform.Find("Panel/TopBanner/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Sect_" + row.ID);
		base.transform.Find("Panel/Character").GetComponent<Image>().sprite = CommonResourcesData.GetTachieFull(row.BattleIcon);
		List<string> list = row.Kungfus.Split('|').ToList();
		List<string> list2 = new List<string>
		{
			"101", "201", "301", "401", "501", "601", "701", "801", "901", "1001",
			"9101", "9301", "9401", "9501", "9601"
		};
		Dictionary<string, List<gang_b03Table.Row>> dictionary = new Dictionary<string, List<gang_b03Table.Row>>();
		foreach (string item in list2)
		{
			dictionary.Add(item, new List<gang_b03Table.Row>());
		}
		foreach (string item2 in list)
		{
			if (!item2.Equals("") && !item2.Equals("0"))
			{
				gang_b07Table.Row row2 = CommonResourcesData.b07.Find_Relate_Wugong_id(item2);
				gang_b03Table.Row row3 = CommonResourcesData.b03.Find_ID(item2);
				if (row2 == null || row3 == null)
				{
					Debug.LogWarning("InitSectCanvas : Can not find wugong id = " + item2);
				}
				else
				{
					dictionary[row3.Style].Add(row3);
				}
			}
		}
		foreach (string item3 in list2)
		{
			if (dictionary[item3].Count <= 0)
			{
				continue;
			}
			GameObject gameObject = Object.Instantiate(KungfuTitlePrefab, base.transform.Find("Panel/KungFusArea/Viewport/Content"));
			switch (item3)
			{
			case "101":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-sword", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("剑法");
				break;
			case "201":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-knife", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("刀法");
				break;
			case "301":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-stick", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("棍法");
				break;
			case "401":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-hand", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("拳掌");
				break;
			case "501":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-finger", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("指法");
				break;
			case "601":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-darts", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("暗器");
				break;
			case "701":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-melody", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("音律");
				break;
			case "801":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-winart", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("酒艺");
				break;
			case "901":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-heart", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("内功");
				break;
			case "1001":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-special", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("特殊");
				break;
			case "9101":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-special", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("阵法");
				break;
			case "9301":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-special", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("辅助");
				break;
			case "9401":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-special", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("药经食谱");
				break;
			case "9501":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-special", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("轻功");
				break;
			case "9601":
				gameObject.transform.Find("KungFuTitle/Type/Image").GetComponent<Image>().sprite = Resources.Load("images/07-01-icon-UI/0508-icon-kongfu-special", typeof(Sprite)) as Sprite;
				gameObject.transform.Find("KungFuTitle/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("绝学");
				break;
			}
			foreach (gang_b03Table.Row item4 in dictionary[item3])
			{
				gang_b07Table.Row row4 = CommonResourcesData.b07.Find_Relate_Wugong_id(item4.ID);
				GameObject gameObject2 = Object.Instantiate(KungfuItemPreafab, base.transform.Find("Panel/KungFusArea/Viewport/Content"));
				if (!flag)
				{
					EventSystem.current.SetSelectedGameObject(gameObject2);
					flag = true;
				}
				gameObject2.transform.Find("Stars/Text").GetComponent<Text>().text = item4.Star;
				switch (item4.Origin)
				{
				case "0":
					gameObject2.transform.Find("Type/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_CreatWugong");
					break;
				case "1":
					gameObject2.transform.Find("Type/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_BuddhismWugong");
					break;
				case "2":
					gameObject2.transform.Find("Type/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_TaoistWugong");
					break;
				case "3":
					gameObject2.transform.Find("Type/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_ConfucianistWugong");
					break;
				case "4":
					gameObject2.transform.Find("Type/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_HeresyWugong");
					break;
				case "5":
					gameObject2.transform.Find("Type/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_JiangHuWugong");
					break;
				}
				gameObject2.name = "WuGong|" + row4.ID;
				EventTriggerListener.Get(gameObject2.gameObject).onClick = OnButtonClick;
				if (HaveItem(row4.ID))
				{
					gameObject2.transform.Find("Name").GetComponent<Text>().text = string.Format(haveColor, item4.Name_Trans);
					gameObject2.GetComponent<Image>().sprite = _normalSprite4;
					gameObject2.transform.Find("Stars").GetComponent<Image>().sprite = _normalSprite3;
					gameObject2.transform.Find("Type").GetComponent<Image>().sprite = _normalSprite3;
				}
				else
				{
					gameObject2.transform.Find("Name").GetComponent<Text>().text = item4.Name_Trans;
				}
			}
		}
		foreach (string item5 in row.Traits.Split('|').ToList())
		{
			if (item5.Equals("") || item5.Equals("0"))
			{
				continue;
			}
			gang_b06Table.Row row5 = CommonResourcesData.b06.Find_id(item5);
			if (row5 == null)
			{
				Debug.LogWarning("InitSectCanvas : Can not find trait id = " + item5);
				continue;
			}
			GameObject gameObject3 = Object.Instantiate(TraitItemPrefab, base.transform.Find("Panel/TraitsAndItems/TraitList"));
			gameObject3.transform.Find("TraitIcon/Text").GetComponent<Text>().text = CommonFunc.ConvertToChineseNumber(int.Parse(row5.traitEquipIndex.Split("&")[0]));
			if (row5.isLockTrait.Equals("1"))
			{
				gameObject3.transform.Find("TraitIcon/BGLock").gameObject.SetActive(value: true);
				gameObject3.transform.Find("TraitIcon/Lock").gameObject.SetActive(value: true);
			}
			if (Havetrait(row5.id))
			{
				gameObject3.transform.Find("Text").GetComponent<Text>().text = string.Format(haveColor, row5.name_Trans);
				gameObject3.GetComponent<Image>().sprite = _normalSprite4;
			}
			else
			{
				gameObject3.transform.Find("Text").GetComponent<Text>().text = row5.name_Trans;
			}
		}
		List<string> list3 = row.Items.Split('|').ToList();
		int num = 0;
		foreach (string item6 in list3)
		{
			if (item6.Equals("") || item6.Equals("0"))
			{
				continue;
			}
			gang_b07Table.Row row6 = CommonResourcesData.b07.Find_Relate_Equip_id(item6);
			gang_b02Table.Row row7 = CommonResourcesData.b02.Find_ID(item6);
			if (row6 == null || row7 == null)
			{
				Debug.LogWarning("InitSectCanvas : Can not find item id = " + item6);
				continue;
			}
			PackageIconController component = base.transform.Find("Panel/TraitsAndItems/ItemList/Content").GetChild(num++).GetComponent<PackageIconController>();
			component.InitPackageIcon(row6, 0, null, 0);
			component.gameObject.name = "Item|" + row6.ID;
			EventTriggerListener.Get(component.gameObject).onClick = OnButtonClick;
			if (HaveItem(row6.ID))
			{
				component.gameObject.GetComponent<Image>().sprite = _normalSprite4;
				component.transform.Find("FullInfo/Icon").GetComponent<Image>().color = Color.white;
				component.transform.Find("FullName/Icon").GetComponent<Image>().color = Color.white;
			}
			else
			{
				component.transform.Find("FullInfo/Icon").GetComponent<Image>().color = Color.gray;
				component.transform.Find("FullName/Icon").GetComponent<Image>().color = Color.gray;
			}
		}
	}

	private bool HaveItem(string _id)
	{
		float num = 0f;
		string value = "_" + _id + "_";
		foreach (KeyValuePair<string, int> item in SharedData.Instance().PlayerPackage)
		{
			if (item.Key.Contains(value) || item.Key.Equals(_id))
			{
				num += (float)item.Value;
			}
		}
		List<string> list = new List<string>();
		list.Add(SharedData.Instance().playerid);
		list.AddRange(SharedData.Instance().FullTeam);
		foreach (string item2 in list)
		{
			CharaData charaData = SharedData.Instance().GetCharaData(item2);
			if (charaData.m_Training_Id != "0")
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_Relateid(charaData.m_Training_Id);
				if (!row.Value.Equals("0") && (row.ID.Contains(value) || row.ID.Equals(_id)))
				{
					num += 1f;
				}
			}
			foreach (string item3 in charaData.m_EquipSlot)
			{
				if (item3 != "0")
				{
					gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(item3);
					if (row2.ID.Contains(value) || row2.ID.Equals(_id))
					{
						num += 1f;
					}
				}
			}
		}
		if (SharedData.Instance().PlayerPackage.ContainsKey(_id))
		{
			num = SharedData.Instance().PlayerPackage[_id];
		}
		return num > 0f;
	}

	private bool Havetrait(string _id)
	{
		List<string> list = new List<string>();
		list.Add(SharedData.Instance().playerid);
		list.AddRange(SharedData.Instance().FullTeam);
		foreach (string item in list)
		{
			if (SharedData.Instance().GetCharaData(item).m_TraitList.Contains(_id))
			{
				return true;
			}
		}
		return false;
	}

	public void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			string[] array = go.name.Split('|');
			if (array[0].Equals("Return"))
			{
				Exit();
			}
			else if (array[0].Equals("WuGong") || array[0].Equals("Item"))
			{
				StartCoroutine(CommonFunc.DelayedOpenHoverOperation(go, showEquip: false, useCharaData: false));
			}
		}
	}

	private void Exit()
	{
		Object.DestroyImmediate(base.gameObject);
	}
}
