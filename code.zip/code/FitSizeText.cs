using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FitSizeText : Text
{
	private readonly UIVertex[] _tmpVerts = new UIVertex[4];

	public int VisibleLines { get; private set; }

	private void _UseFitSettings()
	{
		TextGenerationSettings generationSettings = GetGenerationSettings(base.rectTransform.rect.size);
		generationSettings.resizeTextForBestFit = false;
		if (!base.resizeTextForBestFit)
		{
			base.cachedTextGenerator.PopulateWithErrors(text, generationSettings, base.gameObject);
			return;
		}
		int num = base.resizeTextMinSize;
		int length = text.Length;
		int num2 = base.resizeTextMaxSize;
		while (num2 >= num)
		{
			generationSettings.fontSize = num2;
			base.cachedTextGenerator.PopulateWithErrors(text, generationSettings, base.gameObject);
			if (base.cachedTextGenerator.characterCountVisible != length)
			{
				num2--;
				continue;
			}
			break;
		}
	}

	protected override void OnPopulateMesh(VertexHelper toFill)
	{
		if (null == base.font)
		{
			return;
		}
		m_DisableFontTextureRebuiltCallback = true;
		_UseFitSettings();
		IList<UIVertex> verts = base.cachedTextGenerator.verts;
		float num = 1f / base.pixelsPerUnit;
		int count = verts.Count;
		if (count <= 0)
		{
			toFill.Clear();
			return;
		}
		Vector2 vector = new Vector2(verts[0].position.x, verts[0].position.y) * num;
		vector = PixelAdjustPoint(vector) - vector;
		toFill.Clear();
		if (vector != Vector2.zero)
		{
			for (int i = 0; i < count; i++)
			{
				int num2 = i & 3;
				_tmpVerts[num2] = verts[i];
				_tmpVerts[num2].position *= num;
				_tmpVerts[num2].position.x += vector.x;
				_tmpVerts[num2].position.y += vector.y;
				if (num2 == 3)
				{
					toFill.AddUIVertexQuad(_tmpVerts);
				}
			}
		}
		else
		{
			for (int j = 0; j < count; j++)
			{
				int num3 = j & 3;
				_tmpVerts[num3] = verts[j];
				_tmpVerts[num3].position *= num;
				if (num3 == 3)
				{
					toFill.AddUIVertexQuad(_tmpVerts);
				}
			}
		}
		m_DisableFontTextureRebuiltCallback = false;
		VisibleLines = base.cachedTextGenerator.lineCount;
	}
}
