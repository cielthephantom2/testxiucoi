using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using InputIcons;
using Steamworks;
using UnityEngine;

public class GameDataManager : MonoBehaviour
{
	public const int GameDataRecordCount = 24;

	public const int AutoSaveDataRecordCount = 8;

	private int currentId = -1;

	private string dataFileName = "data.dat";

	public XmlSaver xs = new XmlSaver();

	public List<GameData> gameData = new List<GameData>();

	public List<bool> isGameDataEmptyList = new List<bool>();

	private bool hasLoadConfigFromFile;

	private ConfigData _configData = new ConfigData();

	private StatsAchievementAtlas statsAchievementAtlas = new StatsAchievementAtlas();

	public List<StatsAndAchievementsData> statsAndAchievementsDataList = new List<StatsAndAchievementsData>();

	public List<UnlockAtlasItem> UnlockAtlasList = new List<UnlockAtlasItem>();

	private static GameDataManager instance;

	public string DocumentsPath = "";

	public string saveFileName = "";

	public int getFileInfoIndex;

	public Camera saveCamera;

	public bool isSaving;

	public bool isPackData;

	public bool isRestoreData;

	public bool sceneLoadData;

	public string m_SaveDataFolder = "TheWorldOfKongFu_Stable";

	private bool isAsyncLoadOrSaveDate;

	private int screenWidth = 1920;

	private int screenHeight = 1080;

	public ConfigData configdata
	{
		get
		{
			if (!hasLoadConfigFromFile)
			{
				LoadConfig();
			}
			return _configData;
		}
		set
		{
			_configData = value;
		}
	}

	public static GameDataManager Instance()
	{
		return instance;
	}

	private void Awake()
	{
		instance = this;
		Init();
	}

	private void Init()
	{
		Debug.Log("GameDataManager Init");
		bool flag = false;
		Debug.Log("EDITOR Platform");
		DocumentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\" + m_SaveDataFolder;
		if (!flag)
		{
			flag = Directory.Exists(DocumentsPath);
		}
		Debug.Log(">>> DocumentsPath: [" + DocumentsPath + "] " + (flag ? "Exist." : "NOT Exist."));
		if (!flag)
		{
			Directory.CreateDirectory(DocumentsPath);
			Debug.Log(">>> SavePath created: [" + DocumentsPath + "].");
		}
		for (int i = 0; i < 24; i++)
		{
			GameData gameData = new GameData();
			gameData.key = SystemInfo.deviceUniqueIdentifier;
			this.gameData.Add(gameData);
			isGameDataEmptyList.Add(item: false);
		}
		LoadConfig();
		if ("".Equals(configdata.language))
		{
			string text = Application.systemLanguage.ToString();
			if (text == "ChineseSimplified" || text == "ChineseTraditional")
			{
				configdata.language = text;
			}
			else
			{
				configdata.language = "English";
			}
			Debug.LogWarning("Init configdata.language = " + configdata.language);
			Screen.SetResolution(Screen.resolutions[Screen.resolutions.Length - 1].width, Screen.resolutions[Screen.resolutions.Length - 1].height, FullScreenMode.FullScreenWindow);
		}
		else
		{
			Debug.LogWarning("Load configdata.language = " + configdata.language);
		}
		InitStatsAndAchievementsData();
		LoadStatsAndAchievements();
		LoadUnlockAtlasList();
	}

	private void OnDestroy()
	{
	}

	public string SaveScreenshot(Camera targetCamera)
	{
		RenderTexture renderTexture2 = (targetCamera.targetTexture = new RenderTexture(340, 180, 24));
		targetCamera.Render();
		targetCamera.targetTexture = null;
		RenderTexture.active = renderTexture2;
		Texture2D texture2D = new Texture2D(renderTexture2.width, renderTexture2.height, TextureFormat.RGB24, mipChain: false);
		texture2D.ReadPixels(new Rect(0f, 0f, renderTexture2.width, renderTexture2.height), 0, 0);
		texture2D.Apply();
		byte[] inArray = texture2D.EncodeToPNG();
		RenderTexture.active = null;
		return Convert.ToBase64String(inArray);
	}

	private void SaveConfig(int _id)
	{
		if (_id != 24 && _id < 16)
		{
			configdata.lastSaveId = _id;
		}
		float num = 0f;
		if (currentId != -1)
		{
			num = configdata.gameDurationList[currentId];
		}
		TimeSpan timeSpan = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		configdata.gameDurationList[_id - 1] = num + (float)Convert.ToInt64((timeSpan - SharedData.Instance().starGameTimeSpan).TotalSeconds);
		configdata.saveDataList[_id - 1] = gameData[_id - 1].SceneBefore + "|" + SharedData.Instance().m_PlayRound + "|" + SharedData.Instance().LocalVersion + "|" + SharedData.Instance().m_Game_Mode;
		SharedData.Instance().starGameTimeSpan = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		SaveConfig();
	}

	private void LoadConfig()
	{
		string fileName = DocumentsPath + "\\configdata.dat";
		string fileName2 = DocumentsPath + "\\configdata";
		if (!xs.hasFile(fileName) && !xs.hasFile(fileName2))
		{
			Debug.LogWarning("Dont have any configData");
		}
		string text = DocumentsPath + "\\configdata.dat";
		if (xs.hasFile(text))
		{
			LoadConfigOperate(text);
		}
		else
		{
			Debug.LogWarning("Not found [configdata.dat], try [configdata] instead.");
			text = DocumentsPath + "\\configdata";
			if (xs.hasFile(text))
			{
				LoadConfigOperate(text);
			}
		}
		if (hasLoadConfigFromFile)
		{
			switch (configdata.gameSpeed)
			{
			case 1:
				Time.timeScale = 1f;
				break;
			case 2:
				Time.timeScale = 1.5f;
				break;
			default:
				Time.timeScale = 1f;
				break;
			}
			if (!RunningEnvironment.isSteamDeck)
			{
				InputIconSetConfiguratorSO.Instance.gameIconType = configdata.gameIconType.ToString();
			}
		}
	}

	public void SaveConfig(bool refreshInheritance = false)
	{
		if (refreshInheritance)
		{
			PackaConfigTable();
		}
		string fileName = DocumentsPath + "\\configdata.dat";
		string thisData = xs.SerializeObject(configdata, typeof(ConfigData));
		xs.CreateXML(fileName, thisData);
	}

	private void PackaConfigTable()
	{
		configdata.b02append.Clear();
		configdata.b03append.Clear();
		configdata.b07append.Clear();
		string[] array = configdata.inheritItems.Split('&');
		for (int i = 0; i < array.Length; i++)
		{
			string[] array2 = array[i].Split('|');
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(array2[0]);
			if (row == null)
			{
				Debug.LogWarning("Inheritance can not find b07 id = " + array2[0]);
				continue;
			}
			configdata.b07append.Add(PackB07Table(row));
			if (row.Use[2].Equals('1') || row.Use[3].Equals('1') || row.Use[4].Equals('1'))
			{
				gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(row.Relateid);
				if (row2 == null)
				{
					Debug.LogWarning("Inheritance can not find b02 id = " + row.Relateid);
				}
				else
				{
					configdata.b02append.Add(PackB02Table(row2));
				}
			}
			else if (row.Use[8].Equals('1'))
			{
				gang_b03Table.Row row3 = CommonResourcesData.b03.Find_ID(row.Relateid);
				if (row3 == null)
				{
					Debug.LogWarning("Inheritance can not find b03 id = " + row.Relateid);
				}
				else
				{
					configdata.b03append.Add(PackB03Table(row3));
				}
			}
		}
	}

	public void LoadStatsAndAchievements()
	{
		string text = DocumentsPath + "\\StatsAndAchievementdata.dat";
		if (xs.hasFile(text))
		{
			LoadStatsAndAchievementsOperation(text);
		}
		SaveStatsAndAchievements();
	}

	public void SaveStatsAndAchievements()
	{
		string fileName = DocumentsPath + "\\StatsAndAchievementdata.dat";
		string thisData = xs.SerializeObject(statsAndAchievementsDataList, typeof(List<StatsAndAchievementsData>));
		xs.CreateXML(fileName, thisData);
	}

	private void LoadUnlockAtlasList()
	{
		string text = DocumentsPath + "\\UnlockAtlasdata.dat";
		if (xs.hasFile(text))
		{
			LoadUnlockAtlasListOperation(text);
		}
	}

	public void SaveUnlockAtlasList()
	{
		string fileName = DocumentsPath + "\\UnlockAtlasdata.dat";
		string thisData = xs.SerializeObject(UnlockAtlasList, typeof(List<UnlockAtlasItem>));
		xs.CreateXML(fileName, thisData);
	}

	private void InitStatsAndAchievementsData()
	{
		foreach (gang_a07Table.Row row in CommonResourcesData.a07.GetRowList())
		{
			StatsAndAchievementsData statsAndAchievementsData = new StatsAndAchievementsData();
			statsAndAchievementsData.Achieved = row.Achieved;
			statsAndAchievementsData.AchievedIcon = row.AchievedIcon;
			statsAndAchievementsData.CurValue = row.CurValue;
			statsAndAchievementsData.GetWay = row.GetWay;
			statsAndAchievementsData.Hidden = row.Hidden;
			statsAndAchievementsData.ID = row.ID;
			statsAndAchievementsData.TotalValue = row.TotalValue;
			statsAndAchievementsData.Type = row.Type;
			statsAndAchievementsData.UnAchievedIcon = row.UnAchievedIcon;
			statsAndAchievementsData.Name = row.Name;
			statsAndAchievementsData.Name_EN = row.Name_EN;
			statsAndAchievementsData.Describe = row.Describe;
			statsAndAchievementsData.Describe_EN = row.Describe_EN;
			statsAndAchievementsDataList.Add(statsAndAchievementsData);
		}
	}

	private void RefreshStatsAndAchievement()
	{
		List<StatsAndAchievementsData> list = new List<StatsAndAchievementsData>();
		foreach (gang_a07Table.Row tmp in CommonResourcesData.a07.GetRowList())
		{
			StatsAndAchievementsData statsAndAchievementsData = new StatsAndAchievementsData();
			statsAndAchievementsData.Achieved = tmp.Achieved;
			statsAndAchievementsData.AchievedIcon = tmp.AchievedIcon;
			statsAndAchievementsData.CurValue = tmp.CurValue;
			statsAndAchievementsData.GetWay = tmp.GetWay;
			statsAndAchievementsData.Hidden = tmp.Hidden;
			statsAndAchievementsData.ID = tmp.ID;
			statsAndAchievementsData.TotalValue = tmp.TotalValue;
			statsAndAchievementsData.Type = tmp.Type;
			statsAndAchievementsData.UnAchievedIcon = tmp.UnAchievedIcon;
			statsAndAchievementsData.Name = tmp.Name;
			statsAndAchievementsData.Name_EN = tmp.Name_EN;
			statsAndAchievementsData.Describe = tmp.Describe;
			statsAndAchievementsData.Describe_EN = tmp.Describe_EN;
			if (statsAndAchievementsDataList.Find((StatsAndAchievementsData x) => x.ID == tmp.ID) != null)
			{
				statsAndAchievementsData.Achieved = statsAndAchievementsDataList.Find((StatsAndAchievementsData x) => x.ID == tmp.ID).Achieved;
				statsAndAchievementsData.CurValue = statsAndAchievementsDataList.Find((StatsAndAchievementsData x) => x.ID == tmp.ID).CurValue;
			}
			list.Add(statsAndAchievementsData);
		}
		statsAndAchievementsDataList.Clear();
		statsAndAchievementsDataList = list;
	}

	public bool AddUnlockAtlasList(string _id, string _tableName)
	{
		if (_tableName == "b07" && (!SharedData.Instance().PlayerPackage.ContainsKey(_id) || SharedData.Instance().PlayerPackage[_id] < 1))
		{
			return false;
		}
		if (_tableName == "b06")
		{
			return false;
		}
		if (_tableName == "b07")
		{
			gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(_id);
			if (row2 == null)
			{
				return false;
			}
			if (row2.Use[2] != '1' && row2.Use[3] != '1' && row2.Use[4] != '1' && row2.Use[8] != '1')
			{
				return false;
			}
			if (CommonResourcesData.b03.Find_ID(row2.Relateid) == null && CommonResourcesData.b02.Find_ID(row2.Relateid) == null)
			{
				return false;
			}
		}
		if (_id.StartsWith("MB07") || _id.StartsWith("MB02"))
		{
			return false;
		}
		if (_tableName.Equals("b01") && _id.Contains("_"))
		{
			_id = _id.Split("_")[0];
		}
		bool flag = true;
		foreach (UnlockAtlasItem unlockAtlas in UnlockAtlasList)
		{
			if (unlockAtlas.ID == _id && unlockAtlas.tableName == _tableName)
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			UnlockAtlasItem unlockAtlasItem = new UnlockAtlasItem();
			unlockAtlasItem.ID = _id;
			unlockAtlasItem.tableName = _tableName;
			unlockAtlasItem.isRead = false;
			UnlockAtlasList.Add(unlockAtlasItem);
			Sprite value = null;
			string key = "";
			switch (_tableName)
			{
			case "b07":
			{
				gang_b07Table.Row row4 = CommonResourcesData.b07.Find_ID(_id);
				if (row4 == null || (row4 != null && row4.isAtlas == "0"))
				{
					return false;
				}
				value = CommonResourcesData.GetBookIcon(row4.BookIcon);
				key = row4.Name_Trans;
				break;
			}
			case "b01":
			{
				gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(_id);
				if (row != null && row.isAtlas == "0")
				{
					return false;
				}
				value = CommonResourcesData.GetRoleIcon(row.BattleIcon);
				key = row.Name_Trans;
				List<gang_b10Table.Row> list = new List<gang_b10Table.Row>();
				for (int i = 20001; i <= 20010; i++)
				{
					list.Add(CommonResourcesData.b10.Find_ID(i.ToString()));
				}
				if (list.Find((gang_b10Table.Row x) => x.Members.Split('|').ToList().Contains(row.ID)) == null)
				{
					return false;
				}
				CommonResourcesData.b10.Find_ID("10001");
				break;
			}
			case "b06":
			{
				gang_b06Table.Row row3 = CommonResourcesData.b06.Find_id(_id);
				if (row3 != null && row3.isAtlas == "0")
				{
					return false;
				}
				value = Resources.Load("images/07-icon/300-Common", typeof(Sprite)) as Sprite;
				key = row3.name_Trans;
				break;
			}
			}
			SharedData.Instance().UnlockAtlasInfoList.TryAdd(key, value);
			SaveUnlockAtlasList();
			return true;
		}
		return false;
	}

	private void LoadConfigOperate(string _configDataFile)
	{
		hasLoadConfigFromFile = true;
		string pXmlizedString = xs.LoadXML(_configDataFile);
		ConfigData configData = xs.DeserializeObject(pXmlizedString, typeof(ConfigData)) as ConfigData;
		if (configdata.playRound < configData.playRound)
		{
			configdata.playRound = configData.playRound;
		}
		int num = 0;
		(configdata.isEAPlayer, num) = EAGameDataManager.LoadOldConfigDataPlayRound();
		configdata.isEAPlayer = false;
		uint earliestPurchaseUnixTime = SteamApps.GetEarliestPurchaseUnixTime(new AppId_t(1407450u));
		if (earliestPurchaseUnixTime == 0)
		{
			Debug.Log("The user has never purchased this app.");
		}
		else
		{
			uint num2 = 1729735200u;
			if (earliestPurchaseUnixTime < num2)
			{
				configdata.isEAPlayer = true;
				Debug.Log("The purchase time is earlier than October 24, 2024.");
			}
			else
			{
				Debug.Log("The purchase time is not earlier than October 24, 2024.");
			}
		}
		if (num != 0 && num > configdata.playRound)
		{
			configdata.playRound = num;
		}
		configdata.lastSaveId = configData.lastSaveId;
		configdata.saveDataList.Clear();
		configdata.snapshotList.Clear();
		configdata.gameDurationList.Clear();
		configdata.LastWriteTime.Clear();
		configdata.FollowerIconList.Clear();
		configdata.FollowerIconB01SkinList.Clear();
		for (int i = 0; i < configData.saveDataList.Count; i++)
		{
			configdata.saveDataList.Add(configData.saveDataList[i]);
			configdata.snapshotList.Add(configData.snapshotList[i]);
			configdata.gameDurationList.Add(configData.gameDurationList[i]);
		}
		for (int j = 0; j < configData.LastWriteTime.Count; j++)
		{
			configdata.LastWriteTime.Add(configData.LastWriteTime[j]);
		}
		for (int k = 0; k < configData.FollowerIconList.Count; k++)
		{
			configdata.FollowerIconList.Add(new List<string>());
			for (int l = 0; l < configData.FollowerIconList[k].Count; l++)
			{
				configdata.FollowerIconList[k].Add(configData.FollowerIconList[k][l]);
			}
		}
		for (int m = 0; m < configData.FollowerIconB01SkinList.Count; m++)
		{
			configdata.FollowerIconB01SkinList.Add(new List<gang_b01SkinTable.Row>());
			for (int n = 0; n < configData.FollowerIconB01SkinList[m].Count; n++)
			{
				configdata.FollowerIconB01SkinList[m].Add(configData.FollowerIconB01SkinList[m][n]);
			}
		}
		configdata.masterVolume = configData.masterVolume;
		configdata.musicVolume = configData.musicVolume;
		configdata.seVolume = configData.seVolume;
		configdata.isMasterMute = configData.isMasterMute;
		configdata.isMusicMute = configData.isMusicMute;
		configdata.isSEMute = configData.isSEMute;
		configdata.screenmode = configData.screenmode;
		configdata.gameSpeed = configData.gameSpeed;
		configdata.gameIconType = configData.gameIconType;
		configdata.resolution = configData.resolution;
		configdata.currentAutoSaveIndex = configData.currentAutoSaveIndex;
		configdata.inheritItems = configData.inheritItems;
		configdata.language = configData.language;
		configdata.m_create_serial_id = configData.m_create_serial_id;
		configdata.b02append = configData.b02append;
		configdata.b03append = configData.b03append;
		configdata.b07append = configData.b07append;
	}

	private void LoadConfigTable()
	{
		foreach (string item in configdata.b02append)
		{
			RestoreB02Table(item);
		}
		foreach (string item2 in configdata.b03append)
		{
			RestoreB03Table(item2);
		}
		foreach (string item3 in configdata.b07append)
		{
			RestoreB07Table(item3);
		}
	}

	private void LoadStatsAndAchievementsOperation(string _dataFile)
	{
		string text = xs.LoadXML(_dataFile);
		if (text != "" && xs.DeserializeObject(text, typeof(List<StatsAndAchievementsData>)) is List<StatsAndAchievementsData> list)
		{
			statsAndAchievementsDataList = list;
		}
	}

	private void LoadUnlockAtlasListOperation(string _dataFile)
	{
		string text = xs.LoadXML(_dataFile);
		if (text != "" && xs.DeserializeObject(text, typeof(List<UnlockAtlasItem>)) is List<UnlockAtlasItem> unlockAtlasList)
		{
			UnlockAtlasList = unlockAtlasList;
		}
	}

	public List<string> LoadConfigSimple(int _id)
	{
		string fileName = DocumentsPath + "\\configdata.dat";
		if (xs.hasFile(fileName))
		{
			ConfigData configData = configdata;
			for (int i = 0; i < configData.saveDataList.Count; i++)
			{
				configdata.saveDataList[i] = configData.saveDataList[i];
				configdata.snapshotList[i] = configData.snapshotList[i];
				configdata.gameDurationList[i] = configData.gameDurationList[i];
			}
			for (int j = 0; j < configData.LastWriteTime.Count; j++)
			{
				configdata.LastWriteTime[j] = configData.LastWriteTime[j];
			}
			for (int k = 0; k < configData.FollowerIconList.Count; k++)
			{
				for (int l = 0; l < configData.FollowerIconList[k].Count; l++)
				{
					configdata.FollowerIconList[k][l] = configData.FollowerIconList[k][l];
				}
			}
			for (int m = 0; m < configData.FollowerIconB01SkinList.Count; m++)
			{
				for (int n = 0; n < configData.FollowerIconB01SkinList[m].Count; n++)
				{
					configdata.FollowerIconB01SkinList[m][n] = configData.FollowerIconB01SkinList[m][n];
				}
			}
		}
		else
		{
			Debug.LogWarning("Not found [configdata.dat], try [configdata] instead.");
			fileName = DocumentsPath + "\\configdata";
			if (xs.hasFile(fileName))
			{
				ConfigData configData2 = configdata;
				for (int num = 0; num < configData2.saveDataList.Count; num++)
				{
					configdata.saveDataList[num] = configData2.saveDataList[num];
					configdata.snapshotList[num] = configData2.snapshotList[num];
					configdata.gameDurationList[num] = configData2.gameDurationList[num];
				}
				for (int num2 = 0; num2 < configData2.LastWriteTime.Count; num2++)
				{
					configdata.LastWriteTime[num2] = configData2.LastWriteTime[num2];
				}
				for (int num3 = 0; num3 < configData2.FollowerIconList.Count; num3++)
				{
					for (int num4 = 0; num4 < configData2.FollowerIconList[num3].Count; num4++)
					{
						configdata.FollowerIconList[num3][num4] = configData2.FollowerIconList[num3][num4];
					}
				}
				for (int num5 = 0; num5 < configData2.FollowerIconB01SkinList.Count; num5++)
				{
					for (int num6 = 0; num6 < configData2.FollowerIconB01SkinList[num5].Count; num6++)
					{
						configdata.FollowerIconB01SkinList[num5][num6] = configData2.FollowerIconB01SkinList[num5][num6];
					}
				}
			}
		}
		return new List<string>
		{
			configdata.saveDataList[_id - 1],
			configdata.snapshotList[_id - 1],
			configdata.gameDurationList[_id - 1].ToString()
		};
	}

	public int LastSaveId()
	{
		return configdata.lastSaveId;
	}

	public IEnumerator Save(int _id)
	{
		Instance().configdata.snapshotList[_id - 1] = Instance().SaveScreenshot(SharedData.Instance().m_MapController.m_camera);
		isSaving = true;
		getFileInfoIndex = _id;
		yield return StartCoroutine(PackData(_id));
		while (isPackData)
		{
			yield return null;
		}
		SaveConfig(_id);
		string text = DocumentsPath + "\\bigbang" + _id + dataFileName;
		Debug.Log("GameDataManager::Save(ID = " + _id + ") - Pack and Save to " + text + ".");
		string thisData = xs.SerializeObject(gameData[_id - 1], typeof(GameData));
		xs.CreateXML(text, thisData);
		currentId = _id - 1;
		isSaving = false;
	}

	public IEnumerator SaveAsync(int _id)
	{
		Instance().configdata.snapshotList[_id - 1] = Instance().SaveScreenshot(SharedData.Instance().m_MapController.m_camera);
		getFileInfoIndex = _id;
		yield return StartCoroutine(PackData(_id));
		while (isPackData)
		{
			yield return null;
		}
		SaveConfig(_id);
		string text = DocumentsPath + "\\bigbang" + _id + dataFileName;
		Debug.Log("GameDataManager::Save(ID = " + _id + ") - Pack and Save to " + text + ".");
		string thisData = xs.SerializeObject(gameData[_id - 1], typeof(GameData));
		xs.CreateXML(text, thisData);
		currentId = _id - 1;
		SharedData.Instance().m_IsAutoSaving = false;
		yield return null;
		SharedData.Instance().m_DataRecordManager.UpdateAutoItem(_id);
	}

	public bool HasSaveData()
	{
		bool result = false;
		foreach (string saveData in configdata.saveDataList)
		{
			if (!"Empty".Equals(saveData))
			{
				result = true;
				break;
			}
		}
		return result;
	}

	public string GetFileInfo(int _id)
	{
		getFileInfoIndex = _id;
		string fileName = DocumentsPath + "\\bigbang" + _id + dataFileName;
		return xs.GetLastWriteTime(fileName);
	}

	public IEnumerator Load(int _id)
	{
		isRestoreData = true;
		currentId = _id - 1;
		SharedData.Instance().m_PlayRound = int.Parse(configdata.saveDataList[currentId].Split('|')[1]);
		LoadOne(_id);
		yield return StartCoroutine(RestoreData(_id));
		while (isRestoreData)
		{
			yield return null;
		}
	}

	private void LoadOne(int _id)
	{
		string text = DocumentsPath + "\\bigbang" + _id + dataFileName;
		if (xs.hasFile(text))
		{
			Debug.Log("GameDataManager::Load(ID = " + _id + ") - Load from " + text + ".");
			string pXmlizedString = xs.LoadXML(text);
			GameData value = xs.DeserializeObject(pXmlizedString, typeof(GameData)) as GameData;
			Debug.Log("GameDataManager::Load() - Data OK.");
			gameData[_id - 1] = value;
			isGameDataEmptyList[_id - 1] = true;
		}
		else
		{
			Debug.Log("GameDataManager::Load(ID = " + _id + ") - File " + text + " NOT exist.");
		}
	}

	public IEnumerator RestoreData(int _id)
	{
		isRestoreData = true;
		SharedData.Instance().gameDataVersion = gameData[_id - 1].gameDateVersion;
		SharedData.Instance().BornID = gameData[_id - 1].bornid;
		SharedData.Instance().playerid = gameData[_id - 1].playerid;
		SharedData.Instance().SceneBefore = gameData[_id - 1].SceneBefore;
		SharedData.Instance().SceneBefore4Camp = gameData[_id - 1].SceneBefore4Camp;
		SharedData.Instance().SpawnPoint = gameData[_id - 1].SpawnPoint;
		SharedData.Instance().playercamctrl = gameData[_id - 1].playercamctrl;
		SharedData.Instance().m_Money = gameData[_id - 1].m_Money;
		SharedData.Instance().m_Epiphany = gameData[_id - 1].m_Epiphany;
		SharedData.Instance().m_PlayRound = gameData[_id - 1].m_PlayRound;
		SharedData.Instance().m_FieldMoveSpeedRate = gameData[_id - 1].m_FieldMoveSpeedRate;
		SharedData.Instance().m_ArenaWinCount = gameData[_id - 1].m_ArenaWinCount;
		SharedData.Instance().m_Arena_Rewards_JunShan = gameData[_id - 1].m_Arena_Rewards_JunShan;
		SharedData.Instance().SetGameMode(gameData[_id - 1].Game_Mode);
		SharedData.Instance().m_MineRefreshWalkStep = gameData[_id - 1].m_MineRefreshWalkStep;
		SharedData.Instance().m_MineRefreshChangeFieldNum = gameData[_id - 1].m_MineRefreshChangeFieldNum;
		SharedData.Instance().m_ShovelDurable = gameData[_id - 1].m_ShovelDurable;
		SharedData.Instance().mapMineList = gameData[_id - 1].mapMineList;
		SharedData.Instance().mapMineCouldRefreshList = gameData[_id - 1].mapMineCouldRefreshList;
		SharedData.Instance().m_DaTianWangSiLevel = gameData[_id - 1].m_DaTianWangSiLevel;
		SharedData.Instance().m_Arena_Rewards_DaTianWangSi = gameData[_id - 1].m_Arena_Rewards_DaTianWangSi;
		foreach (gang_b02Table.Row item in CommonResourcesData.b02append)
		{
			CommonResourcesData.b02.GetRowList().Remove(item);
		}
		CommonResourcesData.b02append.Clear();
		foreach (gang_b03Table.Row item2 in CommonResourcesData.b03append)
		{
			CommonResourcesData.b03.GetRowList().Remove(item2);
		}
		CommonResourcesData.b03append.Clear();
		foreach (gang_b07Table.Row item3 in CommonResourcesData.b07append)
		{
			CommonResourcesData.b07.GetRowList().Remove(item3);
		}
		CommonResourcesData.b07append.Clear();
		LoadConfigTable();
		foreach (string item4 in gameData[_id - 1].b02append)
		{
			RestoreB02Table(item4);
		}
		foreach (string item5 in gameData[_id - 1].b03append)
		{
			RestoreB03Table(item5);
		}
		foreach (string item6 in gameData[_id - 1].b07append)
		{
			RestoreB07Table(item6);
		}
		switch (gameData[_id - 1].playerdirection)
		{
		case 0:
			SharedData.Instance().playerdirection = Direction.Down;
			break;
		case 1:
			SharedData.Instance().playerdirection = Direction.Right;
			break;
		case 2:
			SharedData.Instance().playerdirection = Direction.Up;
			break;
		case 3:
			SharedData.Instance().playerdirection = Direction.Left;
			break;
		}
		SharedData.Instance().FullTeam.Clear();
		if (gameData[_id - 1].FullTeam != null)
		{
			SharedData.Instance().FullTeam.AddRange(gameData[_id - 1].FullTeam);
			foreach (string item7 in SharedData.Instance().FullTeam)
			{
				_ = item7;
			}
		}
		SharedData.Instance().m_SpecialWantedList.Clear();
		if (gameData[_id - 1].m_SpecialWantedList != null)
		{
			SharedData.Instance().m_SpecialWantedList.AddRange(gameData[_id - 1].m_SpecialWantedList);
		}
		if (gameData[_id - 1].lastSelectBattleIdList != null)
		{
			SharedData.Instance().lastSelectBattleIdList.AddRange(gameData[_id - 1].lastSelectBattleIdList);
		}
		if (gameData[_id - 1].m_NewItemList != null)
		{
			SharedData.Instance().m_NewItemList = gameData[_id - 1].m_NewItemList;
		}
		SharedData.Instance().isChooseBattle = false;
		_ = gameData[_id - 1].isChooseBattle;
		SharedData.Instance().isChooseBattle = gameData[_id - 1].isChooseBattle;
		SharedData.Instance().FollowList.Clear();
		if (gameData[_id - 1].FollowList != null)
		{
			SharedData.Instance().FollowList.AddRange(gameData[_id - 1].FollowList);
		}
		SharedData.Instance().m_Mesg_News.Clear();
		if (gameData[_id - 1].Mesg_News != null)
		{
			SharedData.Instance().m_Mesg_News.AddRange(gameData[_id - 1].Mesg_News);
		}
		SharedData.Instance().m_Mesg_Tecs.Clear();
		if (gameData[_id - 1].Mesg_Tecs != null)
		{
			SharedData.Instance().m_Mesg_Tecs.AddRange(gameData[_id - 1].Mesg_Tecs);
		}
		gang_a02Table.Row row = CommonResourcesData.a02.Find_ID(SharedData.Instance().BornID);
		Type type = row.GetType();
		SharedData.Instance().CharaDataList.Clear();
		foreach (SimpleCharaData simpleCharaData in gameData[_id - 1].simpleCharaDatas)
		{
			CharaData charaData = SharedData.Instance().GetCharaData(simpleCharaData.m_Id);
			if (charaData == null)
			{
				Debug.LogWarning("Can NOT find charaId: " + simpleCharaData.m_Id);
				continue;
			}
			charaData.m_Table = simpleCharaData.m_Table;
			charaData.m_Id = simpleCharaData.m_Id;
			charaData.m_Prefab = simpleCharaData.m_Prefab;
			charaData.m_BattleIcon = simpleCharaData.m_BattleIcon;
			charaData.m_DefaultPrefab = simpleCharaData.m_DefaultPrefab;
			charaData.m_DefaultBattleIcon = simpleCharaData.m_DefaultBattleIcon;
			charaData.m_Hp = simpleCharaData.m_Hp;
			charaData.m_Mp = simpleCharaData.m_Mp;
			charaData.m_Training_Id = simpleCharaData.m_Training_Id;
			charaData.m_Level = simpleCharaData.m_Level;
			charaData.m_Exp = simpleCharaData.m_Exp;
			charaData.m_Relationship = simpleCharaData.m_Relationship;
			charaData.m_Ranking = simpleCharaData.m_Ranking;
			charaData.m_Talent = simpleCharaData.m_Talent;
			charaData.m_currentTitleID = simpleCharaData.m_currentTitleID;
			charaData.m_NickName = simpleCharaData.m_NickName;
			charaData.m_Guild = simpleCharaData.m_Guild;
			charaData.totalTalentCost = simpleCharaData.totalTalentCost;
			gang_b01Table.Row row2 = CommonResourcesData.b01.Find_ID(charaData.m_Id);
			charaData.m_Prefab = row2.Prefab;
			if (row2 != null)
			{
				charaData.b01SkinRow = CommonResourcesData.b01Skin.Find_ID(row2.Prefab);
			}
			if (simpleCharaData.m_AtomData.Count <= 0)
			{
				foreach (string sz_AtomDatum in simpleCharaData.sz_AtomData)
				{
					string[] array = sz_AtomDatum.Split(',');
					SimpleAtomData simpleAtomData = new SimpleAtomData
					{
						id = array[0],
						stringValue = array[1],
						bornValue = float.Parse(array[2], CultureInfo.InvariantCulture),
						alterValue = float.Parse(array[3], CultureInfo.InvariantCulture),
						fightValue = float.Parse(array[4], CultureInfo.InvariantCulture),
						rollValue = float.Parse(array[5], CultureInfo.InvariantCulture)
					};
					if (!SharedData.Instance().gameDataVersion.Equals(""))
					{
						simpleAtomData.juqingValue = float.Parse(array[6], CultureInfo.InvariantCulture);
						simpleAtomData.levelupValue = float.Parse(array[7], CultureInfo.InvariantCulture);
						simpleAtomData.talentValue = float.Parse(array[8], CultureInfo.InvariantCulture);
					}
					simpleCharaData.m_AtomData.Add(simpleAtomData);
				}
				simpleCharaData.sz_AtomData.Clear();
			}
			else
			{
				Debug.LogWarning("Load m_AtomData from old savefile ...");
			}
			if (simpleCharaData.m_KongFuData.Count <= 0)
			{
				foreach (string sz_KongFuDatum in simpleCharaData.sz_KongFuData)
				{
					string[] array2 = sz_KongFuDatum.Split(',');
					SimpleKongFuData simpleKongFuData = new SimpleKongFuData
					{
						id = array2[0],
						lv = int.Parse(array2[1]),
						exp = float.Parse(array2[2], CultureInfo.InvariantCulture),
						proficiency = int.Parse(array2[3]),
						isAbolished = false
					};
					if (array2.Length > 4)
					{
						simpleKongFuData.isAbolished = bool.Parse(array2[4]);
					}
					simpleCharaData.m_KongFuData.Add(simpleKongFuData);
				}
				simpleCharaData.sz_KongFuData.Clear();
			}
			else
			{
				Debug.LogWarning("Load m_KongFuData from old savefile ...");
			}
			List<SimpleKongFuData> list = new List<SimpleKongFuData>();
			charaData.m_KongFuListInBattle = simpleCharaData.m_KongFuListInBattle;
			charaData.m_KongFuList.Clear();
			if (list.Count < simpleCharaData.m_KongFuData.Count)
			{
				foreach (SimpleKongFuData kongFuDatum in simpleCharaData.m_KongFuData)
				{
					if (list.Contains(kongFuDatum))
					{
						continue;
					}
					gang_b03Table.Row row3 = CommonResourcesData.b03.Find_ID(kongFuDatum.id);
					if (row3 == null)
					{
						Debug.LogWarning("m_Id[" + simpleCharaData.m_Id + "] kongfu[" + kongFuDatum.id + "] in savefile NOT found.");
						if (charaData.m_KongFuListInBattle.Contains(kongFuDatum.id))
						{
							charaData.m_KongFuListInBattle.Remove(kongFuDatum.id);
						}
					}
					else
					{
						KongFuData kongFuData = new KongFuData();
						kongFuData.kf = row3;
						kongFuData.lv = kongFuDatum.lv;
						kongFuData.exp = kongFuDatum.exp;
						kongFuData.proficiency = kongFuDatum.proficiency;
						kongFuData.isAbolished = kongFuDatum.isAbolished;
						if (kongFuData.isAbolished)
						{
							charaData.m_AbolishedKongFuList.Add(kongFuData);
						}
						else
						{
							charaData.m_KongFuList.Add(kongFuData);
						}
					}
				}
			}
			if (charaData.m_KongFuListInBattle.Count == 0)
			{
				foreach (KongFuData kongFu in charaData.m_KongFuList)
				{
					charaData.m_KongFuListInBattle.Add(kongFu.kf.ID);
				}
			}
			foreach (KeyValuePair<string, AtomData> item8 in charaData.Indexs_Name)
			{
				SimpleAtomData simpleAtomData2 = null;
				foreach (SimpleAtomData atomDatum in simpleCharaData.m_AtomData)
				{
					if (item8.Value.a01ID.Equals(atomDatum.id))
					{
						simpleAtomData2 = atomDatum;
						break;
					}
				}
				if (simpleAtomData2 == null)
				{
					continue;
				}
				item8.Value.stringValue = simpleAtomData2.stringValue;
				item8.Value.bornValue = simpleAtomData2.bornValue;
				item8.Value.alterValue = simpleAtomData2.alterValue;
				item8.Value.fightValue = simpleAtomData2.fightValue;
				item8.Value.juqingValue = simpleAtomData2.juqingValue;
				item8.Value.levelupValue = simpleAtomData2.levelupValue;
				item8.Value.talentValue = simpleAtomData2.talentValue;
				if (!simpleCharaData.m_Id.Equals(gameData[_id - 1].playerid) && item8.Key == "Name")
				{
					gang_b01Table.Row row4 = CommonResourcesData.b01.Find_ID(charaData.m_Id);
					item8.Value.stringValue = row4.Name_Trans;
				}
				if (simpleCharaData.m_Id.Equals(gameData[_id - 1].playerid) && simpleAtomData2.rollValue == 0f)
				{
					gang_a01Table.Row row5 = CommonResourcesData.a01.Find_ID(item8.Value.a01ID);
					if (row5 != null)
					{
						FieldInfo field = type.GetField(row5.Name);
						if (field != null)
						{
							try
							{
								item8.Value.rollValue = float.Parse(field.GetValue(row).ToString(), CultureInfo.InvariantCulture);
							}
							catch (Exception)
							{
								item8.Value.rollValue = -874f;
							}
						}
					}
				}
				else
				{
					item8.Value.rollValue = simpleAtomData2.rollValue;
				}
				item8.Value.drunkbuffValue = 0f;
			}
			charaData.m_TraitList.Clear();
			foreach (string trait in simpleCharaData.m_TraitList)
			{
				charaData.AddTraits(trait);
			}
			charaData.m_EquipTraitDict.Clear();
			for (int i = 1; i <= 9; i++)
			{
				charaData.m_EquipTraitDict[i.ToString()] = "";
			}
			foreach (string equipTrait in simpleCharaData.m_EquipTraitList)
			{
				string[] array3 = equipTrait.Split('|');
				if (int.Parse(array3[0]) <= 9)
				{
					if (array3.Length == 2)
					{
						charaData.m_EquipTraitDict[array3[0]] = array3[1];
					}
					else
					{
						charaData.m_EquipTraitDict[array3[0]] = "";
					}
				}
			}
			charaData.CalAdditionalTrait();
			foreach (string titleExp in simpleCharaData.m_titleExpList)
			{
				string[] array4 = titleExp.Split("|");
				if (array4.Length == 2)
				{
					charaData.m_titleExpDict[array4[0]] = int.Parse(array4[1]);
				}
				else
				{
					charaData.m_titleExpDict[array4[0]] = 0;
				}
			}
			charaData.m_EquipSlot.Clear();
			foreach (string item9 in simpleCharaData.m_EquipSlot)
			{
				charaData.m_EquipSlot.Add(item9);
			}
			charaData.m_NicknameList.Clear();
			foreach (string nickname in simpleCharaData.m_NicknameList)
			{
				charaData.m_NicknameList.Add(nickname);
			}
		}
		if (gameData[_id - 1].protagonistSkinDataNew != null)
		{
			SharedData.Instance().protagonistSkinDataNew = gameData[_id - 1].protagonistSkinDataNew;
		}
		if (gameData[_id - 1].protagonistSkinB01SkinTable != null)
		{
			SharedData.Instance().protagonistSkinB01SkinTable = gameData[_id - 1].protagonistSkinB01SkinTable;
			gang_b01SkinTable.Row row6 = CommonResourcesData.b01ChangeSkin.Find_ID(SharedData.Instance().protagonistSkinB01SkinTable.ID);
			SharedData.Instance().protagonistSkinB01SkinTable.weapon_sword = row6.weapon_sword;
			SharedData.Instance().protagonistSkinB01SkinTable.weapon_knife = row6.weapon_knife;
			SharedData.Instance().protagonistSkinB01SkinTable.weapon_stick = row6.weapon_stick;
		}
		if (SharedData.Instance().protagonistSkinDataNew.isCustom)
		{
			SharedData.Instance().GetCharaData(SharedData.Instance().playerid).b01SkinRow = SharedData.Instance().protagonistSkinB01SkinTable;
		}
		else
		{
			SharedData.Instance().GetCharaData(SharedData.Instance().playerid).b01SkinRow = null;
		}
		SharedData.Instance().MapUnitsBefore.Clear();
		foreach (SimpleMapUnit simpleMapUnit in gameData[_id - 1].simpleMapUnits)
		{
			SharedData.Instance().MapUnitsBefore.Add(simpleMapUnit.map_id, simpleMapUnit.unit_pos);
		}
		SharedData.Instance().PlayerPackage.Clear();
		SharedData.Instance().m_NewItemList.Clear();
		foreach (SimplePackItem simplePackItem in gameData[_id - 1].simplePackItems)
		{
			SharedData.Instance().PlayerPackage.Add(simplePackItem.id, simplePackItem.amount);
			AddUnlockAtlasList(simplePackItem.id, "b07");
		}
		SharedData.Instance().EventsRecord.Clear();
		foreach (SimpleEventRecord simpleEventRecord in gameData[_id - 1].simpleEventRecords)
		{
			EventRecord eventRecord = new EventRecord
			{
				display = simpleEventRecord.display,
				flow = simpleEventRecord.flow,
				elseroute = simpleEventRecord.elseroute,
				objcamarectrl = simpleEventRecord.objcamarectrl
			};
			if (simpleEventRecord.originevdata_flag != "")
			{
				eventRecord.originevdata = CommonResourcesData.e01.Find_flag(simpleEventRecord.originevdata_flag);
			}
			if (simpleEventRecord.evdata_flag != "")
			{
				eventRecord.evdata = CommonResourcesData.e01.Find_flag(simpleEventRecord.evdata_flag);
			}
			switch (simpleEventRecord.objdirection)
			{
			case 0:
				eventRecord.objdirection = Direction.Down;
				break;
			case 1:
				eventRecord.objdirection = Direction.Right;
				break;
			case 2:
				eventRecord.objdirection = Direction.Up;
				break;
			case 3:
				eventRecord.objdirection = Direction.Left;
				break;
			}
			SharedData.Instance().EventsRecord.Add(simpleEventRecord.map_id, eventRecord);
		}
		if (isAsyncLoadOrSaveDate)
		{
			yield return null;
		}
		foreach (string item10 in new List<string>(SharedData.Instance().FlagList.Keys))
		{
			SharedData.Instance().FlagList[item10] = 0;
		}
		if (gameData[_id - 1].simpleFlagDatas.Count > 0)
		{
			foreach (SimpleFlagData simpleFlagData in gameData[_id - 1].simpleFlagDatas)
			{
				if (SharedData.Instance().FlagList.ContainsKey(simpleFlagData.flag))
				{
					SharedData.Instance().FlagList[simpleFlagData.flag] = simpleFlagData.value;
				}
				else
				{
					SharedData.Instance().FlagList.Add(simpleFlagData.flag, simpleFlagData.value);
				}
			}
		}
		else
		{
			string[] array5 = gameData[_id - 1].strFlagDatas.Split('|');
			for (int j = 0; j < array5.Length; j++)
			{
				string[] array6 = array5[j].Split('&');
				if (SharedData.Instance().FlagList.ContainsKey(array6[0]))
				{
					SharedData.Instance().FlagList[array6[0]] = int.Parse(array6[1]);
				}
				else
				{
					SharedData.Instance().FlagList.Add(array6[0], int.Parse(array6[1]));
				}
			}
		}
		if (isAsyncLoadOrSaveDate)
		{
			yield return null;
		}
		foreach (SimpleShopGood simpleShopGood in gameData[_id - 1].simpleShopGoods)
		{
			SharedData.Instance().m_ShopGoods[simpleShopGood.id] = simpleShopGood.hold;
		}
		foreach (SimpleShopGood simpleLoanedItem in gameData[_id - 1].simpleLoanedItems)
		{
			SharedData.Instance().m_LoanedItems[simpleLoanedItem.id] = simpleLoanedItem.hold;
		}
		foreach (SimpleShopGood simpleHoriMono in gameData[_id - 1].simpleHoriMonos)
		{
			SharedData.Instance().m_HoriMonos[simpleHoriMono.id] = simpleHoriMono.hold;
		}
		foreach (SimpleShopGood simpleWantedInfo in gameData[_id - 1].simpleWantedInfos)
		{
			SharedData.Instance().m_WantedInfos[simpleWantedInfo.id] = simpleWantedInfo.hold;
		}
		CommonResourcesData.b10.Find_ID("1010").Members = gameData[_id - 1].m_DongShuFactionMember;
		CommonResourcesData.b10.Find_ID("1011").Members = gameData[_id - 1].m_JinWuFactionMember;
		CommonResourcesData.b10.Find_ID("1006").Members = gameData[_id - 1].m_XiBoFactionMember;
		CommonResourcesData.b10.Find_ID("1007").Members = gameData[_id - 1].m_BeiGuFactionMember;
		SharedData.Instance().m_UnLockMapIconList = gameData[_id - 1].m_UnLockMapIconList;
		if (SharedData.Instance().gameDataVersion.Equals(""))
		{
			List<string> list2 = new List<string>
			{
				"STR", "AGI", "BON", "WIL", "LER", "MOR", "Sword", "Knife", "Stick", "Hand",
				"Finger", "Special", "YinYang", "Melody", "Medical", "Darts", "Wineart", "Steal", "Forge", "Percept"
			};
			foreach (KeyValuePair<string, CharaData> charaData2 in SharedData.Instance().CharaDataList)
			{
				foreach (KeyValuePair<string, AtomData> item11 in charaData2.Value.Indexs_Name)
				{
					if (list2.Contains(item11.Key))
					{
						string key = "GLOBAL_FLAGS_ADDVALUE_" + item11.Key + "_" + charaData2.Value.m_Id;
						string key2 = "GLOBAL_FLAGS_USETALENT_" + item11.Key + "_" + charaData2.Value.m_Id;
						if (SharedData.Instance().FlagList.ContainsKey(key))
						{
							item11.Value.talentValue = SharedData.Instance().FlagList[key];
							item11.Value.bornValue -= item11.Value.talentValue;
						}
						if (SharedData.Instance().FlagList.ContainsKey(key2))
						{
							charaData2.Value.totalTalentCost += SharedData.Instance().FlagList[key2];
						}
					}
					foreach (KongFuData kongFu2 in charaData2.Value.m_KongFuList)
					{
						foreach (string item12 in new List<string>
						{
							kongFu2.kf.Paraplus1,
							kongFu2.kf.Paraplus2,
							kongFu2.kf.Paraplus3,
							kongFu2.kf.Paraplus4
						})
						{
							if (!item12.Equals("") && !item12.Equals("0"))
							{
								string[] array7 = item12.Split('|');
								if (array7[0].Equals(item11.Key))
								{
									item11.Value.bornValue -= (float)(kongFu2.lv - 1) * float.Parse(array7[1], CultureInfo.InvariantCulture);
								}
							}
						}
					}
					item11.Value.rollValue = item11.Value.bornValue;
				}
			}
		}
		else if (SharedData.Instance().gameDataVersion.Equals("Vesion_20240828"))
		{
			List<string> list3 = new List<string>
			{
				"STR", "AGI", "BON", "WIL", "LER", "MOR", "Sword", "Knife", "Stick", "Hand",
				"Finger", "Special", "YinYang", "Melody", "Medical", "Darts", "Wineart", "Steal", "Forge", "Percept"
			};
			foreach (KeyValuePair<string, CharaData> charaData3 in SharedData.Instance().CharaDataList)
			{
				foreach (KeyValuePair<string, AtomData> item13 in charaData3.Value.Indexs_Name)
				{
					if (list3.Contains(item13.Key))
					{
						string key3 = "GLOBAL_FLAGS_USETALENT_" + item13.Key + "_" + charaData3.Value.m_Id;
						if (SharedData.Instance().FlagList.ContainsKey(key3))
						{
							charaData3.Value.totalTalentCost += SharedData.Instance().FlagList[key3];
						}
					}
				}
			}
		}
		SharedData.Instance().m_Patch_Fixed = false;
		isRestoreData = false;
		if (isAsyncLoadOrSaveDate)
		{
			yield return null;
		}
	}

	public IEnumerator PackData(int _id)
	{
		isPackData = true;
		TimeSpan timeSpan = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
		gameData[_id - 1].timeStamp = Convert.ToInt64(timeSpan.TotalSeconds);
		Debug.Log("PackData(): timeStamp = " + gameData[_id - 1].timeStamp);
		string text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
		Debug.Log("PackData(): saveDataTime = " + text);
		if (getFileInfoIndex != 0)
		{
			configdata.LastWriteTime[getFileInfoIndex - 1] = text;
		}
		configdata.FollowerIconList[getFileInfoIndex - 1].Clear();
		configdata.FollowerIconB01SkinList[getFileInfoIndex - 1].Clear();
		SharedData.Instance().player.charadata.m_SkinData.id = SharedData.Instance().playerid;
		configdata.FollowerIconList[getFileInfoIndex - 1].Add(SharedData.Instance().player.charadata.m_Id + "|" + SharedData.Instance().player.charadata.m_Level);
		configdata.FollowerIconB01SkinList[getFileInfoIndex - 1].Add(SharedData.Instance().player.charadata.b01SkinRow);
		foreach (string follow in SharedData.Instance().FollowList)
		{
			CharaData charaData = SharedData.Instance().GetCharaData(follow);
			SharedData.Instance().GetCharaData(follow).m_SkinData.id = follow;
			configdata.FollowerIconList[getFileInfoIndex - 1].Add(charaData.m_Id + "|" + charaData.m_Level);
			configdata.FollowerIconB01SkinList[getFileInfoIndex - 1].Add(charaData.b01SkinRow);
		}
		gameData[_id - 1].simpleCharaDatas.Clear();
		gameData[_id - 1].simpleMapUnits.Clear();
		gameData[_id - 1].simpleEventRecords.Clear();
		gameData[_id - 1].simplePackItems.Clear();
		gameData[_id - 1].simpleFlagDatas.Clear();
		gameData[_id - 1].FullTeam = null;
		gameData[_id - 1].FollowList = null;
		gameData[_id - 1].Mesg_News = null;
		gameData[_id - 1].Mesg_Tecs = null;
		gameData[_id - 1].m_SpecialWantedList = null;
		gameData[_id - 1].m_NewItemList = null;
		gameData[_id - 1].lastSelectBattleIdList = null;
		gameData[_id - 1].isChooseBattle = false;
		foreach (KeyValuePair<string, CharaData> charaData2 in SharedData.Instance().CharaDataList)
		{
			SimpleCharaData simpleCharaData = new SimpleCharaData
			{
				m_Table = charaData2.Value.m_Table,
				m_Id = charaData2.Value.m_Id,
				m_Prefab = charaData2.Value.m_Prefab,
				m_BattleIcon = charaData2.Value.m_BattleIcon,
				m_DefaultPrefab = charaData2.Value.m_DefaultPrefab,
				m_DefaultBattleIcon = charaData2.Value.m_DefaultBattleIcon,
				totalTalentCost = charaData2.Value.totalTalentCost,
				m_Hp = charaData2.Value.m_Hp,
				m_Mp = charaData2.Value.m_Mp,
				m_Training_Id = charaData2.Value.m_Training_Id,
				m_Level = charaData2.Value.m_Level,
				m_Exp = charaData2.Value.m_Exp,
				m_Relationship = charaData2.Value.m_Relationship,
				m_Ranking = charaData2.Value.m_Ranking,
				m_Talent = charaData2.Value.m_Talent,
				m_currentTitleID = charaData2.Value.m_currentTitleID,
				m_NickName = charaData2.Value.m_NickName,
				m_Guild = charaData2.Value.m_Guild,
				m_SkinData = charaData2.Value.m_SkinData
			};
			foreach (KongFuData kongFu in charaData2.Value.m_KongFuList)
			{
				if (kongFu.kf == null)
				{
					Debug.LogWarning("charadata [" + charaData2.Key + "] has a invaild kongfu which will NOT be saved.");
					continue;
				}
				string item = kongFu.kf.ID + "," + kongFu.lv + "," + kongFu.exp + "," + kongFu.proficiency + "," + kongFu.isAbolished;
				simpleCharaData.sz_KongFuData.Add(item);
			}
			foreach (KongFuData abolishedKongFu in charaData2.Value.m_AbolishedKongFuList)
			{
				if (abolishedKongFu.kf == null)
				{
					Debug.LogWarning("charadata [" + charaData2.Key + "] has a invaild kongfu which will NOT be saved.");
					continue;
				}
				string item2 = abolishedKongFu.kf.ID + "," + abolishedKongFu.lv + "," + abolishedKongFu.exp + "," + abolishedKongFu.proficiency + "," + abolishedKongFu.isAbolished;
				simpleCharaData.sz_KongFuData.Add(item2);
			}
			simpleCharaData.m_KongFuListInBattle = charaData2.Value.m_KongFuListInBattle;
			foreach (KeyValuePair<string, AtomData> item10 in charaData2.Value.Indexs_Name)
			{
				string item3 = item10.Value.a01ID + "," + item10.Value.stringValue + "," + item10.Value.bornValue + "," + item10.Value.alterValue + "," + item10.Value.fightValue + "," + item10.Value.rollValue + "," + item10.Value.juqingValue + "," + item10.Value.levelupValue + "," + item10.Value.talentValue;
				simpleCharaData.sz_AtomData.Add(item3);
			}
			simpleCharaData.m_TraitList = charaData2.Value.m_TraitList;
			for (int j = 1; j <= 9; j++)
			{
				simpleCharaData.m_EquipTraitList.Add(j + "|" + charaData2.Value.m_EquipTraitDict[j.ToString()]);
			}
			foreach (KeyValuePair<string, int> item11 in charaData2.Value.m_titleExpDict)
			{
				simpleCharaData.m_titleExpList.Add(item11.Key + "|" + item11.Value);
			}
			simpleCharaData.m_EquipSlot = charaData2.Value.m_EquipSlot;
			simpleCharaData.m_NicknameList = charaData2.Value.m_NicknameList;
			gameData[_id - 1].simpleCharaDatas.Add(simpleCharaData);
		}
		foreach (KeyValuePair<string, Vector3Int> item12 in SharedData.Instance().MapUnitsBefore)
		{
			SimpleMapUnit item4 = new SimpleMapUnit
			{
				map_id = item12.Key,
				unit_pos = item12.Value
			};
			gameData[_id - 1].simpleMapUnits.Add(item4);
		}
		foreach (KeyValuePair<string, int> item13 in SharedData.Instance().PlayerPackage)
		{
			SimplePackItem item5 = new SimplePackItem
			{
				id = item13.Key,
				amount = item13.Value
			};
			gameData[_id - 1].simplePackItems.Add(item5);
		}
		foreach (KeyValuePair<string, EventRecord> item14 in SharedData.Instance().EventsRecord)
		{
			SimpleEventRecord simpleEventRecord = new SimpleEventRecord
			{
				map_id = item14.Key,
				display = item14.Value.display,
				flow = item14.Value.flow,
				elseroute = item14.Value.elseroute,
				objcamarectrl = item14.Value.objcamarectrl
			};
			if (item14.Value.originevdata != null)
			{
				simpleEventRecord.originevdata_flag = item14.Value.originevdata.flag;
			}
			if (item14.Value.evdata != null)
			{
				simpleEventRecord.evdata_flag = item14.Value.evdata.flag;
			}
			switch (item14.Value.objdirection)
			{
			case Direction.Down:
				simpleEventRecord.objdirection = 0;
				break;
			case Direction.Right:
				simpleEventRecord.objdirection = 1;
				break;
			case Direction.Up:
				simpleEventRecord.objdirection = 2;
				break;
			case Direction.Left:
				simpleEventRecord.objdirection = 3;
				break;
			}
			gameData[_id - 1].simpleEventRecords.Add(simpleEventRecord);
		}
		if (isAsyncLoadOrSaveDate)
		{
			yield return null;
		}
		StringBuilder sb = new StringBuilder();
		int i = 0;
		Dictionary<string, int> dictionary = new Dictionary<string, int>();
		foreach (KeyValuePair<string, int> flag in SharedData.Instance().FlagList)
		{
			dictionary.Add(flag.Key, flag.Value);
		}
		foreach (KeyValuePair<string, int> item15 in dictionary)
		{
			if (sb.Length > 0)
			{
				sb.Append("|").Append(item15.Key).Append("&")
					.Append(item15.Value);
			}
			else
			{
				sb.Append(item15.Key).Append("&").Append(item15.Value);
			}
			int num = i + 1;
			i = num;
			if (num % 100 == 0 && isAsyncLoadOrSaveDate)
			{
				yield return null;
			}
		}
		gameData[_id - 1].strFlagDatas = sb.ToString();
		gameData[_id - 1].bornid = SharedData.Instance().BornID;
		gameData[_id - 1].playerid = SharedData.Instance().playerid;
		gameData[_id - 1].SceneBefore = SharedData.Instance().SceneBefore;
		gameData[_id - 1].SceneBefore4Camp = SharedData.Instance().SceneBefore4Camp;
		gameData[_id - 1].SpawnPoint = SharedData.Instance().SpawnPoint;
		gameData[_id - 1].playercamctrl = SharedData.Instance().playercamctrl;
		gameData[_id - 1].m_Money = SharedData.Instance().m_Money;
		gameData[_id - 1].m_Epiphany = SharedData.Instance().m_Epiphany;
		gameData[_id - 1].m_PlayRound = SharedData.Instance().m_PlayRound;
		gameData[_id - 1].m_FieldMoveSpeedRate = SharedData.Instance().m_FieldMoveSpeedRate;
		gameData[_id - 1].Game_Mode = SharedData.Instance().m_Game_Mode;
		gameData[_id - 1].m_ArenaWinCount = SharedData.Instance().m_ArenaWinCount;
		gameData[_id - 1].m_Arena_Rewards_JunShan = SharedData.Instance().m_Arena_Rewards_JunShan;
		gameData[_id - 1].m_MineRefreshWalkStep = SharedData.Instance().m_MineRefreshWalkStep;
		gameData[_id - 1].m_MineRefreshChangeFieldNum = SharedData.Instance().m_MineRefreshChangeFieldNum;
		gameData[_id - 1].m_ShovelDurable = SharedData.Instance().m_ShovelDurable;
		gameData[_id - 1].mapMineList = SharedData.Instance().mapMineList;
		gameData[_id - 1].mapMineCouldRefreshList = SharedData.Instance().mapMineCouldRefreshList;
		gameData[_id - 1].m_DaTianWangSiLevel = SharedData.Instance().m_DaTianWangSiLevel;
		gameData[_id - 1].m_Arena_Rewards_DaTianWangSi = SharedData.Instance().m_Arena_Rewards_DaTianWangSi;
		switch (SharedData.Instance().playerdirection)
		{
		case Direction.Down:
			gameData[_id - 1].playerdirection = 0;
			break;
		case Direction.Right:
			gameData[_id - 1].playerdirection = 1;
			break;
		case Direction.Up:
			gameData[_id - 1].playerdirection = 2;
			break;
		case Direction.Left:
			gameData[_id - 1].playerdirection = 3;
			break;
		}
		gameData[_id - 1].FullTeam = SharedData.Instance().FullTeam;
		gameData[_id - 1].m_SpecialWantedList = SharedData.Instance().m_SpecialWantedList;
		gameData[_id - 1].m_NewItemList = SharedData.Instance().m_NewItemList;
		gameData[_id - 1].lastSelectBattleIdList = SharedData.Instance().lastSelectBattleIdList;
		gameData[_id - 1].isChooseBattle = SharedData.Instance().isChooseBattle;
		gameData[_id - 1].FollowList = SharedData.Instance().FollowList;
		gameData[_id - 1].Mesg_News = SharedData.Instance().m_Mesg_News;
		gameData[_id - 1].Mesg_Tecs = SharedData.Instance().m_Mesg_Tecs;
		gameData[_id - 1].protagonistSkinDataNew = SharedData.Instance().protagonistSkinDataNew;
		gameData[_id - 1].protagonistSkinB01SkinTable = SharedData.Instance().protagonistSkinB01SkinTable;
		gameData[_id - 1].gameDateVersion = SharedData.Instance().currentGameDataVersion;
		gameData[_id - 1].simpleShopGoods.Clear();
		foreach (KeyValuePair<string, int> shopGood in SharedData.Instance().m_ShopGoods)
		{
			SimpleShopGood item6 = new SimpleShopGood
			{
				id = shopGood.Key,
				hold = shopGood.Value
			};
			gameData[_id - 1].simpleShopGoods.Add(item6);
		}
		gameData[_id - 1].simpleLoanedItems.Clear();
		foreach (KeyValuePair<string, int> loanedItem in SharedData.Instance().m_LoanedItems)
		{
			SimpleShopGood item7 = new SimpleShopGood
			{
				id = loanedItem.Key,
				hold = loanedItem.Value
			};
			gameData[_id - 1].simpleLoanedItems.Add(item7);
		}
		gameData[_id - 1].simpleHoriMonos.Clear();
		foreach (KeyValuePair<string, int> horiMono in SharedData.Instance().m_HoriMonos)
		{
			SimpleShopGood item8 = new SimpleShopGood
			{
				id = horiMono.Key,
				hold = horiMono.Value
			};
			gameData[_id - 1].simpleHoriMonos.Add(item8);
		}
		gameData[_id - 1].simpleWantedInfos.Clear();
		foreach (KeyValuePair<string, int> wantedInfo in SharedData.Instance().m_WantedInfos)
		{
			SimpleShopGood item9 = new SimpleShopGood
			{
				id = wantedInfo.Key,
				hold = wantedInfo.Value
			};
			gameData[_id - 1].simpleWantedInfos.Add(item9);
		}
		gameData[_id - 1].m_DongShuFactionMember = CommonResourcesData.b10.Find_ID("1010").Members;
		gameData[_id - 1].m_JinWuFactionMember = CommonResourcesData.b10.Find_ID("1011").Members;
		gameData[_id - 1].m_XiBoFactionMember = CommonResourcesData.b10.Find_ID("1006").Members;
		gameData[_id - 1].m_BeiGuFactionMember = CommonResourcesData.b10.Find_ID("1007").Members;
		gameData[_id - 1].m_UnLockMapIconList = SharedData.Instance().m_UnLockMapIconList;
		gameData[_id - 1].b02append.Clear();
		foreach (gang_b02Table.Row item16 in CommonResourcesData.b02append)
		{
			string text2 = PackB02Table(item16);
			gameData[_id - 1].b02append.Add(text2);
			Debug.Log("configdata.b02append.Add(app): " + text2);
		}
		gameData[_id - 1].b03append.Clear();
		foreach (gang_b03Table.Row item17 in CommonResourcesData.b03append)
		{
			string text3 = PackB03Table(item17);
			gameData[_id - 1].b03append.Add(text3);
			Debug.Log("configdata.b03append.Add(app): " + text3);
		}
		gameData[_id - 1].b07append.Clear();
		foreach (gang_b07Table.Row item18 in CommonResourcesData.b07append)
		{
			string text4 = PackB07Table(item18);
			gameData[_id - 1].b07append.Add(text4);
			Debug.Log("configdata.b07append.Add(app): " + text4);
		}
		isPackData = false;
		isGameDataEmptyList[_id - 1] = true;
		if (isAsyncLoadOrSaveDate)
		{
			yield return null;
		}
	}

	private string PackB02Table(gang_b02Table.Row row)
	{
		return string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat("" + row.ID + ";", row.Name, ";"), row.Name_EN, ";"), row.Style, ";"), row.Limit1, ";"), row.Logic, ";"), row.Limitvalue, ";"), row.Role, ";"), row.add1, ";"), row.Attribute1, ";"), row.add2, ";"), row.Attribute2, ";"), row.add3, ";"), row.Attribute3, ";"), row.add4, ";"), row.Attribute4, ";"), row.add5, ";"), row.Attribute5, ";"), row.Skills1, ";"), row.Skills1Ec, ";"), row.Enhance.ToString());
	}

	private string PackB03Table(gang_b03Table.Row row)
	{
		return string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat("" + row.ID + ";", row.Star, ";"), row.Name, ";"), row.Name_EN, ";"), row.Icon, ";"), row.BookIcon, ";"), row.Origin, ";"), row.LV, ";"), row.Style, ";"), row.Damage, ";"), row.Damageadd, ";"), row.Expend, ";"), row.Expendadd, ";"), row.EXP, ";"), row.EXPadd, ";"), row.Attckstyle, ";"), row.Area, ";"), row.Range, ";"), row.Space, ";"), row.Decreaserate, ";"), row.DelayedattackType, ";"), row.DelayedattackTime, ";"), row.Effect, ";"), row.Sound, ";"), row.Site, ";"), row.Beat, ";"), row.Dart, ";"), row.Crit, ";"), row.Critadd, ";"), row.Crit1, ";"), row.Crit1add, ";"), row.Combo, ";"), row.Comboadd, ";"), row.Skill1, ";"), row.Skill1EC, ";"), row.Skill2, ";"), row.Skill2EC, ";"), row.Skill3, ";"), row.Skill3EC, ";"), row.Skill4, ";"), row.Skill4EC, ";"), row.Skill5, ";"), row.Skill5EC, ";"), row.Limit1, ";"), row.Limit2, ";"), row.Limit3, ";"), row.Paraplus1, ";"), row.Paraplus2, ";"), row.Paraplus3, ";"), row.Paraplus4, ";"), row.AppendTraits, ";"), row.isAtlas);
	}

	private string PackB07Table(gang_b07Table.Row row)
	{
		return string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat(string.Concat("" + row.ID + ";", row.Name, ";"), row.Name_EN, ";"), row.BookIcon, ";"), row.Style, ";"), row.Star, ";"), row.Value, ";"), row.Use, ";"), row.Relateid, ";"), row.Skills1, ";"), row.Skills1Ec, ";"), row.Skills2, ";"), row.Skills2Ec, ";"), row.Skills3, ";"), row.Skills3Ec, ";"), row.Skills4, ";"), row.Skills4Ec, ";"), row.Attckstyle, ";"), row.Area, ";"), row.Range, ";"), row.note, ";"), row.note_EN, ";"), row.isAtlas, ";"), row._PriceType);
	}

	private gang_b02Table.Row RestoreB02Table(string app)
	{
		Debug.Log("configdata.b02append = " + app);
		string[] array = app.Split(';');
		gang_b02Table.Row row = new gang_b02Table.Row();
		int num = 0;
		row.ID = array[num++];
		row.Name = array[num++];
		row.Name_EN = array[num++];
		row.Style = array[num++];
		row.Limit1 = array[num++];
		row.Logic = array[num++];
		row.Limitvalue = array[num++];
		row.Role = array[num++];
		row.add1 = array[num++];
		row.Attribute1 = array[num++];
		row.add2 = array[num++];
		row.Attribute2 = array[num++];
		row.add3 = array[num++];
		row.Attribute3 = array[num++];
		row.add4 = array[num++];
		row.Attribute4 = array[num++];
		row.add5 = array[num++];
		row.Attribute5 = array[num++];
		row.Skills1 = array[num++];
		row.Skills1Ec = array[num++];
		row.Enhance = int.Parse(array[num++]);
		if (CommonResourcesData.b02.GetRowList().Find((gang_b02Table.Row x) => x.ID == row.ID) == null)
		{
			CommonResourcesData.b02.GetRowList().Add(row);
			CommonResourcesData.b02append.Add(row);
		}
		return row;
	}

	private gang_b03Table.Row RestoreB03Table(string app)
	{
		Debug.Log("configdata.b03append = " + app);
		string[] array = app.Split(';');
		gang_b03Table.Row row = new gang_b03Table.Row();
		int num = 0;
		row.ID = array[num++];
		row.Star = array[num++];
		row.Name = array[num++];
		row.Name_EN = array[num++];
		row.Icon = array[num++];
		row.BookIcon = array[num++];
		row.Origin = array[num++];
		row.LV = array[num++];
		row.Style = array[num++];
		row.Damage = array[num++];
		row.Damageadd = array[num++];
		row.Expend = array[num++];
		row.Expendadd = array[num++];
		row.EXP = array[num++];
		row.EXPadd = array[num++];
		row.Attckstyle = array[num++];
		row.Area = array[num++];
		row.Range = array[num++];
		row.Space = array[num++];
		row.Decreaserate = array[num++];
		row.DelayedattackType = array[num++];
		row.DelayedattackTime = array[num++];
		row.Effect = array[num++];
		row.Sound = array[num++];
		row.Site = array[num++];
		row.Beat = array[num++];
		row.Dart = array[num++];
		row.Crit = array[num++];
		row.Critadd = array[num++];
		row.Crit1 = array[num++];
		row.Crit1add = array[num++];
		row.Combo = array[num++];
		row.Comboadd = array[num++];
		row.Skill1 = array[num++];
		row.Skill1EC = array[num++];
		row.Skill2 = array[num++];
		row.Skill2EC = array[num++];
		row.Skill3 = array[num++];
		row.Skill3EC = array[num++];
		row.Skill4 = array[num++];
		row.Skill4EC = array[num++];
		row.Skill5 = array[num++];
		row.Skill5EC = array[num++];
		row.Limit1 = array[num++];
		row.Limit2 = array[num++];
		row.Limit3 = array[num++];
		row.Paraplus1 = array[num++];
		row.Paraplus2 = array[num++];
		row.Paraplus3 = array[num++];
		row.Paraplus4 = array[num++];
		row.AppendTraits = array[num++];
		row.isAtlas = array[num++];
		if (CommonResourcesData.b03.GetRowList().Find((gang_b03Table.Row x) => x.ID == row.ID) == null)
		{
			CommonResourcesData.b03.GetRowList().Add(row);
			CommonResourcesData.b03append.Add(row);
		}
		return row;
	}

	private gang_b07Table.Row RestoreB07Table(string app)
	{
		Debug.Log("configdata.b07append = " + app);
		string[] array = app.Split(';');
		gang_b07Table.Row row = new gang_b07Table.Row();
		int num = 0;
		row.ID = array[num++];
		row.Name = array[num++];
		row.Name_EN = array[num++];
		row.BookIcon = array[num++];
		row.Style = array[num++];
		row.Star = array[num++];
		row.Value = array[num++];
		row.Use = array[num++];
		row.Relateid = array[num++];
		row.Skills1 = array[num++];
		row.Skills1Ec = array[num++];
		row.Skills2 = array[num++];
		row.Skills2Ec = array[num++];
		row.Skills3 = array[num++];
		row.Skills3Ec = array[num++];
		row.Skills4 = array[num++];
		row.Skills4Ec = array[num++];
		row.Attckstyle = array[num++];
		row.Area = array[num++];
		row.Range = array[num++];
		row.note = array[num++];
		row.note_EN = array[num++];
		row.isAtlas = array[num++];
		if (num < array.Length)
		{
			row._PriceType = array[num++];
		}
		if (CommonResourcesData.b07.GetRowList().Find((gang_b07Table.Row x) => x.ID == row.ID) == null)
		{
			CommonResourcesData.b07.GetRowList().Add(row);
			CommonResourcesData.b07append.Add(row);
		}
		return row;
	}
}
