public static class CommonVariables
{
	public static float speed = 0.33f;

	public static float m_cameraOffset = 50f;

	public static float MovementBlockSize = 50f;

	public static float MovingSpeedPPS = 250f;

	public static float TimeToMoveOneBlock = MovementBlockSize / MovingSpeedPPS;
}
