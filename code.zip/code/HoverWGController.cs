using System.Collections;
using UnityEngine;

public class HoverWGController : MonoBehaviour
{
	public Transform hoverItem;

	public Transform hoverWuGong;

	public Transform shopHoverItem;

	public Transform shopHoverWuGong;

	public bool selected;

	public bool isInArea;

	public bool isAtlas;

	private bool isStay;

	private void Start()
	{
		isInArea = false;
		hoverItem = CommonResourcesData.HoverItem.transform;
		hoverWuGong = CommonResourcesData.HoverWuGong.transform;
	}

	private void OnHoverMouseEnter(GameObject go)
	{
		isStay = true;
		if (Cursor.visible)
		{
			StartCoroutine(OnPointerStay(go));
		}
	}

	private void OnHoverMouseExit(GameObject go)
	{
		isStay = false;
		if (Cursor.visible)
		{
			HoverDeselect(go);
		}
	}

	private IEnumerator OnPointerStay(GameObject go)
	{
		yield return new WaitForSeconds(0.5f);
		if (isStay)
		{
			HoverSelect(go, showEquip: false);
		}
		yield return null;
	}

	public void HoverSelect(GameObject go, bool showEquip = true, bool useCharaData = true)
	{
		if (hoverItem.gameObject.activeInHierarchy || hoverWuGong.gameObject.activeInHierarchy)
		{
			CommonFunc.CloseHover();
			return;
		}
		selected = true;
		HoverEnter(go, showEquip, useCharaData);
	}

	public void HoverDeselect(GameObject go)
	{
		selected = false;
		HoverExit(go);
	}

	private void HoverEnter(GameObject go, bool showEquip = true, bool useCharaData = true)
	{
		isInArea = true;
		if (selected)
		{
			ShowItemHoverOrWuGongHover(go, showEquip, useCharaData);
		}
	}

	private void HoverExit(GameObject go)
	{
		isInArea = false;
		SharedData.Instance().m_OpenDetail = "";
		if (hoverItem.gameObject.activeInHierarchy || hoverWuGong.gameObject.activeInHierarchy)
		{
			CommonFunc.CloseHover();
		}
	}

	private void ShowItemHoverOrWuGongHover(GameObject go, bool showEquip = true, bool useCharaData = true)
	{
		string[] array = go.name.Split('|');
		gang_b07Table.Row row = null;
		row = CommonResourcesData.b07.Find_ID(array[1]);
		if (row != null)
		{
			CharaData userData = null;
			if (go.GetComponent<PackageIconController>() != null)
			{
				userData = go.GetComponent<PackageIconController>().userData;
			}
			ShowItemHoverOrWuGongHover(row, userData, showEquip, useCharaData);
		}
	}

	private void ShowItemHoverOrWuGongHover(gang_b07Table.Row row, CharaData userData, bool showEquip = true, bool useCharaData = true)
	{
		if (row.Use[2] == '1' || row.Use[3] == '1' || row.Use[4] == '1')
		{
			Transform transform = null;
			transform = ((!SharedData.Instance().m_PackageController.isOpen || !SharedData.Instance().m_PackageController.isShop) ? hoverItem : shopHoverItem);
			if (!(transform == null))
			{
				SharedData.Instance().m_OpenDetail = row.ID + "|" + row.Relateid;
				CharaData charaData = null;
				charaData = ((!(SharedData.Instance().m_BattleController == null)) ? SharedData.Instance().m_BattleController.m_curcor.selected.charadata : SharedData.Instance().CurrentCharaData);
				EquipOrItemHoverShowInfo.ShowEquipItemHover(charaData, userData, transform, useCharaData);
				if (!showEquip)
				{
					transform.Find("Equiped").gameObject.SetActive(value: false);
					transform.Find("Select").gameObject.SetActive(value: true);
				}
			}
		}
		else if (row.Use[8] == '1')
		{
			SharedData.Instance().m_OpenDetail = row.Relateid;
			ShowWuGongHover(useCharaData);
		}
	}

	private void ShowWuGongHover(bool useCharaData = true)
	{
		if (hoverWuGong == null || hoverWuGong.gameObject.activeInHierarchy)
		{
			return;
		}
		if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_PackageController.isShop)
		{
			shopHoverWuGong.gameObject.SetActive(value: true);
		}
		else
		{
			hoverWuGong.gameObject.SetActive(value: true);
		}
		CharaData charaData = null;
		if (useCharaData)
		{
			charaData = ((!(SharedData.Instance().m_BattleController == null)) ? SharedData.Instance().m_BattleController.m_curcor.selected.charadata : SharedData.Instance().CurrentCharaData);
			if (charaData == null)
			{
				charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
			}
		}
		KongFuData kongFuData = null;
		if (charaData != null && useCharaData)
		{
			kongFuData = charaData.GetKongFuByID(SharedData.Instance().m_OpenDetail);
		}
		if (kongFuData == null)
		{
			kongFuData = new KongFuData();
			kongFuData.kf = CommonResourcesData.b03.Find_ID(SharedData.Instance().m_OpenDetail);
			kongFuData.lv = int.Parse(kongFuData.kf.LV);
			kongFuData.exp = 0f;
			kongFuData.proficiency = 0;
		}
		bool showCharacterIcon = true;
		if (charaData == null || SharedData.Instance().m_PackageController.packagerFunction != PackagerFunction.PlayerPackage)
		{
			showCharacterIcon = false;
		}
		if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_PackageController.isShop)
		{
			SkillHoverShowInfo.SetHoverWugongItem(charaData, kongFuData, shopHoverWuGong.transform, showCharacterIcon);
		}
		else
		{
			SkillHoverShowInfo.SetHoverWugongItem(charaData, kongFuData, hoverWuGong.transform, showCharacterIcon);
		}
	}
}
