using UnityEngine;

public static class SummonSkillManage
{
	public static void SummonSkill(BattleObject _origin, Vector3 _targetPos)
	{
		SkillInfo skillInfo = new SkillInfo();
		skillInfo.Init(_origin.m_SkillRow, _origin);
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			if (skillInfo.sName[i].Equals("Summon") && Random.Range(0f, 1f) < skillInfo.sOddNum[i])
			{
				SummonBattleObject(skillInfo.sValue[i], _origin.race, _targetPos, skillInfo.sTurnNum[i]);
				break;
			}
		}
	}

	private static void SummonBattleObject(string _id, string _race, Vector3 _poison, int _aliveRoundNumber = int.MaxValue)
	{
		if (!(SharedData.Instance().m_BattleController.GetBattleObjectInPos(_poison) != null))
		{
			gang_b01Table.Row data = CommonResourcesData.b01.Find_ID(_id);
			CharaData charaData = new CharaData();
			charaData.Init(data);
			BattleObject battleObject = SkinCharacter.InitSkinCharacter(charaData).AddComponent<BattleObject>();
			battleObject.InitSummonCharacter(_id, _race, _aliveRoundNumber);
			battleObject.transform.localPosition = _poison;
			SharedData.Instance().m_BattleController.allBattleObjs.Add(battleObject);
		}
	}
}
