using System.Collections.Generic;
using System.Globalization;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public static class SkillHoverShowInfo
{
	public static List<SkillShowInfoItem> GetSkillShowInfo(KongFuData kfdata)
	{
		List<SkillShowInfoItem> list = new List<SkillShowInfoItem>();
		int num = 1;
		float num2 = Mathf.Floor(100f * (float.Parse(kfdata.kf.Crit, CultureInfo.InvariantCulture) + float.Parse(kfdata.kf.Critadd, CultureInfo.InvariantCulture) * (float)(kfdata.lv - 1)));
		if (num2 > 0f)
		{
			string info = CommonFunc.I18nGetLocalizedValue("I18N_CritRate") + " " + num2 + "%";
			Sprite sprite = Resources.Load("images/07-icon/300-Crit1", typeof(Sprite)) as Sprite;
			list.Add(new SkillShowInfoItem
			{
				info = info,
				sprite = sprite
			});
			num++;
		}
		float num3 = Mathf.Floor(100f * (float.Parse(kfdata.kf.Crit1, CultureInfo.InvariantCulture) + float.Parse(kfdata.kf.Crit1add, CultureInfo.InvariantCulture) * (float)(kfdata.lv - 1)));
		if (num3 > 0f)
		{
			string info2 = CommonFunc.I18nGetLocalizedValue("I18N_CritDamage") + " " + num3 + "%";
			Sprite sprite2 = Resources.Load("images/07-icon/300-Crit", typeof(Sprite)) as Sprite;
			list.Add(new SkillShowInfoItem
			{
				info = info2,
				sprite = sprite2
			});
			num++;
		}
		float num4 = Mathf.Floor(100f * (float.Parse(kfdata.kf.Combo, CultureInfo.InvariantCulture) + float.Parse(kfdata.kf.Comboadd, CultureInfo.InvariantCulture) * (float)(kfdata.lv - 1)));
		if (num4 > 0f)
		{
			string info3 = CommonFunc.I18nGetLocalizedValue("I18N_ComboRate") + " " + num4 + "%";
			Sprite sprite3 = Resources.Load("images/07-icon/300-Combo", typeof(Sprite)) as Sprite;
			list.Add(new SkillShowInfoItem
			{
				info = info3,
				sprite = sprite3
			});
			num++;
		}
		if (kfdata.kf.Skill1 != "0")
		{
			list.Add(SkillUI(kfdata.kf.Skill1, kfdata.lv, kfdata.kf.Attckstyle.Split("|")[2], kfdata.kf.Skill1EC));
			num++;
		}
		if (kfdata.kf.Skill2 != "0")
		{
			list.Add(SkillUI(kfdata.kf.Skill2, kfdata.lv, kfdata.kf.Attckstyle.Split("|")[2], kfdata.kf.Skill2EC));
			num++;
		}
		if (kfdata.kf.Skill3 != "0")
		{
			list.Add(SkillUI(kfdata.kf.Skill3, kfdata.lv, kfdata.kf.Attckstyle.Split("|")[2], kfdata.kf.Skill3EC));
			num++;
		}
		if (kfdata.kf.Skill4 != "0")
		{
			list.Add(SkillUI(kfdata.kf.Skill4, kfdata.lv, kfdata.kf.Attckstyle.Split("|")[2], kfdata.kf.Skill4EC));
			num++;
		}
		if (kfdata.kf.Skill5 != "0")
		{
			list.Add(SkillUI(kfdata.kf.Skill5, kfdata.lv, kfdata.kf.Attckstyle.Split("|")[2], kfdata.kf.Skill5EC));
			num++;
		}
		return list;
	}

	public static SkillShowInfoItem SkillUI(string _skill, int _lv, string _AttackSelectRange, string _skillEC = "0", gang_b03Table.Row _b03Row = null)
	{
		string[] array = _skill.Split('&');
		string text = array[0];
		string[] array2 = array[1].Split('|');
		string[] array3 = array[2].Split('|');
		string[] array4 = array[3].Split('|');
		float num = float.Parse(array2[0], CultureInfo.InvariantCulture) + float.Parse(array2[1], CultureInfo.InvariantCulture) * (float)(_lv - 1);
		float num2 = Mathf.Floor(100f * (float.Parse(array3[0], CultureInfo.InvariantCulture) + float.Parse(array3[1], CultureInfo.InvariantCulture) * (float)(_lv - 1)));
		int num3 = Mathf.FloorToInt(float.Parse(array4[0], CultureInfo.InvariantCulture) + float.Parse(array4[1], CultureInfo.InvariantCulture) * (float)(_lv - 1));
		string text2 = array[4];
		string text3 = "0";
		if (array.Length == 6)
		{
			text3 = array[5];
		}
		string text4 = "";
		if (_skillEC != "0")
		{
			string[] array5 = _skillEC.Split('|');
			string text5 = array5[0];
			string[] array6 = array5[1].Split('_');
			switch (text5)
			{
			case "SELF":
				text4 += "自身";
				break;
			case "SelectTeammate":
				text4 += "选中队友";
				break;
			case "SelectEnemy":
				text4 += "选中敌人";
				break;
			case "SelectAny":
				text4 += "选中角色";
				break;
			case "AnyTeammate":
				text4 += "任意队友";
				break;
			case "AnyEnemy":
				text4 += "任意敌人";
				break;
			}
			if (array6[0] == "PARA")
			{
				gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(array6[1]);
				if (row != null)
				{
					text4 += row.NameScene_Trans;
					float num4 = float.Parse(array6[3], CultureInfo.InvariantCulture);
					if (array6[2] == ">")
					{
						text4 = text4 + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_GreaterEqual") + "</color> <color=#f0e352>" + (num4 + 1f) + "</color>";
					}
					else if (array6[2] == "<")
					{
						text4 = text4 + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_LessEqual") + "</color> <color=#f0e352>" + (num4 - 1f) + "</color>";
					}
					else if (array6[2] == "=")
					{
						text4 = text4 + "<color=red> " + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + "</color> <color=#f0e352>" + num4 + "</color>";
					}
				}
			}
			else if (array6[0] == "SEX")
			{
				text4 = text4 + " " + CommonFunc.I18nGetLocalizedValue("I18N_IS") + " ";
				if (array6[2] == "0")
				{
					text4 += CommonFunc.I18nGetLocalizedValue("I18N_Woman");
				}
				else if (array6[2] == "1")
				{
					text4 += CommonFunc.I18nGetLocalizedValue("I18N_Man");
				}
			}
			else if (array6[0] == "TRAIT")
			{
				text4 = text4 + " " + CommonFunc.I18nGetLocalizedValue("I18N_Have") + " ";
				gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(array6[2]);
				if (row2 != null)
				{
					text4 = text4 + CommonFunc.I18nGetLocalizedValue("I18N_Have") + " " + row2.name_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_Trait_1");
				}
			}
			text4 += CommonFunc.I18nGetLocalizedValue("I18N_Time_1");
		}
		string text6 = "";
		switch (text2)
		{
		case "0":
			text6 += "战斗开始时，";
			break;
		case "2":
			text6 += "行动时，";
			switch (_AttackSelectRange)
			{
			case "0":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_AttackSelectedCharacter");
				break;
			case "1":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_AttackSelectedEnemy");
				break;
			case "2":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_AttackSelectedTeammate");
				break;
			}
			switch (text3)
			{
			case "4":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_SelectedTeammate");
				break;
			case "5":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_SelectedEnemy");
				break;
			}
			break;
		case "1":
			text6 += CommonFunc.I18nGetLocalizedValue("I18N_AfterAction");
			switch (text3)
			{
			case "0":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForSelf");
				break;
			case "1":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForAllTeammate");
				break;
			case "2":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForAllEnemy");
				break;
			case "3":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForAllCharacter");
				break;
			case "4":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForSelectedTeammate");
				break;
			case "5":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForSelectedEnemy");
				break;
			case "6":
				text6 += CommonFunc.I18nGetLocalizedValue("I18N_ForSelectedCharacter");
				break;
			}
			break;
		case "-1":
			text6 += CommonFunc.I18nGetLocalizedValue("I18N_SelectedArea");
			break;
		case "-2":
			text6 = text6 ?? "";
			break;
		}
		gang_a01Table.Row row3 = CommonResourcesData.a01.Find_Name(text);
		string text7 = "";
		if (num != 0f)
		{
			float num5 = ("2".Equals(row3.Type) ? 100f : 1f);
			string text8 = ("2".Equals(row3.Type) ? "%" : "");
			text7 = ((num > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num5 * num)) + text8;
		}
		if (num.Equals(0f) && "Xisuijing".Equals(text))
		{
			text7 = num.ToString();
		}
		string text9 = "";
		string text10 = "";
		if (num3 > 0)
		{
			text10 = CommonFunc.I18nGetLocalizedValue("I18N_Last") + " " + num3 + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round");
		}
		switch (num3)
		{
		case -1:
			text10 = CommonFunc.I18nGetLocalizedValue("I18N_UntilShutdown");
			break;
		case -2:
			text10 = "";
			break;
		}
		string nameUI_Trans = row3.NameUI_Trans;
		string text11 = ((num2 >= 0f && num2 < 100f) ? (num2 + CommonFunc.I18nGetLocalizedValue("I18N_Chance") + " ") : "");
		List<string> obj = new List<string> { "DefATKup", "SpATKup", "LowHpATKup" };
		List<string> list = new List<string>
		{
			"MelodyATKup", "YinYangATKup", "MedicalATKup", "DartsATKup", "StealATKup", "STRATKup", "AGIATKup", "BONATKup", "WILATKup", "LERATKup",
			"MORATKup"
		};
		List<string> list2 = new List<string> { "LowSTRATKup", "LowAGIATKup", "LowBONATKup", "LowWILATKup", "LowLERATKup", "LowMORATKup" };
		List<string> list3 = new List<string> { "EnemySTRATKup", "EnemyAGIATKup", "EnemyBONATKup", "EnemyWILATKup", "EnemyLERATKup", "EnemyMORATKup" };
		List<string> list4 = new List<string> { "EnemyLowSTRATKup", "EnemyLowAGIATKup", "EnemyLowBONATKup", "EnemyLowWILATKup", "EnemyLowLERATKup", "EnemyLowMORATKup" };
		if (obj.Contains(text) || list.Contains(text) || list2.Contains(text) || list3.Contains(text) || list4.Contains(text))
		{
			text11 = "";
		}
		text9 = text11 + nameUI_Trans + text7 + text10;
		if ("Ironvest".Equals(text))
		{
			text9 = text11 + nameUI_Trans + text7 + CommonFunc.I18nGetLocalizedValue("I18N_Times");
		}
		else if ("CookingReward".Equals(text) || "Charm".Equals(text) || "Bribe".Equals(text))
		{
			text9 = nameUI_Trans;
		}
		else if ("Summon".Equals(text))
		{
			gang_b01Table.Row row4 = CommonResourcesData.b01.Find_ID(array2[0]);
			string text12 = "XXX";
			if (row4 != null)
			{
				text12 = row4.Name_Trans;
			}
			text9 = text11 + nameUI_Trans + text12 + text10;
		}
		else if ("Fend".Equals(text))
		{
			text9 = CommonFunc.I18nGetLocalizedValue("I18N_KnockBackChance");
		}
		else if ("Draw".Equals(text))
		{
			text9 = CommonFunc.I18nGetLocalizedValue("I18N_PullChance");
		}
		else if ("Impact".Equals(text))
		{
			text9 = text11 + nameUI_Trans;
		}
		else if (text.Contains("Terrain"))
		{
			text9 = text11 + nameUI_Trans;
		}
		else if ("RoleAssist".Equals(text))
		{
			text9 = CommonResourcesData.b01.Find_ID(array2[0]).Name_Trans + text11 + nameUI_Trans;
		}
		else if ("WugongAssist".Equals(text))
		{
			gang_b03Table.Row row5 = CommonResourcesData.b03.Find_ID(array2[0]);
			text9 = " " + CommonFunc.I18nGetLocalizedValue("I18N_Have") + " " + row5.Name_Trans + CommonFunc.I18nGetLocalizedValue("I18N_KongFuCharacter") + text11 + nameUI_Trans;
		}
		else if ("Counter".Equals(text))
		{
			text6 = CommonFunc.I18nGetLocalizedValue("I18N_BeAttacked");
		}
		else if ("Gather".Equals(text))
		{
			text6 = "";
		}
		else if ("LowHpATKup".Equals(text) || "SpATKup".Equals(text))
		{
			text9 = text11 + nameUI_Trans + text10;
		}
		else if ("StealATK".Equals(text))
		{
			text9 = text11 + nameUI_Trans + text10;
		}
		else if ("Xisuijing".Equals(text) || "Yijinjing".Equals(text))
		{
			text9 = text9.Replace("+", "");
		}
		else if ("SwapPos".Equals(text))
		{
			text6 = "";
			text9 = text11 + nameUI_Trans + text10;
		}
		Sprite sprite = Resources.Load("images/07-icon/300-" + text, typeof(Sprite)) as Sprite;
		if (sprite == null)
		{
			sprite = Resources.Load("images/07-icon/300-Common", typeof(Sprite)) as Sprite;
		}
		text4 = "";
		text6 = "";
		return new SkillShowInfoItem
		{
			skillInfoType = SkillInfoType.Skill,
			info = text4 + text6 + text9,
			sprite = sprite
		};
	}

	public static string AddUI(string _add, string _Attribute)
	{
		string result = "";
		if (_add != "0" && SharedData.Instance().m_A01NameRowDirec.ContainsKey(_add))
		{
			gang_a01Table.Row row = CommonResourcesData.a01.Find_Name(_add);
			string text = "";
			text = ((!(row.Type == "2")) ? _Attribute : ((Mathf.Round(100f * float.Parse(_Attribute, CultureInfo.InvariantCulture) * 100f) / 100f).ToString("0.##") + "%"));
			result = (("Drunk".Equals(_add) || "Hurt".Equals(_add) || "Poison".Equals(_add) || "Bleed".Equals(_add) || "Burn".Equals(_add) || "Seal".Equals(_add) || "Mad".Equals(_add)) ? ((text[0] != '-') ? ("·" + row.NameScene_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist_2") + " <color=red>-" + text + "</color>") : ("·" + row.NameScene_Trans + " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist_2") + " <color=green>+" + text.Substring(1) + "</color>")) : ((text[0] != '-') ? ("·" + row.NameScene_Trans + " <color=green>+" + text + "</color>") : ("·" + row.NameScene_Trans + " <color=red>" + text + "</color>")));
		}
		return result;
	}

	public static void SetHoverWugongItem(CharaData charadata, KongFuData kfdata, Transform hoverWugongObj, bool showCharacterIcon = false, gang_b03Table.Row _originB03Row = null)
	{
		if (showCharacterIcon)
		{
			hoverWugongObj.Find("SelcetTeammate").gameObject.SetActive(value: true);
			hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG").gameObject.SetActive(value: true);
			Sprite tachieHead = CommonResourcesData.GetTachieHead(charadata.m_BattleIcon);
			if (tachieHead == null)
			{
				hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: false);
				hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
				hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charadata);
			}
			else
			{
				hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG/Icon").gameObject.SetActive(value: true);
				hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
				hoverWugongObj.Find("SelcetTeammate/IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
			}
		}
		hoverWugongObj.Find("Name/Name").GetComponent<Text>().text = kfdata.kf.Name_Trans;
		hoverWugongObj.Find("Name/Style/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + kfdata.kf.Icon, typeof(Sprite)) as Sprite;
		if (kfdata.kf.Star.Equals("10"))
		{
			hoverWugongObj.Find("BG").GetComponent<Image>().sprite = Resources.Load("images/01-border/kongfu-20231229-07", typeof(Sprite)) as Sprite;
		}
		else
		{
			hoverWugongObj.Find("BG").GetComponent<Image>().sprite = Resources.Load("images/01-border/kongfu-20231229-05", typeof(Sprite)) as Sprite;
		}
		Transform transform = hoverWugongObj.Find("Area1");
		Transform transform2 = hoverWugongObj.Find("Area2");
		if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_PackageController.isShop)
		{
			transform = hoverWugongObj.Find("ScrollView/Viewport/Content/Area1");
			transform2 = hoverWugongObj.Find("ScrollView/Viewport/Content/Area2");
		}
		for (int j = 1; j <= 10; j++)
		{
			Transform transform3 = transform.Find("Stars/Stars" + j);
			if (j <= int.Parse(kfdata.kf.Star))
			{
				transform3.gameObject.SetActive(value: true);
			}
			else
			{
				transform3.gameObject.SetActive(value: false);
			}
			if (_originB03Row != null && !(j <= int.Parse(kfdata.kf.Star)).Equals(j <= int.Parse(_originB03Row.Star)))
			{
				transform3.GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
		}
		transform.Find("Lv").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Lv") + kfdata.lv + "<size=25><color=#918574>/" + kfdata.kf.LV + "</color></size>";
		if (_originB03Row != null && !(CommonFunc.I18nGetLocalizedValue("I18N_Lv") + _originB03Row.LV + "<size=25><color=#918574>/" + _originB03Row.LV + "</color></size>").Equals(transform.Find("Lv").GetComponent<Text>().text))
		{
			transform.Find("Lv").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
		}
		transform.Find("icon1/Image").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(kfdata.kf.BookIcon);
		switch (kfdata.kf.Origin)
		{
		case "0":
			transform.Find("icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-createwugong", typeof(Sprite)) as Sprite;
			transform.Find("OriginName").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_CreatWugong");
			break;
		case "1":
			transform.Find("icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-fo", typeof(Sprite)) as Sprite;
			transform.Find("OriginName").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_BuddhismWugong");
			break;
		case "2":
			transform.Find("icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-dao", typeof(Sprite)) as Sprite;
			transform.Find("OriginName").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_TaoistWugong");
			break;
		case "3":
			transform.Find("icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-ru", typeof(Sprite)) as Sprite;
			transform.Find("OriginName").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_ConfucianistWugong");
			break;
		case "4":
			transform.Find("icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-xie", typeof(Sprite)) as Sprite;
			transform.Find("OriginName").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_HeresyWugong");
			break;
		case "5":
			transform.Find("icon2/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/wugong-20231229-za", typeof(Sprite)) as Sprite;
			transform.Find("OriginName").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_JiangHuWugong");
			break;
		}
		if (_originB03Row != null && !_originB03Row.Origin.Equals(kfdata.kf.Origin))
		{
			transform.Find("icon2/Image").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			transform.Find("OriginName").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
		}
		string wugongStyle = CommonFunc.GetWugongStyle(kfdata.kf.Style);
		transform.Find("StyleName").GetComponent<Text>().text = wugongStyle;
		float obj = Mathf.Floor(float.Parse(kfdata.kf.Damage, CultureInfo.InvariantCulture) + float.Parse(kfdata.kf.Damageadd, CultureInfo.InvariantCulture) * (float)(kfdata.lv - 1));
		transform.Find("Status/Power/Num").GetComponent<Text>().text = obj.ToString() ?? "";
		float obj2 = Mathf.Floor(float.Parse(kfdata.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(kfdata.kf.Expendadd, CultureInfo.InvariantCulture) * (float)(kfdata.lv - 1));
		transform.Find("Status/Expend/Num").GetComponent<Text>().text = obj2.ToString() ?? "";
		if (_originB03Row != null)
		{
			if (!Mathf.Floor(float.Parse(_originB03Row.Damage, CultureInfo.InvariantCulture) + float.Parse(_originB03Row.Damageadd, CultureInfo.InvariantCulture) * (float)(int.Parse(_originB03Row.LV) - 1)).Equals(obj))
			{
				transform.Find("Status/Power").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
			if (!Mathf.Floor(float.Parse(_originB03Row.Expend, CultureInfo.InvariantCulture) + float.Parse(_originB03Row.Expendadd, CultureInfo.InvariantCulture) * (float)(int.Parse(_originB03Row.LV) - 1)).Equals(obj2))
			{
				transform.Find("Status/Expend").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
		}
		bool flag = false;
		if (charadata != null)
		{
			foreach (KongFuData kongFu in charadata.m_KongFuList)
			{
				if (kongFu.kf.ID.Equals(kfdata.kf.ID))
				{
					flag = true;
					break;
				}
			}
		}
		List<string> list = new List<string>
		{
			kfdata.kf.Limit1,
			kfdata.kf.Limit2
		};
		for (int k = 0; k < list.Count; k++)
		{
			if (list[k] != "0")
			{
				string[] array = list[k].Split('|');
				bool flag2 = false;
				bool flag3 = false;
				if ("@".Equals(array[0]))
				{
					if ("TRAIT".Equals(array[1]))
					{
						string text = CommonFunc.I18nGetLocalizedValue("I18N_Trait_2");
						string text2 = "";
						gang_b06Table.Row row = null;
						string[] array2 = array[2].Split('_');
						foreach (string text3 in array2)
						{
							row = CommonResourcesData.b06.Find_id(text3);
							if (row != null)
							{
								flag3 = charadata?.m_TraitList.Contains(text3) ?? false;
							}
							else
							{
								Debug.LogWarning("!>>> " + text3 + " NOT in table B06.");
							}
							if (flag3)
							{
								break;
							}
						}
						row = CommonResourcesData.b06.Find_id(array[2].Split('_')[0]);
						text2 = ((!flag3) ? "<color=red>" : "") + row.name_Trans + ((!flag3) ? "</color>" : "");
						transform.Find("Limit/Limit-0" + (k + 1) + "/Text").GetComponent<Text>().text = text + " " + text2;
					}
					else if ("ROLE".Equals(array[1]))
					{
						string text4 = CommonFunc.I18nGetLocalizedValue("I18N_Chara");
						string text5 = "";
						gang_b10Table.Row row2 = CommonResourcesData.b10.Find_ID(array[2]);
						if (row2 != null)
						{
							List<string> list2 = new List<string>(row2.Members.Split('|'));
							string item = "";
							if (charadata != null)
							{
								item = charadata.m_Id.Split('_')[0];
							}
							flag2 = charadata != null && !list2.Contains(item);
							text5 = (flag2 ? "<color=red>" : "") + row2.Name_Trans + (flag2 ? "</color>" : "");
						}
						else
						{
							Debug.LogWarning("!>>> " + array[2] + " NOT in table B10.");
						}
						transform.Find("Limit/Limit-0" + (k + 1) + "/Text").GetComponent<Text>().text = text4 + " " + text5;
					}
					else
					{
						Debug.LogWarning("!>>> Can NOT deal with PARA[" + array[1] + "].");
					}
				}
				else
				{
					string nameUI_Trans = CommonResourcesData.a01.Find_Name(array[0]).NameUI_Trans;
					string text6 = "";
					if (!flag)
					{
						float num = charadata?.GetFieldValueByName(array[0]) ?? 0f;
						float num2 = float.Parse(array[2], CultureInfo.InvariantCulture);
						flag2 = ((array[1] == "1") ? (num < num2) : ((!(array[1] == "2")) ? (num != num2) : (num > num2)));
						flag2 = charadata != null && flag2;
					}
					string text7 = array[1];
					text6 = ((text7 == "1") ? ((flag2 ? "<color=red>" : "") + CommonFunc.I18nGetLocalizedValue("I18N_Greater") + " " + array[2] + (flag2 ? "</color>" : "")) : ((!(text7 == "2")) ? ((flag2 ? "<color=red>" : "") + CommonFunc.I18nGetLocalizedValue("I18N_Equal") + " " + array[2] + (flag2 ? "</color>" : "")) : ((flag2 ? "<color=red>" : "") + CommonFunc.I18nGetLocalizedValue("I18N_NoGreater") + " " + array[2] + (flag2 ? "</color>" : ""))));
					transform.Find("Limit/Limit-0" + (k + 1) + "/Text").GetComponent<Text>().text = nameUI_Trans + " " + text6;
				}
			}
			else
			{
				transform.Find("Limit/Limit-0" + (k + 1) + "/Text").GetComponent<Text>().text = "";
			}
		}
		if (_originB03Row != null)
		{
			List<string> list3 = new List<string> { _originB03Row.Limit1, _originB03Row.Limit2 };
			for (int m = 0; m < list.Count; m++)
			{
				if (!list[m].Equals(list3[m]))
				{
					transform.Find("Limit/Limit-0" + (m + 1)).GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
				}
			}
		}
		List<string> list4 = new List<string>
		{
			kfdata.kf.Paraplus1,
			kfdata.kf.Paraplus2,
			kfdata.kf.Paraplus3,
			kfdata.kf.Paraplus4
		};
		for (int n = 0; n < list4.Count; n++)
		{
			if (list4[n] != "0")
			{
				string[] array3 = list4[n].Split('|');
				gang_a01Table.Row row3 = CommonResourcesData.a01.Find_Name(array3[0]);
				string text8 = "";
				text8 = ((!(row3.Type == "2")) ? array3[1] : ((Mathf.Round(100f * float.Parse(array3[1], CultureInfo.InvariantCulture) * 100f) / 100f).ToString("0.##") + "%"));
				transform.Find("Status-add/Status-add-0" + (n + 1) + "/Text").GetComponent<Text>().text = row3.NameScene_Trans;
				transform.Find("Status-add/Status-add-0" + (n + 1) + "/Num").GetComponent<Text>().text = "<color=#FBF2D9>" + text8 + "</color>";
			}
			else
			{
				transform.Find("Status-add/Status-add-0" + (n + 1) + "/Text").GetComponent<Text>().text = "";
				transform.Find("Status-add/Status-add-0" + (n + 1) + "/Num").GetComponent<Text>().text = "";
			}
		}
		if (_originB03Row != null)
		{
			List<string> list5 = new List<string> { _originB03Row.Paraplus1, _originB03Row.Paraplus2, _originB03Row.Paraplus3, _originB03Row.Paraplus4 };
			for (int num3 = 0; num3 < list4.Count; num3++)
			{
				if (!list4[num3].Equals(list5[num3]))
				{
					transform.Find("Status-add/Status-add-0" + (num3 + 1)).GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
				}
			}
		}
		string[] array4 = kfdata.kf.Attckstyle.Split('|');
		string text9 = array4[0] + array4[1];
		int num4 = int.Parse(kfdata.kf.Range);
		if ("C01".Equals(text9) && num4 > 1)
		{
			text9 += "-1";
		}
		transform2.Find("Range/Title/Text").GetComponent<Text>().text = ((kfdata.kf.Range == "1") ? CommonFunc.I18nGetLocalizedValue("I18N_UnitAttack") : CommonFunc.I18nGetLocalizedValue("I18N_AreaOfEffect"));
		transform2.Find("Range/Range-icon/Image").GetComponent<Image>().sprite = Resources.Load("images/07-icon/" + text9, typeof(Sprite)) as Sprite;
		transform2.Find("Range/SelectDis/Num").GetComponent<Text>().text = kfdata.kf.Area;
		transform2.Find("Range/AtkDis/Num").GetComponent<Text>().text = kfdata.kf.Range;
		transform2.Find("Range/SpaceDis/Num").GetComponent<Text>().text = kfdata.kf.Space;
		transform2.Find("Range/AddDamage/Num").GetComponent<Text>().text = ((kfdata.kf.Decreaserate != "0") ? CommonFunc.I18nGetLocalizedValue("I18N_True") : CommonFunc.I18nGetLocalizedValue("I18N_False"));
		if (_originB03Row != null)
		{
			if (transform2.Find("Range/SelectDis/Num").GetComponent<Text>().text != _originB03Row.Area)
			{
				transform2.Find("Range/SelectDis").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
			if (transform2.Find("Range/AtkDis/Num").GetComponent<Text>().text != _originB03Row.Range)
			{
				transform2.Find("Range/AtkDis").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
			if (transform2.Find("Range/SpaceDis/Num").GetComponent<Text>().text != _originB03Row.Space)
			{
				transform2.Find("Range/SpaceDis").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
			if (transform2.Find("Range/AddDamage/Num").GetComponent<Text>().text != ((_originB03Row.Decreaserate != "0") ? CommonFunc.I18nGetLocalizedValue("I18N_True") : CommonFunc.I18nGetLocalizedValue("I18N_False")))
			{
				transform2.Find("Range/AddDamage").GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
			}
		}
		List<SkillShowInfoItem> skillShowInfo = GetSkillShowInfo(kfdata);
		ScrollRect scrollRect = transform2.Find("Skill/ScrollView").GetComponent<ScrollRect>();
		new Dictionary<string, Transform>();
		int i = scrollRect.content.childCount - 1;
		while (i >= 0)
		{
			SkillShowInfoItem skillShowInfoItem = skillShowInfo.Find((SkillShowInfoItem x) => x.info.Equals(scrollRect.content.GetChild(i).Find("Text").GetComponent<Text>()
				.text));
				if (skillShowInfoItem != null)
				{
					skillShowInfo.Remove(skillShowInfoItem);
				}
				else
				{
					Object.DestroyImmediate(scrollRect.content.GetChild(i).gameObject);
				}
				int l = i - 1;
				i = l;
			}
			GameObject original = Resources.Load("Prefabs/NewUI/SkillItem") as GameObject;
			for (int num5 = 0; num5 < skillShowInfo.Count; num5++)
			{
				GameObject gameObject = Object.Instantiate(original, scrollRect.content);
				gameObject.transform.Find("Icon").GetComponent<Image>().sprite = skillShowInfo[num5].sprite;
				if (SharedData.Instance().m_PackageController.isOpen && SharedData.Instance().m_PackageController.isShop)
				{
					gameObject.transform.Find("Text").GetComponent<ContentSizeFitter>().enabled = false;
					gameObject.transform.Find("Text").GetComponent<Text>().text = skillShowInfo[num5].info;
					gameObject.transform.Find("Text").GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, scrollRect.content.rect.width - 80f);
				}
				else
				{
					gameObject.transform.Find("Text").GetComponent<Text>().text = skillShowInfo[num5].info;
					gameObject.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, gameObject.transform.Find("Text").GetComponent<Text>().preferredWidth + 150f);
				}
				if (_originB03Row != null)
				{
					gameObject.GetComponentInChildren<SkeletonGraphic>().AnimationState.SetAnimation(0, "animation", loop: false);
				}
			}
		}
	}
