using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Starter4Controller : MonoBehaviour
{
	private Color btn_txt_down = new Color(1f, 1f, 0.925f, 0.3f);

	private Color btn_txt_common = new Color(1f, 1f, 0.925f, 1f);

	private Color btn_txt_down1 = new Color(0.412f, 0.376f, 0.325f, 0.3f);

	private Color btn_txt_common1 = new Color(0.412f, 0.376f, 0.325f, 1f);

	private string point_btn = "";

	private Sprite btn_img_normal;

	private Sprite btn_img_selected;

	private Transform modeBtn;

	private Transform modeInfoPanel;

	private List<Transform> modeList = new List<Transform>();

	private List<Transform> modeInfoPanelList = new List<Transform>();

	private Transform next_btn;

	private Transform prev_btn;

	private void Start()
	{
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>();
		foreach (Button obj in componentsInChildren)
		{
			EventTriggerListener.Get(obj.gameObject).onUp = OnButtonUp;
			EventTriggerListener.Get(obj.gameObject).onExit = OnButtonExit;
			EventTriggerListener.Get(obj.gameObject).onDown = OnButtonDown;
		}
		btn_img_normal = Resources.Load("images/01-border/boder-20231228-06", typeof(Sprite)) as Sprite;
		btn_img_selected = Resources.Load("images/01-border/boder-20231228-07", typeof(Sprite)) as Sprite;
		modeBtn = base.transform.Find("Panel/ModeSelect");
		modeInfoPanel = base.transform.Find("Panel/ModeInfo");
		for (int j = 0; j < modeBtn.childCount; j++)
		{
			modeList.Add(modeBtn.GetChild(j));
		}
		for (int k = 0; k < modeInfoPanel.childCount; k++)
		{
			modeInfoPanelList.Add(modeInfoPanel.GetChild(k));
		}
		next_btn = base.transform.Find("Panel/Next");
		prev_btn = base.transform.Find("Panel/Return");
		if (SharedData.Instance().m_Game_Mode == 1)
		{
			OnButtonDown(modeList[SharedData.Instance().m_Game_Mode - 1].gameObject);
			EventSystem.current.SetSelectedGameObject(modeList[SharedData.Instance().m_Game_Mode - 1].gameObject);
		}
		else if (SharedData.Instance().m_Game_Mode == 2)
		{
			OnButtonDown(modeList[SharedData.Instance().m_Game_Mode - 1].gameObject);
			EventSystem.current.SetSelectedGameObject(modeList[SharedData.Instance().m_Game_Mode - 1].gameObject);
		}
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(next_btn.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(prev_btn.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	public void OnButtonDown(GameObject go)
	{
		if (!go.GetComponent<Button>().interactable)
		{
			return;
		}
		if (go.name.StartsWith("Mode"))
		{
			for (int i = 0; i < modeList.Count; i++)
			{
				if (i < 2)
				{
					modeList[i].GetComponent<Image>().sprite = btn_img_normal;
				}
				modeInfoPanelList[i].gameObject.SetActive(value: false);
			}
			go.GetComponent<Image>().sprite = btn_img_selected;
			int num = int.Parse(go.name.Replace("Mode", ""));
			SharedData.Instance().SetGameMode(num);
			modeInfoPanelList[num - 1].gameObject.SetActive(value: true);
		}
		else if (go.name == "Next")
		{
			go.transform.Find("Text").GetComponent<Text>().color = btn_txt_down;
		}
		else if (go.name == "Return")
		{
			go.transform.Find("Text").GetComponent<Text>().color = btn_txt_down1;
		}
		point_btn = go.name;
	}

	public void OnButtonUp(GameObject go)
	{
		if (!go.GetComponent<Button>().interactable)
		{
			return;
		}
		if (go.name == point_btn)
		{
			if (go.name == "Next")
			{
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common;
				SharedData.Instance().ASyncLoadScene("Starter1");
			}
			else if (go.name == "Return")
			{
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common1;
				SharedData.Instance().ASyncLoadScene("Title");
			}
		}
		point_btn = "";
	}

	public void OnButtonExit(GameObject go)
	{
		if (go.name == point_btn)
		{
			if (go.name == "Next")
			{
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common;
			}
			else if (go.name == "Return")
			{
				go.transform.Find("Text").GetComponent<Text>().color = btn_txt_common1;
			}
		}
		point_btn = "";
	}
}
