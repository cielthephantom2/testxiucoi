using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

public class EventSkipper
{
	private static EventSkipper instance;

	private Dictionary<string, List<string>> flagList = new Dictionary<string, List<string>>();

	private string m_dest = "";

	private List<string> checkpoints = new List<string>();

	private Dictionary<string, string> mirrorList = new Dictionary<string, string>();

	public Dictionary<string, string> Event2Map = new Dictionary<string, string>();

	public int m_E02Error;

	public int m_EventLostAndFound;

	private List<string> m_event_queue = new List<string>();

	public Dictionary<string, string> flag2hint = new Dictionary<string, string>();

	public static EventSkipper Instance()
	{
		if (instance == null)
		{
			instance = null;
			instance = new EventSkipper();
			instance.Init();
		}
		return instance;
	}

	private void Init()
	{
		event2mapTable obj = new event2mapTable();
		obj.Load(Resources.Load<TextAsset>("Datas/event2map"));
		foreach (event2mapTable.Row row in obj.GetRowList())
		{
			Event2Map.Add(row.eventid, row.mapid);
		}
		PrepareDatas();
	}

	private void E02DataIntegrityCheck()
	{
		int num = 2;
		foreach (gang_e02Table.Row row in CommonResourcesData.e02.GetRowList())
		{
			if (!"*#06#".Equals(row.check1))
			{
				Debug.LogWarning("[E02-check1][line-" + num + "][" + row.chatid + "].");
				m_E02Error++;
			}
			else if (!"*#06#".Equals(row.check2))
			{
				Debug.LogWarning("[E02-check2][line-" + num + "][" + row.chatid + "].");
				m_E02Error++;
			}
			num++;
		}
		Debug.LogWarning("[DEBUG] E02 check errcount = " + m_E02Error);
	}

	private void EventLostAndFound()
	{
		foreach (string key in Event2Map.Keys)
		{
			List<gang_e01Table.Row> list = CommonResourcesData.e01.FindAll_eventid(key);
			if (list == null || list.Count == 0 || !"FOLLOW".Equals(list[0].trigger))
			{
				continue;
			}
			bool flag = false;
			foreach (gang_e01Table.Row item in list)
			{
				if (!"1".Equals(item.online))
				{
					continue;
				}
				foreach (KeyValuePair<string, List<string>> flag2 in flagList)
				{
					if (flag2.Value.Contains(item.flag) && !CommonResourcesData.e01.Find_flag(flag2.Key).eventid.Equals(key))
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					break;
				}
			}
			if (!flag)
			{
				m_EventLostAndFound++;
				Debug.LogWarning("[ ! ] ====> Event[" + key + "] on MAP[" + Event2Map[key] + "] NOT actived, check it out.");
			}
		}
	}

	private void GenerateBigBangList()
	{
		string text = "eventid,nextflags,hints\n";
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		List<string> list3 = new List<string>();
		foreach (string key in Event2Map.Keys)
		{
			if (!SharedData.Instance().EventTable.ContainsKey(key))
			{
				Debug.LogWarning("[!!] =========> EventID[" + key + "] NOT exist in EventTable!");
				continue;
			}
			List<gang_e01Table.Row> list4 = SharedData.Instance().EventTable[key];
			if (list4 == null || list4.Count == 0)
			{
				continue;
			}
			list.Clear();
			list2.Clear();
			foreach (gang_e01Table.Row item2 in list4)
			{
				if (!"1".Equals(item2.online) || "AUTO".Equals(item2.trigger))
				{
					continue;
				}
				string[] array = item2.nextflag.Split('|');
				foreach (string text2 in array)
				{
					if (!"".Equals(text2))
					{
						gang_e01Table.Row row = CommonResourcesData.e01.Find_flag(text2);
						if (row == null)
						{
							Debug.LogWarning("[!] =========> NextFlag[" + text2 + "] NOT exist in E01!");
						}
						else if ("1".Equals(row.online) && Event2Map.ContainsKey(row.eventid) && SharedData.Instance().EventTable.ContainsKey(row.eventid) && !row.eventid.Equals(key) && !Event2Map[row.eventid].Equals(Event2Map[key]) && !list.Contains(text2))
						{
							list.Add(text2);
						}
					}
				}
				string[] array2 = item2.action.Split('|');
				if (!"CHAT".Equals(array2[0]))
				{
					continue;
				}
				List<gang_e02Table.Row> list5 = CommonResourcesData.e02.FindAll_chatid(array2[1]);
				if (list5 == null || list5.Count <= 0)
				{
					continue;
				}
				list3.Clear();
				foreach (gang_e02Table.Row item3 in list5)
				{
					if ("0".Equals(item3.rumourid))
					{
						continue;
					}
					gang_f01Table.Row row2 = CommonResourcesData.f01.Find_openflag(item3.rumourid);
					if (row2 != null)
					{
						string item = row2.openflag + ":" + row2.note_Trans;
						if (!list2.Contains(item))
						{
							list2.Add(item);
						}
						if (!list3.Contains(item))
						{
							list3.Add(item);
						}
					}
				}
				if (list3.Count <= 0)
				{
					continue;
				}
				string text3 = "";
				foreach (string item4 in list3)
				{
					text3 = text3 + ((text3.Length == 0) ? "" : "|") + item4;
				}
				flag2hint.Add(item2.flag, text3);
			}
			string text4 = "";
			foreach (string item5 in list)
			{
				text4 = text4 + ((text4.Length == 0) ? "" : "|") + item5;
			}
			string text5 = "";
			foreach (string item6 in list2)
			{
				text5 = text5 + ((text5.Length == 0) ? "" : "|") + item6;
			}
			if (text4.Length + text5.Length > 0)
			{
				text = text + key + "," + text4 + "," + text5 + "\n";
			}
		}
		string text6 = Application.dataPath + "/Resources/Datas/bigbang.csv";
		Debug.Log("Write BigBang Data file: " + text6);
		File.WriteAllText(text6, text);
	}

	private void PrepareDatas()
	{
		foreach (List<string> value in flagList.Values)
		{
			value.Clear();
		}
		flagList.Clear();
		mirrorList.Clear();
		List<string> list = new List<string>();
		list.AddRange(SharedData.Instance().FlagList.Keys);
		foreach (string item in list)
		{
			gang_e01Table.Row row = CommonResourcesData.e01.Find_flag(item);
			if (row == null)
			{
				Debug.LogWarning("Can NOT find flag: " + item);
				continue;
			}
			string[] array = row.action.Split('|');
			List<string> list2 = new List<string>();
			if ("CHECK".Equals(array[0]))
			{
				string text = item + "_TRUE";
				if (list.Contains(text))
				{
					mirrorList.Add(text, item);
				}
				text = item + "_FALSE";
				if (list.Contains(text))
				{
					mirrorList.Add(text, item);
				}
			}
			else if ("SELECT".Equals(array[0]))
			{
				string[] array2 = array[1].Split('&');
				if (array2.Length != 0)
				{
					for (int i = 1; i <= array2.Length; i++)
					{
						string text2 = item + "_" + i;
						if (list.Contains(text2))
						{
							mirrorList.Add(text2, item);
						}
					}
				}
			}
			else if ("BATTLE".Equals(array[0]))
			{
				string text3 = item + "_WIN";
				if (list.Contains(text3))
				{
					mirrorList.Add(text3, item);
				}
				text3 = item + "_LOSE";
				if (list.Contains(text3))
				{
					mirrorList.Add(text3, item);
				}
			}
			else if ("SWITCH".Equals(array[0]))
			{
				string[] array3 = array[1].Split('+');
				if (array3.Length != 0)
				{
					for (int j = 1; j <= array3.Length + 1; j++)
					{
						string text4 = item + "_" + j;
						if (list.Contains(text4))
						{
							mirrorList.Add(text4, item);
						}
					}
				}
			}
			else if ("FLAG".Equals(array[0]))
			{
				if ("OPEN".Equals(array[1]))
				{
					list2.Add(array[2]);
				}
			}
			else if ("PLAYCG".Equals(array[0]))
			{
				string text5 = item + "_COMPLETE";
				if (list.Contains(text5))
				{
					mirrorList.Add(text5, item);
				}
			}
			string[] array4 = row.nextflag.Split('|');
			foreach (string text6 in array4)
			{
				if (!text6.Equals(row.eventid))
				{
					list2.Add(text6);
				}
			}
			if (list2.Count > 0)
			{
				flagList.Add(item, list2);
			}
		}
	}

	public void PrepareAndRun(string _dest, string _checkpoints)
	{
		PrepareDatas();
		m_event_queue.Clear();
		m_dest = _dest;
		checkpoints.Clear();
		string[] collection = _checkpoints.Split('&');
		checkpoints.AddRange(collection);
		SharedData.Instance().FlagList[m_dest] = 1;
		Debug.LogWarning("=== Rewind() START at: " + m_dest);
		Rewind(m_dest);
	}

	private void Rewind(string _current)
	{
		string text = "";
		foreach (KeyValuePair<string, List<string>> flag in flagList)
		{
			if (flag.Value.Contains(_current) && !m_event_queue.Contains(flag.Key))
			{
				text = flag.Key;
				break;
			}
		}
		if ("".Equals(text) && mirrorList.ContainsKey(_current))
		{
			text = mirrorList[_current];
		}
		if (!"".Equals(text))
		{
			if (SharedData.Instance().FlagList[text] != 2)
			{
				Debug.LogWarning("....--> m_event_queue Add: [" + text + "]");
				m_event_queue.Add(text);
				Rewind(text);
			}
			else
			{
				Debug.LogWarning("=== Rewind() Interupted at: " + _current + ", prev: " + text);
				LeapActionQueue();
			}
		}
		else
		{
			Debug.LogWarning("=== Rewind() END at: " + _current);
			LeapActionQueue();
		}
	}

	private void LeapActionQueue()
	{
		Debug.LogWarning("");
		Debug.LogWarning("=== LeapActionQueue() START, queue size: " + m_event_queue.Count);
		m_event_queue.Reverse();
		List<string> list = new List<string>();
		foreach (string item in m_event_queue)
		{
			gang_e01Table.Row row = CommonResourcesData.e01.Find_flag(item);
			string[] array = row.action.Split('|');
			if ("GET".Equals(array[0]))
			{
				GetMethod(array);
			}
			else if ("EVENT".Equals(array[0]))
			{
				EventMethod(array, list);
			}
			else if ("FLAG".Equals(array[0]))
			{
				if (array[1] == "INIT")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]] = 0;
					}
				}
				else if (array[1] == "CLOSE")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]] = 2;
					}
				}
				else if (array[1] == "SET")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]] = int.Parse(array[3]);
					}
				}
				else if (array[1] == "ADD")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]]++;
					}
				}
				else if (array[1] == "SUB" && SharedData.Instance().FlagList.ContainsKey(array[2]))
				{
					SharedData.Instance().FlagList[array[2]]--;
				}
			}
			string[] array2 = row.nextflag.Split('|');
			foreach (string text in array2)
			{
				if (!m_event_queue.Contains(text) && !list.Contains(text))
				{
					gang_e01Table.Row row2 = CommonResourcesData.e01.Find_flag(text);
					if (row2 != null && Event2Map[row.eventid].Equals(Event2Map[row2.eventid]))
					{
						list.Add(text);
					}
					SharedData.Instance().FlagList[text] = 1;
				}
			}
			if ("END".Equals(row.output))
			{
				EventFlowEnd(row.eventid);
			}
			else
			{
				SharedData.Instance().FlagList[item] = 2;
			}
		}
		Debug.LogWarning("=== LeapActionQueue() END.");
		if (list.Count > 0)
		{
			Debug.LogWarning("");
			Debug.LogWarning("=== RollSnowball() START, snowball size: " + list.Count);
			RollSnowball(list);
		}
	}

	private void RollSnowball(List<string> _snowball)
	{
		Debug.LogWarning("....--> In call, snowball size: " + _snowball.Count);
		string text = _snowball[0];
		_snowball.RemoveAt(0);
		List<string> list = new List<string>();
		list.AddRange(_snowball);
		do
		{
			Debug.LogWarning("....--> currentflag: [" + text + "]");
			if (text.Equals(m_dest))
			{
				Debug.LogWarning("....--> Meet m_dest[" + m_dest + "], skip this call, snowball size: " + _snowball.Count);
				text = "";
				continue;
			}
			gang_e01Table.Row row = CommonResourcesData.e01.Find_flag(text);
			if (row == null)
			{
				Debug.LogWarning("....--> currentflag: [" + text + "] NOT in E01.");
				text = "";
				continue;
			}
			if ("END".Equals(row.output))
			{
				EventFlowEnd(row.eventid);
			}
			else
			{
				SharedData.Instance().FlagList[text] = 2;
			}
			text = "";
			string[] array = row.action.Split('|');
			string[] array3;
			if ("GET".Equals(array[0]))
			{
				GetMethod(array);
			}
			else if ("EVENT".Equals(array[0]))
			{
				EventMethod(array, null);
			}
			else if ("FLAG".Equals(array[0]))
			{
				if (array[1] == "INIT")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]] = 0;
					}
				}
				else if (array[1] == "OPEN")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						list.Add(array[2]);
						SharedData.Instance().FlagList[array[2]] = 1;
					}
				}
				else if (array[1] == "CLOSE")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]] = 2;
					}
				}
				else if (array[1] == "SET")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]] = int.Parse(array[3]);
					}
				}
				else if (array[1] == "ADD")
				{
					if (SharedData.Instance().FlagList.ContainsKey(array[2]))
					{
						SharedData.Instance().FlagList[array[2]]++;
					}
				}
				else if (array[1] == "SUB" && SharedData.Instance().FlagList.ContainsKey(array[2]))
				{
					SharedData.Instance().FlagList[array[2]]--;
				}
			}
			else if ("CHECK".Equals(array[0]))
			{
				bool flag = false;
				int num = 2;
				if (array[1].StartsWith("FLAGS") && array.Length == 4)
				{
					num = int.Parse(array[3]);
				}
				if (array[1] == "FLAGS")
				{
					string[] array2 = array[2].Split('+');
					flag = true;
					array3 = array2;
					foreach (string key in array3)
					{
						if (SharedData.Instance().FlagList[key] != num)
						{
							flag = false;
							break;
						}
					}
				}
				else if (array[1] == "FLAGSOR")
				{
					string[] array4 = array[2].Split('+');
					flag = false;
					array3 = array4;
					foreach (string key2 in array3)
					{
						if (SharedData.Instance().FlagList[key2] == num)
						{
							flag = true;
							break;
						}
					}
				}
				else if (array[1] == "LANG")
				{
					flag = array[2].Equals(GameDataManager.Instance().configdata.language);
				}
				else if (array[1] == "RANDOM")
				{
					flag = Random.Range(0f, 1f) < float.Parse(array[2], CultureInfo.InvariantCulture);
				}
				else if (array[1] == "GAMEMODE")
				{
					flag = SharedData.Instance().m_Game_Mode == int.Parse(array[2], CultureInfo.InvariantCulture);
				}
				else if (array[1] == "RANKOVER")
				{
					flag = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_Ranking >= int.Parse(array[2]);
				}
				else if (array[1] == "BORNID")
				{
					flag = array[2].Equals(SharedData.Instance().BornID);
				}
				else if (array[1] == "SEX")
				{
					string value = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).GetFieldValueByName("Sex")
						.ToString();
					flag = array[2].Equals(value);
				}
				else if (array[1] == "INHERIT")
				{
					flag = GameDataManager.Instance().configdata.inheritItems.Length > 0;
				}
				else if (array[1] == "KONGFU")
				{
					foreach (KongFuData kongFu in SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_KongFuList)
					{
						if (kongFu.kf.ID == array[2])
						{
							flag = true;
							break;
						}
					}
				}
				else if (array[1] == "PARA")
				{
					string[] array5 = array[2].Split('+');
					flag = true;
					array3 = array5;
					for (int i = 0; i < array3.Length; i++)
					{
						string[] array6 = array3[i].Split('_');
						List<string> list2 = new List<string>();
						if (array6[0] == "ANY")
						{
							list2.Add(SharedData.Instance().playerid);
							list2.AddRange(SharedData.Instance().FollowList);
						}
						else if (array6[0] == "SELF")
						{
							list2.Add(SharedData.Instance().playerid);
						}
						else if (array6[0].StartsWith("SPEC"))
						{
							list2.Add(array6[0].Split('-')[1]);
						}
						else
						{
							list2.Add(array6[0]);
						}
						float num2 = 0f;
						float num3 = float.Parse(array6[3], CultureInfo.InvariantCulture);
						CharaData charaData = null;
						foreach (string item in list2)
						{
							charaData = SharedData.Instance().GetCharaData(item);
							num2 = ((array6[1] == "LV") ? ((float)charaData.m_Level) : ((array6[1] == "MONEY") ? ((float)SharedData.Instance().m_Money) : ((array6[1] == "HP") ? charaData.m_Hp : ((array6[1] == "MP") ? charaData.m_Mp : ((array6[1] == "HPLIMIT") ? charaData.GetFieldValueByName("HP") : ((!(array6[1] == "MPLIMIT")) ? charaData.GetFieldValueByName(array6[1]) : charaData.GetFieldValueByName("MP")))))));
							if (array6[2] == ">")
							{
								if (num2 < num3)
								{
									flag = false;
								}
							}
							else if (array6[2] == "<")
							{
								if (num2 > num3)
								{
									flag = false;
								}
							}
							else if (array6[2] == "=" && num2 != num3)
							{
								flag = false;
							}
							if (flag)
							{
								SharedData.Instance().m_TempParas["teammates"] = charaData.Indexs_Name["Name"].stringValue;
								break;
							}
						}
					}
				}
				else if (array[1] == "TEAM")
				{
					string[] array7 = array[2].Split('_');
					if (array7.Length > 2)
					{
						float num4 = 0f;
						float num5 = 0f;
						if (array7[0] == "COUNT")
						{
							num4 = SharedData.Instance().FollowList.Count;
							num5 = float.Parse(array7[2], CultureInfo.InvariantCulture);
						}
						if (array7[1] == ">")
						{
							if (num4 > num5)
							{
								flag = true;
							}
						}
						else if (array7[1] == "<")
						{
							if (num4 < num5)
							{
								flag = true;
							}
						}
						else if (array7[1] == "=" && num4 == num5)
						{
							flag = true;
						}
					}
					else if (array7.Length > 1 && array7[0] == "EXISTS")
					{
						flag = SharedData.Instance().FollowList.Contains(array7[1]);
					}
				}
				else if (array[1] == "PARTY")
				{
					flag = SharedData.Instance().FullTeam.Contains(array[2]);
				}
				else if (array[1] == "TRAIT")
				{
					flag = SharedData.Instance().GetCharaData(SharedData.Instance().playerid).m_TraitList.Contains(array[2]);
				}
				else if (array[1] == "PACKAGE")
				{
					string[] array8 = array[2].Split('_');
					float num6 = 0f;
					if (SharedData.Instance().PlayerPackage.ContainsKey(array8[0]))
					{
						num6 = SharedData.Instance().PlayerPackage[array8[0]];
					}
					float num7 = float.Parse(array8[2], CultureInfo.InvariantCulture);
					if (array8[1] == ">")
					{
						if (num6 > num7)
						{
							flag = true;
						}
					}
					else if (array8[1] == "<")
					{
						if (num6 < num7)
						{
							flag = true;
						}
					}
					else if (array8[1] == "=" && num6 == num7)
					{
						flag = true;
					}
				}
				else if (array[1] == "MINE")
				{
					if (array[2] == "APPRECIATIONTRAIT")
					{
						SharedData.Instance().appreciationCharacterID = "";
						CharaData charaData2 = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
						if (charaData2.GetFieldValueByName("Appreciation") > 0f)
						{
							SharedData.Instance().appreciationCharacterID = charaData2.m_Id;
						}
						else
						{
							foreach (string follow in SharedData.Instance().FollowList)
							{
								if (SharedData.Instance().GetCharaData(follow).GetFieldValueByName("Appreciation") > 0f)
								{
									SharedData.Instance().appreciationCharacterID = follow;
									CommonResourcesData.b01.Find_ID(follow);
								}
							}
						}
						if (SharedData.Instance().appreciationCharacterID != "")
						{
							flag = true;
						}
					}
				}
				else if (array[1] == "ARENA" && array[2] == "DaTianWangSi" && SharedData.Instance().m_challengePrizeItemList.Count > 0)
				{
					flag = true;
				}
				text = ((!flag) ? (row.flag + "_FALSE") : (row.flag + "_TRUE"));
			}
			else if ("SELECT".Equals(array[0]))
			{
				text = row.flag + "_1";
			}
			else if ("BATTLE".Equals(array[0]))
			{
				text = row.flag + "_WIN";
			}
			else if ("SWITCH".Equals(array[0]))
			{
				int num8 = 1;
				array3 = array[1].Split('+');
				foreach (string key3 in array3)
				{
					if (SharedData.Instance().FlagList[key3] == 2)
					{
						break;
					}
					num8++;
				}
				text = row.flag + "_" + num8;
			}
			if (!"".Equals(text))
			{
				continue;
			}
			array3 = row.nextflag.Split('|');
			foreach (string text2 in array3)
			{
				if (text2.Length <= 0)
				{
					continue;
				}
				gang_e01Table.Row row2 = CommonResourcesData.e01.Find_flag(text2);
				if (row2 != null)
				{
					if (Event2Map[row2.eventid].Equals(Event2Map[row.eventid]))
					{
						if (SharedData.Instance().FlagList[text2] != 2)
						{
							if (row2.eventid.Equals(row.eventid))
							{
								text = text2;
								list.Remove(text);
							}
							else if (!list.Contains(text2))
							{
								Debug.LogWarning("....--> From nextflag add flag: [" + text2 + "] to snowball.");
								list.Add(text2);
							}
						}
						else
						{
							Debug.LogWarning("....--> Skip flag [" + text2 + "] == 2 and SET 1, currentflag: [" + row.flag + "]");
							SharedData.Instance().FlagList[text2] = 1;
						}
					}
					else
					{
						Debug.LogWarning("....--> Skip other map's flag [" + text2 + "] but SET 1, currentflag: [" + row.flag + "]");
						SharedData.Instance().FlagList[text2] = 1;
					}
				}
				else
				{
					Debug.LogWarning("....--> Flag [" + text2 + "] NOT exist, currentflag: [" + row.flag + "]");
				}
			}
		}
		while (!"".Equals(text));
		if (list.Count > 0)
		{
			RollSnowball(list);
		}
		else
		{
			Debug.LogWarning("=== RollSnowball() END.");
		}
	}

	private void GetMethod(string[] action)
	{
		CharaData charaData = SharedData.Instance().GetCharaData(SharedData.Instance().playerid);
		if (action[1] == "LOOT")
		{
			List<gang_c01Table.Row> list = CommonResourcesData.c01.FindAll_ID(action[2]);
			int num = 0;
			{
				foreach (gang_c01Table.Row item in list)
				{
					float num2 = float.Parse(item.Chance, CultureInfo.InvariantCulture);
					if (Random.Range(0f, 1f) >= num2)
					{
						continue;
					}
					int num3 = 0;
					string[] array = item.QTY.Split('|');
					if (array.Length > 1)
					{
						int minInclusive = int.Parse(array[0]);
						int maxExclusive = int.Parse(array[1]) + 1;
						num3 = Random.Range(minInclusive, maxExclusive);
					}
					else
					{
						num3 = int.Parse(array[0]);
					}
					if ("999".Equals(item.Item))
					{
						if (num3 > 0)
						{
							num3 = Mathf.CeilToInt((float)num3 * SharedData.Instance().m_Money_Drop_Rate);
						}
						SharedData.Instance().m_Money += num3;
						if (SharedData.Instance().m_Money < 0)
						{
							SharedData.Instance().m_Money = 0;
						}
					}
					else
					{
						SharedData.Instance().PackageAdd(item.Item, num3);
					}
					num++;
				}
				return;
			}
		}
		if (action[1] == "ATTR")
		{
			CharaData charaData2 = charaData;
			if (action.Length > 4)
			{
				charaData2 = SharedData.Instance().GetCharaData(action[4]);
			}
			if (action[2] == "TALENT")
			{
				charaData2.m_Talent += Mathf.FloorToInt(float.Parse(action[3], CultureInfo.InvariantCulture));
				int num4 = int.Parse(SharedData.Instance().m_A01NameRowDirec["TALENT"].Limit);
				if (charaData2.m_Talent > num4)
				{
					charaData2.m_Talent = num4;
				}
				return;
			}
			if (action[2] == "LV")
			{
				charaData2.m_Level += Mathf.FloorToInt(float.Parse(action[3], CultureInfo.InvariantCulture));
				int num5 = int.Parse(SharedData.Instance().m_A01NameRowDirec["LV"].Limit);
				if (charaData2.m_Level > num5)
				{
					charaData2.m_Level = num5;
				}
				charaData2.m_Exp = 0;
				return;
			}
			if (action[2] == "RANK")
			{
				if ("+".Equals(action[3]))
				{
					charaData2.m_Ranking++;
				}
				else if ("-".Equals(action[3]))
				{
					charaData2.m_Ranking--;
				}
				else
				{
					charaData2.m_Ranking = Mathf.FloorToInt(float.Parse(action[3], CultureInfo.InvariantCulture));
				}
				if (charaData2.m_Ranking < 1)
				{
					charaData2.m_Ranking = 1;
				}
				return;
			}
			charaData2.Indexs_Name[action[2]].bornValue += Mathf.Floor(float.Parse(action[3], CultureInfo.InvariantCulture));
			if (action[2] == "HP")
			{
				if (charaData2.m_Hp > charaData2.GetFieldValueByName("HP"))
				{
					charaData2.m_Hp = charaData2.GetFieldValueByName("HP");
				}
			}
			else if (action[2] == "MP" && charaData2.m_Mp > charaData2.GetFieldValueByName("MP"))
			{
				charaData2.m_Mp = charaData2.GetFieldValueByName("MP");
			}
		}
		else if (action[1] == "EPIPHANY")
		{
			SharedData.Instance().m_Epiphany += Mathf.FloorToInt(float.Parse(action[2], CultureInfo.InvariantCulture));
		}
		else if (action[1] == "OPINION")
		{
			CharaData charaData3 = SharedData.Instance().GetCharaData(action[2]);
			if (charaData3 != null)
			{
				int num6 = int.Parse(action[3]);
				charaData3.m_Relationship += num6;
			}
		}
		else if (action[1] == "TRAIT")
		{
			if (action[2] == "PLAYER")
			{
				if (action[4] == "+")
				{
					if (!charaData.m_TraitList.Contains(action[3]))
					{
						charaData.AddTraits(action[3]);
						GameDataManager.Instance().AddUnlockAtlasList(action[3], "b06");
					}
				}
				else if (charaData.m_TraitList.Contains(action[3]))
				{
					charaData.RemoveTrait(action[3]);
				}
				return;
			}
			CharaData charaData4 = SharedData.Instance().GetCharaData(action[2]);
			if (charaData4 == null)
			{
				return;
			}
			if (action[4] == "+")
			{
				if (!charaData4.m_TraitList.Contains(action[3]))
				{
					charaData4.AddTraits(action[3]);
					GameDataManager.Instance().AddUnlockAtlasList(action[3], "b06");
				}
			}
			else if (charaData4.m_TraitList.Contains(action[3]))
			{
				charaData4.RemoveTrait(action[3]);
			}
		}
		else if (action[1] == "ITEM")
		{
			if ("ARENA".Equals(action[2]))
			{
				if (action[3].Equals("JunShanGaiBang"))
				{
					string[] array2 = SharedData.Instance().m_Arena_RewardsID_JunShan.Split('|');
					List<int> list2 = new List<int>();
					for (int i = 0; i < array2.Length; i++)
					{
						if (SharedData.Instance().m_Arena_Rewards_JunShan[i] == '0')
						{
							list2.Add(i);
						}
					}
					if (list2.Count > 0)
					{
						int index = Random.Range(0, list2.Count);
						action[2] = array2[list2[index]];
						action[3] = "1";
						char[] array3 = SharedData.Instance().m_Arena_Rewards_JunShan.ToCharArray();
						array3[list2[index]] = '1';
						SharedData.Instance().m_Arena_Rewards_JunShan = new string(array3);
					}
					else
					{
						action[2] = "999";
						action[3] = "1000";
					}
				}
				else if (action[3].Equals("DaTianWangSi"))
				{
					if (SharedData.Instance().m_challengePrizeItemList.Count > 0)
					{
						new List<int>();
						for (int j = 0; j < SharedData.Instance().m_challengePrizeItemList.Count; j++)
						{
							string text = SharedData.Instance().m_challengePrizeItemList[j];
							string text2 = SharedData.Instance().m_challengePrizeNumberList[j].ToString();
							string text3 = SharedData.Instance().m_challengePrizeLevelList[j].ToString();
							string text4 = text3 + "&" + text + "&" + text2;
							SharedData sharedData = SharedData.Instance();
							sharedData.m_Arena_Rewards_DaTianWangSi = sharedData.m_Arena_Rewards_DaTianWangSi + text4 + "|";
						}
					}
					List<string> list3 = new List<string>();
					List<int> list4 = new List<int>();
					for (int k = 0; k < SharedData.Instance().m_challengePrizeItemList.Count; k++)
					{
						if (list3.Contains(SharedData.Instance().m_challengePrizeItemList[k]))
						{
							list4[list3.IndexOf(SharedData.Instance().m_challengePrizeItemList[k])] += SharedData.Instance().m_challengePrizeNumberList[k];
							continue;
						}
						list3.Add(SharedData.Instance().m_challengePrizeItemList[k]);
						list4.Add(SharedData.Instance().m_challengePrizeNumberList[k]);
					}
					if (list3.Count > 0)
					{
						new List<int>();
						for (int l = 0; l < list3.Count; l++)
						{
							string key = list3[l];
							string s = list4[l].ToString();
							SharedData.Instance().PackageAdd(key, int.Parse(s));
						}
					}
					action[2] = "";
				}
			}
			if (action[2] == "999")
			{
				float num7 = float.Parse(action[3], CultureInfo.InvariantCulture);
				int num8 = Mathf.CeilToInt(num7);
				if (num7 > 0f)
				{
					num8 = Mathf.CeilToInt(num7 * SharedData.Instance().m_Money_Drop_Rate);
				}
				SharedData.Instance().m_Money += num8;
				if (SharedData.Instance().m_Money < 0)
				{
					SharedData.Instance().m_Money = 0;
				}
			}
			else if (action[2] == "APPRECIATIONMINE")
			{
				SharedData.Instance().PackageRemove(SharedData.Instance().m_unKnownItemID);
				SharedData.Instance().PackageAdd(SharedData.Instance().m_unKnownItemID.Split("&")[1], 1);
				SharedData.Instance().m_unKnownItemID = "";
			}
			else if (action[2] != "")
			{
				SharedData.Instance().PackageAdd(action[2], int.Parse(action[3]));
			}
		}
		else if (action[1] == "INHERIT")
		{
			string[] array4 = GameDataManager.Instance().configdata.inheritItems.Split('&');
			for (int m = 0; m < array4.Length; m++)
			{
				string[] array5 = array4[m].Split('|');
				if (array5[0] == "999")
				{
					int num9 = int.Parse(array5[1]);
					SharedData.Instance().m_Money += num9;
					if (SharedData.Instance().m_Money < 0)
					{
						SharedData.Instance().m_Money = 0;
					}
				}
				else
				{
					SharedData.Instance().PackageAdd(array5[0], int.Parse(array5[1]));
				}
			}
		}
		else
		{
			if (!(action[1] == "WUGONG"))
			{
				return;
			}
			if (action[2] == "PLAYER")
			{
				if (action[4] == "+")
				{
					if (charaData.GetKongFuByID(action[3]) == null)
					{
						KongFuData newkongfu = new KongFuData
						{
							kf = CommonResourcesData.b03.Find_ID(action[3]),
							lv = 1,
							exp = 0f,
							proficiency = 0
						};
						charaData.KongFuListAdd(newkongfu);
					}
				}
				else
				{
					KongFuData kongFuByID = charaData.GetKongFuByID(action[3]);
					if (kongFuByID != null)
					{
						charaData.KongFuListRemove(kongFuByID);
					}
				}
				return;
			}
			CharaData charaData5 = SharedData.Instance().GetCharaData(action[2]);
			if (charaData5 == null)
			{
				return;
			}
			if (action[4] == "+")
			{
				if (charaData5.GetKongFuByID(action[3]) == null)
				{
					KongFuData newkongfu2 = new KongFuData
					{
						kf = CommonResourcesData.b03.Find_ID(action[3]),
						lv = 1,
						exp = 0f,
						proficiency = 0
					};
					charaData5.KongFuListAdd(newkongfu2);
				}
			}
			else
			{
				KongFuData kongFuByID2 = charaData5.GetKongFuByID(action[3]);
				if (kongFuByID2 != null)
				{
					charaData5.KongFuListRemove(kongFuByID2);
				}
			}
		}
	}

	private void EventMethod(string[] _action, List<string> _snowball)
	{
		string[] array = _action[2].Split('&');
		foreach (string key in array)
		{
			List<gang_e01Table.Row> list = SharedData.Instance().EventTable[key];
			if (_action[1] == "OPEN")
			{
				foreach (gang_e01Table.Row item in list)
				{
					SharedData.Instance().FlagList[item.flag] = 0;
				}
			}
			else
			{
				if (!(_action[1] == "CLOSE"))
				{
					continue;
				}
				foreach (gang_e01Table.Row item2 in list)
				{
					SharedData.Instance().FlagList[item2.flag] = 2;
					if (_snowball != null && _snowball.Contains(item2.flag))
					{
						_snowball.Remove(item2.flag);
					}
				}
			}
		}
	}

	private void EventFlowEnd(string _eventid)
	{
		Debug.LogWarning("....=== END Event flow: " + _eventid);
		foreach (gang_e01Table.Row item in SharedData.Instance().EventTable[_eventid])
		{
			SharedData.Instance().FlagList[item.flag] = 2;
		}
	}
}
