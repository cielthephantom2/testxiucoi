public class SceneMove
{
	public string direction;

	public int step;
}
