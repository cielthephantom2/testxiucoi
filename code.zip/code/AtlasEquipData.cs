public class AtlasEquipData : ItemDataBase
{
	public bool isUnlock;

	public gang_b07Table.Row b07Row = new gang_b07Table.Row();

	public gang_b02Table.Row b02Row = new gang_b02Table.Row();

	public string level1 = "";

	public string level2 = "";

	public string level3 = "";

	public override bool IsFilterMatched(string filterStr)
	{
		string[] array = filterStr.Split('|');
		if ((array[1].Equals("") || level1.Equals(array[1])) && (array[2].Equals("") || level2.Equals(array[2])))
		{
			return level3.Contains(array[3]);
		}
		return false;
	}
}
