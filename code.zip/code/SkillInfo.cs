using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class SkillInfo
{
	public int sid = -1;

	public string[] sName = new string[6] { "", "", "", "", "", "" };

	public string[] sValue = new string[6] { "", "", "", "", "", "" };

	public string[] sValueAdd = new string[6] { "", "", "", "", "", "" };

	public string[] sOdds = new string[6] { "", "", "", "", "", "" };

	public string[] sOddsAdd = new string[6] { "", "", "", "", "", "" };

	public string[] sTurn = new string[6] { "", "", "", "", "", "" };

	public string[] sTurnAdd = new string[6] { "", "", "", "", "", "" };

	public string[] sTarget = new string[6] { "", "", "", "", "", "" };

	public string[] sEffectRange = new string[6] { "", "", "", "", "", "" };

	public string[] sSkillEc = new string[6] { "", "", "", "", "", "" };

	public float[] sValueNum = new float[6];

	public float[] sOddNum = new float[6];

	public int[] sTurnNum = new int[6];

	public bool[] isSkillEffect = new bool[6] { true, true, true, true, true, true };

	public void Init(KongFuData _KongFuData, BattleObject _BattleObject)
	{
		List<string> list = new List<string>
		{
			_KongFuData.kf.Skill1,
			_KongFuData.kf.Skill2,
			_KongFuData.kf.Skill3,
			_KongFuData.kf.Skill4,
			_KongFuData.kf.Skill5
		};
		List<string> list2 = new List<string>
		{
			_KongFuData.kf.Skill1EC,
			_KongFuData.kf.Skill2EC,
			_KongFuData.kf.Skill3EC,
			_KongFuData.kf.Skill4EC,
			_KongFuData.kf.Skill5EC
		};
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != "0")
			{
				sid++;
				string[] array = list[i].Split('&');
				sName[sid] = array[0];
				string[] array2 = array[1].Split('|');
				sValue[sid] = array2[0];
				sValueAdd[sid] = array2[1];
				array2 = array[2].Split('|');
				sOdds[sid] = array2[0];
				sOddsAdd[sid] = array2[1];
				array2 = array[3].Split('|');
				sTurn[sid] = array2[0];
				sTurnAdd[sid] = array2[1];
				sTarget[sid] = array[4];
				sEffectRange[sid] = "0";
				if (array.Length == 6)
				{
					sEffectRange[sid] = array[5];
				}
				sSkillEc[sid] = list2[i];
				if (_BattleObject != null && _BattleObject.m_SkillRow != null)
				{
					sValueNum[sid] = (float.Parse(sValue[sid], CultureInfo.InvariantCulture) + float.Parse(sValueAdd[sid], CultureInfo.InvariantCulture) * (float)(_BattleObject.m_SkillRow.lv - 1)) * 1000f / 1000f;
					sOddNum[sid] = float.Parse(sOdds[sid], CultureInfo.InvariantCulture) + float.Parse(sOddsAdd[sid], CultureInfo.InvariantCulture) * (float)(_BattleObject.m_SkillRow.lv - 1);
					sTurnNum[sid] = ((int.Parse(sTurn[sid]) >= 0) ? (int.Parse(sTurn[sid]) + int.Parse(sTurnAdd[sid]) * (_BattleObject.m_SkillRow.lv - 1)) : int.MaxValue);
				}
			}
		}
	}

	public void InitSkill(List<string> _SkillList, List<string> _SkillEcList, int _EnhanceLv = 0)
	{
		for (int i = 0; i < _SkillList.Count; i++)
		{
			if (_SkillList[i] != "0")
			{
				sid++;
				string[] array = _SkillList[i].Split('&');
				sName[sid] = array[0];
				string[] array2 = array[1].Split('|');
				sValue[sid] = array2[0];
				sValueAdd[sid] = array2[1];
				array2 = array[2].Split('|');
				sOdds[sid] = array2[0];
				sOddsAdd[sid] = array2[1];
				array2 = array[3].Split('|');
				sTurn[sid] = array2[0];
				sTurnAdd[sid] = array2[1];
				sTarget[sid] = array[4];
				sEffectRange[sid] = "0";
				if (array.Length == 6)
				{
					sEffectRange[sid] = array[5];
				}
				sSkillEc[sid] = _SkillEcList[i];
				try
				{
					sValueNum[sid] = (float.Parse(sValue[sid], CultureInfo.InvariantCulture) + float.Parse(sValueAdd[sid], CultureInfo.InvariantCulture) * (float)_EnhanceLv) * 1000f / 1000f;
					sOddNum[sid] = float.Parse(sOdds[sid], CultureInfo.InvariantCulture) + float.Parse(sOddsAdd[sid], CultureInfo.InvariantCulture) * (float)_EnhanceLv;
					sTurnNum[sid] = ((int.Parse(sTurn[sid]) >= 0) ? (int.Parse(sTurn[sid]) + int.Parse(sTurnAdd[sid]) * _EnhanceLv) : int.MaxValue);
				}
				catch (Exception ex)
				{
					Debug.LogWarning("InitSkill Failed e = " + ex);
				}
			}
		}
	}
}
