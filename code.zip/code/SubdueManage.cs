using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SubdueManage : MonoBehaviour
{
	private GameObject InteruptInfo;

	private string TitleText = "";

	private int SelectedCount;

	private Sprite NormalSprite;

	private Color NormalColor = new Color(14f / 51f, 0.23137255f, 16f / 85f);

	private Sprite SelectedSprite;

	private Color SelectedColor = new Color(47f / 51f, 76f / 85f, 0.8235294f);

	private List<Button> allBtns = new List<Button>();

	private List<Button> buttonsAlready = new List<Button>();

	private List<Button> buttonsNotYet = new List<Button>();

	private Button currentSelect;

	private int currentCount;

	private void Awake()
	{
		NormalSprite = Resources.Load("images/01-border/boder-20231228-button-02", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
	}

	private void Start()
	{
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		SharedData.Instance().m_FinalSubdueList.Clear();
		SharedData.Instance().m_ExpelList.Clear();
		InteruptInfo = base.transform.Find("Panel/InteruptInfo").gameObject;
		allBtns = base.transform.Find("Panel").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		foreach (Button allBtn in allBtns)
		{
			EventTriggerListener.Get(allBtn.gameObject).onClick = OnButtonClick;
		}
		allBtns = base.transform.Find("Panel/CharacterArea/Viewport/Content").GetComponentsInChildren<Button>(includeInactive: true).ToList();
		foreach (Button allBtn2 in allBtns)
		{
			if (allBtn2.name.StartsWith("SelcetTeammate"))
			{
				buttonsAlready.Add(allBtn2);
			}
			else
			{
				buttonsNotYet.Add(allBtn2);
			}
		}
		if (SharedData.Instance().SubdueManageFor == "Expel")
		{
			foreach (Button item in buttonsNotYet)
			{
				item.gameObject.SetActive(value: false);
			}
		}
		int pokemonCounts = 0;
		for (int i = 0; i < SharedData.Instance().FullTeam.Count; i++)
		{
			string text = SharedData.Instance().FullTeam[i];
			if (!text.Contains('_'))
			{
				continue;
			}
			pokemonCounts++;
			if (pokemonCounts <= 18)
			{
				Button button = buttonsAlready.Find((Button x) => x.gameObject.name == "SelcetTeammate_" + pokemonCounts);
				button.transform.Find("IconMask/IconBG").gameObject.SetActive(value: true);
				CharaData charaData = SharedData.Instance().GetCharaData(text);
				charaData.m_Table = "b01";
				Sprite tachieHead = CommonResourcesData.GetTachieHead(charaData.m_BattleIcon);
				if (tachieHead == null)
				{
					button.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: false);
					button.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
					button.transform.Find("IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(charaData);
				}
				else
				{
					button.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: true);
					button.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
					button.transform.Find("IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead;
				}
				button.transform.Find("Name").gameObject.SetActive(value: true);
				button.transform.Find("Name").GetComponent<Text>().text = charaData.Indexs_Name["Name"].stringValue;
				button.transform.Find("Level").gameObject.SetActive(value: true);
				button.transform.Find("Level/Text").GetComponent<Text>().text = "LV." + charaData.m_Level;
				button.name = button.name + "|" + text + "|0|Already";
				currentCount++;
			}
		}
		int notyetCount = 0;
		foreach (KeyValuePair<string, CharaData> subdue in SharedData.Instance().m_SubdueList)
		{
			notyetCount++;
			if (notyetCount <= 9)
			{
				Button button2 = buttonsNotYet.Find((Button x) => x.gameObject.name == "SelcetPokemon_" + notyetCount);
				button2.transform.Find("IconMask/IconBG").gameObject.SetActive(value: true);
				CharaData value = subdue.Value;
				value.m_Table = "b01";
				Sprite tachieHead2 = CommonResourcesData.GetTachieHead(value.m_BattleIcon);
				if (tachieHead2 == null)
				{
					button2.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: false);
					button2.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: true);
					button2.transform.Find("IconMask/IconBG/IconPixel").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(value);
				}
				else
				{
					button2.transform.Find("IconMask/IconBG/Icon").gameObject.SetActive(value: true);
					button2.transform.Find("IconMask/IconBG/IconPixel").gameObject.SetActive(value: false);
					button2.transform.Find("IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieHead2;
				}
				button2.transform.Find("Name").gameObject.SetActive(value: true);
				button2.transform.Find("Name").GetComponent<Text>().text = value.Indexs_Name["Name"].stringValue;
				button2.transform.Find("Level").gameObject.SetActive(value: true);
				button2.transform.Find("Level/Text").GetComponent<Text>().text = "LV." + value.m_Level;
				button2.name = button2.name + "|" + subdue.Key + "|0|NotYet";
				if (SharedData.Instance().SubdueManageFor.Equals("Subdue"))
				{
					OnButtonClick(button2.gameObject);
				}
			}
		}
		UpdateCount();
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/CharacterArea/Viewport/Content").GetChild(0).gameObject);
		ExecuteEvents.Execute(base.transform.Find("Panel/CharacterArea/Viewport/Content").GetChild(0).gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
	}

	private void Update()
	{
		if (InteruptInfo.activeInHierarchy)
		{
			if (InputSystemCustom.Instance().UI.Confirm.WasPressedThisFrame() || InputSystemCustom.Instance().UI.Cancel.WasPressedThisFrame() || Input.GetMouseButtonDown(0))
			{
				SharedData.Instance().m_OpenDetail = "";
				InteruptInfo.SetActive(value: false);
			}
		}
		else if (InputSystemCustom.Instance().UI.ConfirmBattle.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Btns/ChooseOK").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.ExpelFollower.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/Btns/ExpelBtn").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	private void UpdateCount()
	{
		base.transform.Find("Panel/FollowerCount/Num").GetComponent<Text>().text = currentCount + "/" + SharedData.Instance().AlliesMaxCount;
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		string[] array = go.name.Split('|');
		if (array[0].StartsWith("SelcetTeammate_"))
		{
			if (currentSelect != null)
			{
				currentSelect.GetComponent<Image>().sprite = NormalSprite;
			}
			currentSelect = go.GetComponent<Button>();
			currentSelect.GetComponent<Image>().sprite = SelectedSprite;
		}
		else if (array[0].StartsWith("SelcetPokemon_"))
		{
			if (currentSelect != null)
			{
				currentSelect.GetComponent<Image>().sprite = NormalSprite;
			}
			currentSelect = go.GetComponent<Button>();
			currentSelect.GetComponent<Image>().sprite = SelectedSprite;
			if (array.Length >= 4 && (currentCount < SharedData.Instance().AlliesMaxCount || go.transform.Find("Selected").gameObject.activeInHierarchy))
			{
				go.transform.Find("Selected").gameObject.SetActive(!go.transform.Find("Selected").gameObject.activeInHierarchy);
				if (go.transform.Find("Selected").gameObject.activeInHierarchy)
				{
					currentCount++;
				}
				else
				{
					currentCount--;
				}
				UpdateCount();
			}
		}
		else if (array[0] == "ChooseOK")
		{
			foreach (Button item in buttonsNotYet)
			{
				if (item.transform.Find("Selected").gameObject.activeInHierarchy)
				{
					string key = item.name.Split('|')[1];
					SharedData.Instance().m_FinalSubdueList.Add(key, SharedData.Instance().m_SubdueList[key]);
				}
			}
			SharedData.Instance().m_SubdueList.Clear();
			if (SharedData.Instance().SubdueManageFor == "Expel" || SharedData.Instance().SubdueManageFor == "SubdueTest")
			{
				if (SharedData.Instance().LoadedSceneStack.Count > 0)
				{
					int index = SharedData.Instance().LoadedSceneStack.Count - 1;
					string sceneName = SharedData.Instance().LoadedSceneStack[index];
					SharedData.Instance().LoadedSceneStack.RemoveAt(index);
					SceneManager.UnloadSceneAsync(sceneName);
				}
				SharedData.Instance().m_MapController.ExpelTeam();
				SharedData.Instance().m_MapController.SubdueEnemy();
			}
			else if (SharedData.Instance().SceneBefore4Camp.Length > 0)
			{
				SharedData.Instance().ASyncLoadScene(SharedData.Instance().SceneBefore4Camp);
			}
			else if (SharedData.Instance().SceneBefore.Length > 0)
			{
				SharedData.Instance().BackFromOtherScene = true;
				SharedData.Instance().ASyncLoadScene(SharedData.Instance().SceneBefore);
			}
		}
		else if (array[0] == "ExpelBtn")
		{
			if (!(currentSelect == null) && currentSelect.name.StartsWith("SelcetTeammate_") && currentSelect.name.Split('|').Length >= 4)
			{
				_ = currentSelect.name.Split('|')[1];
				base.transform.Find("Panel/ConfirmExpel/Text").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_ExpelFollower"), currentSelect.transform.Find("Name").GetComponent<Text>().text);
				base.transform.Find("Panel/ConfirmExpel").gameObject.SetActive(value: true);
				base.transform.Find("Panel/Btns").GetComponent<CanvasGroup>().interactable = false;
				base.transform.Find("Panel/CharacterArea").GetComponent<CanvasGroup>().interactable = false;
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/ConfirmExpel/ConfirmExpelCancel").gameObject);
			}
		}
		else if (array[0] == "ConfirmExpelYes")
		{
			InteruptInfo.transform.Find("Info/Text").GetComponent<Text>().text = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_ExpelFollower_Info"), currentSelect.transform.Find("Name").GetComponent<Text>().text);
			InteruptInfo.transform.Find("IconFrame/Icon").GetComponent<Image>().sprite = currentSelect.transform.Find("IconMask/IconBG/Icon").GetComponent<Image>().sprite;
			InteruptInfo.gameObject.SetActive(value: true);
			base.transform.Find("Panel/ConfirmExpel").gameObject.SetActive(value: false);
			SharedData.Instance().m_ExpelList.Add(currentSelect.name.Split('|')[1]);
			currentSelect.transform.Find("IconMask/IconBG").gameObject.SetActive(value: false);
			currentSelect.transform.Find("Name").gameObject.SetActive(value: false);
			currentSelect.transform.Find("Level").gameObject.SetActive(value: false);
			currentSelect.name = currentSelect.name.Split('|')[0];
			base.transform.Find("Panel/Btns").GetComponent<CanvasGroup>().interactable = true;
			base.transform.Find("Panel/CharacterArea").GetComponent<CanvasGroup>().interactable = true;
			EventSystem.current.SetSelectedGameObject(currentSelect.gameObject);
			SharedData.Instance().m_OpenDetail = "ConfirmExpelYes";
			currentCount--;
			UpdateCount();
		}
		else if (array[0] == "ConfirmExpelCancel")
		{
			base.transform.Find("Panel/ConfirmExpel").gameObject.SetActive(value: false);
			base.transform.Find("Panel/Btns").GetComponent<CanvasGroup>().interactable = true;
			base.transform.Find("Panel/CharacterArea").GetComponent<CanvasGroup>().interactable = true;
			EventSystem.current.SetSelectedGameObject(currentSelect.gameObject);
		}
	}
}
