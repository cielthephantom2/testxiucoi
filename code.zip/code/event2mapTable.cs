using System.Collections.Generic;
using UnityEngine;

public class event2mapTable
{
	public class Row
	{
		public string eventid;

		public string mapid;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			Row item = new Row
			{
				eventid = list[i][0],
				mapid = list[i][1]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_eventid(string find)
	{
		return rowList.Find((Row x) => x.eventid == find);
	}

	public List<Row> FindAll_eventid(string find)
	{
		return rowList.FindAll((Row x) => x.eventid == find);
	}

	public Row Find_mapid(string find)
	{
		return rowList.Find((Row x) => x.mapid == find);
	}

	public List<Row> FindAll_mapid(string find)
	{
		return rowList.FindAll((Row x) => x.mapid == find);
	}
}
