using System.Collections.Generic;
using UnityEngine;

public class gang_b08Table
{
	public class Row
	{
		public string ID;

		public string ShopID;

		public string GoodID;

		public string Pack;

		public string Price;

		public PriceType PriceType;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				ShopID = list[i][num++],
				GoodID = list[i][num++],
				Pack = list[i][num++],
				Price = list[i][num++]
			};
			switch (list[i][num++])
			{
			case "money":
				row.PriceType = PriceType.money;
				break;
			case "oldcoin":
				row.PriceType = PriceType.oldcoin;
				break;
			case "bone":
				row.PriceType = PriceType.bone;
				break;
			}
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_ShopID(string find)
	{
		return rowList.Find((Row x) => x.ShopID == find);
	}

	public List<Row> FindAll_ShopID(string find)
	{
		return rowList.FindAll((Row x) => x.ShopID == find);
	}

	public Row Find_GoodID(string find)
	{
		return rowList.Find((Row x) => x.GoodID == find);
	}

	public List<Row> FindAll_GoodID(string find)
	{
		return rowList.FindAll((Row x) => x.GoodID == find);
	}

	public Row Find_Pack(string find)
	{
		return rowList.Find((Row x) => x.Pack == find);
	}

	public List<Row> FindAll_Pack(string find)
	{
		return rowList.FindAll((Row x) => x.Pack == find);
	}

	public Row Find_Price(string find)
	{
		return rowList.Find((Row x) => x.Price == find);
	}

	public List<Row> FindAll_Price(string find)
	{
		return rowList.FindAll((Row x) => x.Price == find);
	}
}
