using System.Collections.Generic;
using UnityEngine;

public static class AStarAlgorithmBattleField
{
	public static int m_MoveProcess = 0;

	public static Vector3Int startPos;

	private static Vector3Int endPos;

	public static Vector2 m_MovingFrom;

	public static Vector2 m_MovingTo;

	public static GameObject tablePrefab = null;

	public static List<GameObject> pathObject = new List<GameObject>();

	private static Dictionary<Vector3Int, int> search = new Dictionary<Vector3Int, int>();

	private static Dictionary<Vector3Int, int> cost = new Dictionary<Vector3Int, int>();

	private static Dictionary<Vector3Int, Vector3Int> pathSave = new Dictionary<Vector3Int, Vector3Int>();

	private static List<Vector3Int> hadSearch = new List<Vector3Int>();

	private static float m_MoveTimer;

	public static Dictionary<Vector3Int, bool> isBattleObjOn = new Dictionary<Vector3Int, bool>();

	public static void AStarWaiting(BattleObject _BattleObject)
	{
		if (m_MoveProcess < 0 || pathObject.Count == 0)
		{
			if (SharedData.Instance().m_BattleController.isRoundActionFinish())
			{
				SharedData.Instance().m_BattleController.m_curcor.SetPosition(_BattleObject);
				AStarClean();
				if (_BattleObject.CheckBuffEffectOn("Dizzy") || _BattleObject.charadata.GetBattleValueByName("Seal") >= 25f)
				{
					_BattleObject.SetBattleObjState(BattleObjectState.RoundOff);
					SharedData.Instance().m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
				}
				else
				{
					_BattleObject.SetBattleObjState(BattleObjectState.ActionInit);
				}
			}
			return;
		}
		if (m_MoveProcess < pathObject.Count - 1)
		{
			pathObject[m_MoveProcess + 1].SetActive(value: false);
		}
		Vector3Int zero = Vector3Int.zero;
		zero.x = Mathf.FloorToInt(pathObject[m_MoveProcess].transform.position.x / CommonVariables.MovementBlockSize);
		zero.y = Mathf.FloorToInt(Mathf.Abs(pathObject[m_MoveProcess].transform.position.y) / CommonVariables.MovementBlockSize);
		_BattleObject.AdjustFace(zero);
		_BattleObject.PlayAnimation(Aniname.aniname_walk);
		_BattleObject.PlayAudioClip(AudioClipEnum.walkClip);
		m_MovingFrom = _BattleObject.gameObject.transform.position;
		m_MovingTo = new Vector2(pathObject[m_MoveProcess].transform.localPosition.x, pathObject[m_MoveProcess].transform.localPosition.y);
		m_MoveProcess--;
		_BattleObject.SetBattleObjState(BattleObjectState.AStarMoving);
	}

	public static void AStarMove(BattleObject _BattleObject)
	{
		m_MoveTimer += Time.deltaTime;
		float num = m_MoveTimer / CommonVariables.TimeToMoveOneBlock;
		Vector2 vector = Vector2.Lerp(m_MovingFrom, m_MovingTo, num);
		_BattleObject.gameObject.transform.position = vector;
		SharedData.Instance().m_BattleController.SetCameraSmooth(_BattleObject);
		if (!(num >= 1f))
		{
			return;
		}
		Vector3Int gridPosition = _BattleObject.GetGridPosition();
		if (_BattleObject.targetGridList.Contains(gridPosition))
		{
			_BattleObject.BattleObjectEscape();
		}
		if (SharedData.Instance().m_BattleController.terrain.ContainsKey(gridPosition) && (!(_BattleObject.charadata.GetBattleValueByName("TrapImmune") > 0f) || (SharedData.Instance().m_BattleController.terrain[gridPosition].t_type != TerrainType.TrapBlast && SharedData.Instance().m_BattleController.terrain[gridPosition].t_type != TerrainType.TrapSeal)))
		{
			SharedData.Instance().m_BattleController.terrain[gridPosition].TerrainEffectOn();
			if (SharedData.Instance().m_BattleController.terrain.ContainsKey(gridPosition) && (SharedData.Instance().m_BattleController.terrain[gridPosition].t_type == TerrainType.Hell || SharedData.Instance().m_BattleController.terrain[gridPosition].t_type == TerrainType.Water))
			{
				m_MoveProcess = -1;
			}
		}
		BattleObject tmp = SharedData.Instance().m_BattleController.GetBattleObjectInPos(gridPosition, _BattleObject);
		if (tmp != null && tmp.race != _BattleObject.race && tmp.isInvisible)
		{
			if (SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == tmp && x.counterType == ActionType.Ambush) == null)
			{
				SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(tmp, ActionType.Ambush));
			}
			Vector3Int targetPos = default(Vector3Int);
			targetPos.x = Mathf.FloorToInt(m_MovingFrom.x / CommonVariables.MovementBlockSize);
			targetPos.y = Mathf.FloorToInt(Mathf.Abs(m_MovingFrom.y) / CommonVariables.MovementBlockSize);
			tmp.AdjustFace(targetPos);
			tmp.SetInvisible(_Invisible: false);
			_BattleObject.SetBattleObjState(BattleObjectState.RoundOff);
			SharedData.Instance().m_BattleController.SetFlowState(BattleControllerFlow.RoundOff);
			SharedData.Instance().m_BattleController.m_Revenge_TGT = _BattleObject;
		}
		if (_BattleObject.m_State == BattleObjectState.AStarMoving)
		{
			_BattleObject.SetBattleObjState(BattleObjectState.AStarWaiting);
		}
		m_MoveTimer = Mathf.Repeat(m_MoveTimer, CommonVariables.TimeToMoveOneBlock);
	}

	public static void Move(BattleObject _BattleObject, Vector3Int target)
	{
		AStarClean();
		SharedData.Instance().m_BattleController.m_curcor.SetPosition(target);
		if (_BattleObject.GetBuffByName("Goldenbell") != null)
		{
			_BattleObject.m_MenuController.UpdateCharacterInfo(_BattleObject);
		}
		_BattleObject.PlayAnimation(Aniname.aniname_walk);
		_BattleObject.PlayAudioClip(AudioClipEnum.walkClip);
		_BattleObject.SetBattleObjState(BattleObjectState.AStarInit);
		if (startPos.Equals(Vector3Int.zero))
		{
			Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(_BattleObject.transform.localPosition);
			startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		}
		endPos = target;
		AStarSearchPath(_BattleObject);
	}

	public static Vector3Int Trace(BattleObject _BattleObject, List<BattleObject> _opponents)
	{
		AStarClean();
		BattleObject battleObject = null;
		Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(_BattleObject.transform.localPosition);
		startPos = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		int num = int.MaxValue;
		foreach (BattleObject _opponent in _opponents)
		{
			if (!_opponent.isDead && !(_opponent == _BattleObject))
			{
				int heuristic = GetHeuristic(startPos, _opponent.GetGridPosition());
				if (heuristic < num)
				{
					num = heuristic;
					battleObject = _opponent;
				}
			}
		}
		endPos = battleObject.GetGridPosition();
		Vector3Int vector3Int2 = AStarSearchPathSub(_BattleObject);
		Vector3Int vector3Int3 = startPos;
		if (pathSave.ContainsKey(endPos))
		{
			vector3Int3 = ShowPath(_BattleObject, _trace: true);
		}
		else
		{
			endPos = vector3Int2;
			vector3Int3 = ShowPath(_BattleObject, _trace: true);
		}
		if (pathObject.Count == 0)
		{
			int num2 = int.MinValue;
			endPos = startPos;
			foreach (Vector3Int key in _BattleObject.unitRange.Keys)
			{
				if (!SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(key) && !SharedData.Instance().m_BattleController.CheckIsItemOnGrid(key))
				{
					int heuristic2 = GetHeuristic(startPos, key);
					if (num2 < heuristic2)
					{
						num2 = heuristic2;
						endPos = key;
					}
				}
			}
			AStarClean();
			vector3Int2 = AStarSearchPathSub(_BattleObject);
			if (pathSave.ContainsKey(endPos))
			{
				vector3Int3 = ShowPath(_BattleObject, _trace: true);
			}
			else
			{
				endPos = vector3Int2;
				vector3Int3 = ShowPath(_BattleObject, _trace: true);
			}
		}
		return vector3Int3;
	}

	public static void TraceMove(BattleObject _BattleObject)
	{
		_BattleObject.PlayAnimation(Aniname.aniname_walk);
		_BattleObject.PlayAudioClip(AudioClipEnum.walkClip);
		_BattleObject.SetBattleObjState(BattleObjectState.AStarWaiting);
	}

	public static void AStarSearchPath(BattleObject _BattleObject)
	{
		Vector3Int vector3Int = AStarSearchPathSub(_BattleObject);
		if (pathSave.ContainsKey(endPos))
		{
			ShowPath(_BattleObject);
			return;
		}
		endPos = vector3Int;
		ShowPath(_BattleObject);
	}

	private static Vector3Int AStarSearchPathSub(BattleObject _BattleObject)
	{
		search.Add(startPos, GetHeuristic(startPos, endPos));
		cost.Add(startPos, 0);
		hadSearch.Add(startPos);
		pathSave.Add(startPos, startPos);
		Vector3Int result = startPos;
		int num = int.MaxValue;
		while (search.Count > 0)
		{
			Vector3Int shortestPos = GetShortestPos();
			if (shortestPos.Equals(endPos))
			{
				break;
			}
			foreach (Vector3Int astarNeighbor in GetAstarNeighbors(_BattleObject, shortestPos))
			{
				if (hadSearch.Contains(astarNeighbor))
				{
					continue;
				}
				bool flag = false;
				if (SharedData.Instance().m_BattleController.terrain.ContainsKey(astarNeighbor))
				{
					if (SharedData.Instance().m_BattleController.terrain[astarNeighbor].t_type.ToString().Contains("Fire") && _BattleObject.BurnResist)
					{
						flag = true;
					}
					else if (SharedData.Instance().m_BattleController.terrain[astarNeighbor].t_type.ToString().Contains("Poison") && _BattleObject.PoisonResist)
					{
						flag = true;
					}
					else if (SharedData.Instance().m_BattleController.terrain[astarNeighbor].t_type.ToString().Contains("Trap") && _BattleObject.TrapResist)
					{
						flag = true;
					}
				}
				if (SharedData.Instance().m_BattleController.terrain.ContainsKey(astarNeighbor) && _BattleObject.isSpitObjDead && !_BattleObject.mad && !flag)
				{
					cost.Add(astarNeighbor, cost[shortestPos] + 1000);
				}
				else
				{
					cost.Add(astarNeighbor, cost[shortestPos] + 1);
				}
				int heuristic = GetHeuristic(astarNeighbor, endPos);
				search.Add(astarNeighbor, cost[astarNeighbor] + heuristic);
				pathSave.Add(astarNeighbor, shortestPos);
				if (heuristic < num)
				{
					num = heuristic;
					if (!isBattleObjOn[astarNeighbor])
					{
						result = astarNeighbor;
					}
				}
				hadSearch.Add(astarNeighbor);
			}
		}
		return result;
	}

	public static void AStarClean()
	{
		startPos = Vector3Int.zero;
		foreach (GameObject item in pathObject)
		{
			if (item != null)
			{
				item.gameObject.SetActive(value: false);
			}
		}
		pathObject.Clear();
		search.Clear();
		cost.Clear();
		pathSave.Clear();
		hadSearch.Clear();
	}

	public static List<Vector3Int> GetAStarPath(BattleObject _BattleObject, Vector3Int startPos, Vector3Int endPos)
	{
		AStarClean();
		List<Vector3Int> list = new List<Vector3Int>();
		search.Add(startPos, GetHeuristic(startPos, endPos));
		cost.Add(startPos, 0);
		hadSearch.Add(startPos);
		pathSave.Add(startPos, startPos);
		Vector3Int vector3Int = startPos;
		int num = int.MaxValue;
		Vector3Int zero = Vector3Int.zero;
		while (search.Count > 0)
		{
			zero = GetShortestPos();
			if (zero.Equals(endPos))
			{
				break;
			}
			foreach (Vector3Int astarNeighbor in GetAstarNeighbors(_BattleObject, zero))
			{
				if (hadSearch.Contains(astarNeighbor))
				{
					continue;
				}
				bool flag = false;
				if (SharedData.Instance().m_BattleController.terrain.ContainsKey(astarNeighbor))
				{
					if (SharedData.Instance().m_BattleController.terrain[astarNeighbor].t_type.ToString().Contains("Fire") && _BattleObject.BurnResist)
					{
						flag = true;
					}
					else if (SharedData.Instance().m_BattleController.terrain[astarNeighbor].t_type.ToString().Contains("Poison") && _BattleObject.PoisonResist)
					{
						flag = true;
					}
					else if (SharedData.Instance().m_BattleController.terrain[astarNeighbor].t_type.ToString().Contains("Trap") && _BattleObject.TrapResist)
					{
						flag = true;
					}
				}
				if (SharedData.Instance().m_BattleController.terrain.ContainsKey(astarNeighbor) && _BattleObject.isSpitObjDead && !_BattleObject.mad && !flag)
				{
					cost.Add(astarNeighbor, cost[zero] + 1000);
				}
				else
				{
					cost.Add(astarNeighbor, cost[zero] + 1);
				}
				int heuristic = GetHeuristic(astarNeighbor, endPos);
				search.Add(astarNeighbor, cost[astarNeighbor] + heuristic);
				pathSave.Add(astarNeighbor, zero);
				if (heuristic < num)
				{
					num = heuristic;
					if (!isBattleObjOn[astarNeighbor])
					{
						vector3Int = astarNeighbor;
					}
				}
				hadSearch.Add(astarNeighbor);
			}
		}
		if (!pathSave.ContainsKey(endPos))
		{
			endPos = vector3Int;
		}
		zero = endPos;
		while (!zero.Equals(startPos))
		{
			Vector3Int vector3Int2 = pathSave[zero];
			list.Add(zero);
			_ = list.Count;
			_ = 1;
			zero = vector3Int2;
		}
		return list;
	}

	private static Vector3Int ShowPath(BattleObject _BattleObject, bool _trace = false)
	{
		Vector3Int vector3Int = endPos;
		Vector3Int result = startPos;
		while (!vector3Int.Equals(startPos))
		{
			Vector3Int vector3Int2 = pathSave[vector3Int];
			if (!_trace || _BattleObject.unitRange.ContainsKey(vector3Int))
			{
				tablePrefab = RangePoolManager.instance.GetObjectFromPool("pathObject");
				tablePrefab.transform.localPosition = new Vector3(25 + vector3Int.x * 50, -25 - vector3Int.y * 50);
				pathObject.Add(tablePrefab);
				if (pathObject.Count == 1)
				{
					result = vector3Int;
				}
				tablePrefab.GetComponentInChildren<SpriteRenderer>().sortingOrder = ((SharedData.Instance().m_BattleController.m_underfoot_SortingOrder > 0) ? SharedData.Instance().m_BattleController.m_underfoot_SortingOrder : 0);
			}
			vector3Int = vector3Int2;
		}
		m_MoveProcess = pathObject.Count - 1;
		if (!_trace)
		{
			_BattleObject.SetBattleObjState(BattleObjectState.AStarWaiting);
		}
		return result;
	}

	public static int GetHeuristic(Vector3Int posA, Vector3Int posB)
	{
		return Mathf.Abs(posA.x - posB.x) + Mathf.Abs(posA.y - posB.y);
	}

	private static int GetHeuristic(BattleObject objA, BattleObject objB)
	{
		Vector3Int gridPosition = objA.GetGridPosition();
		Vector3Int gridPosition2 = objB.GetGridPosition();
		return GetHeuristic(gridPosition, gridPosition2);
	}

	private static Vector3Int GetShortestPos()
	{
		KeyValuePair<Vector3Int, int> keyValuePair = new KeyValuePair<Vector3Int, int>(Vector3Int.zero, int.MaxValue);
		foreach (KeyValuePair<Vector3Int, int> item in search)
		{
			if (item.Value < keyValuePair.Value)
			{
				keyValuePair = item;
			}
		}
		search.Remove(keyValuePair.Key);
		return keyValuePair.Key;
	}

	private static List<Vector3Int> GetAstarNeighbors(BattleObject _BattleObject, Vector3Int target)
	{
		List<Vector3Int> list = new List<Vector3Int>();
		Vector3Int vector3Int = target + Vector3Int.up;
		Vector3Int vector3Int2 = target + Vector3Int.right;
		Vector3Int vector3Int3 = target - Vector3Int.right;
		Vector3Int vector3Int4 = target - Vector3Int.up;
		if (vector3Int.y < SharedData.Instance().m_BattleController.mapSize.y && (_BattleObject.unitRange.ContainsKey(vector3Int) || (_BattleObject.isBlind && SharedData.Instance().m_BattleController.terrain.ContainsKey(vector3Int))))
		{
			if (_BattleObject.m_NoZOC)
			{
				if (_BattleObject.unitRange.ContainsKey(vector3Int))
				{
					list.Add(vector3Int);
				}
			}
			else if (!SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(vector3Int, _BattleObject) && !SharedData.Instance().m_BattleController.CheckIsItemOnGrid(vector3Int) && _BattleObject.unitRange.ContainsKey(vector3Int))
			{
				list.Add(vector3Int);
			}
		}
		if (vector3Int2.x < SharedData.Instance().m_BattleController.mapSize.x && (_BattleObject.unitRange.ContainsKey(vector3Int2) || (_BattleObject.isBlind && SharedData.Instance().m_BattleController.terrain.ContainsKey(vector3Int2))))
		{
			if (_BattleObject.m_NoZOC)
			{
				if (_BattleObject.unitRange.ContainsKey(vector3Int2))
				{
					list.Add(vector3Int2);
				}
			}
			else if (!SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(vector3Int2, _BattleObject) && !SharedData.Instance().m_BattleController.CheckIsItemOnGrid(vector3Int2) && _BattleObject.unitRange.ContainsKey(vector3Int2))
			{
				list.Add(vector3Int2);
			}
		}
		if (vector3Int3.x >= 0 && (_BattleObject.unitRange.ContainsKey(vector3Int3) || (_BattleObject.isBlind && SharedData.Instance().m_BattleController.terrain.ContainsKey(vector3Int3))))
		{
			if (_BattleObject.m_NoZOC)
			{
				if (_BattleObject.unitRange.ContainsKey(vector3Int3))
				{
					list.Add(vector3Int3);
				}
			}
			else if (!SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(vector3Int3, _BattleObject) && !SharedData.Instance().m_BattleController.CheckIsItemOnGrid(vector3Int3) && _BattleObject.unitRange.ContainsKey(vector3Int3))
			{
				list.Add(vector3Int3);
			}
		}
		if (vector3Int4.y >= 0 && (_BattleObject.unitRange.ContainsKey(vector3Int4) || (_BattleObject.isBlind && SharedData.Instance().m_BattleController.terrain.ContainsKey(vector3Int4))))
		{
			if (_BattleObject.m_NoZOC)
			{
				if (_BattleObject.unitRange.ContainsKey(vector3Int4))
				{
					list.Add(vector3Int4);
				}
			}
			else if (!SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(vector3Int4, _BattleObject) && !SharedData.Instance().m_BattleController.CheckIsItemOnGrid(vector3Int4) && _BattleObject.unitRange.ContainsKey(vector3Int4))
			{
				list.Add(vector3Int4);
			}
		}
		return list;
	}
}
