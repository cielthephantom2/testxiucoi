using System.Collections.Generic;
using UnityEngine;

public class gang_e06Table
{
	public class Row
	{
		public string id;

		public string type;

		public string head;

		public string head_EN;

		public string note;

		public string note_EN;

		public string head_Trans => CommonFunc.ShortLangSel(head, head_EN);

		public string note_Trans => CommonFunc.ShortLangSel(note, note_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				id = list[i][num++],
				type = list[i][num++],
				head = list[i][num++],
				head_EN = list[i][num++],
				note = list[i][num++],
				note_EN = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		return rowList.Find((Row x) => x.id == find);
	}

	public List<Row> FindAll_id(string find)
	{
		return rowList.FindAll((Row x) => x.id == find);
	}

	public Row Find_type(string find)
	{
		return rowList.Find((Row x) => x.type == find);
	}

	public List<Row> FindAll_type(string find)
	{
		return rowList.FindAll((Row x) => x.type == find);
	}

	public Row Find_head(string find)
	{
		return rowList.Find((Row x) => x.head == find);
	}

	public List<Row> FindAll_head(string find)
	{
		return rowList.FindAll((Row x) => x.head == find);
	}

	public Row Find_head_EN(string find)
	{
		return rowList.Find((Row x) => x.head_EN == find);
	}

	public List<Row> FindAll_head_EN(string find)
	{
		return rowList.FindAll((Row x) => x.head_EN == find);
	}

	public Row Find_note(string find)
	{
		return rowList.Find((Row x) => x.note == find);
	}

	public List<Row> FindAll_note(string find)
	{
		return rowList.FindAll((Row x) => x.note == find);
	}

	public Row Find_note_EN(string find)
	{
		return rowList.Find((Row x) => x.note_EN == find);
	}

	public List<Row> FindAll_note_EN(string find)
	{
		return rowList.FindAll((Row x) => x.note_EN == find);
	}
}
