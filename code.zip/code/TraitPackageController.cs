using System.Collections;
using System.Collections.Generic;
using System.Linq;
using SuperScrollView;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class TraitPackageController : MonoBehaviour
{
	public LoopGridView traitPackageLoopGrid;

	private int colCount = 7;

	public List<TraitItemData> mTraitPackageDataSourceMgr_Filter = new List<TraitItemData>();

	public List<string> traitIdList = new List<string>();

	public string currentEffectTraitIndex = "";

	public List<string> usedTraitIDList = new List<string>();

	public string currentEffectTraitID = "";

	public TraitNineGirdController customTraitNineGirdController;

	private GameObject currentSelectObj;

	private string currentSelectedID = "";

	private ScrollRect traitPanel;

	private Transform TraitInfo;

	private TraitPackageType traitPackageType;

	public bool isOpen => base.transform.Find("Panel").gameObject.activeInHierarchy;

	private void Start()
	{
		traitPanel = base.transform.Find("Panel/TraitPackage/Traits").GetComponent<ScrollRect>();
		TraitInfo = base.transform.Find("Panel/TraitPackage/TraitInfo");
		Button[] componentsInChildren = GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button button in componentsInChildren)
		{
			if (button.interactable)
			{
				EventTriggerListener.Get(button.gameObject).onClick = OnButtonClick;
			}
		}
		traitPackageLoopGrid.InitGridView(mTraitPackageDataSourceMgr_Filter.Count, OnGetPackageItemByRowColumn);
		InitLoopGridViewColumnCount();
	}

	private LoopGridViewItem OnGetPackageItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		TraitItemData traitItemData = mTraitPackageDataSourceMgr_Filter[index];
		if (traitItemData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("TraitIcon");
		TraitIconController component = loopGridViewItem.GetComponent<TraitIconController>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		component.InitTraitIcon(traitItemData, isChain: false, checkused: true, reName: true);
		EventTriggerListener.Get(loopGridViewItem.gameObject).onClick = OnButtonClick;
		return loopGridViewItem;
	}

	private void InitLoopGridViewColumnCount()
	{
		colCount = Mathf.FloorToInt((traitPackageLoopGrid.transform.Find("Viewport").GetComponent<RectTransform>().rect.width - (float)traitPackageLoopGrid.Padding.left) / (traitPackageLoopGrid.ItemSize.x + traitPackageLoopGrid.ItemPadding.x));
		traitPackageLoopGrid.SetGridFixedGroupCount(GridFixedType.ColumnCountFixed, colCount);
		traitPackageLoopGrid.UpdateColumnRowCount();
	}

	private void Update()
	{
		if (!CommonFunc.IsHoverOpen() && isOpen)
		{
			if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
			{
				OnButtonClick(base.transform.Find("Panel/TraitPackage/Title/Return").gameObject);
			}
			else if (InputSystemCustom.Instance().UI.SelectTrait.WasReleasedThisFrame())
			{
				OnButtonClick(base.transform.Find("Panel/TraitPackage/TraitInfo/Btns/Choose").gameObject);
			}
			else if (InputSystemCustom.Instance().UI.UnEquipTrait.WasReleasedThisFrame())
			{
				OnButtonClick(base.transform.Find("Panel/TraitPackage/TraitInfo/Btns/Cancel").gameObject);
			}
			else if (InputSystemCustom.Instance().UI.ShowFullName.WasReleasedThisFrame())
			{
				OnButtonClick(base.transform.Find("Panel/TraitPackage/Title/FullNameArea/FullName").gameObject);
			}
			if (EventSystem.current.currentSelectedGameObject != null && currentSelectObj != EventSystem.current.currentSelectedGameObject && EventSystem.current.currentSelectedGameObject.name == "Btn")
			{
				RefreshTraitInfo(EventSystem.current.currentSelectedGameObject);
			}
		}
	}

	private void SetCanvasGroup(bool isActive)
	{
		if (customTraitNineGirdController?.starter3Controller != null)
		{
			customTraitNineGirdController.starter3Controller.GetComponent<CanvasGroup>().interactable = isActive;
		}
		if (customTraitNineGirdController?.statusSub3 != null)
		{
			customTraitNineGirdController.statusSub3.GetComponent<CanvasGroup>().interactable = isActive;
		}
		if (customTraitNineGirdController?.createWgController != null)
		{
			customTraitNineGirdController.createWgController.GetComponent<CanvasGroup>().interactable = isActive;
		}
		if (SharedData.Instance().evolutionWgController != null)
		{
			SharedData.Instance().evolutionWgController.GetComponent<CanvasGroup>().interactable = isActive;
		}
		SharedData.Instance().m_StatusMain.GetComponent<CanvasGroup>().interactable = isActive;
		SharedData.Instance().m_StatusSub3.GetComponent<CanvasGroup>().interactable = isActive;
		SharedData.Instance().m_StatusSub4.GetComponent<CanvasGroup>().interactable = isActive;
		SharedData.Instance().m_StatusSub5.GetComponent<CanvasGroup>().interactable = isActive;
	}

	public void OpenTraitPackage(TraitPackageType _traitPackageType, List<string> _traitIdList, string _currentEffectTraitIndex, List<string> _usedTraitIDList, string _currentEffectTraitID)
	{
		base.transform.Find("Panel").GetComponent<Image>().enabled = true;
		EventSystem.current.SetSelectedGameObject(null);
		SetCanvasGroup(isActive: false);
		base.transform.Find("Panel").gameObject.SetActive(value: true);
		SharedData.Instance().LoadSceneStackAdd("TraitPackage");
		base.transform.Find("Panel/TraitPackage/Title/FullNameArea/FullName/Checkmark").gameObject.SetActive(SharedData.Instance().isShowFullName);
		traitPackageType = _traitPackageType;
		traitIdList = _traitIdList;
		currentEffectTraitIndex = _currentEffectTraitIndex;
		usedTraitIDList = _usedTraitIDList;
		currentEffectTraitID = _currentEffectTraitID;
		InitTraitPackage();
	}

	public void CloseTraitPackage()
	{
		if (SharedData.Instance().m_StatusMain.gameObject.activeInHierarchy)
		{
			SharedData.Instance().m_StatusMain.UpdateCurrentSlot();
			SharedData.Instance().m_StatusMain.UpdateCharaInfo();
		}
		currentSelectObj = null;
		traitPackageType = TraitPackageType.None;
		SetCanvasGroup(isActive: true);
		CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
		base.transform.Find("Panel").gameObject.SetActive(value: false);
		SharedData.Instance().LoadSceneStackRemove("TraitPackage");
	}

	private void InitTraitPackage()
	{
		mTraitPackageDataSourceMgr_Filter = new List<TraitItemData>();
		List<string> list = new List<string>();
		if (SharedData.Instance().evolutionWgController != null)
		{
			foreach (KeyValuePair<string, TraitIconController> item2 in SharedData.Instance().evolutionWgController._traitDict)
			{
				if (item2.Value.traitItemData == null || item2.Value.traitItemData.b06Row == null)
				{
					continue;
				}
				string[] array = item2.Value.traitItemData.b06Row.traitEquipIndex.Split("&");
				foreach (string item in array)
				{
					if (!list.Contains(item))
					{
						list.Add(item);
					}
				}
			}
		}
		list.Clear();
		foreach (string traitId in traitIdList)
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(traitId);
			if (row == null)
			{
				continue;
			}
			TraitItemData traitItemData = new TraitItemData
			{
				b06Row = row,
				showIndex = row.traitEquipIndex
			};
			if (traitPackageType == TraitPackageType.AllTraits)
			{
				if (!traitItemData.b06Row.isTitle.Equals("0"))
				{
					continue;
				}
				if (SharedData.Instance().createWgController != null || SharedData.Instance().evolutionWgController != null)
				{
					if (SharedData.Instance().createWgController != null && !traitItemData.b06Row.createType.Equals("0"))
					{
						mTraitPackageDataSourceMgr_Filter.Add(traitItemData);
					}
					if (SharedData.Instance().evolutionWgController != null && !traitItemData.b06Row.breaktype.Equals("0") && !list.Contains(traitItemData.b06Row.traitEquipIndex))
					{
						mTraitPackageDataSourceMgr_Filter.Add(traitItemData);
					}
				}
				else
				{
					mTraitPackageDataSourceMgr_Filter.Add(traitItemData);
				}
			}
			else if (traitPackageType == TraitPackageType.Title)
			{
				if (traitItemData.b06Row.isTitle.Equals("1"))
				{
					mTraitPackageDataSourceMgr_Filter.Add(traitItemData);
				}
			}
			else if (traitPackageType == TraitPackageType.IndexTraits && traitItemData.b06Row.isTitle.Equals("0") && traitItemData.b06Row.traitEquipIndex.Split("&").Contains(currentEffectTraitIndex))
			{
				mTraitPackageDataSourceMgr_Filter.Add(traitItemData);
			}
		}
		int num = colCount - mTraitPackageDataSourceMgr_Filter.Count % colCount;
		if (num == 0)
		{
			num = colCount;
		}
		while (--num >= 0)
		{
			mTraitPackageDataSourceMgr_Filter.Add(new TraitItemData());
		}
		traitPackageLoopGrid.SetListItemCount(mTraitPackageDataSourceMgr_Filter.Count, resetPos: false);
		traitPackageLoopGrid.RefreshAllShownItem();
		traitPackageLoopGrid.MovePanelToItemByIndex(0);
		StartCoroutine(DelaySelectTrait(0));
	}

	private IEnumerator DelaySelectTrait(int _index)
	{
		yield return null;
		GameObject gameObject = traitPackageLoopGrid.GetShownItemByItemIndex(_index)?.transform.Find("Btn").gameObject;
		if (gameObject != null)
		{
			RefreshTraitInfo(gameObject);
			EventSystem.current.SetSelectedGameObject(gameObject);
		}
	}

	private void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MonoBehaviour.print("OnButtonClick -> " + go.name);
		if (go.name.Equals("Return"))
		{
			CloseTraitPackage();
		}
		else if (go.name.Equals("Choose"))
		{
			if (SharedData.Instance().evolutionWgController != null)
			{
				SharedData.Instance().evolutionWgController.CreatePanel2.Find("Traits/Trait|" + SharedData.Instance().evolutionWgController.currentSelectTraitIndex).GetComponent<TraitIconController>().InitTraitIcon(currentSelectedID);
				SharedData.Instance().evolutionWgController.RefreshTraitEffect();
			}
			else
			{
				if (traitPackageType != TraitPackageType.Title && customTraitNineGirdController != null)
				{
					customTraitNineGirdController.TraitDict[currentEffectTraitIndex] = currentSelectedID;
					customTraitNineGirdController.transform.Find("Trait|" + currentEffectTraitIndex).GetComponent<TraitIconController>().InitTraitIcon(currentSelectedID, currentEffectTraitIndex);
					if (customTraitNineGirdController.starter3Controller != null)
					{
						customTraitNineGirdController.starter3Controller.CustomTrait();
					}
					if (customTraitNineGirdController.statusSub3 != null)
					{
						customTraitNineGirdController.statusSub3.EquipTrait();
					}
					if (customTraitNineGirdController.createWgController != null)
					{
						customTraitNineGirdController.createWgController.RefreshTraitEffect();
					}
				}
				if (traitPackageType == TraitPackageType.Title && customTraitNineGirdController.statusSub3 != null)
				{
					customTraitNineGirdController.statusSub3.curdata.m_currentTitleID = currentSelectedID;
					gang_b06Table.Row row = CommonResourcesData.b06.Find_id(currentSelectedID);
					customTraitNineGirdController.statusSub3.transform.Find("Panel/Title/Text").GetComponent<Text>().text = row.name_Trans;
				}
			}
			CloseTraitPackage();
		}
		else if (go.name.Equals("Cancel"))
		{
			if (SharedData.Instance().evolutionWgController != null)
			{
				SharedData.Instance().evolutionWgController.CreatePanel2.Find("Traits/Trait|" + SharedData.Instance().evolutionWgController.currentSelectTraitIndex).GetComponent<TraitIconController>().InitTraitIcon("");
				SharedData.Instance().evolutionWgController.RefreshTraitEffect();
			}
			else
			{
				if (traitPackageType != TraitPackageType.Title && customTraitNineGirdController != null)
				{
					customTraitNineGirdController.TraitDict[currentEffectTraitIndex] = "";
					customTraitNineGirdController.transform.Find("Trait|" + currentEffectTraitIndex).GetComponent<TraitIconController>().InitTraitIcon("");
					if (customTraitNineGirdController.starter3Controller != null)
					{
						customTraitNineGirdController.starter3Controller.CustomTrait();
					}
					if (customTraitNineGirdController.statusSub3 != null)
					{
						customTraitNineGirdController.statusSub3.EquipTrait();
					}
					if (customTraitNineGirdController.createWgController != null)
					{
						customTraitNineGirdController.createWgController.RefreshTraitEffect();
					}
				}
				if (traitPackageType == TraitPackageType.Title && customTraitNineGirdController != null && customTraitNineGirdController.statusSub3 != null)
				{
					customTraitNineGirdController.statusSub3.curdata.m_currentTitleID = "";
					customTraitNineGirdController.statusSub3.transform.Find("Panel/Title/Text").GetComponent<Text>().text = "";
				}
			}
			CloseTraitPackage();
		}
		else
		{
			if (!go.name.Equals("FullName"))
			{
				return;
			}
			SharedData.Instance().isShowFullName = !SharedData.Instance().isShowFullName;
			base.transform.Find("Panel/TraitPackage/Title/FullNameArea/FullName/Checkmark").gameObject.SetActive(SharedData.Instance().isShowFullName);
			foreach (TraitIconController item in traitPanel.content.GetComponentsInChildren<TraitIconController>().ToList())
			{
				item.transform.Find("FullName").gameObject.SetActive(SharedData.Instance().isShowFullName);
			}
		}
	}

	private void RefreshTraitInfo(GameObject traitIcon)
	{
		bool activeInHierarchy = TraitInfo.gameObject.activeInHierarchy;
		TraitIconController componentInParent = traitIcon.GetComponentInParent<TraitIconController>();
		currentSelectObj = traitIcon;
		if (componentInParent == null || componentInParent.traitItemData.b06Row == null)
		{
			currentSelectedID = "";
			TraitInfo.gameObject.SetActive(value: false);
			traitPanel.viewport.GetComponent<RectTransform>().offsetMin = Vector2.zero;
			return;
		}
		TraitInfo.gameObject.SetActive(value: true);
		currentSelectedID = componentInParent.traitItemData.b06Row.id;
		Vector2 offsetMin = traitPanel.viewport.GetComponent<RectTransform>().offsetMin;
		offsetMin.y = TraitInfo.GetComponent<RectTransform>().rect.height;
		traitPanel.viewport.GetComponent<RectTransform>().offsetMin = offsetMin;
		Vector3 vector = traitPanel.content.GetComponent<RectTransform>().anchoredPosition;
		if (!activeInHierarchy && traitPanel.content.GetComponent<RectTransform>().rect.height > traitPanel.viewport.GetComponent<RectTransform>().rect.height)
		{
			vector.y += offsetMin.y;
			traitPanel.content.GetComponent<RectTransform>().anchoredPosition = vector;
		}
		if (traitPackageType == TraitPackageType.AllTraits)
		{
			TraitInfo.Find("Btns/Cancel").gameObject.SetActive(value: false);
			TraitInfo.Find("Btns/Choose").gameObject.SetActive(value: false);
			if (SharedData.Instance().evolutionWgController != null)
			{
				TraitInfo.Find("Btns/Cancel").gameObject.SetActive(currentEffectTraitID == componentInParent.traitItemData.b06Row.id);
				bool active = true;
				foreach (KeyValuePair<string, TraitIconController> item in SharedData.Instance().evolutionWgController._traitDict)
				{
					if (item.Value.traitItemData.b06Row != null && item.Value.traitItemData.b06Row.id.Equals(componentInParent.traitItemData.b06Row.id))
					{
						active = false;
					}
				}
				TraitInfo.Find("Btns/Choose").gameObject.SetActive(active);
			}
		}
		else
		{
			TraitInfo.Find("Btns/Cancel").gameObject.SetActive(currentEffectTraitID == componentInParent.traitItemData.b06Row.id);
			TraitInfo.Find("Btns/Choose").gameObject.SetActive(value: true);
			TraitInfo.Find("Btns/Choose").GetComponent<Button>().interactable = true;
			if (componentInParent.transform.Find("Used").gameObject.activeInHierarchy && currentEffectTraitID != componentInParent.traitItemData.b06Row.id)
			{
				TraitInfo.Find("Btns/Choose").gameObject.SetActive(value: false);
			}
			else if (customTraitNineGirdController != null && customTraitNineGirdController.starter3Controller != null)
			{
				TraitInfo.Find("Btns/Choose/TraitCost/Num").GetComponent<Text>().text = componentInParent.traitItemData.b06Row.traitCost;
				if (customTraitNineGirdController.TraitDict[currentEffectTraitIndex] == componentInParent.traitItemData.b06Row.id)
				{
					TraitInfo.Find("Btns/Choose").gameObject.SetActive(value: false);
				}
				else if (int.Parse(componentInParent.traitItemData.b06Row.traitCost) > int.Parse(customTraitNineGirdController.starter3Controller.transform.Find("Panel/Specify/Status/Title/AtPoints/Num").GetComponent<Text>().text))
				{
					TraitInfo.Find("Btns/Choose").GetComponent<Button>().interactable = false;
				}
			}
		}
		TraitInfo.Find("Name").GetComponent<Text>().text = componentInParent.traitItemData.b06Row.name_Trans;
		TraitInfo.Find("TraitIcon").GetComponent<TraitIconController>().InitTraitIcon(componentInParent.traitItemData.b06Row.id, componentInParent.traitItemData.b06Row.traitEquipIndex);
		TraitInfo.Find("TraitInfo/Add1").GetComponent<Text>().text = componentInParent.traitItemData.b06Row.note_Trans;
		TraitInfo.Find("TraitInfo/Info").GetComponent<Text>().text = componentInParent.traitItemData.b06Row.comment_Trans;
		if (!(SharedData.Instance().createWgController != null) && !(SharedData.Instance().evolutionWgController != null))
		{
			return;
		}
		gang_b12Table.Row row = CommonResourcesData.b12.Find_ID(componentInParent.traitItemData.b06Row.createType);
		gang_b12Table.Row row2 = CommonResourcesData.b12.Find_ID(componentInParent.traitItemData.b06Row.breaktype);
		if (SharedData.Instance().createWgController != null)
		{
			if (row != null)
			{
				Text component = TraitInfo.Find("TraitInfo/Info").GetComponent<Text>();
				component.text = component.text + "\n· " + CommonFunc.I18nGetLocalizedValue("I18N_CreatWugong") + " <color=#F3B846>" + row.Note + "</color>";
			}
			else
			{
				TraitInfo.Find("Btns/Choose").gameObject.SetActive(value: false);
			}
		}
		if (SharedData.Instance().evolutionWgController != null)
		{
			if (row2 != null)
			{
				Text component = TraitInfo.Find("TraitInfo/Info").GetComponent<Text>();
				component.text = component.text + "\n· " + CommonFunc.I18nGetLocalizedValue("I18N_BreakWugong") + " <color=#FF9E0D>" + row2.Note + "</color>";
			}
			else
			{
				TraitInfo.Find("Btns/Choose").gameObject.SetActive(value: false);
			}
		}
	}
}
