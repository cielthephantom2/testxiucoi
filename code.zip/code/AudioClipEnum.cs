public enum AudioClipEnum
{
	None,
	attack1Clip,
	attack2Clip,
	damageClip,
	deathClip,
	attackStandClip,
	missClip,
	hitClip,
	heal1Clip,
	walkClip,
	Water,
	Hell
}
