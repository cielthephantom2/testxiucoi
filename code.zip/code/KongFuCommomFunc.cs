public static class KongFuCommomFunc
{
	public static bool CheckWugongHaveEffect(gang_b03Table.Row _kf, string _skill)
	{
		if (_kf.Skill1.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (_kf.Skill2.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (_kf.Skill3.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (_kf.Skill4.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (_kf.Skill5.StartsWith(_skill + "&"))
		{
			return true;
		}
		return false;
	}

	public static bool CheckWugongHaveEffect(KongFuData kongFuData, string _skill)
	{
		if (kongFuData == null)
		{
			return false;
		}
		return CheckWugongHaveEffect(kongFuData.kf, _skill);
	}

	public static bool CheckItemSkillHaveEffect(gang_b07Table.Row item, string _skill)
	{
		if (item.Skills1.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (item.Skills2.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (item.Skills3.StartsWith(_skill + "&"))
		{
			return true;
		}
		if (item.Skills4.StartsWith(_skill + "&"))
		{
			return true;
		}
		return false;
	}
}
