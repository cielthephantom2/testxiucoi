using System.Collections.Generic;
using UnityEngine;

public class gang_b11Table
{
	public class Row
	{
		public string ID;

		public string Arena;

		public string Wave;

		public string Members;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Arena = list[i][num++],
				Wave = list[i][num++],
				Members = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Arena(string find)
	{
		return rowList.Find((Row x) => x.Arena == find);
	}

	public List<Row> FindAll_Arena(string find)
	{
		return rowList.FindAll((Row x) => x.Arena == find);
	}

	public Row Find_Wave(string find)
	{
		return rowList.Find((Row x) => x.Wave == find);
	}

	public List<Row> FindAll_Wave(string find)
	{
		return rowList.FindAll((Row x) => x.Wave == find);
	}

	public Row Find_Members(string find)
	{
		return rowList.Find((Row x) => x.Members == find);
	}

	public List<Row> FindAll_Members(string find)
	{
		return rowList.FindAll((Row x) => x.Members == find);
	}
}
