using System.Collections.Generic;
using UnityEngine;

public class I18nData
{
	private static I18nData instance;

	public gang_tableI18n tableI18N;

	public static I18nData Instance(bool init = false)
	{
		if (init || instance == null)
		{
			instance = null;
			instance = new I18nData();
			instance.Init();
		}
		return instance;
	}

	private void Init()
	{
		tableI18N = new gang_tableI18n();
		foreach (string item in new List<string>
		{
			"gang_a01", "gang_a07", "gang_b02", "gang_b02_set", "gang_b03", "gang_b06", "gang_b07", "gang_b09", "gang_b10", "gang_b12",
			"gang_c03", "gang_a02", "gang_b01", "gang_b04", "gang_b04_Random"
		})
		{
			tableI18N.AddLoad(Resources.Load<TextAsset>("Datas/Dictionary/" + item + "_TransDict"));
		}
	}
}
