using Spine.Unity;
using UnityEngine;

public class BasicPlayerController : MonoBehaviour
{
	public Direction m_Direction = Direction.Down;

	public SkeletonAnimation[] m_Animations;

	private Vector2 m_Facing = Vector2.zero;

	private void Start()
	{
		m_Animations = base.gameObject.GetComponentsInChildren<SkeletonAnimation>(includeInactive: true);
		InputSystemCustom.Instance().Player.Enable();
	}

	private void Update()
	{
		InputUpdate();
	}

	public void Face(Direction direction, bool isInit = false)
	{
		if (isInit || direction != m_Direction)
		{
			m_Direction = direction;
			switch (direction)
			{
			case Direction.Left:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = 1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			case Direction.Up:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: true);
				break;
			case Direction.Right:
				m_Animations[0].gameObject.SetActive(value: false);
				m_Animations[1].gameObject.SetActive(value: true);
				m_Animations[1].skeleton.ScaleX = -1f;
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			default:
				m_Animations[0].gameObject.SetActive(value: true);
				m_Animations[1].gameObject.SetActive(value: false);
				m_Animations[2].gameObject.SetActive(value: false);
				break;
			}
		}
	}

	private int InputUpdate()
	{
		int result = 0;
		m_Facing = Vector2.zero;
		Vector2 zero = Vector2.zero;
		zero = InputSystemCustom.Instance().Player.PlayerMove.ReadValue<Vector2>();
		if (Mathf.Abs(zero.x) > Mathf.Abs(zero.y))
		{
			zero.y = 0f;
		}
		else
		{
			zero.x = 0f;
		}
		if (zero.x != 0f)
		{
			m_Facing.x = zero.x;
			m_Facing.y = 0f;
			if (zero.x > 0f)
			{
				Face(Direction.Left);
				result = 4;
			}
			else
			{
				Face(Direction.Right);
				result = 2;
			}
		}
		else if (zero.y != 0f)
		{
			m_Facing.x = 0f;
			m_Facing.y = zero.y;
			if (zero.y > 0f)
			{
				Face(Direction.Up);
				result = 3;
			}
			else
			{
				Face(Direction.Down);
				result = 1;
			}
		}
		m_Facing.Normalize();
		Vector3 position = base.transform.position;
		position.x += m_Facing.x * Time.deltaTime * 100f;
		position.y += m_Facing.y * Time.deltaTime * 100f;
		base.transform.position = position;
		if (zero.SqrMagnitude() > 0f)
		{
			PlayAnimation(Aniname.aniname_walk);
		}
		else
		{
			PlayAnimation(Aniname.aniname_stand);
			result = 0;
		}
		return result;
	}

	public void PlayAnimation(string animation, bool loop = true, bool compensate = true, float timescale = 1f)
	{
		if (loop && (animation.Equals(Aniname.aniname_die) || animation.Equals(Aniname.aniname_die)))
		{
			loop = false;
		}
		if (m_Animations[0].AnimationName != animation)
		{
			m_Animations[0].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[0].skeleton.SetToSetupPose();
				m_Animations[0].AnimationState.ClearTracks();
			}
			m_Animations[0].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[1].AnimationName != animation)
		{
			m_Animations[1].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[1].skeleton.SetToSetupPose();
				m_Animations[1].AnimationState.ClearTracks();
			}
			m_Animations[1].AnimationState.SetAnimation(0, animation, loop);
		}
		if (m_Animations[2].AnimationName != animation)
		{
			m_Animations[2].timeScale = timescale;
			if (!compensate)
			{
				m_Animations[2].skeleton.SetToSetupPose();
				m_Animations[2].AnimationState.ClearTracks();
			}
			m_Animations[2].AnimationState.SetAnimation(0, animation, loop);
		}
	}
}
