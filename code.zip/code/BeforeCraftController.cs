using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BeforeCraftController : MonoBehaviour
{
	private GameObject ChoosePanel;

	private Sprite NormalSprite;

	private Color NormalColor = new Color(14f / 51f, 0.23137255f, 16f / 85f);

	private Sprite SelectedSprite;

	private Color SelectedColor = new Color(47f / 51f, 76f / 85f, 0.8235294f);

	private Button[] buttons;

	private bool isExiting;

	private void Awake()
	{
		NormalSprite = Resources.Load("images/01-border0508-menu-button-off", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/0508-menu-button-special", typeof(Sprite)) as Sprite;
	}

	private void Start()
	{
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		ChoosePanel = base.transform.Find("Choose").gameObject;
		buttons = ChoosePanel.GetComponentsInChildren<Button>(includeInactive: true);
		Button[] array = buttons;
		for (int i = 0; i < array.Length; i++)
		{
			EventTriggerListener.Get(array[i].gameObject).onClick = OnButtonClick;
		}
		GameObject gameObject = ChoosePanel.transform.Find("Team").gameObject;
		buttons = gameObject.GetComponentsInChildren<Button>(includeInactive: true);
		int num = 0;
		bool flag = false;
		array = buttons;
		foreach (Button button in array)
		{
			if (num == 0)
			{
				string playerid = SharedData.Instance().playerid;
				flag = playerid.Equals(SharedData.Instance().CurrentChara);
				RefreshBtn(button, flag);
				CharaData charaData = SharedData.Instance().GetCharaData(playerid);
				button.GetComponentInChildren<Text>().text = charaData.Indexs_Name["Name"].stringValue;
				button.name = "Team|" + playerid + "|" + (flag ? "1" : "0");
			}
			else if (num <= SharedData.Instance().FollowList.Count)
			{
				string text = SharedData.Instance().FollowList[num - 1];
				flag = text.Equals(SharedData.Instance().CurrentChara);
				RefreshBtn(button, flag);
				gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(text);
				button.GetComponentInChildren<Text>().text = row.Name_Trans;
				button.name = "Team|" + text + "|" + (flag ? "1" : "0");
			}
			else
			{
				button.GetComponentInChildren<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Vacancy");
				button.interactable = false;
			}
			num++;
		}
	}

	private void RefreshBtn(Button _b, bool _selected)
	{
		if (_selected)
		{
			_b.GetComponent<Image>().sprite = SelectedSprite;
			_b.GetComponentInChildren<Text>().color = SelectedColor;
		}
		else
		{
			_b.GetComponent<Image>().sprite = NormalSprite;
			_b.GetComponentInChildren<Text>().color = NormalColor;
		}
	}

	private void OnButtonClick(GameObject go)
	{
		if (!(go == null) && go.activeInHierarchy && !(go.GetComponent<Button>() == null) && go.GetComponent<Button>().IsInteractable())
		{
			string[] array = go.name.Split('|');
			if (array[0] == "Team")
			{
				SharedData.Instance().CurrentChara = array[1];
				ExitScene();
			}
		}
	}

	private void ExitScene()
	{
		if (isExiting)
		{
			return;
		}
		isExiting = true;
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			int index = SharedData.Instance().LoadedSceneStack.Count - 1;
			SharedData.Instance().LoadedSceneStack.RemoveAt(index);
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				index = SharedData.Instance().LoadedSceneStack.Count - 1;
				SceneManager.LoadScene(SharedData.Instance().LoadedSceneStack[index], LoadSceneMode.Additive);
			}
		}
		SceneManager.UnloadSceneAsync("BeforeCraft");
	}
}
