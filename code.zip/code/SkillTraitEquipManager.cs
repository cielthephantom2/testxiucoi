using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using DG.Tweening;
using UnityEngine;

public static class SkillTraitEquipManager
{
	private const float EPSINON = 1E-05f;

	public static List<Vector3Int> m_GatherPosList = new List<Vector3Int>();

	public static void RunLastAttack(BattleObject _attacker, Vector3 _pos)
	{
		SwapPosSkiiManage.SwapPosSkill(_attacker, _pos);
		ImpactSkiiManage.ImpactSkill(_attacker, _pos);
		if (_attacker.charadata.GetBattleValueByName("Drunk") >= 25f && _attacker.charadata.GetBattleValueByName("Missresist") > 0f)
		{
			_attacker.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_DrunkMiss") + "<color=green> " + CommonFunc.I18nGetLocalizedValue("I18N_Resist") + " </color>", "Drunk");
		}
		if ("10001".Equals(_attacker.m_SkillRow.kf.ID) && _attacker.charadata.m_EquipTraitDict.ContainsValue("SCP99"))
		{
			_attacker.AddDamageInfo("<color=green>" + CommonFunc.I18nGetLocalizedValue("I18N_TakeItEasy") + "</color>", "SCP99ME");
		}
		RunSkill(_attacker, _attacker, 0f, isSelf: true);
		RunTraitSkill(_attacker, _attacker, 0f, isSelf: true);
		RunEquipSkill(_attacker, _attacker, 0f, isSelf: true);
		SharedData.Instance().m_BattleController.m_BattleInterBG.DOFade(0f, 0.2f);
	}

	public static void RunLastBeHit(BattleObject _attacker, BattleObject _defender, float injury = 0f, bool isSelf = false)
	{
		if ("601".Equals(_attacker.m_SkillRow.kf.Style) && SharedData.Instance().useItemID != "")
		{
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(SharedData.Instance().useItemID);
			if (row != null)
			{
				UseItemInBattle(row, _attacker, _defender);
			}
		}
		if (_attacker.CheckBuffEffectOn("Invisible") && Random.Range(0f, 1f) < _attacker.charadata.GetBattleValueByName("InvisibleAttackDizzy"))
		{
			_defender.AddBuff("Dizzy", "Skill", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_Dizzy_1"));
		}
		else if (_attacker.m_SkillRow.kf.Attckstyle.Contains("A|07") && Random.Range(0f, 1f) < _attacker.charadata.GetBattleValueByName("ThroughAttackDizzy"))
		{
			_defender.AddBuff("Dizzy", "Skill", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_Dizzy_1"));
		}
		else if (_attacker.m_SkillRow != null && KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "Impact") && Random.Range(0f, 1f) < _attacker.charadata.GetBattleValueByName("ImpactAttackDizzy"))
		{
			_defender.AddBuff("Dizzy", "Skill", 0f, 1, CommonFunc.I18nGetLocalizedValue("I18N_Dizzy_1"));
		}
		if (!(_attacker != _defender) || !(_attacker.race != _defender.race) || _defender.CheckBuffEffectOn("Goldenbell") || _defender.charadata.GetBattleValueByName("Seal") >= 25f || _defender.isUnSealNextRound)
		{
			return;
		}
		float battleValueByName = _defender.charadata.GetBattleValueByName("Formless");
		ActionType currentObjActionType = SharedData.Instance().m_BattleController.GetCurrentObjActionType();
		if (Random.Range(0f, 1f) <= battleValueByName && !_defender.isDead && currentObjActionType == ActionType.None && !_attacker.m_SkillRow.isSwapPosSkill && !_attacker.m_SkillRow.kf.Attckstyle.StartsWith("A|06"))
		{
			if (_defender.CheckCouldCounter() && SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == _defender && x.counterType == ActionType.Formless) == null)
			{
				SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(_defender, ActionType.Formless));
			}
		}
		else if (_defender.CheckHasCounterWugong() && !_defender.isDead && currentObjActionType == ActionType.None && !_attacker.m_SkillRow.isSwapPosSkill && !_attacker.m_SkillRow.kf.Attckstyle.StartsWith("A|06"))
		{
			if (_defender.CheckCouldCounter() && SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == _defender && x.counterType == ActionType.WugongCounter) == null)
			{
				SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(_defender, ActionType.WugongCounter));
			}
		}
		else if (InjuryCalManager.CheckCouldReturnWugong(_attacker, _defender) && !_defender.isDead && currentObjActionType == ActionType.None && !_attacker.m_SkillRow.isSwapPosSkill && !_attacker.m_SkillRow.kf.Attckstyle.StartsWith("A|06"))
		{
			if (_defender.CheckCouldCounter() && SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == _defender && x.counterType == ActionType.Return) == null)
			{
				SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(_defender, ActionType.Return));
			}
			_defender.AddDamageInfo("<color=#E74722>" + CommonFunc.I18nGetLocalizedValue("I18N_SeeThrough") + "</color>", "See through");
		}
		else if (_defender.CheckBuffEffectOn("Return") && !_defender.isDead && currentObjActionType == ActionType.None && !_attacker.m_SkillRow.isSwapPosSkill && !_attacker.m_SkillRow.kf.Attckstyle.StartsWith("A|06") && _defender.CheckCouldCounter() && SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == _defender && x.counterType == ActionType.FormlessSuper) == null)
		{
			SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(_defender, ActionType.FormlessSuper));
		}
	}

	public static void RunSkill(BattleObject _attacker, BattleObject _defender, float injury = 0f, bool isSelf = false)
	{
		SkillInfo skillInfo = new SkillInfo();
		skillInfo.Init(_attacker.m_SkillRow, _attacker);
		bool isClose = false;
		if (_attacker.m_SkillRow.kf.Style == "9601" && (_attacker.GetEffectOnSuperWugongID() == _attacker.m_SkillRow.kf.ID || _attacker.GetEffectOnFormationWugongID() == _attacker.m_SkillRow.kf.ID))
		{
			isClose = true;
		}
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			if (skillInfo.sTarget[i] == "-2" || skillInfo.sTarget[i] == "-1" || (Mathf.Abs(skillInfo.sOddNum[i]) < 1E-05f && skillInfo.sTurnNum[i] == 0 && Mathf.Abs(skillInfo.sValueNum[i]) < 1E-05f) || (isSelf && (skillInfo.sTarget[i] == "2" || skillInfo.sTarget[i] == "0")) || (!isSelf && (skillInfo.sTarget[i] == "1" || skillInfo.sTarget[i] == "0")) || !(Random.Range(0f, 1f) <= skillInfo.sOddNum[i]) || !CheckIsSkillEffect(_attacker, _defender, skillInfo.sSkillEc[i]))
			{
				continue;
			}
			List<BattleObject> list = new List<BattleObject>();
			if (isSelf && skillInfo.sTarget[i] == "1")
			{
				if (skillInfo.sEffectRange[i] == "0")
				{
					list.Add(_attacker);
				}
				else if (skillInfo.sEffectRange[i] == "1")
				{
					list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race == _attacker.race && !x.isDead);
				}
				else if (skillInfo.sEffectRange[i] == "2")
				{
					list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race != _attacker.race && !x.isDead);
				}
				else if (skillInfo.sEffectRange[i] == "3")
				{
					list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead);
				}
				else if (skillInfo.sEffectRange[i] == "4")
				{
					list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				}
				else if (skillInfo.sEffectRange[i] == "5")
				{
					list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race != _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				}
				else if (skillInfo.sEffectRange[i] == "6")
				{
					list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				}
			}
			else if (skillInfo.sEffectRange[i] == "0")
			{
				list.Add(_defender);
			}
			else if (skillInfo.sEffectRange[i] == "4")
			{
				if (_defender.race == _attacker.race)
				{
					list.Add(_defender);
				}
			}
			else if (skillInfo.sEffectRange[i] == "5" && _defender.race != _attacker.race)
			{
				list.Add(_defender);
			}
			foreach (BattleObject item in list)
			{
				RunSkillDetails(_attacker, item, skillInfo, i, "Wugong|" + _attacker.m_SkillRow.kf.ID + "|" + _attacker.gameObject.name + "|", injury, isClose);
			}
		}
		if (isSelf = false)
		{
			_defender.charadata.Indexs_Name["Burn"].fightValue += 25f;
		}
		_attacker.RefreshEffectOn();
		_defender.RefreshEffectOn();
		_attacker.AlreadyAttackObjCount++;
	}

	public static void RunSkillDetails(BattleObject _attacker, BattleObject _defender, SkillInfo _skillInfo, int _index, string _source, float injury = 0f, bool isClose = false)
	{
		string keyWord = _skillInfo.sName[_index];
		float finalval = _skillInfo.sValueNum[_index];
		int num = _skillInfo.sTurnNum[_index];
		string text = " " + CommonFunc.I18nGetLocalizedValue("I18N_Resist");
		string text2 = SharedData.Instance().m_A01NameRowDirec[keyWord].NameScene_Trans + " ";
		string text3 = "";
		string text4 = "";
		string text5 = "";
		if (finalval != 0f)
		{
			List<string> list = new List<string>
			{
				"Fend", "Draw", "Steal", "StealATK", "Bleed", "Poison", "Drunk", "Hurt", "Seal", "Burn",
				"Mad", "Spit", "MPburn", "HPsteal", "MPsteal", "Impact", "Swap", "AllWugongDownExceptMelody", "Poisonturn", "Hurtturn",
				"Bleedturn", "Madturn", "Burnturn", "Summon"
			};
			text3 = ((!keyWord.EndsWith("down") && !keyWord.EndsWith("minus") && !list.Contains(keyWord)) ? ((finalval > 0f) ? "<color=#7fd142>" : "<color=#e74722>") : ((finalval > 0f) ? "<color=#e74722>" : "<color=#7fd142>"));
			float num2 = (SharedData.Instance().m_A01NameRowDirec[keyWord].Type.Equals("2") ? 100f : 1f);
			string text6 = (SharedData.Instance().m_A01NameRowDirec[keyWord].Type.Equals("2") ? "%" : "");
			text4 = ((finalval > 0f) ? "+" : "-") + Mathf.Abs(Mathf.Floor(num2 * finalval)) + text6;
			text5 = "</color> ";
		}
		string text7 = ((num > 0 && int.Parse(_skillInfo.sTurn[_index]) >= 0) ? (" " + num + " " + CommonFunc.I18nGetLocalizedValue("I18N_Round")) : "");
		string damageinfo = text2 + text3 + text4 + text5 + text7;
		if (isClose)
		{
			Debug.LogWarning("//关闭绝学");
			_defender.RemoveBuff(_defender.m_Buffs.Find((BuffData x) => x.source == _source && x.name == keyWord));
			return;
		}
		if (_defender.charadata.GetBattleValueByName(keyWord + "resist") > 0f)
		{
			_defender.AddDamageInfo(text2 + text, "");
			return;
		}
		switch (keyWord)
		{
		case "HP":
		{
			float num7 = Mathf.Floor(finalval);
			if (num7 > 0f)
			{
				num7 = Mathf.Floor(finalval * (1f + _attacker.charadata.GetBattleValueByName("Medical") / 100f));
				if (_attacker.m_SkillRow != null)
				{
					num7 += Mathf.Floor(num7 + (KongFuCommomFunc.CheckWugongHaveEffect(_attacker.m_SkillRow.kf, "ATKCureup") ? (finalval / 100f) : 0f));
				}
				_defender.AddDamageInfo(num7.ToString(), "HEAL");
			}
			else
			{
				string text8 = Mathf.Abs(num7).ToString();
				_defender.AddDamageInfo(text8.ToString(), "DAMAGE");
			}
			break;
		}
		case "MP":
			_defender.AddDamageInfo(finalval.ToString(), "HEALMP");
			break;
		case "MPburn":
		{
			float num4 = _defender.charadata.GetBattleValueByName("MP") * (1f - CommonFunc.saturate(_defender.charadata.GetBattleValueByName("Hurt") / float.Parse(SharedData.Instance().m_A01NameRowDirec["Hurt"].Limit, CultureInfo.InvariantCulture)));
			float num5 = Mathf.Floor(finalval * num4);
			if (num5 > 0f)
			{
				_defender.AddBuffInfo(keyWord, num5.ToString());
			}
			break;
		}
		case "Drunk":
		case "Hurt":
		case "Poison":
		case "Bleed":
		case "Burn":
		case "Seal":
		case "Mad":
		{
			_defender.AddDamageInfo(damageinfo, keyWord);
			float num8 = _defender.charadata.Indexs_Name[keyWord].fightValue + finalval;
			if (num8 < 0f)
			{
				num8 = 0f;
			}
			_defender.charadata.Indexs_Name[keyWord].fightValue = num8;
			break;
		}
		case "HurtToBleed":
		case "HurtToBurn":
		case "SealToHurt":
		case "HurtToMad":
		case "BleedToSeal":
		{
			string key = keyWord.Substring(0, keyWord.IndexOf("To"));
			string key2 = keyWord.Substring(keyWord.IndexOf("To") + 2, keyWord.Length - (keyWord.IndexOf("To") + 2));
			_defender.charadata.Indexs_Name[key2].fightValue += _defender.charadata.Indexs_Name[key].fightValue;
			_defender.charadata.Indexs_Name[key].fightValue = 0f;
			_defender.AddDamageInfo(text2, "");
			if (_attacker.charadata.GetBattleValueByName("DebuffTransHealHp") > 0f)
			{
				foreach (BattleObject allBattleObj in _attacker.m_BattleController.allBattleObjs)
				{
					if (!allBattleObj.isDead && !(allBattleObj.race != _attacker.race))
					{
						allBattleObj.AddDamageInfo((allBattleObj.charadata.GetBattleValueByName("HP") * _attacker.charadata.GetBattleValueByName("DebuffTransHealHp")).ToString(), "HEAL");
					}
				}
			}
			if (!(_attacker.charadata.GetBattleValueByName("FoMoZhiJian") > 0f))
			{
				break;
			}
			_attacker.AddDamageInfo("+25", "Mad");
			_attacker.charadata.Indexs_Name[keyWord].fightValue += 25f;
			BuffData buffData = _attacker.m_Buffs.Find((BuffData x) => x.source == "FoMoZhiJian");
			if (buffData != null)
			{
				if (buffData.value < 5f)
				{
					buffData.value += 1f;
				}
			}
			else
			{
				_attacker.AddBuff("FoMoZhiJian", "FoMoZhiJian", 1f, int.MaxValue);
			}
			break;
		}
		case "DebuffToMad":
		{
			float num3 = _defender.charadata.Indexs_Name["Seal"].fightValue + _defender.charadata.Indexs_Name["Hurt"].fightValue + _defender.charadata.Indexs_Name["Poison"].fightValue + _defender.charadata.Indexs_Name["Bleed"].fightValue + _defender.charadata.Indexs_Name["Burn"].fightValue + _defender.charadata.Indexs_Name["Drunk"].fightValue;
			_defender.charadata.Indexs_Name["Mad"].fightValue += num3;
			_defender.charadata.Indexs_Name["Seal"].fightValue = 0f;
			_defender.charadata.Indexs_Name["Hurt"].fightValue = 0f;
			_defender.charadata.Indexs_Name["Poison"].fightValue = 0f;
			_defender.charadata.Indexs_Name["Bleed"].fightValue = 0f;
			_defender.charadata.Indexs_Name["Burn"].fightValue = 0f;
			_defender.charadata.Indexs_Name["Drunk"].fightValue = 0f;
			_defender.AddDamageInfo(text2, "");
			if (_attacker.charadata.GetBattleValueByName("DebuffTransHealHp") > 0f)
			{
				foreach (BattleObject allBattleObj2 in _attacker.m_BattleController.allBattleObjs)
				{
					if (!allBattleObj2.isDead && !(allBattleObj2.race != _attacker.race))
					{
						allBattleObj2.AddDamageInfo((allBattleObj2.charadata.GetBattleValueByName("HP") * _attacker.charadata.GetBattleValueByName("DebuffTransHealHp")).ToString(), "HEAL");
					}
				}
			}
			if (!(_attacker.charadata.GetBattleValueByName("FoMoZhiJian") > 0f))
			{
				break;
			}
			_attacker.AddDamageInfo("+25", "Mad");
			_attacker.charadata.Indexs_Name[keyWord].fightValue += 25f;
			BuffData buffData2 = _attacker.m_Buffs.Find((BuffData x) => x.source == "FoMoZhiJian");
			if (buffData2 != null)
			{
				if (buffData2.value < 5f)
				{
					buffData2.value += 1f;
				}
			}
			else
			{
				_attacker.AddBuff("FoMoZhiJian", "FoMoZhiJian", 1f, int.MaxValue);
			}
			break;
		}
		case "Crit":
		case "Crit1":
		case "Combo":
		case "Rebound":
		case "ATK":
		case "DEF":
		case "SP":
		case "HPturn":
		case "MPturn":
		case "ATKdown":
		case "DEFdown":
		case "SPdown":
		case "Medical":
		case "Melody":
		case "Wineart":
		case "Steal":
		case "AllyCountATKup":
		case "HeresyDEFup":
		case "ZaxueDEFup":
		case "Poisonturn":
		case "Hurtturn":
		case "Bleedturn":
		case "Madturn":
		case "Burnturn":
		case "Drunkturn":
		case "SuperWugongXiBo1":
		case "SuperWugongBeiGu1":
		case "SuperWugongQuanZhen1":
		case "SuperWugongQuanZhen2":
		case "SuperWugongJinWu1":
		case "Yijinjing":
		case "Xisuijing":
		case "HPplus":
		case "MPplus":
		case "ATKplus":
		case "DEFplus":
		case "SPplus":
		case "HPminus":
		case "MPminus":
		case "ATKminus":
		case "DEFminus":
		case "SPminus":
		case "Blind":
		case "Fear":
		case "Dizzy":
		case "DodgeAdd":
		case "Multikill":
		case "Runaway":
		case "Invisible":
		case "Goldenbell":
		case "BanSwordWugong":
		case "BanKnifeWugong":
		case "BanStickWugong":
		case "BanHandWugong":
		case "BanFingerWugong":
		case "BanSpecialWugong":
		case "BanMelodyWugong":
		case "BanDartsWugong":
		case "BanWineartWugong":
		case "BanBuddhismWugong":
		case "BanTaoistWugong":
		case "BanConfucianistWugong":
		case "BanHeresyWugong":
		case "BanZaxueWugong":
		case "BanWeaponWugong":
		case "Return":
		case "Dexterous":
		case "FinalInjuryPlus":
		case "FinalInjuryMinus":
		case "AllMove":
		case "STRminus":
		case "AGIminus":
		case "BONminus":
		case "WILminus":
		case "LERminus":
		case "MORminus":
		case "STRdown":
		case "AGIdown":
		case "BONdown":
		case "WILdown":
		case "LERdown":
		case "MORdown":
		case "InvisibleATKup":
		case "DizzyATKup":
		case "WugongSwordATKup":
		case "WugongKnifeATKup":
		case "WugongStickATKup":
		case "WugongHandATKup":
		case "WugongFingerATKup":
		case "WugongSpecialATKup":
		case "WugongMelodyATKup":
		case "WugongDartsATKup":
		case "WugongWineartATKup":
		case "BuddhismWugongATKup":
		case "TaoistWugongATKup":
		case "ConfucianistWugongATKup":
		case "HeresyWugongATKup":
		case "ZaxueWugongATKup":
		case "EnemyDamageMinus":
		case "ClearDebuffTurn":
		case "Wugong_1210_Enhance":
		case "Wugong_10011_Enhance":
		case "Wugong_10213_Enhance":
		case "Wugong_10208_Enhance":
		case "Wugong_2209_Enhance":
		case "Wugong_1033_Enhance":
		case "Wugong_1207_Enhance":
		case "Wugong_2010_Enhance":
		case "Wugong_3204_Enhance":
		case "Wugong_1204_Enhance":
		case "Wugong_2011_Enhance":
		case "ATKaura":
		case "DEFaura":
		case "SPaura":
		case "Critaura":
		case "Crit1aura":
		case "Comboaura":
		case "BurnATKup":
		case "PoisonHealHpTurn":
		{
			bool durnk = false;
			bool flag = true;
			if (_source.StartsWith("Item|") && (keyWord.Equals("SP") || keyWord.Equals("ATK") || keyWord.Equals("DEF") || keyWord.Equals("Combo") || keyWord.Equals("Crit") || keyWord.Equals("Crit1")))
			{
				if (_defender.charadata.GetBattleValueByName("Drunkresist") <= 0f)
				{
					float num9 = _defender.charadata.Indexs_Name[keyWord].drunkbuffValue + finalval;
					if (num9 < 0f)
					{
						num9 = 0f;
					}
					_defender.charadata.Indexs_Name[keyWord].drunkbuffValue = num9;
					durnk = true;
				}
				else
				{
					flag = false;
				}
			}
			if (!flag)
			{
				break;
			}
			_defender.AddBuff(keyWord, _source, finalval, num, "", durnk);
			_defender.AddDamageInfo(damageinfo, keyWord);
			if (keyWord == "Dexterous")
			{
				ResidualShadow2 residualShadow = _attacker.gameObject.GetComponent<ResidualShadow2>();
				if (residualShadow == null)
				{
					residualShadow = _attacker.gameObject.AddComponent<ResidualShadow2>();
				}
				residualShadow.EnableResidualShadow();
			}
			break;
		}
		case "HurtLeadDizzy":
		case "SealLeadDizzy":
		case "PoisonLeadDizzy":
		case "BleedLeadDizzy":
		case "MadLeadDizzy":
		case "BurnLeadDizzy":
		case "EunuchLeadDizzy":
			if ((keyWord == "EunuchLeadDizzy" && _defender.charadata.m_TraitList.Contains("10129")) || _defender.charadata.GetBattleValueByName(keyWord.Replace("LeadDizzy", "")) >= 25f)
			{
				_defender.RemoveBuff(_defender.m_Buffs.Find((BuffData x) => x.source == _source && x.name == keyWord));
				_defender.AddBuff("Dizzy", _source, finalval, num);
				_defender.AddDamageInfo(damageinfo, keyWord);
			}
			break;
		case "Spit":
			_defender.RemoveBuff(_defender.GetBuffByName(keyWord));
			_defender.AddBuff(keyWord, _source, finalval, num);
			if (_attacker.race.Equals("player"))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1022");
			}
			break;
		case "Ironvest":
			_defender.RemoveBuff(_defender.m_Buffs.Find((BuffData x) => x.source == _source && x.name == keyWord));
			_defender.AddBuff(keyWord, _source, finalval, num);
			_defender.AddDamageInfo(text2, "");
			break;
		case "HealBlind":
		case "HealFear":
		case "HealDizzy":
			if (_defender.RemoveBuff(_defender.GetBuffByName(keyWord.Replace("Heal", ""))))
			{
				_defender.AddDamageInfo(text2, "");
			}
			break;
		case "HPsteal":
		case "MPsteal":
			SkillKeyWordManage.StealHpOrMp(_attacker, _defender, keyWord, injury, finalval);
			break;
		case "HPstealaround":
		{
			foreach (BattleObject allBattleObj3 in SharedData.Instance().m_BattleController.allBattleObjs)
			{
				if (!allBattleObj3.isDead && !(allBattleObj3 == _attacker) && !(allBattleObj3.race == _attacker.race))
				{
					Vector3Int vector3Int = allBattleObj3.GetGridPosition() - _attacker.GetGridPosition();
					if (vector3Int == Vector3Int.up || vector3Int == Vector3Int.down || vector3Int == Vector3Int.left || vector3Int == Vector3Int.right)
					{
						SkillKeyWordManage.StealHpOrMp(_attacker, allBattleObj3, "HPsteal", allBattleObj3.charadata.m_Hp, finalval);
					}
				}
			}
			break;
		}
		case "HPSwap":
		case "MPSwap":
			SkillKeyWordManage.TransHPOrMP(_attacker, _defender, keyWord.Replace("Swap", ""), finalval);
			break;
		case "ExchangeHpToMp":
		case "ExchangeMpToHp":
			SkillKeyWordManage.ExchangeHpBetweenMp(_attacker, _defender, keyWord, finalval);
			break;
		case "StealATK":
			if (_attacker.race == "player")
			{
				int steal = Mathf.RoundToInt(finalval + _attacker.charadata.GetBattleValueByName("Steal"));
				SkillKeyWordManage.StealAnItem(_attacker, _defender, steal);
			}
			break;
		case "Impact":
			ImpactSkiiManage.isAlreadImpact = true;
			ImpactSkiiManage.ImpactSkill(_attacker, _defender, injury);
			break;
		case "SwapPos":
			SwapPosSkiiManage.SwapPosSkill(_attacker, _defender);
			break;
		case "TurtleBreath":
			_defender.AddBuff(keyWord, _source, finalval, num + 1);
			_defender.BattleObjectDead(_isActive: true);
			break;
		case "DIEtogether":
			_attacker.AddDamageInfo("9999", "DAMAGE");
			_defender.AddDamageInfo("9999", "DAMAGE");
			break;
		case "Sacrifice":
			_attacker.AddDamageInfo(_attacker.charadata.m_Hp.ToString(), "DAMAGE");
			_defender.AddDamageInfo(_defender.charadata.GetBattleValueByName("HP").ToString(), "HEAL");
			break;
		case "DeathImmediately":
			_defender.AddDamageInfo(_defender.charadata.GetBattleValueByName("HP").ToString(), "DAMAGE");
			break;
		case "Gather":
		{
			if (!(_attacker != _defender) || SharedData.Instance().m_BattleController.GetGridNeighbors(_attacker.GetGridPosition()).Contains(_defender.GetGridPosition()))
			{
				break;
			}
			int num6 = int.MaxValue;
			Vector3Int item = Vector3Int.zero;
			Vector3Int gridPosition = _attacker.GetGridPosition();
			foreach (Vector3Int item2 in SharedData.Instance().m_BattleController.obstacle)
			{
				if (SharedData.Instance().m_BattleController.GetBattleObjectInPos(item2) == null && !m_GatherPosList.Contains(item2) && Mathf.Abs(item2.x - gridPosition.x) + Mathf.Abs(item2.y - gridPosition.y) < num6)
				{
					num6 = Mathf.Abs(item2.x - gridPosition.x) + Mathf.Abs(item2.y - gridPosition.y);
					item = item2;
				}
			}
			m_GatherPosList.Add(item);
			Vector3 pos = new Vector3(25 + item.x * 50, -25 - item.y * 50);
			_defender.StartCoroutine(_defender.GatherMove(pos));
			break;
		}
		case "RoleAssist":
		{
			BattleObject battleObject = SharedData.Instance().m_BattleController.allBattleObjs.Find((BattleObject x) => x.charadata.m_Id == finalval.ToString() && !x.isDead && x.race == _attacker.race && x != _attacker);
			if (battleObject != null && !battleObject.isSealFreeze)
			{
				if (SharedData.Instance().m_BattleController.ExtraActionOrder.Find((ActionOrderItem x) => x.battleObject == battleObject && x.counterType == ActionType.RoleAssist) == null)
				{
					SharedData.Instance().m_BattleController.ExtraActionOrder.Add(new ActionOrderItem(battleObject, ActionType.RoleAssist));
				}
				Debug.Log(battleObject.name + "人物连携");
			}
			break;
		}
		case "TriggerBurn":
		case "TriggerPoison":
		case "TriggerHurt":
		case "TriggerSeal":
		case "TriggerMad":
		case "TriggerBleed":
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, keyWord.Replace("Trigger", ""), injury);
			break;
		case "TriggerAllDebuff":
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, "Burn", injury);
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, "Poison", injury);
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, "Hurt", injury);
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, "Seal", injury);
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, "Mad", injury);
			SkillKeyWordManage.TriggerDebuff(_attacker, _defender, "Bleed", injury);
			break;
		case "ClearDebuff":
			SkillKeyWordManage.ClearDebuffFunction(_attacker, _defender, injury);
			break;
		case "ClearGainBuff":
			SkillKeyWordManage.ClearGainBuffFunction(_attacker, _defender, injury);
			break;
		case "ClearAllBuff":
			SkillKeyWordManage.ClearDebuffFunction(_attacker, _defender, injury);
			SkillKeyWordManage.ClearGainBuffFunction(_attacker, _defender, injury);
			break;
		case "DrawDebuff":
			SkillKeyWordManage.ExchangeDebuff(_defender, _attacker, "Mad");
			SkillKeyWordManage.ExchangeDebuff(_defender, _attacker, "Hurt");
			SkillKeyWordManage.ExchangeDebuff(_defender, _attacker, "Poison");
			SkillKeyWordManage.ExchangeDebuff(_defender, _attacker, "Bleed");
			SkillKeyWordManage.ExchangeDebuff(_defender, _attacker, "Burn");
			break;
		case "DistributeDebuff":
		{
			float rate = 1f / (float)_attacker.attackObjs.Count;
			SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Mad", rate);
			SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Hurt", rate);
			SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Poison", rate);
			SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Bleed", rate);
			SkillKeyWordManage.ExchangeDebuff(_attacker, _defender, "Burn", rate);
			break;
		}
		case "StealGainBuff":
			SkillKeyWordManage.StealGainBuff(_attacker, _defender);
			break;
		case "Bribe":
			SharedData.Instance().m_BattleController.RebellionProcess(_defender, RebellionType.Bribe);
			break;
		case "Charm":
			SharedData.Instance().m_BattleController.RebellionProcess(_defender, RebellionType.Charm);
			break;
		case "Temptation":
			SharedData.Instance().m_BattleController.RebellionProcess(_defender, RebellionType.Temptation, num);
			break;
		case "ControlMad":
			SharedData.Instance().m_BattleController.RebellionProcess(_defender, RebellionType.ControlMad, num);
			break;
		case "SaveMad":
			SharedData.Instance().m_BattleController.RebellionProcess(_defender, RebellionType.SaveMad);
			break;
		case "ElfBall":
		case "Recruithuman":
		case "Recruitanimal":
		{
			List<string> list2 = null;
			if (keyWord == "Recruithuman")
			{
				list2 = CommonResourcesData.b10.Find_ID("2001").Members.Split("|").ToList();
			}
			else if (keyWord == "Recruitanimal" || keyWord == "ElfBall")
			{
				list2 = CommonResourcesData.b10.Find_ID("2002").Members.Split("|").ToList();
			}
			if (list2.Contains(_defender.charadata.m_B01Id))
			{
				if (Random.Range(0f, 1f) < 1f - _defender.charadata.m_Hp / _defender.charadata.GetBattleValueByName("HP"))
				{
					if (SharedData.Instance().m_BattleController.Rebellion(_defender, int.MaxValue, RebellionType.ElfBall))
					{
						SharedData.Instance().m_MenuController.OpenInteruptInfo(_defender, _defender.charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SubdueSuccess"));
						_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_Yummy"), "");
					}
					else
					{
						SharedData.Instance().m_MenuController.OpenInteruptInfo(_defender, _defender.charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SubdueFailed"));
						_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_NotEnought"), "");
					}
				}
				else
				{
					SharedData.Instance().m_MenuController.OpenInteruptInfo(_defender, _defender.charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SubdueFailed"));
					_defender.AddDamageInfo(CommonFunc.I18nGetLocalizedValue("I18N_NotEnought"), "");
				}
			}
			else
			{
				SharedData.Instance().m_MenuController.OpenInteruptInfo(_defender, _defender.charadata.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_SubdueDisable"));
				_defender.AddDamageInfo(_defender.charadata.Indexs_Name["Name"].stringValue + CommonFunc.I18nGetLocalizedValue("I18N_CanNotSubdue"), "");
			}
			break;
		}
		}
	}

	public static bool CheckIsSkillEffect(BattleObject _attacker, BattleObject _defender, string _skillEc)
	{
		bool flag = true;
		if (_skillEc != "0")
		{
			flag = false;
			List<BattleObject> list = new List<BattleObject>();
			string[] array = _skillEc.Split('|');
			string text = array[0];
			string[] array2 = array[1].Split('_');
			switch (text)
			{
			case "SELF":
				list.Add(_attacker);
				break;
			case "SelectTeammate":
				list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				break;
			case "SelectEnemy":
				list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race != _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				break;
			case "SelectAny":
				list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				break;
			case "AnyTeammate":
				list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == _attacker.race);
				break;
			case "AnyEnemy":
				list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race != _attacker.race);
				break;
			case "Any":
				list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead);
				break;
			}
			foreach (BattleObject item in list)
			{
				if (array2[0] == "PARA")
				{
					float battleValueByName = item.charadata.GetBattleValueByName(array2[1]);
					if (array2[2] == ">")
					{
						flag = battleValueByName >= float.Parse(array2[3], CultureInfo.InvariantCulture) + 1f;
					}
					else if (array2[2] == "<")
					{
						flag = battleValueByName <= float.Parse(array2[3], CultureInfo.InvariantCulture) - 1f;
					}
					else if (array2[2] == "=")
					{
						flag = battleValueByName == float.Parse(array2[3], CultureInfo.InvariantCulture);
					}
					if (flag)
					{
						break;
					}
				}
				else if (array2[0] == "SEX")
				{
					flag = array2[2] == item.sex;
					if (flag)
					{
						break;
					}
				}
				else if (array2[0] == "TRAIT")
				{
					flag = item.charadata.m_TraitList.Contains(array2[2]);
					if (flag)
					{
						break;
					}
				}
			}
			Debug.Log("Skill have effect condition = " + _skillEc + " isEffect = " + flag);
		}
		return flag;
	}

	public static void RunTraitSkill(BattleObject _attacker, BattleObject _defender, float injury, bool isSelf = false, bool isInitCharacter = false)
	{
		List<string> list = new List<string>();
		foreach (KeyValuePair<string, string> item in _attacker.charadata.m_EquipTraitDict)
		{
			if (!(item.Value == ""))
			{
				list.Add(item.Value);
			}
		}
		if (_attacker.charadata.m_currentTitleID != "")
		{
			list.Add(_attacker.charadata.m_currentTitleID);
		}
		foreach (string item2 in list)
		{
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item2);
			List<string> skillList = new List<string> { row.Skills1, row.Skills2, row.Skills3 };
			List<string> skillEcList = new List<string> { row.Skills1Ec, row.Skills2Ec, row.Skills3Ec };
			SkillInfo skillInfo = new SkillInfo();
			skillInfo.InitSkill(skillList, skillEcList);
			for (int i = 0; i <= skillInfo.sid; i++)
			{
				if (skillInfo.sName[i] == "" || (isSelf && !isInitCharacter && skillInfo.sTarget[i] != "1") || (isSelf && isInitCharacter && skillInfo.sTarget[i] != "0") || (!isSelf && !isInitCharacter && skillInfo.sTarget[i] != "2") || !(Random.Range(0f, 1f) < skillInfo.sOddNum[i]) || !CheckIsSkillEffect(_attacker, _defender, skillInfo.sSkillEc[i]))
				{
					continue;
				}
				List<BattleObject> list2 = new List<BattleObject>();
				if (isSelf && (isInitCharacter || skillInfo.sTarget[i] == "1"))
				{
					if (skillInfo.sEffectRange[i] == "0")
					{
						list2.Add(_attacker);
					}
					else if (skillInfo.sEffectRange[i] == "1")
					{
						list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race == _attacker.race && !x.isDead);
					}
					else if (skillInfo.sEffectRange[i] == "2")
					{
						list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race != _attacker.race && !x.isDead);
					}
					else if (skillInfo.sEffectRange[i] == "3")
					{
						list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead);
					}
					else if (skillInfo.sEffectRange[i] == "4")
					{
						list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
					}
					else if (skillInfo.sEffectRange[i] == "5")
					{
						list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race != _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
					}
					else if (skillInfo.sEffectRange[i] == "6")
					{
						list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
					}
				}
				else
				{
					list2.Add(_defender);
				}
				foreach (BattleObject item3 in list2)
				{
					RunSkillDetails(_attacker, item3, skillInfo, i, "Trait|" + row.id + "|" + _attacker.gameObject.name + "|", injury);
					item3.RefreshEffectOn();
					_attacker.RefreshEffectOn();
				}
			}
		}
	}

	public static void RunEquipSkill(BattleObject _attacker, BattleObject _defender, float injury = 0f, bool isSelf = false, bool isInitCharacter = false)
	{
		foreach (string item in _attacker.charadata.m_EquipSlot)
		{
			if (!(item != "0"))
			{
				continue;
			}
			gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(item);
			gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(row.Relateid);
			SkillInfo skillInfo = new SkillInfo();
			List<string> skillList = new List<string> { row2.Skills1 };
			List<string> skillEcList = new List<string> { row2.Skills1Ec };
			skillInfo.InitSkill(skillList, skillEcList, row2.Enhance);
			for (int i = 0; i <= skillInfo.sid; i++)
			{
				if ((isSelf && !isInitCharacter && skillInfo.sTarget[i] != "1") || (isSelf && isInitCharacter && skillInfo.sTarget[i] != "0") || (!isSelf && !isInitCharacter && skillInfo.sTarget[i] != "2") || !(Random.Range(0f, 1f) < skillInfo.sOddNum[i]) || !CheckIsSkillEffect(_attacker, _defender, skillInfo.sSkillEc[i]))
				{
					continue;
				}
				List<BattleObject> list = new List<BattleObject>();
				if (isSelf && (isInitCharacter || skillInfo.sTarget[i] == "1"))
				{
					if (skillInfo.sEffectRange[i] == "0")
					{
						list.Add(_attacker);
					}
					else if (skillInfo.sEffectRange[i] == "1")
					{
						list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race == _attacker.race && !x.isDead);
					}
					else if (skillInfo.sEffectRange[i] == "2")
					{
						list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race != _attacker.race && !x.isDead);
					}
					else if (skillInfo.sEffectRange[i] == "3")
					{
						list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead);
					}
					else if (skillInfo.sEffectRange[i] == "4")
					{
						list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
					}
					else if (skillInfo.sEffectRange[i] == "5")
					{
						list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race != _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
					}
					else if (skillInfo.sEffectRange[i] == "6")
					{
						list = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
					}
				}
				else
				{
					list.Add(_defender);
				}
				foreach (BattleObject item2 in list)
				{
					RunSkillDetails(_attacker, item2, skillInfo, i, "Equip|" + item + "|" + _attacker.gameObject.name + "|", injury);
					item2.RefreshEffectOn();
					_attacker.RefreshEffectOn();
				}
			}
		}
		string find = _attacker.charadata.m_EquipSlot[0] + "|" + _attacker.charadata.m_EquipSlot[1] + "|" + _attacker.charadata.m_EquipSlot[2];
		gang_b02SetTable.Row row3 = CommonResourcesData.b02Set.Find_Set(find);
		if (row3 == null)
		{
			return;
		}
		SkillInfo skillInfo2 = new SkillInfo();
		List<string> skillList2 = new List<string> { row3.Skills1, row3.Skills2, row3.Skills3 };
		List<string> skillEcList2 = new List<string> { row3.Skills1Ec, row3.Skills2Ec, row3.Skills3Ec };
		skillInfo2.InitSkill(skillList2, skillEcList2);
		for (int j = 0; j <= skillInfo2.sid; j++)
		{
			if ((isSelf && !isInitCharacter && skillInfo2.sTarget[j] != "1") || (isSelf && isInitCharacter && skillInfo2.sTarget[j] != "0") || (!isSelf && !isInitCharacter && skillInfo2.sTarget[j] != "2") || !(Random.Range(0f, 1f) < skillInfo2.sOddNum[j]) || !CheckIsSkillEffect(_attacker, _defender, skillInfo2.sSkillEc[j]))
			{
				continue;
			}
			List<BattleObject> list2 = new List<BattleObject>();
			if (isSelf && (isInitCharacter || skillInfo2.sTarget[j] == "1"))
			{
				if (skillInfo2.sEffectRange[j] == "0")
				{
					list2.Add(_attacker);
				}
				else if (skillInfo2.sEffectRange[j] == "1")
				{
					list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race == _attacker.race && !x.isDead);
				}
				else if (skillInfo2.sEffectRange[j] == "2")
				{
					list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => x.race != _attacker.race && !x.isDead);
				}
				else if (skillInfo2.sEffectRange[j] == "3")
				{
					list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead);
				}
				else if (skillInfo2.sEffectRange[j] == "4")
				{
					list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race == _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				}
				else if (skillInfo2.sEffectRange[j] == "5")
				{
					list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && x.race != _attacker.race && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				}
				else if (skillInfo2.sEffectRange[j] == "6")
				{
					list2 = SharedData.Instance().m_BattleController.allBattleObjs.FindAll((BattleObject x) => !x.isDead && _attacker.attackSelectRange.Contains(x.GetGridPosition()));
				}
			}
			else
			{
				list2.Add(_defender);
			}
			foreach (BattleObject item3 in list2)
			{
				RunSkillDetails(_attacker, item3, skillInfo2, j, "Equip|" + row3.ID + "|" + _attacker.gameObject.name + "|", injury);
				item3.RefreshEffectOn();
				_attacker.RefreshEffectOn();
			}
		}
	}

	public static void UseItemInBattle(gang_b07Table.Row _b07row, BattleObject _attacker, BattleObject _defender)
	{
		SkillInfo skillInfo = new SkillInfo();
		List<string> skillList = new List<string> { _b07row.Skills1, _b07row.Skills2, _b07row.Skills3, _b07row.Skills4 };
		List<string> skillEcList = new List<string> { "0", "0", "0", "0" };
		skillInfo.InitSkill(skillList, skillEcList);
		for (int i = 0; i <= skillInfo.sid; i++)
		{
			if (Random.Range(0f, 1f) < skillInfo.sOddNum[i] && CheckIsSkillEffect(_attacker, _defender, skillInfo.sSkillEc[i]))
			{
				RunSkillDetails(_attacker, _defender, skillInfo, i, "Item|" + _b07row.ID + "|" + _attacker.gameObject.name + "|", skillInfo.sValueNum[i]);
				_defender.RefreshEffectOn();
			}
		}
	}
}
