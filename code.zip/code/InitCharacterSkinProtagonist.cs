using System.Collections;
using System.Reflection;
using Spine;
using Spine.Unity;
using UnityEngine;

public class InitCharacterSkinProtagonist : MonoBehaviour
{
	private string baseSkin = "base";

	public SpriteRenderer SpecificMaleSprite;

	public SpriteRenderer SpecificFeMaleSprite;

	public SkeletonAnimation skeletonMaleNormalAnimation;

	public SkeletonAnimation skeletonMaleStrongAnimation;

	public SkeletonAnimation skeletonMaleFatAnimation;

	public SkeletonAnimation skeletonFemaleNormalAnimation;

	public SkeletonAnimation skeletonFemaleBlackAnimation;

	private SkeletonAnimation skeletonAnimation;

	public Camera FullBodyCamera;

	public Camera HeadCamera;

	private Skin characterSkin;

	private void Start()
	{
		SpecificMaleSprite.gameObject.SetActive(!SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().playerid.Equals("9001"));
		SpecificFeMaleSprite.gameObject.SetActive(!SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().playerid.Equals("9002"));
		skeletonMaleNormalAnimation.gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.MaleNormal));
		skeletonMaleStrongAnimation.gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.MaleStrong));
		skeletonMaleFatAnimation.gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.MaleFat));
		skeletonFemaleNormalAnimation.gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.FemaleNormal));
		skeletonFemaleBlackAnimation.gameObject.SetActive(SharedData.Instance().protagonistSkinDataNew.isCustom && SharedData.Instance().protagonistSkinDataNew.SkinType.Equals(SkinType.FemaleSpecial));
		switch (SharedData.Instance().protagonistSkinDataNew.SkinType)
		{
		case SkinType.None:
			skeletonAnimation = null;
			break;
		case SkinType.MaleNormal:
			skeletonAnimation = skeletonMaleNormalAnimation;
			break;
		case SkinType.MaleStrong:
			skeletonAnimation = skeletonMaleStrongAnimation;
			break;
		case SkinType.MaleFat:
			skeletonAnimation = skeletonMaleFatAnimation;
			break;
		case SkinType.FemaleNormal:
			skeletonAnimation = skeletonFemaleNormalAnimation;
			break;
		case SkinType.FemaleSpecial:
			skeletonAnimation = skeletonFemaleBlackAnimation;
			break;
		}
		if (SharedData.Instance().protagonistSkinDataNew.isCustom)
		{
			UpdateCharacterSkin();
		}
		StartCoroutine(DelayRender());
		Object.DontDestroyOnLoad(base.gameObject);
	}

	private IEnumerator DelayRender()
	{
		yield return null;
		FullBodyCamera.Render();
		HeadCamera.Render();
		RenderTexture renderTexture = Resources.Load("images/08-Character/Protagonist") as RenderTexture;
		Texture2D texture2D = new Texture2D(renderTexture.width, renderTexture.height, TextureFormat.RGBA32, mipChain: false);
		RenderTexture.active = renderTexture;
		texture2D.ReadPixels(new Rect(0f, 0f, renderTexture.width, renderTexture.height), 0, 0);
		texture2D.Apply();
		RenderTexture.active = null;
		SharedData.Instance().ProtagonistFullSprite = Sprite.Create(texture2D, new Rect(0f, 0f, texture2D.width, texture2D.height), new Vector2(0.5f, 0.5f));
		RenderTexture renderTexture2 = Resources.Load("images/13-CharacterHead/ProtagonistHead") as RenderTexture;
		Texture2D texture2D2 = new Texture2D(renderTexture2.width, renderTexture2.height, TextureFormat.RGBA32, mipChain: false);
		RenderTexture.active = renderTexture2;
		texture2D2.ReadPixels(new Rect(0f, 0f, renderTexture2.width, renderTexture2.height), 0, 0);
		texture2D2.Apply();
		RenderTexture.active = null;
		SharedData.Instance().ProtagonistHeadSprite = Sprite.Create(texture2D2, new Rect(0f, 0f, texture2D2.width, texture2D2.height), new Vector2(0.5f, 0.5f));
		SharedData.Instance().InitSkin = true;
		Object.DestroyImmediate(base.gameObject);
	}

	private void UpdateCharacterSkin()
	{
		FieldInfo[] fields = SharedData.Instance().protagonistSkinDataNew.GetType().GetFields();
		Skeleton skeleton = skeletonAnimation.Skeleton;
		SkeletonData data = skeleton.Data;
		characterSkin = new Skin("character-base");
		Skin skin = data.FindSkin("base");
		characterSkin.AddSkin(skin);
		FieldInfo[] array = fields;
		foreach (FieldInfo fieldInfo in array)
		{
			if (fieldInfo.Name.Equals("SkinType"))
			{
				continue;
			}
			string text = fieldInfo.GetValue(SharedData.Instance().protagonistSkinDataNew).ToString();
			if (!text.Equals("0") && !text.Equals(""))
			{
				skin = data.FindSkin(text);
				if (skin == null)
				{
					Debug.LogWarning("InitCharacterSkin can not Find Skin =  [" + text + "]");
				}
				else
				{
					characterSkin.AddSkin(skin);
				}
			}
		}
		skeleton.SetSkin(characterSkin);
		skeleton.SetSlotsToSetupPose();
	}
}
