using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using DG.Tweening;
using MessagePack;
using Spine.Unity;
using SuperScrollView;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class EvolutionEqNewController : MonoBehaviour
{
	public static int EnhanceAnvilLevel;

	public static EnhanceType EnhanceEquipmentType;

	private LoopGridView _packageLoopGrid;

	private List<PackageItemData> _mPackageDataSourceMgrFilter = new List<PackageItemData>();

	private PackageItemData _selectedPackageItem;

	private readonly PackagerFunction packagerFunction = PackagerFunction.Equip;

	private string _packageTopFilter = "00111000000";

	private string _packageSubFilter = "";

	private string _tmpTopFilter = "00111000000";

	private string _tmpSubFilter = "";

	private bool _forging;

	private AudioSource _mAudioSource;

	private AudioClip _mHitIt;

	private AudioClip _mSuccess;

	private AudioClip _mFailed;

	private AudioClip _mEvoultion;

	private Sprite _normalSprite;

	private Sprite _selectedSprite;

	private GameObject _selectedEquip;

	private string _filter = "0011100000";

	public List<string> materials = new List<string> { "", "", "" };

	private CharaData _curchara;

	private int _forgeLv;

	private int _evolutionLevel = 1;

	private float _doubleRate = 1f;

	private Sprite _canNotForgeSprit;

	private Sprite _canForgeSprit;

	private EvolutionEqLevelInfo _evolutionEqLevelInfo;

	private Transform _enhanceEquipmentPanel;

	private Transform _evolutionEquipmentPanel;

	private Transform _reSetEquipmentPanel;

	private bool isEvolutionEffectfinish = true;

	private Transform infoPanel;

	private string infoText = "";

	private PointerEventData pointerEventData;

	public GameObject SelectPanel;

	private PackageFilterPanelType packageFilterPanelType = PackageFilterPanelType.Equip;

	private PackageSortType packageSortType;

	private GameObject FilterBtn;

	private void Start()
	{
		SharedData.Instance().ForgeEquipmentID = "";
		SharedData.Instance().OpenPackagerFunction = PackagerFunction.PlayerPackage;
		_enhanceEquipmentPanel = base.transform.Find("Panel/EnhancePanel");
		_evolutionEquipmentPanel = base.transform.Find("Panel/EvolutionPanel");
		_reSetEquipmentPanel = base.transform.Find("Panel/ResetPanel");
		_mAudioSource = GetComponent<AudioSource>();
		_normalSprite = Resources.Load("images/01-border/boder-20231228-button-03", typeof(Sprite)) as Sprite;
		_selectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		_canNotForgeSprit = Resources.Load("images/01-border/boder-20231228-06", typeof(Sprite)) as Sprite;
		_canForgeSprit = Resources.Load("images/01-border/boder-20231228-highlihgt-01", typeof(Sprite)) as Sprite;
		_mHitIt = Resources.Load("Music/SE/HitTheAnvil") as AudioClip;
		_mSuccess = Resources.Load("Music/SE/success-sound") as AudioClip;
		_mFailed = Resources.Load("Music/SE/failure-sound") as AudioClip;
		_mEvoultion = Resources.Load("Music/SE/Lengend_01_01") as AudioClip;
		infoPanel = base.transform.Find("Panel/Info");
		SelectPanel = base.transform.Find("Panel/EquipList/Select").gameObject;
		FilterBtn = base.transform.Find("Panel/EquipList/FilterPanel").gameObject;
		_packageLoopGrid = GetComponentInChildren<LoopGridView>();
		_packageLoopGrid.InitGridView(_mPackageDataSourceMgrFilter.Count, OnGetPackageItemByRowColumn);
		RefreshPackageUIList();
		if (EnhanceEquipmentType.Equals(EnhanceType.Enhance))
		{
			_enhanceEquipmentPanel.gameObject.SetActive(value: true);
			_evolutionEquipmentPanel.gameObject.SetActive(value: false);
			_reSetEquipmentPanel.gameObject.SetActive(value: false);
			_curchara = SharedData.Instance().CurrentCharaData;
			RefreshMaterialSection();
			InitForger();
			base.transform.Find("Panel/TopBanner/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_Enhance");
		}
		else if (EnhanceEquipmentType.Equals(EnhanceType.Reset))
		{
			_enhanceEquipmentPanel.gameObject.SetActive(value: false);
			_evolutionEquipmentPanel.gameObject.SetActive(value: false);
			_reSetEquipmentPanel.gameObject.SetActive(value: true);
			base.transform.Find("Panel/TopBanner/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_Reset");
		}
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
		StartCoroutine(ExecuteAfterAllStart());
		SharedData.Instance().m_EvolutionEqNewController = this;
	}

	private IEnumerator ExecuteAfterAllStart()
	{
		yield return null;
		EventSystem.current.SetSelectedGameObject(_selectedEquip);
		OnButtonClickEquipment(_selectedEquip.GetComponent<Button>());
	}

	private void Update()
	{
		if (infoPanel.gameObject.activeSelf && (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame() || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame()))
		{
			StartCoroutine(DelayControllInfoPanel(active: false));
			return;
		}
		if (isEvolutionEffectfinish && _evolutionEquipmentPanel.gameObject.activeInHierarchy && (Input.GetMouseButtonUp(0) || InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame()))
		{
			StartCoroutine(DelayCloseEvolutionEquipPanel());
		}
		if (!infoPanel.gameObject.activeSelf && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() && SharedData.Instance().m_PackageController.isOpen.Equals(obj: false))
		{
			pointerEventData = new PointerEventData(EventSystem.current);
			ExecuteEvents.Execute(base.transform.Find("Panel/TopBanner/Return").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
		}
		else if (!infoPanel.gameObject.activeSelf && InputSystemCustom.Instance().UI.ConfirmEnhance.WasReleasedThisFrame() && SharedData.Instance().m_PackageController.isOpen.Equals(obj: false))
		{
			pointerEventData = new PointerEventData(EventSystem.current);
			if (EnhanceEquipmentType.Equals(EnhanceType.Enhance))
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/EnhancePanel/EvolutionItem/ConfirmEnhance").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
			else if (EnhanceEquipmentType.Equals(EnhanceType.Reset))
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/ResetPanel/ConfirmReset").gameObject, pointerEventData, ExecuteEvents.pointerClickHandler);
			}
		}
		else if (InputSystemCustom.Instance().UI.PackageFilter.WasReleasedThisFrame())
		{
			OnButtonClick(FilterBtn);
		}
		else if (InputSystemCustom.Instance().UI.ShowFullName.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/EquipList/FullNameArea/FullName").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		if (!(InputDeviceDetector.instance.JoyCursor != null))
		{
			return;
		}
		EvolutionEqLevelInfo componentInParent = InputDeviceDetector.instance.JoyCursor.GetComponentInParent<EvolutionEqLevelInfo>();
		if (!(_evolutionEqLevelInfo == componentInParent))
		{
			_evolutionEqLevelInfo = componentInParent;
			if (_evolutionEqLevelInfo != null)
			{
				_evolutionEqLevelInfo.OnPointerEnter(new PointerEventData(EventSystem.current));
			}
			else if (_evolutionEqLevelInfo == null)
			{
				_enhanceEquipmentPanel.Find("EvolutionItem/EvolutionLV/Lv1/On").GetComponentInParent<EvolutionEqLevelInfo>().OnPointerExit(new PointerEventData(EventSystem.current));
			}
		}
	}

	private IEnumerator DelayCloseEvolutionEquipPanel()
	{
		yield return null;
		base.transform.GetComponent<CanvasGroup>().interactable = true;
		RefreshPackageUIList();
		_forging = false;
		_evolutionEquipmentPanel.gameObject.SetActive(value: false);
	}

	private IEnumerator DelayControllInfoPanel(bool active)
	{
		yield return null;
		base.transform.GetComponent<CanvasGroup>().interactable = !active;
		infoPanel.gameObject.SetActive(active);
	}

	private LoopGridViewItem OnGetPackageItemByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		PackageItemData packageItemData = _mPackageDataSourceMgrFilter[index];
		if (packageItemData == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("PackageIcon");
		PackageIconController component = loopGridViewItem.GetComponent<PackageIconController>();
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		component.InitPackageIcon(packageItemData, isShowHeadIcoN: false);
		EventTriggerListener.Get(loopGridViewItem.gameObject).onClick = OnButtonClick;
		return loopGridViewItem;
	}

	private void RefreshPackageUIList(gang_b02Table.Row _originB02Row = null)
	{
		List<PackageItemData> packageList = PackageController.GetPackageList(packagerFunction, packageSortType);
		packageList.RemoveAll((PackageItemData t) => !PackageController.CouldPassUseFilter(t.b07Row, _tmpTopFilter, _tmpSubFilter, isFilterBtnActive: true, _packageTopFilter, _packageSubFilter));
		if (EnhanceEquipmentType.Equals(EnhanceType.Reset))
		{
			packageList.RemoveAll((PackageItemData t) => !t.b07Row.ID.Contains("_"));
		}
		_mPackageDataSourceMgrFilter = packageList;
		int num = 4 - _mPackageDataSourceMgrFilter.Count % 4;
		if (num == 0)
		{
			num = 4;
		}
		while (--num >= 0)
		{
			_mPackageDataSourceMgrFilter.Add(new PackageItemData
			{
				ID = num.ToString()
			});
		}
		_packageLoopGrid.SetListItemCount(_mPackageDataSourceMgrFilter.Count, resetPos: false);
		_packageLoopGrid.RefreshAllShownItem();
		int num2 = -1;
		if (_selectedPackageItem != null)
		{
			PackageItemData item = _mPackageDataSourceMgrFilter.Find((PackageItemData x) => x.ID.Equals(_selectedPackageItem.ID));
			num2 = _mPackageDataSourceMgrFilter.IndexOf(item);
		}
		if (num2 == -1)
		{
			num2 = 0;
		}
		_selectedPackageItem = _mPackageDataSourceMgrFilter[num2];
		_packageLoopGrid.MovePanelToItemByIndex(num2);
		StartCoroutine(DelayClickSelectedEquip(_originB02Row));
	}

	private IEnumerator DelayClickSelectedEquip(gang_b02Table.Row _originB02Row = null)
	{
		yield return null;
		string n = "Viewport/Content/ItemBtn|" + _selectedPackageItem.ID + "|" + ((_selectedPackageItem.b07Row != null) ? _selectedPackageItem.b07Row.Use : "") + "|" + ((_selectedPackageItem.userData != null) ? _selectedPackageItem.userData.m_Id : "null");
		_selectedEquip = _packageLoopGrid.transform.Find(n)?.gameObject;
		InputDeviceDetector.instance.ClearJoyStack();
		EventSystem.current.SetSelectedGameObject(_selectedEquip);
		OnButtonClickEquipment(_selectedEquip.GetComponent<Button>(), _originB02Row);
	}

	private void InitForger()
	{
		Transform transform = _enhanceEquipmentPanel.Find("EvolutionItem");
		transform.Find("SelcetTeammate/IconMask/IconBG").gameObject.SetActive(value: true);
		Sprite tachieFull = CommonResourcesData.GetTachieFull(_curchara.m_BattleIcon);
		transform.Find("SelcetTeammate/IconMask/IconBG/Icon").GetComponent<Image>().sprite = tachieFull;
		transform.Find("SelcetTeammate/Info/Forge/Value").GetComponent<Text>().text = _curchara.GetFieldValueByName("Forge").ToString();
		_forgeLv = Mathf.Clamp((int)_curchara.GetFieldValueByName("Forge") / 30, 1, 10);
		_evolutionLevel = 1;
		transform.Find("SelcetTeammate/Info/ForgeLimit/Value").GetComponent<Text>().text = "+" + _forgeLv;
		for (int i = 1; i <= 4; i++)
		{
			transform.Find("EvolutionLV/Lv" + i + "/On").gameObject.SetActive(value: false);
		}
		transform.Find("SelcetTeammate/Info/Name").GetComponent<Text>().text = _curchara.Indexs_Name["Name"].stringValue;
		transform.Find("EvolutionLV/Lv1/On").gameObject.SetActive(value: true);
		transform.Find("EvolutionLV/Lv1/On").GetComponent<EvolutionEqLevelInfo>().LevelInfo = CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_LvInfo_0");
		int num = EnhanceAnvilLevel;
		while (--num > 0)
		{
			_evolutionLevel++;
			transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").GetComponent<EvolutionEqLevelInfo>().LevelInfo = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_LvInfo_1"));
			transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").gameObject.SetActive(value: true);
		}
		foreach (KeyValuePair<string, string> item in _curchara.m_EquipTraitDict)
		{
			if (_evolutionLevel > 4)
			{
				break;
			}
			if (item.Value == "0")
			{
				continue;
			}
			gang_b06Table.Row row = CommonResourcesData.b06.Find_id(item.Value);
			if (row == null)
			{
				continue;
			}
			List<string> list = new List<string> { row.add1, row.add2, row.add3, row.add4 };
			List<string> list2 = new List<string> { row.attribute1, row.attribute2, row.attribute3, row.attribute4 };
			for (int j = 0; j < list.Count; j++)
			{
				if (list[j].Contains("ForgeLV") && _evolutionLevel < 4)
				{
					int num2 = int.Parse(list2[j]);
					while (--num2 >= 0 && _evolutionLevel < 4)
					{
						_evolutionLevel++;
						transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").GetComponent<EvolutionEqLevelInfo>().LevelInfo = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_LvInfo_2"), row.name_Trans);
						transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").gameObject.SetActive(value: true);
					}
				}
			}
		}
		foreach (string item2 in _curchara.m_EquipSlot)
		{
			if (_evolutionLevel > 4)
			{
				break;
			}
			if (item2.Equals("0") || item2.Equals(""))
			{
				continue;
			}
			gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(item2);
			if (row2 == null)
			{
				continue;
			}
			gang_b02Table.Row row3 = CommonResourcesData.b02.Find_ID(row2.Relateid);
			if (row3 == null)
			{
				continue;
			}
			List<string> list3 = new List<string> { row3.add1, row3.add2, row3.add3, row3.add4, row3.add5 };
			List<string> list4 = new List<string> { row3.Attribute1, row3.Attribute2, row3.Attribute3, row3.Attribute4, row3.Attribute5 };
			for (int k = 0; k < list3.Count; k++)
			{
				if (list3[k].Contains("ForgeLV") && _evolutionLevel < 4)
				{
					int num3 = int.Parse(list4[k]);
					while (--num3 >= 0 && _evolutionLevel < 4)
					{
						_evolutionLevel++;
						transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").GetComponent<EvolutionEqLevelInfo>().LevelInfo = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_LvInfo_3"), row3.Name_Trans);
						transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").gameObject.SetActive(value: true);
					}
				}
			}
		}
		string find = _curchara.m_EquipSlot[0] + "|" + _curchara.m_EquipSlot[1] + "|" + _curchara.m_EquipSlot[2];
		gang_b02SetTable.Row row4 = CommonResourcesData.b02Set.Find_Set(find);
		if (row4 == null || _evolutionLevel >= 4)
		{
			return;
		}
		List<string> list5 = new List<string> { row4.add1, row4.add2, row4.add3, row4.add4, row4.add5 };
		List<string> list6 = new List<string> { row4.Attribute1, row4.Attribute2, row4.Attribute3, row4.Attribute4, row4.Attribute5 };
		for (int l = 0; l < list5.Count; l++)
		{
			if (list5[l].Contains("ForgeLV") && _evolutionLevel < 4)
			{
				int num4 = int.Parse(list6[l]);
				while (--num4 >= 0 && _evolutionLevel < 4)
				{
					_evolutionLevel++;
					transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").GetComponent<EvolutionEqLevelInfo>().LevelInfo = string.Format(CommonFunc.I18nGetLocalizedValue("I18N_EvolutionEq_LvInfo_3"), row4.Name_Trans);
					transform.Find("EvolutionLV/Lv" + _evolutionLevel + "/On").gameObject.SetActive(value: true);
				}
			}
		}
	}

	public void RefreshMaterialSection()
	{
		int num = 0;
		_doubleRate = 1f;
		gang_b07Table.Row row = null;
		for (int i = 1; i <= 3; i++)
		{
			string mid = materials[i - 1];
			_ = materials.FindAll((string x) => x == mid).Count;
			int num2 = 0;
			for (int j = 1; j <= 3; j++)
			{
				if (j != i && materials[j - 1] == mid)
				{
					num2++;
				}
			}
			if ("".Equals(mid) || !SharedData.Instance().PlayerPackage.ContainsKey(mid) || SharedData.Instance().PlayerPackage[mid] <= num2)
			{
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Icon").gameObject.SetActive(value: true);
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Image").gameObject.SetActive(value: false);
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Name").GetComponent<Text>().text = "";
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Num").GetComponent<Text>().text = "";
				materials[i - 1] = "";
				continue;
			}
			row = CommonResourcesData.b07.Find_ID(mid);
			if (row != null)
			{
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Icon").gameObject.SetActive(value: false);
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Image").gameObject.SetActive(value: true);
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Image").GetComponent<Image>().sprite = CommonResourcesData.GetBookIcon(row.BookIcon);
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Name").GetComponent<Text>().text = row.Name_Trans;
				_enhanceEquipmentPanel.Find("EvolutionItem/Materials/Material|" + i + "/Num").GetComponent<Text>().text = SharedData.Instance().PlayerPackage[mid].ToString();
				num++;
				if (row.ID.Equals("12014") || row.ID.Equals("12013"))
				{
					_doubleRate *= 2f;
				}
			}
		}
		int num3 = 0;
		if (SharedData.Instance().ForgeEquipmentID != "")
		{
			row = CommonResourcesData.b07.Find_ID(SharedData.Instance().ForgeEquipmentID);
			num3 = CommonResourcesData.b02.Find_ID(row.Relateid).Enhance;
		}
		if (num > 0 && SharedData.Instance().ForgeEquipmentID != "" && num3 < _forgeLv)
		{
			_enhanceEquipmentPanel.Find("EvolutionItem/ConfirmEnhance").GetComponent<Image>().sprite = _canForgeSprit;
			return;
		}
		_enhanceEquipmentPanel.Find("EvolutionItem/ConfirmEnhance").GetComponent<Image>().sprite = _canNotForgeSprit;
		if (num3.Equals(10))
		{
			infoText = CommonFunc.I18nGetLocalizedValue("I18N_EnhenceEquip_Cant_Info1");
		}
		else if (num3 >= _forgeLv)
		{
			infoText = CommonFunc.I18nGetLocalizedValue("I18N_EnhenceEquip_Cant_Info2");
		}
		else if (num <= 0)
		{
			infoText = CommonFunc.I18nGetLocalizedValue("I18N_EnhenceEquip_Cant_Info3");
		}
	}

	private void OnButtonClick(GameObject obj)
	{
		if (obj == null || !obj.activeInHierarchy || obj.GetComponent<Button>() == null || !obj.GetComponent<Button>().IsInteractable() || infoPanel.gameObject.activeSelf)
		{
			return;
		}
		Button component = obj.GetComponent<Button>();
		if (_forging || _evolutionEquipmentPanel.gameObject.activeInHierarchy || !isEvolutionEffectfinish)
		{
			return;
		}
		string[] array = component.name.Split('|');
		if (array[0] == "Return")
		{
			ExitScene();
		}
		else if (array[0] == "ItemBtn")
		{
			OnButtonClickEquipment(component);
		}
		else
		{
			if (array[0] == "SelcetTeammate")
			{
				return;
			}
			if (array[0] == "Material")
			{
				CommonResourcesData.inputDeviceDetector.PushJoyStack();
				SharedData.Instance().m_Transfer_Info = "FORGE|" + materials[0] + "|" + materials[1] + "|" + materials[2] + "|" + array[1];
				MonoBehaviour.print("[EvolutionEQ] transfer info to Package scene: " + SharedData.Instance().m_Transfer_Info);
				SharedData.Instance().OpenPackageFor = "EvolutionEQ|" + array[1];
				SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.EvolutionEQ, "00000000010");
			}
			else if (array[0] == "ConfirmEnhance")
			{
				if (component.GetComponent<Image>().sprite != _canForgeSprit)
				{
					StartCoroutine(DelayControllInfoPanel(active: true));
					infoPanel.transform.Find("Banner1/Text").GetComponent<Text>().text = infoText;
				}
				else
				{
					base.transform.GetComponent<CanvasGroup>().interactable = false;
					_forging = true;
					HitTheAnvil();
				}
			}
			else if (array[0].Equals("ConfirmReset"))
			{
				if (!(component.GetComponent<Image>().sprite != _canForgeSprit))
				{
					base.transform.GetComponent<CanvasGroup>().interactable = false;
					_forging = true;
					HitTheAnvil();
				}
			}
			else if (array[0].Equals("FilterPanel"))
			{
				SelectPanel.gameObject.SetActive(!SelectPanel.gameObject.activeSelf);
				_packageLoopGrid.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
				if (SelectPanel.gameObject.activeSelf)
				{
					CommonResourcesData.inputDeviceDetector.PushJoyStack();
					if (packageFilterPanelType.Equals(PackageFilterPanelType.Equip))
					{
						EventSystem.current.SetSelectedGameObject(SelectPanel.transform.Find("Viewport/Content/Sorter|Forward|Fix").gameObject);
					}
				}
				else
				{
					CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
				}
			}
			else if (array[0] == "Filter")
			{
				if (array[1].Equals("Use"))
				{
					_packageTopFilter = array[2];
					_packageSubFilter = "";
					if (array.Length >= 4)
					{
						_packageSubFilter = array[3];
					}
				}
				if (obj.name == "Filter|Use|1111111111||Fix")
				{
					FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter");
				}
				else
				{
					FilterBtn.transform.Find("Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Filter") + " : " + obj.transform.Find("Text").GetComponent<Text>().text;
				}
				_selectedEquip = null;
				if (array[1].Equals("Use"))
				{
					RefreshPackageUIList();
				}
				SelectPanel.gameObject.SetActive(value: false);
				_packageLoopGrid.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
			}
			else if (array[0] == "Sorter")
			{
				switch (array[1])
				{
				case "Forward":
					packageSortType = PackageSortType.Forward;
					break;
				case "Reverse":
					packageSortType = PackageSortType.Reverse;
					break;
				case "Resort":
					packageSortType = PackageSortType.Resort;
					break;
				}
				_selectedEquip = null;
				RefreshPackageUIList();
				SelectPanel.gameObject.SetActive(value: false);
				_packageLoopGrid.GetComponent<CanvasGroup>().interactable = !SelectPanel.gameObject.activeSelf;
				SelectPanel.transform.Find("Viewport/Content/Sorter|Forward|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Forward) ? CommonResourcesData.SelectedSprite : CommonResourcesData.NormalPackageIconSprite);
				SelectPanel.transform.Find("Viewport/Content/Sorter|Reverse|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Reverse) ? CommonResourcesData.SelectedSprite : CommonResourcesData.NormalPackageIconSprite);
				SelectPanel.transform.Find("Viewport/Content/Sorter|Resort|Fix").GetComponent<Image>().sprite = (packageSortType.Equals(PackageSortType.Resort) ? CommonResourcesData.SelectedSprite : CommonResourcesData.NormalPackageIconSprite);
			}
			else
			{
				if (!array[0].StartsWith("FullName"))
				{
					return;
				}
				SharedData.Instance().isShowFullName = !SharedData.Instance().isShowFullName;
				if (SharedData.Instance().isShowFullName)
				{
					base.transform.Find("Panel/EquipList/FullNameArea/FullName/Checkmark").gameObject.SetActive(value: true);
				}
				else
				{
					base.transform.Find("Panel/EquipList/FullNameArea/FullName/Checkmark").gameObject.SetActive(value: false);
				}
				foreach (PackageIconController item in _packageLoopGrid.GetComponentsInChildren<PackageIconController>(includeInactive: true).ToList())
				{
					item.transform.Find("FullName").gameObject.SetActive(SharedData.Instance().isShowFullName);
					item.transform.Find("FullInfo").gameObject.SetActive(!SharedData.Instance().isShowFullName);
				}
			}
		}
	}

	private void OnButtonClickEquipment(Button btn, gang_b02Table.Row _originB02Row = null)
	{
		if (_selectedEquip != null)
		{
			_selectedEquip.GetComponent<Image>().sprite = _normalSprite;
		}
		_selectedEquip = btn.gameObject;
		_selectedEquip.GetComponent<Image>().sprite = _selectedSprite;
		PackageIconController component = _selectedEquip.GetComponent<PackageIconController>();
		component.HideNewInfo();
		if (component.b07Row == null)
		{
			SharedData.Instance().ForgeEquipmentID = "";
			if (EnhanceEquipmentType.Equals(EnhanceType.Enhance))
			{
				_enhanceEquipmentPanel.Find("HoverItem").gameObject.SetActive(value: false);
			}
			else if (EnhanceEquipmentType.Equals(EnhanceType.Reset))
			{
				_reSetEquipmentPanel.gameObject.SetActive(value: false);
			}
			return;
		}
		SharedData.Instance().ForgeEquipmentID = component.b07Row.ID;
		if (EnhanceEquipmentType.Equals(EnhanceType.Enhance))
		{
			_enhanceEquipmentPanel.Find("HoverItem").gameObject.SetActive(value: true);
			EquipOrItemHoverShowInfo.ItemHoverSub("Select/", component.b07Row.ID, component.b07Row.Relateid, null, component.userData, _enhanceEquipmentPanel.Find("HoverItem"), _originB02Row);
			RefreshMaterialSection();
		}
		else if (EnhanceEquipmentType.Equals(EnhanceType.Reset))
		{
			_reSetEquipmentPanel.gameObject.SetActive(value: true);
			string text = (component.b07Row.ID.Contains("_") ? component.b07Row.ID.Split('_')[1] : component.b07Row.ID);
			gang_b02EvolutionTable.Row row = CommonResourcesData.b02Evolution.Find_Evolution(text);
			if (row != null)
			{
				text = row.Origin;
			}
			gang_b07Table.Row row2 = CommonResourcesData.b07.Find_ID(text);
			EquipOrItemHoverShowInfo.ItemHoverSub("Evolution/", text, row2.Relateid, null, null, _reSetEquipmentPanel.Find("HoverItem"));
			EquipOrItemHoverShowInfo.ItemHoverSub("Origin/", component.b07Row.ID, component.b07Row.Relateid, null, null, _reSetEquipmentPanel.Find("HoverItem"));
		}
	}

	private void ExitScene()
	{
		if (SharedData.Instance().m_PackageController.isOpen)
		{
			SharedData.Instance().m_PackageController.ClosePackage();
		}
		if (SharedData.Instance().LoadedSceneStack.Count > 0)
		{
			int index = SharedData.Instance().LoadedSceneStack.Count - 1;
			SharedData.Instance().LoadedSceneStack.RemoveAt(index);
			if (SharedData.Instance().LoadedSceneStack.Count > 0)
			{
				index = SharedData.Instance().LoadedSceneStack.Count - 1;
				SceneManager.LoadScene(SharedData.Instance().LoadedSceneStack[index], LoadSceneMode.Additive);
			}
		}
		SharedData.Instance().m_Transfer_Info = "";
		SharedData.Instance().ForgeEquipmentID = "";
		SharedData.Instance().ForgeEquipmentStyle = "";
		SharedData.Instance().m_OpenDetail = "";
		SceneManager.UnloadSceneAsync("EvolutionEQ");
	}

	private void HitTheAnvil()
	{
		_mAudioSource.clip = _mHitIt;
		_mAudioSource.Play();
		StatsAndAchievements.Instance().UnlockAchievement("1031");
		if (EnhanceEquipmentType.Equals(EnhanceType.Enhance))
		{
			StartCoroutine(CheckEnhanceResult(_mHitIt.length));
		}
		else if (EnhanceEquipmentType.Equals(EnhanceType.Reset))
		{
			StartCoroutine(CheckResetResult(_mHitIt.length));
		}
	}

	private IEnumerator CheckEnhanceResult(float _delay)
	{
		yield return new WaitForSeconds(_delay);
		for (int i = 0; i < 3; i++)
		{
			if (!"".Equals(materials[i]))
			{
				SharedData.Instance().PackageAdd(materials[i], -1);
			}
		}
		gang_b07Table.Row b07row = CommonResourcesData.b07.Find_ID(SharedData.Instance().ForgeEquipmentID);
		gang_b02Table.Row b02row = CommonResourcesData.b02.Find_ID(b07row.Relateid);
		CharaData userData = _selectedEquip.GetComponent<PackageIconController>().userData;
		_selectedPackageItem.b07Row = b07row;
		_selectedPackageItem.ID = b07row.ID;
		if (userData == null)
		{
			_selectedPackageItem.number = SharedData.Instance().PlayerPackage[b07row.ID];
		}
		else
		{
			_selectedPackageItem.number = 1;
		}
		_selectedPackageItem.originPrice = int.Parse(b07row.Value);
		_selectedPackageItem.effectPrice = int.Parse(b07row.Value);
		_selectedPackageItem.userData = userData;
		float successRate = GetSuccessRate(b02row.Enhance.ToString());
		if (UnityEngine.Random.Range(0f, 1f) < successRate)
		{
			Debug.Log("Enhance success!");
			gang_b02Table.Row originB02Row = MessagePackSerializer.Deserialize<gang_b02Table.Row>(MessagePackSerializer.Serialize(b02row));
			if (!b02row.ID.Contains("MB02_"))
			{
				gang_b07Table.Row row = SharedData.Instance().BuildB07AppendRow(b07row.ID);
				gang_b02Table.Row row2 = SharedData.Instance().BuildB02AppendRow(b02row.ID);
				row.Relateid = row2.ID;
				row2.Enhance++;
				if (userData == null)
				{
					SharedData.Instance().PackageAdd(b07row.ID, -1);
					SharedData.Instance().PackageAdd(row.ID, 1);
				}
				else
				{
					userData.m_EquipSlot[int.Parse(b02row.Style) - 1] = row.ID;
				}
				b07row = row;
				b02row = row2;
			}
			else
			{
				b02row.Enhance++;
			}
			_selectedPackageItem.b07Row = b07row;
			_selectedPackageItem.ID = b07row.ID;
			_selectedPackageItem.number = 1;
			_selectedPackageItem.originPrice = int.Parse(b07row.Value);
			_selectedPackageItem.effectPrice = int.Parse(b07row.Value);
			_selectedPackageItem.userData = userData;
			foreach (string material in materials)
			{
				if (!"".Equals(material))
				{
					gang_b07Table.Row row3 = CommonResourcesData.b07.Find_ID(material);
					gang_b13Table.Row row4 = CommonResourcesData.b13.Find_ID(row3.Relateid);
					if (row4 != null)
					{
						MaterialAdd(row4, b02row);
					}
				}
			}
			RefreshMaterialSection();
			bool flag = false;
			if (b02row.Enhance.Equals(10))
			{
				StatsAndAchievements.Instance().UnlockAchievement("1032");
				string find = b02row.ID;
				if (b02row.ID.Contains("_"))
				{
					find = b02row.ID.Split('_')[1];
				}
				gang_b02EvolutionTable.Row row5 = CommonResourcesData.b02Evolution.Find_Origin(find);
				if (row5 != null)
				{
					flag = true;
					GameDataManager.Instance().AddUnlockAtlasList(row5.Evolution, "b07");
					gang_b07Table.Row b07rowNew = null;
					gang_b02Table.Row b02rowNew = null;
					b07rowNew = SharedData.Instance().BuildB07AppendRow(row5.Evolution);
					b02rowNew = SharedData.Instance().BuildB02AppendRow(row5.Evolution);
					b07rowNew.Relateid = b02rowNew.ID;
					b02rowNew.Enhance = 10;
					Type type = CommonResourcesData.b02.Find_ID(row5.Evolution).GetType();
					Type type2 = b02rowNew.GetType();
					for (int j = 1; j <= 5; j++)
					{
						string value = type.GetField("add" + j).GetValue(b02row).ToString();
						string text = type.GetField("Attribute" + j).GetValue(b02row).ToString();
						for (int k = 1; k <= 5; k++)
						{
							FieldInfo field = type2.GetField("add" + k);
							FieldInfo field2 = type2.GetField("Attribute" + k);
							string text2 = field.GetValue(b02rowNew).ToString();
							string s = field2.GetValue(b02rowNew).ToString();
							if (text2.Equals(value))
							{
								float num = float.Parse(s, CultureInfo.InvariantCulture);
								float num2 = float.Parse(text, CultureInfo.InvariantCulture);
								field2.SetValue(b02rowNew, (num + num2).ToString());
								break;
							}
							if (text2.Equals("0") || text2.Equals(""))
							{
								field.SetValue(b02rowNew, value);
								field2.SetValue(b02rowNew, text);
								break;
							}
						}
					}
					if (userData == null)
					{
						SharedData.Instance().PackageAdd(b07row.ID, -1);
						SharedData.Instance().PackageAdd(b07rowNew.ID, 1);
					}
					else
					{
						userData.m_EquipSlot[int.Parse(b02row.Style) - 1] = b07rowNew.ID;
					}
					isEvolutionEffectfinish = false;
					_evolutionEquipmentPanel.gameObject.SetActive(value: true);
					SkeletonGraphic[] componentsInChildren = _evolutionEquipmentPanel.Find("Effect").GetComponentsInChildren<SkeletonGraphic>(includeInactive: true);
					foreach (SkeletonGraphic skeletonGraphic in componentsInChildren)
					{
						if (CommonFunc.ShortLangSel("CN", "EN", "CN").Equals(skeletonGraphic.gameObject.name))
						{
							skeletonGraphic.gameObject.SetActive(value: true);
							skeletonGraphic.AnimationState.SetAnimation(0, "animation", loop: false);
							skeletonGraphic.AnimationState.Complete += delegate
							{
								isEvolutionEffectfinish = true;
							};
						}
						else
						{
							skeletonGraphic.gameObject.SetActive(value: false);
						}
					}
					_evolutionEquipmentPanel.Find("HoverItem").gameObject.SetActive(value: false);
					DOVirtual.DelayedCall(1.23f, delegate
					{
						Transform transform = _evolutionEquipmentPanel.Find("HoverItem");
						transform.gameObject.SetActive(value: true);
						CanvasGroup component = transform.GetComponent<CanvasGroup>();
						component.alpha = 0f;
						component.DOFade(1f, 0.2f);
						EquipOrItemHoverShowInfo.ItemHoverSub("Origin/", b07row.ID, b02row.ID, null, null, transform);
						EquipOrItemHoverShowInfo.ItemHoverSub("Evolution/", b07rowNew.ID, b02rowNew.ID, null, null, transform);
						b07row = b07rowNew;
						b02row = b02rowNew;
					});
				}
			}
			if (!flag)
			{
				RefreshPackageUIList(originB02Row);
				_mAudioSource.clip = _mSuccess;
				_mAudioSource.Play();
				StartCoroutine(FinishForge(_mSuccess.length));
			}
			else
			{
				_mAudioSource.clip = _mEvoultion;
				_mAudioSource.Play();
			}
			_curchara.Indexs_Name["Forge"].rollValue += 1f;
			InitForger();
		}
		else
		{
			Debug.Log("Enhance failed!");
			RefreshMaterialSection();
			_mAudioSource.clip = _mFailed;
			_mAudioSource.Play();
			StartCoroutine(FinishForge(_mFailed.length));
		}
	}

	private IEnumerator CheckResetResult(float _delay)
	{
		yield return new WaitForSeconds(_delay);
		gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(SharedData.Instance().ForgeEquipmentID);
		gang_b02Table.Row row2 = CommonResourcesData.b02.Find_ID(row.Relateid);
		CharaData userData = _selectedEquip.GetComponent<PackageIconController>().userData;
		string text = (row.ID.Contains("_") ? row.ID.Split('_')[1] : row.ID);
		gang_b02EvolutionTable.Row row3 = CommonResourcesData.b02Evolution.Find_Evolution(text);
		if (row3 != null)
		{
			text = row3.Origin;
		}
		gang_b07Table.Row row4 = CommonResourcesData.b07.Find_ID(text);
		_selectedPackageItem.b07Row = row4;
		_selectedPackageItem.ID = row4.ID;
		if (userData == null)
		{
			if (SharedData.Instance().PlayerPackage.ContainsKey(row4.ID))
			{
				_selectedPackageItem.number = SharedData.Instance().PlayerPackage[row4.ID];
			}
			else
			{
				_selectedPackageItem.number = 1;
			}
			SharedData.Instance().PackageAdd(row.ID, -1);
			SharedData.Instance().PackageAdd(text, 1);
		}
		else
		{
			_selectedPackageItem.number = 1;
			userData.m_EquipSlot[int.Parse(row2.Style) - 1] = text;
		}
		_selectedPackageItem.originPrice = int.Parse(row4.Value);
		_selectedPackageItem.effectPrice = int.Parse(row4.Value);
		_selectedPackageItem.userData = userData;
		RefreshPackageUIList();
		_mAudioSource.clip = _mSuccess;
		_mAudioSource.Play();
		StartCoroutine(FinishForge(_mSuccess.length));
	}

	private float GetSuccessRate(string _enhance)
	{
		return 1f;
	}

	private void MaterialAdd(gang_b13Table.Row _b13Row, gang_b02Table.Row _b02row)
	{
		FieldInfo fieldInfo = null;
		FieldInfo fieldInfo2 = null;
		Type type = _b02row.GetType();
		bool flag = false;
		string[] array = null;
		if (_b02row.Style.Equals("1"))
		{
			array = _b13Row.WeaponAdd.Split('|');
		}
		else if (_b02row.Style.Equals("2"))
		{
			array = _b13Row.ArmorAdd.Split('|');
		}
		else if (_b02row.Style.Equals("3"))
		{
			array = _b13Row.AccessoryAdd.Split('|');
		}
		if (_b02row.Style.Equals("1") && !_b13Row.CommonWeaponAdd.Equals("0"))
		{
			List<string> list = new List<string> { "SwordATK", "KnifeATK", "StickATK", "HandATK", "FingerATK", "SpecialATK", "MelodyATK", "DartsATK", "WineartATK" };
			for (int i = 1; i <= 5; i++)
			{
				fieldInfo = type.GetField("add" + i);
				fieldInfo2 = type.GetField("Attribute" + i);
				if (list.Contains(fieldInfo.GetValue(_b02row).ToString()))
				{
					float num = float.Parse(_b13Row.CommonWeaponAdd.Split('|')[_evolutionLevel], CultureInfo.InvariantCulture) * _doubleRate;
					float num2 = float.Parse(fieldInfo2.GetValue(_b02row).ToString(), CultureInfo.InvariantCulture);
					fieldInfo2.SetValue(_b02row, (num + num2).ToString());
				}
			}
		}
		if (!array.Length.Equals(5))
		{
			return;
		}
		for (int j = 1; j <= 5; j++)
		{
			fieldInfo = type.GetField("add" + j);
			fieldInfo2 = type.GetField("Attribute" + j);
			if (!flag && fieldInfo.GetValue(_b02row).ToString().Equals(array[0]))
			{
				float num3 = float.Parse(array[_evolutionLevel], CultureInfo.InvariantCulture) * _doubleRate;
				float num4 = float.Parse(fieldInfo2.GetValue(_b02row).ToString(), CultureInfo.InvariantCulture);
				fieldInfo2.SetValue(_b02row, (num3 + num4).ToString());
				flag = true;
			}
		}
		if (flag)
		{
			return;
		}
		for (int k = 1; k <= 5; k++)
		{
			fieldInfo = type.GetField("add" + k);
			fieldInfo2 = type.GetField("Attribute" + k);
			if (fieldInfo.GetValue(_b02row).ToString().Equals("0") || fieldInfo.GetValue(_b02row).ToString().Equals(""))
			{
				float num5 = float.Parse(array[_evolutionLevel], CultureInfo.InvariantCulture) * _doubleRate;
				fieldInfo.SetValue(_b02row, array[0]);
				fieldInfo2.SetValue(_b02row, num5.ToString());
				break;
			}
		}
	}

	private IEnumerator FinishForge(float _delay)
	{
		yield return new WaitForSeconds(_delay);
		if (!_evolutionEquipmentPanel.gameObject.activeInHierarchy)
		{
			base.transform.GetComponent<CanvasGroup>().interactable = true;
		}
		SharedData.Instance().m_OpenDetail = "";
		_forging = false;
	}
}
