using System.Linq;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.Tilemaps;

public class EffectController : MonoBehaviour
{
	public int m_DefaultLayer = -1;

	public bool loopRun;

	protected SkeletonAnimation m_Animation;

	public BattleObject m_BattleObj;

	public BattleObject m_TargetObj;

	public float m_Injury;

	public int m_combo;

	private int m_Maxcombo;

	private float m_MaxInjury;

	public bool m_isFinalEffect;

	private void Start()
	{
		if (m_DefaultLayer < 0)
		{
			if (SharedData.Instance().m_BattleController != null)
			{
				GetComponent<MeshRenderer>().sortingOrder = SharedData.Instance().m_BattleController.m_Effect_SortingOrder;
			}
			else
			{
				GetComponent<MeshRenderer>().sortingOrder = Object.FindObjectsOfType<TilemapRenderer>().FirstOrDefault((TilemapRenderer s) => s.name == "EffectLayer").sortingOrder;
			}
		}
		else
		{
			GetComponent<MeshRenderer>().sortingOrder = m_DefaultLayer;
		}
		m_Animation = GetComponent<SkeletonAnimation>();
		m_Animation.AnimationState.SetAnimation(0, m_Animation.skeleton.Data.Animations.Items[0], loopRun);
		if (!loopRun)
		{
			m_Animation.AnimationState.Complete += State_Complete;
		}
		m_Animation.AnimationState.Event += State_Event;
		m_Maxcombo = m_combo;
		m_MaxInjury = m_Injury;
	}

	private void State_Complete(TrackEntry trackEntry)
	{
		if (m_isFinalEffect && m_BattleObj != null)
		{
			SkillTraitEquipManager.RunLastAttack(m_BattleObj, base.transform.position);
			m_BattleObj.SetBattleObjState(BattleObjectState.ActionOver);
			m_BattleObj.AdjustAnimationSpeed(1f, Color.white);
		}
		if (SharedData.Instance().m_BattleController != null)
		{
			Object.Destroy(base.gameObject);
		}
	}

	private void State_Event(TrackEntry trackEntry, Spine.Event e)
	{
		if (!"behit".Equals(e.Data.Name))
		{
			return;
		}
		m_combo--;
		if (m_TargetObj != null)
		{
			m_Injury = m_MaxInjury * (1f + m_BattleObj.charadata.GetBattleValueByName("MultihitATKup") * (float)(m_Maxcombo - m_combo - 1));
			m_TargetObj.BeHitCal(m_combo, m_Injury);
		}
		if (m_BattleObj != null && m_combo <= 0)
		{
			ThroughoutSkillManage.ThroughoutSkill(m_BattleObj, base.transform.position);
			if (m_TargetObj == null)
			{
				ImpactSkiiManage.ImpactSkill(m_BattleObj, base.transform.position);
			}
			else
			{
				ImpactSkiiManage.isAlreadImpact = true;
			}
		}
		if (m_combo <= 0 && m_TargetObj == null && m_BattleObj != null)
		{
			SummonSkillManage.SummonSkill(m_BattleObj, base.transform.position);
		}
	}
}
