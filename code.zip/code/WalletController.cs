using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class WalletController : MonoBehaviour
{
	public Slider m_MoneySlider;

	public Text m_MoneyText;

	private bool isClosing;

	private void Start()
	{
		m_MoneySlider.maxValue = SharedData.Instance().m_Money;
		OnMoneyChanged();
	}

	private void OnEnable()
	{
		m_MoneySlider.maxValue = SharedData.Instance().m_Money;
		OnMoneyChanged();
		m_MoneySlider.value = 0f;
		EventSystem.current.SetSelectedGameObject(m_MoneySlider.gameObject);
		isClosing = false;
	}

	private void Update()
	{
		if (InputSystemCustom.Instance().UI.Confirm.WasReleasedThisFrame())
		{
			Confirm();
		}
		else if (InputDeviceDetector.isMouse1Up || InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
		{
			Cancel();
		}
	}

	public void Confirm()
	{
		if (!isClosing)
		{
			isClosing = true;
			SharedData.Instance().useItemID = "999";
			SharedData.Instance().m_BattlePackageStatus = 4;
			base.gameObject.SetActive(value: false);
		}
	}

	public void Cancel()
	{
		if (!isClosing)
		{
			isClosing = true;
			SharedData.Instance().m_MoneyForAttack = 0f;
			SharedData.Instance().m_BattlePackageStatus = 99;
			base.gameObject.SetActive(value: false);
		}
	}

	public void OnMoneyChanged()
	{
		SharedData.Instance().m_MoneyForAttack = m_MoneySlider.value;
		m_MoneyText.text = "-" + SharedData.Instance().m_MoneyForAttack;
	}
}
