using UnityEngine;
using UnityEngine.UI;

public class DebugGrass : MonoBehaviour
{
	public Text _WaveSpeed_Text;

	public Text _WaveScale_Text;

	public Text _SwingAmplitude_Text;

	public Text _SwingFrequency_Text;

	public Text _InteractiveDistanceFade_Text;

	public Text _InteractiveMaxInteractice;

	public Text _InteractiveMaxInteracticeShort_Text;

	public Text _TraceSamplingInterval_Text;

	public Text _TraceDistanceFade_Text;

	public Text _TraceMaxInteractice;

	public Text _TraceMaxInteracticeShrot_Text;

	public Slider _WaveSpeedSlider;

	public Slider _WaveScaleSlider;

	public Slider _SwingAmplitudeSlider;

	public Slider _SwingFrequencySlider;

	public Slider _InteractiveDistanceFadeSlider;

	public Slider _InteractiveMaxInteracticeOffsetSlider;

	public Slider _InteractiveMaxInteracticeShortSlider;

	public Slider _TraceDistanceFadeSlider;

	public Slider _TraceMaxInteracticeOffsetSlider;

	public Slider _TraceMaxInteracticeShortSlider;

	private bool isopen;

	public GameObject ui;

	public Toggle enableAlpha;

	public Toggle enableChangSorting;

	public Slider _Alpha_Value_Slider;

	public Slider _Alpha_Speed_Slider;

	public Text _Alpha_Value_Text;

	public Text _Alpha_Speed_Text;

	public Slider _Alpha_Dis_Slider;

	public Text _Alpha_Dis_Text;

	public Toggle enableTrace;

	public Slider _TraceSamplingInterval_Slider;

	public Slider _Trace_Length_Slider;

	public Slider _Trace_Fade_Slider;

	public Text _Trace_Length_Text;

	public Text _Trace_Fade_Text;

	private void Start()
	{
		_WaveSpeedSlider.value = SharedData.Instance().m_WaveSpeed;
		_WaveScaleSlider.value = SharedData.Instance().m_WaveScale;
		_SwingAmplitudeSlider.value = SharedData.Instance().m_SwingAmplitude;
		_SwingFrequencySlider.value = SharedData.Instance().m_SwingFrequency;
		_InteractiveDistanceFadeSlider.value = SharedData.Instance().m_InteractiveDistanceFade;
		_InteractiveMaxInteracticeOffsetSlider.value = SharedData.Instance().m_InteractiveMaxInteracticeOffset;
		_InteractiveMaxInteracticeShortSlider.value = SharedData.Instance().m_InteractiveMaxInteracticeShort;
		_TraceSamplingInterval_Slider.value = SharedData.Instance().m_TraceSamplingInterval;
		_Trace_Length_Slider.value = SharedData.Instance().m_Trace_Length;
		_Trace_Fade_Slider.value = SharedData.Instance().m_Trace_Fade;
		_TraceDistanceFadeSlider.value = SharedData.Instance().m_TraceDistanceFade;
		_TraceMaxInteracticeOffsetSlider.value = SharedData.Instance().m_TraceMaxInteracticeOffset;
		_TraceMaxInteracticeShortSlider.value = SharedData.Instance().m_TraceMaxInteracticeShort;
		enableAlpha.isOn = SharedData.Instance().isChangeAlpha;
		_Alpha_Value_Slider.value = SharedData.Instance().m_Alpha_Value;
		_Alpha_Speed_Slider.value = SharedData.Instance().m_Alpha_Speed;
		_Alpha_Dis_Slider.value = SharedData.Instance().m_Alpha_Dis;
		enableChangSorting.isOn = SharedData.Instance().isChangeSortingLayer;
		enableTrace.isOn = SharedData.Instance().isEnableTrace;
	}

	private void Update()
	{
		_WaveSpeed_Text.text = _WaveSpeedSlider.value.ToString();
		_WaveScale_Text.text = _WaveScaleSlider.value.ToString();
		_SwingAmplitude_Text.text = _SwingAmplitudeSlider.value.ToString();
		_SwingFrequency_Text.text = _SwingFrequencySlider.value.ToString();
		_InteractiveDistanceFade_Text.text = _InteractiveDistanceFadeSlider.value.ToString();
		_InteractiveMaxInteractice.text = _InteractiveMaxInteracticeOffsetSlider.value.ToString();
		_TraceDistanceFade_Text.text = _TraceDistanceFadeSlider.value.ToString();
		_TraceMaxInteractice.text = _TraceMaxInteracticeOffsetSlider.value.ToString();
		_Alpha_Value_Text.text = _Alpha_Value_Slider.value.ToString();
		_Alpha_Speed_Text.text = _Alpha_Speed_Slider.value.ToString();
		_Alpha_Dis_Text.text = _Alpha_Dis_Slider.value.ToString();
		_TraceSamplingInterval_Text.text = _TraceSamplingInterval_Slider.value.ToString();
		_Trace_Length_Text.text = ((int)_Trace_Length_Slider.value).ToString();
		_Trace_Fade_Text.text = _Trace_Fade_Slider.value.ToString();
		_InteractiveMaxInteracticeShort_Text.text = _InteractiveMaxInteracticeShortSlider.value.ToString();
		_TraceMaxInteracticeShrot_Text.text = _TraceMaxInteracticeShortSlider.value.ToString();
		SharedData.Instance().m_WaveSpeed = _WaveSpeedSlider.value;
		SharedData.Instance().m_WaveScale = _WaveScaleSlider.value;
		SharedData.Instance().m_SwingAmplitude = _SwingAmplitudeSlider.value;
		SharedData.Instance().m_SwingFrequency = _SwingFrequencySlider.value;
		SharedData.Instance().m_InteractiveDistanceFade = _InteractiveDistanceFadeSlider.value;
		SharedData.Instance().m_InteractiveMaxInteracticeOffset = _InteractiveMaxInteracticeOffsetSlider.value;
		SharedData.Instance().m_InteractiveMaxInteracticeShort = _InteractiveMaxInteracticeShortSlider.value;
		SharedData.Instance().m_TraceSamplingInterval = _TraceSamplingInterval_Slider.value;
		SharedData.Instance().m_Trace_Length = (int)_Trace_Length_Slider.value;
		SharedData.Instance().m_Trace_Fade = _Trace_Fade_Slider.value;
		SharedData.Instance().m_TraceDistanceFade = _TraceDistanceFadeSlider.value;
		SharedData.Instance().m_TraceMaxInteracticeOffset = _TraceMaxInteracticeOffsetSlider.value;
		SharedData.Instance().m_TraceMaxInteracticeShort = _TraceMaxInteracticeShortSlider.value;
		SharedData.Instance().isChangeAlpha = enableAlpha.isOn;
		SharedData.Instance().m_Alpha_Value = _Alpha_Value_Slider.value;
		SharedData.Instance().m_Alpha_Speed = _Alpha_Speed_Slider.value;
		SharedData.Instance().m_Alpha_Dis = _Alpha_Dis_Slider.value;
		SharedData.Instance().isChangeSortingLayer = enableChangSorting.isOn;
		SharedData.Instance().isEnableTrace = enableTrace.isOn;
	}

	public void OnOpenButtonClick()
	{
		ui.gameObject.SetActive(!isopen);
		isopen = !isopen;
	}
}
