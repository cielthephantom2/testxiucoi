using System.Collections.Generic;
using UnityEngine;

public class gang_b12Table
{
	public class Row
	{
		public string ID;

		public string TraitIndex;

		public string add1;

		public string attribute1;

		public string add2;

		public string attribute2;

		public string Note;

		public string Note_EN;

		public string Note_Trans => CommonFunc.ShortLangSel(Note, Note_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				ID = list[i][num++],
				TraitIndex = list[i][num++],
				add1 = list[i][num++],
				attribute1 = list[i][num++],
				add2 = list[i][num++],
				attribute2 = list[i][num++],
				Note = list[i][num++]
			};
			row.Note = I18nData.Instance().tableI18N.Find_ID("gang_b12_" + row.ID + "_Note")?.zh_CH;
			row.Note_EN = I18nData.Instance().tableI18N.Find_ID("gang_b12_" + row.ID + "_Note")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}
}
