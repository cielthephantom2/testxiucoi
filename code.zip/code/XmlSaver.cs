using System;
using System.Buffers;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using MessagePack;

public class XmlSaver
{
	private void Mount()
	{
	}

	private void UnMount()
	{
	}

	public string Encrypt(string toE)
	{
		return toE;
	}

	public string Decrypt(string toD, bool isEA = false)
	{
		if (!isEA)
		{
			return toD;
		}
		byte[] bytes = Encoding.UTF8.GetBytes("91429750903495708124650874157912");
		ICryptoTransform cryptoTransform = new RijndaelManaged
		{
			Key = bytes,
			Mode = CipherMode.ECB,
			Padding = PaddingMode.PKCS7
		}.CreateDecryptor();
		byte[] array = Convert.FromBase64String(toD);
		byte[] bytes2 = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
		return Encoding.UTF8.GetString(bytes2);
	}

	public string SerializeObject(object pObject, Type ty)
	{
		MethodInfo methodInfo = typeof(MessagePackSerializer).GetMethods(BindingFlags.Static | BindingFlags.Public).FirstOrDefault((MethodInfo m) => m.Name == "Serialize" && m.IsGenericMethodDefinition && m.GetParameters().Length == 3);
		object[] parameters = new object[3]
		{
			pObject,
			null,
			default(CancellationToken)
		};
		return Convert.ToBase64String((byte[])methodInfo.MakeGenericMethod(ty).Invoke(null, parameters));
	}

	public object DeserializeObject(string pXmlizedString, Type ty, bool isEA = false)
	{
		if ((pXmlizedString.Length >= 5 && pXmlizedString[0] == '<' && pXmlizedString[1] == '?' && pXmlizedString[2] == 'x' && pXmlizedString[3] == 'm' && pXmlizedString[4] == 'l') || isEA)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(ty);
			MemoryStream memoryStream = new MemoryStream(StringToUTF8ByteArray(pXmlizedString));
			new XmlTextWriter(memoryStream, Encoding.UTF8);
			return xmlSerializer.Deserialize(memoryStream);
		}
		byte[] array = Convert.FromBase64String(pXmlizedString);
		ReadOnlySequence<byte> readOnlySequence = new ReadOnlySequence<byte>(array);
		MethodInfo methodInfo = typeof(MessagePackSerializer).GetMethods(BindingFlags.Static | BindingFlags.Public).FirstOrDefault((MethodInfo m) => m.Name == "Deserialize" && m.IsGenericMethodDefinition && m.GetParameters().Length == 3);
		object[] parameters = new object[3]
		{
			readOnlySequence,
			null,
			default(CancellationToken)
		};
		return methodInfo.MakeGenericMethod(ty).Invoke(null, parameters);
	}

	public void CreateXML(string fileName, string thisData)
	{
		Mount();
		string value = Encrypt(thisData);
		StreamWriter streamWriter = File.CreateText(fileName);
		streamWriter.Write(value);
		streamWriter.Close();
		UnMount();
	}

	public string LoadXML(string fileName)
	{
		Mount();
		string text = "";
		StreamReader streamReader = File.OpenText(fileName);
		string text2 = streamReader.ReadToEnd();
		streamReader.Close();
		text = ((text2 != null && !(text2 == "")) ? Decrypt(text2) : "");
		UnMount();
		return text;
	}

	public static void DeletXML(string fileName)
	{
	}

	public bool hasFile(string fileName)
	{
		Mount();
		bool result = File.Exists(fileName);
		UnMount();
		return result;
	}

	public string GetLastWriteTime(string fileName)
	{
		Mount();
		string result = "";
		FileInfo fileInfo = new FileInfo(fileName);
		if (fileInfo.Exists)
		{
			result = fileInfo.LastWriteTime.ToString();
		}
		UnMount();
		return result;
	}

	public string UTF8ByteArrayToString(byte[] characters)
	{
		return new UTF8Encoding().GetString(characters);
	}

	public byte[] StringToUTF8ByteArray(string pXmlString)
	{
		return new UTF8Encoding().GetBytes(pXmlString);
	}
}
