using System.Collections.Generic;
using UnityEngine;

public class gang_b12WugongTypeTable
{
	public class Row
	{
		public string ID;

		public string Style;

		public string Name;

		public string Limit1;

		public string Limit2;

		public string A01;

		public string A02;

		public string A03;

		public string A04;

		public string A05;

		public string A06;

		public string A07;

		public string B01;

		public string B02;

		public string B03;

		public string B04;

		public string B05;

		public string C01;

		public string C02;

		public string C03;

		public string C04;

		public string D01;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Style = list[i][num++],
				Name = list[i][num++],
				Limit1 = list[i][num++],
				Limit2 = list[i][num++],
				A01 = list[i][num++],
				A02 = list[i][num++],
				A03 = list[i][num++],
				A04 = list[i][num++],
				A05 = list[i][num++],
				A06 = list[i][num++],
				A07 = list[i][num++],
				B01 = list[i][num++],
				B02 = list[i][num++],
				B03 = list[i][num++],
				B04 = list[i][num++],
				B05 = list[i][num++],
				C01 = list[i][num++],
				C02 = list[i][num++],
				C03 = list[i][num++],
				C04 = list[i][num++],
				D01 = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Style(string find)
	{
		return rowList.Find((Row x) => x.Style == find);
	}

	public List<Row> FindAll_Style(string find)
	{
		return rowList.FindAll((Row x) => x.Style == find);
	}
}
