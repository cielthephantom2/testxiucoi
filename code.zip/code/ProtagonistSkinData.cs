using MessagePack;

[MessagePackObject(false)]
public class ProtagonistSkinData
{
	[Key(0)]
	public SkinType SkinType;

	[Key(1)]
	public int Face;

	[Key(2)]
	public int Hair;

	[Key(3)]
	public int Clothes;

	[Key(4)]
	public int Hat;

	[Key(5)]
	public int FaceMask;

	[Key(6)]
	public int Cloak;

	[Key(7)]
	public int Beard;
}
