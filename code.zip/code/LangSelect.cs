using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LangSelect : MonoBehaviour
{
	private string language = "";

	public string TextCHN = "";

	public string TextENG = "";

	public string TextJPN = "";

	public Sprite spriteCHN;

	public Sprite spriteCHT;

	public Sprite spriteENG;

	public Sprite spriteJPN;

	private Text text;

	private TMP_Text tMP_Text;

	private void Start()
	{
		InitLang();
	}

	private void Update()
	{
		if (GameDataManager.Instance().configdata.language != language)
		{
			InitLang();
		}
	}

	private void InitLang()
	{
		SharedData.Instance();
		text = GetComponent<Text>();
		tMP_Text = GetComponent<TMP_Text>();
		Image component = GetComponent<Image>();
		if (text != null)
		{
			gang_t01Table.Row row = CommonResourcesData.t01.Find_id(TextCHN);
			if (row != null)
			{
				text.text = CommonFunc.ShortLangSel(row.CHN, row.ENG).Replace('|', '\n');
			}
			else
			{
				text.text = CommonFunc.ShortLangSel(TextCHN, TextENG).Replace('|', '\n');
			}
		}
		if (tMP_Text != null)
		{
			gang_t01Table.Row row2 = CommonResourcesData.t01.Find_id(TextCHN);
			if (row2 != null)
			{
				tMP_Text.text = CommonFunc.ShortLangSel(row2.CHN, row2.ENG).Replace('|', '\n');
			}
			else
			{
				tMP_Text.text = CommonFunc.ShortLangSel(TextCHN, TextENG).Replace('|', '\n');
			}
		}
		if (component != null)
		{
			switch (GameDataManager.Instance().configdata.language)
			{
			case "English":
				component.sprite = spriteENG;
				break;
			case "ChineseTraditional":
				component.sprite = spriteCHT;
				break;
			case "Japanese":
				component.sprite = spriteJPN;
				break;
			default:
				component.sprite = spriteCHN;
				break;
			}
		}
		language = GameDataManager.Instance().configdata.language;
	}
}
