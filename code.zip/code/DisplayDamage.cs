using UnityEngine;

public class DisplayDamage
{
	public string damage;

	public string type;

	public bool isShow;

	public int beat;

	public bool critical;

	public GameObject damageObj;
}
