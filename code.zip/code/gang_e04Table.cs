using System.Collections.Generic;
using UnityEngine;

public class gang_e04Table
{
	public class Row
	{
		public string id;

		public string mapName;

		public string bgm;

		public string AreaName;

		public string name_chn;

		public string name_eng;

		public string savedata;

		public string teleport;

		public string maplocation;

		public string leave;

		public string name_Trans => CommonFunc.ShortLangSel(name_chn, name_eng);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				id = list[i][num++],
				mapName = list[i][num++],
				bgm = list[i][num++],
				AreaName = list[i][num++],
				name_chn = list[i][num++],
				name_eng = list[i][num++],
				savedata = list[i][num++],
				teleport = list[i][num++],
				maplocation = list[i][num++],
				leave = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_id(string find)
	{
		return rowList.Find((Row x) => x.id == find);
	}

	public List<Row> FindAll_id(string find)
	{
		return rowList.FindAll((Row x) => x.id == find);
	}

	public Row Find_mapName(string find)
	{
		return rowList.Find((Row x) => x.mapName == find);
	}

	public Row Find_name_chn(string find)
	{
		return rowList.Find((Row x) => x.name_chn == find);
	}

	public List<Row> FindAll_name_chn(string find)
	{
		return rowList.FindAll((Row x) => x.name_chn == find);
	}

	public Row Find_name_eng(string find)
	{
		return rowList.Find((Row x) => x.name_eng == find);
	}

	public List<Row> FindAll_name_eng(string find)
	{
		return rowList.FindAll((Row x) => x.name_eng == find);
	}

	public Row Find_savedata(string find)
	{
		return rowList.Find((Row x) => x.savedata == find);
	}

	public List<Row> FindAll_savedata(string find)
	{
		return rowList.FindAll((Row x) => x.savedata == find);
	}

	public Row Find_maplocation(string find)
	{
		return rowList.Find((Row x) => x.maplocation == find);
	}

	public List<Row> FindAll_maplocation(string find)
	{
		return rowList.FindAll((Row x) => x.maplocation == find);
	}

	public Row Find_leave(string find)
	{
		return rowList.Find((Row x) => x.leave == find);
	}

	public List<Row> FindAll_leave(string find)
	{
		return rowList.FindAll((Row x) => x.leave == find);
	}
}
