using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class StatusSub6 : MonoBehaviour
{
	private void Awake()
	{
		SharedData.Instance().m_StatusSub6 = this;
	}

	private void OnEnable()
	{
		if (SharedData.Instance().CurrentChara == "")
		{
			return;
		}
		CharaData currentCharaData = SharedData.Instance().CurrentCharaData;
		if (currentCharaData == null)
		{
			return;
		}
		base.transform.Find("Panel/Area1/Name").GetComponent<Text>().text = currentCharaData.Indexs_Name["Name"].stringValue;
		base.transform.Find("Panel/Area1/LV/Num").GetComponent<Text>().text = currentCharaData.m_Level.ToString() ?? "";
		gang_a05Table.Row row = CommonResourcesData.a05.Find_LV(currentCharaData.m_Level.ToString() ?? "");
		base.transform.Find("Panel/Area1/Exp/Num").GetComponent<Text>().text = currentCharaData.m_Exp + "/" + row.EXP;
		base.transform.Find("Panel/Area1/ExpBar").GetComponent<Slider>().value = (float)currentCharaData.m_Exp / float.Parse(row.EXP, CultureInfo.InvariantCulture);
		gang_b01Table.Row row2 = CommonResourcesData.b01.Find_ID(SharedData.Instance().CurrentChara);
		base.transform.Find("Panel/Status/Line1/Sex/Text1").GetComponent<Text>().text = ("1".Equals(row2.Sex) ? CommonFunc.I18nGetLocalizedValue("I18N_Man") : CommonFunc.I18nGetLocalizedValue("I18N_Woman"));
		gang_b06Table.Row row3 = CommonResourcesData.b06.Find_id(currentCharaData.m_currentTitleID);
		if (row3 != null)
		{
			base.transform.Find("Panel/Status/Nickname/Text1").GetComponent<Text>().text = row3.name_Trans;
		}
		else
		{
			base.transform.Find("Panel/Status/Nickname/Text1").GetComponent<Text>().text = currentCharaData.m_NickName;
		}
		gang_b10Table.Row row4 = CommonResourcesData.b10.Find_ID(currentCharaData.m_Guild);
		if (row4 != null)
		{
			base.transform.Find("Panel/Status/Guild/Text1").GetComponent<Text>().text = row4.Name_Trans;
		}
		else
		{
			base.transform.Find("Panel/Status/Guild/Text1").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_Null");
		}
		if (SharedData.Instance().CurrentChara.Equals(SharedData.Instance().playerid))
		{
			gang_a02Table.Row row5 = CommonResourcesData.a02.Find_ID(SharedData.Instance().BornID);
			if (row5 != null)
			{
				base.transform.Find("Panel/Status/Line1/Age/Text1").GetComponent<Text>().text = row5.Age;
				base.transform.Find("Panel/Status/Duty/Text1").GetComponent<Text>().text = row5.Duty_Trans;
				base.transform.Find("Panel/Status/Born/Text1").GetComponent<Text>().text = row5.Birthplace_Trans;
				base.transform.Find("Panel/Status/Birth/Text1").GetComponent<Text>().text = row5.Birthdate_Trans;
				base.transform.Find("Panel/Status/Fate/Text1").GetComponent<Text>().text = row5.Lifecode_Trans;
				base.transform.Find("Panel/Status/Country/Text1").GetComponent<Text>().text = row5.Position_Trans;
				base.transform.Find("Panel/Detail/Text").GetComponent<Text>().text = row5.Note_Trans;
			}
			else
			{
				base.transform.Find("Panel/Status/Line1/Age/Text1").GetComponent<Text>().text = row2.Age;
				base.transform.Find("Panel/Status/Duty/Text1").GetComponent<Text>().text = row2.Duty_Trans;
				base.transform.Find("Panel/Status/Born/Text1").GetComponent<Text>().text = row2.Birthplace_Trans;
				base.transform.Find("Panel/Status/Birth/Text1").GetComponent<Text>().text = row2.Birthdate_Trans;
				base.transform.Find("Panel/Status/Fate/Text1").GetComponent<Text>().text = row2.Lifecode_Trans;
				base.transform.Find("Panel/Status/Country/Text1").GetComponent<Text>().text = row2.Position_Trans;
				base.transform.Find("Panel/Detail/Text").GetComponent<Text>().text = row2.Background_Trans;
			}
		}
		else
		{
			base.transform.Find("Panel/Status/Line1/Age/Text1").GetComponent<Text>().text = row2.Age;
			base.transform.Find("Panel/Status/Duty/Text1").GetComponent<Text>().text = row2.Duty_Trans;
			base.transform.Find("Panel/Status/Born/Text1").GetComponent<Text>().text = row2.Birthplace_Trans;
			base.transform.Find("Panel/Status/Birth/Text1").GetComponent<Text>().text = row2.Birthdate_Trans;
			base.transform.Find("Panel/Status/Fate/Text1").GetComponent<Text>().text = row2.Lifecode_Trans;
			base.transform.Find("Panel/Status/Country/Text1").GetComponent<Text>().text = row2.Position_Trans;
			base.transform.Find("Panel/Detail/Text").GetComponent<Text>().text = row2.Background_Trans;
		}
		Transform transform = base.transform.Find("Panel/Character");
		CharaData currentCharaData2 = SharedData.Instance().CurrentCharaData;
		transform.Find("Icon").GetComponent<InitCharacterIcon>().InitCharacterSkinIcon(currentCharaData2);
		transform.Find("Tachie").gameObject.SetActive(value: false);
		if (currentCharaData2.m_BattleIcon != "")
		{
			Sprite tachieFull = CommonResourcesData.GetTachieFull(currentCharaData2.m_BattleIcon);
			if (tachieFull != null)
			{
				transform.Find("Tachie").gameObject.SetActive(value: true);
				transform.Find("Tachie/Tachie").GetComponent<Image>().sprite = tachieFull;
			}
		}
	}
}
