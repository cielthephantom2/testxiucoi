using System.Collections.Generic;
using UnityEngine;

public class gang_b04Table
{
	public class Row
	{
		public string GID;

		public string Note;

		public string ID;

		public string B01ID;

		public string Type;

		public string Side;

		public string Sex;

		public string KeyPos;

		public string SetData;

		public string Prefab;

		public string Sound;

		public string BattleIcon;

		public string Name;

		public string Name_EN;

		public string Age;

		public string Depth;

		public string Depthvalue;

		public string Ranking;

		public string Guild;

		public string Guild_EN;

		public string Duty;

		public string Duty_EN;

		public string Nickname;

		public string Birthplace;

		public string Birthplace_EN;

		public string EXP;

		public string AiType;

		public string Lvlimit;

		public string LV;

		public string HP;

		public string HP1;

		public string MP;

		public string MP1;

		public string ATK;

		public string ATK1;

		public string DEF;

		public string DEF1;

		public string SP;

		public string SP1;

		public string DropID;

		public string mustDropID;

		public string kongfu1;

		public string KFLV1;

		public string kongfu2;

		public string KFLV2;

		public string kongfu3;

		public string KFLV3;

		public string kongfu4;

		public string KFLV4;

		public string kongfu5;

		public string KFLV5;

		public string Traits;

		public string Movement;

		public string STR;

		public string STR1;

		public string AGI;

		public string AGI1;

		public string BON;

		public string BON1;

		public string WIL;

		public string WIL1;

		public string LER;

		public string LER1;

		public string MOR;

		public string MOR1;

		public string Sword;

		public string Sword1;

		public string Knife;

		public string Knife1;

		public string Stick;

		public string Stick1;

		public string Hand;

		public string Hand1;

		public string Finger;

		public string Finger1;

		public string Special;

		public string Special1;

		public string YinYang;

		public string YinYang1;

		public string Melody;

		public string Melody1;

		public string Making;

		public string Making1;

		public string Darts;

		public string Darts1;

		public string Wineart;

		public string Wineart1;

		public string Steal;

		public string Steal1;

		public string Forge;

		public string Forge1;

		public string Percept;

		public string Percept1;

		public string separateexp;

		public string Name_Trans => CommonFunc.ShortLangSel(Name, Name_EN);

		public string Guild_Trans => CommonFunc.ShortLangSel(Guild, Guild_EN);

		public string Duty_Trans => CommonFunc.ShortLangSel(Duty, Duty_EN);

		public string Birthplace_Trans => CommonFunc.ShortLangSel(Birthplace, Birthplace_EN);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv, bool isRandom = false)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row
			{
				GID = list[i][num++],
				Note = list[i][num++],
				ID = list[i][num++],
				B01ID = list[i][num++],
				Type = list[i][num++],
				Side = list[i][num++],
				Sex = list[i][num++],
				KeyPos = list[i][num++],
				SetData = list[i][num++],
				Prefab = list[i][num++],
				Sound = list[i][num++],
				BattleIcon = list[i][num++],
				Name = list[i][num++],
				Age = list[i][num++],
				Depth = list[i][num++],
				Depthvalue = list[i][num++],
				Ranking = list[i][num++],
				Guild = list[i][num++],
				Duty = list[i][num++],
				Nickname = list[i][num++],
				Birthplace = list[i][num++],
				EXP = list[i][num++],
				AiType = list[i][num++],
				Lvlimit = list[i][num++],
				LV = list[i][num++],
				HP = list[i][num++],
				HP1 = list[i][num++],
				MP = list[i][num++],
				MP1 = list[i][num++],
				ATK = list[i][num++],
				ATK1 = list[i][num++],
				DEF = list[i][num++],
				DEF1 = list[i][num++],
				SP = list[i][num++],
				SP1 = list[i][num++],
				DropID = list[i][num++],
				mustDropID = list[i][num++],
				kongfu1 = list[i][num++],
				KFLV1 = list[i][num++],
				kongfu2 = list[i][num++],
				KFLV2 = list[i][num++],
				kongfu3 = list[i][num++],
				KFLV3 = list[i][num++],
				kongfu4 = list[i][num++],
				KFLV4 = list[i][num++],
				kongfu5 = list[i][num++],
				KFLV5 = list[i][num++],
				Traits = list[i][num++],
				Movement = list[i][num++],
				STR = list[i][num++],
				STR1 = list[i][num++],
				AGI = list[i][num++],
				AGI1 = list[i][num++],
				BON = list[i][num++],
				BON1 = list[i][num++],
				WIL = list[i][num++],
				WIL1 = list[i][num++],
				LER = list[i][num++],
				LER1 = list[i][num++],
				MOR = list[i][num++],
				MOR1 = list[i][num++],
				Sword = list[i][num++],
				Sword1 = list[i][num++],
				Knife = list[i][num++],
				Knife1 = list[i][num++],
				Stick = list[i][num++],
				Stick1 = list[i][num++],
				Hand = list[i][num++],
				Hand1 = list[i][num++],
				Finger = list[i][num++],
				Finger1 = list[i][num++],
				Special = list[i][num++],
				Special1 = list[i][num++],
				YinYang = list[i][num++],
				YinYang1 = list[i][num++],
				Melody = list[i][num++],
				Melody1 = list[i][num++],
				Making = list[i][num++],
				Making1 = list[i][num++],
				Darts = list[i][num++],
				Darts1 = list[i][num++],
				Wineart = list[i][num++],
				Wineart1 = list[i][num++],
				Steal = list[i][num++],
				Steal1 = list[i][num++],
				Forge = list[i][num++],
				Forge1 = list[i][num++],
				Percept = list[i][num++],
				Percept1 = list[i][num++],
				separateexp = list[i][num++]
			};
			string text = "gang_b04_";
			if (isRandom)
			{
				text = "gang_b04_Random_";
			}
			string text2 = text + row.GID + "_" + row.ID;
			row.Name = I18nData.Instance().tableI18N.Find_ID(text2 + "_Name")?.zh_CH;
			row.Name_EN = I18nData.Instance().tableI18N.Find_ID(text2 + "_Name")?.en_US;
			row.Guild = I18nData.Instance().tableI18N.Find_ID(text2 + "_Guild")?.zh_CH;
			row.Guild_EN = I18nData.Instance().tableI18N.Find_ID(text2 + "_Guild")?.en_US;
			row.Duty = I18nData.Instance().tableI18N.Find_ID(text2 + "_Duty")?.zh_CH;
			row.Duty_EN = I18nData.Instance().tableI18N.Find_ID(text2 + "_Duty")?.en_US;
			row.Birthplace = I18nData.Instance().tableI18N.Find_ID(text2 + "_Birthplace")?.zh_CH;
			row.Birthplace_EN = I18nData.Instance().tableI18N.Find_ID(text2 + "_Birthplace")?.en_US;
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_GID(string find)
	{
		return rowList.Find((Row x) => x.GID == find);
	}

	public List<Row> FindAll_GID(string find)
	{
		return rowList.FindAll((Row x) => x.GID == find);
	}

	public Row Find_Note(string find)
	{
		return rowList.Find((Row x) => x.Note == find);
	}

	public List<Row> FindAll_Note(string find)
	{
		return rowList.FindAll((Row x) => x.Note == find);
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_B01ID(string find)
	{
		return rowList.Find((Row x) => x.B01ID == find);
	}

	public List<Row> FindAll_B01ID(string find)
	{
		return rowList.FindAll((Row x) => x.B01ID == find);
	}

	public Row Find_Type(string find)
	{
		return rowList.Find((Row x) => x.Type == find);
	}

	public List<Row> FindAll_Type(string find)
	{
		return rowList.FindAll((Row x) => x.Type == find);
	}

	public Row Find_Side(string find)
	{
		return rowList.Find((Row x) => x.Side == find);
	}

	public List<Row> FindAll_Side(string find)
	{
		return rowList.FindAll((Row x) => x.Side == find);
	}

	public Row Find_Sex(string find)
	{
		return rowList.Find((Row x) => x.Sex == find);
	}

	public List<Row> FindAll_Sex(string find)
	{
		return rowList.FindAll((Row x) => x.Sex == find);
	}

	public Row Find_KeyPos(string find)
	{
		return rowList.Find((Row x) => x.KeyPos == find);
	}

	public List<Row> FindAll_KeyPos(string find)
	{
		return rowList.FindAll((Row x) => x.KeyPos == find);
	}

	public Row Find_SetData(string find)
	{
		return rowList.Find((Row x) => x.SetData == find);
	}

	public List<Row> FindAll_SetData(string find)
	{
		return rowList.FindAll((Row x) => x.SetData == find);
	}

	public Row Find_Prefab(string find)
	{
		return rowList.Find((Row x) => x.Prefab == find);
	}

	public List<Row> FindAll_Prefab(string find)
	{
		return rowList.FindAll((Row x) => x.Prefab == find);
	}

	public Row Find_Sound(string find)
	{
		return rowList.Find((Row x) => x.Sound == find);
	}

	public List<Row> FindAll_Sound(string find)
	{
		return rowList.FindAll((Row x) => x.Sound == find);
	}

	public Row Find_BattleIcon(string find)
	{
		return rowList.Find((Row x) => x.BattleIcon == find);
	}

	public List<Row> FindAll_BattleIcon(string find)
	{
		return rowList.FindAll((Row x) => x.BattleIcon == find);
	}

	public Row Find_Name(string find)
	{
		return rowList.Find((Row x) => x.Name == find);
	}

	public List<Row> FindAll_Name(string find)
	{
		return rowList.FindAll((Row x) => x.Name == find);
	}

	public Row Find_Age(string find)
	{
		return rowList.Find((Row x) => x.Age == find);
	}

	public List<Row> FindAll_Age(string find)
	{
		return rowList.FindAll((Row x) => x.Age == find);
	}

	public Row Find_Depth(string find)
	{
		return rowList.Find((Row x) => x.Depth == find);
	}

	public List<Row> FindAll_Depth(string find)
	{
		return rowList.FindAll((Row x) => x.Depth == find);
	}

	public Row Find_Depthvalue(string find)
	{
		return rowList.Find((Row x) => x.Depthvalue == find);
	}

	public List<Row> FindAll_Depthvalue(string find)
	{
		return rowList.FindAll((Row x) => x.Depthvalue == find);
	}

	public Row Find_Ranking(string find)
	{
		return rowList.Find((Row x) => x.Ranking == find);
	}

	public List<Row> FindAll_Ranking(string find)
	{
		return rowList.FindAll((Row x) => x.Ranking == find);
	}

	public Row Find_Guild(string find)
	{
		return rowList.Find((Row x) => x.Guild == find);
	}

	public List<Row> FindAll_Guild(string find)
	{
		return rowList.FindAll((Row x) => x.Guild == find);
	}

	public Row Find_Duty(string find)
	{
		return rowList.Find((Row x) => x.Duty == find);
	}

	public List<Row> FindAll_Duty(string find)
	{
		return rowList.FindAll((Row x) => x.Duty == find);
	}

	public Row Find_Nickname(string find)
	{
		return rowList.Find((Row x) => x.Nickname == find);
	}

	public List<Row> FindAll_Nickname(string find)
	{
		return rowList.FindAll((Row x) => x.Nickname == find);
	}

	public Row Find_Birthplace(string find)
	{
		return rowList.Find((Row x) => x.Birthplace == find);
	}

	public List<Row> FindAll_Birthplace(string find)
	{
		return rowList.FindAll((Row x) => x.Birthplace == find);
	}

	public Row Find_EXP(string find)
	{
		return rowList.Find((Row x) => x.EXP == find);
	}

	public List<Row> FindAll_EXP(string find)
	{
		return rowList.FindAll((Row x) => x.EXP == find);
	}

	public Row Find_AiType(string find)
	{
		return rowList.Find((Row x) => x.AiType == find);
	}

	public List<Row> FindAll_AiType(string find)
	{
		return rowList.FindAll((Row x) => x.AiType == find);
	}

	public Row Find_Lvlimit(string find)
	{
		return rowList.Find((Row x) => x.Lvlimit == find);
	}

	public List<Row> FindAll_Lvlimit(string find)
	{
		return rowList.FindAll((Row x) => x.Lvlimit == find);
	}

	public Row Find_LV(string find)
	{
		return rowList.Find((Row x) => x.LV == find);
	}

	public List<Row> FindAll_LV(string find)
	{
		return rowList.FindAll((Row x) => x.LV == find);
	}

	public Row Find_HP(string find)
	{
		return rowList.Find((Row x) => x.HP == find);
	}

	public List<Row> FindAll_HP(string find)
	{
		return rowList.FindAll((Row x) => x.HP == find);
	}

	public Row Find_MP(string find)
	{
		return rowList.Find((Row x) => x.MP == find);
	}

	public List<Row> FindAll_MP(string find)
	{
		return rowList.FindAll((Row x) => x.MP == find);
	}

	public Row Find_ATK(string find)
	{
		return rowList.Find((Row x) => x.ATK == find);
	}

	public List<Row> FindAll_ATK(string find)
	{
		return rowList.FindAll((Row x) => x.ATK == find);
	}

	public Row Find_DEF(string find)
	{
		return rowList.Find((Row x) => x.DEF == find);
	}

	public List<Row> FindAll_DEF(string find)
	{
		return rowList.FindAll((Row x) => x.DEF == find);
	}

	public Row Find_SP(string find)
	{
		return rowList.Find((Row x) => x.SP == find);
	}

	public List<Row> FindAll_SP(string find)
	{
		return rowList.FindAll((Row x) => x.SP == find);
	}

	public Row Find_DropID(string find)
	{
		return rowList.Find((Row x) => x.DropID == find);
	}

	public List<Row> FindAll_DropID(string find)
	{
		return rowList.FindAll((Row x) => x.DropID == find);
	}

	public Row Find_kongfu1(string find)
	{
		return rowList.Find((Row x) => x.kongfu1 == find);
	}

	public List<Row> FindAll_kongfu1(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu1 == find);
	}

	public Row Find_KFLV1(string find)
	{
		return rowList.Find((Row x) => x.KFLV1 == find);
	}

	public List<Row> FindAll_KFLV1(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV1 == find);
	}

	public Row Find_kongfu2(string find)
	{
		return rowList.Find((Row x) => x.kongfu2 == find);
	}

	public List<Row> FindAll_kongfu2(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu2 == find);
	}

	public Row Find_KFLV2(string find)
	{
		return rowList.Find((Row x) => x.KFLV2 == find);
	}

	public List<Row> FindAll_KFLV2(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV2 == find);
	}

	public Row Find_kongfu3(string find)
	{
		return rowList.Find((Row x) => x.kongfu3 == find);
	}

	public List<Row> FindAll_kongfu3(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu3 == find);
	}

	public Row Find_KFLV3(string find)
	{
		return rowList.Find((Row x) => x.KFLV3 == find);
	}

	public List<Row> FindAll_KFLV3(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV3 == find);
	}

	public Row Find_kongfu4(string find)
	{
		return rowList.Find((Row x) => x.kongfu4 == find);
	}

	public List<Row> FindAll_kongfu4(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu4 == find);
	}

	public Row Find_KFLV4(string find)
	{
		return rowList.Find((Row x) => x.KFLV4 == find);
	}

	public List<Row> FindAll_KFLV4(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV4 == find);
	}

	public Row Find_kongfu5(string find)
	{
		return rowList.Find((Row x) => x.kongfu5 == find);
	}

	public List<Row> FindAll_kongfu5(string find)
	{
		return rowList.FindAll((Row x) => x.kongfu5 == find);
	}

	public Row Find_KFLV5(string find)
	{
		return rowList.Find((Row x) => x.KFLV5 == find);
	}

	public List<Row> FindAll_KFLV5(string find)
	{
		return rowList.FindAll((Row x) => x.KFLV5 == find);
	}

	public Row Find_Traits(string find)
	{
		return rowList.Find((Row x) => x.Traits == find);
	}

	public List<Row> FindAll_Traits(string find)
	{
		return rowList.FindAll((Row x) => x.Traits == find);
	}

	public Row Find_Movement(string find)
	{
		return rowList.Find((Row x) => x.Movement == find);
	}

	public List<Row> FindAll_Movement(string find)
	{
		return rowList.FindAll((Row x) => x.Movement == find);
	}

	public Row Find_STR(string find)
	{
		return rowList.Find((Row x) => x.STR == find);
	}

	public List<Row> FindAll_STR(string find)
	{
		return rowList.FindAll((Row x) => x.STR == find);
	}

	public Row Find_AGI(string find)
	{
		return rowList.Find((Row x) => x.AGI == find);
	}

	public List<Row> FindAll_AGI(string find)
	{
		return rowList.FindAll((Row x) => x.AGI == find);
	}

	public Row Find_BON(string find)
	{
		return rowList.Find((Row x) => x.BON == find);
	}

	public List<Row> FindAll_BON(string find)
	{
		return rowList.FindAll((Row x) => x.BON == find);
	}

	public Row Find_WIL(string find)
	{
		return rowList.Find((Row x) => x.WIL == find);
	}

	public List<Row> FindAll_WIL(string find)
	{
		return rowList.FindAll((Row x) => x.WIL == find);
	}

	public Row Find_LER(string find)
	{
		return rowList.Find((Row x) => x.LER == find);
	}

	public List<Row> FindAll_LER(string find)
	{
		return rowList.FindAll((Row x) => x.LER == find);
	}

	public Row Find_MOR(string find)
	{
		return rowList.Find((Row x) => x.MOR == find);
	}

	public List<Row> FindAll_MOR(string find)
	{
		return rowList.FindAll((Row x) => x.MOR == find);
	}

	public Row Find_Sword(string find)
	{
		return rowList.Find((Row x) => x.Sword == find);
	}

	public List<Row> FindAll_Sword(string find)
	{
		return rowList.FindAll((Row x) => x.Sword == find);
	}

	public Row Find_Knife(string find)
	{
		return rowList.Find((Row x) => x.Knife == find);
	}

	public List<Row> FindAll_Knife(string find)
	{
		return rowList.FindAll((Row x) => x.Knife == find);
	}

	public Row Find_Stick(string find)
	{
		return rowList.Find((Row x) => x.Stick == find);
	}

	public List<Row> FindAll_Stick(string find)
	{
		return rowList.FindAll((Row x) => x.Stick == find);
	}

	public Row Find_Hand(string find)
	{
		return rowList.Find((Row x) => x.Hand == find);
	}

	public List<Row> FindAll_Hand(string find)
	{
		return rowList.FindAll((Row x) => x.Hand == find);
	}

	public Row Find_Finger(string find)
	{
		return rowList.Find((Row x) => x.Finger == find);
	}

	public List<Row> FindAll_Finger(string find)
	{
		return rowList.FindAll((Row x) => x.Finger == find);
	}

	public Row Find_Special(string find)
	{
		return rowList.Find((Row x) => x.Special == find);
	}

	public List<Row> FindAll_Special(string find)
	{
		return rowList.FindAll((Row x) => x.Special == find);
	}

	public Row Find_YinYang(string find)
	{
		return rowList.Find((Row x) => x.YinYang == find);
	}

	public List<Row> FindAll_YinYang(string find)
	{
		return rowList.FindAll((Row x) => x.YinYang == find);
	}

	public Row Find_Melody(string find)
	{
		return rowList.Find((Row x) => x.Melody == find);
	}

	public List<Row> FindAll_Melody(string find)
	{
		return rowList.FindAll((Row x) => x.Melody == find);
	}

	public Row Find_Making(string find)
	{
		return rowList.Find((Row x) => x.Making == find);
	}

	public List<Row> FindAll_Making(string find)
	{
		return rowList.FindAll((Row x) => x.Making == find);
	}

	public Row Find_Darts(string find)
	{
		return rowList.Find((Row x) => x.Darts == find);
	}

	public List<Row> FindAll_Darts(string find)
	{
		return rowList.FindAll((Row x) => x.Darts == find);
	}

	public Row Find_Wineart(string find)
	{
		return rowList.Find((Row x) => x.Wineart == find);
	}

	public List<Row> FindAll_Wineart(string find)
	{
		return rowList.FindAll((Row x) => x.Wineart == find);
	}

	public Row Find_Steal(string find)
	{
		return rowList.Find((Row x) => x.Steal == find);
	}

	public List<Row> FindAll_Steal(string find)
	{
		return rowList.FindAll((Row x) => x.Steal == find);
	}
}
