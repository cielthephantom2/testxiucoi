public enum LoadDataType
{
	Manual,
	Auto
}
