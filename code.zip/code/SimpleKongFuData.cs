using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class SimpleKongFuData
{
	[Key(0)]
	public string id;

	[Key(1)]
	public int lv;

	[Key(2)]
	public float exp;

	[Key(3)]
	public int proficiency;

	[Key(4)]
	public bool isAbolished;
}
