public enum RebellionType
{
	None,
	Charm,
	Bribe,
	Temptation,
	ControlMad,
	SaveMad,
	ElfBall
}
