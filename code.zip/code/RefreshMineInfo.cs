using System;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class RefreshMineInfo
{
	[Key(0)]
	public string _scenename;

	[Key(1)]
	public bool _couldRefresh;
}
