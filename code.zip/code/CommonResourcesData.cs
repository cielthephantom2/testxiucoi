using System.Collections.Generic;
using JiebaNet.Segmenter;
using OpenCCNET;
using UnityEngine;
using UnityEngine.U2D;

public static class CommonResourcesData
{
	public static bool isLoadAllResources = false;

	public static bool isInitAllResources = false;

	public static gang_a01Table a01 = null;

	public static gang_a02Table a02 = null;

	public static gang_a05Table a05 = null;

	public static gang_a06Table a06 = null;

	public static gang_a07Table a07 = null;

	public static gang_b01Table b01 = null;

	public static gang_b01SkinTable b01Skin = null;

	public static gang_b01SkinTable b01ChangeSkin = null;

	public static gang_b02Table b02 = null;

	public static gang_b02SetTable b02Set = null;

	public static Dictionary<string, List<string>> b02SetDict = new Dictionary<string, List<string>>();

	public static gang_b02EvolutionTable b02Evolution = null;

	public static List<gang_b02Table.Row> b02append = new List<gang_b02Table.Row>();

	public static gang_b03Table b03 = null;

	public static gang_b03_SkiillEffect_Table b03SkillEffect = null;

	public static List<gang_b03Table.Row> b03append = new List<gang_b03Table.Row>();

	public static gang_b04Table b04 = null;

	public static gang_b04Table b04_Random = null;

	public static gang_b04RandomFightInfos b04RandomFightInfos = null;

	public static gang_b05Table b05 = null;

	public static gang_b06Table b06 = null;

	public static gang_b06ChainTable b06Chain = null;

	public static gang_b07Table b07 = null;

	public static List<gang_b07Table.Row> b07append = new List<gang_b07Table.Row>();

	public static gang_b08Table b08 = null;

	public static gang_b09Table b09 = null;

	public static gang_b10Table b10 = null;

	public static gang_b11Table b11 = null;

	public static gang_b12Table b12 = null;

	public static gang_b12WugongTypeTable b12WugongType = null;

	public static gang_b12WugongStarLimit b12WugongStarLimit = null;

	public static gang_b12WugongTypeAttackArea b12WugongTypeAttackArea = null;

	public static gang_b13Table b13 = null;

	public static gang_b14Table b14 = null;

	public static gang_b15Table b15 = null;

	public static gang_b16Table b16 = null;

	public static gang_c01Table c01 = null;

	public static gang_c02Table c02 = null;

	public static gang_c03Table c03 = null;

	public static gang_c04Table c04 = null;

	public static gang_e01Table e01 = null;

	public static gang_e02Table e02 = null;

	public static gang_e03Table e03 = null;

	public static gang_e04Table e04 = null;

	public static gang_e06Table e06 = null;

	public static gang_e07Table e07 = null;

	public static gang_t01Table t01 = null;

	public static gang_f01Table f01 = null;

	public static gang_f02Table f02 = null;

	public static SensitiveWord0Table sw0 = null;

	private static GameObject _m_CurcorPrefab = null;

	private static GameObject _m_DamagePrefab = null;

	private static GameObject _m_InfoPrefab = null;

	private static GameObject _m_CriticalPrefab = null;

	private static GameObject _m_HealPrefab = null;

	private static GameObject _m_MpPrefab = null;

	private static GameObject _m_PoisonPrefab = null;

	private static GameObject _m_BleedPrefab = null;

	private static GameObject _m_BurnPrefab = null;

	private static GameObject _m_SkillNamePrefab = null;

	private static GameObject _m_BuffsPrefab = null;

	private static GameObject _m_ExpPrefab = null;

	private static GameObject _PathPrefab = null;

	private static GameObject _StartPosPrefab = null;

	private static GameObject _RangePrefab = null;

	private static GameObject _RangeCPrefab = null;

	private static GameObject _RangeEPrefab = null;

	private static GameObject _AtkRangePrefab = null;

	private static GameObject _AtkSelRangePrefab = null;

	private static GameObject _HealSelRangePrefab = null;

	private static GameObject _Buff_bleed_Prefab = null;

	private static GameObject _Buff_buffATK_Prefab = null;

	private static GameObject _Buff_buffDEF_Prefab = null;

	private static GameObject _Buff_buffSP_Prefab = null;

	private static GameObject _Buff_burn_Prefab = null;

	private static GameObject _Buff_counter_Prefab = null;

	private static GameObject _Buff_crit_Prefab = null;

	private static GameObject _Buff_debuffATK_Prefab = null;

	private static GameObject _Buff_debuffDEF_Prefab = null;

	private static GameObject _Buff_debuffSP_Prefab = null;

	private static GameObject _Buff_drunk_Prefab = null;

	private static GameObject _Buff_fendicon_Prefab = null;

	private static GameObject _Buff_hpsteal_Prefab = null;

	private static GameObject _Buff_hpstealicon_Prefab = null;

	private static GameObject _Buff_hurt_Prefab = null;

	private static GameObject _Buff_mad_Prefab = null;

	private static GameObject _Buff_mpburnicon_Prefab = null;

	private static GameObject _Buff_mpstealicon_Prefab = null;

	private static GameObject _Buff_poison_Prefab = null;

	private static GameObject _Buff_reboundicon_Prefab = null;

	private static GameObject _Buff_seal_Prefab = null;

	private static GameObject _Buff_EffectOnBleed_Prefab = null;

	private static GameObject _Buff_EffectOnDrunk_Prefab = null;

	private static GameObject _Buff_EffectOnFire_Prefab = null;

	private static GameObject _Buff_EffectOnHurt_Prefab = null;

	private static GameObject _Buff_EffectOnMad_Prefab = null;

	private static GameObject _Buff_EffectOnPoison_Prefab = null;

	private static GameObject _Buff_EffectOnBleed2_Prefab = null;

	private static GameObject _Buff_EffectOnFire2_Prefab = null;

	private static GameObject _Buff_EffectOnPoison2_Prefab = null;

	private static GameObject _Buff_EffectOnSpitPrefab = null;

	private static GameObject _Buff_EffectOnBlindPrefab = null;

	private static GameObject _Buff_EffectOnDizzyPrefab = null;

	private static GameObject _Buff_EffectOnFearPrefab = null;

	private static GameObject _EnemyMarkerPrefab = null;

	private static GameObject _PlayerMarkerPrefab = null;

	private static GameObject _Mesg_NewsPrefab = null;

	private static GameObject _Mesg_TecsPrefab = null;

	private static GameObject _Note_HeadPrefab = null;

	private static GameObject _Note_NotePrefab = null;

	private static GameObject _Terrain_Fall_Prefab = null;

	private static GameObject _Terrain_WaterFall_Prefab = null;

	private static GameObject _Terrain_FireLv1_Prefab = null;

	private static GameObject _Terrain_FireLv2_Prefab = null;

	private static GameObject _Terrain_FirePersistent_Prefab = null;

	private static GameObject _Terrain_PoisonLv1_Prefab = null;

	private static GameObject _Terrain_PoisonLv2_Prefab = null;

	private static GameObject _Terrain_PoisonPersistent_Prefab = null;

	private static GameObject _Terrain_TrapSeal_Prefab = null;

	private static GameObject _Terrain_TrapBlast_Prefab = null;

	private static GameObject _m_DustPrefab = null;

	private static GameObject _m_Mine300001 = null;

	private static GameObject _m_Mine300002 = null;

	private static GameObject _m_Mine300003 = null;

	private static GameObject _m_Mine300004 = null;

	private static GameObject _m_Mine300005 = null;

	private static GameObject _m_InteractiveGrassPrefab = null;

	private static GameObject _m_SkinItemsPrefab = null;

	private static GameObject _TraitIconPrefab = null;

	private static GameObject _m_NextOrderInfoPrefab = null;

	private static GameObject _TraitpackageCanvasPrefab = null;

	private static GameObject _PackageCanvasPrefab = null;

	private static GameObject _AtlasCanvasPrefab = null;

	private static GameObject _StatusMainPrefab = null;

	private static GameObject _StatusSub1Prefab = null;

	private static GameObject _StatusSub2Prefab = null;

	private static GameObject _StatusSub3Prefab = null;

	private static GameObject _StatusSub4Prefab = null;

	private static GameObject _StatusSub5Prefab = null;

	private static GameObject _StatusSub6Prefab = null;

	private static GameObject _DataRecordCanvasPrefab = null;

	private static GameObject _LoadControllerPrefab = null;

	private static GameObject _HoverCanvasPrefab = null;

	private static GameObject _FieldCanvasPrefab = null;

	private static GameObject _BattleFieldCanvasPrefab = null;

	private static GameObject _BattleFieldCurcorPrefab = null;

	public static GameObject Buff_combo_Prefab = null;

	public static GameObject Buff_multiKill_Prefab = null;

	public static GameObject Buff_Runaway_Prefab = null;

	public static GameObject Buff_Assist_Prefab = null;

	public static GameObject Buff_Counter_Prefab = null;

	public static GameObject Buff_DodgeAdd_Prefab = null;

	public static GameObject Buff_Return_Prefab = null;

	public static AudioClip SE_Click = null;

	public static AudioClip SE_Save = null;

	public static AudioClip SE_Load = null;

	public static AudioClip SE_JiangHu = null;

	public static AudioClip SE_HELL = null;

	public static AudioClip SE_WATER = null;

	public static AudioClip Battle_SE = null;

	public static Sprite NS_ButtonA = null;

	public static Sprite NS_ButtonB = null;

	public static Sprite NS_ButtonX = null;

	public static Sprite NS_ButtonY = null;

	public static Sprite NS_DPad = null;

	public static Sprite NS_DPadDown = null;

	public static Sprite NS_DPadUp = null;

	public static Sprite NS_DPadRight = null;

	public static Sprite NS_DPadLeft = null;

	public static Sprite NS_DPadHorizon = null;

	public static Sprite NS_DPadVertical = null;

	public static Sprite NS_ShoulderRight = null;

	public static Sprite NS_ShoulderLeft = null;

	public static Sprite NS_TriggerLeft = null;

	public static Sprite NS_TriggerRight = null;

	public static Sprite NS_JoyStickRight = null;

	public static Sprite NS_JoyStickLeft = null;

	public static Sprite NS_Start = null;

	public static Sprite NS_Menu = null;

	public static Sprite PS_ButtonX = null;

	public static Sprite PS_ButtonO = null;

	public static Sprite PS_ButtonR = null;

	public static Sprite PS_ButtonT = null;

	public static Sprite PS_DPad = null;

	public static Sprite PS_DPadDown = null;

	public static Sprite PS_DPadUp = null;

	public static Sprite PS_DPadRight = null;

	public static Sprite PS_DPadLeft = null;

	public static Sprite PS_DPadHorizon = null;

	public static Sprite PS_DPadVertical = null;

	public static Sprite PS_ShoulderRight = null;

	public static Sprite PS_ShoulderLeft = null;

	public static Sprite PS_TriggerLeft = null;

	public static Sprite PS_TriggerRight = null;

	public static Sprite PS_JoyStickRight = null;

	public static Sprite PS_JoyStickLeft = null;

	public static Sprite PS_Start = null;

	public static Sprite PS_Menu = null;

	public static Sprite XBOX_ButtonA = null;

	public static Sprite XBOX_ButtonB = null;

	public static Sprite XBOX_ButtonX = null;

	public static Sprite XBOX_ButtonY = null;

	public static Sprite XBOX_DPad = null;

	public static Sprite XBOX_DPadDown = null;

	public static Sprite XBOX_DPadUp = null;

	public static Sprite XBOX_DPadRight = null;

	public static Sprite XBOX_DPadLeft = null;

	public static Sprite XBOX_DPadHorizon = null;

	public static Sprite XBOX_DPadVertical = null;

	public static Sprite XBOX_ShoulderRight = null;

	public static Sprite XBOX_ShoulderLeft = null;

	public static Sprite XBOX_TriggerLeft = null;

	public static Sprite XBOX_TriggerRight = null;

	public static Sprite XBOX_JoyStickRight = null;

	public static Sprite XBOX_JoyStickLeft = null;

	public static Sprite XBOX_Start = null;

	public static Sprite XBOX_Menu = null;

	public static Sprite TransprantSprite = null;

	public static Sprite NormalPackageIconSprite = null;

	public static Sprite SelectedSprite = null;

	public static Sprite InheritanceSprite = null;

	public static Sprite NewItemSprite = null;

	public static SpriteAtlas Icon07spriteAtlas;

	public static SpriteAtlas interactiveGrassAtlas;

	public static SpriteAtlas BookIconSpriteAtlas;

	public static SpriteAtlas RoleIconSpriteAtlas;

	public static Texture2D mapPathTexture = null;

	public static Texture2D mapUnlockTexture = null;

	public static TraitPackageController traitPackageController = null;

	public static PackageController packageController = null;

	public static AtlasManagerNewController atlasManagerNewController = null;

	public static StatusMainController statusMainController = null;

	public static StatusSub1 statusSub1 = null;

	public static StatusSub2 statusSub2 = null;

	public static StatusSub3 statusSub3 = null;

	public static StatusSub4 statusSub4 = null;

	public static StatusSub5 statusSub5 = null;

	public static StatusSub6 statusSub6 = null;

	public static DataRecordManager dataRecordManager = null;

	public static InputDeviceDetector inputDeviceDetector;

	public static GameObject HoverCanvas = null;

	public static GameObject HoverItem = null;

	public static GameObject HoverWuGong = null;

	public static GameObject gameDataManager = null;

	public static GameObject EventSystem = null;

	public static GameObject ButtonSoundEffects = null;

	public static GameObject InputDeviceChangeCanvas = null;

	private static Dictionary<string, GameObject> charaterPrefabDict = new Dictionary<string, GameObject>();

	private static Dictionary<string, AudioClip> bgmDict = new Dictionary<string, AudioClip>();

	private static Dictionary<string, Sprite> InteractiveGrassSpriteDict = new Dictionary<string, Sprite>();

	public static AudioClip WinBGM = null;

	public static AudioClip LoseBGM = null;

	public static AudioClip EventAudioclip = null;

	public static GameObject cameraShadowPrefab = null;

	public static Texture2D m_Talk_Pointer = null;

	public static Texture2D m_Loot_Pointer = null;

	public static Texture2D m_Wanted_Pointer = null;

	public static Texture2D m_Walk_Pointer = null;

	public static Texture2D m_Select_Pointer = null;

	public static GameObject WantedPrefab = null;

	public static GameObject ProtagonistSkin = null;

	public static GameObject StartPosPrefab
	{
		get
		{
			if (_StartPosPrefab == null)
			{
				_StartPosPrefab = (GameObject)Resources.Load("Prefabs/StartPos");
			}
			return _StartPosPrefab;
		}
	}

	public static GameObject PathPrefab
	{
		get
		{
			if (_PathPrefab == null)
			{
				_PathPrefab = (GameObject)Resources.Load("Prefabs/Path");
			}
			return _PathPrefab;
		}
	}

	public static GameObject RangePrefab
	{
		get
		{
			if (_RangePrefab == null)
			{
				_RangePrefab = (GameObject)Resources.Load("Prefabs/Range");
			}
			return _RangePrefab;
		}
	}

	public static GameObject RangeCPrefab
	{
		get
		{
			if (_RangeCPrefab == null)
			{
				_RangeCPrefab = (GameObject)Resources.Load("Prefabs/RangeC");
			}
			return _RangeCPrefab;
		}
	}

	public static GameObject RangeEPrefab
	{
		get
		{
			if (_RangeEPrefab == null)
			{
				_RangeEPrefab = (GameObject)Resources.Load("Prefabs/RangeE");
			}
			return _RangeEPrefab;
		}
	}

	public static GameObject AtkRangePrefab
	{
		get
		{
			if (_AtkRangePrefab == null)
			{
				_AtkRangePrefab = (GameObject)Resources.Load("Prefabs/AtkRange");
			}
			return _AtkRangePrefab;
		}
	}

	public static GameObject AtkSelRangePrefab
	{
		get
		{
			if (_AtkSelRangePrefab == null)
			{
				_AtkSelRangePrefab = (GameObject)Resources.Load("Prefabs/AtkSelRange");
			}
			return _AtkSelRangePrefab;
		}
	}

	public static GameObject HealSelRangePrefab
	{
		get
		{
			if (_HealSelRangePrefab == null)
			{
				_HealSelRangePrefab = (GameObject)Resources.Load("Prefabs/HealSelRange");
			}
			return _HealSelRangePrefab;
		}
	}

	public static GameObject m_CurcorPrefab
	{
		get
		{
			if (_m_CurcorPrefab == null)
			{
				_m_CurcorPrefab = (GameObject)Resources.Load("Prefabs/Field/Curcor");
			}
			return _m_CurcorPrefab;
		}
	}

	public static GameObject m_DamagePrefab
	{
		get
		{
			if (_m_DamagePrefab == null)
			{
				_m_DamagePrefab = (GameObject)Resources.Load("Prefabs/Damage/Damage");
			}
			return _m_DamagePrefab;
		}
	}

	public static GameObject m_InfoPrefab
	{
		get
		{
			if (_m_InfoPrefab == null)
			{
				_m_InfoPrefab = (GameObject)Resources.Load("Prefabs/Damage/Info");
			}
			return _m_InfoPrefab;
		}
	}

	public static GameObject m_CriticalPrefab
	{
		get
		{
			if (_m_CriticalPrefab == null)
			{
				_m_CriticalPrefab = (GameObject)Resources.Load("Prefabs/Damage/Critical");
			}
			return _m_CriticalPrefab;
		}
	}

	public static GameObject m_HealPrefab
	{
		get
		{
			if (_m_HealPrefab == null)
			{
				_m_HealPrefab = (GameObject)Resources.Load("Prefabs/Damage/Heal");
			}
			return _m_HealPrefab;
		}
	}

	public static GameObject m_MpPrefab
	{
		get
		{
			if (_m_MpPrefab == null)
			{
				_m_MpPrefab = (GameObject)Resources.Load("Prefabs/Damage/Mp");
			}
			return _m_MpPrefab;
		}
	}

	public static GameObject m_PoisonPrefab
	{
		get
		{
			if (_m_PoisonPrefab == null)
			{
				_m_PoisonPrefab = (GameObject)Resources.Load("Prefabs/Damage/Poison");
			}
			return _m_PoisonPrefab;
		}
	}

	public static GameObject m_BleedPrefab
	{
		get
		{
			if (_m_BleedPrefab == null)
			{
				_m_BleedPrefab = (GameObject)Resources.Load("Prefabs/Damage/Bleed");
			}
			return _m_BleedPrefab;
		}
	}

	public static GameObject m_BurnPrefab
	{
		get
		{
			if (_m_BurnPrefab == null)
			{
				_m_BurnPrefab = (GameObject)Resources.Load("Prefabs/Damage/Burn");
			}
			return _m_BurnPrefab;
		}
	}

	public static GameObject m_SkillNamePrefab
	{
		get
		{
			if (_m_SkillNamePrefab == null)
			{
				_m_SkillNamePrefab = (GameObject)Resources.Load("Prefabs/Damage/SkillName");
			}
			return _m_SkillNamePrefab;
		}
	}

	public static GameObject m_BuffsPrefab
	{
		get
		{
			if (_m_BuffsPrefab == null)
			{
				_m_BuffsPrefab = (GameObject)Resources.Load("Prefabs/Damage/Buffs");
			}
			return _m_BuffsPrefab;
		}
	}

	public static GameObject m_ExpPrefab
	{
		get
		{
			if (_m_ExpPrefab == null)
			{
				_m_ExpPrefab = (GameObject)Resources.Load("Prefabs/Damage/Exp");
			}
			return _m_ExpPrefab;
		}
	}

	public static GameObject Buff_bleed_Prefab
	{
		get
		{
			if (_Buff_bleed_Prefab == null)
			{
				_Buff_bleed_Prefab = (GameObject)Resources.Load("Prefabs/Buff/bleed");
			}
			return _Buff_bleed_Prefab;
		}
	}

	public static GameObject Buff_buffATK_Prefab
	{
		get
		{
			if (_Buff_buffATK_Prefab == null)
			{
				_Buff_buffATK_Prefab = (GameObject)Resources.Load("Prefabs/Buff/buffATK");
			}
			return _Buff_buffATK_Prefab;
		}
	}

	public static GameObject Buff_buffDEF_Prefab
	{
		get
		{
			if (_Buff_buffDEF_Prefab == null)
			{
				_Buff_buffDEF_Prefab = (GameObject)Resources.Load("Prefabs/Buff/buffDEF");
			}
			return _Buff_buffDEF_Prefab;
		}
	}

	public static GameObject Buff_buffSP_Prefab
	{
		get
		{
			if (_Buff_buffSP_Prefab == null)
			{
				_Buff_buffSP_Prefab = (GameObject)Resources.Load("Prefabs/Buff/buffSP");
			}
			return _Buff_buffSP_Prefab;
		}
	}

	public static GameObject Buff_burn_Prefab
	{
		get
		{
			if (_Buff_burn_Prefab == null)
			{
				_Buff_burn_Prefab = (GameObject)Resources.Load("Prefabs/Buff/burn");
			}
			return _Buff_burn_Prefab;
		}
	}

	public static GameObject Buff_counter_Prefab
	{
		get
		{
			if (_Buff_counter_Prefab == null)
			{
				_Buff_counter_Prefab = (GameObject)Resources.Load("Prefabs/Buff/counterold");
			}
			return _Buff_counter_Prefab;
		}
	}

	public static GameObject Buff_crit_Prefab
	{
		get
		{
			if (_Buff_crit_Prefab == null)
			{
				_Buff_crit_Prefab = (GameObject)Resources.Load("Prefabs/Buff/crit");
			}
			return _Buff_crit_Prefab;
		}
	}

	public static GameObject Buff_debuffATK_Prefab
	{
		get
		{
			if (_Buff_debuffATK_Prefab == null)
			{
				_Buff_debuffATK_Prefab = (GameObject)Resources.Load("Prefabs/Buff/debuffATK");
			}
			return _Buff_debuffATK_Prefab;
		}
	}

	public static GameObject Buff_debuffDEF_Prefab
	{
		get
		{
			if (_Buff_debuffDEF_Prefab == null)
			{
				_Buff_debuffDEF_Prefab = (GameObject)Resources.Load("Prefabs/Buff/debuffDEF");
			}
			return _Buff_debuffDEF_Prefab;
		}
	}

	public static GameObject Buff_debuffSP_Prefab
	{
		get
		{
			if (_Buff_debuffSP_Prefab == null)
			{
				_Buff_debuffSP_Prefab = (GameObject)Resources.Load("Prefabs/Buff/debuffSP");
			}
			return _Buff_debuffSP_Prefab;
		}
	}

	public static GameObject Buff_drunk_Prefab
	{
		get
		{
			if (_Buff_drunk_Prefab == null)
			{
				_Buff_drunk_Prefab = (GameObject)Resources.Load("Prefabs/Buff/drunk");
			}
			return _Buff_drunk_Prefab;
		}
	}

	public static GameObject Buff_fendicon_Prefab
	{
		get
		{
			if (_Buff_fendicon_Prefab == null)
			{
				_Buff_fendicon_Prefab = (GameObject)Resources.Load("Prefabs/Buff/fendicon");
			}
			return _Buff_fendicon_Prefab;
		}
	}

	public static GameObject Buff_hpsteal_Prefab
	{
		get
		{
			if (_Buff_hpsteal_Prefab == null)
			{
				_Buff_hpsteal_Prefab = (GameObject)Resources.Load("Prefabs/Buff/hpsteal");
			}
			return _Buff_hpsteal_Prefab;
		}
	}

	public static GameObject Buff_hpstealicon_Prefab
	{
		get
		{
			if (_Buff_hpstealicon_Prefab == null)
			{
				_Buff_hpstealicon_Prefab = (GameObject)Resources.Load("Prefabs/Buff/hpstealicon");
			}
			return _Buff_hpstealicon_Prefab;
		}
	}

	public static GameObject Buff_hurt_Prefab
	{
		get
		{
			if (_Buff_hurt_Prefab == null)
			{
				_Buff_hurt_Prefab = (GameObject)Resources.Load("Prefabs/Buff/hurt");
			}
			return _Buff_hurt_Prefab;
		}
	}

	public static GameObject Buff_mad_Prefab
	{
		get
		{
			if (_Buff_mad_Prefab == null)
			{
				_Buff_mad_Prefab = (GameObject)Resources.Load("Prefabs/Buff/mad");
			}
			return _Buff_mad_Prefab;
		}
	}

	public static GameObject Buff_mpburnicon_Prefab
	{
		get
		{
			if (_Buff_mpburnicon_Prefab == null)
			{
				_Buff_mpburnicon_Prefab = (GameObject)Resources.Load("Prefabs/Buff/mpburnicon");
			}
			return _Buff_mpburnicon_Prefab;
		}
	}

	public static GameObject Buff_mpstealicon_Prefab
	{
		get
		{
			if (_Buff_mpstealicon_Prefab == null)
			{
				_Buff_mpstealicon_Prefab = (GameObject)Resources.Load("Prefabs/Buff/mpstealicon");
			}
			return _Buff_mpstealicon_Prefab;
		}
	}

	public static GameObject Buff_poison_Prefab
	{
		get
		{
			if (_Buff_poison_Prefab == null)
			{
				_Buff_poison_Prefab = (GameObject)Resources.Load("Prefabs/Buff/poison");
			}
			return _Buff_poison_Prefab;
		}
	}

	public static GameObject Buff_reboundicon_Prefab
	{
		get
		{
			if (_Buff_reboundicon_Prefab == null)
			{
				_Buff_reboundicon_Prefab = (GameObject)Resources.Load("Prefabs/Buff/reboundicon");
			}
			return _Buff_reboundicon_Prefab;
		}
	}

	public static GameObject Buff_seal_Prefab
	{
		get
		{
			if (_Buff_seal_Prefab == null)
			{
				_Buff_seal_Prefab = (GameObject)Resources.Load("Prefabs/Buff/seal");
			}
			return _Buff_seal_Prefab;
		}
	}

	public static GameObject Buff_EffectOnBleed_Prefab
	{
		get
		{
			if (_Buff_EffectOnBleed_Prefab == null)
			{
				_Buff_EffectOnBleed_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_bleed");
			}
			return _Buff_EffectOnBleed_Prefab;
		}
	}

	public static GameObject Buff_EffectOnDrunk_Prefab
	{
		get
		{
			if (_Buff_EffectOnDrunk_Prefab == null)
			{
				_Buff_EffectOnDrunk_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_drunk");
			}
			return _Buff_EffectOnDrunk_Prefab;
		}
	}

	public static GameObject Buff_EffectOnFire_Prefab
	{
		get
		{
			if (_Buff_EffectOnFire_Prefab == null)
			{
				_Buff_EffectOnFire_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_fire");
			}
			return _Buff_EffectOnFire_Prefab;
		}
	}

	public static GameObject Buff_EffectOnHurt_Prefab
	{
		get
		{
			if (_Buff_EffectOnHurt_Prefab == null)
			{
				_Buff_EffectOnHurt_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_hurt");
			}
			return _Buff_EffectOnHurt_Prefab;
		}
	}

	public static GameObject Buff_EffectOnMad_Prefab
	{
		get
		{
			if (_Buff_EffectOnMad_Prefab == null)
			{
				_Buff_EffectOnMad_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_mad");
			}
			return _Buff_EffectOnMad_Prefab;
		}
	}

	public static GameObject Buff_EffectOnPoison_Prefab
	{
		get
		{
			if (_Buff_EffectOnPoison_Prefab == null)
			{
				_Buff_EffectOnPoison_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_poison");
			}
			return _Buff_EffectOnPoison_Prefab;
		}
	}

	public static GameObject Buff_EffectOnBleed2_Prefab
	{
		get
		{
			if (_Buff_EffectOnBleed2_Prefab == null)
			{
				_Buff_EffectOnBleed2_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_bleed2");
			}
			return _Buff_EffectOnBleed2_Prefab;
		}
	}

	public static GameObject Buff_EffectOnFire2_Prefab
	{
		get
		{
			if (_Buff_EffectOnFire2_Prefab == null)
			{
				_Buff_EffectOnFire2_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_fire2");
			}
			return _Buff_EffectOnFire2_Prefab;
		}
	}

	public static GameObject Buff_EffectOnPoison2_Prefab
	{
		get
		{
			if (_Buff_EffectOnPoison2_Prefab == null)
			{
				_Buff_EffectOnPoison2_Prefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_poison2");
			}
			return _Buff_EffectOnPoison2_Prefab;
		}
	}

	public static GameObject Buff_EffectOnSpitPrefab
	{
		get
		{
			if (_Buff_EffectOnSpitPrefab == null)
			{
				_Buff_EffectOnSpitPrefab = (GameObject)Resources.Load("Prefabs/Buff/effecton_spit");
			}
			return _Buff_EffectOnSpitPrefab;
		}
	}

	public static GameObject Buff_EffectOnBlindPrefab
	{
		get
		{
			if (_Buff_EffectOnBlindPrefab == null)
			{
				_Buff_EffectOnBlindPrefab = (GameObject)Resources.Load("Prefabs/BattleNew/blind");
			}
			return _Buff_EffectOnBlindPrefab;
		}
	}

	public static GameObject Buff_EffectOnFearPrefab
	{
		get
		{
			if (_Buff_EffectOnFearPrefab == null)
			{
				_Buff_EffectOnFearPrefab = (GameObject)Resources.Load("Prefabs/BattleNew/fear");
			}
			return _Buff_EffectOnFearPrefab;
		}
	}

	public static GameObject Buff_EffectOnDizzyPrefab
	{
		get
		{
			if (_Buff_EffectOnDizzyPrefab == null)
			{
				_Buff_EffectOnDizzyPrefab = (GameObject)Resources.Load("Prefabs/BattleNew/dizzy");
			}
			return _Buff_EffectOnDizzyPrefab;
		}
	}

	public static GameObject EnemyMarkerPrefab
	{
		get
		{
			if (_EnemyMarkerPrefab == null)
			{
				_EnemyMarkerPrefab = (GameObject)Resources.Load("Prefabs/Character/EnemyMarker");
			}
			return _EnemyMarkerPrefab;
		}
	}

	public static GameObject PlayerMarkerPrefab
	{
		get
		{
			if (_PlayerMarkerPrefab == null)
			{
				_PlayerMarkerPrefab = (GameObject)Resources.Load("Prefabs/Character/PlayerMarker");
			}
			return _PlayerMarkerPrefab;
		}
	}

	public static GameObject Mesg_NewsPrefab
	{
		get
		{
			if (_Mesg_NewsPrefab == null)
			{
				_Mesg_NewsPrefab = (GameObject)Resources.Load("Prefabs/Field/NewsBlock");
			}
			return _Mesg_NewsPrefab;
		}
	}

	public static GameObject Mesg_TecsPrefab
	{
		get
		{
			if (_Mesg_TecsPrefab == null)
			{
				_Mesg_TecsPrefab = (GameObject)Resources.Load("Prefabs/Field/TecsBlock");
			}
			return _Mesg_TecsPrefab;
		}
	}

	public static GameObject Note_HeadPrefab
	{
		get
		{
			if (_Note_HeadPrefab == null)
			{
				_Note_HeadPrefab = (GameObject)Resources.Load("Prefabs/Field/HeadBlock");
			}
			return _Note_HeadPrefab;
		}
	}

	public static GameObject Note_NotePrefab
	{
		get
		{
			if (_Note_NotePrefab == null)
			{
				_Note_NotePrefab = (GameObject)Resources.Load("Prefabs/Field/NoteBlock");
			}
			return _Note_NotePrefab;
		}
	}

	public static GameObject Terrain_Fall_Prefab
	{
		get
		{
			if (_Terrain_Fall_Prefab == null)
			{
				_Terrain_Fall_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/Fall");
			}
			return _Terrain_Fall_Prefab;
		}
	}

	public static GameObject Terrain_WaterFall_Prefab
	{
		get
		{
			if (_Terrain_WaterFall_Prefab == null)
			{
				_Terrain_WaterFall_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/WaterFall");
			}
			return _Terrain_WaterFall_Prefab;
		}
	}

	public static GameObject Terrain_FireLv1_Prefab
	{
		get
		{
			if (_Terrain_FireLv1_Prefab == null)
			{
				_Terrain_FireLv1_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/FireLv1");
			}
			return _Terrain_FireLv1_Prefab;
		}
	}

	public static GameObject Terrain_FireLv2_Prefab
	{
		get
		{
			if (_Terrain_FireLv2_Prefab == null)
			{
				_Terrain_FireLv2_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/FireLv2");
			}
			return _Terrain_FireLv2_Prefab;
		}
	}

	public static GameObject Terrain_FirePersistent_Prefab
	{
		get
		{
			if (_Terrain_FirePersistent_Prefab == null)
			{
				_Terrain_FirePersistent_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/FirePersistent");
			}
			return _Terrain_FirePersistent_Prefab;
		}
	}

	public static GameObject Terrain_PoisonLv1_Prefab
	{
		get
		{
			if (_Terrain_PoisonLv1_Prefab == null)
			{
				_Terrain_PoisonLv1_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/PoisonLv1");
			}
			return _Terrain_PoisonLv1_Prefab;
		}
	}

	public static GameObject Terrain_PoisonLv2_Prefab
	{
		get
		{
			if (_Terrain_PoisonLv2_Prefab == null)
			{
				_Terrain_PoisonLv2_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/PoisonLv2");
			}
			return _Terrain_PoisonLv2_Prefab;
		}
	}

	public static GameObject Terrain_PoisonPersistent_Prefab
	{
		get
		{
			if (_Terrain_PoisonPersistent_Prefab == null)
			{
				_Terrain_PoisonPersistent_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/PoisonPersistent");
			}
			return _Terrain_PoisonPersistent_Prefab;
		}
	}

	public static GameObject Terrain_TrapSeal_Prefab
	{
		get
		{
			if (_Terrain_TrapSeal_Prefab == null)
			{
				_Terrain_TrapSeal_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/TrapSeal");
			}
			return _Terrain_TrapSeal_Prefab;
		}
	}

	public static GameObject Terrain_TrapBlast_Prefab
	{
		get
		{
			if (_Terrain_TrapBlast_Prefab == null)
			{
				_Terrain_TrapBlast_Prefab = (GameObject)Resources.Load("Prefabs/Effect/Terrain/TrapBlast");
			}
			return _Terrain_TrapBlast_Prefab;
		}
	}

	public static GameObject m_DustPrefab
	{
		get
		{
			if (_m_DustPrefab == null)
			{
				_m_DustPrefab = (GameObject)Resources.Load("Prefabs/BattleNew/Dust");
			}
			return _m_DustPrefab;
		}
	}

	public static GameObject m_Mine300001
	{
		get
		{
			if (_m_Mine300001 == null)
			{
				_m_Mine300001 = (GameObject)Resources.Load("Prefabs/Effect/Terrain/Mine300001");
			}
			return _m_Mine300001;
		}
	}

	public static GameObject m_Mine300002
	{
		get
		{
			if (_m_Mine300002 == null)
			{
				_m_Mine300002 = (GameObject)Resources.Load("Prefabs/Effect/Terrain/Mine300002");
			}
			return _m_Mine300002;
		}
	}

	public static GameObject m_Mine300003
	{
		get
		{
			if (_m_Mine300003 == null)
			{
				_m_Mine300003 = (GameObject)Resources.Load("Prefabs/Effect/Terrain/Mine300003");
			}
			return _m_Mine300003;
		}
	}

	public static GameObject m_Mine300004
	{
		get
		{
			if (_m_Mine300004 == null)
			{
				_m_Mine300004 = (GameObject)Resources.Load("Prefabs/Effect/Terrain/Mine300004");
			}
			return _m_Mine300004;
		}
	}

	public static GameObject m_Mine300005
	{
		get
		{
			if (_m_Mine300005 == null)
			{
				_m_Mine300005 = (GameObject)Resources.Load("Prefabs/Effect/Terrain/Mine300005");
			}
			return _m_Mine300005;
		}
	}

	public static GameObject m_InteractiveGrassPrefab
	{
		get
		{
			if (_m_InteractiveGrassPrefab == null)
			{
				_m_InteractiveGrassPrefab = (GameObject)Resources.Load("Prefabs/Effect/InteractiveGrass/InteractiveGrass");
			}
			return _m_InteractiveGrassPrefab;
		}
	}

	public static GameObject m_NextOrderInfoPrefab
	{
		get
		{
			if (_m_NextOrderInfoPrefab == null)
			{
				_m_NextOrderInfoPrefab = (GameObject)Resources.Load("Prefabs/NewUI/BattleOrderInfo");
			}
			return _m_NextOrderInfoPrefab;
		}
	}

	public static GameObject m_SkinItemsPrefab
	{
		get
		{
			if (_m_SkinItemsPrefab == null)
			{
				_m_SkinItemsPrefab = (GameObject)Resources.Load("Prefabs/Debug/SkinItem");
			}
			return _m_SkinItemsPrefab;
		}
	}

	public static GameObject TraitIconPrefab
	{
		get
		{
			if (_TraitIconPrefab == null)
			{
				_TraitIconPrefab = (GameObject)Resources.Load("Prefabs/NewUI/TraitIcon");
			}
			return _TraitIconPrefab;
		}
	}

	public static GameObject TraitpackageCanvasPrefab
	{
		get
		{
			if (_TraitpackageCanvasPrefab == null)
			{
				_TraitpackageCanvasPrefab = (GameObject)Resources.Load("Prefabs/NewUI/TraitPackageCanvas");
			}
			return _TraitpackageCanvasPrefab;
		}
	}

	public static GameObject PackageCanvasPrefab
	{
		get
		{
			if (_PackageCanvasPrefab == null)
			{
				_PackageCanvasPrefab = (GameObject)Resources.Load("Prefabs/NewUI/PackageCanvas");
			}
			return _PackageCanvasPrefab;
		}
	}

	public static GameObject AtlasCanvasPrefab
	{
		get
		{
			if (_AtlasCanvasPrefab == null)
			{
				_AtlasCanvasPrefab = (GameObject)Resources.Load("Prefabs/NewUI/AtlasCanvas");
			}
			return _AtlasCanvasPrefab;
		}
	}

	public static GameObject StatusMainPrefab
	{
		get
		{
			if (_StatusMainPrefab == null)
			{
				_StatusMainPrefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusMain");
			}
			return _StatusMainPrefab;
		}
	}

	public static GameObject StatusSub1Prefab
	{
		get
		{
			if (_StatusSub1Prefab == null)
			{
				_StatusSub1Prefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusSub1");
			}
			return _StatusSub1Prefab;
		}
	}

	public static GameObject StatusSub2Prefab
	{
		get
		{
			if (_StatusSub2Prefab == null)
			{
				_StatusSub2Prefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusSub2");
			}
			return _StatusSub2Prefab;
		}
	}

	public static GameObject StatusSub3Prefab
	{
		get
		{
			if (_StatusSub3Prefab == null)
			{
				_StatusSub3Prefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusSub3");
			}
			return _StatusSub3Prefab;
		}
	}

	public static GameObject StatusSub4Prefab
	{
		get
		{
			if (_StatusSub4Prefab == null)
			{
				_StatusSub4Prefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusSub4");
			}
			return _StatusSub4Prefab;
		}
	}

	public static GameObject StatusSub5Prefab
	{
		get
		{
			if (_StatusSub5Prefab == null)
			{
				_StatusSub5Prefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusSub5");
			}
			return _StatusSub5Prefab;
		}
	}

	public static GameObject StatusSub6Prefab
	{
		get
		{
			if (_StatusSub6Prefab == null)
			{
				_StatusSub6Prefab = (GameObject)Resources.Load("Prefabs/NewUI/StatusSub6");
			}
			return _StatusSub6Prefab;
		}
	}

	public static GameObject DataRecordCanvasPrefab
	{
		get
		{
			if (_DataRecordCanvasPrefab == null)
			{
				_DataRecordCanvasPrefab = (GameObject)Resources.Load("Prefabs/NewUI/DataRecordCanvas");
			}
			return _DataRecordCanvasPrefab;
		}
	}

	public static GameObject LoadControllerPrefab
	{
		get
		{
			if (_LoadControllerPrefab == null)
			{
				_LoadControllerPrefab = (GameObject)Resources.Load("Prefabs/NewUI/DataLoadCanvas");
			}
			return _LoadControllerPrefab;
		}
	}

	public static GameObject HoverCanvasPrefab
	{
		get
		{
			if (_HoverCanvasPrefab == null)
			{
				_HoverCanvasPrefab = (GameObject)Resources.Load("Prefabs/NewUI/HoverCanvas");
			}
			return _HoverCanvasPrefab;
		}
	}

	public static GameObject FieldCanvasPrefab
	{
		get
		{
			if (_FieldCanvasPrefab == null)
			{
				_FieldCanvasPrefab = (GameObject)Resources.Load("Prefabs/Field/Canvas");
			}
			return _FieldCanvasPrefab;
		}
	}

	public static GameObject BattleFieldCanvasPrefab
	{
		get
		{
			if (_BattleFieldCanvasPrefab == null)
			{
				_BattleFieldCanvasPrefab = (GameObject)Resources.Load("Prefabs/BattleMenu/BattleCanvas");
			}
			return _BattleFieldCanvasPrefab;
		}
	}

	public static GameObject BattleFieldCurcorPrefab
	{
		get
		{
			if (_BattleFieldCurcorPrefab == null)
			{
				_BattleFieldCurcorPrefab = (GameObject)Resources.Load("Prefabs/BattleMenu/Curcor");
			}
			return _BattleFieldCurcorPrefab;
		}
	}

	public static void LoadAllResource()
	{
		Debug.Log("LoadAllResource");
		RegisterTypes.Initialize();
		LoadResources();
		Debug.Log("LoadAllResource... Done");
		Debug.Log("InstantiateCommonResources");
		InstantiateCommonResources();
		Debug.Log("InstantiateCommonResources... Done");
	}

	private static void LoadOpenCC(string path)
	{
		ConfigManager.ConfigFileBaseDir = path + "/JiebaResource";
		ZhConverter.Initialize(path + "/Dictionary", path + "/JiebaResource");
	}

	public static void LoadResources()
	{
		if (isLoadAllResources)
		{
			return;
		}
		Debug.Log("Load All SpriteAtlas...");
		TransprantSprite = Resources.Load("images/00-transprant", typeof(Sprite)) as Sprite;
		NormalPackageIconSprite = Resources.Load("images/01-border/boder-20231228-button-03", typeof(Sprite)) as Sprite;
		InheritanceSprite = Resources.Load("images/01-border/boder-20231228-button-05-new", typeof(Sprite)) as Sprite;
		SelectedSprite = Resources.Load("images/01-border/boder-20231228-button-01", typeof(Sprite)) as Sprite;
		NewItemSprite = Resources.Load("images/01-border/boder-20241028-button-item", typeof(Sprite)) as Sprite;
		Icon07spriteAtlas = Resources.Load("images/07-icon", typeof(SpriteAtlas)) as SpriteAtlas;
		interactiveGrassAtlas = Resources.Load("images/12-mapeffect", typeof(SpriteAtlas)) as SpriteAtlas;
		BookIconSpriteAtlas = Resources.Load("images/BookIconAtlas", typeof(SpriteAtlas)) as SpriteAtlas;
		RoleIconSpriteAtlas = Resources.Load("images/RoleIconAtlas", typeof(SpriteAtlas)) as SpriteAtlas;
		Debug.Log("Load All SpriteAtlas... Done");
		Debug.Log("LoadOpenCC...");
		LoadOpenCC(Application.streamingAssetsPath);
		Debug.Log("LoadOpenCC... Done");
		Debug.Log("Load All Csv...");
		I18nData.Instance(init: true);
		a01 = new gang_a01Table();
		a01.Load(Resources.Load<TextAsset>("Datas/gang_a01"));
		a02 = new gang_a02Table();
		a02.Load(Resources.Load<TextAsset>("Datas/gang_a02"));
		a05 = new gang_a05Table();
		a05.Load(Resources.Load<TextAsset>("Datas/gang_a05"));
		a06 = new gang_a06Table();
		a06.Load(Resources.Load<TextAsset>("Datas/gang_a06"));
		a07 = new gang_a07Table();
		a07.Load(Resources.Load<TextAsset>("Datas/gang_a07"));
		b01 = new gang_b01Table();
		b01.Load(Resources.Load<TextAsset>("Datas/gang_b01"));
		b01Skin = new gang_b01SkinTable();
		b01Skin.Load(Resources.Load<TextAsset>("Datas/gang_b01_skin_zhongyuan"));
		b01ChangeSkin = new gang_b01SkinTable();
		b01ChangeSkin.Load(Resources.Load<TextAsset>("Datas/gang_b01_skin_ChangeSkin"));
		b01Skin.GetRowList().AddRange(b01ChangeSkin.GetRowList());
		b02 = new gang_b02Table();
		b02.Load(Resources.Load<TextAsset>("Datas/gang_b02"));
		b02Set = new gang_b02SetTable();
		b02Set.Load(Resources.Load<TextAsset>("Datas/gang_b02_set"));
		foreach (gang_b02SetTable.Row row in b02Set.GetRowList())
		{
			string[] array = row.Set.Split('|');
			foreach (string key in array)
			{
				if (b02SetDict.ContainsKey(key))
				{
					b02SetDict[key].Add(row.ID);
					continue;
				}
				b02SetDict.Add(key, new List<string> { row.ID });
			}
		}
		b02Evolution = new gang_b02EvolutionTable();
		b02Evolution.Load(Resources.Load<TextAsset>("Datas/gang_b02_evolution"));
		b03 = new gang_b03Table();
		b03.Load(Resources.Load<TextAsset>("Datas/gang_b03"));
		b03SkillEffect = new gang_b03_SkiillEffect_Table();
		b03SkillEffect.Load(Resources.Load<TextAsset>("Datas/gang_b03SkillEffect"));
		b04 = new gang_b04Table();
		b04.Load(Resources.Load<TextAsset>("Datas/gang_b04"));
		b04_Random = new gang_b04Table();
		b04_Random.Load(Resources.Load<TextAsset>("Datas/gang_b04_Random"), isRandom: true);
		b04RandomFightInfos = new gang_b04RandomFightInfos();
		b04RandomFightInfos.Load(Resources.Load<TextAsset>("Datas/gang_b04RandomFightInfo"));
		b05 = new gang_b05Table();
		b05.Load(Resources.Load<TextAsset>("Datas/gang_b05"));
		b06 = new gang_b06Table();
		b06.Load(Resources.Load<TextAsset>("Datas/gang_b06"));
		b06Chain = new gang_b06ChainTable();
		b06Chain.Load(Resources.Load<TextAsset>("Datas/gang_b06_chain"));
		b07 = new gang_b07Table();
		b07.Load(Resources.Load<TextAsset>("Datas/gang_b07"));
		b08 = new gang_b08Table();
		b08.Load(Resources.Load<TextAsset>("Datas/gang_b08"));
		b09 = new gang_b09Table();
		b09.Load(Resources.Load<TextAsset>("Datas/gang_b09"));
		b10 = new gang_b10Table();
		b10.Load(Resources.Load<TextAsset>("Datas/gang_b10"));
		b11 = new gang_b11Table();
		b11.Load(Resources.Load<TextAsset>("Datas/gang_b11"));
		b12 = new gang_b12Table();
		b12.Load(Resources.Load<TextAsset>("Datas/gang_b12"));
		b12WugongType = new gang_b12WugongTypeTable();
		b12WugongType.Load(Resources.Load<TextAsset>("Datas/gang_b12_wuGongType"));
		b12WugongStarLimit = new gang_b12WugongStarLimit();
		b12WugongStarLimit.Load(Resources.Load<TextAsset>("Datas/gang_b12_wuGongStarsLimit"));
		b12WugongTypeAttackArea = new gang_b12WugongTypeAttackArea();
		b12WugongTypeAttackArea.Load(Resources.Load<TextAsset>("Datas/gang_b12_wuGongAttackArea"));
		b13 = new gang_b13Table();
		b13.Load(Resources.Load<TextAsset>("Datas/gang_b13"));
		b14 = new gang_b14Table();
		b14.Load(Resources.Load<TextAsset>("Datas/gang_b14"));
		b15 = new gang_b15Table();
		b15.Load(Resources.Load<TextAsset>("Datas/gang_b15"));
		b16 = new gang_b16Table();
		b16.Load(Resources.Load<TextAsset>("Datas/gang_b16"));
		c01 = new gang_c01Table();
		c01.Load(Resources.Load<TextAsset>("Datas/gang_c01"));
		c02 = new gang_c02Table();
		c02.Load(Resources.Load<TextAsset>("Datas/gang_c02"));
		c03 = new gang_c03Table();
		c03.Load(Resources.Load<TextAsset>("Datas/gang_c03"));
		c04 = new gang_c04Table();
		c04.Load(Resources.Load<TextAsset>("Datas/gang_c04"));
		e01 = new gang_e01Table();
		e01.Load(Resources.Load<TextAsset>("Datas/gang_e01"));
		e02 = new gang_e02Table();
		e02.Load(Resources.Load<TextAsset>("Datas/gang_e02"));
		e03 = new gang_e03Table();
		e03.Load(Resources.Load<TextAsset>("Datas/gang_e03"));
		e04 = new gang_e04Table();
		e04.Load(Resources.Load<TextAsset>("Datas/gang_e04"));
		e06 = new gang_e06Table();
		e06.Load(Resources.Load<TextAsset>("Datas/gang_e06"));
		e07 = new gang_e07Table();
		e07.Load(Resources.Load<TextAsset>("Datas/gang_e07"));
		t01 = new gang_t01Table();
		t01.Load(Resources.Load<TextAsset>("Datas/gang_t01"));
		f01 = new gang_f01Table();
		f01.Load(Resources.Load<TextAsset>("Datas/gang_f01"));
		f02 = new gang_f02Table();
		f02.Load(Resources.Load<TextAsset>("Datas/gang_f02"));
		sw0 = new SensitiveWord0Table();
		sw0.Load(Resources.Load<TextAsset>("Datas/SensitiveWord0"));
		Debug.Log("Load All Csv... Done");
		Debug.Log("Load All Audio Resources...");
		SE_Click = Resources.Load("Music/SE/Click", typeof(AudioClip)) as AudioClip;
		SE_Save = Resources.Load("Music/SE/Save", typeof(AudioClip)) as AudioClip;
		SE_Load = Resources.Load("Music/SE/Load", typeof(AudioClip)) as AudioClip;
		SE_JiangHu = Resources.Load("Music/SE/JiangHu", typeof(AudioClip)) as AudioClip;
		Battle_SE = Resources.Load("Music/SE/01-20240222-fight", typeof(AudioClip)) as AudioClip;
		LoadBgm("01-oldtemple-01-mix");
		LoadBgm("01-oldtemple-02-mix");
		LoadBgm("01_yansiwanzhong-midilike");
		LoadBgm("01_yansiwanzhong");
		LoadBgm("02-market-mix");
		LoadBgm("02_battle_qiecuo");
		LoadBgm("03-terminal-mix");
		LoadBgm("03_battle_dahui");
		LoadBgm("04-pub_mix");
		LoadBgm("04_linancheng");
		LoadBgm("05-barracks-mix");
		LoadBgm("05_linancheng_variation");
		LoadBgm("06-cave-mixwav");
		LoadBgm("06_huajishijian");
		LoadBgm("07-grave-mix");
		LoadBgm("07_tufashijian");
		LoadBgm("08-hill-mix");
		LoadBgm("08_tufashijian_variation");
		LoadBgm("09-peaceful");
		LoadBgm("09_yansiwanzhong_variation");
		LoadBgm("10-gang");
		LoadBgm("11-wildwind");
		LoadBgm("12-xiaoxiangnightrain");
		LoadBgm("13-somebodyonroof");
		LoadBgm("14-seeyouagaininjianghu");
		LoadBgm("15-yuyifour");
		LoadBgm("16-Inpower");
		LoadBgm("17-xiaoxiangnightrain-new");
		LoadBgm("18-greatbuddha");
		LoadBgm("19-drinkinggame");
		LoadBgm("20-nanyangwar");
		LoadBgm("21-Firerescue-slow");
		LoadBgm("21-Firerescue");
		LoadBgm("22-yuyigodfather");
		LoadBgm("23-market-linan-mix");
		LoadBgm("24-night-mix");
		LoadBgm("25-Chickenflydogjump-mix");
		LoadBgm("Chinatown_Healing_loop");
		SE_HELL = Resources.Load("Music/SE/HELL", typeof(AudioClip)) as AudioClip;
		SE_WATER = Resources.Load("Music/SE/WATER", typeof(AudioClip)) as AudioClip;
		WinBGM = LoadBgm("battle_win");
		LoseBGM = LoadBgm("battle_lose");
		EventAudioclip = Resources.Load("Music/Charas/Man/walk", typeof(AudioClip)) as AudioClip;
		Debug.Log("Load All Audio Resources... Done");
		Debug.Log("Load All InteractiveGrass...");
		LoadInteractiveGrass("Tile_GRASS-0909_113");
		LoadInteractiveGrass("Tile_GRASS-0909_114");
		LoadInteractiveGrass("Tile_GRASS-0909_115");
		LoadInteractiveGrass("Tile_GRASS-0909_116");
		LoadInteractiveGrass("Tile_GRASS-0909_117");
		LoadInteractiveGrass("Tile_GRASS-0909_118");
		LoadInteractiveGrass("Tile_GRASS-0909_119");
		LoadInteractiveGrass("Tile_GRASS-0909_120");
		LoadInteractiveGrass("Tile_GRASS-0909_121");
		LoadInteractiveGrass("Tile_GRASS-0909_122");
		LoadInteractiveGrass("Tile_GRASS-0909_124");
		LoadInteractiveGrass("Tile_GRASS-0909_126");
		LoadInteractiveGrass("Tile_GRASS-0909_127");
		LoadInteractiveGrass("Tile_GRASS-0909_128");
		LoadInteractiveGrass("Tile_GRASS-0909_129");
		LoadInteractiveGrass("Tile_GRASS-0909_130");
		LoadInteractiveGrass("Tile_GRASS-0909_131");
		LoadInteractiveGrass("Tile_GRASS-0909_132");
		LoadInteractiveGrass("Tile_GRASS-0909_81");
		LoadInteractiveGrass("Tile_GRASS-0909_82");
		LoadInteractiveGrass("Tile_GRASS-0909_83");
		LoadInteractiveGrass("Tile_GRASS-0909_85");
		LoadInteractiveGrass("Tile_GRASS-0909_86");
		LoadInteractiveGrass("Tile_GRASS-0909_87");
		LoadInteractiveGrass("Tile_GRASS-0909_88");
		LoadInteractiveGrass("Tile_GRASS-0909_89");
		LoadInteractiveGrass("Tile_GRASS-0909_90");
		LoadInteractiveGrass("Tile_GRASS-0909_91");
		LoadInteractiveGrass("Tile_GRASS-0909_92");
		LoadInteractiveGrass("Tile_GRASS-0909_95");
		LoadInteractiveGrass("Tile_GRASS-0909_96");
		LoadInteractiveGrass("Tile_GRASS-0909_97");
		LoadInteractiveGrass("Tile_GRASS-0909_98");
		LoadInteractiveGrass("Tile_GRASS-0909_99");
		LoadInteractiveGrass("map-grass-move-1013-04");
		LoadInteractiveGrass("map-grass-move-1013-05");
		LoadInteractiveGrass("map-grass-move-1013-ice-01");
		cameraShadowPrefab = Resources.Load("Prefabs/Effect/Ground/CaveScreenShadow", typeof(GameObject)) as GameObject;
		m_Talk_Pointer = Resources.Load("images/07-icon/mouseover-talk", typeof(Texture2D)) as Texture2D;
		m_Loot_Pointer = Resources.Load("images/07-icon/mouseover-find", typeof(Texture2D)) as Texture2D;
		m_Wanted_Pointer = Resources.Load("images/07-icon/mouseover-wanted", typeof(Texture2D)) as Texture2D;
		WantedPrefab = Resources.Load("Prefabs/NewUI/Wanted", typeof(GameObject)) as GameObject;
		ProtagonistSkin = Resources.Load("Prefabs/Skin/ProtagonistSkin", typeof(GameObject)) as GameObject;
		Debug.Log("Load All InteractiveGrass...Done");
		isLoadAllResources = true;
	}

	private static void InstantiateCommonResources()
	{
		if (isInitAllResources)
		{
			return;
		}
		if (!isLoadAllResources)
		{
			Debug.LogWarning("InstantiateCommonResources Error, not load all resources!");
			return;
		}
		if (gameDataManager == null)
		{
			gameDataManager = new GameObject("GameDataManager");
			gameDataManager.AddComponent<GameDataManager>();
			gameDataManager.AddComponent<AutoGameSaveController>();
			Object.DontDestroyOnLoad(gameDataManager);
		}
		Object.Instantiate(Resources.Load("Prefabs/AudioManager") as GameObject);
		GameObject gameObject = new GameObject("MapLoader");
		gameObject.AddComponent<MapLoader>();
		Object.DontDestroyOnLoad(gameObject);
		if (EventSystem == null)
		{
			EventSystem = Object.Instantiate(Resources.Load("Prefabs/EventSystemPermanent") as GameObject);
			Object.DontDestroyOnLoad(EventSystem);
		}
		if (ButtonSoundEffects == null)
		{
			ButtonSoundEffects = Object.Instantiate(Resources.Load("Prefabs/ButtonSoundEffects") as GameObject);
			Object.DontDestroyOnLoad(ButtonSoundEffects);
		}
		if (HoverCanvas == null)
		{
			HoverCanvas = Object.Instantiate(HoverCanvasPrefab);
			Object.DontDestroyOnLoad(HoverCanvas);
			HoverItem = HoverCanvas.transform.Find("Panel/HoverItem").gameObject;
			HoverWuGong = HoverCanvas.transform.Find("Panel/HoverWuGong").gameObject;
		}
		if (InputDeviceChangeCanvas == null)
		{
			InputDeviceChangeCanvas = Object.Instantiate((GameObject)Resources.Load("Prefabs/JoyStick/InputDeviceChangeCanvas"));
			inputDeviceDetector = InputDeviceChangeCanvas.GetComponentInChildren<InputDeviceDetector>();
			Object.DontDestroyOnLoad(InputDeviceChangeCanvas);
		}
		if (packageController == null)
		{
			packageController = Object.Instantiate(PackageCanvasPrefab).GetComponent<PackageController>();
			Object.DontDestroyOnLoad(packageController);
		}
		if (traitPackageController == null)
		{
			traitPackageController = Object.Instantiate(TraitpackageCanvasPrefab).GetComponent<TraitPackageController>();
			Object.DontDestroyOnLoad(traitPackageController);
			traitPackageController.CloseTraitPackage();
		}
		if (atlasManagerNewController == null)
		{
			atlasManagerNewController = Object.Instantiate(AtlasCanvasPrefab).GetComponent<AtlasManagerNewController>();
			Object.DontDestroyOnLoad(atlasManagerNewController);
		}
		if (statusMainController == null)
		{
			statusMainController = Object.Instantiate(StatusMainPrefab).GetComponent<StatusMainController>();
			statusMainController.gameObject.SetActive(value: false);
			statusMainController.name = "StatusMain";
			Object.DontDestroyOnLoad(statusMainController);
		}
		if (statusSub1 == null)
		{
			statusSub1 = Object.Instantiate(StatusSub1Prefab).GetComponent<StatusSub1>();
			statusSub1.gameObject.SetActive(value: false);
			statusSub1.name = "statusSub1";
			Object.DontDestroyOnLoad(statusSub1);
		}
		if (statusSub2 == null)
		{
			statusSub2 = Object.Instantiate(StatusSub2Prefab).GetComponent<StatusSub2>();
			statusSub2.gameObject.SetActive(value: false);
			statusSub2.name = "statusSub2";
			Object.DontDestroyOnLoad(statusSub2);
		}
		if (statusSub3 == null)
		{
			statusSub3 = Object.Instantiate(StatusSub3Prefab).GetComponent<StatusSub3>();
			statusSub3.gameObject.SetActive(value: false);
			statusSub3.name = "statusSub3";
			Object.DontDestroyOnLoad(statusSub3);
		}
		if (statusSub4 == null)
		{
			statusSub4 = Object.Instantiate(StatusSub4Prefab).GetComponent<StatusSub4>();
			statusSub4.gameObject.SetActive(value: false);
			statusSub4.name = "statusSub4";
			Object.DontDestroyOnLoad(statusSub4);
		}
		if (statusSub5 == null)
		{
			statusSub5 = Object.Instantiate(StatusSub5Prefab).GetComponent<StatusSub5>();
			statusSub5.gameObject.SetActive(value: false);
			statusSub5.name = "statusSub5";
			Object.DontDestroyOnLoad(statusSub5);
		}
		if (statusSub6 == null)
		{
			statusSub6 = Object.Instantiate(StatusSub6Prefab).GetComponent<StatusSub6>();
			statusSub6.gameObject.SetActive(value: false);
			statusSub6.name = "statusSub6";
			Object.DontDestroyOnLoad(statusSub6);
		}
		if (dataRecordManager == null)
		{
			dataRecordManager = Object.Instantiate(DataRecordCanvasPrefab).GetComponent<DataRecordManager>();
			dataRecordManager.gameObject.SetActive(value: false);
			dataRecordManager.name = "DataRecordCanvas";
			Object.DontDestroyOnLoad(dataRecordManager);
		}
		isInitAllResources = true;
	}

	public static void UpdateResourcesByLanguage()
	{
		string language = GameDataManager.Instance().configdata.language;
		if (!(language == "English"))
		{
			if (language == "ChineseTraditional")
			{
				Buff_combo_Prefab = (GameObject)Resources.Load("Prefabs/Buff/comboTW");
				Buff_multiKill_Prefab = (GameObject)Resources.Load("Prefabs/Buff/MultikillTW");
				Buff_Runaway_Prefab = (GameObject)Resources.Load("Prefabs/Buff/RunawayTW");
				Buff_Assist_Prefab = (GameObject)Resources.Load("Prefabs/Buff/AssistTW");
				Buff_Counter_Prefab = (GameObject)Resources.Load("Prefabs/Buff/CounterTW");
				Buff_DodgeAdd_Prefab = (GameObject)Resources.Load("Prefabs/Buff/DodgeAddTW");
				Buff_Return_Prefab = (GameObject)Resources.Load("Prefabs/Buff/ReturnTW");
			}
			else
			{
				Buff_combo_Prefab = (GameObject)Resources.Load("Prefabs/Buff/combo");
				Buff_multiKill_Prefab = (GameObject)Resources.Load("Prefabs/Buff/Multikill");
				Buff_Runaway_Prefab = (GameObject)Resources.Load("Prefabs/Buff/Runaway");
				Buff_Assist_Prefab = (GameObject)Resources.Load("Prefabs/Buff/Assist");
				Buff_Counter_Prefab = (GameObject)Resources.Load("Prefabs/Buff/Counter");
				Buff_DodgeAdd_Prefab = (GameObject)Resources.Load("Prefabs/Buff/DodgeAdd");
				Buff_Return_Prefab = (GameObject)Resources.Load("Prefabs/Buff/Return");
			}
		}
		else
		{
			Buff_combo_Prefab = (GameObject)Resources.Load("Prefabs/Buff/comboEN");
			Buff_multiKill_Prefab = (GameObject)Resources.Load("Prefabs/Buff/MultikillEN");
			Buff_Runaway_Prefab = (GameObject)Resources.Load("Prefabs/Buff/RunawayEN");
			Buff_Assist_Prefab = (GameObject)Resources.Load("Prefabs/Buff/AssistEN");
			Buff_Counter_Prefab = (GameObject)Resources.Load("Prefabs/Buff/CounterEN");
			Buff_DodgeAdd_Prefab = (GameObject)Resources.Load("Prefabs/Buff/DodgeAddEN");
			Buff_Return_Prefab = (GameObject)Resources.Load("Prefabs/Buff/ReturnEN");
		}
	}

	public static GameObject LoadCharacter(string name)
	{
		string text = "Prefabs/Character/" + name;
		if (!charaterPrefabDict.ContainsKey(text))
		{
			GameObject value = (GameObject)Resources.Load(text);
			charaterPrefabDict.Add(text, value);
		}
		return charaterPrefabDict[text];
	}

	public static AudioClip LoadBgm(string _bgm)
	{
		string text = "Music/Bgm/" + _bgm;
		if (!bgmDict.ContainsKey(text))
		{
			AudioClip value = (AudioClip)Resources.Load(text);
			bgmDict.Add(text, value);
		}
		return bgmDict[text];
	}

	public static Sprite LoadInteractiveGrass(string _grass)
	{
		if (!InteractiveGrassSpriteDict.ContainsKey(_grass))
		{
			Sprite sprite = interactiveGrassAtlas.GetSprite(_grass);
			InteractiveGrassSpriteDict.Add(_grass, sprite);
		}
		return InteractiveGrassSpriteDict[_grass];
	}

	public static Sprite GetBookIcon(string _name)
	{
		return BookIconSpriteAtlas.GetSprite(_name);
	}

	public static Sprite GetRoleIcon(string _name)
	{
		return RoleIconSpriteAtlas.GetSprite(_name.ToLower());
	}

	public static Sprite GetTachieHead(string _name)
	{
		Sprite sprite = null;
		if ((SharedData.Instance().protagonistSkinDataNew.isCustom && _name.Equals("role-protagonist")) || _name.Equals("role-heroine") || _name.Equals("role-02-male") || _name.Equals("role-02-female"))
		{
			sprite = SharedData.Instance().ProtagonistHeadSprite;
		}
		else
		{
			sprite = Resources.Load("images/13-CharacterHead/" + _name.ToLower(), typeof(Sprite)) as Sprite;
			if (!sprite)
			{
				sprite = Resources.Load("images/13-CharacterHead/pic-0-npc", typeof(Sprite)) as Sprite;
			}
		}
		return sprite;
	}

	public static Sprite GetTachieFull(string _name)
	{
		Sprite sprite = null;
		if (SharedData.Instance().protagonistSkinDataNew.isCustom && (_name.Equals("role-protagonist") || _name.Equals("role-heroine") || _name.Equals("role-02-male") || _name.Equals("role-02-female")))
		{
			sprite = SharedData.Instance().ProtagonistFullSprite;
		}
		else
		{
			sprite = Resources.Load("images/08-Character/" + _name.ToLower(), typeof(Sprite)) as Sprite;
			if (!sprite)
			{
				sprite = Resources.Load("images/08-Character/pic-0-npc", typeof(Sprite)) as Sprite;
			}
			if (!sprite)
			{
				sprite = Resources.Load("images/08-Character/transparent", typeof(Sprite)) as Sprite;
			}
		}
		return sprite;
	}
}
