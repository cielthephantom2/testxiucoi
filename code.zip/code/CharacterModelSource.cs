public enum CharacterModelSource
{
	b01,
	b04,
	b04Random,
	e01
}
