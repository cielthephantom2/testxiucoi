using System.Collections.Generic;
using System.Globalization;
using MessagePack;
using UnityEngine;

[MessagePackObject(false)]
public class KongFuData
{
	[Key(0)]
	private gang_b03Table.Row _kf;

	[Key(2)]
	public int lv;

	[Key(3)]
	public float exp;

	[Key(4)]
	public int proficiency;

	[Key(5)]
	public Vector3Int runtime_atk_pos;

	[Key(6)]
	public float runtime_combo_rate;

	[Key(7)]
	public float runtime_style_damage;

	[Key(8)]
	public int newlv;

	[Key(9)]
	public bool isSummonSkill;

	[Key(10)]
	public bool isSwapPosSkill;

	[Key(11)]
	public bool isAttackSkill;

	[Key(12)]
	public bool isHealHpSkill;

	[Key(13)]
	public bool isHealNegativeBuffSkill;

	[Key(14)]
	public bool isBuffSkill;

	[Key(15)]
	public List<string> BuffSkillList = new List<string>();

	[Key(16)]
	public bool isAbolished;

	[Key(1)]
	public gang_b03Table.Row kf
	{
		get
		{
			return _kf;
		}
		set
		{
			_kf = value;
			isSummonSkill = _isSummonSkill();
			isSwapPosSkill = _isSwapPosSkill();
			isAttackSkill = _isAttackSkill();
			isHealHpSkill = _isHealHpSkill();
			isBuffSkill = _isBuffSkill();
			_GetBuffSkillList();
			isHealNegativeBuffSkill = _isHealNegativeBuffSkill();
		}
	}

	public void CheckAppendTraits(CharaData _targetData)
	{
		string[] array = _kf.AppendTraits.Split('|');
		if ("0".Equals(array[0]))
		{
			return;
		}
		int num = int.Parse(array[0]);
		if (num == 999)
		{
			foreach (gang_c04Table.Row item in CommonResourcesData.c04.FindAll_ID(array[1]))
			{
				gang_b07Table.Row row = CommonResourcesData.b07.Find_ID(item.Item);
				if (row != null)
				{
					int amount = int.Parse(item.QTY);
					SharedData.Instance().PackageAdd(item.Item, amount);
					if (SharedData.Instance().m_AppendTraitInfos.Length > 0)
					{
						SharedData.Instance().m_AppendTraitInfos += "|";
					}
					SharedData sharedData = SharedData.Instance();
					sharedData.m_AppendTraitInfos = sharedData.m_AppendTraitInfos + _targetData.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetFood") + " <color=#f0e352>" + row.Name_Trans + "</color>！&" + row.BookIcon;
				}
			}
			return;
		}
		if (newlv != num)
		{
			return;
		}
		string[] array2 = array[1].Split('&');
		string[] array3;
		if (!"0".Equals(array2[0]))
		{
			array3 = array2;
			foreach (string text in array3)
			{
				if (_targetData.m_TraitList.Contains(text))
				{
					continue;
				}
				gang_b06Table.Row row2 = CommonResourcesData.b06.Find_id(text);
				if (row2 != null)
				{
					_targetData.AddTraits(text);
					GameDataManager.Instance().AddUnlockAtlasList(text, "b06");
					if (SharedData.Instance().m_AppendTraitInfos.Length > 0)
					{
						SharedData.Instance().m_AppendTraitInfos += "|";
					}
					SharedData sharedData = SharedData.Instance();
					sharedData.m_AppendTraitInfos = sharedData.m_AppendTraitInfos + _targetData.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_GetTrait") + " <color=#f0e352>" + row2.name_Trans + "</color>！";
				}
			}
		}
		string[] array4 = array[2].Split('&');
		if ("0".Equals(array4[0]))
		{
			return;
		}
		array3 = array4;
		foreach (string text2 in array3)
		{
			if (!_targetData.m_TraitList.Contains(text2))
			{
				continue;
			}
			_targetData.RemoveTrait(text2);
			gang_b06Table.Row row3 = CommonResourcesData.b06.Find_id(text2);
			if (row3 != null)
			{
				if (SharedData.Instance().m_AppendTraitInfos.Length > 0)
				{
					SharedData.Instance().m_AppendTraitInfos += "|";
				}
				SharedData sharedData = SharedData.Instance();
				sharedData.m_AppendTraitInfos = sharedData.m_AppendTraitInfos + _targetData.Indexs_Name["Name"].stringValue + " " + CommonFunc.I18nGetLocalizedValue("I18N_LostTrait") + " <color=#f0e352>" + row3.name_Trans + "</color>！";
			}
		}
	}

	public bool CheckLevelUp(float _addexp, float _levellimit, float _learn, CharaData _targetData)
	{
		bool result = false;
		float num = float.Parse(_kf.LV, CultureInfo.InvariantCulture);
		float num2 = ((num < _levellimit) ? num : _levellimit);
		int num3 = Mathf.RoundToInt(float.Parse(_kf.EXP, CultureInfo.InvariantCulture) + (float)(newlv - 1) * float.Parse(_kf.EXPadd, CultureInfo.InvariantCulture) * Mathf.Abs(3f - _learn / 10f));
		_addexp *= 1f + _targetData.GetBattleValueByName("WuGongEXPup");
		exp += _addexp;
		if (exp >= (float)num3)
		{
			if ((float)newlv < num2)
			{
				newlv++;
				exp -= num3;
				result = true;
				CheckAppendTraits(_targetData);
				CheckLevelUp(0f, num2, _learn, _targetData);
			}
			else
			{
				exp = num3;
			}
		}
		return result;
	}

	public bool _isAttackSkill()
	{
		if (_kf.Damage != "0")
		{
			return true;
		}
		return false;
	}

	public bool _isHealHpSkill()
	{
		if (KongFuCommomFunc.CheckWugongHaveEffect(_kf, "HP"))
		{
			return true;
		}
		if (KongFuCommomFunc.CheckWugongHaveEffect(_kf, "HPturn"))
		{
			return true;
		}
		return false;
	}

	public bool _isHealNegativeBuffSkill()
	{
		if (_kf.Attckstyle.Split("|")[2] != "2")
		{
			return false;
		}
		foreach (string buffSkill in BuffSkillList)
		{
			if (buffSkill.StartsWith("Poison") || buffSkill.StartsWith("Burn") || buffSkill.StartsWith("Hurt") || buffSkill.StartsWith("Bleed") || buffSkill.StartsWith("Mad"))
			{
				return true;
			}
		}
		return false;
	}

	public bool _isBuffSkill()
	{
		if (_kf.Attckstyle.Split("|")[2] != "2")
		{
			return false;
		}
		return true;
	}

	public List<string> _GetBuffSkillList()
	{
		if (_kf.Attckstyle.Split("|")[2] != "2")
		{
			return BuffSkillList;
		}
		if (_kf.Skill1 != "0")
		{
			BuffSkillList.Add(_kf.Skill1.Split("|")[0]);
		}
		if (_kf.Skill2 != "0")
		{
			BuffSkillList.Add(_kf.Skill2.Split("|")[0]);
		}
		if (_kf.Skill3 != "0")
		{
			BuffSkillList.Add(_kf.Skill3.Split("|")[0]);
		}
		if (_kf.Skill4 != "0")
		{
			BuffSkillList.Add(_kf.Skill4.Split("|")[0]);
		}
		if (_kf.Skill5 != "0")
		{
			BuffSkillList.Add(_kf.Skill5.Split("|")[0]);
		}
		return BuffSkillList;
	}

	public bool _isSwapPosSkill()
	{
		string value = "SwapPos&";
		if (_kf.Skill1.StartsWith(value) || _kf.Skill2.StartsWith(value) || _kf.Skill3.StartsWith(value) || _kf.Skill4.StartsWith(value) || _kf.Skill5.StartsWith(value))
		{
			return true;
		}
		value = "Impact&";
		if (_kf.Skill1.StartsWith(value) || _kf.Skill2.StartsWith(value) || _kf.Skill3.StartsWith(value) || _kf.Skill4.StartsWith(value) || _kf.Skill5.StartsWith(value))
		{
			return true;
		}
		if (_kf.Attckstyle.StartsWith("A|07"))
		{
			return true;
		}
		return false;
	}

	public bool _isSummonSkill()
	{
		string text = "";
		if (_kf.Skill1.StartsWith("Summon"))
		{
			text = _kf.Skill1;
		}
		else if (_kf.Skill2.StartsWith("Summon"))
		{
			text = _kf.Skill2;
		}
		else if (_kf.Skill3.StartsWith("Summon"))
		{
			text = _kf.Skill3;
		}
		else if (_kf.Skill4.StartsWith("Summon"))
		{
			text = _kf.Skill4;
		}
		else if (_kf.Skill5.StartsWith("Summon"))
		{
			text = _kf.Skill5;
		}
		if (text != "")
		{
			return true;
		}
		return false;
	}
}
