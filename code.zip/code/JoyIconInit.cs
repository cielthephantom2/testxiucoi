using System.Collections;
using InputIcons;
using UnityEngine;
using UnityEngine.UI;

public class JoyIconInit : MonoBehaviour
{
	public bool isJumpAnimation;

	private void Start()
	{
	}

	private IEnumerator delayChangeIcon()
	{
		yield return null;
		Sprite sprite = Resources.Load("images/07-01-icon-UI/jumpAnimation", typeof(Sprite)) as Sprite;
		Object.DestroyImmediate(base.transform.GetComponent<II_ImagePrompt>());
		Object.DestroyImmediate(base.transform.Find("JoyIcon").GetComponent<II_ImagePrompt>());
		base.transform.GetComponent<Image>().sprite = sprite;
		base.transform.Find("JoyIcon").GetComponent<Image>().sprite = sprite;
	}
}
