using System.Collections.Generic;
using UnityEngine;

public class f01checkTable
{
	public class Row
	{
		public string note;

		public string note_en;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			Row row = new Row();
			row.note = list[i][0];
			row.note_en = list[i][1];
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_note(string find)
	{
		return rowList.Find((Row x) => x.note == find);
	}

	public List<Row> FindAll_note(string find)
	{
		return rowList.FindAll((Row x) => x.note == find);
	}

	public Row Find_note_en(string find)
	{
		return rowList.Find((Row x) => x.note_en == find);
	}

	public List<Row> FindAll_note_en(string find)
	{
		return rowList.FindAll((Row x) => x.note_en == find);
	}
}
