using UnityEngine;

public class SkillShowInfoItem
{
	public SkillInfoType skillInfoType;

	public string info;

	public Sprite sprite;
}
