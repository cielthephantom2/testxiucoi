using System.Collections.Generic;
using UnityEngine;

public class gang_b05Table
{
	public class Row
	{
		public string GID;

		public string ID;

		public string Prefab1;

		public string Prefab2;

		public string ItemID;

		public string Note;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				GID = list[i][num++],
				ID = list[i][num++],
				Prefab1 = list[i][num++],
				Prefab2 = list[i][num++],
				ItemID = list[i][num++],
				Note = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_GID(string find)
	{
		return rowList.Find((Row x) => x.GID == find);
	}

	public List<Row> FindAll_GID(string find)
	{
		return rowList.FindAll((Row x) => x.GID == find);
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}

	public Row Find_Prefab1(string find)
	{
		return rowList.Find((Row x) => x.Prefab1 == find);
	}

	public List<Row> FindAll_Prefab1(string find)
	{
		return rowList.FindAll((Row x) => x.Prefab1 == find);
	}

	public Row Find_Prefab2(string find)
	{
		return rowList.Find((Row x) => x.Prefab2 == find);
	}

	public List<Row> FindAll_Prefab2(string find)
	{
		return rowList.FindAll((Row x) => x.Prefab2 == find);
	}

	public Row Find_ItemID(string find)
	{
		return rowList.Find((Row x) => x.ItemID == find);
	}

	public List<Row> FindAll_ItemID(string find)
	{
		return rowList.FindAll((Row x) => x.ItemID == find);
	}

	public Row Find_Note(string find)
	{
		return rowList.Find((Row x) => x.Note == find);
	}

	public List<Row> FindAll_Note(string find)
	{
		return rowList.FindAll((Row x) => x.Note == find);
	}
}
