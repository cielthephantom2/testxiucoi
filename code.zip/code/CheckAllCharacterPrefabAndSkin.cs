using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using Spine.Unity;
using SuperScrollView;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CheckAllCharacterPrefabAndSkin : MonoBehaviour
{
	private List<CharacterModelInfo> characterModelInfos = new List<CharacterModelInfo>();

	private ScrollRect scrollRect;

	private LoopGridView characterModelLoopGridView;

	private GameObject CharacterModelInfoPrefab;

	private List<GameObject> characterModelInfoObjList = new List<GameObject>();

	private InitCharacterIcon initCharacterIcon;

	private void Start()
	{
		SharedData.Instance(init: true);
		characterModelLoopGridView = GetComponentInChildren<LoopGridView>();
		scrollRect = GetComponentInChildren<ScrollRect>();
		initCharacterIcon = GetComponentInChildren<InitCharacterIcon>();
		characterModelInfos = new List<CharacterModelInfo>();
		CharacterModelInfoPrefab = Resources.Load("Prefabs/Debug/CharacterModelInfo") as GameObject;
		foreach (gang_b01Table.Row row2 in CommonResourcesData.b01.GetRowList())
		{
			CharacterModelInfo characterModelInfo = new CharacterModelInfo
			{
				id = row2.ID,
				soucre = CharacterModelSource.b01,
				name = row2.Name_Trans,
				battleIcon = row2.BattleIcon,
				prefab = row2.Prefab
			};
			if (characterModelInfos.Find((CharacterModelInfo x) => x.name.Equals(characterModelInfo.name) && x.battleIcon.Equals(characterModelInfo.battleIcon) && x.prefab.Equals(characterModelInfo.prefab) && x.soucre.Equals(characterModelInfo.soucre)) == null)
			{
				characterModelInfos.Add(characterModelInfo);
			}
		}
		foreach (gang_b04Table.Row row3 in CommonResourcesData.b04.GetRowList())
		{
			CharacterModelInfo characterModelInfo = new CharacterModelInfo
			{
				id = row3.GID + "_" + row3.ID,
				soucre = CharacterModelSource.b04,
				name = row3.Name_Trans,
				battleIcon = row3.BattleIcon,
				prefab = row3.Prefab
			};
			if (characterModelInfos.Find((CharacterModelInfo x) => x.name.Equals(characterModelInfo.name) && x.battleIcon.Equals(characterModelInfo.battleIcon) && x.prefab.Equals(characterModelInfo.prefab) && x.soucre.Equals(characterModelInfo.soucre)) == null)
			{
				characterModelInfos.Add(characterModelInfo);
			}
		}
		foreach (gang_b04Table.Row row4 in CommonResourcesData.b04_Random.GetRowList())
		{
			string name_Trans = row4.Name_Trans;
			CharacterModelInfo characterModelInfo = new CharacterModelInfo
			{
				id = row4.GID + "_" + row4.ID,
				soucre = CharacterModelSource.b04Random,
				name = name_Trans,
				battleIcon = row4.BattleIcon,
				prefab = row4.Prefab
			};
			if (characterModelInfos.Find((CharacterModelInfo x) => x.name.Equals(characterModelInfo.name) && x.battleIcon.Equals(characterModelInfo.battleIcon) && x.prefab.Equals(characterModelInfo.prefab) && x.soucre.Equals(characterModelInfo.soucre)) == null)
			{
				characterModelInfos.Add(characterModelInfo);
			}
		}
		foreach (gang_e01Table.Row row5 in CommonResourcesData.e01.GetRowList())
		{
			if (row5.display.StartsWith("Prefabs/Character/"))
			{
				string text = row5.display.Split('/')[2].Split('|')[0];
				CharacterModelInfo characterModelInfo = null;
				gang_b01Table.Row row = CommonResourcesData.b01.Find_Prefab(text);
				if (row != null)
				{
					characterModelInfo = new CharacterModelInfo
					{
						id = row5.flag,
						soucre = CharacterModelSource.e01,
						name = row.Name_Trans,
						battleIcon = row.BattleIcon,
						prefab = row.Prefab
					};
				}
				else
				{
					characterModelInfo = new CharacterModelInfo
					{
						id = row5.flag,
						soucre = CharacterModelSource.e01,
						name = "null",
						battleIcon = "null",
						prefab = text,
						isBattleIconFalse = true,
						isNotSkinFalse = true,
						isHeadTachieFalse = true,
						isSkinFalse = true,
						isTachieFalse = true
					};
				}
				if (characterModelInfos.Find((CharacterModelInfo x) => x.name.Equals(characterModelInfo.name) && x.battleIcon.Equals(characterModelInfo.battleIcon) && x.prefab.Equals(characterModelInfo.prefab) && x.soucre.Equals(characterModelInfo.soucre)) == null)
				{
					characterModelInfos.Add(characterModelInfo);
				}
			}
		}
		foreach (CharacterModelInfo characterModelInfo2 in characterModelInfos)
		{
			characterModelInfo2.b01SkinRow = CommonResourcesData.b01Skin.Find_ID(characterModelInfo2.prefab);
			if (characterModelInfo2.b01SkinRow != null)
			{
				characterModelInfo2.isSkin = true;
			}
			else
			{
				characterModelInfo2.isSkin = false;
				if (Resources.Load("Prefabs/Character/" + characterModelInfo2.prefab) as GameObject == null)
				{
					characterModelInfo2.isNotSkinFalse = true;
				}
			}
			if (CommonResourcesData.GetRoleIcon(characterModelInfo2.battleIcon) == null && characterModelInfo2.b01SkinRow == null)
			{
				characterModelInfo2.isBattleIconFalse = true;
			}
			Sprite tachieFull = CommonResourcesData.GetTachieFull(characterModelInfo2.battleIcon);
			if (tachieFull == null || tachieFull.name.Equals("pic-0-npc") || tachieFull.name.Equals("transparent"))
			{
				characterModelInfo2.isTachieFalse = true;
			}
			tachieFull = CommonResourcesData.GetTachieHead(characterModelInfo2.battleIcon);
			if (tachieFull == null || tachieFull.name.Equals("pic-0-npc") || tachieFull.name.Equals("transparent"))
			{
				characterModelInfo2.isHeadTachieFalse = true;
			}
		}
		characterModelInfos.Sort();
		characterModelLoopGridView.InitGridView(characterModelInfos.Count, OnGetCharacterModelInfoByRowColumn);
		Button[] componentsInChildren = base.transform.GetComponentsInChildren<Button>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			EventTriggerListener.Get(componentsInChildren[i].gameObject).onClick = OnButtonClick;
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (!go.name.Equals("Save"))
		{
			return;
		}
		string text = "souce,id,name,battleIcon,prefab,isSkin,isSkinFalse,isNotSkinFalse,isBattleIconFalse,isTachieFalse,isHeadTachieFalse\n";
		foreach (CharacterModelInfo characterModelInfo in characterModelInfos)
		{
			string text2 = characterModelInfo.soucre.ToString() + "," + characterModelInfo.id + "," + characterModelInfo.name + "," + characterModelInfo.battleIcon + "," + characterModelInfo.prefab + "," + characterModelInfo.isSkin + "," + characterModelInfo.isSkinFalse + "," + characterModelInfo.isNotSkinFalse + "," + characterModelInfo.isBattleIconFalse + "," + characterModelInfo.isTachieFalse + "," + characterModelInfo.isHeadTachieFalse + "\n";
			text += text2;
		}
		File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/TheWorldOfKongFu/CharacterModelInfoCheck.csv", text);
		Debug.Log("SaveFile Success");
	}

	private LoopGridViewItem OnGetCharacterModelInfoByRowColumn(LoopGridView gridView, int index, int row, int column)
	{
		if (index < 0)
		{
			return null;
		}
		CharacterModelInfo characterModelInfo = characterModelInfos[index];
		if (characterModelInfo == null)
		{
			return null;
		}
		LoopGridViewItem loopGridViewItem = gridView.NewListViewItem("CharacterModelInfo");
		if (!loopGridViewItem.IsInitHandlerCalled)
		{
			loopGridViewItem.IsInitHandlerCalled = true;
		}
		CharacterModelInfoUI(characterModelInfo, loopGridViewItem.gameObject);
		return loopGridViewItem;
	}

	private GameObject CharacterModelInfoUI(CharacterModelInfo characterModelInfo, GameObject tmpObj)
	{
		tmpObj.GetComponent<CharacterModelInfoController>().characterModelInfo = characterModelInfo;
		tmpObj.transform.Find("Info").GetComponent<TMP_Text>().text = "soucre = " + characterModelInfo.soucre.ToString() + ";name = " + characterModelInfo.name + ";\nprefab = " + characterModelInfo.prefab + ";battleIcon = " + characterModelInfo.battleIcon;
		try
		{
			gang_b01SkinTable.Row row = CommonResourcesData.b01Skin.Find_ID(characterModelInfo.prefab);
			tmpObj.transform.Find("PrefabSkin").gameObject.SetActive(row != null);
			tmpObj.transform.Find("PrefabNotSkin").gameObject.SetActive(row == null);
			tmpObj.transform.Find("BattleIcon1/Icon/IconImage").gameObject.SetActive(row == null);
			tmpObj.transform.Find("BattleIcon1/Icon/IconSkin").gameObject.SetActive(row != null);
			if (row != null)
			{
				SkeletonGraphic component = tmpObj.transform.Find("PrefabSkin/body_back").GetComponent<SkeletonGraphic>();
				SkeletonGraphic component2 = tmpObj.transform.Find("PrefabSkin/body_left").GetComponent<SkeletonGraphic>();
				SkeletonGraphic component3 = tmpObj.transform.Find("PrefabSkin/body_top").GetComponent<SkeletonGraphic>();
				SkinCharacter.InitSkinCharacterUI(component, row);
				SkinCharacter.InitSkinCharacterUI(component2, row);
				SkinCharacter.InitSkinCharacterUI(component3, row);
				component.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
				component2.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
				component3.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
				tmpObj.GetComponentInChildren<InitCharacterIcon>().InitCharacterSkinIcon(row);
			}
			else
			{
				characterModelInfo.isSkin = false;
				if (Resources.Load("Prefabs/Character/" + characterModelInfo.prefab) as GameObject != null)
				{
					GameObject prefab = UnityEngine.Object.Instantiate(Resources.Load("Prefabs/Character/" + characterModelInfo.prefab) as GameObject);
					StartCoroutine(delayset(tmpObj, prefab));
				}
				else
				{
					tmpObj.transform.Find("PrefabNotSkin").gameObject.SetActive(value: false);
				}
				Sprite roleIcon = CommonResourcesData.GetRoleIcon(characterModelInfo.battleIcon);
				tmpObj.transform.Find("BattleIcon1/Icon/IconImage").GetComponent<Image>().sprite = roleIcon;
			}
			tmpObj.transform.Find("BattleIcon2").GetComponent<Image>().sprite = CommonResourcesData.GetTachieFull(characterModelInfo.battleIcon);
			tmpObj.transform.Find("BattleIcon2/Image").GetComponent<Image>().sprite = CommonResourcesData.GetTachieHead(characterModelInfo.battleIcon);
			Toggle[] componentsInChildren = tmpObj.GetComponentsInChildren<Toggle>(includeInactive: true);
			foreach (Toggle toggle in componentsInChildren)
			{
				switch (toggle.name)
				{
				case "skin":
					toggle.isOn = characterModelInfo.isSkinFalse;
					break;
				case "notSkin":
					toggle.isOn = characterModelInfo.isNotSkinFalse;
					break;
				case "Tachie":
					toggle.isOn = characterModelInfo.isTachieFalse;
					break;
				case "headTachie":
					toggle.isOn = characterModelInfo.isHeadTachieFalse;
					break;
				case "battleIcon":
					toggle.isOn = characterModelInfo.isBattleIconFalse;
					break;
				}
			}
			return tmpObj;
		}
		catch (Exception exception)
		{
			Toggle[] componentsInChildren = tmpObj.GetComponentsInChildren<Toggle>(includeInactive: true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].isOn = true;
			}
			Debug.LogError("CharacterModelInfoUI fall");
			Debug.LogException(exception);
			tmpObj.GetComponent<Image>().color = Color.red;
			return tmpObj;
		}
	}

	private IEnumerator delayset(GameObject tmpObj, GameObject prefab)
	{
		yield return null;
		if (prefab != null)
		{
			SkeletonGraphic component = tmpObj.transform.Find("PrefabNotSkin/body_back").GetComponent<SkeletonGraphic>();
			SkeletonGraphic component2 = tmpObj.transform.Find("PrefabNotSkin/body_left").GetComponent<SkeletonGraphic>();
			SkeletonGraphic component3 = tmpObj.transform.Find("PrefabNotSkin/body_top").GetComponent<SkeletonGraphic>();
			component.skeletonDataAsset = prefab.transform.Find("body_back").GetComponent<SkeletonAnimation>().skeletonDataAsset;
			component2.skeletonDataAsset = prefab.transform.Find("body_left").GetComponent<SkeletonAnimation>().skeletonDataAsset;
			component3.skeletonDataAsset = prefab.transform.Find("body_top").GetComponent<SkeletonAnimation>().skeletonDataAsset;
			SkeletonAnimation component4 = prefab.transform.Find("body_back").GetComponent<SkeletonAnimation>();
			component.initialSkinName = component4.initialSkinName;
			SkeletonAnimation component5 = prefab.transform.Find("body_left").GetComponent<SkeletonAnimation>();
			component2.initialSkinName = component5.initialSkinName;
			SkeletonAnimation component6 = prefab.transform.Find("body_top").GetComponent<SkeletonAnimation>();
			component3.initialSkinName = component6.initialSkinName;
			component.Initialize(overwrite: true);
			component2.Initialize(overwrite: true);
			component3.Initialize(overwrite: true);
			component.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
			component2.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
			component3.AnimationState.SetAnimation(0, Aniname.aniname_stand, loop: true);
			UnityEngine.Object.DestroyImmediate(prefab.gameObject);
		}
	}
}
