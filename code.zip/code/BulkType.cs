public enum BulkType
{
	None,
	Shop,
	Loan,
	Redeem
}
