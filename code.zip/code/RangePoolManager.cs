using System.Collections.Generic;
using UnityEngine;

public class RangePoolManager
{
	public static readonly RangePoolManager instance = new RangePoolManager();

	[HideInInspector]
	public List<GameObject> pathObjectPool = new List<GameObject>();

	[HideInInspector]
	public List<GameObject> rangeObjectPool = new List<GameObject>();

	[HideInInspector]
	public List<GameObject> rangeCObjectPool = new List<GameObject>();

	[HideInInspector]
	public List<GameObject> rangeEObjectPool = new List<GameObject>();

	[HideInInspector]
	public List<GameObject> atkRangeObjectPool = new List<GameObject>();

	[HideInInspector]
	public List<GameObject> atkSelRangeObjectPool = new List<GameObject>();

	[HideInInspector]
	public List<GameObject> healSelRangeObjectPool = new List<GameObject>();

	private RangePoolManager()
	{
	}

	public GameObject GetObjectFromPool(string _type)
	{
		List<GameObject> list = null;
		GameObject original = CommonResourcesData.PathPrefab;
		switch (_type)
		{
		case "pathObject":
			list = pathObjectPool;
			original = CommonResourcesData.PathPrefab;
			break;
		case "Range":
			list = rangeObjectPool;
			original = CommonResourcesData.RangePrefab;
			break;
		case "RangeC":
			list = rangeCObjectPool;
			original = CommonResourcesData.RangeCPrefab;
			break;
		case "RangeE":
			list = rangeEObjectPool;
			original = CommonResourcesData.RangeEPrefab;
			break;
		case "AtkRange":
			list = atkRangeObjectPool;
			original = CommonResourcesData.AtkRangePrefab;
			break;
		case "AtkSelRange":
			list = atkSelRangeObjectPool;
			original = CommonResourcesData.AtkSelRangePrefab;
			break;
		case "HealSelRange":
			list = healSelRangeObjectPool;
			original = CommonResourcesData.HealSelRangePrefab;
			break;
		}
		GameObject gameObject = null;
		foreach (GameObject item in list)
		{
			if (!item.activeInHierarchy)
			{
				gameObject = item;
				gameObject.SetActive(value: true);
				break;
			}
		}
		if (gameObject == null)
		{
			gameObject = Object.Instantiate(original, SharedData.Instance().m_BattleController.map.transform);
			list.Add(gameObject);
		}
		return gameObject;
	}

	public void ClearObjectPool()
	{
		pathObjectPool.Clear();
		rangeObjectPool.Clear();
		rangeCObjectPool.Clear();
		rangeEObjectPool.Clear();
		atkRangeObjectPool.Clear();
		atkSelRangeObjectPool.Clear();
		healSelRangeObjectPool.Clear();
		AStarAlgorithmBattleField.AStarClean();
	}

	public void InitObjPoll()
	{
		foreach (string item in new List<string> { "pathObject", "Range", "RangeC", "RangeE", "AtkRange", "AtkSelRange", "HealSelRange" })
		{
			int num = 100;
			while (num-- > 0)
			{
				GetObjectFromPool(item).gameObject.SetActive(value: false);
			}
		}
	}
}
