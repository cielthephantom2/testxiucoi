using System.Collections.Generic;
using UnityEngine;

public class gang_b04RandomFightInfos
{
	public class Row
	{
		public string ID;

		public string Name;

		public string GID;

		public string Unique;

		public string RequireStep;

		public string BattleRate;

		public string MinEnemy;

		public string MaxEnemy;

		public string BattleField;
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row item = new Row
			{
				ID = list[i][num++],
				Name = list[i][num++],
				GID = list[i][num++],
				Unique = list[i][num++],
				RequireStep = list[i][num++],
				BattleRate = list[i][num++],
				MinEnemy = list[i][num++],
				MaxEnemy = list[i][num++],
				BattleField = list[i][num++]
			};
			rowList.Add(item);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_ID(string find)
	{
		return rowList.Find((Row x) => x.ID == find);
	}

	public List<Row> FindAll_ID(string find)
	{
		return rowList.FindAll((Row x) => x.ID == find);
	}
}
