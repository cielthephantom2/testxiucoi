using UnityEngine;
using UnityEngine.UI;

public class CautionLangSelect : MonoBehaviour
{
	public string TextCHN = "";

	public string TextENG = "";

	public string TextJPN = "";

	private void Start()
	{
		string text = Application.systemLanguage.ToString();
		if (text == "ChineseSimplified" || text == "ChineseTraditional")
		{
			GetComponent<Text>().text = "长按跳过动画";
		}
		else
		{
			GetComponent<Text>().text = "Long Press Skip Animation";
		}
	}
}
