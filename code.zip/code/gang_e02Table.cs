using System;
using System.Collections.Generic;
using UnityEngine;

public class gang_e02Table
{
	public class Row
	{
		public string chatid;

		public string talkicon;

		public string eventid;

		public string side;

		public string chating;

		public string rumourid;

		public string side_EN;

		public string check1;

		public string chating_en;

		public string check2;

		public string side_Trans => CommonFunc.ShortLangSel(side, side_EN);

		public string chating_Trans => CommonFunc.ShortLangSel(chating, chating_en);
	}

	private List<Row> rowList = new List<Row>();

	private bool isLoaded;

	public bool IsLoaded()
	{
		return isLoaded;
	}

	public List<Row> GetRowList()
	{
		return rowList;
	}

	public void Load(TextAsset csv)
	{
		rowList.Clear();
		List<string[]> list = CsvParser2.Parse(csv.text);
		for (int i = 1; i < list.Count; i++)
		{
			int num = 0;
			Row row = new Row();
			try
			{
				row.chatid = list[i][num++];
				row.talkicon = list[i][num++];
				row.eventid = list[i][num++];
				row.side = list[i][num++];
				row.chating = list[i][num++];
				row.rumourid = list[i][num++];
				row.side_EN = list[i][num++];
				row.check1 = list[i][num++];
				row.chating_en = list[i][num++];
				row.check2 = list[i][num++];
			}
			catch (Exception)
			{
				Debug.LogWarning(row.chatid + " " + row.side_EN);
				throw;
			}
			rowList.Add(row);
		}
		isLoaded = true;
	}

	public int NumRows()
	{
		return rowList.Count;
	}

	public Row GetAt(int i)
	{
		if (rowList.Count <= i)
		{
			return null;
		}
		return rowList[i];
	}

	public Row Find_chatid(string find)
	{
		return rowList.Find((Row x) => x.chatid == find);
	}

	public List<Row> FindAll_chatid(string find)
	{
		return rowList.FindAll((Row x) => x.chatid == find);
	}

	public Row Find_talkicon(string find)
	{
		return rowList.Find((Row x) => x.talkicon == find);
	}

	public List<Row> FindAll_talkicon(string find)
	{
		return rowList.FindAll((Row x) => x.talkicon == find);
	}

	public Row Find_eventid(string find)
	{
		return rowList.Find((Row x) => x.eventid == find);
	}

	public List<Row> FindAll_eventid(string find)
	{
		return rowList.FindAll((Row x) => x.eventid == find);
	}

	public Row Find_side(string find)
	{
		return rowList.Find((Row x) => x.side == find);
	}

	public List<Row> FindAll_side(string find)
	{
		return rowList.FindAll((Row x) => x.side == find);
	}

	public Row Find_chating(string find)
	{
		return rowList.Find((Row x) => x.chating == find);
	}

	public List<Row> FindAll_chating(string find)
	{
		return rowList.FindAll((Row x) => x.chating == find);
	}

	public Row Find_rumourid(string find)
	{
		return rowList.Find((Row x) => x.rumourid == find);
	}

	public List<Row> FindAll_rumourid(string find)
	{
		return rowList.FindAll((Row x) => x.rumourid == find);
	}

	public Row Find_side_EN(string find)
	{
		return rowList.Find((Row x) => x.side_EN == find);
	}

	public List<Row> FindAll_side_EN(string find)
	{
		return rowList.FindAll((Row x) => x.side_EN == find);
	}

	public Row Find_check1(string find)
	{
		return rowList.Find((Row x) => x.check1 == find);
	}

	public List<Row> FindAll_check1(string find)
	{
		return rowList.FindAll((Row x) => x.check1 == find);
	}

	public Row Find_chating_en(string find)
	{
		return rowList.Find((Row x) => x.chating_en == find);
	}

	public List<Row> FindAll_chating_en(string find)
	{
		return rowList.FindAll((Row x) => x.chating_en == find);
	}

	public Row Find_check2(string find)
	{
		return rowList.Find((Row x) => x.check2 == find);
	}

	public List<Row> FindAll_check2(string find)
	{
		return rowList.FindAll((Row x) => x.check2 == find);
	}
}
