public enum Direction
{
	Down = 2,
	Left = 6,
	Up = 8,
	Right = 4
}
