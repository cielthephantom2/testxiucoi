using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu3Controller : MonoBehaviour
{
	public GameObject WalkSub;

	public GameObject WConfirm;

	public GameObject WConfirmLeave;

	private GameObject MobileTerminalUI;

	public GameObject MobileTerminalWalkSub;

	private GameObject WalkMain;

	private GameObject joyStick;

	private GameObject joyTouch;

	private Transform RandonFightInfo;

	private Text RandomBattleInfoValue;

	private Text RandomBattleInfoName;

	private string Seconds = "";

	private string Steps = "";

	[HideInInspector]
	public List<Transform> AchievementsInfoList = new List<Transform>();

	[HideInInspector]
	public List<Transform> AtlasInfoList = new List<Transform>();

	private void Awake()
	{
		WalkSub = base.transform.Find("WalkSub").gameObject;
		WalkSub.SetActive(value: false);
		WConfirm = base.transform.Find("Confirm").gameObject;
		WConfirm.SetActive(value: false);
		WConfirmLeave = base.transform.Find("ConfirmLeave").gameObject;
		WConfirmLeave.SetActive(value: false);
		WalkMain = base.transform.Find("WalkMain").gameObject;
		MobileTerminalUI = base.transform.Find("MobileTerminalUI").gameObject;
		MobileTerminalWalkSub = WalkSub;
		MobileTerminalWalkSub.SetActive(value: false);
		joyStick = base.transform.Find("JoyStick").gameObject;
		joyTouch = base.transform.Find("JoyTouch").gameObject;
		RandonFightInfo = base.transform.Find("RandomFightInfo");
		RandomBattleInfoValue = RandonFightInfo.Find("Value").GetComponent<Text>();
		RandomBattleInfoName = RandonFightInfo.Find("Name").GetComponent<Text>();
		Seconds = CommonFunc.I18nGetLocalizedValue("I18N_Seconds");
		Steps = CommonFunc.I18nGetLocalizedValue("I18N_RandomFight_Walk_Steps");
		Button[] componentsInChildren = base.gameObject.GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button button in componentsInChildren)
		{
			if (button.name != "JoyTouch")
			{
				EventTriggerListener.Get(button.gameObject).onClick = OnButtonClick;
			}
		}
		AchievementsInfoList.Add(base.transform.parent.Find("AchievementsInfoList/AchievementsInfo1"));
		AchievementsInfoList.Add(base.transform.parent.Find("AchievementsInfoList/AchievementsInfo2"));
		AchievementsInfoList.Add(base.transform.parent.Find("AchievementsInfoList/AchievementsInfo3"));
		AchievementsInfoList.Add(base.transform.parent.Find("AchievementsInfoList/AchievementsInfo4"));
		AchievementsInfoList.Add(base.transform.parent.Find("AchievementsInfoList/AchievementsInfo5"));
		AtlasInfoList.Add(base.transform.parent.Find("AtlasInfoList/AtlasInfo1"));
		AtlasInfoList.Add(base.transform.parent.Find("AtlasInfoList/AtlasInfo2"));
		AtlasInfoList.Add(base.transform.parent.Find("AtlasInfoList/AtlasInfo3"));
		AtlasInfoList.Add(base.transform.parent.Find("AtlasInfoList/AtlasInfo4"));
		AtlasInfoList.Add(base.transform.parent.Find("AtlasInfoList/AtlasInfo5"));
		OhPlayerController player = SharedData.Instance().player;
		if ((object)player != null && player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["AvoidRandomBattleTime"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue + Seconds;
			return;
		}
		OhPlayerController player2 = SharedData.Instance().player;
		if ((object)player2 != null && player2.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["MeetRandomBattleTime"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue + Seconds;
			return;
		}
		OhPlayerController player3 = SharedData.Instance().player;
		if ((object)player3 != null && player3.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["AvoidRandomBattleSetps"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue + Steps;
			return;
		}
		OhPlayerController player4 = SharedData.Instance().player;
		if ((object)player4 != null && player4.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["MeetRandomBattleSetps"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue + Steps;
		}
	}

	private void Update()
	{
		if (SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue > 0f)
		{
			SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue = SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue - Time.deltaTime;
			if (SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue < 0f)
			{
				SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue = 0f;
			}
		}
		if (SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue > 0f)
		{
			SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue = SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue - Time.deltaTime;
			if (SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue < 0f)
			{
				SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue = 0f;
			}
		}
		bool flag = false;
		if (SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["AvoidRandomBattleTime"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleTime"].alterValue + Seconds;
			flag = true;
		}
		else if (SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["MeetRandomBattleTime"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleTime"].alterValue + Seconds;
			flag = true;
		}
		if (SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["AvoidRandomBattleSetps"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["AvoidRandomBattleSetps"].alterValue + Steps;
			flag = true;
		}
		else if (SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue > 0f)
		{
			RandomBattleInfoName.text = SharedData.Instance().m_A01NameRowDirec["MeetRandomBattleSetps"].NameScene_Trans;
			RandomBattleInfoValue.text = (int)SharedData.Instance().player.charadata.Indexs_Name["MeetRandomBattleSetps"].alterValue + Steps;
			flag = true;
		}
		if (flag && !RandonFightInfo.gameObject.activeInHierarchy)
		{
			RandonFightInfo.gameObject.SetActive(value: true);
		}
		if (!flag && RandonFightInfo.gameObject.activeInHierarchy)
		{
			RandonFightInfo.gameObject.SetActive(value: false);
		}
		UnlockAchievement();
		UnlockAtlas();
		if (!CommonFunc.IsHoverOpen() && !(SharedData.Instance().m_MapController == null) && !SharedData.Instance().m_MapController.IsChating() && !SharedData.Instance().m_StatusMain.gameObject.activeInHierarchy && !SharedData.Instance().m_PackageController.isOpen && !SharedData.Instance().m_TraitPackageController.isOpen && SceneManager.sceneCount <= 1 && !SharedData.Instance().IsViewOpen)
		{
			if (InputSystemCustom.Instance().UI.OpenStatusMain.WasReleasedThisFrame())
			{
				OpenStatusMain("1");
			}
			else if (InputSystemCustom.Instance().UI.OpenSystemMenu.WasReleasedThisFrame())
			{
				SwitchSub();
			}
			else if (WalkSub.gameObject.activeInHierarchy && InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame())
			{
				SwitchSub();
			}
			else if (InputSystemCustom.Instance().UI.QuickOpenLoadManual.WasReleasedThisFrame() && SharedData.Instance().loadMapE04.savedata.Equals("1"))
			{
				SharedData.Instance().m_MapController.SaveMapSnapShot();
				Close();
				SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
				SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Save;
				SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
			}
		}
	}

	public void OnButtonClick(GameObject go)
	{
		if (go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		MapController mapController = SharedData.Instance().m_MapController;
		MonoBehaviour.print("[Menu3] Click button: " + go.name);
		if (go.name == "WalkMain" || go.name == "MTWalkMainPort")
		{
			OpenStatusMain("1");
		}
		else if (go.name == "WalkTeam")
		{
			Close();
			SharedData.Instance().LoadSceneStackAdd("BeforeTeam");
			SceneManager.LoadScene("BeforeTeam", LoadSceneMode.Additive);
		}
		else if (go.name == "WalkItem")
		{
			SharedData.Instance().OpenPackageFor = "WalkSub";
			SharedData.Instance().OpenPackageFilter = "1000000000";
			Close();
			SharedData.Instance().LoadSceneStackAdd("Package");
			SceneManager.LoadScene("Package", LoadSceneMode.Additive);
		}
		else if (go.name == "WalkSave" || go.name == "MTSave")
		{
			mapController.SaveMapSnapShot();
			Close();
			SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
			SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Save;
			SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
		}
		else if (go.name == "WalkLoad" || go.name == "MTLoad")
		{
			Close();
			SharedData.Instance().LoadSceneStackAdd("DataRecordManage");
			SharedData.Instance().m_DataRecordManager.DataType = SaveOrLoad.Load;
			SharedData.Instance().m_DataRecordManager.gameObject.SetActive(value: true);
		}
		else if (go.name == "WalkCamp")
		{
			mapController.SaveMapSnapShot();
			SharedData.Instance().BackFromOtherScene = false;
			SharedData.Instance().SpawnPoint = "Spawn";
			SharedData.Instance().ASyncLoadScene("Base_YingDi");
		}
		else if (go.name == "WalkLeave")
		{
			WalkSub.SetActive(value: false);
			MobileTerminalWalkSub.SetActive(value: false);
			WConfirmLeave.transform.Find("Text").GetComponent<Text>().text = CommonFunc.ShortLangSel("确认是否快速离开迷宫？", "Confirm quick leave dungeon?");
			WConfirmLeave.SetActive(value: true);
			EventSystem.current.SetSelectedGameObject(WConfirmLeave.transform.Find("LeaveOk").gameObject);
		}
		else if (go.name == "LeaveOk")
		{
			string[] array = mapController.m_leave_pos.Split('|');
			if (array.Length > 1)
			{
				if (SharedData.Instance().FlagList["STAGE_02_1_1A"] == 1)
				{
					mapController.LeaveTeam("1186");
					mapController.OpenEvent("STAGE_02_1_1A");
					mapController.OpenEvent("MAP_01_19", _active: true);
				}
				SharedData.Instance().SpawnPoint = array[1];
				SharedData.Instance().SpawnStatus = "Normal";
				mapController.LoadScene(array[0]);
			}
		}
		else if (go.name == "LeaveCancel")
		{
			WConfirmLeave.SetActive(value: false);
		}
		else if (go.name == "WalkTitle")
		{
			WalkSub.SetActive(value: false);
			MobileTerminalWalkSub.SetActive(value: false);
			WConfirm.transform.Find("Text").GetComponent<Text>().text = CommonFunc.ShortLangSel("确认是否要返回标题？", "Confirm bake to title?");
			WConfirm.SetActive(value: true);
			EventSystem.current.SetSelectedGameObject(WConfirm.transform.Find("YouAreOk").gameObject);
		}
		else if (go.name == "WalkCancel")
		{
			WalkSub.SetActive(value: false);
			MobileTerminalWalkSub.SetActive(value: false);
		}
		else if (go.name == "YouAreOk")
		{
			SharedData.Instance().ASyncLoadScene("Title");
		}
		else if (go.name == "NaoCanDaShaBi")
		{
			WConfirm.SetActive(value: false);
			InputSystemCustom.Instance().Player.Enable();
		}
		else if (go.name == "WalkMap" || go.name == "MTMap")
		{
			mapController.OpenMapView();
		}
		else if (go.name == "WalkLog")
		{
			mapController.OpenLogView();
		}
		else if (go.name == "MTSystem")
		{
			MobileTerminalWalkSub.SetActive(!MobileTerminalWalkSub.activeInHierarchy);
		}
		else if (go.name == "WalkSetting")
		{
			Close();
			MobileTerminalUI.SetActive(value: false);
			joyStick.SetActive(value: false);
			joyTouch.SetActive(value: false);
			Camera.main.GetComponent<AudioListener>().enabled = false;
			SharedData.Instance().LoadSceneStackAdd("Config");
			SceneManager.LoadScene("Config", LoadSceneMode.Additive);
		}
		else if (go.name == "WalkFieldGuide")
		{
			Close();
			SharedData.Instance().m_AtlasManagerNewController.OpenAtlas();
		}
		else if (go.name == "WalkRumour")
		{
			Close();
			SharedData.Instance().IsViewOpen = true;
			SceneManager.LoadScene("JourneyList", LoadSceneMode.Additive);
		}
	}

	public void OpenStatusMain(string _subid)
	{
		InputDeviceDetector.instance.ClearJoyStack();
		WConfirm.SetActive(value: false);
		WConfirmLeave.SetActive(value: false);
		WalkSub.SetActive(value: false);
		MobileTerminalWalkSub.SetActive(value: false);
		base.gameObject.SetActive(value: false);
		SharedData.Instance().OpenPackageFor = "WalkMain";
		switch (_subid)
		{
		case "1":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub1.gameObject;
			break;
		case "2":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub2.gameObject;
			break;
		case "3":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub3.gameObject;
			break;
		case "4":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub4.gameObject;
			break;
		case "5":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub5.gameObject;
			break;
		case "6":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_StatusSub6.gameObject;
			break;
		case "7":
			SharedData.Instance().CurrentStatusSubName = SharedData.Instance().m_PackageController.gameObject;
			break;
		}
		SharedData.Instance().CurrentChara = SharedData.Instance().playerid;
		SharedData.Instance().m_StatusMain.gameObject.SetActive(value: true);
		if (SharedData.Instance().CurrentStatusSubName == SharedData.Instance().m_PackageController.gameObject)
		{
			SharedData.Instance().m_PackageController.OpenPackage(refresh: true, PackagerFunction.PlayerPackage);
		}
		else
		{
			SharedData.Instance().CurrentStatusSubName.gameObject.SetActive(value: true);
		}
	}

	public void Open()
	{
		if (!SharedData.Instance().m_StatusMain.gameObject.activeInHierarchy && !SharedData.Instance().IsViewOpen && !IsOpen())
		{
			base.gameObject.SetActive(value: true);
		}
	}

	public void Close()
	{
		if (IsOpen())
		{
			WConfirm.SetActive(value: false);
			WConfirmLeave.SetActive(value: false);
			WalkSub.SetActive(value: false);
			MobileTerminalWalkSub.SetActive(value: false);
			base.gameObject.SetActive(value: false);
			InputSystemCustom.Instance().Player.Enable();
		}
	}

	public bool IsOpen()
	{
		return base.gameObject.activeInHierarchy;
	}

	public void SwitchSub()
	{
		if (WConfirm.activeInHierarchy)
		{
			WConfirm.SetActive(value: false);
		}
		else if (WConfirmLeave.activeInHierarchy)
		{
			WConfirmLeave.SetActive(value: false);
		}
		else
		{
			WalkSub.SetActive(!WalkSub.activeInHierarchy);
		}
		if (WalkSub.activeInHierarchy)
		{
			EventSystem.current.SetSelectedGameObject(WalkSub.transform.Find("WalkSetting").gameObject);
		}
	}

	public void UnlockAchievement()
	{
		if (SharedData.Instance().UnlockAchievementInfoList.Count == 0)
		{
			return;
		}
		foreach (KeyValuePair<string, Sprite> unlockAchievementInfo in SharedData.Instance().UnlockAchievementInfoList)
		{
			if (SharedData.Instance().UnlockAchievementInfoAlreadyShow.Contains(unlockAchievementInfo.Key))
			{
				continue;
			}
			foreach (Transform achievementsInfo in AchievementsInfoList)
			{
				if (!achievementsInfo.GetComponent<Animation>().isPlaying)
				{
					achievementsInfo.Find("Text").GetComponent<Text>().text = unlockAchievementInfo.Key;
					achievementsInfo.Find("Image").GetComponent<Image>().sprite = unlockAchievementInfo.Value;
					achievementsInfo.GetComponent<Animation>()["Achievements" + achievementsInfo.gameObject.name[achievementsInfo.gameObject.name.Length - 1]].speed = 1f;
					achievementsInfo.GetComponent<Animation>().Play();
					SharedData.Instance().UnlockAchievementInfoAlreadyShow.Add(unlockAchievementInfo.Key);
					break;
				}
			}
		}
	}

	public void UnlockAtlas()
	{
		if (SharedData.Instance().UnlockAtlasInfoList.Count == 0)
		{
			return;
		}
		foreach (KeyValuePair<string, Sprite> unlockAtlasInfo in SharedData.Instance().UnlockAtlasInfoList)
		{
			if (SharedData.Instance().UnlockAtlasInfoAlreadyShow.Contains(unlockAtlasInfo.Key))
			{
				continue;
			}
			foreach (Transform atlasInfo in AtlasInfoList)
			{
				if (!atlasInfo.GetComponent<Animation>().isPlaying)
				{
					atlasInfo.Find("Text").GetComponent<Text>().text = CommonFunc.ShortLangSel("解锁图鉴", "UnLock Atlas") + "[" + unlockAtlasInfo.Key + "]";
					atlasInfo.Find("Image").GetComponent<Image>().sprite = unlockAtlasInfo.Value;
					atlasInfo.GetComponent<Animation>()["Achievements" + atlasInfo.gameObject.name[atlasInfo.gameObject.name.Length - 1]].speed = 1f;
					atlasInfo.GetComponent<Animation>().Play();
					SharedData.Instance().UnlockAtlasInfoAlreadyShow.Add(unlockAtlasInfo.Key);
					break;
				}
			}
		}
	}
}
