using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

public class InitCharacterIcon : MonoBehaviour
{
	public void InitCharacterSkinIcon(gang_b01SkinTable.Row b01SkinRow, int LV = 0)
	{
		base.transform.Find("IconSkin").gameObject.SetActive(value: true);
		base.transform.Find("IconImage").gameObject.SetActive(value: false);
		SkeletonGraphic component = base.transform.Find("IconSkin").GetComponent<SkeletonGraphic>();
		SkinCharacter.InitSkinCharacterUI(component, b01SkinRow);
		Spine.Animation animation = component.Skeleton.Data.FindAnimation(Aniname.aniname_stand);
		if (animation == null)
		{
			Debug.LogError("Animation not found: " + Aniname.aniname_stand);
			return;
		}
		animation.Apply(component.Skeleton, 0f, 0f, loop: false, null, 1f, MixBlend.Replace, MixDirection.In);
		component.Update(0f);
	}

	public void InitCharacterSkinIcon(CharaData charaData, int LV = 0)
	{
		if (charaData == null)
		{
			base.transform.Find("IconSkin").gameObject.SetActive(value: false);
			base.transform.Find("IconImage").gameObject.SetActive(value: false);
			return;
		}
		base.transform.Find("IconSkin").gameObject.SetActive(value: true);
		base.transform.Find("IconImage").gameObject.SetActive(value: true);
		_ = charaData.m_Prefab;
		_ = CommonResourcesData.b01.Find_ID(charaData.m_Id)?.Prefab;
		gang_b01SkinTable.Row b01SkinRow = charaData.b01SkinRow;
		if (b01SkinRow == null)
		{
			base.transform.Find("IconImage").GetComponent<Image>().sprite = CommonResourcesData.GetRoleIcon(charaData.m_BattleIcon);
			base.transform.Find("IconSkin").gameObject.SetActive(value: false);
		}
		else
		{
			InitCharacterSkinIcon(b01SkinRow, LV);
		}
		if (LV != 0)
		{
			base.transform.Find("LV").gameObject.SetActive(value: true);
			base.transform.Find("LV/Text").GetComponent<Text>().text = "LV." + LV;
		}
	}

	public void InitCharacterSkinIcon(string _id, int LV = 0, gang_b01SkinTable.Row _b01SkinRow = null)
	{
		gang_b01Table.Row row = CommonResourcesData.b01.Find_ID(_id);
		gang_b01SkinTable.Row row2 = SharedData.Instance().GetCharaData(row.ID).b01SkinRow;
		if (_b01SkinRow != null)
		{
			row2 = _b01SkinRow;
		}
		if (row2 == null)
		{
			base.transform.Find("IconSkin").gameObject.SetActive(value: false);
			base.transform.Find("IconImage").gameObject.SetActive(value: true);
			base.transform.Find("IconImage").GetComponent<Image>().sprite = CommonResourcesData.GetRoleIcon(row.BattleIcon);
		}
		else
		{
			InitCharacterSkinIcon(row2, LV);
		}
		if (LV != 0)
		{
			base.transform.Find("LV").gameObject.SetActive(value: true);
			base.transform.Find("LV/Text").GetComponent<Text>().text = "LV." + LV;
		}
	}
}
