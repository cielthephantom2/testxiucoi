using System;
using System.Collections.Generic;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class GameData
{
	[Key(0)]
	public string key;

	[Key(1)]
	public long timeStamp = long.MinValue;

	[Key(2)]
	public string saveDataTime = "";

	[Key(3)]
	public List<SimpleCharaData> simpleCharaDatas = new List<SimpleCharaData>();

	[Key(4)]
	public List<SimpleMapUnit> simpleMapUnits = new List<SimpleMapUnit>();

	[Key(5)]
	public List<SimpleEventRecord> simpleEventRecords = new List<SimpleEventRecord>();

	[Key(6)]
	public List<SimpleFlagData> simpleFlagDatas = new List<SimpleFlagData>();

	[Key(7)]
	public string strFlagDatas = "";

	[Key(8)]
	public string bornid = "";

	[Key(9)]
	public string playerid = "";

	[Key(10)]
	public string SceneBefore = "";

	[Key(11)]
	public string SceneBefore4Camp = "";

	[Key(12)]
	public string SpawnPoint = "";

	[Key(13)]
	public bool playercamctrl;

	[Key(14)]
	public int m_Money;

	[Key(15)]
	public int m_Epiphany;

	[Key(16)]
	public int m_PlayRound;

	[Key(17)]
	public float m_FieldMoveSpeedRate = 1f;

	[Key(18)]
	public int playerdirection;

	[Key(19)]
	public List<SimplePackItem> simplePackItems = new List<SimplePackItem>();

	[Key(20)]
	public List<string> FullTeam;

	[Key(21)]
	public List<string> FollowList;

	[Key(22)]
	public List<string> Mesg_News;

	[Key(23)]
	public List<string> Mesg_Tecs;

	[Key(24)]
	public int Game_Mode;

	[Key(25)]
	public int m_ArenaWinCount;

	[Key(26)]
	public string m_Arena_Rewards_JunShan = "000000000000000";

	[Key(27)]
	public List<SimpleShopGood> simpleShopGoods = new List<SimpleShopGood>();

	[Key(28)]
	public List<SimpleShopGood> simpleLoanedItems = new List<SimpleShopGood>();

	[Key(29)]
	public List<SimpleShopGood> simpleHoriMonos = new List<SimpleShopGood>();

	[Key(30)]
	public List<SimpleShopGood> simpleWantedInfos = new List<SimpleShopGood>();

	[Key(31)]
	public int m_MineRefreshWalkStep;

	[Key(32)]
	public int m_MineRefreshChangeFieldNum;

	[Key(33)]
	public int m_ShovelDurable;

	[Key(34)]
	public List<MineInfo> mapMineList = new List<MineInfo>();

	[Key(35)]
	public List<RefreshMineInfo> mapMineCouldRefreshList = new List<RefreshMineInfo>();

	[Key(36)]
	public int m_DaTianWangSiLevel;

	[Key(37)]
	public string m_Arena_Rewards_DaTianWangSi = "";

	[Key(38)]
	public string m_DongShuFactionMember = "1202|607";

	[Key(39)]
	public string m_UnLockMapIconList = "";

	[Key(40)]
	public List<string> b02append = new List<string>();

	[Key(41)]
	public List<string> b03append = new List<string>();

	[Key(42)]
	public List<string> b07append = new List<string>();

	[Key(43)]
	public List<string> m_SpecialWantedList = new List<string>();

	[Key(44)]
	public List<string> lastSelectBattleIdList = new List<string>();

	[Key(45)]
	public bool isChooseBattle;

	[Key(46)]
	[IgnoreMember]
	public ProtagonistSkinData protagonistSkinData = new ProtagonistSkinData();

	[Key(47)]
	public string m_JinWuFactionMember = "9018|502";

	[Key(48)]
	public string m_XiBoFactionMember = "202|401|402|403";

	[Key(49)]
	public gang_b01SkinTable.Row protagonistSkinB01SkinTable;

	[Key(50)]
	public ProtagonistSkinDataNew protagonistSkinDataNew;

	[Key(51)]
	public string gameDateVersion = "";

	[Key(52)]
	public string m_BeiGuFactionMember = "205";

	[Key(53)]
	public List<string> m_NewItemList = new List<string>();
}
