using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using TMPro;
using UnityEngine;

public static class RangeManager
{
	public static bool isCalShowUnitRange = false;

	private static List<GameObject> rangeObject = new List<GameObject>();

	private static List<GameObject> AtkRangeObject = new List<GameObject>();

	private static List<GameObject> AtkSelRangeObject = new List<GameObject>();

	private static int GetMovement(BattleObject battleObject)
	{
		int num = 0;
		float battleValueByName = battleObject.charadata.GetBattleValueByName("SP");
		int i;
		for (i = 1; 30f * Mathf.Pow(2f, i - 1) <= battleValueByName; i++)
		{
		}
		num = i;
		if (num > 5)
		{
			num = 5;
		}
		num += (int)battleObject.charadata.GetFieldValueByName("Movement");
		if (num > 8)
		{
			num = 8;
		}
		if (battleObject.charadata.GetBattleValueByName("Burn") > 125f)
		{
			num = 1;
		}
		return num;
	}

	private static void CalAttackRange(BattleObject battleObject, string type)
	{
		battleObject.attackRange.Clear();
		Vector3Int vector3Int = SharedData.Instance().m_BattleController.tilemap.WorldToCell(battleObject.transform.localPosition);
		Vector3Int vector3Int2 = new Vector3Int(vector3Int.x, -vector3Int.y, 0);
		if (type.Split('|')[1] == "B")
		{
			ShowAttackSelectRange(battleObject, vector3Int2);
			SharedData.Instance().m_BattleController.ShowHpGaugeInAttackRange();
			return;
		}
		if (battleObject.m_Revenge_Target != null && !battleObject.m_Revenge_Target.isDead)
		{
			if (SharedData.Instance().m_BattleController.GetCurrentObjActionType() != 0)
			{
				battleObject.m_AttackType = type.Split('|');
				battleObject.attackRange.Add(battleObject.m_Revenge_Target.GetGridPosition());
			}
			return;
		}
		foreach (KeyValuePair<Vector3Int, int> item in AttackData.GetRange1ByAttackType(battleObject.m_AttackType, vector3Int2, battleObject))
		{
			battleObject.attackRange.Add(item.Key);
		}
	}

	private static void CalAttackSelectRange(BattleObject battleObject, Vector3Int attackPos)
	{
		ClearAttackSelectRange();
		battleObject.attackSelectRange.Clear();
		Dictionary<Vector3Int, int> dictionary = null;
		battleObject.AdjustFace(attackPos);
		dictionary = ((!(battleObject.m_AttackType[1] != "B")) ? AttackData.GetRange2ByAttackType(battleObject.m_AttackType, battleObject.GetGridPosition(), 0, battleObject.GetGridPosition()) : AttackData.GetRange2ByAttackType(battleObject.m_AttackType, attackPos, (int)battleObject.m_Direction, battleObject.GetGridPosition()));
		foreach (KeyValuePair<Vector3Int, int> item in dictionary)
		{
			battleObject.attackSelectRange.Add(item.Key);
		}
	}

	public static IEnumerator ShowUnitRangeCoroutine(BattleObject battleObject, bool reCallAStarPathDict = true, BattleControllerFlow battleControllerFlow = BattleControllerFlow.None, BattleObjectState battleObjectState = BattleObjectState.None)
	{
		isCalShowUnitRange = true;
		if (battleObject.unitRange.Count == 0)
		{
			int movement = GetMovement(battleObject);
			Vector3Int position = battleObject.GetGridPosition();
			if (reCallAStarPathDict)
			{
				AutoBattleCal.alreadyAStarPathDict.Clear();
				AutoBattleCal.AStarPathDamageDict.Clear();
			}
			if (battleObject.CheckBuffEffectOn("Dexterous") || battleObject.CheckBuffEffectOn("AllMove"))
			{
				movement = 20;
			}
			bool isNoZoc = battleObject.m_NoZOC;
			Dictionary<Vector3Int, bool> isBattleObjOnTmp = new Dictionary<Vector3Int, bool>();
			foreach (BattleObject allBattleObj in SharedData.Instance().m_BattleController.allBattleObjs)
			{
				Vector3Int gridPosition = allBattleObj.GetGridPosition();
				if (gridPosition == position)
				{
					continue;
				}
				bool value = SharedData.Instance().m_BattleController.CheckIsEnemyOnGrid(gridPosition, battleObject) || SharedData.Instance().m_BattleController.CheckIsItemOnGrid(gridPosition);
				if (isBattleObjOnTmp.ContainsKey(gridPosition))
				{
					if (!isBattleObjOnTmp[gridPosition])
					{
						isBattleObjOnTmp.TryAdd(gridPosition, value);
					}
				}
				else
				{
					isBattleObjOnTmp.TryAdd(gridPosition, value);
				}
			}
			yield return null;
			if (SharedData.Instance().m_BattleController.obstacle.Contains(position))
			{
				Dictionary<Vector3Int, int> dictionary = new Dictionary<Vector3Int, int>();
				Queue<Vector3Int> queue = new Queue<Vector3Int>();
				queue.Enqueue(position);
				dictionary[position] = 0;
				while (queue.Count > 0)
				{
					Vector3Int vector3Int = queue.Dequeue();
					int num = dictionary[vector3Int];
					if (num >= movement)
					{
						continue;
					}
					foreach (Vector3Int gridNeighbor in SharedData.Instance().m_BattleController.GetGridNeighbors(vector3Int))
					{
						if (!dictionary.ContainsKey(gridNeighbor) && (isNoZoc || !isBattleObjOnTmp.ContainsKey(gridNeighbor) || !isBattleObjOnTmp[gridNeighbor]))
						{
							dictionary[gridNeighbor] = num + 1;
							queue.Enqueue(gridNeighbor);
						}
					}
				}
				foreach (KeyValuePair<Vector3Int, int> item in dictionary)
				{
					if (item.Value <= movement)
					{
						battleObject.unitRange.Add(item.Key, item.Value);
					}
				}
			}
			yield return null;
			battleObject.standPosList.Clear();
			battleObject.standPosList.Add(position, 0);
			InitUnitTabele(battleObject, position);
			foreach (Vector3Int item2 in battleObject.unitRange.Keys.ToList())
			{
				if (position == item2)
				{
					continue;
				}
				bool flag = false;
				List<Vector3Int> aStarPath = AStarAlgorithmBattleField.GetAStarPath(battleObject, position, item2);
				if (aStarPath.Count > 0)
				{
					flag = aStarPath[0] == item2;
				}
				if (!flag)
				{
					battleObject.unitRange.Remove(item2);
				}
				else if (!SharedData.Instance().m_BattleController.CheckIsBattleObjectOnGrid(item2) && !SharedData.Instance().m_BattleController.CheckIsItemOnGrid(item2))
				{
					battleObject.standPosList.Add(item2, battleObject.unitRange[item2]);
					InitUnitTabele(battleObject, item2);
					if (reCallAStarPathDict)
					{
						AutoBattleCal.alreadyAStarPathDict.Add(item2, aStarPath);
						float pathTerrainDamage = AutoBattleCal.GetPathTerrainDamage(battleObject, aStarPath);
						AutoBattleCal.AStarPathDamageDict.Add(aStarPath, pathTerrainDamage);
					}
				}
			}
			yield return null;
			battleObject.m_MpBroken = true;
			battleObject.m_couldAttack = false;
			battleObject.m_couldHealHp = false;
			battleObject.m_couldHealNegativeBuff = false;
			battleObject.m_couldAddBuff = false;
			battleObject.m_couldEscape = false;
			foreach (Vector3Int gridNeighbor2 in SharedData.Instance().m_BattleController.GetGridNeighbors(battleObject.GetGridPosition()))
			{
				if (!SharedData.Instance().m_BattleController.IsBlock(gridNeighbor2))
				{
					battleObject.m_couldEscape = true;
					break;
				}
			}
			bool flag2 = SharedData.Instance().m_BattleController.GetCurrentObjActionType() == ActionType.Runaway || battleObject.CheckBuffEffectOn("Dexterous");
			for (int j = 0; j < battleObject.m_SkillList.Count; j++)
			{
				string[] array = battleObject.m_SkillList[j].Split('|');
				KongFuData kongFuByID = battleObject.charadata.GetKongFuByID(array[0]);
				float num2 = Mathf.Floor(float.Parse(kongFuByID.kf.Expend, CultureInfo.InvariantCulture) + float.Parse(kongFuByID.kf.Expendadd, CultureInfo.InvariantCulture) * ((float)kongFuByID.lv - 1f));
				if ((battleObject.charadata.m_Mp < num2 || flag2 || battleObject.CheckIsWugongWasBan(kongFuByID.kf)) && battleObject.GetEffectOnSuperWugongID() != kongFuByID.kf.ID && battleObject.GetEffectOnFormationWugongID() != kongFuByID.kf.ID)
				{
					battleObject.m_SkillList[j] = array[0] + "|" + array[1] + "|" + array[2] + "|" + array[3] + "|" + kongFuByID.lv + "|MP-POOR|" + num2;
					continue;
				}
				battleObject.m_MpBroken = false;
				battleObject.m_SkillList[j] = array[0] + "|" + array[1] + "|" + array[2] + "|" + array[3] + "|" + kongFuByID.lv + "|MP-GOOD|" + num2;
				if (!battleObject.m_couldAttack && (kongFuByID.isAttackSkill || kongFuByID.isSummonSkill))
				{
					battleObject.m_couldAttack = true;
				}
				if (!battleObject.m_couldHealHp && kongFuByID.isHealHpSkill)
				{
					battleObject.m_couldHealHp = true;
				}
				if (!battleObject.m_couldHealNegativeBuff && kongFuByID.isHealNegativeBuffSkill)
				{
					battleObject.m_couldHealNegativeBuff = true;
				}
				if (!battleObject.m_couldAddBuff && kongFuByID.isBuffSkill)
				{
					battleObject.m_couldAddBuff = true;
				}
				if (!battleObject.m_couldSwapPos && kongFuByID.isSwapPosSkill)
				{
					battleObject.m_couldEscape = true;
					battleObject.m_couldSwapPos = true;
				}
			}
			for (int i = 0; i < battleObject.m_SkillList.Count; i++)
			{
				string[] array2 = battleObject.m_SkillList[i].Split('|');
				if ("MP-POOR".Equals(array2[5]))
				{
					continue;
				}
				gang_b03Table.Row b03RowIn = CommonResourcesData.b03.Find_ID(array2[0]);
				foreach (KeyValuePair<Vector3Int, int> standPos in battleObject.standPosList)
				{
					Forecast forecast = null;
					int num3 = -1;
					KongFuData kongFuByID2 = battleObject.charadata.GetKongFuByID(array2[0]);
					if (SharedData.Instance().m_BattleController.isLostControl && ("9001".Equals(kongFuByID2.kf.Style) || KongFuCommomFunc.CheckWugongHaveEffect(kongFuByID2.kf, "StealATK")))
					{
						continue;
					}
					foreach (KeyValuePair<Vector3Int, int> item3 in AttackData.GetRange1ByAttackType(array2, standPos.Key, battleObject, b03RowIn))
					{
						Forecast forecast2;
						if (forecast != null && forecast.actionName == battleObject.m_SkillList[i] && item3.Value == num3)
						{
							Vector3Int vector3Int2 = item3.Key - forecast.targetPos;
							forecast2 = new Forecast
							{
								actionPos = standPos.Key,
								targetPos = item3.Key,
								actionName = battleObject.m_SkillList[i],
								effectPosList = new List<Vector3Int>()
							};
							foreach (Vector3Int effectPos2 in forecast.effectPosList)
							{
								forecast2.effectPosList.Add(effectPos2 + vector3Int2);
							}
							battleObject.AttackForecastDict[standPos.Key].Add(forecast2);
						}
						else
						{
							Dictionary<Vector3Int, int> range2ByAttackType = AttackData.GetRange2ByAttackType(array2, item3.Key, item3.Value, standPos.Key, b03RowIn);
							List<Forecast> list = new List<Forecast>();
							if (battleObject.AttackForecastDict.ContainsKey(standPos.Key))
							{
								list = battleObject.AttackForecastDict[standPos.Key];
							}
							else
							{
								battleObject.AttackForecastDict.Add(standPos.Key, list);
							}
							forecast2 = new Forecast
							{
								actionPos = standPos.Key,
								targetPos = item3.Key,
								actionName = battleObject.m_SkillList[i],
								effectPosList = range2ByAttackType.Keys.ToList()
							};
							list.Add(forecast2);
						}
						forecast = forecast2;
						num3 = item3.Value;
						foreach (Vector3Int effectPos in forecast2.effectPosList)
						{
							bool num4 = battleObject.AttackForecastRange.TryAdd(effectPos, 0);
							if (battleObject.AttackForecastRange[effectPos] == 0 && array2[3] == "2" && SharedData.Instance().m_BattleController.allBattleObjs.Find((BattleObject x) => !x.isDead && x != battleObject && x.race == battleObject.race && x.isSelectable && x.GetGridPosition() == effectPos) != null)
							{
								battleObject.AttackForecastRange[effectPos] = 1;
							}
							if (num4)
							{
								InitAttackForecasTabele(battleObject, effectPos, battleObject.AttackForecastRange[effectPos]);
							}
						}
					}
				}
				yield return null;
			}
		}
		else
		{
			foreach (KeyValuePair<Vector3Int, int> standPos2 in battleObject.standPosList)
			{
				InitUnitTabele(battleObject, standPos2.Key);
			}
			foreach (KeyValuePair<Vector3Int, int> item4 in battleObject.AttackForecastRange)
			{
				InitAttackForecasTabele(battleObject, item4.Key, battleObject.AttackForecastRange[item4.Key]);
			}
		}
		isCalShowUnitRange = false;
		if (battleControllerFlow != BattleControllerFlow.None)
		{
			SharedData.Instance().m_BattleController.SetFlowState(battleControllerFlow);
		}
		if (battleObjectState != BattleObjectState.None)
		{
			battleObject.SetBattleObjState(battleObjectState);
		}
		yield return null;
	}

	private static void InitUnitTabele(BattleObject battleObject, Vector3Int pos)
	{
		GameObject gameObject = null;
		if (battleObject.m_State == BattleObjectState.HandOut)
		{
			gameObject = RangePoolManager.instance.GetObjectFromPool("Range");
		}
		else if (battleObject.race == "player")
		{
			gameObject = RangePoolManager.instance.GetObjectFromPool("RangeC");
			gameObject.transform.Find("Movement").GetComponent<TextMeshPro>();
		}
		else if (battleObject.race == "enemy")
		{
			gameObject = RangePoolManager.instance.GetObjectFromPool("RangeE");
		}
		gameObject.transform.localPosition = new Vector3(25 + pos.x * 50, -25 - pos.y * 50);
		rangeObject.Add(gameObject);
		gameObject.GetComponentInChildren<SpriteRenderer>().sortingOrder = ((SharedData.Instance().m_BattleController.m_underfoot_SortingOrder > 0) ? SharedData.Instance().m_BattleController.m_underfoot_SortingOrder : 0);
	}

	private static void InitAttackForecasTabele(BattleObject battleObject, Vector3Int pos, int type)
	{
		GameObject gameObject = null;
		if (!battleObject.unitRange.ContainsKey(pos) && SharedData.Instance().m_BattleController.obstacle.Contains(pos))
		{
			gameObject = ((type != 1) ? RangePoolManager.instance.GetObjectFromPool("AtkSelRange") : RangePoolManager.instance.GetObjectFromPool("HealSelRange"));
			gameObject.transform.localPosition = new Vector3(25 + pos.x * 50, -25 - pos.y * 50);
			rangeObject.Add(gameObject);
			gameObject.GetComponentInChildren<SpriteRenderer>().sortingOrder = ((SharedData.Instance().m_BattleController.m_underfoot_SortingOrder > 0) ? SharedData.Instance().m_BattleController.m_underfoot_SortingOrder : 0);
		}
	}

	public static void ShowAttackRange(BattleObject battleObject, string _type)
	{
		ClearUnitRange();
		ClearAttackRange();
		ClearAttackSelectRange();
		CalAttackRange(battleObject, _type);
		foreach (Vector3Int item in battleObject.attackRange)
		{
			GameObject objectFromPool = RangePoolManager.instance.GetObjectFromPool("AtkRange");
			objectFromPool.transform.localPosition = new Vector3(25 + item.x * 50, -25 - item.y * 50);
			AtkRangeObject.Add(objectFromPool);
			objectFromPool.GetComponentInChildren<SpriteRenderer>().sortingOrder = ((SharedData.Instance().m_BattleController.m_underfoot_SortingOrder > 0) ? SharedData.Instance().m_BattleController.m_underfoot_SortingOrder : 0);
		}
	}

	public static void ShowAttackSelectRange(BattleObject battleObject, Vector3Int attackPos)
	{
		ClearAttackSelectRange();
		battleObject.m_attackPos = attackPos;
		switch (SharedData.Instance().m_BattleController.GetCurrentObjActionType())
		{
		case ActionType.Formless:
		case ActionType.Fantan:
			battleObject.attackSelectRange.Add(battleObject.m_Revenge_Target.GetGridPosition());
			break;
		case ActionType.WugongCounter:
		case ActionType.Return:
		case ActionType.FormlessSuper:
		case ActionType.Ambush:
			CalAttackSelectRange(battleObject, battleObject.m_Revenge_Target.GetGridPosition());
			break;
		default:
			CalAttackSelectRange(battleObject, attackPos);
			break;
		}
		GameObject gameObject = null;
		foreach (Vector3Int item in battleObject.attackSelectRange)
		{
			if (SharedData.Instance().m_BattleController.obstacle.Contains(item))
			{
				gameObject = ((!"ITEM".Equals(battleObject.m_AttackType[0]) && !"2".Equals(battleObject.m_AttackType[3])) ? RangePoolManager.instance.GetObjectFromPool("AtkSelRange") : RangePoolManager.instance.GetObjectFromPool("HealSelRange"));
				gameObject.transform.localPosition = new Vector3(25 + item.x * 50, -25 - item.y * 50);
				AtkSelRangeObject.Add(gameObject);
				gameObject.GetComponentInChildren<SpriteRenderer>().sortingOrder = ((SharedData.Instance().m_BattleController.m_attackselectrange_SortingOrder > 0) ? SharedData.Instance().m_BattleController.m_attackselectrange_SortingOrder : 0);
			}
		}
	}

	private static void ChangeAttackSelectRangeColor(BattleObject battleObject, Vector3Int attackPos)
	{
		if (float.Parse(battleObject.m_SkillRow.kf.Decreaserate, CultureInfo.InvariantCulture) == 0f)
		{
			return;
		}
		Color white = Color.white;
		float num = float.MaxValue;
		float num2 = float.MinValue;
		float num3 = 0.5f;
		foreach (Vector3Int item in battleObject.attackSelectRange)
		{
			float num4 = Vector3Int.Distance(item, attackPos);
			if (num4 < num)
			{
				num = num4;
			}
			if (num4 > num2)
			{
				num2 = num4;
			}
		}
		int num5 = 0;
		foreach (Vector3Int item2 in battleObject.attackSelectRange)
		{
			float num6 = Vector3Int.Distance(item2, attackPos);
			if (float.Parse(battleObject.m_SkillRow.kf.Decreaserate, CultureInfo.InvariantCulture) > 0f)
			{
				white.a = (num - num6) * (1f - num3) / (num2 - num) + 1f;
			}
			else if (float.Parse(battleObject.m_SkillRow.kf.Decreaserate, CultureInfo.InvariantCulture) < 0f)
			{
				white.a = (num6 - num2) * (1f - num3) / (num2 - num) + 1f;
			}
			AtkSelRangeObject[num5].GetComponentInChildren<SpriteRenderer>().color = white;
			num5++;
		}
	}

	public static void ClearUnitRange()
	{
		foreach (GameObject item in rangeObject)
		{
			if (item != null)
			{
				item.SetActive(value: false);
			}
		}
		rangeObject.Clear();
	}

	public static void ClearAttackRange()
	{
		foreach (GameObject item in AtkRangeObject)
		{
			if (item != null)
			{
				item.SetActive(value: false);
			}
		}
		AtkRangeObject.Clear();
	}

	public static void ClearAttackSelectRange()
	{
		foreach (GameObject item in AtkSelRangeObject)
		{
			if (item != null)
			{
				item.SetActive(value: false);
			}
		}
		AtkSelRangeObject.Clear();
	}

	public static void ClearAllRange()
	{
		ClearUnitRange();
		ClearAttackRange();
		ClearAttackSelectRange();
	}
}
