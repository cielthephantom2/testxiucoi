using UnityEngine;

public class SelectLangObject : MonoBehaviour
{
	private GameObject text;

	private GameObject text_EN;

	private GameObject text_CHT;

	private GameObject text_JPN;

	private void Start()
	{
		text = base.transform.Find("LangObj").gameObject;
		text_EN = base.transform.Find("LangObj_English").gameObject;
		Transform transform = base.transform.Find("LangObj_Traditional");
		if (transform != null)
		{
			text_CHT = transform.gameObject;
		}
		transform = base.transform.Find("LangObj_Japanese");
		if (transform != null)
		{
			text_JPN = transform.gameObject;
		}
		switch (GameDataManager.Instance().configdata.language)
		{
		case "English":
			text.SetActive(value: false);
			text_EN.SetActive(value: true);
			if (text_CHT != null)
			{
				text_CHT.SetActive(value: false);
			}
			if (text_JPN != null)
			{
				text_JPN.SetActive(value: false);
			}
			break;
		case "ChineseTraditional":
			text_EN.SetActive(value: false);
			if (text_CHT != null)
			{
				text_CHT.SetActive(value: true);
				text.SetActive(value: false);
			}
			else
			{
				text.SetActive(value: true);
			}
			if (text_JPN != null)
			{
				text_JPN.SetActive(value: false);
			}
			break;
		case "Japanese":
			text_EN.SetActive(value: false);
			if (text_JPN != null)
			{
				text_JPN.SetActive(value: true);
				text.SetActive(value: false);
			}
			else
			{
				text.SetActive(value: true);
			}
			if (text_CHT != null)
			{
				text_CHT.SetActive(value: false);
			}
			break;
		default:
			text.SetActive(value: true);
			text_EN.SetActive(value: false);
			if (text_CHT != null)
			{
				text_CHT.SetActive(value: false);
			}
			if (text_JPN != null)
			{
				text_JPN.SetActive(value: false);
			}
			break;
		}
	}
}
