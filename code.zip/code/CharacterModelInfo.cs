using System;

public class CharacterModelInfo : IComparable<CharacterModelInfo>
{
	public gang_b01SkinTable.Row b01SkinRow;

	public string id;

	public CharacterModelSource soucre;

	public string name;

	public string battleIcon;

	public string prefab;

	public bool isSkin;

	public bool isSkinFalse;

	public bool isNotSkinFalse;

	public bool isBattleIconFalse;

	public bool isTachieFalse;

	public bool isHeadTachieFalse;

	public int CompareTo(CharacterModelInfo other)
	{
		if (soucre == other.soucre)
		{
			return name.CompareTo(other.name);
		}
		return soucre.CompareTo(other.soucre);
	}
}
