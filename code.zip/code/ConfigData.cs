using System;
using System.Collections.Generic;
using MessagePack;

[Serializable]
[MessagePackObject(false)]
public class ConfigData
{
	[Key(0)]
	public List<string> saveDataList = new List<string>();

	[Key(1)]
	public List<string> snapshotList = new List<string>();

	[Key(2)]
	public List<float> gameDurationList = new List<float>();

	[Key(3)]
	public List<string> LastWriteTime = new List<string>();

	[Key(4)]
	public List<List<string>> FollowerIconList = new List<List<string>>();

	[Key(5)]
	public int lastSaveId = 1;

	[Key(6)]
	public int playRound;

	[Key(7)]
	public float masterVolume = -6f;

	[Key(8)]
	public float musicVolume = -6f;

	[Key(9)]
	public float seVolume = -6f;

	[Key(10)]
	public int screenmode;

	[Key(11)]
	public int resolution = 2;

	[Key(12)]
	public string inheritItems = "";

	[Key(13)]
	public string language = "";

	[Key(14)]
	public int m_create_serial_id = 1000;

	[Key(15)]
	public bool isMasterMute;

	[Key(16)]
	public bool isMusicMute;

	[Key(17)]
	public bool isSEMute;

	[Key(18)]
	public List<List<gang_b01SkinTable.Row>> FollowerIconB01SkinList = new List<List<gang_b01SkinTable.Row>>();

	[Key(19)]
	public int gameSpeed = 1;

	[Key(20)]
	public GameIconType gameIconType;

	[Key(21)]
	public int currentAutoSaveIndex = 16;

	[Key(22)]
	public int InheritItemCount = 1;

	[Key(23)]
	public List<string> b02append = new List<string>();

	[Key(24)]
	public List<string> b03append = new List<string>();

	[Key(25)]
	public List<string> b07append = new List<string>();

	[IgnoreMember]
	public bool isEAPlayer;

	public ConfigData()
	{
		for (int i = 0; i < 24; i++)
		{
			saveDataList.Add("Empty");
			snapshotList.Add("");
			gameDurationList.Add(0f);
			LastWriteTime.Add("");
			FollowerIconList.Add(new List<string>());
			FollowerIconB01SkinList.Add(new List<gang_b01SkinTable.Row>());
		}
	}
}
