using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DataRecordManager : MonoBehaviour
{
	private SaveOrLoad _dataType = SaveOrLoad.Load;

	private LoadDataType _loadDataType;

	private bool isUpdatingDisplay;

	private bool isReadFileDone;

	private GameObject ChoosePanel;

	private GameObject ConfirmPanel;

	private GameObject DoingPanel;

	private GameObject DataDoingPanel;

	private string[] dataflag = new string[24]
	{
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0"
	};

	private int confirmid;

	private bool processing;

	private ScrollRect AutoSaveSR;

	private GameObject confirmObj;

	private Sprite normalSprite;

	private Sprite selectedSprite;

	public SaveOrLoad DataType
	{
		get
		{
			return _dataType;
		}
		set
		{
			_dataType = value;
			SetDataTye();
		}
	}

	public LoadDataType loadDataType
	{
		get
		{
			return _loadDataType;
		}
		set
		{
			_loadDataType = value;
			SetLoadGameRecordType();
		}
	}

	private void Start()
	{
		Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
		normalSprite = Resources.Load("images/01-border/boder-20231228-01", typeof(Sprite)) as Sprite;
		selectedSprite = Resources.Load("images/01-border/boder-20231228-05", typeof(Sprite)) as Sprite;
		ChoosePanel = base.transform.Find("Panel/GameRecord").gameObject;
		AutoSaveSR = base.transform.Find("Panel/GameRecordAuto").GetComponent<ScrollRect>();
		ConfirmPanel = base.transform.Find("Panel/Confirm").gameObject;
		DoingPanel = base.transform.Find("Panel/Doing").gameObject;
		DataDoingPanel = base.transform.Find("Panel/DataDoing").gameObject;
		DataDoingPanel.SetActive(value: true);
		Button[] componentsInChildren = base.transform.Find("Panel").GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button obj in componentsInChildren)
		{
			obj.name.Split('|');
			EventTriggerListener.Get(obj.gameObject).onClick = OnButtonClick;
		}
		StartCoroutine(ReadFileASync());
	}

	private void OnEnable()
	{
		StartCoroutine(isAutoSaving());
		if (isReadFileDone)
		{
			GetComponent<CanvasGroup>().interactable = true;
			processing = false;
			DataDoingPanel.SetActive(value: false);
			DoingPanel.SetActive(value: false);
			Cursor.SetCursor(null, Vector2.one, CursorMode.ForceSoftware);
			InputDeviceDetector.instance.PushJoyStack();
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|0").gameObject);
			if (DataType.Equals(SaveOrLoad.Load))
			{
				SetLoadGameRecordType();
			}
			else
			{
				EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|0").gameObject);
			}
		}
	}

	private IEnumerator isAutoSaving()
	{
		if (SharedData.Instance().m_IsAutoSaving)
		{
			DoingPanel?.SetActive(value: true);
		}
		yield return SharedData.Instance().m_IsAutoSaving;
		DoingPanel?.SetActive(value: false);
	}

	private void Update()
	{
		if (SharedData.Instance().m_IsAutoSaving || DataDoingPanel.activeInHierarchy || DoingPanel.activeInHierarchy || isUpdatingDisplay || processing || !isReadFileDone)
		{
			return;
		}
		if (InputSystemCustom.Instance().UI.Cancel.WasReleasedThisFrame() || InputDeviceDetector.isMouse1Up)
		{
			if (ConfirmPanel.activeInHierarchy)
			{
				ConfirmPanel.SetActive(value: false);
				EventSystem.current.SetSelectedGameObject(confirmObj);
			}
			else
			{
				ExecuteEvents.Execute(base.transform.Find("Panel/Return").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
			}
		}
		else if (InputSystemCustom.Instance().UI.AutoSaveBtn.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/AutoSaveBtn").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
		else if (InputSystemCustom.Instance().UI.ManualSaveBtn.WasReleasedThisFrame())
		{
			ExecuteEvents.Execute(base.transform.Find("Panel/ManualSaveBtn").gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
		}
	}

	private void SetDataTye()
	{
		if (_dataType == SaveOrLoad.Save)
		{
			base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_UI_Save_Data_Title");
			base.transform.Find("Panel/Confirm/Yes/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_UI_Save_Data_Confirm_Yes");
			base.transform.Find("Panel/Doing/Image/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_UI_Saving_Data");
			ChoosePanel?.gameObject.SetActive(value: true);
			AutoSaveSR?.gameObject.SetActive(value: false);
		}
		else if (_dataType == SaveOrLoad.Load)
		{
			base.transform.Find("Panel/Title/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_UI_Load_Data_Title");
			base.transform.Find("Panel/Confirm/Yes/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_UI_Load_Data_Confirm_Yes");
			base.transform.Find("Panel/Doing/Image/Text").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_UI_Loading_Data");
			ChoosePanel?.gameObject.SetActive(value: true);
			AutoSaveSR?.gameObject.SetActive(value: true);
		}
	}

	private void SetLoadGameRecordType()
	{
		ChoosePanel.gameObject.SetActive(!loadDataType.Equals(LoadDataType.Auto));
		AutoSaveSR.gameObject.SetActive(loadDataType.Equals(LoadDataType.Auto));
		base.transform.Find("Panel/AutoSaveBtn").GetComponent<Image>().sprite = (loadDataType.Equals(LoadDataType.Auto) ? selectedSprite : normalSprite);
		base.transform.Find("Panel/ManualSaveBtn").GetComponent<Image>().sprite = (loadDataType.Equals(LoadDataType.Manual) ? selectedSprite : normalSprite);
		if (loadDataType.Equals(LoadDataType.Manual))
		{
			EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|0").gameObject);
			return;
		}
		int num = 0;
		for (int num2 = GameDataManager.Instance().configdata.currentAutoSaveIndex - 1; num2 >= 16; num2--)
		{
			AutoSaveSR.content.Find("Data|" + num2).SetSiblingIndex(num++);
		}
		for (int num3 = 23; num3 > GameDataManager.Instance().configdata.currentAutoSaveIndex - 1; num3--)
		{
			AutoSaveSR.content.Find("Data|" + num3).SetSiblingIndex(num++);
		}
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/GameRecordAuto/Viewport/Content").GetChild(0).gameObject);
	}

	public void OnButtonClick(GameObject go)
	{
		if (SharedData.Instance().m_IsAutoSaving || DataDoingPanel.activeInHierarchy || DoingPanel.activeInHierarchy || isUpdatingDisplay || processing || !isReadFileDone || go == null || !go.activeInHierarchy || go.GetComponent<Button>() == null || !go.GetComponent<Button>().IsInteractable())
		{
			return;
		}
		string[] array = go.name.Split('|');
		if (array[0] == "Data")
		{
			int num = 0;
			num = ((!array[1].Equals("Newest")) ? int.Parse(array[1]) : (GameDataManager.Instance().configdata.currentAutoSaveIndex - 1));
			if (DataType == SaveOrLoad.Save)
			{
				if (num < 16)
				{
					if (dataflag[num] == "1")
					{
						ConfirmPanel.SetActive(value: true);
						confirmObj = go;
						confirmid = num;
						EventSystem.current.SetSelectedGameObject(ConfirmPanel.transform.Find("No").gameObject);
					}
					else
					{
						DoingPanel.SetActive(value: true);
						processing = true;
						StartCoroutine(DataSaving(num));
					}
				}
			}
			else if (!(dataflag[num] == "0") && go.transform.Find("HaveData").gameObject.activeInHierarchy)
			{
				ConfirmPanel.SetActive(value: true);
				confirmObj = go;
				confirmid = num;
				EventSystem.current.SetSelectedGameObject(ConfirmPanel.transform.Find("No").gameObject);
			}
		}
		else if (array[0] == "Yes")
		{
			DoingPanel.SetActive(value: true);
			ConfirmPanel.SetActive(value: false);
			processing = true;
			GetComponent<CanvasGroup>().interactable = false;
			if (DataType == SaveOrLoad.Save)
			{
				StartCoroutine(DataSaving(confirmid));
				return;
			}
			GameDataManager.Instance().sceneLoadData = true;
			SharedData.Instance(init: true);
			SharedData.Instance().starGameTimeSpan = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			StartCoroutine(DataLoading());
		}
		else if (array[0] == "No")
		{
			EventSystem.current.SetSelectedGameObject(confirmObj);
			ConfirmPanel.SetActive(value: false);
		}
		else if (array[0] == "ChooseOK")
		{
			ExitScene();
		}
		else if (array[0] == "Return")
		{
			ExitScene();
		}
		else if (array[0] == "AutoSaveBtn")
		{
			loadDataType = LoadDataType.Auto;
		}
		else if (array[0] == "ManualSaveBtn")
		{
			loadDataType = LoadDataType.Manual;
		}
	}

	private IEnumerator DataSaving(int _id)
	{
		for (int i = 0; i <= 15; i++)
		{
			base.transform.Find("Panel/GameRecord/Viewport/Content/Data|" + i + "/HaveData/New").gameObject.SetActive(value: false);
		}
		StartCoroutine(GameDataManager.Instance().Save(_id + 1));
		while (GameDataManager.Instance().isSaving)
		{
			yield return null;
		}
		UpdateSpecial(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|" + _id).GetComponent<Button>(), _id);
		yield return null;
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|" + _id).gameObject);
		yield return new WaitForSeconds(0.1f);
		DoingPanel.SetActive(value: false);
		processing = false;
		GetComponent<CanvasGroup>().interactable = true;
		yield return null;
	}

	private IEnumerator DataLoading()
	{
		SharedData.Instance().m_FinalSubdueList.Clear();
		SharedData.Instance().m_SubdueList.Clear();
		StartCoroutine(GameDataManager.Instance().Load(confirmid + 1));
		while (GameDataManager.Instance().isRestoreData)
		{
			yield return null;
		}
		processing = false;
		GetComponent<CanvasGroup>().interactable = true;
		if (SharedData.Instance().SceneBefore == "")
		{
			SharedData.Instance().ASyncLoadScene("Starter1");
		}
		else if (SharedData.Instance().SceneBefore4Camp.Length > 0)
		{
			SharedData.Instance().ASyncLoadScene(SharedData.Instance().SceneBefore4Camp);
		}
		else if (SharedData.Instance().SceneBefore.Length > 0)
		{
			SharedData.Instance().BackFromOtherScene = true;
			SharedData.Instance().ASyncLoadScene(SharedData.Instance().SceneBefore);
		}
		SharedData.Instance().LoadedSceneStack.Clear();
	}

	private void ExitScene()
	{
		InputSystemCustom.Instance().Player.Enable();
		SharedData.Instance().LoadedSceneStack.Clear();
		if (SharedData.Instance().m_MenuController != null)
		{
			SharedData.Instance().m_MenuController.GetComponent<CanvasGroup>().interactable = true;
		}
		if (SharedData.Instance().m_titleController != null)
		{
			SharedData.Instance().m_titleController.GetComponent<CanvasGroup>().interactable = true;
		}
		CommonResourcesData.inputDeviceDetector.ResetJoyCurce();
		base.gameObject.SetActive(value: false);
	}

	private IEnumerator ReadFileASync()
	{
		while (SharedData.Instance().m_IsAutoSaving)
		{
			yield return null;
		}
		yield return null;
		Button[] componentsInChildren = ChoosePanel.GetComponentsInChildren<Button>(includeInactive: true);
		int dataID = 0;
		Button[] array = componentsInChildren;
		foreach (Button button in array)
		{
			if (!(button.name == "ChooseOK"))
			{
				if (button.name.StartsWith("Data|"))
				{
					dataID = ((!button.name.Equals("Data|Newest")) ? int.Parse(button.name.Split("|")[1]) : (GameDataManager.Instance().configdata.currentAutoSaveIndex - 1));
				}
				UpdateSpecial(button, dataID);
				yield return null;
			}
		}
		dataID = 16;
		componentsInChildren = AutoSaveSR.GetComponentsInChildren<Button>(includeInactive: true);
		array = componentsInChildren;
		foreach (Button button2 in array)
		{
			if (!(button2.name == "ChooseOK"))
			{
				if (button2.name.StartsWith("Data|"))
				{
					dataID = int.Parse(button2.name.Split("|")[1]);
				}
				UpdateSpecial(button2, dataID);
				yield return null;
			}
		}
		isUpdatingDisplay = false;
		yield return new WaitForSeconds(0.1f);
		DataDoingPanel.SetActive(value: false);
		DoingPanel.SetActive(value: false);
		isReadFileDone = true;
		InputDeviceDetector.instance.PushJoyStack();
		EventSystem.current.SetSelectedGameObject(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|0").gameObject);
	}

	public void UpdateSpecial(Button DataItem, int dataID)
	{
		if (dataID >= 24)
		{
			return;
		}
		isUpdatingDisplay = true;
		string fileInfo = GameDataManager.Instance().GetFileInfo(dataID + 1);
		if (fileInfo.Length > 0)
		{
			dataflag[dataID] = "1";
			List<string> list = new List<string>
			{
				GameDataManager.Instance().configdata.saveDataList[dataID],
				GameDataManager.Instance().configdata.snapshotList[dataID],
				GameDataManager.Instance().configdata.gameDurationList[dataID].ToString()
			};
			string[] array = list[0].Split('|');
			if (array[0] != "Empty")
			{
				DataItem.transform.Find("HaveData").gameObject.SetActive(value: true);
				DataItem.transform.Find("NoData").gameObject.SetActive(value: false);
				if (array.Length > 3)
				{
					string text = "";
					text = array[3] switch
					{
						"0" => CommonFunc.I18nGetLocalizedValue("I18N_Original"), 
						"1" => CommonFunc.I18nGetLocalizedValue("I18N_StoryMode"), 
						"2" => CommonFunc.I18nGetLocalizedValue("I18N_AdventureMode"), 
						_ => CommonFunc.I18nGetLocalizedValue("I18N_Unknown"), 
					};
					DataItem.transform.Find("HaveData/Name").GetComponent<Text>().text = "[" + CommonFunc.ShortLangSel(SharedData.Instance().Translate2Hanzi(int.Parse(array[1])) + "周目", "Round " + array[1], SharedData.Instance().Translate2Hanzi(int.Parse(array[1])) + "周目") + "][" + text + "] " + CommonResourcesData.e04.Find_id(array[0]).name_Trans + " - " + fileInfo + " <size=24>[" + array[2] + "]</size>";
				}
				else if (array.Length > 2)
				{
					DataItem.transform.Find("HaveData/Name").GetComponent<Text>().text = "[" + CommonFunc.ShortLangSel(SharedData.Instance().Translate2Hanzi(int.Parse(array[1])) + "周目", "Round " + array[1], SharedData.Instance().Translate2Hanzi(int.Parse(array[1])) + "周目") + "] " + CommonResourcesData.e04.Find_id(array[0]).name_Trans + " - " + fileInfo + " <size=24>[" + array[2] + "]</size>";
				}
				else if (array.Length > 1)
				{
					DataItem.transform.Find("HaveData/Name").GetComponent<Text>().text = "[" + CommonFunc.ShortLangSel(SharedData.Instance().Translate2Hanzi(int.Parse(array[1])) + "周目", "Round " + array[1], SharedData.Instance().Translate2Hanzi(int.Parse(array[1])) + "周目") + "] " + CommonResourcesData.e04.Find_id(array[0]).name_Trans + " - " + fileInfo;
				}
				else
				{
					DataItem.transform.Find("HaveData/Name").GetComponent<Text>().text = CommonFunc.I18nGetLocalizedValue("I18N_DataOld") + CommonResourcesData.e04.Find_id(array[0]).name_Trans + " - " + fileInfo;
				}
				if (dataID < 16)
				{
					DataItem.transform.Find("HaveData/New").gameObject.SetActive(GameDataManager.Instance().LastSaveId() - 1 == dataID);
				}
				else
				{
					DataItem.transform.Find("HaveData/New").gameObject.SetActive(value: false);
				}
				if (!string.IsNullOrEmpty(list[1]))
				{
					byte[] data = Convert.FromBase64String(list[1]);
					Texture2D texture2D = new Texture2D(340, 180);
					texture2D.LoadImage(data);
					Sprite sprite = Sprite.Create(texture2D, new Rect(0f, 0f, texture2D.width, texture2D.height), new Vector2(0.5f, 0.5f));
					DataItem.transform.Find("HaveData/SnapShotMask/SnapShot").GetComponent<Image>().sprite = sprite;
				}
				if (list[2] != "")
				{
					TimeSpan timeSpan = TimeSpan.FromSeconds(float.Parse(list[2], CultureInfo.InvariantCulture));
					string text2 = $"{(int)Math.Floor(timeSpan.TotalHours)} " + CommonFunc.I18nGetLocalizedValue("I18N_Hours") + $" {timeSpan.Minutes:D2} " + CommonFunc.I18nGetLocalizedValue("I18N_Minutes") + $" {timeSpan.Seconds:D2} " + CommonFunc.I18nGetLocalizedValue("I18N_Seconds") + " ";
					DataItem.transform.Find("HaveData/GameDuration").GetComponent<Text>().text = text2;
				}
			}
		}
		DataItem.transform.Find("HaveData/IconList").GetComponent<IconListController>().InitIconList(GameDataManager.Instance().configdata.FollowerIconList[dataID], showLevel: true, GameDataManager.Instance().configdata.FollowerIconB01SkinList[dataID]);
		isUpdatingDisplay = false;
	}

	public void UpdateAutoItem(int index)
	{
		UpdateSpecial(base.transform.Find("Panel/GameRecord/Viewport/Content/Data|Newest").GetComponent<Button>(), GameDataManager.Instance().configdata.currentAutoSaveIndex - 1);
		UpdateSpecial(base.transform.Find("Panel/GameRecordAuto/Viewport/Content/Data|" + (index - 1)).GetComponent<Button>(), index - 1);
	}
}
